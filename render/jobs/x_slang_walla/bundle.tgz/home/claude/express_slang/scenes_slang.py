"""scenes_slang.py (2 Nov 2026): "Hebrew slang in English" series for @expressenglishcom. Navy stage (story continuity with
stories/1102 sababa: navy, sky, yellow), a white scene panel with stick figures (blue = the Israeli speaker / active,
orange = the foreign colleague / passive, red = the new English words inside the bubble). Hebrew only as on-screen text.

Scene types
  slang_hook {"he": slang, "setting"}                    frame 0: "How do you say <he>?" + the scene, colleague puzzled
  slang      {"he", "setting", "who", "bubble", "by_me", "casual", "wrong", "hears", "biz",
              "marks": {"s": casual spoken, "n": "Not", "h": "hears", "b": biz spoken}}
             phases: bubble (line 2) -> Say casual (s) -> Not wrong + colleague confused (n, h) -> At work biz (b)
Loads scenes_situ (figures, settings, bubbles) which loads scenes_x (loop cross-fade, looping music bed).
"""
import importlib.util, math
_p = "/home/claude/express_slang/scenes_situ.py"
_s = importlib.util.spec_from_file_location("scenes_situ", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
for _k, _v in vars(_m).items():
    if _k.startswith("sc_"): globals()[_k] = _v
import render as RD
from render import P, T, PP, fade_in, block, block_h, pill
from kit import ease, St, sa, rr
from kit import font as kfont
figure, _panel, _bubble, _setting_situ, _mark = _m.figure, _m._panel, _m._bubble, _m._setting, _m._mark
BLUE, ORANGE, INK = _m.BLUE, _m.ORANGE, _m.INK

WHITE = (1, 1, 1, 1.0); YELLOW = (1.0, 0xCD / 255, 0x50 / 255, 1.0); SKY = (0x45 / 255, 0xA4 / 255, 0xDD / 255, 1.0)
NEWRED = (0xD6 / 255, 0x3A / 255, 0x4A / 255, 1.0); GREYW = (1, 1, 1, 0.62)
CHIP = "HEBREW SLANG IN ENGLISH"


def _coffee(c, x, yf, h):
    """a simple coffee machine on a counter, centred at x"""
    w = h * 0.55; top = yf - h * 0.78
    sa(c, (0.62, 0.48, 0.34, 1.0), St.a); rr(c, x - w * 0.95, yf - h * 0.30, w * 1.9, 22, 8); c.fill()    # counter
    sa(c, (0.25, 0.29, 0.36, 1.0), St.a); rr(c, x - w / 2, top, w, h * 0.48, 18); c.fill()               # body
    sa(c, (0.45, 0.50, 0.58, 1.0), St.a); rr(c, x - w / 2 + 16, top + 18, w - 32, 34, 10); c.fill()      # panel
    sa(c, SKY, St.a); c.arc(x + w * 0.25, top + 35, 8, 0, 2 * math.pi); c.fill()
    sa(c, WHITE, St.a); rr(c, x - 26, yf - h * 0.30 - 64, 52, 62, 10); c.fill()                          # cup
    sa(c, INK, 0.35 * St.a); c.set_line_width(4)
    for k in range(3):   # steam
        xx = x - 14 + k * 14; c.move_to(xx, yf - h * 0.30 - 74)
        c.curve_to(xx - 10, yf - h * 0.30 - 94, xx + 10, yf - h * 0.30 - 104, xx, yf - h * 0.30 - 124); c.stroke()


def _scene(c, kind, x0, y0, x1, y1, t, me, them, h, yf):
    """draw the setting; returns (my head point, their head point) for bubble tails"""
    if kind == "zoom":
        tail = _setting_situ(c, "zoom", x0, y0, x1, y1, t, me, them, h, yf)
        n = 3; gap = 22; tw = (x1 - x0 - 40 - gap * (n - 1)) / n
        return tail, (x0 + 20 + 2 * (tw + gap) + tw / 2, tail[1])
    if kind == "coffee":
        _coffee(c, (x0 + x1) / 2, yf, h)
        tail = _setting_situ(c, "plain", x0, y0, x1, y1, t, me, them, h, yf)
    else:
        tail = _setting_situ(c, kind, x0, y0, x1, y1, t, me, them, h, yf)
    return tail, (x1 - 190 - 40, tail[1])


def _hook_title(c, t, he, y, a=1.0, s=1.0):
    T(c, "How do you say", 118, 540, y, WHITE, a, s, 900, maxw=960)
    z = 190; f = kfont(z, 900)
    while z > 90 and f.getlength(he) + 0.5 * z > 940: z -= 4; f = kfont(z, 900)
    wq = kfont(z, 900).getlength("?"); w_he = kfont(z, 900).getlength(he)
    br = 1.0 + 0.02 * math.sin(t * 2.4)
    T(c, he, z, 540 - wq / 2 - 6, y + 70 + z * 0.62, YELLOW, a, s * br, 900, maxw=940)
    T(c, "?", z, 540 + w_he / 2 + 4, y + 70 + z * 0.62, WHITE, a, s * br, 900, maxw=200)
    return y + 70 + z * 1.25


def sc_slang_hook(c, t, S):
    pill(c, CHIP, 40, 540, 300, SKY, WHITE, 1.0, 1.0, w=800)
    yb = _hook_title(c, t, S["he"], 450)
    y0 = max(yb + 30, 820); y1 = 1460
    _panel(c, 70, y0, 1010, y1)
    h = min(470, (y1 - y0) - 120); yf = y1 - 45
    them = "listen" if (t % 2.6) < 1.3 else "shock"
    _scene(c, S.get("setting", "office"), 70, y0, 1010, y1, t, "talk", them, h, yf)
    T(c, "?", 120, 1010 - 190 + 6 * math.sin(t * 5), yf - h - 60, ORANGE, 1.0, 1.0 + 0.06 * math.sin(t * 6), 900)


def _strike(c, txt, z, y, k, color):
    zz, ls = RD.wrap(txt, z, 800, 900, 1)
    lw_ = min(900, kfont(zz, 800).getlength(txt.replace("*", "")))
    sa(c, color, St.a); c.set_line_width(7); c.move_to(540 - lw_ / 2, y + 4); c.line_to(540 - lw_ / 2 + lw_ * k, y + 4); c.stroke()


def sc_slang(c, t, S):
    t0 = S["t0"]; tm = S["times"]
    ts = tm.get("s", t0 + 2.0); tn = tm.get("n", ts + 2.0); th = tm.get("h", tn + 1.0); tb = tm.get("b", th + 2.0)
    pill(c, CHIP, 40, 540, 300, SKY, WHITE, fade_in(t, t0, S, 0.2), 1.0, w=800)
    # scene panel
    x0, y0, x1, y1 = 70, 360, 1010, 980
    pa = fade_in(t, t0, S, 0.25); old = St.a; St.a *= pa
    _panel(c, x0, y0, x1, y1)
    by_me = S.get("by_me")
    if t < ts - 0.1:  me, them = ("talk", "listen") if by_me else ("listen", "talk")
    elif t < tn - 0.1: me, them = "talk", "happy"
    elif t < tb - 0.1: me, them = "talk", ("listen" if t < th - 0.05 else "shock")
    else: me, them = "talk", "happy"
    mytail, theirtail = _scene(c, S.get("setting", "office"), x0, y0, x1, y1, t, me, them, 290, y1 - 40)
    St.a = old
    if tn - 0.1 <= t < tb - 0.1 and t >= th - 0.05:
        T(c, "?!", 100, x1 - 190 + 6 * math.sin(t * 5), y0 + 250, ORANGE, pa, 1.0 + 0.05 * math.sin(t * 6), 900)
    # the speech bubble: line 2 bubble, then casual, then the wrong literal, then the business line
    if t < ts - 0.1: txt, who, k0, col = S["bubble"], ("me" if by_me else "them"), t0, INK
    elif t < tn - 0.1: txt, who, k0, col = S["casual"], "me", ts, INK
    elif t < tb - 0.1: txt, who, k0, col = S["wrong"], "me", tn, (0.45, 0.48, 0.55, 1.0)
    else: txt, who, k0, col = S["biz"], "me", tb, INK
    ba, bs = PP(t, k0 - 0.1, S, bounce=2.2)
    hn = block_h(txt, 70, 800, 820, 2); by0 = y0 + 26; by1 = by0 + hn + 56
    tail = mytail if who == "me" else theirtail
    _bubble(c, x0 + 30, by0, x1 - 30, by1, (tail[0] + (10 if who == "me" else -10), by1 + 50), BLUE if who == "me" else ORANGE, ba)
    old = St.a; St.a *= ba
    block(c, txt, 70, 540, (by0 + by1) / 2, col, 1.0, bs, 800, hl=NEWRED, maxw=820, max_lines=2)
    St.a = old
    # rows under the panel
    ya, ys = PP(t, ts - 0.1, S, bounce=2.2)          # 1. Say: casual
    if ya > 0.01:
        pill(c, "Say", 44, 540, 1050, SKY, WHITE, ya, ys, w=800)
        block(c, S["casual"], 88, 540, 1132, WHITE, ya, ys, 900, hl=YELLOW, maxw=960, max_lines=1)
    na, ns = PP(t, tn - 0.1, S, bounce=2.2)          # 2. Not: the literal translation, struck, + what they hear
    if na > 0.01:
        wr = S["wrong"]; zz, _ = RD.wrap(wr, 72, 800, 760, 1); wl = kfont(zz, 800).getlength(wr)
        old = St.a; St.a *= na; _mark(c, 540 + 20 - wl / 2 - 50, 1245, 28, False); St.a = old
        T(c, wr, 72, 540 + 20, 1245, GREYW, na, ns, 800, maxw=760)
        if t >= th - 0.05:
            k = ease((t - th + 0.05) / 0.3); old = St.a; St.a *= na
            sa(c, NEWRED, 0.9 * St.a); c.set_line_width(7); c.move_to(540 + 20 - wl / 2, 1249); c.line_to(540 + 20 - wl / 2 + wl * k, 1249); c.stroke()
            St.a = old
            ha, hs = PP(t, th - 0.05, S, bounce=2.2)
            T(c, f"{S['pron']} hears: {S['hears']}", 60, 540, 1318, ORANGE, ha, hs, 800, maxw=940)
    wa, ws = PP(t, tb - 0.1, S, bounce=2.2)          # 3. At work: business-safe
    if wa > 0.01:
        pill(c, "At work", 44, 540, 1405, BLUE, WHITE, wa, ws, w=800)
        block(c, S["biz"], 84, 540, 1482, WHITE, wa, ws, 900, hl=YELLOW, maxw=960, max_lines=1)
    # the Hebrew the Israeli wants to say: one small line at the bottom
    T(c, f"בעברית: {S['he']}", 52, 540, 1568, YELLOW, fade_in(t, t0 + 0.2, S, 0.3), 1.0, 700, maxw=900)
