"""scenes_slang2.py (10 Nov 2026): "Hebrew slang in English" batch 2 (format v2) for @expressenglishcom.
Navy stage, white scene panel with stick figures (blue = the Israeli speaker / active, orange = the colleague / passive, red =
the new English words), Apple-clean cards. Hebrew only on screen: the frame-0 hook and one small bottom line.

Scene types
  slang2       frame 0: hook "Say <he> in English?" over the scene + empty option cards. The colleague's bubble, then each
               option pops (bubble + its card) on its spoken words; a "Your turn: say it out loud" cue in the pauses;
               the dictionary source in a small label. marks: o<k> option k spoken, e<k> last word of option line k.
  slang2_chat  one mini chat (3 messages: them / me / them) in a chat window. marks: c<k> message k spoken.
  slang2_save  the hook again at the top (same place as frame 0, so the loop is seamless), a recap card of the options and
               "Save this for your next meeting" with a bookmark. marks: s.
Loads scenes_slang -> scenes_situ -> scenes_x (loop cross-fade into frame 0, looping music bed).
"""
import importlib.util, math
_p = "/home/claude/express_slang/scenes_slang.py"
_s = importlib.util.spec_from_file_location("scenes_slang", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
import render as RD
from render import P, T, PP, fade_in, block, block_h, pill
from kit import ease, St, sa, rr, ramp
from kit import font as kfont
_scene, _panel, _bubble, figure = _m._scene, _m._panel, _m._bubble, _m.figure
BLUE, ORANGE, INK = _m.BLUE, _m.ORANGE, _m.INK
WHITE, YELLOW, SKY, NEWRED, GREYW = _m.WHITE, _m.YELLOW, _m.SKY, _m.NEWRED, _m.GREYW
CHIP = "HEBREW SLANG IN ENGLISH"
PX0, PY0, PX1, PY1 = 70, 350, 1010, 900          # scene panel
TAGCOL = {"Casual": SKY, "Or": SKY, "At work": BLUE}


def _he_hook(he): return he.rstrip("?").strip()


def hook(c, t, he, a=1.0, s=1.0):
    """'Say <he>' (Hebrew in yellow) over 'in English?', always in the same place (frame 0 and the end card)"""
    if a <= 0.01: return
    h = _he_hook(he); z = 136
    while z > 90 and kfont(z, 800).getlength("Say ") + kfont(z, 800).getlength(h) > 960: z -= 4
    w1 = kfont(z, 800).getlength("Say "); w2 = kfont(z, 800).getlength(h); x0 = 540 - (w1 + w2) / 2
    br = 1.0 + 0.015 * math.sin(t * 2.4)
    c.save(); c.translate(540, 200); c.scale(s * br, s * br); c.translate(-540, -200)
    T(c, "Say", z, x0 + w1 / 2 - 12, 138, WHITE, a, 1.0, 800, maxw=500)
    T(c, h, z, x0 + w1 + w2 / 2, 138, YELLOW, a, 1.0, 800, maxw=900)
    T(c, "in English?", 96, 540, 272, WHITE, a, 1.0, 800, maxw=900)
    c.restore()


def he_line(c, he, a):
    T(c, f"בעברית: {_he_hook(he)}", 52, 540, 1555, YELLOW, a, 1.0, 700, maxw=900)


def _cards(n):
    if n == 3: return [(945 + k * 162, 122) for k in range(3)]
    return [(965 + k * 175, 145) for k in range(n)]


def card(c, tag, txt, top, h, a, s, ghost=0.0):
    """an option card: white rounded card, tag pill on its top edge, the line in ink with the new words red"""
    cx, cy = 540, top + h / 2
    if ghost > 0.01 and a < 0.99:   # empty slot before the option is said
        g = ghost * (1 - a); old = St.a; St.a *= g
        sa(c, WHITE, 0.10 * St.a); rr(c, PX0, top, PX1 - PX0, h, 30); c.fill()
        sa(c, WHITE, 0.30 * St.a); c.set_line_width(3); rr(c, PX0, top, PX1 - PX0, h, 30); c.stroke()
        St.a = old
        T(c, "?", 76, cx, cy + 8, GREYW, g, 1.0, 900, maxw=200)
        pill(c, tag, 38, 220, top, TAGCOL.get(tag, SKY), WHITE, g, 1.0, w=800)
    if a <= 0.01: return
    c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
    old = St.a; St.a *= a
    sa(c, INK, 0.18 * St.a); rr(c, PX0 + 3, top + 10, PX1 - PX0, h, 30); c.fill()
    sa(c, WHITE, St.a); rr(c, PX0, top, PX1 - PX0, h, 30); c.fill()
    St.a = old
    block(c, txt, 70, cx, cy + 10, INK, a, 1.0, 800, hl=NEWRED, maxw=860, max_lines=1)
    c.restore()
    pill(c, tag, 38, 220, top, TAGCOL.get(tag, SKY), WHITE, a, s, w=800)


def sc_slang2(c, t, S):
    t0 = S["t0"]; tm = S["times"]; opts = S["opts"]; n = len(opts)
    to = [tm.get(f"o{k}", t0 + 2.0 + 2.0 * k) for k in range(n)]
    te = [tm.get(f"e{k}", to[k] + 0.6) + 0.5 for k in range(n)]
    tend = S["t1"] if S.get("t1") else to[-1] + 3.0
    # top: the hook (frame 0), then the series chip once the first answer lands
    ha = 1.0 - ramp(t, to[0] - 0.35, to[0] - 0.05)
    hook(c, t, S["he"], ha)
    pill(c, CHIP, 42, 540, 200, SKY, WHITE, ramp(t, to[0] - 0.05, to[0] + 0.25), 1.0, w=800)
    # the scene
    _panel(c, PX0, PY0, PX1, PY1)
    if t < to[0] - 0.1: me, them = "listen", "talk"
    else: me, them = "talk", "happy"
    mytail, theirtail = _scene(c, S.get("setting", "office"), PX0, PY0, PX1, PY1, t, me, them, 255, PY1 - 36)
    k_now = max([k for k in range(n) if t >= to[k] - 0.1], default=-1)
    if k_now < 0: txt, who, k0 = S["bubble"], "them", t0
    else: txt, who, k0 = opts[k_now][1], "me", to[k_now]
    ba, bs = PP(t, k0 - 0.1, S, bounce=2.2)
    hn = block_h(txt, 66, 800, 820, 2); by0 = PY0 + 24; by1 = by0 + hn + 50
    tail = mytail if who == "me" else theirtail
    _bubble(c, PX0 + 30, by0, PX1 - 30, by1, (tail[0] + (10 if who == "me" else -10), by1 + 46), BLUE if who == "me" else ORANGE, ba)
    old = St.a; St.a *= ba
    block(c, txt, 66, 540, (by0 + by1) / 2, INK, 1.0, bs, 800, hl=NEWRED, maxw=820, max_lines=2)
    St.a = old
    # the option cards (empty slots at frame 0, filled as each option is said)
    for k, ((tag, line), (top, h)) in enumerate(zip(opts, _cards(n))):
        a, s = PP(t, to[k] - 0.1, S, bounce=2.2)
        card(c, tag, line, top, h, a, s, ghost=1.0)
    # your turn: in the pause after each option
    yt = 0.0
    for k in range(n):
        nxt = to[k + 1] - 0.15 if k + 1 < n else tend - 0.1
        if te[k] < nxt - 0.4: yt = max(yt, ramp(t, te[k], te[k] + 0.2) * (1 - ramp(t, nxt - 0.25, nxt)))
    if yt > 0.01:
        pill(c, "Your turn: say it out loud", 40, 540, 1432, YELLOW, INK, yt, 1.0 + 0.03 * math.sin(t * 6), w=800)
    # source + the Hebrew bottom line
    T(c, S["src"], 36, 540, 1492, GREYW, ramp(t, to[0], to[0] + 0.3), 1.0, 700, maxw=940)
    he_line(c, S["he"], ramp(t, to[0], to[0] + 0.3))


def _avatar(c, x, y, col, label, a):
    old = St.a; St.a *= a
    sa(c, col, St.a); c.arc(x, y, 44, 0, 2 * math.pi); c.fill()
    St.a = old
    T(c, label, 36 if len(label) > 1 else 46, x, y + 3, WHITE, a, 1.0, 800, maxw=80)


def sc_slang2_chat(c, t, S):
    t0 = S["t0"]; tm = S["times"]; chat = S["chat"]
    pill(c, "MINI CHAT", 42, 540, 200, SKY, WHITE, fade_in(t, t0, S, 0.2), 1.0, w=800)
    x0, y0, x1, y1 = 70, 290, 1010, 1470
    sa(c, INK, 0.10 * St.a); rr(c, x0 + 3, y0 + 12, x1 - x0, y1 - y0, 40); c.fill()
    sa(c, (0.96, 0.97, 0.99, 1.0), St.a); rr(c, x0, y0, x1 - x0, y1 - y0, 40); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 40); c.clip()
    sa(c, (0.86, 0.90, 0.96, 1.0), St.a); c.rectangle(x0, y0, x1 - x0, 96); c.fill()
    c.restore()
    T(c, f"{S['who']} and you", 40, 540, y0 + 50, INK, 1.0, 1.0, 800, maxw=700)
    maxw = 660; lay = []
    for who, txt in chat:
        z, ls = RD.wrap(txt, 70, 800, maxw, 2); lay.append((kfont(z, 800), z, ls))
    hs = [z * 1.14 * len(ls) + 56 for _, z, ls in lay]; gap = 90
    y = y0 + 96 + max(50, ((y1 - y0 - 96) - sum(hs) - gap * (len(hs) - 1)) / 2)
    for k, (who, txt) in enumerate(chat):
        tk = tm.get(f"c{k}", t0 + 0.3 + 1.6 * k)
        a, s = PP(t, tk - 0.08, S, bounce=2.2)
        me = who == "me"; f, z, ls = lay[k]
        bw = max(f.getlength(l.replace("*", "")) for l in ls) + 80
        bh = hs[k]
        ax = x1 - 80 if me else x0 + 80; bx0 = (ax - 66 - bw) if me else (ax + 66); bx1 = bx0 + bw
        if a > 0.01:
            cx, cy = (bx0 + bx1) / 2, y + bh / 2
            c.save(); c.translate(ax, cy); c.scale(s, s); c.translate(-ax, -cy)
            _avatar(c, ax, y + bh - 44, BLUE if me else ORANGE, "You" if me else S["who"][0], a)
            old = St.a; St.a *= a
            sa(c, INK, 0.10 * St.a); rr(c, bx0 + 2, y + 8, bw, bh, 34); c.fill()
            sa(c, (0.90, 0.95, 1.0, 1.0) if me else WHITE, St.a); rr(c, bx0, y, bw, bh, 34); c.fill()
            sa(c, BLUE if me else ORANGE, St.a); c.set_line_width(6); rr(c, bx0, y, bw, bh, 34); c.stroke()
            St.a = old
            block(c, txt, 70, cx, cy + 4, INK, a, 1.0, 800, hl=NEWRED, maxw=maxw + 10, max_lines=2)
            c.restore()
        y += bh + gap
    he_line(c, S["he"], fade_in(t, t0, S, 0.3))


def _bookmark(c, x, y, s, a):
    old = St.a; St.a *= a
    w, h = 64 * s, 86 * s
    c.move_to(x - w / 2, y - h / 2); c.line_to(x + w / 2, y - h / 2); c.line_to(x + w / 2, y + h / 2)
    c.line_to(x, y + h / 2 - 24 * s); c.line_to(x - w / 2, y + h / 2); c.close_path()
    sa(c, YELLOW, St.a); c.fill()
    St.a = old


def sc_slang2_save(c, t, S):
    t0 = S["t0"]; ts = S["times"].get("s", t0 + 0.2); opts = S["opts"]; n = len(opts)
    hook(c, t, S["he"], fade_in(t, t0, S, 0.25))
    rh = 190 if n == 3 else 220; top = 400; bot = top + 40 + rh * n
    pa = fade_in(t, t0, S, 0.25)
    old = St.a; St.a *= pa
    sa(c, INK, 0.18 * St.a); rr(c, PX0 + 3, top + 12, PX1 - PX0, bot - top, 40); c.fill()
    sa(c, WHITE, St.a); rr(c, PX0, top, PX1 - PX0, bot - top, 40); c.fill()
    St.a = old
    for k, (tag, line) in enumerate(opts):
        y = top + 40 + rh * k
        a, s = PP(t, t0 + 0.1 + 0.15 * k, S, bounce=2.2)
        pill(c, tag, 38, 540, y + 34, TAGCOL.get(tag, SKY), WHITE, a, s, w=800)
        block(c, line, 70, 540, y + 34 + 82, INK, a, s, 800, hl=NEWRED, maxw=880, max_lines=1)
        if k < n - 1:
            sa(c, INK, 0.12 * St.a * a); c.rectangle(PX0 + 60, y + rh - 8, PX1 - PX0 - 120, 3); c.fill()
    a, s = PP(t, ts - 0.1, S, bounce=2.2)
    yb = bot + 110
    _bookmark(c, 540, yb + 6 * math.sin(t * 4), 1.0, a)
    block(c, "Save this for your *next meeting*", 74, 540, yb + 150, WHITE, a, s, 900, hl=YELLOW, maxw=960, max_lines=2)
