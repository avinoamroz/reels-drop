"""rehook4 (29 Oct 2026): new hooks for 8 weak trials. Reuses the v2new engine (/home/claude/v2new/build.py:
opener + parent body segments + optional question outro, audio prebuilt by audio4.py) and adds:
- 8 new openers (light house theme, or the parent's own frames for potential), text on screen at frame 0, motion by 1.5 s
- body "freeze": cfg["freeze"] = {segment start: s} shows the parent frame at a+s for the first s seconds of that segment
  (skips the parent's crossfade out of its old title; audio is untouched, so the voice keeps its first word)
- outro: Hebrew under the follow chip, optional fluency tip phase before the question (Express).
usage: build4.py cfg.json [--frames t1,t2,..]"""
import sys, math, json
sys.path.insert(0, "/home/claude/v2new")
import build as B
from build import F, hx, clamp, eout, eio, back, emoji, paste_c, text_c, chip, rowfill, vgrad, draw_sub, W, H, FPS
from PIL import Image, ImageDraw, ImageFilter

NAVY, BLUE, GOLD, GOLD2, GOLDT, GREY, RED, GREEN = hx("163260"), hx("2A88D4"), hx("B8923F"), hx("E6C77E"), hx("96702A"), hx("5B6B82"), hx("D63A4A"), hx("1E9E62")
WHITE = (255, 255, 255)

# ------------------------------------------------------------ light house background with drifting particles
_LBG = {}
def light_bg(t):
    if "bg" not in _LBG:
        _LBG["bg"] = vgrad(hx("F4F5F7"), hx("D9DDE3"))
        import random; r = random.Random(7)
        _LBG["p"] = [(r.uniform(0, W), r.uniform(0, H), r.uniform(2, 5), r.uniform(10, 30), r.uniform(0, 6.28)) for _ in range(46)]
    im = _LBG["bg"].copy(); d = ImageDraw.Draw(im, "RGBA")
    for x, y, rr, sp, ph in _LBG["p"]:
        yy = (y - sp * t) % H; xx = x + 8 * math.sin(t * 0.9 + ph)
        d.ellipse([xx - rr, yy - rr, xx + rr, yy + rr], fill=GOLD + (70,))
    return im

def series(im, en, he, y=120):
    chip(im, en, W / 2, y, 30, fill=NAVY + (255,), outline=GOLD, color=GOLD2)
    text_c(im, he, 30, W / 2, y + 52, w=700, color=NAVY)

def title(im, t, lines, y0, size=92, gap=None, hl=BLUE, he=None, he_size=48, he_gap=None):
    """navy English lines (punch-in 1.08 -> 1 over 0.25 s), Hebrew line under them in blue"""
    sc = 1.08 - 0.08 * eout(t / 0.25); gap = gap or int(size * 1.12); y = y0
    for s in lines:
        sz = s[1] if isinstance(s, tuple) else size; s = s[0] if isinstance(s, tuple) else s
        text_c(im, s, sz, W / 2, y, color=NAVY, hl=hl, sc=sc); y += int(sz * 1.14)
    if he:
        for h in (he if isinstance(he, list) else [he]):
            y += 6; text_c(im, h, he_size, W / 2, y, w=700, color=BLUE); y += int(he_size * 1.3)
    return y

def source(im, s, y=1548):
    d = ImageDraw.Draw(im); d.text((W / 2, y), s, font=F(400, 26), fill=GREY, anchor="mm")

def pop(t, t0, d=0.25): return back((t - t0) / d) if t >= t0 else 0.0

def panel(im, box, fill=WHITE + (235,), outline=NAVY, r=34, wd=4):
    ImageDraw.Draw(im, "RGBA").rounded_rectangle(box, radius=r, fill=fill, outline=outline + (255,), width=wd)

# ============================================================ openers
def op_table(t, bg, O):            # shabbat_p3: one table, 1.8 km
    T = O["times"]; im = light_bg(t)
    series(im, "SHABBAT WORLD RECORD", "שיא עולם בשבת")
    title(im, t, ["One *Shabbat* table.", "*1.8 km* long."], 300, 96, he="שולחן שבת אחד. באורך 1.8 ק״מ.")
    x0, y0, x1, y1 = 70, 600, 1010, 1180
    pn = Image.new("RGBA", (x1 - x0, y1 - y0)); pd = ImageDraw.Draw(pn)
    h = y1 - y0
    for k in range(h):                           # dusk sky -> sea -> sand
        f = k / h
        c = (tuple(int(a + (b - a) * (f / 0.42)) for a, b in zip(hx("3B2A5A"), hx("F2A65A"))) if f < 0.42 else
             hx("2F6FA8") if f < 0.56 else tuple(int(a + (b - a) * ((f - 0.56) / 0.44)) for a, b in zip(hx("F0C987"), hx("E3B26C"))))
        pd.line([(0, k), (x1 - x0, k)], fill=c + (255,))
    for i in range(14):                          # skyline
        bx = 520 + i * 30; bh = 40 + (i * 37) % 110; pd.rectangle([bx, int(0.42 * h) - bh, bx + 22, int(0.42 * h)], fill=(40, 30, 60, 255))
    sun = int(0.42 * h); pd.ellipse([150, sun - 60, 270, sun + 60], fill=(255, 214, 120, 255)); pd.rectangle([140, sun, 280, sun + 62], fill=hx("2F6FA8") + (255,))
    mk = Image.new("L", pn.size, 0); ImageDraw.Draw(mk).rounded_rectangle([0, 0, pn.width - 1, pn.height - 1], radius=34, fill=255); pn.putalpha(mk)
    im.alpha_composite(pn, (x0, y0)); ImageDraw.Draw(im).rounded_rectangle([x0, y0, x1, y1], radius=34, outline=NAVY, width=4)
    u = eio((t - 0.15) / 1.35); d = ImageDraw.Draw(im, "RGBA")
    ty = 1080; ta, tb = 110, 110 + 860 * u
    if u > 0:
        d.rounded_rectangle([ta, ty - 9, tb, ty + 9], radius=9, fill=(255, 255, 255, 255))
        cols = [hx(c) for c in ("163260", "2A88D4", "D63A4A", "1E9E62", "B8923F", "7A4FB0")]
        for i, x in enumerate(range(ta + 8, int(tb), 17)):
            d.ellipse([x - 6, ty - 26, x + 6, ty - 14], fill=cols[i % 6] + (255,)); d.ellipse([x - 6, ty + 14, x + 6, ty + 26], fill=cols[(i + 3) % 6] + (255,))
        if u > 0.05: paste_c(im, emoji("🕯️", 46), tb, ty - 52, 1.0)
    km = 1.8 * u; sc = 1 + 0.12 * math.exp(-((t - 1.52) / 0.09) ** 2)
    text_c(im, f"*{km:.1f} km*", 128, W / 2, 1300, w=900, color=NAVY, hl=GOLDT, sc=sc)
    text_c(im, "3,000 guests × 60 cm, all on one side", 40, W / 2, 1404, w=700, color=NAVY)
    text_c(im, "3,000 אורחים × 60 ס״מ, כולם בצד אחד", 36, W / 2, 1456, w=700, color=BLUE)
    source(im, "Math: about 60 cm per guest (catering seating guideline)")
    draw_sub(im, O["_subs"], t); return im

def op_strangers(t, bg, O):        # shabbat_p2: 3,000 strangers
    T = O["times"]; im = light_bg(t)
    series(im, "SHABBAT WORLD RECORD", "שיא עולם בשבת")
    title(im, t, ["*3,000* strangers.", ("One table. One Friday night.", 70)], 300, 104, he="3,000 זרים. שולחן אחד. ליל שישי אחד.")
    x0, y0, x1, y1 = 80, 600, 1000, 1220
    panel(im, (x0, y0, x1, y1), fill=hx("1C2342") + (255,), outline=NAVY)
    d = ImageDraw.Draw(im, "RGBA"); nc, nr = 60, 50; sx = (x1 - x0 - 60) / (nc - 1); sy = (y1 - y0 - 200) / (nr - 1)
    k = int(3000 * eout((t - 0.08) / 1.3))
    for i in range(3000):
        cx = x0 + 30 + (i % nc) * sx; cy = y0 + 170 + (i // nc) * sy
        d.ellipse([cx - 3.6, cy - 3.6, cx + 3.6, cy + 3.6], fill=(GOLD2 + (255,)) if i < k else (70, 78, 110, 255))
    for j, cx in enumerate((W / 2 - 70, W / 2 + 70)):
        s = pop(t, T["fri"] + 0.08 * j)
        if s > 0:
            g = Image.new("RGBA", (220, 220)); ImageDraw.Draw(g).ellipse([50, 50, 170, 170], fill=(255, 200, 90, 120)); paste_c(im, g.filter(ImageFilter.GaussianBlur(26)), cx, y0 + 85, s)
            paste_c(im, emoji("🕯️", 92), cx, y0 + 85, s)
    text_c(im, f"*{k:,}* guests", 64, W / 2, 1300, w=900, color=NAVY, hl=GOLDT)
    text_c(im, "The plan: April 2027, Tel Aviv beach", 40, W / 2, 1390, w=700, color=NAVY)
    text_c(im, "התוכנית: אפריל 2027, חוף תל אביב", 36, W / 2, 1442, w=700, color=BLUE)
    draw_sub(im, O["_subs"], t); return im

def op_record(t, bg, O):           # guinness_il: Tel Aviv held a world record, Berlin took it
    T = O["times"]; im = light_bg(t)
    series(im, "SHABBAT WORLD RECORD", "שיא העולם לארוחת שבת")
    title(im, t, ["Tel Aviv held a *world record.*", "Then *Berlin* took it."], 300, 80, he="לתל אביב היה שיא עולם. ואז ברלין לקחה אותו.")
    x0, y0, x1, y1 = 90, 590, 990, 1330
    panel(im, (x0, y0, x1, y1))
    d = ImageDraw.Draw(im, "RGBA")
    d.line([(x0 + 120, y0 + 52), (x1 - 120, y0 + 52)], fill=GOLD + (255,), width=3)
    text_c(im, "WORLD RECORD", 36, W / 2, y0 + 52, w=900, color=GOLDT)
    text_c(im, "Largest Shabbat dinner", 54, W / 2, y0 + 124, w=800, color=NAVY)
    text_c(im, "ארוחת השבת הגדולה בעולם", 40, W / 2, y0 + 184, w=700, color=BLUE)
    tb = T["berlin"]; lost = t >= tb
    # Tel Aviv row (holds the trophy until Berlin lands)
    ry = y0 + 470 + (110 * eout((t - tb) / 0.35) if lost else 0)
    n = int(2226 * eout((t - 0.1) / 1.0))
    a_row = 1.0 - 0.55 * eout((t - tb) / 0.35) if lost else 1.0
    row = Image.new("RGBA", (800, 150)); rd = ImageDraw.Draw(row)
    rd.rounded_rectangle([0, 0, 799, 149], radius=26, fill=(240, 244, 250, 255), outline=(BLUE if not lost else GREY) + (255,), width=4)
    rd.text((40, 52), "Tel Aviv, 2014", font=F(800, 46), fill=NAVY, anchor="lm"); rd.text((40, 108), "תל אביב, 2014", font=F(700, 34), fill=BLUE, anchor="lm", direction="rtl")
    rd.text((770, 75), f"{n:,}", font=F(900, 78), fill=NAVY, anchor="rm")
    paste_c(im, row, W / 2, ry, 1.0, a_row)
    if not lost: paste_c(im, emoji("🏆", 84), x1 - 70, ry - 96, pop(t, 0.9, 0.3))
    if lost:
        s = pop(t, tb + 0.05, 0.3); by = y0 + 330
        brow = Image.new("RGBA", (800, 150)); bd = ImageDraw.Draw(brow)
        bd.rounded_rectangle([0, 0, 799, 149], radius=26, fill=(255, 248, 232, 255), outline=GOLD + (255,), width=5)
        bd.text((40, 52), "Berlin", font=F(900, 50), fill=NAVY, anchor="lm"); bd.text((40, 108), "ברלין", font=F(700, 34), fill=GOLDT, anchor="lm", direction="rtl")
        bd.text((770, 75), "beat it", font=F(900, 60), fill=GOLDT, anchor="rm")
        paste_c(im, brow, W / 2, by, s); paste_c(im, emoji("🏆", 84), x1 - 70, by - 96, s)
        st = pop(t, tb + 0.35, 0.22)
        if st > 0:
            chip(im, "RECORD LOST", W / 2, ry + 108, 34, fill=RED + (255,), outline=RED, color=WHITE, sc=st)
            text_c(im, "השיא אבד", 32, W / 2, ry + 166, w=700, color=RED, a=clamp((t - tb - 0.35) / 0.2))
    source(im, "Source: Guinness World Records, largest Shabbat dinner (Tel Aviv 2014: 2,226 people)")
    draw_sub(im, O["_subs"], t); return im

def op_dogs(t, bg, O):             # maps_p2: one city had 5 registered dogs
    T = O["times"]; im = light_bg(t)
    series(im, "MAPS OF ISRAEL", "המפות של ישראל")
    title(im, t, ["One Israeli city had", "just *5* registered dogs."], 300, 90, he="בעיר אחת בישראל היו רק 5 כלבים רשומים.")
    x0, y0, x1, y1 = 90, 600, 990, 1240
    panel(im, (x0, y0, x1, y1))
    # pin with a question mark
    s = pop(t, 0.05, 0.3); pin = Image.new("RGBA", (200, 260)); pd = ImageDraw.Draw(pin)
    pd.ellipse([10, 10, 190, 190], fill=NAVY + (255,)); pd.polygon([(40, 150), (160, 150), (100, 250)], fill=NAVY + (255,))
    pd.text((100, 100), "?", font=F(900, 120), fill=GOLD2, anchor="mm"); paste_c(im, pin, W / 2, y0 + 190, s * (1 + 0.04 * math.sin(t * 5)))
    text_c(im, "City: ???", 44, W / 2, y0 + 360, w=700, color=NAVY)
    for i in range(5):
        ti = 0.25 + i * 0.17; paste_c(im, emoji("🐕", 92), W / 2 + (i - 2) * 150, y0 + 500, pop(t, ti, 0.22))
    k = sum(1 for i in range(5) if t >= 0.25 + i * 0.17)
    text_c(im, f"*{k}* dogs", 96, W / 2, 1340, w=900, color=NAVY, hl=GOLDT, sc=1 + 0.1 * math.exp(-((t - 0.95) / 0.08) ** 2))
    tv = pop(t, 1.35, 0.3)
    if tv > 0:
        chip(im, "Tel Aviv: 43,000 dogs", W / 2, 1440, 40, fill=BLUE + (255,), outline=BLUE, color=WHITE, sc=tv)
        text_c(im, "תל אביב: 43,000 כלבים", 34, W / 2, 1500, w=700, color=BLUE, a=clamp((t - 1.4) / 0.3))
    if t >= T["guess"]:
        chip(im, "Guess which.", W / 2, y0 + 345, 42, fill=GOLD + (255,), outline=GOLD, color=WHITE, sc=pop(t, T["guess"], 0.22))
        text_c(im, "נחשו איזו.", 34, W / 2, y0 + 410, w=700, color=GOLDT, a=clamp((t - T["guess"]) / 0.2))
    source(im, "Sources: INN 2019; Ministry of Agriculture dog registry 2022 (via ICE)", 1570)
    draw_sub(im, O["_subs"], t); return im

def op_un(t, bg, O):               # un_item7: 193 countries, only one gets its own item
    T = O["times"]; im = light_bg(t)
    series(im, "UN BY THE NUMBERS", "האו״ם במספרים")
    title(im, t, ["*193* countries.", ("Only *one* gets its own", 72), ("permanent UN agenda item.", 72)], 290, 104,
          he="193 מדינות. רק לאחת יש סעיף קבוע משלה באו״ם.")
    x0, y0, x1, y1 = 110, 640, 970, 1330
    panel(im, (x0, y0, x1, y1))
    d = ImageDraw.Draw(im, "RGBA"); nc = 14; sp = (x1 - x0 - 120) / (nc - 1)
    k = int(193 * eout((t - 0.08) / 1.1)); tone = T["only"]; dim = eout((t - tone) / 0.35) if t >= tone else 0.0
    ONE = 96
    for i in range(193):
        cx = x0 + 60 + (i % nc) * sp; cy = y0 + 60 + (i // nc) * sp * 0.82
        if i >= k: d.ellipse([cx - 13, cy - 13, cx + 13, cy + 13], outline=(170, 180, 196, 255), width=2); continue
        if i == ONE and dim > 0:
            g = 1 + 0.35 * abs(math.sin((t - tone) * 6)); r = 18 * g
            d.ellipse([cx - r - 10, cy - r - 10, cx + r + 10, cy + r + 10], fill=GOLD2 + (110,)); d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=GOLD + (255,))
        else:
            c0 = BLUE; c = tuple(int(a + (b - a) * dim) for a, b in zip(c0, (200, 206, 216))); d.ellipse([cx - 13, cy - 13, cx + 13, cy + 13], fill=c + (255,))
    text_c(im, f"*{k}* UN member states", 52, W / 2, 1400, w=900, color=NAVY, hl=BLUE)
    if dim > 0:
        chip(im, "1 country, 1 permanent item: Item 7", W / 2, 1462, 34, fill=GOLD + (255,), outline=GOLD, color=WHITE, sc=pop(t, tone + 0.15, 0.25))
        text_c(im, "מדינה אחת, סעיף קבוע אחד: סעיף 7", 30, W / 2, 1512, w=700, color=GOLDT, a=clamp((t - tone - 0.15) / 0.25))
    source(im, "Sources: UN, 193 member states; UN Human Rights Council, Resolution 5/1 (2007), agenda", 1566)
    draw_sub(im, O["_subs"], t); return im

def op_holly(t, bg, O):            # lib_hollywood_jews: without these immigrants, no Hollywood
    im = light_bg(t)
    paste_c(im, emoji("🎬", 96), W / 2, 200, 1 + 0.05 * math.sin(t * 4))
    title(im, t, ["Without these *immigrants*,", "*no Hollywood.*"], 340, 92, he="בלי המהגרים האלה, לא היה הוליווד.")
    names = [("Paramount", "פרמאונט"), ("Universal", "יוניברסל"), ("Fox", "פוקס"), ("MGM", "MGM"), ("Warner Bros.", "האחים וורנר"), ("Columbia", "קולומביה")]
    for i, (en, he) in enumerate(names):
        cx = 300 if i % 2 == 0 else 780; cy = 680 + (i // 2) * 190; s = pop(t, 0.15 + i * 0.17, 0.25)
        if s <= 0: continue
        card = Image.new("RGBA", (440, 160)); cd = ImageDraw.Draw(card)
        cd.rounded_rectangle([0, 0, 439, 159], radius=28, fill=WHITE + (245,), outline=(GOLD if i % 2 else BLUE) + (255,), width=4)
        cd.text((220, 62), en, font=F(900, 54), fill=NAVY, anchor="mm"); cd.text((220, 118), he, font=F(700, 34), fill=BLUE, anchor="mm", direction="rtl")
        paste_c(im, card, cx, cy, s)
    u = eio((t - 0.2) / 2.6); paste_c(im, emoji("🚢", 110), -80 + (W + 160) * u, 1300, 1.0)
    d = ImageDraw.Draw(im, "RGBA"); d.line([(60, 1350), (W - 60, 1350)], fill=BLUE + (120,), width=4)
    text_c(im, "Founded by Jewish immigrants and their sons", 40, W / 2, 1420, w=700, color=NAVY, a=clamp((t - 1.1) / 0.3))
    text_c(im, "הוקמו בידי מהגרים יהודים ובניהם", 36, W / 2, 1472, w=700, color=BLUE, a=clamp((t - 1.1) / 0.3))
    source(im, "Source: Neal Gabler, An Empire of Their Own (1988)")
    draw_sub(im, O["_subs"], t); return im

def op_board(t, bg, O):            # lib_board_story: one hour, a room of business owners, your problem in the hot seat
    T = O["times"]; im = light_bg(t)
    series(im, "FOUNDER STORY | THE BOARD", "סיפור מייסד | The Board")
    title(im, t, ["*1 hour.* A room full", "of business owners.", ("Your biggest problem in the *hot seat.*", 54)], 290, 84,
          he="שעה אחת. חדר מלא בבעלי עסקים. והבעיה הכי גדולה שלכם במרכז.", he_size=40)
    cx, cy, rx, ry = W / 2, 1050, 300, 170
    d = ImageDraw.Draw(im, "RGBA")
    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=hx("8A5A34") + (255,), outline=NAVY + (255,), width=5)
    d.ellipse([cx - rx + 30, cy - ry + 24, cx + rx - 30, cy + ry - 24], outline=(255, 255, 255, 60), width=3)
    hot = t >= T["hot"]; n = 10
    for i in range(n):
        a = math.pi / 2 + 2 * math.pi * i / n; sx, sy = cx + (rx + 70) * math.cos(a), cy + (ry + 60) * math.sin(a)
        s = pop(t, 0.12 + i * 0.09, 0.22)
        if s <= 0: continue
        you = i == 0; r = 34 * s
        if you and hot:
            g = Image.new("RGBA", (300, 300)); ImageDraw.Draw(g).ellipse([60, 60, 240, 240], fill=(255, 196, 70, 170)); paste_c(im, g.filter(ImageFilter.GaussianBlur(30)), sx, sy, 1 + 0.15 * math.sin((t - T["hot"]) * 8))
        col = (RED if hot else GOLD) if you else (BLUE if i % 2 else NAVY)
        d = ImageDraw.Draw(im, "RGBA"); d.ellipse([sx - r, sy - r, sx + r, sy + r], fill=col + (255,), outline=WHITE + (255,), width=4)
    if hot:
        chip(im, "YOU", cx, cy + ry + 150, 34, fill=RED + (255,), outline=RED, color=WHITE, sc=pop(t, T["hot"], 0.22))
        text_c(im, "אתם", 32, cx, cy + ry + 206, w=700, color=RED, a=clamp((t - T["hot"]) / 0.2))
    # one-hour ring sweeping on the table
    u = clamp(t / max(0.5, O["take"] - 0.2)); d = ImageDraw.Draw(im, "RGBA")
    d.ellipse([cx - 80, cy - 80, cx + 80, cy + 80], fill=WHITE + (240,), outline=(200, 206, 216, 255), width=10)
    d.arc([cx - 80, cy - 80, cx + 80, cy + 80], -90, -90 + 360 * u, fill=GOLD + (255,), width=12)
    d.text((cx, cy - 8), "1h", font=F(900, 64), fill=NAVY, anchor="mm"); d.text((cx, cy + 40), "שעה", font=F(700, 28), fill=BLUE, anchor="mm", direction="rtl")
    draw_sub(im, O["_subs"], t); return im

def op_pot(t, bg, O):              # potential (Express): 100 English moments a day, you speak in 0
    T = O["times"]; im = rowfill(bg, 40, 706); sc = 1.08 - 0.08 * eout(t / 0.25)
    text_c(im, "*100* English moments a day.", 80, W / 2, 160, sc=sc)
    text_c(im, "You speak in *0.*", 92, W / 2, 268, sc=sc)
    text_c(im, "100 רגעים באנגלית ביום. ואתם מדברים באפס מהם.", 44, W / 2, 352, w=700, color=(214, 224, 240))
    d = ImageDraw.Draw(im); x0, x1 = 430, 990
    for k, (lab, he, y) in enumerate([("Heard", "שומעים", 452), ("Spoken", "מדברים", 548)]):
        paste_c(im, emoji("🎧" if k == 0 else "🗣️", 54), 120, y)
        d.text((170, y - 12), lab, font=F(800, 42), fill=WHITE, anchor="lm"); d.text((170, y + 26), he, font=F(700, 30), fill=(170, 186, 214), anchor="lm", direction="rtl")
        d.rounded_rectangle([x0, y - 22, x1, y + 22], radius=22, fill=(16, 28, 62), outline=(70, 92, 140), width=2)
        if k == 0:
            u = eout((t - 0.1) / 1.0); xe = x0 + 44 + (x1 - x0 - 44) * u
            d.rounded_rectangle([x0, y - 22, xe, y + 22], radius=22, fill=hx("F4A340"))
            d.text((x1 - 16, y), f"{int(round(100 * u))}", font=F(900, 34), fill=NAVY if u > 0.8 else WHITE, anchor="rm")
        else:
            tf = T["you"]; fl = t > tf; sh = 7 * math.sin(t * 60) * math.exp(-(t - tf) * 6) if fl else 0
            d.rounded_rectangle([x0 + sh, y - 22, x0 + 40 + sh, y + 22], radius=22, fill=RED if fl else (90, 104, 140))
            d.text((x1 - 16 + sh, y), "0", font=F(900, 34), fill=RED if fl else WHITE, anchor="rm")
    draw_sub(im, O["_subs"], t); return im

B.REPL += [(r"\bOne point eight kilometers\b", "1.8 kilometers"), (r"\bThree thousand\b", "3,000"), (r"\bA hundred and ninety-three\b", "193"),
           (r"\bfive registered\b", "5 registered"), (r"^A hundred English\b", "100 English"), (r"\bseven minutes\b", "7 minutes")]
B.OPENERS.update(table=op_table, strangers=op_strangers, record=op_record, dogs=op_dogs, un=op_un, holly=op_holly, board=op_board, pot=op_pot)

# ============================================================ outro: question card (+ optional fluency tip), Hebrew under every line
def outro(t, last, O):
    if "_blur" not in O: O["_blur"] = last.filter(ImageFilter.GaussianBlur(10))
    u = eout(t / 0.35); base = Image.blend(last, O["_blur"], u); im = Image.blend(base, Image.new("RGBA", (W, H), (6, 12, 30, 255)), 0.86 * u)
    card = Image.new("RGBA", (W, H)); cy = 800; tip = O.get("tip"); tq = tip["until"] if tip else 0.0
    if tip and t < tq + 0.3:
        a = 1 - clamp((t - tq) / 0.3); y = 560
        text_c(card, tip["en"][0], 92, W / 2, y, sc=back(t / 0.4), a=a); y += 86
        text_c(card, tip["he"][0], 48, W / 2, y, w=700, color=(214, 224, 240), a=a); y += 110
        for k, (en, he) in enumerate(zip(tip["en"][1:], tip["he"][1:])):
            ak = a * clamp((t - tip["at"][k]) / 0.25)
            text_c(card, en, 58, W / 2, y, w=800, a=ak, sc=back((t - tip["at"][k]) / 0.35) if t > tip["at"][k] else 0.01); y += 72
            text_c(card, he, 42, W / 2, y, w=700, color=GOLD2, a=ak); y += 104
    if t >= tq:
        s = t - tq
        text_c(card, O["en1"], 88, W / 2, cy - 60, sc=back(s / 0.4))
        if O.get("en2"): text_c(card, O["en2"], 88, W / 2, cy + 50, sc=back((s - 0.05) / 0.4))
        yh = cy + (150 if O.get("en2") else 50)
        text_c(card, O["he"], 50, W / 2, yh, w=700, color=(214, 224, 240), a=clamp((s - 0.15) / 0.3))
        text_c(card, "Tell me in the comments", 46, W / 2, yh + 100, w=800, color=GOLD2, a=clamp((s - 0.3) / 0.3))
        text_c(card, "ספרו לי בתגובות", 40, W / 2, yh + 164, w=700, color=(190, 200, 220), a=clamp((s - 0.3) / 0.3))
        chip(card, O["follow"], W / 2, yh + 280, 38, fill=(42, 136, 212, 255), outline=hx("2A88D4"), color=WHITE, a=clamp((s - 0.45) / 0.3))
        text_c(card, "עקבו לעוד", 36, W / 2, yh + 350, w=700, color=(190, 200, 220), a=clamp((s - 0.5) / 0.3))
    im.alpha_composite(card); draw_sub(im, O["_subs"], t); return im
B.outro = outro

# ============================================================ body freeze (skip the parent's old-title crossfade)
_frames_of = B.frames_of
FREEZE = {}
def frames_of(src, a, n):
    fz = FREEZE.get(round(a, 3), 0.0)
    if not fz:
        yield from _frames_of(src, a, n); return
    k = int(round(fz * FPS)); it = _frames_of(src, a + k / FPS, n - k); first = next(it)
    for _ in range(k + 1): yield first
    yield from it
RECHIP = {}
def rechip(fr):
    """cover the parent's 'SERIES | PART N' chip (y 225..372) with a clean series chip, only when that chip is on the frame"""
    if not RECHIP: return fr
    px = fr.convert("RGB").crop((300, 255, 780, 282)); m = sum(px.convert("L").getdata()) / (480 * 27)
    if m > 170: return fr
    im = fr.convert("RGBA").copy(); bg = light_bg(0.0).crop((0, 222, W, 376)); im.paste(bg, (0, 222))
    chip(im, RECHIP["en"], W / 2, 268, 40, fill=NAVY + (255,), outline=GOLD, color=WHITE)
    text_c(im, RECHIP["he"], 38, W / 2, 342, w=700, color=NAVY); return im
def frames_of2(src, a, n):
    for fr in frames_of(src, a, n): yield rechip(fr)
B.frames_of = frames_of2

if __name__ == "__main__":
    C = json.load(open(sys.argv[1]))
    FREEZE.update({round(float(a), 3): s for a, s in C.get("freeze", {}).items()})
    if C.get("rechip"): RECHIP.update(C["rechip"])
    B.main()
