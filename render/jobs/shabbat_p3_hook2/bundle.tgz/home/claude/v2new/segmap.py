"""map voice-stem segments to a final mix by local cross-correlation. usage: segmap.py final.mp4 voice.wav segs.json(list [a,b,text])"""
import sys, json, numpy as np, subprocess
from scipy.signal import fftconvolve
SR = 8000
def load(p):
    b = subprocess.run(["ffmpeg","-v","error","-i",p,"-ac","1","-ar",str(SR),"-f","f32le","-"],capture_output=True,check=True).stdout
    return np.frombuffer(b,np.float32).astype(np.float64)
x = load(sys.argv[1]); v = load(sys.argv[2]); segs = json.load(open(sys.argv[3])); off = 0.0; out = []
for a, b, t in segs:
    s = v[int(a*SR):int(b*SR)]; c0 = a + off - 3; c0 = max(0, c0); win = x[int(c0*SR):int((b + off + 3)*SR)]
    c = fftconvolve(win, s[::-1], "valid"); k = np.argmax(c); t0 = c0 + k / SR; off = t0 - a
    out.append([round(t0,3), round(t0 + (b - a),3), t]); print(round(t0,2), round(t0+b-a,2), round(off,2), t)
json.dump(out, open(sys.argv[3].replace(".json","_final.json"),"w"), indent=0)
