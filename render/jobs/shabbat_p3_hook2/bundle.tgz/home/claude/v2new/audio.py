"""local audio for a v2new reel: opener (new voice + bed + SFX, or the parent's own audio) + parent body segments + outro.
usage: audio.py cfg.json -> cfg["audio"] (48 kHz stereo, -14 LUFS, true peak under -1.5 dBTP). Frame-exact with build.py."""
import sys, os, json, math, subprocess, re
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit"); import mix as MX
SR = 48000; FPS = 30; SPF = SR // FPS
C = json.load(open(sys.argv[1])); O = C["opener"]; OU = C.get("outro")
def load(p, ch=2):
    b = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", str(ch), "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(b, np.float32).astype(np.float64).reshape(-1, ch)
def fade(x, ms=10):
    f = int(SR * ms / 1000); x = x.copy(); x[:f] *= np.linspace(0, 1, f)[:, None]; x[-f:] *= np.linspace(1, 0, f)[:, None]; return x
def act(y):
    h = max(16, min(2400, len(y) // 8)); m = len(y) // h; e = np.sqrt((y[:m * h].reshape(m, h) ** 2).mean(1)); th = e.max() * 10 ** (-30 / 20); return np.sqrt((e[e > th] ** 2).mean())
P = load(C["src"])
body = []
for a, b in C["body"]:
    n = int(round((b - a) * FPS)) * SPF; i = int(round(a * SR)); seg = P[i:i + n]
    if len(seg) < n: seg = np.pad(seg, ((0, n - len(seg)), (0, 0)))
    body.append(fade(seg))
body = np.concatenate(body); ref = act(body.mean(1))
def bed_slice(spec, t0, n):
    src = spec["src"]
    if src.startswith("file:"): x = load(src[5:])
    else: x = MX.bed(src, spec.get("total", 60.0)).T
    i = int(t0 * SR); y = x[i:i + n]
    if len(y) < n: y = np.pad(y, ((0, n - len(y)), (0, 0)))
    return y
def voice_part(vo_wav, at, n, bed, events):
    v = load(vo_wav, 1)[:, 0]; g = ref * 0.9 / act(v); v = v * g
    y = np.zeros((n, 2)); k = int(at * SR); m = min(n - k, len(v)); y[k:k + m] += v[:m, None]
    vv = np.zeros(n); vv[k:k + m] = v[:m]; sp = MX.speech_env(vv)
    if bed is not None:
        bl = act(v) * 10 ** (-17 / 20); bed = bed * (bl / (act(bed.mean(1)) + 1e-12)); bed = bed * (10 ** (-7 * sp / 20))[:, None]
        f = int(0.25 * SR); bed[-f:] *= np.linspace(1, 0.6, f)[:, None]; y += bed
    for t, kind, db in events:
        x = MX.sfx(kind); x = x.mean(0) if x.ndim == 2 else x; x = x / (act(x) + 1e-12) * act(v) * 10 ** ((-12 + db + MX.SFX_DB.get(kind, 0)) / 20)
        x = x * 10 ** (-4 * sp[min(n - 1, int(t * SR))] / 20); i = int(t * SR); j = min(n, i + len(x))
        if j > i >= 0: y[i:j] += x[:j - i, None]
    return y
T = O.get("times", {})
EV = {"potential": [(0.0, "whoosh", 0), (1.08, "pop", 0), (1.16, "pop", -3)],
      "ethno": [(0.0, "whoosh", 0), (T.get("m", 3) , "pop", -3), (T.get("j", 6), "ding", 0)],
      "gov": [(0.0, "whoosh", 0), (0.98, "pop", 0), (T.get("x", 1.25), "pop", 2), (T.get("party", 2.6), "pop", 0), (T.get("q", 4.3), "ding", -2)],
      "rescue": [(0.0, "whoosh", 0)] + [(0.1 + i * 0.15, "pop", -8) for i in range(8)] + [(0.9, "ding", -4)],
      "terror": [(0.15, "whoosh", 0), (1.15, "ding", 0)],
      "truesize": [(0.0, "whoosh", -3), (0.95, "whoosh", 0), (T.get("same", 2.2), "pop", 0), (T.get("reveal", 4.8), "ding", -2)]}
N0 = int(round(O["take"] * FPS)) * SPF
if O.get("audio") == "parent":
    op = fade(P[:N0], 3)
    # SFX on the parent audio: the scan passing the two 'hope' words, and the War counter staying at 0
    def scan_t(y):   # inverse of op_hatikvah's scan
        from scipy.optimize import brentq
        f = lambda t: 520 + 776 * (lambda x: x * x * (3 - 2 * x))(min(1, max(0, (t - 0.3) / 1.45))) - y
        return brentq(f, 0.3, 1.75)
    ev = [(scan_t(560 + 4 * 92), "pop", -2), (scan_t(560 + 5 * 92), "pop", -2), (1.85, "ding", -4)]
    for t, kind, db in ev:
        x = MX.sfx(kind); x = x.mean(0) if x.ndim == 2 else x; x = x / (act(x) + 1e-12) * ref * 10 ** ((-14 + db + MX.SFX_DB.get(kind, 0)) / 20); i = int(t * SR); j = min(N0, i + len(x)); op[i:j] += x[:j - i, None]
else:
    bs = C["bed"]; t0 = bs["t0"]
    if t0 == "before_body": t0 = C["body"][0][0] - O["take"]
    op = fade(voice_part(O["vo_wav"], O["vo_at"], N0, bed_slice(bs, t0, N0), EV[O["kind"]]), 6)
parts = [op, body]
if OU:
    NU = int(round(OU["dur"] * FPS)) * SPF; bs = C["bed"]
    ou = voice_part(OU["vo_wav"], OU["vo_at"], NU, bed_slice(bs, bs.get("outro_t0", 0), NU), [(0.0, "pop", 0)])
    f = int(1.2 * SR); ou[-f:] *= np.linspace(1, 0, f)[:, None]; parts.append(fade(ou))
def lev(y):
    m = y.mean(1); h = 2400; n = len(m) // h; e = np.sqrt((m[:n * h].reshape(n, h) ** 2).mean(1)); th = e.max() * 10 ** (-1.5); return 20 * np.log10(np.sqrt((e[e > th] ** 2).mean()))
Lb = lev(body[:int(12 * SR)])
for k in [0] + ([2] if OU else []):
    if k == 0 and O.get("audio") == "parent": continue
    g = Lb - 0.5 - lev(parts[k]); parts[k] = parts[k] * 10 ** (g / 20); print("part", k, "gain", round(g, 1), "dB")
y = np.concatenate(parts); tmp = C["audio"] + ".pre.wav"; sf.write(tmp, y.astype(np.float32), SR, subtype="FLOAT")
pre = "alimiter=limit=0.5:attack=3:release=60:level=false"
lo = subprocess.run(["ffmpeg", "-nostats", "-i", tmp, "-af", pre + ",loudnorm=I=-14:TP=-2.5:LRA=11:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
J = json.loads(lo[lo.rindex("{"):lo.rindex("}") + 1])
ln = (f"{pre},loudnorm=I=-14:TP=-2.5:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
      f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-af", ln, "-ar", "48000", "-c:a", "pcm_s16le", C["audio"]], check=True); os.remove(tmp)
print(C["id"], "audio", round(len(y) / SR, 3), "s ->", C["audio"])
