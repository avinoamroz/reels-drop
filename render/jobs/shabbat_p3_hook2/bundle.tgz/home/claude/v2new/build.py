"""v2new reels: new opener (frame 0 hook, motion by 0.5 to 1.5 s) + trimmed parent body + optional question end card.
usage: build.py cfg.json [--frames t1,t2,..]   (--frames writes PNGs of the timeline and exits)
Video only from here; the audio wav is prebuilt locally (audio.py) and muxed. 1080x1920, 30 fps, H.264, AAC 48 kHz."""
import sys, os, json, math, re, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
W, H, FPS = 1080, 1920, 30
FONT_DIR = os.path.join(os.path.dirname(HERE), "vid", "fonts")
EMOJI = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"
_FC = {}
def F(w, s):
    k = (w, int(s))
    if k not in _FC: _FC[k] = ImageFont.truetype(f"{FONT_DIR}/Heebo-{w}.ttf", int(s), layout_engine=ImageFont.Layout.RAQM)
    return _FC[k]
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def clamp(x): return max(0.0, min(1.0, x))
def eout(x): x = clamp(x); return 1 - (1 - x) ** 3
def eio(x): x = clamp(x); return x * x * (3 - 2 * x)
def back(x, s=1.7): x = clamp(x); x -= 1; return 1 + x * x * ((s + 1) * x + s)
def is_he(s): return any("֐" <= c <= "׿" for c in s)
DASHES = tuple(chr(c) for c in (0x2012, 0x2013, 0x2014, 0x2015))
WHITE, GOLD, GOLD2, NAVY, RED, SKY = (255, 255, 255), hx("B8923F"), hx("E6C77E"), hx("163260"), hx("E0475A"), hx("5DB4FF")

_EM = {}
def emoji(e, px):
    k = (e, px)
    if k not in _EM:
        f = ImageFont.truetype(EMOJI, 109, layout_engine=ImageFont.Layout.RAQM)
        im = Image.new("RGBA", (160, 160)); ImageDraw.Draw(im).text((80, 80), e, font=f, embedded_color=True, anchor="mm")
        bb = im.getbbox(); im = im.crop(bb) if bb else im
        s = px / max(im.size); _EM[k] = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    return _EM[k]
def paste_c(base, im, cx, cy, sc=1.0, a=1.0):
    if sc <= 0.01 or a <= 0.01: return
    if sc != 1.0: im = im.resize((max(1, int(im.width * sc)), max(1, int(im.height * sc))), Image.LANCZOS)
    if a < 1.0:
        im = im.copy(); im.putalpha(im.getchannel("A").point(lambda v: int(v * a)))
    base.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))

def rich_line(s, size, w=900, color=WHITE, hl=GOLD2):
    """one line with *highlight* words -> RGBA image (LTR) or plain Hebrew (RTL)"""
    assert not any(d in s for d in DASHES), s
    f = F(w, size)
    if is_he(s):
        s = s.replace("*", ""); wd = int(f.getlength(s, direction="rtl")) + 20
        im = Image.new("RGBA", (wd, int(size * 1.5))); ImageDraw.Draw(im).text((wd / 2, size * 0.75), s, font=f, fill=color, anchor="mm", direction="rtl")
        return im
    parts = re.findall(r"\*[^*]+\*|[^*]+", s); wd = int(sum(f.getlength(p.strip("*")) for p in parts)) + 20
    im = Image.new("RGBA", (wd, int(size * 1.5))); d = ImageDraw.Draw(im); x = 10
    for p in parts:
        t = p.strip("*"); d.text((x, size * 0.75), t, font=f, fill=hl if p.startswith("*") else color, anchor="lm"); x += f.getlength(t)
    return im
def text_c(base, s, size, cx, cy, w=900, color=WHITE, hl=GOLD2, sc=1.0, a=1.0, maxw=980):
    im = rich_line(s, size, w, color, hl)
    if im.width > maxw: im = im.resize((maxw, int(im.height * maxw / im.width)), Image.LANCZOS)
    paste_c(base, im, cx, cy, sc, a); return im.width

REPL = [(r"\ba hundred and twenty\b", "120"), (r"\bfifty-three\b", "53"), (r"^Fifteen\b", "15"), (r"\bfourteen\b", "14")]
def subs_from_words(words, at, maxw=4):
    """[(t0, t1, text)] in reel time, groups of <= maxw words split at punctuation"""
    groups, cur = [], []
    for w in words:
        cur.append(w)
        if w["word"][-1] in ",.?!:" or len(cur) >= maxw: groups.append(cur); cur = []
    if cur: groups.append(cur)
    out = [[g[0]["start"] + at - 0.05, g[-1]["end"] + at + 0.2, " ".join(x["word"] for x in g)] for g in groups]
    for o in out:
        for k, v in REPL: o[2] = re.sub(k, v, o[2], flags=re.I)
    for i in range(len(out) - 1): out[i][1] = min(out[i][1], out[i + 1][0])
    return out
def draw_sub(base, subs, t, y=1640):
    for a, b, s in subs:
        if a <= t < b:
            f = F(800, 52); s = s.replace("...", "..."); tw = f.getlength(s); bw, bh = int(tw) + 64, 86
            im = Image.new("RGBA", (bw, bh)); d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, bw - 1, bh - 1], radius=26, fill=(9, 18, 44, 235), outline=GOLD + (255,), width=3)
            d.text((bw / 2, bh / 2 + 1), s, font=f, fill=WHITE, anchor="mm"); base.alpha_composite(im, (int(W / 2 - bw / 2), int(y - bh / 2)))

def rowfill(im, y0, y1, x=6):
    """paint rows y0..y1 with the colour of column x in the same row (erases text on a vertical-gradient background)"""
    a = np.asarray(im).copy(); a[y0:y1, :, :3] = a[y0:y1, x:x + 1, :3]; return Image.fromarray(a)

def vgrad(c0, c1):
    t = np.linspace(0, 1, H)[:, None, None]; a = np.array(c0)[None, None] * (1 - t) + np.array(c1)[None, None] * t
    a = np.repeat(a, W, 1).astype(np.uint8); return Image.fromarray(np.dstack([a, np.full((H, W), 255, np.uint8)]), "RGBA")

def chip(base, s, cx, cy, size=34, fill=(0, 0, 0, 0), outline=GOLD, color=GOLD2, a=1.0, sc=1.0):
    f = F(800, size); tw = f.getlength(s, direction="rtl" if is_he(s) else None); bw, bh = int(tw) + 48, int(size * 1.7)
    im = Image.new("RGBA", (bw, bh)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, bw - 1, bh - 1], radius=bh // 2, fill=fill, outline=outline + (255,), width=3)
    d.text((bw / 2, bh / 2), s, font=f, fill=color, anchor="mm", direction="rtl" if is_he(s) else None)
    paste_c(base, im, cx, cy, sc, a)

# ============================================================ openers
def op_potential(t, bg, O):
    im = rowfill(bg, 40, 706); sc = 1.08 - 0.08 * eout(t / 0.25)
    text_c(im, "You've listened for *years.*", 86, W / 2, 160, sc=sc)
    text_c(im, "Still can't *speak?*", 86, W / 2, 266, sc=sc)
    text_c(im, "שנים אתם מקשיבים לאנגלית. ועדיין לא מדברים?", 46, W / 2, 352, w=700, color=(214, 224, 240))
    d = ImageDraw.Draw(im); x0, x1 = 430, 990
    # listening meter fills by 1.1 s, speaking stays empty and flashes red
    for k, (lab, he, y) in enumerate([("Listening", "הקשבה", 452), ("Speaking", "דיבור", 548)]):
        paste_c(im, emoji("🎧" if k == 0 else "🗣️", 54), 120, y)
        d.text((170, y - 12), lab, font=F(800, 42), fill=WHITE, anchor="lm"); d.text((170, y + 26), he, font=F(700, 30), fill=(170, 186, 214), anchor="lm", direction="rtl")
        d.rounded_rectangle([x0, y - 22, x1, y + 22], radius=22, fill=(16, 28, 62), outline=(70, 92, 140), width=2)
        if k == 0:
            u = eout((t - 0.12) / 0.95); xe = x0 + 44 + (x1 - x0 - 44) * u
            d.rounded_rectangle([x0, y - 22, xe, y + 22], radius=22, fill=hx("F4A340"))
            d.text((x1 - 16, y), f"{int(round(100 * u))}%", font=F(900, 34), fill=NAVY if u > 0.8 else WHITE, anchor="rm")
        else:
            fl = t > 1.15; sh = 7 * math.sin(t * 60) * math.exp(-(t - 1.15) * 6) if fl else 0
            d.rounded_rectangle([x0 + sh, y - 22, x0 + 40 + sh, y + 22], radius=22, fill=RED if fl else (90, 104, 140))
            if fl: d.text((x1 - 16 + sh, y), "0%", font=F(900, 34), fill=RED, anchor="rm")
    draw_sub(im, O["_subs"], t); return im

LYR = ["כל עוד בלבב פנימה", "נפש יהודי הומיה", "ולפאתי מזרח קדימה", "עין לציון צופיה", "עוד לא אבדה תקותנו", "התקוה בת שנות אלפים", "להיות עם חפשי בארצנו", "ארץ ציון וירושלים"]
_HBG = {}
def hat_bg():
    if "bg" not in _HBG:
        im = vgrad((14, 30, 58), (22, 50, 96)); d = ImageDraw.Draw(im, "RGBA"); cx, cy, r = W / 2, 905, 440
        for rot in (0, 180):
            pts = [(cx + r * math.sin(math.radians(rot + a)), cy - r * math.cos(math.radians(rot + a))) for a in (0, 120, 240)]
            d.polygon(pts, outline=(120, 160, 220, 20), width=5)
        d.rectangle([0, 46, W, 60], fill=(40, 80, 160, 120)); d.rectangle([0, H - 60, W, H - 46], fill=(40, 80, 160, 120))
        _HBG["bg"] = im
    return _HBG["bg"].copy()
def op_hatikvah(t, bg, O):
    im = hat_bg(); sc = 1.08 - 0.08 * eout(t / 0.25)
    text_c(im, "Israel's anthem has", 96, W / 2, 210, sc=sc); text_c(im, "no word for *war.*", 96, W / 2, 318, sc=sc)
    text_c(im, "בהמנון של ישראל אין מילה למלחמה.", 50, W / 2, 410, w=700, color=(206, 218, 238))
    d = ImageDraw.Draw(im, "RGBA"); y0, dy = 560, 92; scan = y0 - 40 + (len(LYR) * dy + 40) * eio((t - 0.3) / 1.45)
    hope = 0
    if 0.3 < t < 1.9:
        d.rectangle([90, scan - 3, W - 90, scan + 3], fill=GOLD2 + (150,)); d.rectangle([90, scan - 34, W - 90, scan - 3], fill=GOLD2 + (26,))
    for i, ln in enumerate(LYR):
        y = y0 + i * dy; passed = scan > y
        words = ln.split(); f = F(700, 54); full = f.getlength(ln, direction="rtl"); x = W / 2 + full / 2
        for wd in words:   # right to left
            ww = f.getlength(wd, direction="rtl"); is_hope = "תקו" in wd
            if is_hope and passed: hope += 1
            colr = GOLD2 if (is_hope and passed) else ((236, 240, 248) if passed else (120, 140, 176))
            if is_hope and passed:
                p = clamp((scan - y) / 60); s = 1 + 0.25 * math.sin(math.pi * p)
                tmp = Image.new("RGBA", (int(ww) + 40, 90)); ImageDraw.Draw(tmp).text((tmp.width / 2, 45), wd, font=f, fill=GOLD2, anchor="mm", direction="rtl")
                paste_c(im, tmp, x - ww / 2, y, s)
            else:
                d.text((x - ww / 2, y), wd, font=f, fill=colr, anchor="mm", direction="rtl")
            x -= ww + f.getlength(" ")
    # counters
    fin = t > 1.8
    for k, (lab, he, n, c) in enumerate([("War", "מלחמה", 0, RED), ("Hope", "תקווה", hope, GOLD2)]):
        cx = 300 + k * 480; cy = 1360; s = 1 + 0.18 * math.exp(-((t - 1.85) / 0.08) ** 2) if k == 0 else 1.0
        box = Image.new("RGBA", (400, 150)); bd = ImageDraw.Draw(box)
        bd.rounded_rectangle([0, 0, 399, 149], radius=30, fill=(10, 20, 44, 230), outline=c + (255,), width=4)
        bd.text((40, 52), lab, font=F(800, 46), fill=WHITE, anchor="lm"); bd.text((40, 108), he, font=F(700, 36), fill=(180, 196, 222), anchor="lm", direction="rtl")
        bd.text((360, 75), str(n), font=F(900, 96), fill=c, anchor="rm"); paste_c(im, box, cx, cy, s)
    draw_sub(im, O["_subs"], t); return im

_EBG = {}
def op_ethno(t, bg, O):
    if "bg" not in _EBG:
        b = Image.new("RGBA", (W, H), (11, 11, 13, 255)); g = Image.new("L", (W, H), 0); ImageDraw.Draw(g).ellipse([-200, 500, W + 200, 1700], fill=60)
        b.paste((58, 40, 14, 255), (0, 0), g.filter(ImageFilter.GaussianBlur(160))); _EBG["bg"] = b
    im = _EBG["bg"].copy(); sc = 1.08 - 0.08 * eout(t / 0.25)
    text_c(im, "*120* Christian countries.", 84, W / 2, 190, sc=sc); text_c(im, "*53* Muslim. *1* Jewish.", 84, W / 2, 296, sc=sc)
    text_c(im, "120 מדינות נוצריות. 53 מוסלמיות. 1 יהודית.", 48, W / 2, 386, w=700, color=(225, 214, 190))
    text_c(im, "Countries where it is the majority religion", 34, W / 2, 452, w=700, color=(160, 160, 166))
    d = ImageDraw.Draw(im, "RGBA"); T = O.get("times", {})
    cols = [(120, 10, 205, T["c"], "Christian", "נוצרים"), (53, 6, 640, T["m"], "Muslim", "מוסלמים")]
    for n, nc, cx, t0, lab, he in cols:
        sp = 34 if nc == 10 else 46; r = 12 if nc == 10 else 16; rows = math.ceil(n / nc); gx = cx - (nc - 1) * sp / 2 + (90 if nc == 10 else 0)
        dur = 1.6 if n > 100 else 1.0; k_on = int(n * eout((t - t0) / dur)) if t >= t0 else 0
        for i in range(n):
            x = gx + (i % nc) * sp; y = 680 + (i // nc) * sp
            if i < k_on: d.ellipse([x - r, y - r, x + r, y + r], fill=(236, 230, 214, 255))
            else: d.ellipse([x - r, y - r, x + r, y + r], outline=(80, 76, 70, 255), width=2)
        xx = gx + (nc - 1) * sp / 2; ycnt = 1128
        d.text((xx, ycnt + 20), str(k_on), font=F(900, 92), fill=WHITE if k_on else (90, 88, 84), anchor="mm")
        d.text((xx, ycnt + 92), lab, font=F(800, 40), fill=(220, 214, 200), anchor="mm"); d.text((xx, ycnt + 140), he, font=F(700, 34), fill=(160, 154, 140), anchor="mm", direction="rtl")
    # the one Jewish state
    tj = T["j"]; cx, cy = 925, 880; on = t >= tj; p = (t - tj)
    if on:
        g = 1 + 0.35 * math.exp(-p * 3) * abs(math.sin(p * 8)); rr = 34 * back(p / 0.35)
        glow = Image.new("RGBA", (360, 360)); ImageDraw.Draw(glow).ellipse([80, 80, 280, 280], fill=GOLD2 + (150,)); glow = glow.filter(ImageFilter.GaussianBlur(40))
        paste_c(im, glow, cx, cy, g); d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=GOLD2 + (255,))
    else:
        d.ellipse([cx - 34, cy - 34, cx + 34, cy + 34], outline=(80, 76, 70, 255), width=3)
    d.text((cx, 1148), "1" if on else "0", font=F(900, 92), fill=GOLD2 if on else (90, 88, 84), anchor="mm")
    d.text((cx, 1220), "Jewish", font=F(800, 40), fill=(220, 214, 200), anchor="mm"); d.text((cx, 1268), "יהודים", font=F(700, 34), fill=(160, 154, 140), anchor="mm", direction="rtl")
    d.text((W / 2, 1545), "Source: Pew Research Center, global religion data for 2020 (countries and territories)", font=F(400, 26), fill=(130, 128, 124), anchor="mm")
    draw_sub(im, O["_subs"], t, y=1660); return im

_GBG = {}
def op_gov(t, bg, O):
    if "bg" not in _GBG:
        b = vgrad((14, 28, 66), (30, 66, 178)); d = ImageDraw.Draw(b, "RGBA")
        for (x, y) in ((0, 0), (W, 0), (0, H), (W, H)):
            sx = 1 if x == 0 else -1; sy = 1 if y == 0 else -1
            d.line([(x, y + sy * 0), (x + sx * 150, y + sy * 150)], fill=(200, 220, 255, 70), width=3)
            d.line([(x + sx * 150, y), (x, y + sy * 150)], fill=(200, 220, 255, 70), width=3)
        _GBG["bg"] = b
    im = _GBG["bg"].copy(); sc = 1.08 - 0.08 * eout(t / 0.25); T = O.get("times", {})
    text_c(im, "You don't vote for", 88, W / 2, 200, sc=sc); text_c(im, "Israel's *Prime Minister.*", 88, W / 2, 308, sc=sc, hl=SKY)
    text_c(im, "בישראל לא מצביעים לראש הממשלה.", 50, W / 2, 400, w=700, color=(206, 220, 245))
    d = ImageDraw.Draw(im, "RGBA")
    # PM card with a red X stamp
    pm = Image.new("RGBA", (620, 170)); pd = ImageDraw.Draw(pm)
    pd.rounded_rectangle([0, 0, 619, 169], radius=28, fill=(255, 255, 255, 245)); pd.rectangle([40, 50, 110, 120], outline=NAVY + (255,), width=6)
    pd.text((140, 68), "Prime Minister", font=F(900, 54), fill=NAVY, anchor="lm"); pd.text((140, 124), "ראש ממשלה", font=F(700, 36), fill=(90, 104, 130), anchor="lm", direction="rtl")
    u = eout((t - 0.05) / 0.35); paste_c(im, pm, W / 2 + (1 - u) * -700, 600)
    if t > T["x"]:
        s = back((t - T["x"]) / 0.22); dd = ImageDraw.Draw(im); cx, cy = W / 2 - 235, 600; r = 46 * s
        dd.line([(cx - r, cy - r), (cx + r, cy + r)], fill=RED, width=16); dd.line([(cx - r, cy + r), (cx + r, cy - r)], fill=RED, width=16)
        chip(im, "Not on the ballot", W / 2, 728, 32, fill=(224, 71, 90, 255), outline=RED, color=WHITE, sc=back((t - T["x"] - 0.1) / 0.25))
    # ballot box + party slip dropping in
    bx, by = W / 2, 1180; d.rounded_rectangle([bx - 270, by - 150, bx + 270, by + 190], radius=30, fill=(18, 44, 112, 255), outline=(150, 190, 255, 255), width=4)
    d.text((bx, by + 70), "KNESSET ELECTION", font=F(900, 40), fill=(220, 232, 255), anchor="mm"); d.text((bx, by + 122), "בחירות לכנסת", font=F(700, 34), fill=(160, 186, 230), anchor="mm", direction="rtl")
    slip = Image.new("RGBA", (330, 200)); sd = ImageDraw.Draw(slip); sd.rounded_rectangle([0, 0, 329, 199], radius=14, fill=(255, 255, 255, 255))
    sd.text((165, 80), "PARTY", font=F(900, 64), fill=NAVY, anchor="mm"); sd.text((165, 148), "מפלגה", font=F(800, 44), fill=(90, 104, 130), anchor="mm", direction="rtl")
    v = eio((t - 0.3) / 0.75); sy = 760 + v * (by - 150 - 760 + 40); rot = (1 - v) * 18
    if t < 1.25:
        sl = slip.rotate(rot, expand=True, resample=Image.BICUBIC)
        if v > 0.85:   # clip into the slot
            keep = int(sl.height * clamp(1 - (v - 0.85) / 0.15 * 0.9)); sl = sl.crop((0, 0, sl.width, max(1, keep)))
        im.alpha_composite(sl, (int(bx - sl.width / 2), int(sy - sl.height / 2)))
    d.rounded_rectangle([bx - 170, by - 160, bx + 170, by - 140], radius=10, fill=(6, 14, 40, 255))
    if t > T["party"]:
        chip(im, "You vote for a party list", W / 2, 1440, 40, fill=(30, 158, 98, 255), outline=hx("1E9E62"), color=WHITE, sc=back((t - T["party"]) / 0.25))
    if t > T["q"]:
        q = back((t - T["q"]) / 0.3); text_c(im, "So who picks the PM?", 64, W / 2, 900, w=900, sc=q, color=GOLD2)
    draw_sub(im, O["_subs"], t); return im

def op_rescue(t, bg, O):
    im = rowfill(bg, 40, 640); T = O.get("times", {})
    n = 15; s = 1 + 0.14 * math.exp(-((t - 1.25) / 0.09) ** 2)
    f = F(900, 190); fw = f.getlength("15"); f2 = F(900, 96); w2 = f2.getlength(" babies")
    x0 = W / 2 - (fw + w2 + 24) / 2; tmp = Image.new("RGBA", (int(fw) + 40, 240)); ImageDraw.Draw(tmp).text((20, 120), str(n), font=f, fill=GOLD2, anchor="lm")
    paste_c(im, tmp, x0 + tmp.width / 2 - 20, 160, s); ImageDraw.Draw(im).text((x0 + fw + 34, 178), "babies", font=f2, fill=WHITE, anchor="lm")
    text_c(im, "born in an Israeli field hospital", 64, W / 2, 312)
    text_c(im, "15 תינוקות נולדו בבית חולים שדה ישראלי", 46, W / 2, 386, w=700, color=(214, 224, 240))
    for i in range(15):
        ti = 0.1 + i * 0.075
        if t >= ti: paste_c(im, emoji("👶", 50), W / 2 + (i - 7) * 62, 470, back((t - ti) / 0.2))
    chip(im, "Turkey, 1999 · טורקיה", W / 2, 560, 34, fill=(9, 18, 44, 230), sc=back((t - 0.9) / 0.25))
    draw_sub(im, O["_subs"], t); return im

_TBG = {}
def op_terror(t, bg, O):
    if "bg" not in _TBG: _TBG["bg"] = vgrad((6, 8, 20), (24, 14, 30))
    im = _TBG["bg"].copy(); T = O.get("times", {})
    # two sweeping spotlights
    for k, (ox, ph) in enumerate(((-60, 0.0), (W + 60, 1.7))):
        ang = math.radians((28 if k == 0 else -28) + 16 * math.sin(t * 2.6 + ph)); L = 2300
        cx, cy = ox + L * math.sin(ang), -80 + L * math.cos(ang); wv = 330
        cone = Image.new("RGBA", (W, H)); ImageDraw.Draw(cone).polygon([(ox, -80), (cx - wv, cy), (cx + wv, cy)], fill=(255, 236, 190, 46))
        im.alpha_composite(cone.filter(ImageFilter.GaussianBlur(18)))
    chip(im, "THE TERROR AWARDS · SATIRE, EVERY FACT SOURCED", W / 2, 118, 28, fill=(0, 0, 0, 120))
    sc = 1.08 - 0.08 * eout(t / 0.25)
    text_c(im, "And the award for", 98, W / 2, 250, sc=sc); text_c(im, "*terror* goes to...", 98, W / 2, 360, sc=sc)
    text_c(im, "והפרס על טרור הולך ל...", 52, W / 2, 452, w=700, color=(225, 214, 190))
    d = ImageDraw.Draw(im, "RGBA"); ex, ey = W / 2, 1120
    # envelope: card rises out of it from 0.45 s
    u = eout((t - 0.45) / 0.6); card_y = ey - 40 - 300 * u
    cd = Image.new("RGBA", (440, 300)); cdd = ImageDraw.Draw(cd); cdd.rounded_rectangle([0, 0, 439, 299], radius=18, fill=(250, 246, 236, 255), outline=GOLD + (255,), width=5)
    cdd.text((220, 110), "THE WINNER", font=F(900, 52), fill=NAVY, anchor="mm"); cdd.text((220, 190), "IS...", font=F(900, 64), fill=GOLD, anchor="mm")
    im.alpha_composite(cd, (int(ex - 220), int(card_y - 150)))
    d = ImageDraw.Draw(im, "RGBA")
    d.rectangle([ex - 300, ey - 20, ex + 300, ey + 300], fill=(196, 152, 64, 255)); d.polygon([(ex - 300, ey + 300), (ex, ey + 130), (ex + 300, ey + 300)], fill=(170, 128, 50, 255))
    fl = 1 - 2 * eio((t - 0.2) / 0.3)   # flap opens
    d.polygon([(ex - 300, ey - 20), (ex + 300, ey - 20), (ex, ey - 20 + 170 * fl)], fill=(212, 170, 80, 255))
    if t > 1.15: paste_c(im, emoji("🏆", 170), ex, 640, back((t - 1.15) / 0.3))
    draw_sub(im, O["_subs"], t); return im

def op_truesize(t, bg, O):
    T = O.get("times", {}); im = bg.copy()
    a = 1 - eio((t - T["reveal"]) / 0.3)
    if a > 0:
        cov = rowfill(bg, 150, 645); cov = Image.blend(bg, cov, a) if a < 1 else cov
        im = cov
        if a > 0.02:
            sc = 1.08 - 0.08 * eout(t / 0.25)
            text_c(im, "Drag *Greenland*", 104, W / 2, 255, sc=sc, a=a, hl=SKY); text_c(im, "onto *Africa.*", 104, W / 2, 370, sc=sc, a=a, hl=SKY)
            text_c(im, "גררו את גרינלנד על אפריקה.", 52, W / 2, 470, w=700, color=(206, 220, 245), a=a)
            if t > T["same"]: chip(im, "Same size?", W / 2, 560, 38, fill=(9, 18, 44, 230), outline=SKY, color=WHITE, sc=back((t - T["same"]) / 0.22), a=a)
    im = rowfill(im, 1500, 1602)
    draw_sub(im, O["_subs"], t, y=1550); return im

OPENERS = dict(potential=op_potential, hatikvah=op_hatikvah, ethno=op_ethno, gov=op_gov, rescue=op_rescue, terror=op_terror, truesize=op_truesize)

# ============================================================ outro card
def outro(t, last, O):
    if "_blur" not in O: O["_blur"] = last.filter(ImageFilter.GaussianBlur(10))
    u = eout(t / 0.35); base = Image.blend(last, O["_blur"], u); im = Image.blend(base, Image.new("RGBA", (W, H), (6, 12, 30, 255)), 0.84 * u)
    card = Image.new("RGBA", (W, H)); cy = 820
    text_c(card, O["en1"], 88, W / 2, cy - 60, sc=back(t / 0.4)); text_c(card, O["en2"], 88, W / 2, cy + 50, sc=back((t - 0.05) / 0.4))
    text_c(card, O["he"], 50, W / 2, cy + 150, w=700, color=(214, 224, 240), a=clamp((t - 0.15) / 0.3))
    text_c(card, "Tell me in the comments 👇".replace(" 👇", ""), 46, W / 2, cy + 250, w=800, color=GOLD2, a=clamp((t - 0.3) / 0.3))
    text_c(card, "ספרו לי בתגובות", 40, W / 2, cy + 314, w=700, color=(190, 200, 220), a=clamp((t - 0.3) / 0.3))
    chip(card, O["follow"], W / 2, cy + 430, 38, fill=(42, 136, 212, 255), outline=hx("2A88D4"), color=WHITE, a=clamp((t - 0.45) / 0.3))
    im.alpha_composite(card); draw_sub(im, O["_subs"], t); return im

# ============================================================ timeline
def frames_of(src, a, n):
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-ss", f"{a:.3f}", "-i", src, "-frames:v", str(n), "-vf", "fps=30,scale=1080:1920",
                          "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    last = None
    for _ in range(n):
        b = p.stdout.read(W * H * 3)
        if len(b) < W * H * 3: break
        last = Image.frombuffer("RGB", (W, H), b).convert("RGBA"); yield last
    p.stdout.close(); p.wait()
    # pad (rare: short read at the end of a file)

def main():
    C = json.load(open(sys.argv[1])); O = C["opener"]; src = C["src"]
    def load_words(p, at): return subs_from_words(json.load(open(p)), at) if p else []
    O["_subs"] = load_words(O.get("words"), O.get("vo_at", 0)) if not O.get("subs") else O["subs"]
    N0 = int(round(O["take"] * FPS)); segs = [(a, b, int(round((b - a) * FPS))) for a, b in C["body"]]
    OU = C.get("outro"); NU = int(round(OU["dur"] * FPS)) if OU else 0
    if OU: OU["_subs"] = load_words(OU.get("words"), OU.get("vo_at", 0))
    total = N0 + sum(s[2] for s in segs) + NU
    want = None
    if "--frames" in sys.argv: want = {int(round(float(x) * FPS)): x for x in sys.argv[sys.argv.index("--frames") + 1].split(",")}
    out = C["out"]; os.makedirs(os.path.dirname(out), exist_ok=True)
    enc = None
    if want is None:
        enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                                "-i", C["audio"], "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                                "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-t", f"{total / FPS:.3f}", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    k = 0
    def emit(img):
        nonlocal k
        if want is None: enc.stdin.write(img.convert("RGB").tobytes())
        elif k in want: img.convert("RGB").save(f"{C['qa_dir']}/f_{float(want[k]):06.2f}.png")
        k += 1
    fn = OPENERS[O["kind"]]
    if want is not None: os.makedirs(C["qa_dir"], exist_ok=True)
    need_op = want is None or any(x < N0 for x in want)
    if O.get("bg_t0") is not None:
        bgs = list(frames_of(src, O["bg_t0"], int(round(O.get("bg_len", O["take"]) * FPS)))) if need_op else []
        print("bg frames", len(bgs))
        for i in range(N0):
            if want is not None and i not in want: k += 1; continue
            bgi = bgs[min(int(i * len(bgs) / N0), len(bgs) - 1)] if bgs else Image.new("RGBA", (W, H)); emit(fn(i / FPS, bgi, O))
    else:
        for i in range(N0):
            if want is not None and i not in want: k += 1; continue
            emit(fn(i / FPS, None, O))
    last = None
    for a, b, n in segs:
        if want is not None and not any(k <= x < k + n for x in want) and not (OU and a == segs[-1][0]):
            k += n; continue
        got = 0
        for fr in frames_of(src, a, n):
            last = fr; emit(fr); got += 1
        while got < n: emit(last); got += 1
    if OU:
        for i in range(NU): emit(outro(i / FPS, last, OU))
    if enc: enc.stdin.close(); enc.wait(); print("wrote", out, total / FPS, "s", "rc", enc.returncode)
    else: print("frames", sorted(want.values()))

if __name__ == "__main__":
    main()
