"""after the cloud renders: QA frames, verify raw URLs, write gh payloads and Launch Map JSON docs (local files for ArtifactData).
usage: deliver.py qa | payloads"""
import sys, json, glob, os, subprocess, time
R = "/home/claude/v2new"; DROP = "/home/claude/reels-drop"; Q = "/home/claude/posting/queue/gh"
RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
cfgs = [json.load(open(f)) for f in sorted(glob.glob(f"{R}/cfg/*.json"))]
def dur(p): return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout)
if sys.argv[1] == "qa":
    from PIL import Image
    os.makedirs(f"{R}/qa/final", exist_ok=True)
    for c in cfgs:
        mp4 = f"{DROP}/{c['id']}.mp4"; d = dur(mp4); ts = [0, 0.5, 1.0, 1.5, 3.0, 5.0, c["opener"]["take"] + 0.5, d * 0.5, d * 0.75, d - 1.0]
        ims = []
        for t in ts:
            p = f"{R}/qa/final/{c['id']}_{t:05.1f}.png"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", mp4, "-frames:v", "1", p], check=True); ims.append(Image.open(p))
        S = Image.new("RGB", (360 * len(ims), 640)); [S.paste(im.resize((360, 640)), (i * 360, 0)) for i, im in enumerate(ims)]
        S.save(f"{R}/qa/final/{c['id']}_sheet360.jpg", quality=85)
        e = subprocess.run(["ffmpeg", "-nostats", "-i", mp4, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
        I = [l for l in e.splitlines() if l.strip().startswith("I:")][-1].strip(); P = [l for l in e.splitlines() if l.strip().startswith("Peak:")][-1].strip()
        print(c["id"], round(d, 2), "s", I, P, "frames at", [round(t, 1) for t in ts])
elif sys.argv[1] == "payloads":
    for c in cfgs:
        i = c["id"]; url = RAW + f"{i}.mp4"; cap = open(f"{R}/captions/{i}.txt").read().strip(); assert len(cap) < 2200
        body = {"media_type": "REELS", "video_url": url, "caption": cap, "share_to_feed": True, "is_ai_generated": True,
                "trial_params": {"graduation_strategy": "SS_PERFORMANCE"}}
        p = {"action": "init", "account": c["account"], "tag": f"{i}-gh", "body": json.dumps(body, ensure_ascii=False)}
        json.dump(p, open(f"{Q}/{i}.json", "w"), ensure_ascii=False)
        code = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "-I", url], capture_output=True, text=True).stdout.strip()
        print(i, c["account"], f"{Q}/{i}.json", "raw", code)
