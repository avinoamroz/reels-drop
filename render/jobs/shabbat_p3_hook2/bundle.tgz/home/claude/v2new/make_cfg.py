"""write cfg/<id>.json for the 7 v2new reels (paths, opener times from the voice word timings, body segments, outro)."""
import json, os
R = os.path.dirname(os.path.abspath(__file__)); HOME = os.path.dirname(R); V = f"{R}/vo"
os.makedirs(f"{R}/cfg", exist_ok=True); os.makedirs(f"{R}/out", exist_ok=True)
def wd(n, p): return json.load(open(f"{V}/{n}_{p}_words.json"))
def at(n, p, word, lead, k=0):
    hits = [w["start"] for w in wd(n, p) if w["word"].strip(".,?!:").lower() == word.lower()]; return round(hits[k] + lead, 3)
def dur(n, p): import soundfile as sf; return sf.info(f"{V}/{n}_{p}.wav").duration
# hatikvah: first parent line words (voice timeline == final timeline for line 1)
hw = json.load(open(f"{HOME}/hatikvah/v3/vo_chain_words.json"))[:11]
json.dump([{"word": w["word"], "start": round(w["start"], 3), "end": round(w["end"], 3)} for w in hw], open(f"{V}/hatikvah_hook_words.json", "w"))
L = 0.2
C = {
 "potential_v2new": dict(parent="potential", account="express", src=f"{HOME}/potential/potential_v5_cta2.mp4",
    opener=dict(kind="potential", take=round(L + dur("potential", "hook") + 0.35, 3), bg_t0=0.0, bg_len=2.95, vo="potential_hook", vo_at=L),
    body=[[3.0, 8.69], [9.13, 15.09], [15.99, 22.72], [23.62, 29.22], [30.11, 36.3], [43.66, 52.75]],
    outro=dict(dur=round(L + dur("potential", "end") + 1.5, 3), vo="potential_end", vo_at=L, en1="His day or hers?", en2="Which one is *yours?*",
               he="היום שלו או שלה? איזה מהם שלכם?", follow="Follow @expressenglishcom"),
    bed=dict(src=f"file:{HOME}/potential/vo_cta2/bed_only_cta2.wav", t0=0.0, outro_t0=60.0)),
 "hatikvah_v2new": dict(parent="lib_hatikvah", account="noam", src=f"{HOME}/hatikvah/hatikvah_v3.mp4",
    opener=dict(kind="hatikvah", take=3.95, audio="parent", words_file="hatikvah_hook", vo_at=0.0),
    body=[[6.75, 45.75], [56.3, 61.32]], outro=None, bed=None),
 "ethnoreligion_v2new": dict(parent="ethnoreligion_hook2", account="noam", src=f"{HOME}/ethnoreligion/ethnoreligion_v3_clean.mp4",
    opener=dict(kind="ethno", take=round(L + dur("ethno", "hook") + 0.35, 3), vo="ethno_hook", vo_at=L,
                times=dict(c=0.08, m=at("ethno", "hook", "Muslims", L) - 0.05, j=at("ethno", "hook", "One", L) - 0.05)),
    body=[[0.0, 18.05], [54.34, 59.75], [65.17, 70.6], [92.75, 105.3]], outro=None,
    bed=dict(src=f"file:{HOME}/ethnoreligion/music_er.wav", t0=0.0)),
 "branches_executive_v2new": dict(parent="lib_branches_executive_government_vo_7min_clean", account="noam", src=f"{HOME}/branches/executive/government_vo_7min_clean.mp4",
    opener=dict(kind="gov", take=round(L + dur("gov", "hook") + 0.35, 3), vo="gov_hook", vo_at=L,
                times=dict(x=1.25, party=at("gov", "hook", "You", L, 1), q=at("gov", "hook", "So", L))),
    body=[[4.17, 31.6], [40.31, 51.95]],
    outro=dict(dur=round(L + dur("gov", "end") + 1.6, 3), vo="gov_end", vo_at=L, en1="Did you know *this?*", en2="",
               he="ידעתם את זה?", follow="Follow @noamroz__"),
    bed=dict(src="cinematic", t0=0.0, outro_t0=20.0)),
 "israel_rescue_v2new": dict(parent="lib_israel_rescue", account="noam", src=f"{HOME}/israel_rescue/israel_rescue_v9.mp4",
    opener=dict(kind="rescue", take=round(L + dur("rescue", "hook") + 0.35, 3), bg_t0=21.3, bg_len=3.6, vo="rescue_hook", vo_at=L),
    body=[[34.45, 47.95], [52.2, 82.93]], outro=None, bed=dict(src="cinematic", t0=0.0)),
 "terror_awards_v2new": dict(parent="terror_awards", account="noam", src=f"{HOME}/reels-drop/terror_awards.mp4",
    opener=dict(kind="terror", take=round(0.25 + dur("terror", "hook") + 0.4, 3), vo="terror_hook", vo_at=0.25),
    body=[[11.5, 58.8]], outro=None, bed=dict(src="cinematic", t0="before_body", total=58.8)),
 "true_size_v2new": dict(parent="true_size_hook2", account="noam", src=f"{HOME}/true_size_map/true_size_v4.mp4",
    opener=dict(kind="truesize", take=round(L + dur("truesize", "hook") + 0.3, 3), bg_t0=23.3, bg_len=6.5, vo="truesize_hook", vo_at=L,
                times=dict(same=at("truesize", "hook", "Same", L), reveal=at("truesize", "hook", "Africa", L, 1) - 0.1)),
    body=[[29.8, 49.4], [56.45, 62.5], [63.8, 70.1]],
    outro=dict(dur=round(L + dur("truesize", "end") + 1.6, 3), vo="truesize_end", vo_at=L, en1="Which one surprised", en2="you the *most?*",
               he="מה הכי הפתיע אתכם?", follow="Follow @noamroz__"),
    bed=dict(src=f"file:{HOME}/rehook3/h3/ts_music.wav", t0=0.0, outro_t0=8.0)),
}
for i, c in C.items():
    c["id"] = i; c["out"] = f"{R}/out/{i}.mp4"; c["audio"] = f"{R}/out/{i}_mix.wav"; c["qa_dir"] = f"{R}/qa/{i}"
    o = c["opener"]; o["words"] = f"{V}/{o.get('words_file') or o['vo']}_words.json"
    if o.get("vo"): o["vo_wav"] = f"{V}/{o['vo']}.wav"
    if c["outro"]: c["outro"]["words"] = f"{V}/{c['outro']['vo']}_words.json"; c["outro"]["vo_wav"] = f"{V}/{c['outro']['vo']}.wav"
    json.dump(c, open(f"{R}/cfg/{i}.json", "w"), ensure_ascii=False, indent=1)
    n = round(o["take"] + sum(b - a for a, b in c["body"]) + (c["outro"]["dur"] if c["outro"] else 0), 2)
    print(i, "opener", o["take"], "total", n, o.get("times", ""))
