"""she_walks_alone_v2: one stick-figure woman walks six cities on the map, a live 3-rule scorecard fills per city."""
import math
HOOK = "One woman. *6* cities.|*3* rules."; HOOK_Y = 930
STYLE = "map_fold"; CAM0 = (33.0, 40.0, 82.0)
BED = "journey"; GAPS = {0: 0.45, 1: 0.5, 2: 0.3, 3: 0.3, 4: 0.3, 5: 0.4, 6: 0.4, 7: 0.6, 8: 0.45, 9: 0.45}
CITIES = [("London", "GB", (-0.13, 51.5)), ("Tel Aviv", "IL", (34.78, 32.08)), ("Cairo", "EG", (31.24, 30.04)),
          ("Riyadh", "SA", (46.68, 24.71)), ("Tehran", "IR", (51.39, 35.69)), ("Kabul", "AF", (69.2, 34.55))]
CELLS = ["YYY", "YYY", "YYY", "PPY", "PNY", "NNN"]

def keys(T, cam):
    return [(0.0, 0.01, cam(*CAM0)), (T.S(1) - 0.2, 1.0, cam(33.0, 40.0, 84, 470)), (T.S(10) - 0.3, 1.0, cam(*CAM0))]

def cell_t(T, k, j):
    li = 2 + k
    if k <= 2: return T.WT(li, "yes", n=j + 1)
    if k == 3: return T.WT(li, ["travel", "modest", "university"][j])
    if k == 4: return T.WT(li, ["married", "hijab", "university"][j])
    return T.WT(li, "no", n=j + 1)

def woman(cv, x, y, sc, ph, a, walking):
    from rlib import WHITE, SKY
    hs = 13 * sc; sw = math.sin(ph) * 9 * sc if walking else 0
    hip = (x, y - 30 * sc); neck = (x, y - 62 * sc); head = (x, neck[1] - hs - 2 * sc)
    cv.line([hip, (x - 9 * sc + sw, y)], WHITE, 4 * sc, a); cv.line([hip, (x + 9 * sc - sw, y)], WHITE, 4 * sc, a)
    cv.c.new_path(); cv.c.move_to(x, neck[1]); cv.c.line_to(x - 17 * sc, hip[1] + 4 * sc); cv.c.line_to(x + 17 * sc, hip[1] + 4 * sc); cv.c.close_path()
    cv.col(SKY, a); cv.c.fill()
    cv.line([(x, neck[1] + 4 * sc), (x - 14 * sc - sw * 0.6, neck[1] + 26 * sc)], WHITE, 4 * sc, a)
    cv.line([(x, neck[1] + 4 * sc), (x + 14 * sc + sw * 0.6, neck[1] + 26 * sc)], WHITE, 4 * sc, a)
    cv.circ(*head, hs, "#0E2250", a, stroke=WHITE, lw=4 * sc)
    cv.line([(head[0] + hs * 0.6, head[1] - hs * 0.6), (head[0] + hs * 1.5, head[1] + hs * 0.6)], "#E6C77E", 5 * sc, a)

def pos(T, t, X):
    from rlib import ease
    pts = [X.geo(*c[2]) for c in CITIES]
    if t < T.S(2): return pts[0], False
    for k in range(1, 6):
        t0, t1 = T.S(1 + k) + 0.6, T.S(2 + k) - 0.05
        if t < t0: return pts[k - 1], False
        if t < t1:
            u = ease((t - t0) / (t1 - t0)); p = (pts[k - 1][0] + (pts[k][0] - pts[k - 1][0]) * u, pts[k - 1][1] + (pts[k][1] - pts[k - 1][1]) * u - 40 * math.sin(math.pi * u))
            return p, True
    return pts[5], False

def draw(E, X, cv, T, t):
    from rlib import seg, win, YEL, WHITE, SKY
    A = win(t, T.S(1) - 0.1, T.S(10) - 0.2, 0.4, 0.4)
    if A > 0.01:
        for k, (nm, fl, ll) in enumerate(CITIES):
            ca = A * seg(t, T.S(2 + k) - 0.2, T.S(2 + k) + 0.1)
            if ca > 0.01:
                x, y = X.geo(*ll); cv.circ(x, y, 9, YEL, ca); E.tag(cv, nm, x + (-40 if nm == "Tel Aviv" else 0), y + (-40 if nm == "Tel Aviv" else 42), 38, WHITE, ca)
        (x, y), wk = pos(T, t, X); woman(cv, x, y - 4, 2.3, t * 9, A, wk)
        E.panel(cv, 40, 790, 1000, 720, A)
        E.checks(cv, [("✈️", "Travel"), ("\U0001F487‍♀️", "Hair"), ("\U0001F393", "Study")],
                 [dict(label=nm, flag=fl, at=T.S(2 + k), hl=(fl == "IL"), cells=[(CELLS[k][j], cell_t(T, k, j)) for j in range(3)]) for k, (nm, fl, _) in enumerate(CITIES)],
                 t, A, 990, rowh=88, x_lab=60, col_x=(590, 765, 935), head_sz=40)
        E.src(cv, "World Bank WBL 2024 + national laws (caption)", A, 1488)
        notes = {3: "Travel alone from age 21 (2019). Modest dress code.", 4: "Married: husband signs her passport. Hijab is law.", 5: "Universities closed to women, Dec 2022."}
        for k, txt in notes.items():
            na = A * win(t, T.S(2 + k) + 0.2, T.S(3 + k) - 0.1, 0.3, 0.3)
            if na > 0.01: E.tag(cv, txt, 540, 260, 42, YEL, na)
    b = win(t, T.S(8) - 0.1, T.S(9) - 0.1, 0.3, 0.3)
    if b > 0.01:
        cv.rrect(60, 520, 960, 330, 32, "#0B1730", 0.95 * b, stroke=YEL, lw=3, sa=b)
        cv.text("Israel isn't perfect either", 540, 590, 56, YEL, b)
        cv.text("Divorce only via religious courts.", 540, 680, 50, WHITE, b, maxw=900)
        cv.text("A husband can refuse it.", 540, 760, 50, WHITE, b, maxw=900)
    lp = seg(t, T.S(10) - 0.2, T.S(10) + 0.3)
    if lp > 0.01: E.title(cv, "Where is a woman *free?*", 300, lp, 84)

def sfx(T):
    ev = [(T.S(1) - 0.3, "whoosh", -24)]
    for k in range(6):
        ev.append((T.S(2 + k) - 0.2, "whoosh", -28))
        for j in range(3):
            ev.append((cell_t(T, k, j), {"Y": "check", "P": "pop", "N": "buzz"}[CELLS[k][j]], -22))
    ev += [(T.S(8) - 0.2, "thud", -18), (T.S(9), "ding", -22), (T.S(10) - 0.3, "whoosh", -24)]
    return ev
PLAIN = True
