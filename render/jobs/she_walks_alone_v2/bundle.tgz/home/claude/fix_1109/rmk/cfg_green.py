"""green_200_v2: 240 million trees, same land. Map + forest counter with a running year, Twain loop."""
import math
HOOK = "*240 million* trees.|Same land."; HOOK_Y = 930
STYLE = "globe_unpeel"; CAM0 = (35.0, 31.45, 4.6)
TAIL = 1.3; BED = "cinematic"; TEMPO = 1.0; GAPS = {0: 0.7, 1: 0.6, 2: 0.55, 3: 0.4, 4: 0.4, 5: 0.4, 6: 0.75, 7: 0.6, 8: 0.7, 9: 0.6}
FORESTS = [("Ben Shemen", 34.96, 31.94, 1.0, 1908), ("Hulda", 34.88, 31.83, 0.6, 1908), ("Yatir", 35.05, 31.36, 1.5, 1964),
           ("Lahav", 34.86, 31.38, 1.1, 1952), ("Biriya", 35.50, 32.98, 1.2, 1949), ("Carmel", 35.03, 32.72, 1.1, 1920),
           ("Menashe", 35.06, 32.58, 0.9, 1950), ("Gilboa", 35.42, 32.49, 0.8, 1950), ("Jerusalem hills", 35.05, 31.77, 1.3, 1949),
           ("Segev", 35.23, 32.88, 0.8, 1950), ("Ammiad", 35.53, 32.92, 0.7, 1950), ("Kissufim", 34.42, 31.33, 0.7, 1960),
           ("Hanita", 35.17, 33.07, 0.6, 1950), ("Eshtaol", 35.00, 31.79, 0.9, 1956), ("Beeri", 34.47, 31.42, 0.8, 1960),
           ("Ilanot", 34.92, 32.29, 0.4, 1950), ("Tel Arad", 35.12, 31.30, 0.5, 1970), ("Naftali", 35.57, 33.10, 0.7, 1955)]
STEPS = [(3, "four", 1901, 14), (4, "nineteen", 1942, 35), (5, "early", 1972, 600), (6, "twenty", 2019, 1000)]

def keys(T, cam):
    K0 = cam(*CAM0); KB = cam(35.0, 31.6, 5.2, 860)
    return [(0.0, 0.01, K0), (T.S(1) - 0.2, 1.0, KB), (T.S(7) - 0.3, 0.9, cam(34.85, 32.0, 1.6, 800)),
            (T.S(8) - 0.3, 0.9, cam(35.0, 31.8, 1.4, 800)), (T.S(9) - 0.3, 1.0, KB), (T.S(10) - 0.3, 1.0, K0)]

def prog(T, t):
    pts = [T.WT(li, w) for li, w, _, _ in STEPS]
    if t < pts[0]: return None
    for k in range(len(pts) - 1):
        if t < pts[k + 1]: return k, min(1, max(0, (t - pts[k]) / (pts[k + 1] - pts[k])))
    return len(pts) - 2, 1.0

def year_at(T, t):
    if t < T.S(2): return 1867
    p = prog(T, t)
    if p is None: return 1901
    k, u = p; return STEPS[k][2] + (STEPS[k + 1][2] - STEPS[k][2]) * u

def km_at(T, t):
    p = prog(T, t)
    if p is None: return 0
    k, u = p; return STEPS[k][3] + (STEPS[k + 1][3] - STEPS[k][3]) * u

def draw(E, X, cv, T, t):
    from rlib import seg, win, YEL, WHITE, GREEN, RED
    y = year_at(T, t); grow_on = t >= T.S(3) - 0.2
    # forest blobs grow with the year (approximate positions)
    for nm, lo, la, wgt, y0 in FORESTS:
        if not grow_on or y < y0 - 3: continue
        g = min(1, (y - y0 + 3) / 25.0); x, yy = X.geo(lo, la); r = (10 + 26 * wgt) * g * min(1.4, (math.exp(X.cam[2]) / 230) ** 0.8)
        cv.circ(x, yy, r * 1.25, "#0F5A2E", 0.55); cv.circ(x, yy, r, "#2FBF63", 0.85)
    A = win(t, T.S(1) - 0.1, T.S(10) - 0.2, 0.3, 0.4)
    if A > 0.01: cv.text(f"{int(round(y))}", 540, 300, 120, YEL, A)
    q = win(t, T.S(1) - 0.1, T.S(2) - 0.1, 0.3, 0.3)
    if q > 0.01:
        E.panel(cv, 70, 1080, 940, 380, q)
        E.title(cv, "\"A *desolate* country\"", 1190, q, 92)
        cv.text("Mark Twain, The Innocents Abroad (1869), ch. 56", 540, 1340, 40, "#C9D6EA", q, maxw=880)
    k = win(t, T.S(2) - 0.1, T.S(3) - 0.1, 0.3, 0.3)
    if k > 0.01:
        E.panel(cv, 110, 1080, 860, 360, k)
        cv.text("KKL-JNF founded", 540, 1190, 72, WHITE, k); cv.text("to buy land and plant it", 540, 1290, 50, "#C9D6EA", k)
        E.src(cv, "Jewish National Fund (KKL-JNF), founded 1901", k, 1488)
    c = win(t, T.S(3) - 0.1, T.S(7) - 0.1, 0.3, 0.3)
    if c > 0.01:
        E.panel(cv, 110, 1110, 860, 330, c)
        cv.text(f"{int(round(km_at(T, t))):,}" + ("+" if t >= T.WT(6, "twenty") else ""), 540, 1230, 150, "#7CF0A5", c)
        cv.text("km² of planted forest", 540, 1365, 52, WHITE, c)
        E.src(cv, "KKL-JNF Forestry Facts and Figures, 2025. Forest positions approximate.", c, 1488)
    o = win(t, T.S(7) - 0.1, T.S(8) - 0.1, 0.3, 0.3)
    if o > 0.01:
        x, yy = X.geo(34.76, 32.05); E.emo(cv, "\U0001F34A", x, yy, 90, o); E.tag(cv, "Jaffa", x, yy + 75, 44, WHITE, o)
        E.panel(cv, 90, 1130, 900, 300, o)
        cv.text("Orange groves:", 540, 1220, 60, WHITE, o); cv.text("Arab and Jewish growers", 540, 1320, 56, YEL, o)
        E.src(cv, "Jaffa orange history; 1930s citrus boom (Mandate statistics)", o, 1488)
    b = win(t, T.S(8) - 0.1, T.S(9) - 0.1, 0.3, 0.3)
    if b > 0.01:
        x, yy = X.geo(35.0, 31.84); E.pin(cv, x, yy, RED, b, t); E.tag(cv, "Canada Park", x, yy - 60, 44, WHITE, b)
        E.panel(cv, 70, 1100, 940, 340, b, stroke=RED)
        cv.text("Not spotless:", 540, 1180, 58, YEL, b)
        cv.text("forests on Arab villages", 540, 1265, 54, WHITE, b); cv.text("emptied in 1948 and 1967", 540, 1345, 54, WHITE, b)
        E.src(cv, "Canada Park: Imwas, Yalu, Beit Nuba (1967). Haaretz; Zochrot", b, 1488)
    p = win(t, T.S(9) - 0.1, T.S(10) - 0.1, 0.3, 0.3)
    if p > 0.01:
        E.panel(cv, 90, 1110, 900, 330, p)
        cv.text(f"{int(E.roll(t, T.S(9) + 0.3, 1000, 240000000, 1.8)):,}", 540, 1230, 110, "#7CF0A5", p, maxw=860)
        cv.text("trees planted, KKL-JNF says", 540, 1360, 50, WHITE, p)
        E.src(cv, "KKL-JNF: more than 240 million trees", p, 1488)
    lp = seg(t, T.S(10) - 0.2, T.S(10) + 0.3)
    if lp > 0.01: E.title(cv, "Now count *the trees.*", 1300, lp, 86)

def sfx(T):
    ev = [(T.S(1) - 0.3, "whoosh", -24), (T.S(2) - 0.2, "pop", -20)]
    for li, w, *_ in STEPS: ev += [(T.WT(li, w), "pop", -22), (T.WT(li, w), "roll", T.WT(li, w) + 0.9)]
    ev += [(T.S(7) - 0.3, "whoosh", -26), (T.S(8) - 0.2, "thud", -18), (T.S(9) + 0.3, "roll", T.S(9) + 2.1), (T.S(9) + 2.1, "ding", -22), (T.S(10) - 0.3, "whoosh", -24)]
    return ev
PLAIN = True
