"""finalize.py <name> <card_id> [--skip-wrap]: opener in front (op_wrap), publish through a cloud copy job (repo commit + 540p + cloud ASR),
ASR score vs tts.txt, frame checks (0, 1, 3 s, last), preview to /home/claude/lm_prev/pending/<card>_540.mp4."""
import sys, os, json, subprocess, importlib, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
name, card = sys.argv[1], sys.argv[2]
C = importlib.import_module(f"cfg_{name}"); W_ = f"{HERE}/{name}/work"
def run(c, **k): print("+", " ".join(c)[:200], flush=True); return subprocess.run(c, check=True, **k)
def dur(p): return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout)
final = f"{W_}/{card}.mp4"
if "--skip-wrap" not in sys.argv:
    lon, lat, wd = C.CAM0
    run([sys.executable, f"{HERE}/op_wrap_p.py", "--reel", f"{W_}/body.mp4", "--style", C.STYLE, "--cam", f"{lon},{lat},{wd},960",
         "--hook", C.HOOK, "--hook-y", str(C.HOOK_Y), "--out", final] + (["--plain"] if getattr(C, "PLAIN", False) else []))
print("final", final, round(dur(final), 2))
# frames 0, 1, 3, last
d = dur(final); fr = []
for t in (0.0, 1.0, 3.0, d - 0.05):
    p = f"{W_}/chk_{t:05.2f}.png"; run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", final, "-frames:v", "1", "-vf", "scale=360:-1", p]); fr.append(p)
run(["ffmpeg", "-v", "error", "-y", *sum([["-i", p] for p in fr], []), "-filter_complex", "hstack=4", f"{W_}/chk.png"])
if "--no-publish" in sys.argv: sys.exit()
# publish: a cloud job that only copies the file (GitHub commits <card>.mp4 + render/out/<card>_540.mp4 and runs ASR)
sys.path.insert(0, "/home/claude/reelkit"); import cloud_render as CR
_c = CR.collect
_g = CR.git
def _git(*a, check=True):
    import time
    if a[:1] == ("pull",): a = ("-c", "gc.auto=0", "pull", "-q", "--rebase", "--autostash", "origin", "main")
    elif a[:1] == ("push",) or a[:1] == ("commit",): a = ("-c", "gc.auto=0") + a
    for k in range(6):
        r = subprocess.run(["git", "-C", CR.REPO, *a], capture_output=True, text=True)
        if r.returncode == 0 or not check: return r
        time.sleep(5)
    raise subprocess.CalledProcessError(r.returncode, a, r.stdout, r.stderr)
CR.git = _git
CR.collect = lambda e, a: [final]
CR.send([dict(id=card, cmd=f"mkdir -p {W_} && ls -la {final}", out=final, entry=[], add=[final])])
run([sys.executable, "/home/claude/reelkit/cloud_render.py", "wait", card, "--timeout", "1500"])
r = subprocess.run([sys.executable, "/home/claude/reelkit/cloud_asr.py", card, "--script", f"{HERE}/{name}/tts.txt"], capture_output=True, text=True)
open(f"{W_}/asr.txt", "w").write(r.stdout); print(r.stdout[-2500:])
os.makedirs("/home/claude/lm_prev/pending", exist_ok=True)
shutil.copy(f"/home/claude/reels-drop/render/out/{card}_540.mp4", f"/home/claude/lm_prev/pending/{card}_540.mp4")
lufs = subprocess.run(["ffmpeg", "-nostats", "-i", final, "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
print("LUFS", [l for l in lufs.splitlines() if l.strip().startswith("I:")][-1], "dur", round(d, 2))
