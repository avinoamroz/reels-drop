import json,sys,os
n=sys.argv[1]; L=[l.strip() for l in open(f'{n}/tts.txt') if l.strip()]; t=0.25; out=[]
os.makedirs(f'{n}/work',exist_ok=True)
for i,l in enumerate(L):
    ws=[];
    for w in l.split(): ws.append(dict(w=w,t0=round(t,3),t1=round(t+0.36,3))); t+=0.385
    out.append(dict(i=i,text=l,t0=ws[0]['t0'],t1=ws[-1]['t1'],words=ws)); t+=0.4
json.dump(dict(dur=t,lines=out),open(f'{n}/work/timing.json','w'))
print(n, round(t,1))
