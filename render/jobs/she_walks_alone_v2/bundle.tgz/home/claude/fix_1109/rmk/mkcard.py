"""mkcard.py <name>: payload (posting/queue/gh/<card>.json) + Launch Map card JSON (<name>/work/card.json) + captions doc JSON."""
import sys, json, re, subprocess
name = sys.argv[1]; HERE = "/home/claude/fix_1109/rmk"
M = json.load(open(f"{HERE}/cards.json"))[name]
card = M["id"]; U = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
cap = open(f"{HERE}/cap/{name}.txt").read().strip()
assert len(cap) < 2200 and not re.search("[‒-―]", cap) and not re.search("in my view|to be fair", cap, re.I)
assert 3 <= len(re.findall(r"#\w+", cap)) <= 5
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f"{HERE}/{name}/work/{card}.mp4"], capture_output=True, text=True).stdout)
asr = open(f"{HERE}/{name}/work/asr.txt").read()
m = re.search(r"overall\s+([\d.]+)", asr); score = float(m.group(1)) if m else None
body = dict(media_type="REELS", video_url=U + card + ".mp4", caption=cap, share_to_feed=True, is_ai_generated=True, trial_params=dict(graduation_strategy="SS_PERFORMANCE"))
json.dump(dict(action="init", account="noam", tag=card + "-gh", body=json.dumps(body, ensure_ascii=False)), open(f"/home/claude/posting/queue/gh/{card}.json", "w"), ensure_ascii=False, indent=1)
d = dict(account="noamroz__", kind="remake", parent=M["parent"], lang="en", status="check", dayLabel="To review", time="TBD", slotted=False, ai=True,
         addedAt=M["addedAt"], title=M["title"], note=M["note"].replace("{DUR}", f"{dur:.1f}").replace("{ASR}", f"{score:.2f}" if score else "n/a"),
         videoUrl=U + card + ".mp4", src=U + card + ".mp4", link=U + card + ".mp4", previewRaw=U + f"render/out/{card}_540.mp4",
         previewPending=f"/home/claude/lm_prev/pending/{card}_540.mp4", payload=card, runtime=round(dur, 1),
         predViews=M["predViews"], predWhy=M["predWhy"], caption=cap, hook=M["hook"], opener=M["opener"])
json.dump(d, open(f"{HERE}/{name}/work/card.json", "w"), ensure_ascii=False)
json.dump(dict(caption=cap, video=U + card + ".mp4", payload=card), open(f"{HERE}/{name}/work/capdoc.json", "w"), ensure_ascii=False)
print(card, round(dur, 1), "asr", score, "caption", len(cap))
