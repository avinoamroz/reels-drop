"""terror_compare_v2: Jewish terror vs HAMAS and other armed groups, map + counters + live scorecard."""
import random
HOOK = "*147* suicide bombings.|Jewish ones: *0*"; HOOK_Y = 930
STYLE = "map_tear_v2"; CAM0 = (35.05, 31.6, 5.0)
BED = "doc_piano"; GAPS = {0: 0.5, 1: 0.35, 2: 0.4, 4: 0.55, 6: 0.4, 7: 0.5, 8: 0.5, 9: 0.45}
SUBS = {"U.S.": "US", "U.N.": "UN"}
HEB = (35.11, 31.525)
random.seed(4)
WB = [(random.uniform(35.05, 35.45), random.uniform(31.45, 32.45)) for _ in range(90)]

def keys(T, cam):
    K0 = cam(*CAM0); KH = cam(35.1, 31.55, 2.2, 700); KI = cam(35.0, 31.7, 6.5, 560); KW = cam(35.25, 31.95, 2.6, 640)
    return [(0.0, 0.01, K0), (T.S(2) - 0.3, 1.2, KH), (T.S(5) - 0.4, 1.1, KI), (T.S(8) - 0.4, 1.0, KW), (T.S(10) - 0.4, 1.1, K0)]

def dim(T, t):
    from rlib import seg
    return 0.6 * seg(t, T.S(3) - 0.3, T.S(3) + 0.2) * (1 - seg(t, T.S(5) - 0.4, T.S(5))) + seg(t, T.S(7) - 0.3, T.S(7)) * (1 - seg(t, T.S(8) - 0.4, T.S(8))) \
        + seg(t, T.S(9) - 0.3, T.S(9)) * (1 - seg(t, T.S(10) - 0.4, T.S(10)))

def pill(cv, txt, x, y, col, a, sc=1.0):
    if a <= 0.01: return
    w = cv.tw(txt, 50) + 46
    cv.c.save(); cv.c.translate(x, y); cv.c.scale(sc, sc); cv.rrect(-w / 2, -40, w, 80, 24, col, a); cv.text(txt, 0, 0, 50, "#FFFFFF", a, shadow=False); cv.c.restore()

def draw(E, X, cv, T, t):
    from rlib import seg, win, YEL, WHITE, RED, GREEN, GREY
    A1 = win(t, T.S(1) - 0.1, T.S(5) - 0.2, 0.35, 0.4)
    if A1 > 0.01: E.title(cv, "Jewish terror is *real.*", 300, A1, 84)
    a2 = win(t, T.S(2) - 0.1, T.S(3) - 0.1, 0.3, 0.3)
    if a2 > 0.01:
        x, y = X.geo(*HEB); E.pin(cv, x, y, RED, a2, t); E.tag(cv, "Hebron, 1994", x, y - 60, 46, WHITE, a2)
        ka = a2 * seg(t, T.WT(2, "twenty") - 0.1, T.WT(2, "twenty") + 0.2)
        E.panel(cv, 140, 1050, 800, 380, ka)
        cv.text(f"{int(E.roll(t, T.WT(2, 'twenty'), 0, 29, 0.8))}", 540, 1180, 190, YEL, ka)
        cv.text("killed at prayer", 540, 1330, 64, WHITE, ka)
        E.src(cv, "Shamgar Commission report, 1994", a2, 1490)
    a3 = win(t, T.S(3) - 0.1, T.S(5) - 0.2, 0.35, 0.4)
    if a3 > 0.01:
        E.panel(cv, 50, 520, 980, 760, a3)
        cv.text("Israel's answer", 540, 600, 66, "#C9D6EA", a3)
        rows = [("PM: \"a shame on Zionism\"", T.WT(3, "shame")), ("Kach movement banned", T.WT(4, "banned")), ("Killer's shrine bulldozed", T.WT(4, "bulldozed"))]
        for k, (lab, at_) in enumerate(rows):
            ra = a3 * seg(t, at_ - 0.15, at_ + 0.15); y = 760 + k * 170
            if ra > 0.01:
                E.mark(cv, "Y", 140, y, 42, ra, E.pop_s(t, at_)); cv.text(lab, 210, y, 64, WHITE, ra, align="l", maxw=780)
        E.src(cv, "Knesset 1994; Kach ban 1994; shrine razed 1999", a3, 1490)
    a4 = win(t, T.S(5) - 0.1, T.S(7) - 0.1, 0.35, 0.4)
    if a4 > 0.01:
        E.title(cv, "Other side: *2000 to 2005*", 300, a4, 80)
        ta = T.WT(6, "hundred") - 0.1; n = int(E.roll(t, ta, 0, 147, 1.6)) if t > ta else 0
        E.panel(cv, 60, 930, 960, 560, a4 * seg(t, ta - 0.2, ta))
        for i in range(147):
            if i < n:
                cx = 130 + (i % 21) * 41; cy = 1000 + (i // 21) * 41; cv.circ(cx, cy, 15, RED, a4)
        if t > ta:
            cv.text(f"{n}", 300, 1370, 120, YEL, a4); cv.text("suicide bombings", 300, 1450, 48, WHITE, a4, maxw=420)
        da = a4 * seg(t, T.WT(6, "over") - 0.1, T.WT(6, "over") + 0.2)
        cv.text("500+", 770, 1370, 120, YEL, da); cv.text("killed", 770, 1450, 48, WHITE, da)
        E.src(cv, "Sep 2000 to 2005. Source: ITIC, Jan 2006", a4, 1530)
    a5 = win(t, T.S(7) - 0.1, T.S(8) - 0.1, 0.3, 0.35)
    if a5 > 0.01:
        E.panel(cv, 50, 520, 980, 760, a5)
        cv.text("Their answer", 540, 600, 66, "#C9D6EA", a5)
        rows = [("Squares named after attackers", T.WT(7, "squares")), ("Payments to attackers' families", T.WT(7, "payments"))]
        for k, (lab, at_) in enumerate(rows):
            ra = a5 * seg(t, at_ - 0.15, at_ + 0.15); y = 800 + k * 220
            if ra > 0.01: E.emo(cv, "\U0001F3C5" if k == 0 else "\U0001F4B5", 150, y, 76, ra); cv.text(lab, 230, y, 64, WHITE, ra, align="l", maxw=760)
        E.src(cv, "UN statement May 2017; US State Dept, Apr 2026", a5, 1490)
    a6 = win(t, T.S(8) - 0.1, T.S(9) - 0.1, 0.3, 0.35)
    if a6 > 0.01:
        E.title(cv, "Settler violence is *real too*", 300, a6, 76)
        ta = T.WT(8, "over"); n = int(E.roll(t, ta, 0, 1449, 1.4)) if t > ta else 0
        for i, (lo, la) in enumerate(WB):
            if i < n / 1449 * len(WB): x, y = X.geo(lo, la); cv.circ(x, y, 9, RED, 0.9 * a6)
        E.panel(cv, 140, 1150, 800, 300, a6 * seg(t, ta - 0.2, ta))
        if t > ta: cv.text(f"{n:,}", 540, 1260, 130, YEL, a6); cv.text("settler attacks, 2024", 540, 1385, 50, WHITE, a6)
        E.src(cv, "UN OCHA 2024. Dots illustrative.", a6, 1500)
    a7 = win(t, T.S(9) - 0.1, T.S(10) - 0.15, 0.3, 0.35)
    if a7 > 0.01:
        E.panel(cv, 40, 470, 1000, 820, a7)
        cv.text("Jewish", 640, 560, 44, "#C9D6EA", a7, maxw=200); cv.text("terror", 640, 610, 44, "#C9D6EA", a7, maxw=200)
        cv.text("HAMAS &", 880, 560, 44, "#C9D6EA", a7, maxw=240); cv.text("armed groups", 880, 610, 40, "#C9D6EA", a7, maxw=240)
        rows = [("Killers banned", ("Yes", GREEN), ("No", RED), T.WT(9, "bans")), ("Killers honored", ("No", GREEN), ("Yes", RED), T.WT(9, "names"))]
        for k, (lab, c1, c2, at_) in enumerate(rows):
            y = 780 + k * 220; ra = a7 * seg(t, at_ - 0.2, at_ + 0.1)
            if ra > 0.01:
                cv.text(lab, 90, y, 64, WHITE, ra, align="l", maxw=440)
                pill(cv, c1[0], 640, y, c1[1], ra, E.pop_s(t, at_)); pill(cv, c2[0], 880, y, c2[1], ra, E.pop_s(t, at_ + 0.25))
        E.src(cv, "Sources in the caption", a7, 1490)
    lp = seg(t, T.S(10) - 0.2, T.S(10) + 0.3)
    if lp > 0.01: E.title(cv, "Both sides are *the same?*", 300, lp, 80)

def sfx(T):
    return [(T.S(2) - 0.3, "whoosh", -24), (T.WT(2, "twenty"), "roll", T.WT(2, "twenty") + 0.8), (T.WT(3, "shame"), "check", -20),
            (T.WT(4, "banned"), "check", -20), (T.WT(4, "bulldozed"), "check", -20), (T.S(5) - 0.3, "whoosh", -24),
            (T.WT(6, "hundred"), "roll", T.WT(6, "hundred") + 1.6), (T.WT(6, "over"), "thud", -16), (T.S(7) - 0.2, "whoosh", -26),
            (T.WT(7, "squares"), "pop", -20), (T.WT(7, "payments"), "pop", -20), (T.S(8) - 0.3, "whoosh", -24),
            (T.WT(8, "over"), "roll", T.WT(8, "over") + 1.4), (T.WT(9, "bans"), "pop", -18), (T.WT(9, "names"), "buzz", -22), (T.S(10) - 0.3, "whoosh", -24)]
PLAIN = True
