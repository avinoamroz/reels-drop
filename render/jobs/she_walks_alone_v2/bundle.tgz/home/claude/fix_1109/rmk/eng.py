"""eng.py (9 Nov 2026): shared engine for the batch C remakes (@noamroz__).
A reel = cfg module (cfg_<name>.py) + voice (reels-drop/voice/rmk1109_<name>.wav + _words.json).

  python3 eng.py <name> voice            -> <name>/work/vo.wav + timing.json   (house voice chain, line gaps from cfg.GAPS)
  python3 eng.py <name> mix              -> <name>/work/mix.m4a                (bed at -16 LUFS ducked 9 dB under speech + SFX, -14 LUFS)
  python3 eng.py <name> snaps 0,3,10     -> <name>/work/snap_*.png             (body frames, reel time)
  python3 eng.py <name> render [OUT]     -> silent body + mix muxed            (frames in parallel)
The opener (map_open.py style via op_wrap.py) goes in front afterwards: its zoom lands on cfg.CAM0 and the narration
starts on the zoom. Map: whole land of Israel gold, West Bank and Gaza a darker gold with the Green Line in green (rlib.MapR)."""
import sys, os, math, json, re, subprocess, importlib
import numpy as np, cv2
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from rlib import *
sys.path.insert(0, "/home/claude/map_tear_opener"); import hook as hk_

NAME = sys.argv[1]; D = f"{HERE}/{NAME}"; os.makedirs(f"{D}/work", exist_ok=True)
C = importlib.import_module(f"cfg_{NAME}")
TJ_P = f"{D}/work/timing.json"

# ------------------------------------------------------------------ timing helpers (cfg uses these through E)
class Tm:
    def __init__(s, tj): s.L = tj["lines"]
    def S(s, i): return s.L[i]["t0"]
    def E(s, i): return s.L[i]["t1"]
    def WT(s, i, word, end=False, n=1):
        k = 0
        for w in s.L[i]["words"]:
            if re.sub(r"[^\w]", "", w["w"]).lower().startswith(word.lower()):
                k += 1
                if k == n: return w["t1" if end else "t0"]
        raise KeyError((i, word))
    @property
    def END(s): return round(s.L[-1]["t1"] + getattr(C, "TAIL", 0.75), 2)

def cam(lon, lat, wd, sy=960.0):
    """camera as (lon, lat, log k, cosf, sy); wd = visible width in degrees (same numbers as map_open --cam), sy = screen y of (lon, lat)"""
    cosf = max(0.6, math.cos(math.radians(min(62, abs(lat))))); return np.array([lon, lat, math.log(W / (wd * cosf)), cosf, sy], float)

# ------------------------------------------------------------------ voice
def build_voice():
    sys.path.insert(0, "/home/claude/reelkit"); import voice, soundfile as sf
    from clean_vo import clean as clean_vo
    RD = "/home/claude/fix_1109/rmk/voice"; SR = voice.SR
    LINES = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
    voice.TEMPO = getattr(C, "TEMPO", 1.1)
    raw = f"{RD}/rmk1109_{NAME}.wav"; dry = voice.chain_dry(raw)
    cl = clean_vo(dry, SR); y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); vo = voice.post(y)
    k = (len(vo) / SR - voice.LEAD) / (len(dry) / SR)
    Wd = json.load(open(f"{RD}/rmk1109_{NAME}_words.json"))
    words = [dict(w=w["word"], t0=voice.LEAD + w["start"] * k, t1=voice.LEAD + w["end"] * k) for w in Wd]
    tot = sum(len(l.split()) for l in LINES); print("tokens script", tot, "tts", len(words))
    assert tot == len(words), "token mismatch"
    segs = []; out = []; idx = 0; t = 0.2
    for i, text in enumerate(LINES):
        n = len(text.split()); ws = words[idx:idx + n]; idx += n
        a, b = ws[0]["t0"] - 0.05, ws[-1]["t1"] + 0.10
        seg = vo[int(a * SR):int(b * SR)].copy(); f = int(0.01 * SR); seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        segs.append((t, seg))
        out.append(dict(i=i, text=text, t0=round(t + 0.05, 3), t1=round(t + (b - a) - 0.10, 3),
                        words=[dict(w=w["w"], t0=round(t + w["t0"] - a, 3), t1=round(t + w["t1"] - a, 3)) for w in ws]))
        t += len(seg) / SR + C.GAPS.get(i, 0.3)
    yy = np.zeros(int(t * SR) + SR)
    for t0, s_ in segs: yy[int(t0 * SR):int(t0 * SR) + len(s_)] += s_
    sf.write(f"{D}/work/vo.wav", yy[:int(t * SR)].astype(np.float32), SR)
    json.dump(dict(dur=t, lines=out), open(TJ_P, "w"), indent=0)
    for o in out: print(o["i"], o["t0"], o["t1"], o["text"][:60])
    print("voice end", round(out[-1]["t1"], 2))

# ------------------------------------------------------------------ audio
SR = 48000
def build_mix():
    import soundfile as sf
    sys.path.insert(0, "/home/claude/rehook"); import rk
    sys.path.insert(0, "/home/claude/reelkit"); import mix as MX
    Tq = Tm(json.load(open(TJ_P))); T = Tq.END; n = int(T * SR)
    vo, sr = sf.read(f"{D}/work/vo.wav")
    if sr != SR: vo = np.interp(np.arange(int(len(vo) * SR / sr)) * sr / SR, np.arange(len(vo)), vo)
    vo = np.pad(vo, (0, max(0, n - len(vo))))[:n]
    bed = MX.bed(getattr(C, "BED", "cinematic"), T + 0.6, T - 1.0)[:, :n]
    def lufs(x):
        o = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", "ebur128", "-f", "null", "-"],
                           input=x.T.astype(np.float32).tobytes(), capture_output=True).stderr.decode()
        return float(o[o.rfind("I:"):].split()[1])
    bed *= 10 ** ((getattr(C, "BED_LUFS", -16) - lufs(bed)) / 20); bed_lufs = lufs(bed)
    m = np.zeros(n)
    for l in Tq.L: m[max(0, int((l["t0"] - 0.08) * SR)):int((l["t1"] + 0.12) * SR)] = 1
    k = int(0.12 * SR); m = np.convolve(m, np.ones(k) / k, "same"); bed *= (10 ** (-9 * m / 20))[None]
    fo = int(0.25 * SR); bed[:, -fo:] *= np.linspace(1, 0.3, fo)[None]
    sfx = np.zeros(n); rng = np.random.default_rng(3); tt = lambda d: np.arange(int(d * SR)) / SR
    def put(t, y, db):
        i = int(t * SR); j = min(n, i + len(y))
        if 0 <= i < n: sfx[i:j] += y[:j - i] * 10 ** (db / 20)
    def tick(): x = tt(0.03); return np.sin(2 * np.pi * 1800 * x) * np.exp(-x * 220)
    def pop(): x = tt(0.14); return np.sin(2 * np.pi * (500 + 900 * x * 6) * x) * np.exp(-x * 30)
    def whoosh(d=0.6, f0=300, f1=2400):
        x = tt(d); ph = 2 * np.pi * np.cumsum(f0 + (f1 - f0) * (x / d) ** 2) / SR
        return (rng.standard_normal(len(x)) * 0.35 + np.sin(ph) * 0.2) * np.sin(np.pi * x / d) ** 1.5
    def thud(): x = tt(0.35); y = np.sin(2 * np.pi * 70 * x) * np.exp(-x * 16); return y / np.abs(y).max()
    def ding(): x = tt(0.6); return (np.sin(2 * np.pi * 1320 * x) + 0.5 * np.sin(2 * np.pi * 1980 * x)) * np.exp(-x * 7)
    def buzz(): x = tt(0.25); return np.sign(np.sin(2 * np.pi * 110 * x)) * 0.5 * np.exp(-x * 9)
    def check(): x = tt(0.18); return np.sin(2 * np.pi * (880 + 600 * x / 0.18) * x) * np.exp(-x * 18)
    K = dict(tick=tick, pop=pop, whoosh=lambda: whoosh(), thud=thud, ding=ding, buzz=buzz, check=check)
    for ev in C.sfx(Tq):
        if ev[1] == "roll":
            for t in np.arange(ev[0], ev[2], 0.045): put(t, tick(), -30)
        else: put(ev[0], K[ev[1]](), ev[2] if len(ev) > 2 else -24)
    x = np.stack([vo, vo]) + bed + np.stack([sfx, sfx])
    J = rk.finish_audio(x, f"{D}/work/mix.m4a")
    json.dump(dict(T_END=T, bed_lufs=bed_lufs, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1, default=str)
    print("audio", T, "bed LUFS", round(bed_lufs, 1), J.get("final_I"), J.get("final_TP"))

# ------------------------------------------------------------------ widgets (cfg draw() calls these)
def title(cv, txt, y, a=1.0, sz=80, col=WHITE, maxw=980):
    """*word* in yellow; wraps to 2 lines"""
    if a <= 0.01: return
    words = txt.split(); lines = [[]]
    for w in words:
        test = " ".join(x.replace("*", "") for x in lines[-1] + [w])
        if lines[-1] and cv.tw(test, sz) > maxw: lines.append([w])
        else: lines[-1].append(w)
    if len(lines) > 2: sz = int(sz * 0.86); return title(cv, txt, y, a, sz, col, maxw) if sz > 60 else None
    lh = sz * 1.18; y0 = y - lh * (len(lines) - 1) / 2
    for li, ln in enumerate(lines):
        parts = []; hl = False
        for w in ln:
            on = w.startswith("*"); off = w.rstrip(".,!?:;").endswith("*")
            ww = w.replace("*", "")
            parts.append((ww + " ", YEL if (on or hl) else col)); hl = (hl or on) and not off
        parts[-1] = (parts[-1][0].rstrip(), parts[-1][1])
        cv.rich(parts, 540, y0 + li * lh, sz, a, maxw)
def panel(cv, x, y, w, h, a=1.0, stroke=SKY):
    cv.rrect(x, y, w, h, 34, "#0B1A3C", 0.84 * a, stroke=stroke, lw=2.5, sa=0.55 * a)
def fmtn(v, dec=0, prefix="", suffix=""):
    s = f"{v:,.{dec}f}"; return f"{prefix}{s}{suffix}"
def counter(cv, v, cx, cy, sz=180, a=1.0, dec=0, prefix="", suffix="", col=YEL):
    cv.text(fmtn(v, dec, prefix, suffix), cx, cy, sz, col, a, maxw=1000)
def roll(t, t0, v0, v1, d=1.0):
    """count from v0 to v1 starting at t0 (log-eased for big jumps)"""
    u = eout((t - t0) / d)
    if u >= 0.999: return v1
    if v1 > 10 * max(v0, 1): return math.exp(math.log(max(v0, 1)) + (math.log(v1) - math.log(max(v0, 1))) * u) if u > 0 else v0
    return v0 + (v1 - v0) * u
def src(cv, txt, a=1.0, y=1488):
    if a <= 0.01: return
    if cv.tw(txt, 38, False) <= 960: cv.text(txt, 540, y, 38, "#C9D6EA", a, bold=False, maxw=960, shadow=True, minsz=36); return
    w = txt.split(); best = None
    for k in range(1, len(w)):
        l1, l2 = " ".join(w[:k]), " ".join(w[k:]); m = max(cv.tw(l1, 38, False), cv.tw(l2, 38, False))
        if best is None or m < best[0]: best = (m, l1, l2)
    cv.text(best[1], 540, y - 24, 38, "#C9D6EA", a, bold=False, maxw=960, shadow=True, minsz=36)
    cv.text(best[2], 540, y + 24, 38, "#C9D6EA", a, bold=False, maxw=960, shadow=True, minsz=36)
def flag(cv, code, cx, cy, sz=64, a=1.0):
    ch = "".join(chr(0x1F1E6 + ord(c) - 65) for c in code.upper())
    cv.image(emoji(ch), cx, cy, sz / 109, a)
def emo(cv, ch, cx, cy, sz=64, a=1.0): cv.image(emoji(ch), cx, cy, sz / 109, a)
def mark(cv, kind, cx, cy, r=34, a=1.0, sc=1.0):
    """Y green tick, N red cross, P amber half"""
    if a <= 0.01: return
    r *= sc; colr = {"Y": GREEN, "N": RED, "P": "#F2A93B"}[kind]
    cv.circ(cx, cy, r, colr, a)
    if kind == "Y": cv.line([(cx - r * 0.45, cy + r * 0.02), (cx - r * 0.12, cy + r * 0.36), (cx + r * 0.5, cy - r * 0.34)], "#FFFFFF", r * 0.22, a)
    elif kind == "N":
        cv.line([(cx - r * 0.38, cy - r * 0.38), (cx + r * 0.38, cy + r * 0.38)], "#FFFFFF", r * 0.22, a)
        cv.line([(cx - r * 0.38, cy + r * 0.38), (cx + r * 0.38, cy - r * 0.38)], "#FFFFFF", r * 0.22, a)
    else: cv.line([(cx - r * 0.42, cy), (cx + r * 0.42, cy)], "#FFFFFF", r * 0.24, a)
def pop_s(t, t0): return back(seg(t, t0, t0 + 0.35, lambda u: u)) if t >= t0 else 0.0
def bars(cv, rows, t, a, y0, rowh=118, vmax=None, x0=70, w=940, dec=0, suffix="", lab_w=300, grow=0.8):
    """rows: dict(label, flag|emo, value, at, color, txt); bar grows from 0 at `at`"""
    vmax = vmax or max(r["value"] for r in rows)
    for k, r in enumerate(rows):
        ra = a * seg(t, r["at"] - 0.1, r["at"] + 0.2)
        if ra <= 0.01: continue
        y = y0 + k * rowh; v = r["value"] * eout((t - r["at"]) / grow)
        ix = x0 + 40
        if r.get("flag"): flag(cv, r["flag"], ix, y, 60, ra)
        elif r.get("emo"): emo(cv, r["emo"], ix, y, 60, ra)
        cv.text(r["label"], ix + 46, y, 58, WHITE, ra, align="l", maxw=lab_w - 80)
        bx = x0 + lab_w; bw = (w - lab_w - 170) * max(0.004, v / vmax)
        cv.rrect(bx, y - 28, max(10, bw), 56, 14, r.get("color", SKY), ra)
        cv.text(r.get("txt") or fmtn(v, r.get("dec", dec), "", r.get("suffix", suffix)), bx + max(10, bw) + 16, y, 60,
                r.get("tcol", YEL), ra, align="l", maxw=300)
def checks(cv, cols, rows, t, a, y0, rowh=128, x_lab=80, col_x=(560, 720, 880), head_sz=40):
    """cols: short headers (with emoji); rows: dict(label, flag, cells=[(kind, at)], at)"""
    for j, c in enumerate(cols):
        if isinstance(c, tuple): emo(cv, c[0], col_x[j], y0 - 120, 56, a); cv.text(c[1], col_x[j], y0 - 62, head_sz, "#C9D6EA", a, bold=True, maxw=170, minsz=36)
        else: cv.text(c, col_x[j], y0 - 70, head_sz, "#C9D6EA", a, maxw=170, minsz=36)
    for k, r in enumerate(rows):
        ra = a * seg(t, r["at"] - 0.1, r["at"] + 0.2)
        if ra <= 0.01: continue
        y = y0 + k * rowh
        if r.get("hl"): cv.rrect(50, y - rowh / 2 + 8, 980, rowh - 16, 22, "#FFD23F", 0.13 * ra)
        if r.get("flag"): flag(cv, r["flag"], x_lab + 30, y, 58, ra)
        cv.text(r["label"], x_lab + 74, y, 60, WHITE, ra, align="l", maxw=col_x[0] - x_lab - 140)
        for j, (kind, at) in enumerate(r["cells"]):
            if kind and t >= at: mark(cv, kind, col_x[j], y, 36, ra, pop_s(t, at))
def pin(cv, x, y, col=YEL, a=1.0, t=0.0, r=11):
    if a <= 0.01: return
    pr = (t * 0.9) % 1.0
    cv.circ(x, y, r + 26 * pr, None, 1, stroke=col, lw=3); cv.c.new_path()
    cv.circ(x, y, r, col, a, stroke="#FFFFFF", lw=3)
def tag(cv, txt, x, y, sz=46, col=WHITE, a=1.0, bg="#0B1730"):
    if a <= 0.01: return
    w = cv.tw(txt, sz) + 34; x = min(max(x, w / 2 + 12), W - 12 - w / 2); cv.rrect(x - w / 2, y - sz * 0.75, w, sz * 1.5, 16, bg, 0.85 * a)
    cv.text(txt, x, y, sz, col, a, shadow=False, maxw=1000)

# ------------------------------------------------------------------ frames
_MR = [None]; _CACHE = {}
def mapimg(cm, hi):
    key = (tuple(np.round(cm, 4)), tuple(sorted((k, round(v, 2)) for k, v in hi.items())))
    if key in _CACHE: return _CACHE[key]
    if _MR[0] is None: _MR[0] = MapR()
    MR = _MR[0]; lon, lat, lk, cosf, sy = cm
    img, M = MR.render(MR.view(lon, lat, math.exp(lk), cosf, sy), H, hi=[k for k, v in hi.items() if v > 0.02], hi_a=hi)
    if len(_CACHE) > 16: _CACHE.clear()
    _CACHE[key] = (img, M); return img, M
def cam_at(keys, t):
    cur = keys[0][2]
    for i, (t0, d, k) in enumerate(keys):
        if t < t0: break
        prev = keys[i - 1][2] if i else k
        u = ease((t - t0) / d); cur = prev + (k - prev) * u
        if u < 1: return cur
    return cur
_VIG = None
def vignette():
    global _VIG
    if _VIG is None:
        y = np.arange(H, dtype=np.float32)[:, None]
        top = np.clip(1 - y / 520, 0, 1) ** 1.6 * 0.45; bot = np.clip((y - 1180) / 740, 0, 1) ** 1.2 * 0.62
        _VIG = (1 - np.maximum(top, bot))[..., None].astype(np.float32)
    return _VIG
class Ctx:   # what cfg.draw gets
    pass
def make_frame(Tq, keys, hook_img, chunks):
    def frame(t):
        cm = cam_at(keys, t); hi = C.hi(Tq, t) if hasattr(C, "hi") else {}
        img, M = mapimg(cm, hi); base = img.astype(np.float32) * vignette()
        dim = C.dim(Tq, t) if hasattr(C, "dim") else 0.0
        if dim > 0: base *= (1 - 0.45 * dim)
        cv = Canvas(base); X = Ctx(); X.M = M; X.cam = cm
        X.geo = lambda lon, lat: geo2px(M, lon, lat)
        C.draw(sys.modules[__name__], X, cv, Tq, t)
        # hook on frame 0 (where the opener's hook lands), fades out at the end of line 0
        ha = 1 - seg(t, Tq.E(0) + 0.15, Tq.E(0) + 0.55)
        out = cv.out().astype(np.float32)
        if ha > 0.01: out = hk_.paste(out, hook_img, 540, C.HOOK_Y, 1.0, ha)
        cv2 = Canvas(out); sub(cv2, t, chunks); return np.clip(cv2.out(), 0, 255).astype(np.uint8)
    return frame
def sub_chunks(Tq):
    rep = getattr(C, "SUBS", {})
    CH = []
    for l in Tq.L:
        cur = [];
        for w in l["words"]:
            cur.append(w)
            if len(cur) >= 6 or re.search(r"[.,?!:;]$", w["w"]) and len(cur) >= 2:
                CH.append([" ".join(x["w"] for x in cur), cur[0]["t0"], cur[-1]["t1"]]); cur = []
        if cur: CH.append([" ".join(x["w"] for x in cur), cur[0]["t0"], cur[-1]["t1"]])
    for c in CH:
        c[0] = re.sub(r"[\"“”]", "", c[0]).rstrip(",;:")
        for a, b in rep.items(): c[0] = c[0].replace(a, b)
    for j in range(len(CH) - 1):
        CH[j][2] = min(CH[j + 1][1] - 0.02, CH[j][2] + 0.5) if CH[j + 1][1] - CH[j][2] < 0.5 else CH[j][2] + 0.25
    CH[-1][2] += 0.4
    return CH
def sub(cv, t, CH):
    if t < getattr(C, "SUB_FROM", 0.0): return
    for txt, a, b in CH:
        if a - 0.05 <= t <= b:
            al = min(1, (t - (a - 0.05)) / 0.1) * min(1, (b - t) / 0.1 + 0.0001)
            sz = 58; w = min(1000, cv.tw(txt, sz) + 56)
            cv.rrect(540 - w / 2, 1612 - 48, w, 96, 28, "#0B1730", 0.80 * al, stroke=YEL, lw=2, sa=0.5 * al)
            cv.text(txt, 540, 1612, sz, WHITE, al, maxw=960, shadow=False)
            return

def setup():
    Tq = Tm(json.load(open(TJ_P))); keys = C.keys(Tq, cam)
    return Tq, keys, hk_.make(C.HOOK), sub_chunks(Tq)
_F = [None]
def _init():
    Tq, keys, hi, ch = setup(); _F[0] = make_frame(Tq, keys, hi, ch)
def _one(i): return _F[0](i / FPS).tobytes()

if __name__ == "__main__":
    act = sys.argv[2]
    if act == "voice": build_voice()
    elif act == "mix": build_mix()
    elif act == "snaps":
        Tq, keys, hi, ch = setup(); fr = make_frame(Tq, keys, hi, ch); tiles = []
        ts = [float(x) for x in sys.argv[3].split(",")]
        for s_ in ts: tiles.append(cv2.resize(fr(s_), (360, 640), interpolation=cv2.INTER_AREA))
        while len(tiles) % 5: tiles.append(np.zeros_like(tiles[0]))
        rows = [np.hstack(tiles[i:i + 5]) for i in range(0, len(tiles), 5)]
        cv2.imwrite(f"{D}/work/sheet.png", np.vstack(rows)); print("sheet", f"{D}/work/sheet.png", "min font", MINSZ[0], "T_END", Tq.END)
    elif act == "render":
        out = sys.argv[3] if len(sys.argv) > 3 else f"{D}/work/body.mp4"
        Tq = Tm(json.load(open(TJ_P))); nfr = int(round(Tq.END * FPS)); sil = f"{D}/work/silent.mp4"
        import multiprocessing as mp
        pr = subprocess.Popen(["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", sil], stdin=subprocess.PIPE)
        with mp.Pool(os.cpu_count(), initializer=_init) as P:
            for i, b in enumerate(P.imap(_one, range(nfr), chunksize=8)):
                pr.stdin.write(b)
                if i % 300 == 0: print(i, nfr, flush=True)
        pr.stdin.close(); assert pr.wait() == 0
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", sil, "-i", f"{D}/work/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "copy",
                        "-shortest", "-movflags", "+faststart", out], check=True)
        print("done", out)
