"""colonize_olympics_v7: the Colonization Olympics as a data race (share of the world's land at each empire's peak), then 50 inventions."""
HOOK = "Colonization Olympics.|Israel: *0.02%*"; HOOK_Y = 930
STYLE = "map_crumple"; CAM0 = (30.0, 38.0, 75.0)
BED = "playful"; GAPS = {0: 0.45, 1: 0.4, 2: 0.3, 3: 0.3, 4: 0.45, 5: 0.55, 6: 0.4, 7: 0.4, 9: 0.4, 10: 0.5, 11: 0.45}
LANES = [("Britain", "GB", 23.8, "GBR", (2, "britain")), ("Mongols", None, 16.1, "MNG", (3, "mongols")), ("Russia", "RU", 15.3, "RUS", (3, "russia")),
         ("Spain", "ES", 9.2, "ESP", (4, "spain")), ("France", "FR", 7.7, "FRA", (4, "france")), ("Ottomans", None, 3.5, "TUR", (4, "ottomans")),
         ("Israel", "IL", 0.02, "ISR", (5, "zero"))]

def keys(T, cam):
    K0 = cam(*CAM0); KW = cam(40, 40, 150, 430)
    return [(0.0, 0.01, K0), (T.S(1) - 0.2, 1.0, KW), (T.S(12) - 0.3, 1.0, K0)]

def hi(T, t):
    out = {}
    for nm, fl, v, code, (li, w) in LANES[:6]:
        a0 = T.WT(li, w); out[code] = 0.8 * min(1, max(0, (t - a0) / 0.4)) * (1 - min(1, max(0, (t - T.S(7)) / 0.6)))
    return out

def dim(T, t):
    from rlib import seg
    return seg(t, T.S(7) - 0.3, T.S(7)) * (1 - seg(t, T.S(12) - 0.3, T.S(12)))

def draw(E, X, cv, T, t):
    from rlib import seg, win, YEL, WHITE, SKY, figure
    A = win(t, T.S(1) - 0.1, T.S(7) - 0.1, 0.3, 0.4)
    if A > 0.01:
        cv.text("Event: most of the planet", 540, 290, 60, WHITE, A)
        E.panel(cv, 40, 760, 1000, 760, A)
        cv.text("Share of the world's land at peak", 540, 820, 44, "#C9D6EA", A)
        rows = []
        for nm, fl, v, code, (li, w) in LANES:
            rows.append(dict(label=nm, flag=fl, emo=None if fl else "\U0001F3C3", value=v, at=T.WT(li, w), color="#FFD23F" if nm == "Israel" else "#E5484D",
                             txt=("0.02%" if nm == "Israel" else f"{v:.1f}%"), tcol=YEL if nm == "Israel" else WHITE))
        E.bars(cv, rows, t, A, 905, rowh=84, vmax=23.8, lab_w=370, grow=1.0)
        for k, r in enumerate(rows):   # a runner on the tip of each bar
            if t > r["at"] and r["label"] != "Israel":
                from rlib import eout
                bw = (940 - 370 - 170) * max(0.004, r["value"] * eout((t - r["at"]) / 1.0) / 23.8)
                figure(cv, 70 + 370 + bw - 6, 905 + k * 84 + 30, 0.42, WHITE, badge=False, a=A, walk=t * 14)
        E.src(cv, "Taagepera, via Wikipedia. Israel incl. WB and Gaza", A, 1500)
    w = win(t, T.S(6) - 0.1, T.S(8) - 0.1, 0.3, 0.3)
    if w > 0.01:
        E.panel(cv, 140, 380, 800, 330, w)
        figure(cv, 400, 650, 1.6, WHITE, arms="point", a=w, flip=1)
        E.emo(cv, "\U0001F964", 560, 560, 90, w * seg(t, T.WT(6, "water") - 0.3, T.WT(6, "water")))
        cv.text("Water station", 760, 470, 48, YEL, w)
    inv = [(8, "\U0001F48A", "PillCam", "Given Imaging, Yokneam. FDA 2001"), (9, "❤️", "CARTO 3D heart map", "Biosense, Haifa, 1993"),
           (9, "\U0001F453", "OrCam MyEye", "OrCam, Jerusalem, 2010")]
    for k, (li, ic, nm, sub) in enumerate(inv):
        a0 = T.S(li) if k < 2 else T.WT(9, "clip")
        ia = win(t, a0 - 0.1, T.S(10) - 0.1, 0.3, 0.3)
        if ia <= 0.01: continue
        y = 640 + k * 260
        E.panel(cv, 70, y - 110, 940, 220, ia)
        E.emo(cv, ic, 170, y, 100, ia); cv.text(nm, 250, y - 30, 58, WHITE, ia, align="l", maxw=740); cv.text(sub, 250, y + 45, 40, "#C9D6EA", ia, align="l", maxw=740, bold=False)
    m = win(t, T.S(10) - 0.1, T.S(11) - 0.1, 0.3, 0.3)
    if m > 0.01:
        n = int(E.roll(t, T.S(10) + 0.2, 0, 50, 1.6))
        cv.text(f"{n}", 540, 420, 170, YEL, m); cv.text("Israeli inventions, medicine and tech", 540, 540, 46, WHITE, m)
        for i in range(n):
            E.emo(cv, "\U0001F947", 140 + (i % 10) * 89, 680 + (i // 10) * 120, 74, m)
        E.src(cv, "Company histories, Globes. Full list in caption", m, 1488)
    b = win(t, T.S(11) - 0.1, T.S(12) - 0.1, 0.3, 0.3)
    if b > 0.01:
        E.title(cv, "Borders: still argued over.", 820, b, 72)
        E.title(cv, "Colonizer? *Didn't even qualify.*", 1000, b * seg(t, T.WT(11, "colonizer") - 0.2, T.WT(11, "colonizer")), 76)
    lp = win(t, T.S(12) - 0.1, 999, 0.3, 0.3)
    if lp > 0.01: E.title(cv, "We compete in *R&D.*", 300, lp, 80); E.title(cv, "Not in...", 420, lp, 80)

def sfx(T):
    ev = [(T.S(1) - 0.3, "whoosh", -24), (T.WT(2, "off") - 0.1, "thud", -16)]
    for nm, fl, v, code, (li, w) in LANES: ev.append((T.WT(li, w), "pop" if nm != "Israel" else "buzz", -22))
    ev += [(T.WT(6, "water"), "pop", -20), (T.S(8), "ding", -24), (T.S(9), "ding", -24), (T.WT(9, "clip"), "ding", -24),
           (T.S(10) + 0.2, "roll", T.S(10) + 1.8), (T.S(10) + 1.8, "ding", -20), (T.WT(11, "colonizer"), "thud", -18), (T.S(12) - 0.3, "whoosh", -24)]
    return ev
