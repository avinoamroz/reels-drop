"""un_per_person_v2: 15 of 26 UNGA condemnations, live scoreboard on a world map, then per 10 million people."""
HOOK = "*15* of *26* UN|condemnations?"; HOOK_Y = 930
STYLE = "globe_spin_whip"; CAM0 = (36.0, 31.5, 24.0)      # opener lands here (map_open --cam lon,lat,wd,960)
BED = "doc_piano"; GAPS = {0: 0.45, 1: 0.35, 6: 0.5, 9: 0.5, 11: 0.45}
SUBS = {"U.N.": "UN"}
PIN = dict(RUS=(37.6, 55.75), USA=(-77.0, 38.9), IRN=(51.4, 35.7), PRK=(125.75, 39.0), MMR=(96.1, 19.75), SDN=(32.5, 15.6), ISR=(35.2, 31.8))
ROWS = [("RUS", "RU", "Russia", 6, 2), ("USA", "US", "USA", 2, 3), ("IRN", "IR", "Iran", 1, 4), ("PRK", "KP", "N. Korea", 1, 4),
        ("MMR", "MM", "Myanmar", 1, 4), ("SDN", "SD", "Sudan", 0, 5), ("ISR", "IL", "Israel", 15, 6)]
PER = [("Israel", "IL", 14.9), ("Russia", "RU", 0.41), ("N. Korea", "KP", 0.38), ("Myanmar", "MM", 0.18), ("Iran", "IR", 0.11), ("USA", "US", 0.06), ("Rest of world", None, 0.013)]

def at(T, row):
    code, _, name, v, li = row
    if code in ("IRN", "PRK", "MMR"): return T.WT(4, {"IRN": "iran", "PRK": "north", "MMR": "myanmar"}[code])
    return T.S(li)

def keys(T, cam):
    K0 = cam(*CAM0); KW = cam(18, 30, 205, 610)
    return [(0.0, 0.01, K0), (T.S(1) - 0.2, 1.4, KW), (T.S(12) - 0.4, 1.2, K0)]

def hi(T, t):
    out = {}
    for row in ROWS[:5]:
        a0 = at(T, row); out[row[0]] = 0.85 * (min(1, max(0, (t - a0) / 0.4)) if t > a0 else 0) * (1 - min(1, max(0, (t - T.S(12) + 0.3) / 0.5)))
    return out

def dim(T, t):
    from rlib import seg
    return seg(t, T.S(7) - 0.3, T.S(7) + 0.3) * (1 - seg(t, T.S(12) - 0.4, T.S(12) + 0.2))

def draw(E, X, cv, T, t):
    from rlib import seg, win, eout, YEL, WHITE, GREY, RED, SKY, GREEN
    A1 = win(t, T.S(1) - 0.1, T.S(7) - 0.1, 0.4, 0.4)          # scoreboard
    A2 = win(t, T.S(7) - 0.1, T.S(10) - 0.1, 0.4, 0.4)         # per 10M
    A3 = win(t, T.S(10) - 0.1, T.S(12) - 0.2, 0.4, 0.4)        # balance
    # pins
    for row in ROWS:
        a0 = at(T, row) if row[0] != "ISR" else T.S(6)
        pa = A1 * seg(t, a0 - 0.1, a0 + 0.2)
        if pa > 0.01:
            x, y = X.geo(*PIN[row[0]]); E.pin(cv, x, y, YEL if row[0] == "ISR" else (GREY if row[3] == 0 else RED), pa, t)
            E.tag(cv, f"{row[2]} {row[3]}", x, y - (78 if row[0] == "ISR" else 46), 38, YEL if row[0] == "ISR" else WHITE, pa)
    if A1 > 0.01:
        E.title(cv, "UN General Assembly *2025:* who got condemned?", 250, A1, 62)
        n = 0
        for row in ROWS:
            a0 = at(T, row) if row[0] != "ISR" else T.WT(6, "fifteen")
            if t >= a0: n += row[3] * min(1, (t - a0) / 0.6)
        E.panel(cv, 50, 830, 980, 690, A1)
        cv.text("Condemnations", 300, 890, 44, "#C9D6EA", A1, align="c", maxw=460)
        cv.text(f"{int(round(n))} / 26", 820, 890, 60, YEL, A1, maxw=320)
        rows = [dict(label=r[2], flag=r[1], value=r[3], at=(at(T, r) if r[0] != "ISR" else T.WT(6, "fifteen")),
                     color=("#FFD23F" if r[0] == "ISR" else "#E5484D"), txt=str(r[3]) if r[3] else "0", tcol=YEL if r[0] == "ISR" else WHITE) for r in ROWS]
        E.bars(cv, rows, t, A1, 965, rowh=74, vmax=15, lab_w=330, x0=70, w=940)
        cmb = A1 * seg(t, T.WT(6, "more") - 0.1, T.WT(6, "more") + 0.3)
        if cmb > 0.01:
            cv.rrect(80, 640, 920, 140, 30, "#0B1730", 0.9 * cmb, stroke=YEL, lw=3, sa=cmb)
            cv.rich([("Israel ", WHITE), ("15", YEL), ("   Rest of world ", WHITE), ("11", YEL)], 540, 710, 66, cmb)
        E.src(cv, "Source: UN Watch, UNGA 2025 session, Nov 2025", A1, 1500)
    if A2 > 0.01:
        E.title(cv, "Per *10 million* people", 330, A2, 84)
        rows = []
        for k, (nm, fl, v) in enumerate(PER):
            a0 = T.WT(8, "israel") if nm == "Israel" else (T.WT(8, "russia") if nm == "Russia" else T.WT(8, "under") + 0.15 * k)
            rows.append(dict(label=nm, flag=fl, emo=None if fl else "\U0001F30D", value=v, at=a0, color="#FFD23F" if nm == "Israel" else "#E5484D",
                             txt=(f"{v:.1f}" if v >= 1 else f"{v:.2f}" if v >= 0.05 else f"{v:.3f}"), tcol=YEL if nm == "Israel" else WHITE))
        E.panel(cv, 50, 520, 980, 720, A2)
        E.bars(cv, rows, t, A2, 610, rowh=92, vmax=14.9, lab_w=420)
        xa = A2 * seg(t, T.S(9) - 0.1, T.S(9) + 0.3)
        if xa > 0.01:
            cv.rrect(140, 1270, 800, 190, 34, "#0B1730", 0.92 * xa, stroke=YEL, lw=3, sa=xa)
            cv.text(f"{int(E.roll(t, T.S(9), 1, 1100, 1.2)):,}x", 540, 1345, 120, YEL, xa, maxw=760)
            cv.text("the rest of the world", 540, 1425, 44, WHITE, xa, maxw=760)
        E.src(cv, "UN Watch 2025; population: UN WPP 2024", A2, 1500)
    if A3 > 0.01:
        b1 = win(t, T.S(10) - 0.1, T.S(12) - 0.2, 0.4, 0.4)
        E.panel(cv, 60, 760, 960, 520, A3)
        E.title(cv, "Israel's war in Gaza deserves *scrutiny,* like any war.", 900, A3, 68)
        b2 = A3 * seg(t, T.S(11) - 0.1, T.S(11) + 0.3)
        cv.text("15 to 11", 540, 1080, 120, YEL, b2, maxw=900)
        E.title(cv, "isn't scrutiny. It's a *pattern.*", 1200, b2, 68)
    lp = seg(t, T.S(12) - 0.2, T.S(12) + 0.3)
    if lp > 0.01: E.title(cv, "Next time someone quotes the UN...", 330, lp, 72)

def sfx(T):
    ev = [(T.S(1) - 0.3, "whoosh", -24)]
    for r in ROWS[:5]: ev.append((at(T, r), "pop", -20))
    ev += [(T.WT(6, "fifteen") - 0.05, "thud", -14), (T.WT(6, "fifteen"), "roll", T.WT(6, "fifteen") + 0.6), (T.WT(6, "more"), "ding", -22),
           (T.S(7) - 0.3, "whoosh", -24), (T.WT(8, "israel"), "pop", -18), (T.S(9), "roll", T.S(9) + 1.2), (T.S(9) + 1.2, "thud", -16),
           (T.S(11), "ding", -22), (T.S(12) - 0.3, "whoosh", -24)]
    return ev
