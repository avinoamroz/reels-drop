#!/usr/bin/env python3
"""op_wrap.py: put a map_open.py motion opener (2.4 s) in front of a reel so the reel's NARRATION STARTS ON THE ZOOM
(Noam 4 Nov: "after the globe spin or map move a ZOOM IN, then the speech").

  python3 op_wrap.py --reel REEL.mp4 --style globe_unpeel --box 33.6,29.3,36.4,33.6 --hook 'Once a week,|*Israel stops.*' \
      --hook-y 855 --hook-s 1.0 --out OUT.mp4 [--body BODY.mp4 --audio AUDIO.m4a]

The opener's zoom starts at z0 (0.625 T, globe_unpeel 0.5 T). The reel's audio is laid in at z0, so its picture is
joined at t_b = T - z0 (the first d = T - z0 seconds of the reel's picture are covered by the zoom, the opener
cross-dissolves into the reel frame at t_b = d). Picture and sound stay in sync after the cut.
The last 0.5 s of the reel dissolve into the opener's frame 0, so the loop lands on the globe / map (circular).
--body/--audio: a pre-trimmed silent body that already starts at t_b = d and already ends on frame 0 (own renders).
"""
import argparse, json, os, subprocess, sys, tempfile
MO = "/home/claude/map_tear_opener/map_open.py"
def run(c): subprocess.run(c, check=True)
def dur(p): return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout)
ap = argparse.ArgumentParser()
ap.add_argument("--reel"); ap.add_argument("--body"); ap.add_argument("--audio")
ap.add_argument("--style", required=True); ap.add_argument("--cam"); ap.add_argument("--box")
ap.add_argument("--hook", required=True); ap.add_argument("--hook-y", default="930"); ap.add_argument("--hook-s", default="1.0")
ap.add_argument("--title"); ap.add_argument("--plain", action="store_true"); ap.add_argument("--dur", type=float, default=2.4); ap.add_argument("--out", required=True)
A = ap.parse_args()
T = A.dur; z0 = (0.5 if A.style == "globe_unpeel" else 0.625) * T; d = T - z0
tmp = tempfile.mkdtemp(prefix="opw_", dir="/home/claude/fix_1109/rmk")
geo = ["--cam", A.cam] if A.cam else ["--box", A.box]
common = ["--style", A.style, *geo, "--hook", A.hook, "--hook-y", str(A.hook_y), "--hook-s", str(A.hook_s), "--dur", str(T)]
if A.title: common += ["--title", A.title]
if A.plain: common += ["--plain"]
# 1. the opener's frame 0 (the loop target)
run([sys.executable, MO, *common, "--snaps", "0", "--out", f"{tmp}/op.mp4"]); op0 = f"{tmp}/op_0.00.png"
# 2. the body: reel picture from t_b = d, last 0.5 s dissolving into op0
if A.body:
    body = A.body; aud = A.audio
else:
    L = dur(A.reel) - d; body = f"{tmp}/body.mp4"; aud = A.reel
    fc = (f"[0:v]setpts=PTS-STARTPTS,format=yuv420p[b];[1:v]scale=1080:1920,format=rgba,fade=in:st={L - 0.5:.3f}:d=0.5:alpha=1[o];"
          f"[b][o]overlay=shortest=1:format=auto,format=yuv420p[v]")
    run(["ffmpeg", "-v", "error", "-y", "-ss", f"{d:.4f}", "-i", A.reel, "-loop", "1", "-framerate", "30", "-t", f"{L:.3f}", "-i", op0,
         "-filter_complex", fc, "-map", "[v]", "-an", "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-t", f"{L:.3f}", body])
# 3. opener + body (opener SFX, silent body)
run([sys.executable, MO, *common, "--reel", body, "--out", f"{tmp}/joined.mp4"])
tot = dur(f"{tmp}/joined.mp4")
# 4. lay the reel's audio in at z0, under the opener's SFX tail
ms = int(round(z0 * 1000))
fc = (f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo[s];[1:a]aformat=sample_rates=48000:channel_layouts=stereo,adelay={ms}|{ms}[r];"
      f"[s][r]amix=inputs=2:normalize=0:duration=first,atrim=0:{tot:.3f}[a]")
run(["ffmpeg", "-v", "error", "-y", "-i", f"{tmp}/joined.mp4", "-i", aud, "-filter_complex", fc, "-map", "0:v", "-map", "[a]",
     "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", A.out])
r = subprocess.run(["ffmpeg", "-nostats", "-i", A.out, "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
lufs = [l for l in r.splitlines() if l.strip().startswith("I:")][-1].split()[1]
subprocess.run(["rm", "-rf", tmp])
print(json.dumps(dict(out=A.out, style=A.style, T=T, z0=round(z0, 3), d=round(d, 3), dur=round(dur(A.out), 2), lufs=lufs)))
