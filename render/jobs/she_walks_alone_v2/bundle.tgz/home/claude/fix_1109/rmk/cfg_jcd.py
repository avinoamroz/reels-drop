"""jews_cause_death_v2: satire of the 'Jews are behind every death' conspiracy. Map + running counter + stick-figure gags, then rescues."""
import math
HOOK = "*2.2 million* deaths.|The Jews?"; HOOK_Y = 930
STYLE = "globe_spin_night"; CAM0 = (36.0, 32.0, 24.0)
BED = "playful"; GAPS = {0: 0.45, 1: 0.4, 3: 0.45, 5: 0.45, 6: 0.45, 7: 0.8, 8: 0.6, 10: 0.45, 11: 0.5, 12: 0.45}
PT = dict(tlv=(34.78, 32.08), jer=(35.21, 31.77), dam=(36.29, 33.51), san=(44.2, 15.35), kha=(32.53, 15.5), kig=(30.06, -1.95),
          ank=(36.2, 36.2), hai=(-72.34, 18.54), gaza=(34.45, 31.45))
DEATHS = [(2, "SYR", 528500, "Syria", "Syrian Observatory for Human Rights, 1 Jan 2025"),
          (4, "YEM", 377000, "Yemen", "UNDP, Nov 2021 (direct and indirect deaths)"),
          (6, "SDN", 300000, "Darfur", "UN humanitarian chief John Holmes, 2008"),
          (7, "RWA", 1000000, "Rwanda", "UN Outreach Programme on the Rwanda genocide")]

def keys(T, cam):
    K0 = cam(*CAM0)
    return [(0.0, 0.01, K0), (T.S(2) - 0.35, 1.0, cam(36.5, 33.0, 9, 700)), (T.S(4) - 0.4, 1.0, cam(42, 22, 30, 640)),
            (T.S(6) - 0.4, 1.0, cam(30, 14, 26, 640)), (T.S(7) - 0.4, 1.0, cam(30, 0, 22, 640)), (T.S(8) - 0.3, 1.0, cam(20, 15, 90, 700)),
            (T.S(9) - 0.4, 1.0, cam(35.5, 34.0, 12, 640)), (T.S(10) - 0.4, 1.2, cam(-20, 25, 150, 640)),
            (T.S(11) - 0.4, 1.1, cam(34.7, 31.5, 3.2, 640)), (T.S(12) - 0.3, 1.0, cam(20, 15, 90, 700)), (T.S(13) - 0.3, 1.0, K0)]

def hi(T, t):
    out = {}
    for li, code, *_ in DEATHS:
        a = min(1, max(0, (t - T.S(li)) / 0.5)) * (1 - min(1, max(0, (t - T.S(9) + 0.4) / 0.6)))
        out[code] = 0.85 * a
    return out

def dim(T, t):
    from rlib import seg
    return seg(t, T.S(8) - 0.3, T.S(8)) * (1 - seg(t, T.S(9) - 0.3, T.S(9))) + seg(t, T.S(12) - 0.3, T.S(12)) * (1 - seg(t, T.S(13) - 0.3, T.S(13)))

def total(T, t, E):
    n = 0
    for li, code, v, *_ in DEATHS:
        a0 = T.S(li) + 0.4
        if t > a0: n += v * min(1, (t - a0) / 1.0)
    return n

def draw(E, X, cv, T, t):
    from rlib import seg, win, YEL, WHITE, RED, GREEN, SKY, GREY, figure, brain, pulse_beam
    A1 = win(t, T.S(1) - 0.1, T.S(2) - 0.1, 0.3, 0.3)
    if A1 > 0.01:
        E.panel(cv, 70, 1050, 940, 360, A1)
        cv.text("Online conspiracy theory:", 540, 1130, 46, "#C9D6EA", A1)
        E.title(cv, "\"Jews are behind *every death*\"", 1270, A1, 74)
    # running total (top) from Syria to the turn
    ta = win(t, T.S(2) - 0.1, T.S(9) - 0.2, 0.3, 0.4)
    if ta > 0.01:
        cv.rrect(170, 230, 740, 150, 30, "#0B1730", 0.85 * ta, stroke=YEL, lw=2.5, sa=0.7 * ta)
        cv.text("Blamed on Jews:", 540, 268, 40, "#C9D6EA", ta)
        cv.text(f"{int(total(T, t, E)):,}", 540, 335, 76, YEL, ta)
    for k, (li, code, v, nm, srcl) in enumerate(DEATHS):
        a = win(t, T.S(li) - 0.1, (T.S(li + 1) if li in (2, 4, 6) else T.S(li + 1)) - 0.1, 0.3, 0.3)
        if li in (2, 4): a = win(t, T.S(li) - 0.1, T.S(li + 2) - 0.1, 0.3, 0.3)
        if a <= 0.01: continue
        cv.text(nm, 540, 470, 96, WHITE, a)
        cv.text(f"{int(E.roll(t, T.S(li) + 0.4, 0, v, 1.0)):,}" + ("+" if code == "RWA" else ""), 540, 580, 92, YEL, a)
        cv.text("dead", 540, 660, 52, "#C9D6EA", a)
        E.src(cv, srcl, a, 1500)
    # gag 1: secret lab, beams to Damascus
    g = win(t, T.S(3) - 0.1, T.S(4) - 0.1, 0.3, 0.3)
    if g > 0.01:
        p0 = X.geo(*PT["tlv"]); p1 = X.geo(*PT["dam"])
        pulse_beam(cv, p0, p1, t, bend=-120, prog=seg(t, T.WT(3, "beaming") - 0.2, T.WT(3, "beaming") + 0.5), a=g)
        E.panel(cv, 60, 860, 960, 560, g, stroke=RED)
        cv.text("SECRET LAB, Tel Aviv", 450, 930, 60, WHITE, g)
        cv.line([(100, 1360), (980, 1360)], "#3C70B0", 4, g)
        for i, x in enumerate((300, 540, 780)):
            hd = figure(cv, x, 1360, 1.9, WHITE, arms="temple", a=g)
            brain(cv, hd[0], hd[1] - 70, 1.3, 0.5 + 0.5 * math.sin(t * 6 + i), g)
        cv.text("(satire)", 860, 930, 40, "#C9D6EA", g)
    # gag 2: texting from Jerusalem
    g = win(t, T.S(5) - 0.1, T.S(6) - 0.1, 0.3, 0.3)
    if g > 0.01:
        cv.rrect(300, 840, 480, 620, 50, "#0E2250", g, stroke=WHITE, lw=6, sa=g)
        b1 = g * seg(t, T.WT(5, "please") - 0.1, T.WT(5, "please") + 0.2); b2 = g * seg(t, T.WT(5, "listened") - 0.2, T.WT(5, "listened"))
        cv.rrect(330, 930, 400, 150, 26, SKY, b1); cv.text("please, start", 530, 975, 52, WHITE, b1, shadow=False); cv.text("a war", 530, 1040, 52, WHITE, b1, shadow=False)
        cv.rrect(380, 1130, 370, 110, 26, "#2B3D63", b2); cv.text("ok", 565, 1185, 60, WHITE, b2, shadow=False)
        cv.text("Jerusalem", 540, 1400, 42, "#C9D6EA", g)
        cv.text("(satire)", 540, 820, 40, "#C9D6EA", g)
    # gag 3: delegation knocks
    g = win(t, T.S(6) + 0.6, T.S(7) - 0.1, 0.3, 0.3)
    if g > 0.01:
        E.panel(cv, 60, 900, 960, 520, g)
        cv.rrect(720, 960, 200, 400, 10, "#8A5A2B", g); cv.circ(890, 1170, 10, YEL, g)
        for i, x in enumerate((360, 500)):
            figure(cv, x, 1360, 1.8, WHITE, arms="point" if i else "down", brief=True, a=g, flip=1)
        cv.text("Delegation", 300, 960, 46, "#C9D6EA", g)
    g = win(t, T.WT(7, "also") - 0.1, T.S(8) - 0.1, 0.2, 0.3)
    if g > 0.01:
        E.panel(cv, 200, 960, 680, 460, g); figure(cv, 540, 1360, 2.2, WHITE, arms="shrug", a=g); cv.text("Also us?", 540, 1010, 54, YEL, g)
    # turn
    g = win(t, T.S(8) - 0.1, T.S(9) - 0.15, 0.3, 0.3)
    if g > 0.01: E.title(cv, "Or maybe people did this *to each other.*", 900, g, 84)
    # rescues
    for li, dst, num, cap, srcl, plus in [(9, "ank", 19, "pulled out alive", "IDF Olive Branches, Feb 2023 (JNS, Jerusalem Post)", False),
                                          (10, "hai", 1100, "patients treated", "IDF field hospital, Haiti 2010 (Ynet)", True)]:
        g = win(t, T.S(li) - 0.1, T.S(li + 1) - 0.1, 0.3, 0.3)
        if g <= 0.01: continue
        p0 = X.geo(*PT["tlv"]); p1 = X.geo(*PT[dst])
        pulse_beam(cv, p0, p1, t, bend=-160 if li == 10 else -90, col=SKY, prog=seg(t, T.S(li), T.S(li) + 0.9), a=g)
        E.pin(cv, *p1, GREEN, g, t)
        cv.text("Israel sends rescuers", 540, 330, 66, WHITE, g)
        E.panel(cv, 140, 1050, 800, 360, g)
        cv.text(f"{int(E.roll(t, T.S(li) + 0.6, 0, num, 0.9)):,}" + ("+" if plus else ""), 540, 1185, 150, YEL, g)
        cv.text(cap, 540, 1320, 54, WHITE, g)
        E.src(cv, srcl, g, 1490)
    g = win(t, T.S(11) - 0.1, T.S(12) - 0.1, 0.3, 0.3)
    if g > 0.01:
        cv.text("Gaza, since Oct 2023", 540, 330, 66, WHITE, g)
        E.panel(cv, 110, 1050, 860, 360, g)
        cv.text(f"{int(E.roll(t, T.WT(11, 'over'), 0, 73000, 1.0)):,}+", 540, 1185, 140, YEL, g)
        cv.text("dead, per Gaza's Health Ministry", 540, 1320, 48, WHITE, g)
        E.src(cv, "Via AP, Jun 2026. It does not separate fighters and civilians.", g, 1490)
    g = win(t, T.S(12) - 0.1, T.S(13) - 0.15, 0.3, 0.3)
    if g > 0.01:
        E.title(cv, "Not a fact.", 820, g, 110)
        E.title(cv, "A *conspiracy theory.*", 980, g * seg(t, T.WT(12, "conspiracy") - 0.3, T.WT(12, "conspiracy")), 96)

def sfx(T):
    ev = []
    for li, *_ in DEATHS: ev += [(T.S(li) - 0.3, "whoosh", -24), (T.S(li) + 0.4, "roll", T.S(li) + 1.4)]
    ev += [(T.WT(3, "beaming") - 0.1, "pop", -20), (T.WT(5, "please"), "pop", -20), (T.WT(5, "listened"), "pop", -20),
           (T.WT(6, "asked"), "thud", -20), (T.WT(6, "asked") + 0.2, "thud", -20), (T.WT(7, "also"), "pop", -20),
           (T.S(8) - 0.4, "thud", -14), (T.S(9) - 0.3, "whoosh", -24), (T.S(9) + 0.6, "roll", T.S(9) + 1.5), (T.S(9) + 1.5, "ding", -22),
           (T.S(10) - 0.3, "whoosh", -24), (T.S(10) + 0.6, "roll", T.S(10) + 1.5), (T.S(11) - 0.3, "whoosh", -26),
           (T.WT(12, "conspiracy"), "thud", -16), (T.S(13) - 0.3, "whoosh", -24)]
    return ev
