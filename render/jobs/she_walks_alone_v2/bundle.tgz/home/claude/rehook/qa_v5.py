"""QA for the v5 all-Cartesia rebuilds: web copy (540x960), contact sheet, ebur128, ASR of the final mix vs script, frame 0 check.
usage: python3 qa_v5.py fff_v4|thinking_v3|trust_v3"""
import sys, json, numpy as np; sys.path.insert(0, "/home/claude/rehook"); import rk5
RH = "/home/claude/rehook"; name = sys.argv[1]
txt = {"fff_v4": "cartesia_full_fff.txt", "thinking_v3": "cartesia_full_thinking.txt", "trust_v3": "cartesia_full_trust.txt"}[name]
Q = json.load(open(f"{RH}/qa_{name}.json")); W = Q["words"]; L = rk5.lines_of(f"{RH}/{txt}"); T, TR = Q["T_END"], Q["T_TR"]
times = sorted(set([0.0, 0.5, 1.0, 1.5, 2.5, round(TR - 0.4, 2), round(TR + 0.5, 2)] + [round(float(x), 2) for x in np.linspace(TR + 3, T - 1.0, 8)]))
nb = [f"Hook {Q['hook']}  body from {TR:.2f} s. Subtitles: {len(Q['subs'])} chunks from the new word times."]
if "pads" in Q: nb.append(f"Silence added after lines (index: s): {[(k, p) for k, p in enumerate(Q['pads']) if p]}")
R = rk5.qa(name, f"{RH}/{name}.mp4", f"{RH}/{name}_web.mp4", L, W, f"{RH}/{name}_qa.png", times, extra_notes=nb)
Q["qa"] = R; json.dump(Q, open(f"{RH}/qa_{name}.json", "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: R[k] for k in ("main", "web", "loudness", "asr_mismatches", "asr_inserted", "first_frame_ink")}, ensure_ascii=False))
