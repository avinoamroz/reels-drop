"""rehook copy of /home/claude/thinking_paths/audio.py: cues/VO/out from argv + hook sfx."""
"""Thinking paths: warm pad bed that builds slowly + soft wind + subtle sfx + narration (ducked) -> mix.wav (pre-loudnorm).
Same approach as /home/claude/gap/audio.py."""
import json, subprocess, sys, numpy as np, soundfile as sf
from scipy.signal import lfilter, butter, sosfilt, fftconvolve
D = "/home/claude/thinking_paths"; SR = 48000
CUE_P, VO_P, OUT_P = sys.argv[1:4]
cue = json.load(open(CUE_P)); T_END = cue["T_END"]
n = int(T_END * SR) + 1; rng = np.random.default_rng(21)
def nf(m): return 440 * 2 ** ((m - 69) / 12)
def lp(x, a): return lfilter([a], [1, a - 1], x)
tt_ = lambda d: np.arange(int(d * SR)) / SR
def place(buf, sig, st, g=1.0, pan=0.0):
    i = int(st * SR); j = min(n, i + len(sig))
    if i < 0: sig = sig[-i:]; i = 0
    if j > i: s = g * sig[:j - i]; buf[0][i:j] += s * (1 - pan); buf[1][i:j] += s * (1 + pan)

# bed: Dmaj9 / Bm9 / Gmaj9 / Asus at 64 BPM, layers enter one by one (pad, bass, plucks, high shimmer)
BED = (np.zeros(n), np.zeros(n)); beat = 60 / 64; bar = 4 * beat
prog = [(38, [62, 66, 69, 73, 76]), (35, [62, 66, 69, 71, 73]), (31, [62, 66, 67, 71, 74]), (33, [61, 64, 69, 71, 76])]
b = 0; NB = int(T_END / bar) + 1
while b * bar < T_END:
    st = b * bar; root, ch = prog[b % 4]; build = min(1.0, b / max(1, NB - 3))
    d = bar + 1.6; t = tt_(d); pad = np.zeros_like(t)
    for m in ch:
        for dt in (-0.07, 0.0, 0.07): pad += np.sin(2 * np.pi * nf(m - 12) * 2 ** (dt / 12) * t + rng.random() * 6)
    pad *= np.minimum(1, t / 1.6) * np.minimum(1, (d - t) / 1.4); pad = lp(pad, 0.04 + 0.03 * build)
    place(BED, pad, st, 0.016 * (0.75 + 0.45 * build), -0.1)
    if b >= 1:
        t = tt_(bar + 0.5); place(BED, np.sin(2 * np.pi * nf(root - 12) * t) * np.minimum(1, t / 0.4) * np.exp(-t * 0.45), st, 0.08 * (0.7 + 0.4 * build))
    if b >= 3:
        for q in range(8 if b >= 9 else 4):
            if q % 2 and b < 6 and q < 4: continue
            m = ch[[0, 2, 4, 1, 3, 2, 4, 0][q]] + 12; t = tt_(1.2)
            pl = (np.sin(2 * np.pi * nf(m) * t) + 0.25 * np.sin(2 * np.pi * 2 * nf(m) * t) * np.exp(-t * 8)) * np.minimum(1, t / 0.004) * np.exp(-t * 3.2)
            place(BED, pl, st + q * beat * (0.5 if b >= 9 else 1), 0.022 * (0.8 + 0.4 * build) * (1.1 if q == 0 else 0.8), 0.35 if q % 2 else -0.35)
    if b >= 12:   # high shimmer for the ending
        t = tt_(bar + 1.0); sh = sum(np.sin(2 * np.pi * nf(m + 12) * t + rng.random() * 6) for m in ch[2:])
        place(BED, sh * np.sin(np.pi * t / (bar + 1.0)) ** 2, st, 0.006, 0.2)
    b += 1
# wind: soft band-passed noise, slow swells
w = rng.standard_normal(n); w = sosfilt(butter(2, [250, 1400], "bp", fs=SR, output="sos"), w)
sw = 0.55 + 0.45 * np.sin(2 * np.pi * np.arange(n) / SR / 7.3) * np.sin(2 * np.pi * np.arange(n) / SR / 3.1 + 1)
WIND = np.stack([w * sw, np.roll(w, 2400) * sw]) * 0.012

SFX = (np.zeros(n), np.zeros(n))
def noise(d): return rng.standard_normal(int(d * SR))
def chime(t0, base, g=0.10):
    for k, m in enumerate((base, base + 7, base + 12)):
        t = tt_(2.2); f = nf(m)
        x = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 5)) * np.minimum(1, t / 0.004) * np.exp(-t * 2.2)
        place(SFX, x, t0 + 0.07 * k, g * (1 - 0.2 * k), (-0.3, 0, 0.3)[k])
def swept(t0, d, g, lo, hi, pre=0.3, pan=0.15):
    x = noise(d); sw_ = np.zeros_like(x)
    for k in range(0, len(x), 480):
        fc = lo + hi * np.sin(np.pi * min(1, k / len(x))); sw_[k:k + 480] = sosfilt(butter(2, [fc * 0.6, fc * 1.4], "bp", fs=SR, output="sos"), x[k:k + 480])
    t = tt_(d); place(SFX, sw_ * np.sin(np.pi * t / d) ** 2, t0 - pre, g, pan)
for tk in cue["STONES"]:   # soft stone tap
    t = tt_(0.14); x = (np.sin(2 * np.pi * 620 * t) * np.exp(-t * 55) + 0.6 * np.sin(2 * np.pi * 1340 * t) * np.exp(-t * 80)) + 0.3 * noise(0.14) * np.exp(-t * 120)
    place(SFX, x, tk, 0.09, rng.random() * 0.4 - 0.2)
for tk in cue["SYN"]:      # synapse blip
    t = tt_(0.25); place(SFX, np.sin(2 * np.pi * nf(86) * t) * np.minimum(1, t / 0.003) * np.exp(-t * 18), tk, 0.05, rng.random() * 0.6 - 0.3)
for k, tc in enumerate(cue["CHIMES"]): chime(tc, [81, 86, 83, 88, 90][k % 5], 0.10)
for tp in cue["POPS"]:
    t = tt_(0.09); f = 420 + 800 * (t / 0.09); place(SFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 0.09), tp, 0.10, rng.random() * 0.6 - 0.3)
for tw in cue["WHOOSH"]: swept(tw, 0.9, 0.2, 300, 2200)
for tc in cue["CARDS"]: swept(tc, 0.6, 0.12, 300, 2200)


# ---------------- hook sfx (rehook): soft pencil taps while the path draws, bubble pop, ice crackle + shimmer on "freeze", whoosh into the body
HK = cue["HOOK"]; HSFX = (np.zeros(n), np.zeros(n))
for k, tk in enumerate(HK["draw"]):
    t = tt_(0.08); x = sosfilt(butter(2, [1800, 5200], "bp", fs=SR, output="sos"), noise(0.08)) * np.exp(-t * 60); place(HSFX, x, tk, 0.25 + 0.1 * (k % 2), -0.2 + 0.1 * (k % 3))
t = tt_(0.09); f = 420 + 800 * (t / 0.09); place(HSFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 0.09), HK["what"], 0.6, 0.3)
for k in range(70):
    tc = HK["freeze"] + 1.1 * (k / 70) ** 1.3 + 0.02 * rng.random(); t = tt_(0.02)
    place(HSFX, sosfilt(butter(2, 4000, "hp", fs=SR, output="sos"), noise(0.02)) * np.exp(-t * 300), tc, 0.5 * rng.random() + 0.1, rng.random() - 0.5)
t = tt_(1.6); place(HSFX, sum(np.sin(2 * np.pi * nf(m) * t) for m in (93, 98, 100)) * np.minimum(1, t / 0.2) * np.exp(-t * 1.6), HK["freeze"], 0.05)
t = tt_(0.6); place(HSFX, np.sin(2 * np.pi * (42 + 40 * np.exp(-t * 10)) * t) * np.exp(-t * 6), HK["freeze"], 0.5)
swept(HK["tr"], 0.8, 0.22, 300, 2200)
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", VO_P, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
v = np.frombuffer(raw, np.float32).astype(np.float64)[:n]; v = np.pad(v, (0, n - len(v)))
hop = int(0.02 * SR); env = np.sqrt(np.abs(fftconvolve(v ** 2, np.ones(hop) / hop, "same")) + 1e-12)
act = 20 * np.log10(env) > 20 * np.log10(np.abs(v).max()) - 35
lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)))
bed = np.stack(BED); lb = 20 * np.log10(np.sqrt(np.mean(bed ** 2)) + 1e-12)
held = fftconvolve(act.astype(float), np.ones(int(0.3 * SR)), "full")[:n] > 0.5
mask = np.clip(fftconvolve(held.astype(float), np.ones(int(0.15 * SR)) / int(0.15 * SR), "same"), 0, 1)
g_sp, g_gap = 10 ** ((lv - 19 - lb) / 20), 10 ** ((lv - 12 - lb) / 20)
gain = g_gap + (g_sp - g_gap) * mask
lw = 20 * np.log10(np.sqrt(np.mean(WIND ** 2)) + 1e-12)
sfx = np.stack(SFX); ls = 20 * np.log10(np.sqrt(np.mean(sfx[:, sfx[0] != 0] ** 2)) + 1e-12)
out = np.stack([v, v]) + bed * gain + WIND * 10 ** ((lv - 30 - lw) / 20) + sfx * 10 ** ((lv - 11 - ls) / 20)
hs = np.stack(HSFX); lh = 20 * np.log10(np.sqrt(np.mean(hs[:, hs[0] != 0] ** 2)) + 1e-12); out += hs * 10 ** ((lv - 13 - lh) / 20)
fi = int(0.05 * SR); out[:, :fi] *= np.linspace(0.3, 1, fi); fo = int(1.2 * SR); out[:, -fo:] *= np.linspace(1, 0, fo)
out /= max(1.0, np.abs(out).max() / 0.95)
sf.write(OUT_P, out.T.astype(np.float32), SR)
print("voice level", round(lv, 1), "dBFS, mix", round(out.shape[1] / SR, 2), "s")
