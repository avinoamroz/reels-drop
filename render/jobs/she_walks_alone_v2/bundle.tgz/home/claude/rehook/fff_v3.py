"""FIGHT, FLIGHT, FREEZE v3: new moving silver hook (Cartesia line A) + the original navy body.
Hook 0..~5.8 s: stylised head, thought cloud full of English words that goes blank white on "nothing", red brain alarm pulse,
zoom into the head with a white flash -> the original body (frames decoded from fff_v1.mp4, the subtitle-free render of the
posted fff_v2_subs.mp4) from the DANGER beat on. The old title line and "Someone asks you a question in English" are cut
(the hook now says it). Audio: original audio.py rebuilt with the shifted cues + new VO, hook sfx, two-pass loudnorm.
usage: python3 fff_v3.py --snaps 0,1,2 | --render"""
import sys, os, json, math, argparse, subprocess, time
sys.path.insert(0, "/home/claude/rehook")
from rk import *
from rk import remux
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); ap.add_argument("--audio", action="store_true"); A = ap.parse_args()
D0 = "/home/claude/fff"; OUT = f"{RH}/fff_v3.mp4"
# ------------------------------------------------------------------ old timeline (same mapping as fff/reel.py)
SEGS = json.load(open(f"{D0}/vo/segs.json"))["segs"]; SF = json.load(open(f"{D0}/vo/segs_full.json")); CH = SF["chunks"]; FS = SF["segs"]
CT = {}
for si, (f0, f1) in enumerate(FS):
    g = [k for k, ch in enumerate(CH) if ch[0] >= f0 - 0.01 and ch[1] <= f1 + 0.01]; g0, g1 = CH[g[0]][0], CH[g[-1]][1]; s0, s1 = SEGS[si]
    for k in g: CT[k] = tuple(s0 + (CH[k][j] - g0) / (g1 - g0) * (s1 - s0) for j in (0, 1))
CUE0 = json.load(open(f"{D0}/cues.json")); T_END0 = CUE0["T_END"]
T_AND = CT[2][0]; T_DANGER = T_AND - 0.15; CUT_A = (CT[1][1] + T_AND) / 2; VIS0 = T_DANGER + 0.32
# ------------------------------------------------------------------ new timeline
HK = json.load(open(f"{RH}/vo/hooks_asr.json"))["A"]; LEAD = 0.3
HC = [(LEAD + a, LEAD + b, s) for a, b, s in HK["chunks"]]          # You know the words. | Someone asks ... and... | Nothing.
HOOK_END = LEAD + HK["speech"][1]
DF = int(round((HOOK_END + 0.5 - T_AND) * FPS)); DELTA = DF / FPS      # whole frames
T_TR = VIS0 + DELTA                                                   # first body frame (after the white flash peak)
T_END = T_END0 + DELTA; N = int(round(T_END * FPS))
T_NOTH = HC[2][0]; T_ASK = HC[1][0]; T_AND_H = T_ASK + (HC[1][1] - T_ASK) * 0.88    # "and..." near the end of chunk 2
print(f"DELTA {DELTA:.3f}  hook end {HOOK_END:.2f}  body visuals from {T_TR:.2f} (old {VIS0:.2f})  T_END {T_END:.2f}")

# ------------------------------------------------------------------ hook drawing
HT = HookText("יודעים את המילים.\nואז שואלים אתכם באנגלית... ושקט.", 58,
              [(0.0, "You know\nthe *words.*", 128), (T_ASK - 0.05, "Someone asks you\na question in *English.*", 100),
               (T_AND_H - 0.05, "And...", 140), (T_NOTH - 0.04, "*nothing.*", 156)], y_he=262)
WORDS = [("presentation", 44, -140, -50), ("I think that...", 44, 150, -58), ("the budget", 44, -120, 48), ("next quarter", 44, 150, 52)]
WS = [pil2cairo(rich(s, sz, 800, B255 if k % 2 == 0 else N255)) for k, (s, sz, _, _) in enumerate(WORDS)]
def bub_img(lines, sz=50):
    f = font(sz, 800); tw = max(f.getlength(l) for l in lines); lh = sz * 1.2; pw, ph = int(tw + 64), int(lh * len(lines) + 36)
    im = Image.new("RGBA", (pw + 20, ph + 60), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([10, 10, 10 + pw, 10 + ph], 30, fill=(255, 255, 255, 255), outline=N255, width=5)
    d.polygon([(pw - 70, ph + 6), (pw - 20, ph + 6), (pw + 4, ph + 52)], fill=(255, 255, 255, 255), outline=None)
    d.line([(pw - 70, ph + 8), (pw + 4, ph + 52), (pw - 20, ph + 8)], fill=N255, width=5)
    for j, l in enumerate(lines): d.text((10 + pw / 2, 10 + 18 + lh * (j + 0.5)), l, font=f, fill=N255, anchor="mm")
    return pil2cairo(im)
BUB = bub_img(["So, what do", "you think?"])
CX, CY = 540, 1290      # head centre
def cloud_path(c, x, y, w, h):
    pts = [(-0.12, 0.03, 0.42), (0.14, 0.03, 0.42), (-0.36, 0.12, 0.30), (-0.16, -0.18, 0.36), (0.12, -0.22, 0.38), (0.36, -0.02, 0.32), (0.28, 0.22, 0.28), (0.0, 0.26, 0.30), (-0.26, 0.26, 0.26)]
    for px, py, r in pts: c.new_sub_path(); c.arc(x + px * w, y + py * h * 1.3, r * h, 0, 2 * math.pi)
def brain_icon(c, x, y, s, a, col=BLUE):
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.scale(s, s)
    c.move_to(-95, 20); c.curve_to(-120, -40, -70, -85, -20, -70); c.curve_to(10, -95, 70, -85, 85, -45); c.curve_to(125, -25, 115, 40, 70, 48)
    c.curve_to(40, 70, -10, 68, -30, 52); c.curve_to(-70, 70, -110, 55, -95, 20); c.close_path()
    fill(c, (0.93, 0.95, 0.99), a); c.fill_preserve(); stroke(c, col, 7, a); c.stroke()
    for p in ((-55, -40, -30, -5, -50, 25), (0, -60, 20, -20, -5, 15), (45, -50, 70, -10, 45, 25)):
        c.move_to(p[0], p[1]); c.curve_to(p[2], p[3] - 10, p[2], p[3] + 10, p[4], p[5]); stroke(c, col, 5, a * 0.8); c.stroke()
    c.move_to(0, 50); c.line_to(0, 90); stroke(c, col, 9, a); c.stroke(); c.restore()
def hook_frame(c, t):
    bg_silver(c, t)
    alarm = ramp(t, T_NOTH - 0.02, T_NOTH + 0.12)
    pulse = 0.5 + 0.5 * math.sin((t - T_NOTH) * 2 * math.pi * 2.2)
    z = ramp(t, T_TR - 0.42, T_TR)                                      # zoom into the head
    c.save(); zs = 1 + 1.9 * z ** 2; c.translate(CX, CY - 90); c.scale(zs, zs); c.translate(-CX, -(CY - 90))
    # red alarm edges (soft on silver)
    if alarm > 0.01:
        g = cairo.RadialGradient(540, 1150, 420, 540, 1150, 1150); g.add_color_stop_rgba(0, *RED[:3], 0); g.add_color_stop_rgba(1, *RED[:3], 0.30 * alarm * (0.55 + 0.45 * pulse))
        c.set_source(g); c.paint()
    bob = 6 * math.sin(t * 2.3); shake = 5 * math.sin(t * 47) * alarm * (1 - z)
    hx_, hy_ = CX + shake, CY + bob
    # shoulders / torso
    rr(c, hx_ - 270, hy_ + 190, 540, 260, 120); fill(c, NAVY); c.fill()
    rr(c, hx_ - 60, hy_ + 150, 120, 70, 20); fill(c, (0.86, 0.88, 0.92)); c.fill()
    # red alarm rings from the head
    if alarm > 0.01:
        for k in range(3):
            u = ((t - T_NOTH) / 0.75 + k / 3) % 1; stroke(c, RED, 8 * (1 - u) + 2, alarm * (1 - u) * 0.8); c.arc(hx_, hy_ - 40, 230 + 260 * u, 0, 2 * math.pi); c.stroke()
    # head
    c.save(); c.translate(hx_, hy_); c.scale(1, 1.08); c.arc(0, 0, 200, 0, 2 * math.pi); c.restore()
    fill(c, PAPER); c.fill_preserve(); stroke(c, NAVY, 10); c.stroke()
    # brain inside the head (appears on "And...", red alarm on "nothing")
    ba = max(0.0, ramp(t, T_AND_H - 0.1, T_AND_H + 0.3) * 0.55, alarm)
    if ba > 0.01:
        brain_icon(c, hx_, hy_ - 128, 0.74, ba, RED if alarm > 0.5 else BLUE)
        if alarm > 0.01:
            glow(c, hx_ - 18, hy_ - 112, 110, RED, 0.55 * alarm * (0.5 + 0.5 * pulse))
            fill(c, RED, alarm); c.arc(hx_ - 18, hy_ - 112, 13 + 5 * pulse, 0, 2 * math.pi); c.fill()
    # face: eyes, brows, mouth
    wide = ramp(t, T_NOTH - 0.05, T_NOTH + 0.2); blink = 1.0 if (t % 2.6) > 0.12 or wide > 0.5 else 0.12
    for sx in (-1, 1):
        ex, ey = hx_ + sx * 72, hy_ + 18
        if wide > 0.01: fill(c, PAPER); c.arc(ex, ey, 26 * wide, 0, 2 * math.pi); c.fill_preserve(); stroke(c, NAVY, 5, wide); c.stroke()
        c.save(); c.translate(ex, ey); c.scale(1, blink); fill(c, NAVY); c.arc(0, 0, lerp(17, 11, wide), 0, 2 * math.pi); c.fill(); c.restore()
        by_ = ey - 52 - 20 * wide; stroke(c, NAVY, 9); c.move_to(ex - 30, by_ + 6 - sx * 4 * (1 - wide)); c.line_to(ex + 30, by_ + 6 + sx * 4 * (1 - wide) - 8 * wide); c.stroke()
    my = hy_ + 100
    if wide < 0.5:
        stroke(c, NAVY, 9); c.move_to(hx_ - 50, my); c.curve_to(hx_ - 20, my + 22, hx_ + 20, my + 22, hx_ + 50, my); c.stroke()
    else:
        c.save(); c.translate(hx_, my + 8); c.scale(1, 1.3); c.arc(0, 0, 16, 0, 2 * math.pi); c.restore(); fill(c, NAVY); c.fill()
    # sweat drop after the blank
    if alarm > 0.01:
        u = ((t - T_NOTH) * 0.9) % 1; dx, dy = hx_ + 175, hy_ - 70 + 70 * u
        c.move_to(dx, dy - 24); c.curve_to(dx + 16, dy, dx + 14, dy + 16, dx, dy + 16); c.curve_to(dx - 14, dy + 16, dx - 16, dy, dx, dy - 24); fill(c, BLUE, alarm * (1 - u)); c.fill()
    # thought cloud (top right of the head)
    cx_, cy_ = 620 + 4 * math.sin(t * 1.3), 905 + 6 * math.sin(t * 1.7); cw_, chh = 640, 250
    sc_c = lerp(0.94, 1.0, eob(min(1, (t + 0.25) / 0.5)))
    c.save(); c.translate(cx_, cy_); c.scale(sc_c, sc_c); c.translate(-cx_, -cy_)
    for k, (dx, dy, r) in enumerate(((hx_ + 90, hy_ - 228, 14), (hx_ + 120, hy_ - 268, 22))):
        fill(c, PAPER); c.arc(dx, dy, r, 0, 2 * math.pi); c.fill_preserve(); stroke(c, NAVY, 5); c.stroke()
    if alarm > 0.01: glow(c, cx_, cy_, 380, (1, 1, 1), 0.9 * alarm)
    cloud_path(c, cx_, cy_, cw_, chh); fill(c, PAPER); c.fill()
    cloud_path(c, cx_, cy_, cw_, chh); stroke(c, NAVY, 6, 1 - 0.75 * alarm); c.stroke()
    cloud_path(c, cx_, cy_, cw_, chh); fill(c, PAPER); c.fill()
    for k, (s, sz, ox, oy) in enumerate(WORDS):
        sc_ = 1 - alarm; ang = k * 1.7
        x = cx_ + ox + 10 * math.sin(t * 1.1 + k * 2) + 220 * alarm * math.cos(ang); y = cy_ + oy + 8 * math.sin(t * 1.4 + k) + 160 * alarm * math.sin(ang)
        paste(c, WS[k], x, y, 1 - alarm, max(0.01, sc_ * (1 + 0.15 * alarm)))
    if alarm > 0.3 and ((t - T_NOTH) * 2.2) % 1 < 0.55: fill(c, NAVY, alarm); c.rectangle(cx_ - 4, cy_ - 40, 8, 80); c.fill()
    c.restore()
    # question bubble from the left
    qa = win(t, T_ASK + 0.15, T_NOTH + 0.4, 0.2, 0.3)
    if qa > 0.01: paste(c, BUB, 80 + 6 * math.sin(t * 2), 1090, qa, eob(min(1, (t - T_ASK - 0.15) / 0.3)), "tl")
    c.restore()
    # text stays put (not zoomed); it leaves with the flash
    HT.render(c, t, 1 - ramp(t, T_TR - 0.3, T_TR - 0.05))
    fl = ramp(t, T_TR - 0.3, T_TR)
    if fl > 0.01: c.set_source_rgba(1, 1, 1, fl); c.paint()

# ------------------------------------------------------------------ subtitles: body lines 1..14 (line 1 trimmed to "And your brain hears... DANGER.")
TTS = [l.strip() for l in open(f"{D0}/tts_v4.txt") if l.strip()]
TTS[1] = "[calm] And your brain hears... DANGER."
SUBL = []
for si in range(1, len(FS)):
    ks = [k for k, ch in enumerate(CH) if ch[0] >= FS[si][0] - 0.01 and ch[1] <= FS[si][1] + 0.01]
    if si == 1: ks = [2, 3]
    txt = subclean(TTS[si]); SUBL.append((txt, line_map(txt, [(CT[k][0] + DELTA, CT[k][1] + DELTA, CH[k][2]) for k in ks])))
SUBS = sub_items(SUBL, 1605)

def body_surface(buf):
    return cairo.ImageSurface.create_for_data(buf, cairo.FORMAT_ARGB32, W, H, W * 4)
def post_body(c, t):
    fl = 1 - ramp(t, T_TR, T_TR + 0.32)
    if fl > 0.01: c.set_source_rgba(1, 1, 1, fl); c.paint()
    draw_subs(c, t, SUBS)

if A.snaps:
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for ts in [float(x) for x in A.snaps.split(",")]:
        if ts < T_TR: hook_frame(c, ts); surf2pil(surf).save(f"{SCR}/fff_{ts:05.2f}.png")
        else:
            raw = run(["ffmpeg", "-v", "error", "-ss", f"{ts - DELTA:.3f}", "-i", f"{D0}/fff_v1.mp4", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "bgra", "-"])
            buf = bytearray(raw); s2 = body_surface(buf); c2 = cairo.Context(s2); post_body(c2, ts); surf2pil(s2).save(f"{SCR}/fff_{ts:05.2f}.png")
    print("snaps in", SCR); sys.exit(0)

def build_audio():
    t0 = time.time()
    # ---------------- audio: hook + body VO, original audio.py with shifted cues
    vo_old = load(f"{D0}/vo/vo.wav"); body_lvl = active_db(vo_old[int(CUT_A * SR):])
    yA, vm = matched_hook("A", "fff", body_lvl)
    n = int(T_END * SR) + 1; vo = np.zeros(n)
    place(vo, yA, LEAD); body = vo_old[int(CUT_A * SR):].copy(); f_ = int(0.01 * SR); body[:f_] *= np.linspace(0, 1, f_); place(vo, body, CUT_A + DELTA)
    vo_path = f"{SCR}/fff_v3_vo.wav"; import soundfile as sf; sf.write(vo_path, vo.astype(np.float32), SR, subtype="FLOAT")
    def sh(v): return [sh(x) for x in v] if isinstance(v, list) else (v + DELTA if isinstance(v, (int, float)) else v)
    cue = {k: sh(v) for k, v in CUE0.items()}; cue["B"][0] = 0.0; cue["T_END"] = T_END
    cue["HEART"][0] = T_NOTH + 0.05; cue["HOOK"] = dict(ask=T_ASK + 0.15, and_=T_AND_H, noth=T_NOTH, tr=T_TR)
    cue_path = f"{SCR}/fff_v3_cues.json"; json.dump(cue, open(cue_path, "w"))
    mix_path = f"{SCR}/fff_v3_mix.wav"
    run(["nice", "-n", "15", "python3", f"{RH}/fff_audio.py", cue_path, vo_path, mix_path])
    st = load_stereo = None
    mix = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", mix_path, "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"]), np.float32).reshape(-1, 2).T.astype(np.float64)
    m4a = f"{SCR}/fff_v3.m4a"; J = finish_audio(mix, m4a); os.remove(mix_path); os.remove(vo_path)
    print("audio", J["input_i"], "->", m4a, round(time.time() - t0), "s", flush=True)
    return m4a, J

if A.audio:
    m4a, J = build_audio(); remux(OUT, m4a, OUT); os.remove(m4a)
    q = json.load(open(f"{RH}/qa_fff_v3.json")); q["loudnorm_in"] = J; json.dump(q, open(f"{RH}/qa_fff_v3.json", "w"), indent=1, ensure_ascii=False)
    print("remuxed", OUT, J["final_I"], J["final_TP"], J["steps"]); sys.exit(0)

if A.render:
    t0 = time.time()
    m4a, J = build_audio()
    # ---------------- video
    enc = Encoder(OUT, m4a, crf=19)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    FTR = int(math.ceil(T_TR * FPS - 1e-6))
    for fi in range(FTR): hook_frame(c, fi / FPS); enc.write(surf)
    dec = subprocess.Popen(["ffmpeg", "-nostdin", "-v", "error", "-i", f"{D0}/fff_v1.mp4", "-vf", f"select=gte(n\\,{FTR - DF})", "-vsync", "0",
                            "-f", "rawvideo", "-pix_fmt", "bgra", "-"], stdout=subprocess.PIPE)
    fb = W * H * 4; last = None
    for fi in range(FTR, N):
        raw = dec.stdout.read(fb)
        if len(raw) < fb: raw = last                     # hold the last frame if the source runs out (rounding)
        last = raw; buf = bytearray(raw); s2 = body_surface(buf); c2 = cairo.Context(s2); post_body(c2, fi / FPS); s2.flush(); enc.write_bgra(np.frombuffer(buf, np.uint8))
        if fi % 300 == 0: print("frame", fi, "/", N, round(time.time() - t0), "s", flush=True)
    dec.stdout.close(); dec.wait(); enc.close(); os.remove(m4a)
    print("video done", OUT, round(time.time() - t0), "s")
    json.dump(dict(DELTA=DELTA, T_TR=T_TR, T_END=T_END, HOOK=HC, CUT_A=CUT_A, VIS0=VIS0, loudnorm_in=J, body_level_db=body_lvl,
                   subs=[(round(a, 2), round(b, 2), s) for a, b, *_, s in SUBS]), open(f"{RH}/qa_fff_v3.json", "w"), indent=1, ensure_ascii=False)
