"""[v2 of trust_v3_cta2.py, 26 Oct 2026, Noam: "remove confidence vs trust, it's not clear."]
Cut: script lines 1 to 4 (the confidence / trust hook and its two example cards) and the split-screen hook animation + its SFX.
The reel now opens on the Ambition / Greed card, fully drawn at frame 0. Everything else is the cta2 build unchanged: same
Cartesia narration (vo5/trust_cta2/vo.wav, cut before "Ambition", word times from vo5/trust_cta2/words.json shifted, no new
ASR), same cards, padding rule, music, ducking and subtitles. Output trust_v3_v2.mp4.
[cta2 copy of trust_v3.py, 26 Oct 2026: new fluency card and narration line (vo5/trust_cta2, cartesia_full_trust_cta2.txt), output trust_v3_cta2.mp4]
TRUST OR CONFIDENCE (values_2) v3: the whole narration is the new Cartesia recording (cart_trust_raw.wav, cartesia_full_trust.txt)
through the house chain (vo5/trust/vo.wav, word times in vo5/trust/words.json). Visuals as v2 (moving split-screen hook: confidence
wobbles and falls, trust climbs a ladder; then the recoloured engine_v3 cards over the animated silver background). Each card now
starts at its line in the new narration (minus 0.12 s, as the engine); the engine's reading-time rule is applied to the new
pacing (silence added after a line whose card needs more time), and the hook keeps 1.1 s after its last word as v2.
usage: python3 trust_v3.py --snaps 0,1,2 | --render"""
import sys, os, re, io, json, math, argparse, subprocess, time, runpy, types
sys.path.insert(0, "/home/claude/rehook")
from rk import *
from rk import remux
import rk5, v5lib
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); A = ap.parse_args()
DV = "/home/claude/names/values_2"; OUT = f"{RH}/trust_v3_v2.mp4"; VW = f"{RH}/vo5/trust_cta2"
C = runpy.run_path(f"{DV}/cfg_v3.py"); CARDS = C["CARDS"]; MUSIC = C["MUSIC"]
_S2 = runpy.run_path("/home/claude/names/values_1/cfg_cta2.py")["SEVEN2"]; assert sum(c.get("id") == "seven" for c in CARDS) == 1
CARDS = [_S2 if c.get("id") == "seven" else c for c in CARDS]   # cta2: the new fluency card (same card as values_1 cta2)
VO0 = "/home/claude/vo_v4/out/values_2.wav"; PADDED = f"{DV}/values_2_v3_vo_padded.wav"

# ------------------------------------------------------------------ engine_v3 card code, recoloured
E = open("/home/claude/reels_v3/engine_v3.py").read()
def sect(a, b): i = E.index(a); j = E.index(b, i); return E[i:j]
code = sect("def hx(h, a=255):", "# ---------------------------------------------------------------- fonts") + \
       sect("HEEBO = {w:", "# ---------------------------------------------------------------- rules") + \
       sect("SIZE_RULE = {", "for i, c in enumerate(CARDS):") + \
       sect("EMC = {}", "# ---------------------------------------------------------------- build all cards")
def rp(a, b):
    global code; assert code.count(a) >= 1, a; code = code.replace(a, b)
rp('COLS = {"white": WHITE,', 'COLS = {"white": hx("#163260"), "slate": hx("#5B6E8C"),')
rp('"yel": YEL}', '"yel": hx("#2A88D4")}')
rp('toks.append((w_, YEL if sky else base))', 'toks.append((w_, hx("#2A88D4") if sky else base))')
rp('"src": dict(size=40, w=400, col="white"', '"src": dict(size=40, w=400, col="slate"')
rp('fill=(255, 255, 255, 18), outline=SKY[:3] + (160,), width=4)', 'fill=(255, 255, 255, 190), outline=hx("#2A88D4")[:3] + (200,), width=4)')
rp('d.rounded_rectangle([CX - 70, y, CX + 70, y + 4], 2, fill=YEL[:3] + (220,))', 'd.rounded_rectangle([CX - 70, y, CX + 70, y + 4], 2, fill=hx("#2A88D4")[:3] + (230,))')
rp('d.rounded_rectangle([CX - pw / 2, y, CX + pw / 2, y + ph], int(ph / 2), fill=hx("#0E1E3A"), outline=YEL, width=7)',
   'd.rounded_rectangle([CX - pw / 2, y, CX + pw / 2, y + ph], int(ph / 2), fill=hx("#163260"), outline=hx("#2A88D4"), width=7)')
rp('d.text((CX, y + ph / 2 + 4), k["s"], font=f, fill=col(k["col"]), anchor="mm")', 'd.text((CX, y + ph / 2 + 4), k["s"], font=f, fill=(255, 255, 255, 255), anchor="mm")')
EN = dict(W=W, H=H, FPS=FPS, SAFE0=260, SAFE1=1540, CX=540, MAXW=820, MAPY0=290, MAPH=620, ERR=[], re=re, io=io, math=math, np=np,
          Image=Image, ImageDraw=ImageDraw, ImageFont=ImageFont)
exec(compile(code, "engine_cards", "exec"), EN)

# ------------------------------------------------------------------ v2: drop lines 0..3 (confidence vs trust), re-base the narration
DROP = 4
LINES = rk5.lines_of(f"{RH}/cartesia_full_trust_cta2.txt"); WORDS0 = rk5.words_of(VW)["words"]; VO0_ = load(f"{VW}/vo.wav")
assert len(LINES) == len(CARDS)
first = [w for w in WORDS0 if w["li"] == DROP][0]["t0"]; prev_end = [w for w in WORDS0 if w["li"] == DROP - 1][-1]["t1"]
CUT = first - 0.3; assert CUT > prev_end + 0.05, (CUT, prev_end)
VO = VO0_[int(round(CUT * SR)):].copy(); fz = int(0.01 * SR); VO[:fz] *= np.linspace(0, 1, fz)
WORDS = [dict(w, li=w["li"] - DROP, t0=round(w["t0"] - CUT, 3), t1=round(w["t1"] - CUT, 3)) for w in WORDS0 if w["li"] >= DROP]
CARDS = CARDS[DROP:]; LINES = LINES[DROP:]
LAYERS = {i: pil2cairo(EN["draw_card"](CARDS[i])) for i in range(len(CARDS))}
assert not EN["ERR"], EN["ERR"]
LW = lambda li: rk5.line_words(WORDS, li)
en_words, card_text = EN["en_words"], EN["card_text"]
need_ = [max(3.0, sum(len(en_words(s_)) for s_ in card_text(c)) / 3 + 1) for c in CARDS]
pads = [0.0] * len(CARDS)
for k in range(0, len(CARDS) - 1):
    have = (LW(k + 1)[0]["t0"] - 0.12) - (max(0.0, LW(k)[0]["t0"] - 0.12) if k else 0.0)
    if need_[k] > have:
        pads[k] = round(min(1.5, need_[k] - have) + 0.05, 2); VO, WORDS = rk5.pad_after_line(VO, WORDS, k, pads[k])
segs = [(LW(k)[0]["t0"], LW(k)[-1]["t1"]) for k in range(len(CARDS))]
T0 = [0.0] + [max(0.0, s_[0] - 0.12) for s_ in segs[1:]]; T_END = max(len(VO) / SR, segs[-1][1]) + 1.6
print("cut at", round(CUT, 3), "pads", [(k, p) for k, p in enumerate(pads) if p], "T_END", round(T_END, 2))
N = int(round(T_END * FPS)); TR = 0.32
NT0 = T0; NT1 = NT0[1:] + [T_END]

# ------------------------------------------------------------------ body frames (engine card transitions over the moving silver bg)
def body_card(c, i, lt, dur, a=1.0, dy=0.0):
    if dur > 6.0: dy += 16 - 32 * ease(lt / dur)            # engine: a still card over 6 s drifts
    c.set_source_surface(LAYERS[i], 0, dy); c.paint_with_alpha(a)
def body_frame(c, t):
    bg_silver(c, t)
    k = max(j for j in range(len(NT0)) if NT0[j] <= t + 1e-9); lt = t - NT0[k]; dur = NT1[k] - NT0[k]
    if k > 0 and lt < TR:
        u = ease(lt / TR); pd = NT1[k - 1] - NT0[k - 1]
        body_card(c, k - 1, pd, pd, 1 - u); body_card(c, k, lt, dur, u, 36 * (1 - u))
    else: body_card(c, k, lt, dur)                            # card 0 is fully on screen at frame 0 (hook rule)
# subtitles: every line from the re-based word times
rk5.MAX_SUB_W = 900      # one-line pills: the cards' source line sits just above the subtitle
SUBL = [rk5.sub_line(LINES[i], LW(i)) for i in range(len(CARDS))]
SUBS = sub_items(SUBL, 1600)
def frame(fi, c, surf):
    t = fi / FPS
    body_frame(c, t); draw_subs(c, t, SUBS)

if A.snaps:
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for ts in [float(x) for x in A.snaps.split(",")]: frame(int(round(ts * FPS)), c, surf); surf2pil(surf).save(f"{SCR}/tru3v2_{ts:05.2f}.png")
    print("snaps in", SCR); sys.exit(0)

def build_audio():
    import soundfile as sf
    NS = int((T_END + 0.1) * SR); v = np.zeros(NS); place(v, VO, 0.0)
    # music + ducking exactly as engine_v3
    mu = load(MUSIC); xf = int(2 * SR); mo = mu.copy()
    while len(mo) < NS: r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:] * (1 - r) + mu[:xf] * r, mu[xf:]])
    mo = mo[:NS]; hop = int(0.02 * SR)
    fr = np.sqrt(np.convolve(v ** 2, np.ones(hop) / hop, "same") + 1e-12); act = 20 * np.log10(fr) > 20 * np.log10(np.abs(v).max() + 1e-9) - 35
    lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)) + 1e-12); lm = 20 * np.log10(np.sqrt(np.mean(mo ** 2)) + 1e-12)
    mm = np.convolve(act.astype(float), np.ones(int(0.25 * SR)), "full")[:NS] > 0
    k_ = np.ones(int(0.12 * SR)) / int(0.12 * SR); mask = np.convolve(mm.astype(float), k_, "same")
    gain = 10 ** ((lv - 10 - lm) / 20) + (10 ** ((lv - 18 - lm) / 20) - 10 ** ((lv - 10 - lm) / 20)) * mask
    out = v + mo * gain
    out = out
    fi_ = int(0.05 * SR); out[:fi_] *= np.linspace(0.3, 1, fi_); fo = int(1.5 * SR); out[-fo:] *= np.linspace(1, 0, fo)
    out = out / max(1.0, np.abs(out).max() / 0.95)
    m4a = f"{SCR}/trust_v3_v2.m4a"; J = finish_audio(np.stack([out, out]), m4a); return m4a, J

if A.render:
    t0 = time.time(); m4a, J = build_audio(); print("audio", J["final_I"], J["final_TP"], J["steps"], round(time.time() - t0), "s", flush=True)
    enc = Encoder(OUT, m4a, crf=20); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for fi in range(N):
        frame(fi, c, surf); enc.write(surf)
        if fi % 300 == 0: print("frame", fi, "/", N, round(time.time() - t0), "s", flush=True)
    enc.close(); os.remove(m4a); print("video done", OUT, round(time.time() - t0), "s")
    json.dump(dict(T_END=T_END, cut=CUT, dropped_lines=[1, 2, 3, 4], pads=pads, loudnorm=J,
                   cards=[(CARDS[i].get("id"), round(NT0[i], 2), round(NT1[i], 2)) for i in range(len(CARDS))],
                   subs=[(round(a, 2), round(b, 2), s) for a, b, *_, s in SUBS], words=WORDS), open(f"{RH}/qa_trust_v3_v2.json", "w"), indent=1, ensure_ascii=False)
