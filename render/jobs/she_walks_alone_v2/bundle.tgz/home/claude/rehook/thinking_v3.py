"""THINKING IS NOT WHAT YOU THINK v3: the whole narration is the new Cartesia recording (cart_thinking_raw.wav,
cartesia_full_thinking.txt) through the house chain (vo5/thinking/vo.wav, word times in vo5/thinking/words.json).
Visuals as v2 (the original /home/claude/thinking_paths/reel.py loaded as source and patched in memory to the silver look, quote
cards removed; moving field hook with the path that freezes), but the body is drawn at warped time: every old narration chunk
start/end is pinned to the time the same words are spoken in the new narration (scenes, cards and sfx cues land on their words).
Subtitles from the new word times.
usage: python3 thinking_v3.py --snaps 0,1,2 | --render"""
import sys, os, json, math, argparse, subprocess, time, types, inspect
sys.path.insert(0, "/home/claude/rehook")
import rk
from rk import HookText, ramp, ease, eob, win, lerp, pil2cairo, rich, N255, B255, S255, BG0, BG1, RULE, BLUE, NAVY, ICE, SCR, RH, FPS, W, H, SR
import rk5, v5lib
from rk import remux, sub_items, line_map, draw_subs, subclean, load, active_db, matched_hook, place, finish_audio, Encoder, run
import numpy as np, cairo
from PIL import Image
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); A = ap.parse_args()
D0 = "/home/claude/thinking_paths"; OUT = f"{RH}/thinking_v3.mp4"; CUE_OUT = f"{SCR}/thinking_v3_cues_old.json"; VW = f"{RH}/vo5/thinking"

# ------------------------------------------------------------------ load + patch the original reel code
sys.path.insert(0, "/home/claude/gap"); import common as GC
src = open(f"{D0}/reel.py").read()
def sub(a, b, cnt=1):
    global src; assert src.count(a) == cnt, (src.count(a), a[:80]); src = src.replace(a, b)
sub('ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--sheet"); ap.add_argument("--qa", action="store_true"); ap.add_argument("--render", action="store_true")\nA = ap.parse_args()',
    'A = types.SimpleNamespace(snaps=None, sheet=None, qa=False, render=False)')
sub('json.dump(CUES, open(f"{D}/cues.json", "w"))', 'json.dump(CUES, open(CUE_OUT, "w"))')
sub('    (0.0, 3.35, [("head", "Thinking is the\\n*hardest work*\\nthere is.", 124), ("he", "לחשוב זו העבודה הקשה ביותר.", 66)], 0),\n', '')
sub('    (3.35, 8.45, [("body", "...which is probably\\nwhy *so few*\\npeople do it.", 84), ("small", "Henry Ford (attributed)", 44), ("he", "אולי לכן כל כך מעטים עושים את זה.", 62)], 0),\n', '')
# silver veil (same alpha profile as the navy one), lighter bottom fade
sub('''    g = cairo.LinearGradient(0, 0, 0, 900); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 0.97)
    g.add_color_stop_rgba(0.70, *NAVY[:3], 0.82); g.add_color_stop_rgba(0.80, *NAVY[:3], 0.45); g.add_color_stop_rgba(0.93, *NAVY[:3], 0); c.set_source(g); c.rectangle(0, 0, W, 900); c.fill()
    g = cairo.LinearGradient(0, 1500, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 0); g.add_color_stop_rgba(1, *NAVYD[:3], 0.7); c.set_source(g); c.rectangle(0, 1500, W, 420); c.fill()''',
    '''    S0_, S1_ = SV_BG0, SV_BG1; mid = tuple(lerp(a_, b_, 0.6) for a_, b_ in zip(S0_, S1_))
    g = cairo.LinearGradient(0, 0, 0, 900); g.add_color_stop_rgba(0, *S0_[:3], 1); g.add_color_stop_rgba(0.55, *mid[:3], 0.97)
    g.add_color_stop_rgba(0.70, *S1_[:3], 0.84); g.add_color_stop_rgba(0.80, *S1_[:3], 0.48); g.add_color_stop_rgba(0.93, *S1_[:3], 0); c.set_source(g); c.rectangle(0, 0, W, 900); c.fill()
    for k_, (bx_, by_, br_) in enumerate(((250, 260, 420), (860, 520, 380))):
        rg = cairo.RadialGradient(bx_, by_, 0, bx_, by_, br_); rg.add_color_stop_rgba(0, 1, 1, 1, 0.45); rg.add_color_stop_rgba(1, 1, 1, 1, 0); c.set_source(rg); c.arc(bx_, by_, br_, 0, 6.3); c.fill()
    c.set_source_rgba(*SV_RULE[:3], 0.7); c.set_line_width(2); c.move_to(70, 215); c.line_to(1010, 215); c.stroke(); c.set_source_rgba(*SV_BLUE[:3], 1); c.rectangle(70, 211, 64, 8); c.fill()
    g = cairo.LinearGradient(0, 1500, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 0); g.add_color_stop_rgba(1, *NAVYD[:3], 0.45); c.set_source(g); c.rectangle(0, 1500, W, 420); c.fill()''')
sub('''        g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 0.94 * u); g.add_color_stop_rgba(0.55, *NAVY[:3], 0.9 * u); g.add_color_stop_rgba(1, *ROYAL[:3], 0.85 * u)''',
    '''        g = cairo.LinearGradient(0, 0, W * 0.25, H); g.add_color_stop_rgba(0, *SV_BG0[:3], 0.97 * u); g.add_color_stop_rgba(1, *SV_BG1[:3], 0.97 * u)''')
sub('def frame(fi):\n    t = fi / FPS\n', 'def frame(fi, t=None):\n    t = fi / FPS if t is None else t\n')
# silver caption + end card: the gap/common functions with the colours swapped (white -> navy, yellow -> blue, CTA pill white on navy)
cap_src = inspect.getsource(GC.caption).replace("(255, 213, 74, 255) if yel", "SV_B255 if yel").replace("(255, 255, 255, 255)", "SV_N255")
assert "SV_B255" in cap_src
end_src = inspect.getsource(GC.end_card)
end_src = end_src.replace("fill=(14, 30, 58, 255), outline=(255, 213, 74, 255), width=7)", "fill=SV_N255, outline=SV_B255, width=7)")
end_src = end_src.replace('d.text((540, y + ph / 2 + 4), ln, font=f, fill=(255, 213, 74, 255), anchor="mm")', 'd.text((540, y + ph / 2 + 4), ln, font=f, fill=SV_W255, anchor="mm")')
end_src = end_src.replace("(255, 213, 74, 255) if yel", "SV_B255 if yel").replace("(255, 255, 255, 255)", "SV_N255").replace("fill=(255, 255, 255, 18)", "fill=(255, 255, 255, 170)")
end_src = end_src.replace('fill=SV_N255, anchor="mm")\n            if CX', 'fill=(255, 255, 255, 255), anchor="mm")\n            if CX')
sub("# ================================================================ text pieces", cap_src + "\n" + end_src + "\n# ================================================================ text pieces")
M = types.ModuleType("thk"); M.__dict__.update(dict(types=types, CUE_OUT=CUE_OUT, SV_BG0=BG0, SV_BG1=BG1, SV_RULE=RULE, SV_BLUE=BLUE, SV_N255=N255, SV_B255=B255, SV_W255=(255, 255, 255, 255),
                                                    __file__=f"{D0}/reel.py"))
cwd = os.getcwd(); exec(compile(src, "thk_patched", "exec"), M.__dict__)
SEG, WD, T_END0 = M.SEG, M.WD, M.T_END
assert all(c[0] >= 8.4 for c in M.CARDS), "quote cards still present"

# ------------------------------------------------------------------ new narration + warp (old body time <- new time)
LINES = rk5.lines_of(f"{RH}/cartesia_full_thinking.txt"); WORDS = rk5.words_of(VW)["words"]; VO = load(f"{VW}/vo.wav")
LW = lambda li: rk5.line_words(WORDS, li)
gap = LW(1)[0]["t0"] - LW(0)[-1]["t1"]
if gap < 0.5: VO, WORDS = rk5.pad_after_line(VO, WORDS, 0, round(0.5 - gap, 3))     # at least 0.5 s after the hook line (as v2)
OLD_CH = [tuple(c) for i_ in range(2, 16) for c in WD[i_]]                          # old lines 2..15 = new lines 1..14
oldw = v5lib.old_word_times(LINES[1:], OLD_CH); neww = [w for w in WORDS if w["li"] >= 1]; assert len(oldw) == len(neww)
f_old, g_new, PAIRS = v5lib.warp_from_pairs(rk5.chunk_anchors(oldw, neww, OLD_CH))
VIS0 = 8.45; T_TR = g_new(VIS0); T_END = g_new(T_END0); N = int(round(T_END * FPS))
T_WHAT = v5lib.phrase_time(WORDS, 0, "what do you think,"); T_ENG = v5lib.phrase_time(WORDS, 0, "in English,"); T_FRZ = v5lib.phrase_time(WORDS, 0, "why do you freeze?")
HOOK_END = LW(0)[-1]["t1"]
print(f"hook {LW(0)[0]['t0']:.2f}..{HOOK_END:.2f}  what {T_WHAT:.2f} eng {T_ENG:.2f} freeze {T_FRZ:.2f}  body from {T_TR:.2f}  T_END {T_END:.2f}")
assert T_TR > HOOK_END + 0.2
HT = HookText("למה אתם קופאים כששואלים אתכם\nבאנגלית 'מה אתה חושב?'", 58,
              [(0.0, "When someone\nasks you,", 124), (T_WHAT - 0.05, "*\"What do you\nthink?\"*", 124), (T_ENG - 0.05, "in English,", 124),
               (T_FRZ - 0.05, "why do you\n*freeze?*", 132)], y_he=262)
def bub_right(lines, sz=56):
    from PIL import ImageDraw
    f = rk.font(sz, 800); tw = max(f.getlength(l) for l in lines); lh = sz * 1.2; pw, ph = int(tw + 64), int(lh * len(lines) + 36)
    im = Image.new("RGBA", (pw + 20, ph + 60), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([10, 10, 10 + pw, 10 + ph], 32, fill=(255, 255, 255, 248))
    d.polygon([(pw - 90, ph + 6), (pw - 40, ph + 6), (pw + 14, ph + 54)], fill=(255, 255, 255, 248))
    for j, l in enumerate(lines): d.text((10 + pw / 2, 10 + 18 + lh * (j + 0.5)), l, font=f, fill=N255, anchor="mm")
    return pil2cairo(im)
BUBQ = bub_right(["So, what do", "you think?"])
FROST, FDIST = M.__dict__.get("FROST"), None
def make_frost():
    from PIL import ImageDraw, ImageFilter
    rng = np.random.default_rng(11); im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    def branch(x, y, ang, ln, dep):
        if dep == 0 or ln < 8: return
        x2, y2 = x + ln * math.cos(ang), y + ln * math.sin(ang); d.line([(x, y), (x2, y2)], fill=(225, 246, 255, int(120 + 25 * dep)), width=max(1, dep))
        for s_ in (-1, 1):
            if rng.random() < 0.8: branch(x + (x2 - x) * 0.5, y + (y2 - y) * 0.5, ang + s_ * (0.6 + 0.3 * rng.random()), ln * 0.5, dep - 1)
        branch(x2, y2, ang + 0.3 * (rng.random() - 0.5), ln * 0.75, dep - 1)
    for (cx, cy) in ((0, 860), (W, 860), (0, H), (W, H), (0, 1400), (W, 1400)):
        for k in range(8): branch(cx, cy, math.atan2(1250 - cy, 540 - cx) + (rng.random() - 0.5) * 2.0, 120 + 100 * rng.random(), 6)
    out = Image.alpha_composite(im.filter(ImageFilter.GaussianBlur(4)), im)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dist = np.minimum.reduce([np.hypot(xx - cx, (yy - cy) * 0.75) for cx, cy in ((0, 860), (W, 860), (0, H), (W, H), (0, 1400), (W, 1400))])
    return np.asarray(out).astype(np.float32), dist
FROST, FDIST = make_frost(); _fc = {}
def frost_surf(rad):
    k = int(rad / 12)
    if k not in _fc:
        a = FROST.copy(); a[:, :, 3] *= np.clip((k * 12 - FDIST) / 120, 0, 1); _fc.clear(); _fc[k] = pil2cairo(Image.fromarray(a.astype(np.uint8), "RGBA"))
    return _fc[k]
P = M.P_NEW; LIGHTB = rk.hx("#8FD3FF")
def hook_frame(c, t):
    c.set_source_surface(M.FIELD_A, 0, 0); c.paint()
    c.set_source_surface(M.SHIM, -((t * 18) % 200), -((t * 34) % 600)); c.paint_with_alpha(0.9)
    frz = ramp(t, T_FRZ, T_FRZ + 0.5); out = ramp(t, T_TR - 0.35, T_TR + 0.05)
    # the new path, already drawing at frame 0, stalls and ices over on "freeze"
    u = lerp(0.14, 0.86, ease(min(1.0, t / (T_FRZ + 0.1))))
    col = tuple(lerp(a_, b_, frz) for a_, b_ in zip(LIGHTB, ICE))
    flick = 1 - 0.35 * frz * (0.5 + 0.5 * math.sin(t * 31))
    M.glow_line(c, P, 0.04, u, col, (1 - out) * flick, 8)
    pt, _ = M.at_u(P, u)
    if out < 1:
        M.glow(c, *pt, 70, (1, 1, 1, 1) if frz < 0.5 else ICE, 0.85 * (1 - out) * (1 - 0.5 * frz))
        c.set_source_rgba(1, 1, 1, 1 - out); c.arc(*pt, 10, 0, 2 * math.pi); c.fill()
    M.draw_tufts(c, M.TU_A, t, 1.0, [])
    jit = 3.5 * math.sin(t * 53) * frz * (1 - out)
    M.figure(c, M.S0[0] + jit, M.S0[1], 1.0, t, 0.0, 1.0, M.WHITE if frz < 0.5 else ICE)
    qa = win(t, T_WHAT - 0.6, T_FRZ + 0.6, 0.22, 0.35)
    if qa > 0.01: rk.paste(c, BUBQ, 1010 + 6 * math.sin(t * 2), 1010, qa, eob(min(1, (t - T_WHAT + 0.6) / 0.3)), "br")
    rad = lerp(0, 460, ramp(t, T_FRZ - 0.05, T_TR - 0.2))
    if rad > 12: c.set_source_surface(frost_surf(rad), 0, 0); c.paint_with_alpha(0.55 * (1 - out))
    c.set_source_surface(M.VEIL, 0, 0); c.paint()
    hb = 1 - ramp(t, T_TR - 0.3, T_TR)      # taller silver band behind the 2-line hook text
    if hb > 0.01:
        g = cairo.LinearGradient(0, 520, 0, 860); g.add_color_stop_rgba(0, *BG1[:3], 0.0); g.add_color_stop_rgba(0.25, *BG1[:3], 0.55 * hb); g.add_color_stop_rgba(0.62, *BG1[:3], 0.5 * hb); g.add_color_stop_rgba(1, *BG1[:3], 0); c.set_source(g); c.rectangle(0, 520, W, 340); c.fill()
    HT.render(c, t, 1 - ramp(t, T_TR - 0.25, T_TR + 0.05))

# ------------------------------------------------------------------ subtitles: body lines 1..14, from the new word times
SUBL = [rk5.sub_line(LINES[li], LW(li)) for li in range(1, len(LINES))]
SUBS = sub_items(SUBL, 1600)
def frame_new(fi, c_surf=None):
    t = fi / FPS
    if t < T_TR:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s); hook_frame(c, t)
    else:
        s = M.frame(0, t=f_old(t)); c = cairo.Context(s)
    draw_subs(c, t, SUBS); s.flush(); return s

if A.snaps:
    for ts in [float(x) for x in A.snaps.split(",")]:
        rk.surf2pil(frame_new(int(round(ts * FPS)))).save(f"{SCR}/thk3_{ts:05.2f}.png")
    print("snaps in", SCR); sys.exit(0)

def build_audio():
    t0 = time.time()
    n = int(T_END * SR) + 1; vo = np.zeros(n); place(vo, VO, 0.0)
    import soundfile as sf
    vo_path = f"{SCR}/thinking_v3_vo.wav"; sf.write(vo_path, vo.astype(np.float32), SR, subtype="FLOAT")
    C0 = json.load(open(CUE_OUT))
    def mp(v): return [mp(x) for x in v] if isinstance(v, list) else (round(g_new(v), 4) if isinstance(v, (int, float)) else v)
    cue = {k: mp(v) for k, v in C0.items()}; cue["T_END"] = T_END
    cue["HOOK"] = dict(what=T_WHAT - 0.6, freeze=T_FRZ, tr=T_TR, draw=[0.15 + 0.32 * k for k in range(int(T_FRZ / 0.32))])
    cue_path = f"{SCR}/thinking_v3_cues.json"; json.dump(cue, open(cue_path, "w"))
    mix_path = f"{SCR}/thinking_v3_mix.wav"
    run(["nice", "-n", "15", "python3", f"{RH}/thinking_audio.py", cue_path, vo_path, mix_path])
    mix = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", mix_path, "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"]), np.float32).reshape(-1, 2).T.astype(np.float64)
    m4a = f"{SCR}/thinking_v3.m4a"; J = finish_audio(mix, m4a); os.remove(mix_path); os.remove(vo_path)
    print("audio", J["final_I"], J["final_TP"], J["steps"], round(time.time() - t0), "s", flush=True)
    return m4a, J

if A.render:
    t0 = time.time()
    m4a, J = build_audio()
    enc = Encoder(OUT, m4a, crf=19)
    for fi in range(N):
        enc.write(frame_new(fi))
        if fi % 300 == 0: print("frame", fi, "/", N, round(time.time() - t0), "s", flush=True)
    enc.close(); os.remove(m4a); print("video done", OUT, round(time.time() - t0), "s")
    json.dump(dict(T_TR=T_TR, T_END=T_END, hook=dict(what=T_WHAT, eng=T_ENG, frz=T_FRZ, end=HOOK_END), warp_pairs=PAIRS, loudnorm=J,
                   subs=[(round(a, 2), round(b, 2), s) for a, b, *_, s in SUBS], words=WORDS), open(f"{RH}/qa_thinking_v3.json", "w"), indent=1, ensure_ascii=False)
