"""[cta2 copy of fff_v4.py, 26 Oct 2026: new fluency line + card, see the cta2 block; output fff_v4_cta2.mp4]
FIGHT, FLIGHT, FREEZE v4: the whole narration is the new Cartesia recording (cart_fff_raw.wav, cartesia_full_fff.txt) through the
house chain (vo5/fff/vo.wav, word times in vo5/fff/words.json). Visuals as v3: the moving silver hook (head, thought cloud that blanks
on "nothing", alarm, zoom + white flash), then the original body drawn straight from /home/claude/fff/reel.py (loaded as source and
patched in memory, nothing in that folder is written) at warped time: every old narration chunk start/end is pinned to the time the
same words are spoken in the new narration, so each scene, caption and sfx cue lands on its words. Subtitles from the new word times.
usage: python3 fff_v4.py --snaps 0,1,2 | --render"""
import sys, os, json, math, argparse, subprocess, time, types
sys.path.insert(0, "/home/claude/rehook")
from rk import *
import rk5, v5lib
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); A = ap.parse_args()
D0 = "/home/claude/fff"; OUT = f"{RH}/fff_v4_cta2.mp4"; VW = f"{RH}/vo5/fff"; CUE_OUT = f"{SCR}/fff_v4c2_cues_old.json"

# ------------------------------------------------------------------ original reel (old timeline), patched in memory
src = open(f"{D0}/reel.py").read()
def sub(a, b):
    global src; assert src.count(a) == 1, a[:80]; src = src.replace(a, b)
sub('ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); ap.add_argument("--resume", action="store_true")\nA = ap.parse_args()',
    'A = types.SimpleNamespace(snaps=None, render=False, resume=False)')
sub('json.dump(CUES, open(f"{D}/cues.json", "w"))', 'json.dump(CUES, open(CUE_OUT, "w"))')
sub('def frame(fi):\n    t = fi / FPS\n', 'def frame(fi, t=None):\n    t = fi / FPS if t is None else t\n')
sys.path.insert(0, D0)
M = types.ModuleType("fff_old"); M.__dict__.update(dict(types=types, CUE_OUT=CUE_OUT, __file__=f"{D0}/reel.py"))
exec(compile(src, "fff_patched", "exec"), M.__dict__)
CT0, CH0, T_END0 = M.CT, M.CH, M.T_END
OLD_CH = [(CT0[k][0], CT0[k][1], CH0[k][2]) for k in range(len(CH0))]

# ------------------------------------------------------------------ new narration
LINES = rk5.lines_of(f"{RH}/cartesia_full_fff.txt"); WJ = rk5.words_of(VW); WORDS = WJ["words"]
VO = load(f"{VW}/vo.wav")
# gap hook -> body: at least 0.5 s after "nothing." (as v3), padded with silence if the recording runs on
gap = rk5.line_words(WORDS, 1)[0]["t0"] - rk5.line_words(WORDS, 0)[-1]["t1"]
if gap < 0.5: VO, WORDS = rk5.pad_after_line(VO, WORDS, 0, round(0.5 - gap, 3))
LW = lambda li: rk5.line_words(WORDS, li)
# warp: old body chunks 2.. (from "and your brain hears") <-> the same words in the new narration (new lines 1..14 = old lines 1..14)
BODY_LINES = LINES[1:]
oldw = v5lib.old_word_times(BODY_LINES, OLD_CH[2:]); neww = [w for w in WORDS if w["li"] >= 1]
assert len(oldw) == len(neww)
f_old, g_new, PAIRS = v5lib.warp_from_pairs(rk5.chunk_anchors(oldw, neww, OLD_CH[2:]))

T_AND = CT0[2][0]; T_DANGER0 = T_AND - 0.15; VIS0 = T_DANGER0 + 0.32
T_TR = g_new(VIS0); T_END = g_new(T_END0); N = int(round(T_END * FPS))
# ------------------------------------------------------------------ cta2 (26 Oct 2026): the fluency line (line 13) swapped for the new CTA clip.
# The v4 timeline is mapped by h: identity before the old CTA, the CTA span stretched to the new clip, everything after shifted by delta.
sys.path.insert(0, "/home/claude/cta_v2"); import cta2lib as CL
_li = 13; _lw = LW(_li); _pv = LW(_li - 1); _nx = LW(_li + 1); assert "fluency" in " ".join(w["w"] for w in _lw)
_R = CL.splice(VO, SR, _pv[-1]["t1"], _lw[0]["t0"], _lw[-1]["t1"], _nx[0]["t0"])
VO = _R["vo"]; _cA, _cB, _dl = _R["cA"], _R["cB"], _R["delta"]
_nw = [dict(li=_li, w=w["w"], t0=w["t0"], t1=w["t1"], ok=True, heard=w["w"]) for w in CL.new_words(_R["off"])]
WORDS = [w for w in WORDS if w["li"] < _li] + _nw + [dict(w, t0=round(w["t0"] + _dl, 3), t1=round(w["t1"] + _dl, 3)) for w in WORDS if w["li"] > _li]
LINES = list(LINES); LINES[_li] = CL.NEW_ONE
_f_old0, _g_new0 = f_old, g_new
f_old = lambda t: _f_old0(CL.hinv(t, _cA, _cB, _dl)); g_new = lambda t: CL.hmap(_g_new0(t), _cA, _cB, _dl)
T_END = CL.hmap(T_END, _cA, _cB, _dl); N = int(round(T_END * FPS))
M.CARD7 = M.pil2cairo(M.end_card([("emoji", "23f1", 104), ("head", "Want *fluency?*", 120), ("he", "רוצים שטף?", 58),
                                  ("body", "Talk to yourself in English for *7 minutes* on WhatsApp", 64), ("he", "דברו עם עצמכם באנגלית\n7 דקות בוואטסאפ", 56),
                                  ("body", "Then explain the same idea to a friend", 64), ("he", "ואז תסבירו את אותו רעיון לחבר", 56)]))
print(f"cta2: old CTA {_lw[0]['t0']:.2f}..{_lw[-1]['t1']:.2f}, splice {_cA:.2f}..{_cB:.2f}, delta {_dl:+.2f}, gain {_R['gain_db']} dB, T_END {T_END:.2f}")
L0 = LW(0)
T_ASK = v5lib.phrase_time(WORDS, 0, "Someone"); T_AND_H = v5lib.phrase_time(WORDS, 0, "And..."); T_NOTH = v5lib.phrase_time(WORDS, 0, "nothing.")
HOOK_END = L0[-1]["t1"]
print(f"hook {L0[0]['t0']:.2f}..{HOOK_END:.2f}  ask {T_ASK:.2f} and {T_AND_H:.2f} nothing {T_NOTH:.2f}  body from {T_TR:.2f} (old {VIS0:.2f})  T_END {T_END:.2f}")
assert T_TR > HOOK_END + 0.2

# ------------------------------------------------------------------ hook drawing (v3, unchanged apart from the cue times)
HT = HookText("יודעים את המילים.\nואז שואלים אתכם באנגלית... ושקט.", 58,
              [(0.0, "You know\nthe *words.*", 128), (T_ASK - 0.05, "Someone asks you\na question in *English.*", 100),
               (T_AND_H - 0.05, "And...", 140), (T_NOTH - 0.04, "*nothing.*", 156)], y_he=262)
WORDS_C = [("presentation", 44, -140, -50), ("I think that...", 44, 150, -58), ("the budget", 44, -120, 48), ("next quarter", 44, 150, 52)]
WS = [pil2cairo(rich(s, sz, 800, B255 if k % 2 == 0 else N255)) for k, (s, sz, _, _) in enumerate(WORDS_C)]
def bub_img(lines, sz=50):
    f = font(sz, 800); tw = max(f.getlength(l) for l in lines); lh = sz * 1.2; pw, ph = int(tw + 64), int(lh * len(lines) + 36)
    im = Image.new("RGBA", (pw + 20, ph + 60), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([10, 10, 10 + pw, 10 + ph], 30, fill=(255, 255, 255, 255), outline=N255, width=5)
    d.polygon([(pw - 70, ph + 6), (pw - 20, ph + 6), (pw + 4, ph + 52)], fill=(255, 255, 255, 255), outline=None)
    d.line([(pw - 70, ph + 8), (pw + 4, ph + 52), (pw - 20, ph + 8)], fill=N255, width=5)
    for j, l in enumerate(lines): d.text((10 + pw / 2, 10 + 18 + lh * (j + 0.5)), l, font=f, fill=N255, anchor="mm")
    return pil2cairo(im)
BUB = bub_img(["So, what do", "you think?"])
CX, CY = 540, 1290
def cloud_path(c, x, y, w, h):
    pts = [(-0.12, 0.03, 0.42), (0.14, 0.03, 0.42), (-0.36, 0.12, 0.30), (-0.16, -0.18, 0.36), (0.12, -0.22, 0.38), (0.36, -0.02, 0.32), (0.28, 0.22, 0.28), (0.0, 0.26, 0.30), (-0.26, 0.26, 0.26)]
    for px, py, r in pts: c.new_sub_path(); c.arc(x + px * w, y + py * h * 1.3, r * h, 0, 2 * math.pi)
def brain_icon(c, x, y, s, a, col=BLUE):
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.scale(s, s)
    c.move_to(-95, 20); c.curve_to(-120, -40, -70, -85, -20, -70); c.curve_to(10, -95, 70, -85, 85, -45); c.curve_to(125, -25, 115, 40, 70, 48)
    c.curve_to(40, 70, -10, 68, -30, 52); c.curve_to(-70, 70, -110, 55, -95, 20); c.close_path()
    fill(c, (0.93, 0.95, 0.99), a); c.fill_preserve(); stroke(c, col, 7, a); c.stroke()
    for p in ((-55, -40, -30, -5, -50, 25), (0, -60, 20, -20, -5, 15), (45, -50, 70, -10, 45, 25)):
        c.move_to(p[0], p[1]); c.curve_to(p[2], p[3] - 10, p[2], p[3] + 10, p[4], p[5]); stroke(c, col, 5, a * 0.8); c.stroke()
    c.move_to(0, 50); c.line_to(0, 90); stroke(c, col, 9, a); c.stroke(); c.restore()
def hook_frame(c, t):
    bg_silver(c, t)
    alarm = ramp(t, T_NOTH - 0.02, T_NOTH + 0.12)
    pulse = 0.5 + 0.5 * math.sin((t - T_NOTH) * 2 * math.pi * 2.2)
    z = ramp(t, T_TR - 0.42, T_TR)
    c.save(); zs = 1 + 1.9 * z ** 2; c.translate(CX, CY - 90); c.scale(zs, zs); c.translate(-CX, -(CY - 90))
    if alarm > 0.01:
        g = cairo.RadialGradient(540, 1150, 420, 540, 1150, 1150); g.add_color_stop_rgba(0, *RED[:3], 0); g.add_color_stop_rgba(1, *RED[:3], 0.30 * alarm * (0.55 + 0.45 * pulse))
        c.set_source(g); c.paint()
    bob = 6 * math.sin(t * 2.3); shake = 5 * math.sin(t * 47) * alarm * (1 - z)
    hx_, hy_ = CX + shake, CY + bob
    rr(c, hx_ - 270, hy_ + 190, 540, 260, 120); fill(c, NAVY); c.fill()
    rr(c, hx_ - 60, hy_ + 150, 120, 70, 20); fill(c, (0.86, 0.88, 0.92)); c.fill()
    if alarm > 0.01:
        for k in range(3):
            u = ((t - T_NOTH) / 0.75 + k / 3) % 1; stroke(c, RED, 8 * (1 - u) + 2, alarm * (1 - u) * 0.8); c.arc(hx_, hy_ - 40, 230 + 260 * u, 0, 2 * math.pi); c.stroke()
    c.save(); c.translate(hx_, hy_); c.scale(1, 1.08); c.arc(0, 0, 200, 0, 2 * math.pi); c.restore()
    fill(c, PAPER); c.fill_preserve(); stroke(c, NAVY, 10); c.stroke()
    ba = max(0.0, ramp(t, T_AND_H - 0.1, T_AND_H + 0.3) * 0.55, alarm)
    if ba > 0.01:
        brain_icon(c, hx_, hy_ - 128, 0.74, ba, RED if alarm > 0.5 else BLUE)
        if alarm > 0.01:
            glow(c, hx_ - 18, hy_ - 112, 110, RED, 0.55 * alarm * (0.5 + 0.5 * pulse))
            fill(c, RED, alarm); c.arc(hx_ - 18, hy_ - 112, 13 + 5 * pulse, 0, 2 * math.pi); c.fill()
    wide = ramp(t, T_NOTH - 0.05, T_NOTH + 0.2); blink = 1.0 if (t % 2.6) > 0.12 or wide > 0.5 else 0.12
    for sx in (-1, 1):
        ex, ey = hx_ + sx * 72, hy_ + 18
        if wide > 0.01: fill(c, PAPER); c.arc(ex, ey, 26 * wide, 0, 2 * math.pi); c.fill_preserve(); stroke(c, NAVY, 5, wide); c.stroke()
        c.save(); c.translate(ex, ey); c.scale(1, blink); fill(c, NAVY); c.arc(0, 0, lerp(17, 11, wide), 0, 2 * math.pi); c.fill(); c.restore()
        by_ = ey - 52 - 20 * wide; stroke(c, NAVY, 9); c.move_to(ex - 30, by_ + 6 - sx * 4 * (1 - wide)); c.line_to(ex + 30, by_ + 6 + sx * 4 * (1 - wide) - 8 * wide); c.stroke()
    my = hy_ + 100
    if wide < 0.5:
        stroke(c, NAVY, 9); c.move_to(hx_ - 50, my); c.curve_to(hx_ - 20, my + 22, hx_ + 20, my + 22, hx_ + 50, my); c.stroke()
    else:
        c.save(); c.translate(hx_, my + 8); c.scale(1, 1.3); c.arc(0, 0, 16, 0, 2 * math.pi); c.restore(); fill(c, NAVY); c.fill()
    if alarm > 0.01:
        u = ((t - T_NOTH) * 0.9) % 1; dx, dy = hx_ + 175, hy_ - 70 + 70 * u
        c.move_to(dx, dy - 24); c.curve_to(dx + 16, dy, dx + 14, dy + 16, dx, dy + 16); c.curve_to(dx - 14, dy + 16, dx - 16, dy, dx, dy - 24); fill(c, BLUE, alarm * (1 - u)); c.fill()
    cx_, cy_ = 620 + 4 * math.sin(t * 1.3), 905 + 6 * math.sin(t * 1.7); cw_, chh = 640, 250
    sc_c = lerp(0.94, 1.0, eob(min(1, (t + 0.25) / 0.5)))
    c.save(); c.translate(cx_, cy_); c.scale(sc_c, sc_c); c.translate(-cx_, -cy_)
    for k, (dx, dy, r) in enumerate(((hx_ + 90, hy_ - 228, 14), (hx_ + 120, hy_ - 268, 22))):
        fill(c, PAPER); c.arc(dx, dy, r, 0, 2 * math.pi); c.fill_preserve(); stroke(c, NAVY, 5); c.stroke()
    if alarm > 0.01: glow(c, cx_, cy_, 380, (1, 1, 1), 0.9 * alarm)
    cloud_path(c, cx_, cy_, cw_, chh); fill(c, PAPER); c.fill()
    cloud_path(c, cx_, cy_, cw_, chh); stroke(c, NAVY, 6, 1 - 0.75 * alarm); c.stroke()
    cloud_path(c, cx_, cy_, cw_, chh); fill(c, PAPER); c.fill()
    for k, (s, sz, ox, oy) in enumerate(WORDS_C):
        sc_ = 1 - alarm; ang = k * 1.7
        x = cx_ + ox + 10 * math.sin(t * 1.1 + k * 2) + 220 * alarm * math.cos(ang); y = cy_ + oy + 8 * math.sin(t * 1.4 + k) + 160 * alarm * math.sin(ang)
        paste(c, WS[k], x, y, 1 - alarm, max(0.01, sc_ * (1 + 0.15 * alarm)))
    if alarm > 0.3 and ((t - T_NOTH) * 2.2) % 1 < 0.55: fill(c, NAVY, alarm); c.rectangle(cx_ - 4, cy_ - 40, 8, 80); c.fill()
    c.restore()
    qa = win(t, T_ASK + 0.15, T_NOTH + 0.4, 0.2, 0.3)
    if qa > 0.01: paste(c, BUB, 80 + 6 * math.sin(t * 2), 1090, qa, eob(min(1, (t - T_ASK - 0.15) / 0.3)), "tl")
    c.restore()
    HT.render(c, t, 1 - ramp(t, T_TR - 0.3, T_TR - 0.05))
    fl = ramp(t, T_TR - 0.3, T_TR)
    if fl > 0.01: c.set_source_rgba(1, 1, 1, fl); c.paint()

# ------------------------------------------------------------------ subtitles: body lines 1..14, from the new word times
SUBL = [rk5.sub_line(LINES[li], LW(li)) for li in range(1, len(LINES))]
SUBS = sub_items(SUBL, 1605)
# cta2: the new CTA card is taller than the old one, so only its subtitles are one-line pills (as trust_v3); all other subtitles unchanged
_mw = rk5.MAX_SUB_W; rk5.MAX_SUB_W = 900; _S1 = sub_items(SUBL, 1605); rk5.MAX_SUB_W = _mw
_ta, _tb = _nw[0]["t0"] - 0.3, _nw[-1]["t1"] + 0.2
SUBS = sorted([x for x in SUBS if not (_ta <= x[0] < _tb)] + [x for x in _S1 if _ta <= x[0] < _tb], key=lambda x: x[0])
def post_body(c, t):
    fl = 1 - ramp(t, T_TR, T_TR + 0.32)
    if fl > 0.01: c.set_source_rgba(1, 1, 1, fl); c.paint()
    draw_subs(c, t, SUBS)
def frame_new(fi, surf, c):
    t = fi / FPS
    if t < T_TR: hook_frame(c, t); s = surf
    else: s = M.frame(0, t=f_old(t)); c2 = cairo.Context(s); post_body(c2, t)
    s.flush(); return s

if A.snaps:
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for ts in [float(x) for x in A.snaps.split(",")]: surf2pil(frame_new(int(round(ts * FPS)), surf, c)).save(f"{SCR}/fff4c2_{ts:05.2f}.png")
    print("snaps in", SCR); sys.exit(0)

def build_audio():
    import soundfile as sf
    n = int(T_END * SR) + 1; vo = np.zeros(n); place(vo, VO, 0.0)
    vo_path = f"{SCR}/fff_v4c2_vo.wav"; sf.write(vo_path, vo.astype(np.float32), SR, subtype="FLOAT")
    C0 = json.load(open(CUE_OUT))
    def mp(v): return [mp(x) for x in v] if isinstance(v, list) else (round(g_new(v), 4) if isinstance(v, (int, float)) else v)
    cue = {k: mp(v) for k, v in C0.items()}; cue["B"][0] = 0.0; cue["T_END"] = T_END
    cue["HEART"][0] = T_NOTH + 0.05; cue["HOOK"] = dict(ask=T_ASK + 0.15, and_=T_AND_H, noth=T_NOTH, tr=T_TR)
    cue_path = f"{SCR}/fff_v4c2_cues.json"; json.dump(cue, open(cue_path, "w"))
    mix_path = f"{SCR}/fff_v4c2_mix.wav"
    run(["nice", "-n", "15", "python3", f"{RH}/fff_audio.py", cue_path, vo_path, mix_path])
    mix = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", mix_path, "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"]), np.float32).reshape(-1, 2).T.astype(np.float64)
    m4a = f"{SCR}/fff_v4c2.m4a"; J = finish_audio(mix, m4a); os.remove(mix_path); os.remove(vo_path)
    return m4a, J, cue

if A.render:
    t0 = time.time(); m4a, J, cue = build_audio(); print("audio", J["final_I"], J["final_TP"], J["steps"], round(time.time() - t0), "s", flush=True)
    enc = Encoder(OUT, m4a, crf=19); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for fi in range(N):
        enc.write(frame_new(fi, surf, c))
        if fi % 300 == 0: print("frame", fi, "/", N, round(time.time() - t0), "s", flush=True)
    enc.close(); os.remove(m4a); print("video done", OUT, round(time.time() - t0), "s")
    json.dump(dict(T_TR=T_TR, T_END=T_END, hook=dict(ask=T_ASK, and_=T_AND_H, noth=T_NOTH, end=HOOK_END), warp_pairs=PAIRS, loudnorm=J,
                   subs=[(round(a, 2), round(b, 2), s) for a, b, *_, s in SUBS], words=WORDS), open(f"{RH}/qa_fff_v4_cta2.json", "w"), indent=1, ensure_ascii=False)
