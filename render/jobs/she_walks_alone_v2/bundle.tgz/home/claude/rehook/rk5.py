"""v5 build helpers shared by fff_v4.py, thinking_v3.py, trust_v3.py and the safety_v5 build: word-timed subtitles,
silence padding of the narration, old->new time warps, web encode (540x960, < 8 MB), QA (contact sheet, ebur128, ASR of the
final audio against the script, first-frame check)."""
import os, json, re, numpy as np, soundfile as sf
import sys
sys.path.insert(0, "/home/claude/rehook")
import rk, v5lib
from rk import subclean, SR

def words_of(wd):
    J = json.load(open(f"{wd}/words.json")); return J
def lines_of(txt): return [l.strip() for l in open(txt) if l.strip()]
def line_words(words, li): return [w for w in words if w["li"] == li]

def sub_line(raw, ws, nums=()):
    """script line + its word times -> (clean subtitle text, char-fraction -> time map) for rk.sub_items"""
    txt = subclean(raw, nums); toks = txt.split()
    assert len(toks) == len(ws), (txt, [w["w"] for w in ws])
    P, pos = [], 0
    for tk, w in zip(toks, ws):
        p0 = txt.index(tk, pos); p1 = p0 + len(tk); pos = p1
        P.append((p0 / len(txt), w["t0"])); P.append((p1 / len(txt), w["t1"]))
    return txt, P

def pad_after_line(vo, words, li, dur):
    """insert `dur` s of silence between line li and line li+1 (cut at the middle of the pause). returns vo, words (shifted)"""
    a = line_words(words, li)[-1]["t1"]; b = line_words(words, li + 1)[0]["t0"]; cut = (a + b) / 2
    i = int(round(cut * SR)); vo = np.concatenate([vo[:i], np.zeros(int(round(dur * SR))), vo[i:]])
    out = []
    for w in words:
        w = dict(w)
        if w["t0"] >= cut: w["t0"] = round(w["t0"] + dur, 3); w["t1"] = round(w["t1"] + dur, 3)
        out.append(w)
    return vo, out

def chunk_anchors(old_words, new_words, old_chunks):
    """old narration chunks [(a, b, text)] (old time) + per-script-word old/new times (same script indexing)
    -> warp pairs (t_new, t_old) at every old chunk start / end"""
    pairs = []
    for a, b, _ in old_chunks:
        idx = [k for k, w in enumerate(old_words) if w["t0"] >= a - 0.02 and w["t1"] <= b + 0.02]
        if not idx: continue
        pairs.append((new_words[idx[0]]["t0"], a)); pairs.append((new_words[idx[-1]]["t1"], b))
    return pairs

def web(out, web_out):
    rk.run(["nice", "-n", "15", "ffmpeg", "-nostdin", "-v", "error", "-y", "-i", out, "-vf", "scale=540:960:flags=lanczos", "-c:v", "libx264", "-preset", "slow",
            "-crf", "27", "-maxrate", "750k", "-bufsize", "1500k", "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart", web_out])   # audio stream copied: same loudness and true peak as the main file

def first_frame_check(video, box):
    """share of 'ink' pixels (dark navy or blue text) inside box (x0, y0, x1, y1) of frame 0"""
    raw = rk.run(["ffmpeg", "-v", "error", "-i", video, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
    a = np.frombuffer(raw, np.uint8).reshape(1920, 1080, 3).astype(int); x0, y0, x1, y1 = box; r = a[y0:y1, x0:x1]
    ink = ((r[:, :, 2] - r[:, :, 0] > 40) & (r.sum(2) < 500)) | (r.sum(2) < 200)
    return round(float(ink.mean()), 4)

def qa(name, video, web_out, lines, words, sheet_png, times, extra_notes=(), skip_lines=(), hook_box=(80, 230, 1000, 760)):
    web(video, web_out)
    P, PW = rk.probe(video), rk.probe(web_out); I, TP = rk.loudness(video); Iw, TPw = rk.loudness(web_out)
    heard, mism, ins, wins = v5lib.final_asr(video, words, lines)
    ink = first_frame_check(video, hook_box)
    mm = [f"{m['word']}->{m['heard'] or '(none)'} @{m['t']:.1f}" for m in mism]
    notes = [f"{os.path.basename(video)}: {P['dur']} s, {P['size_mb']} MB, {P['res']}, {P['fps']} fps, {P['sr']} Hz, {I} LUFS, {TP} dBTP  |  web {PW['res']}: {PW['size_mb']} MB, {Iw} LUFS, {TPw} dBTP",
             f"ASR of the final mix vs script: {len(mism)} mismatched word(s): " + (", ".join(mm)[:230] if mm else "none"),
             f"Extra words heard: " + (", ".join(f"{x['heard']} @{x['t']}" for x in ins)[:200] if ins else "none") + f"   |   frame 0 hook text ink share {ink}"] + list(extra_notes)
    rk.qa_sheet(video, times, sheet_png, f"QA  {name}", notes)
    return dict(main=P, web=PW, loudness=dict(I=I, TP=TP, web_I=Iw, web_TP=TPw), asr_heard=heard, asr_mismatches=mism, asr_inserted=ins,
                first_frame_ink=ink, sheet=sheet_png)

# ------------------------------------------------------------------ subtitle chunking: kit.subchunks, but a long sentence is split at
# its comma / colon nearest the middle (not mid-phrase like "a rule: a | mistake ..."), pieces stay <= 7 words where possible
_orig_subchunks = rk.subchunks
_WEAK = {"a", "an", "the", "to", "of", "and", "your", "my", "in", "on", "for", "with", "by", "is", "i", "i'll", "if", "when", "do"}
from PIL import ImageFont as _IF
_SF = _IF.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54)
MAX_SUB_W = 1700     # px of subtitle text per chunk: 1700 = up to two pill lines; a build can set 900 for one-line pills
def _fits(ws): return len(ws) <= 8 and _SF.getlength(" ".join(ws)) <= MAX_SUB_W    # at most two pill lines (rk.sub_items wraps at 920 px), kit word limit
def _subchunks_punct(s, n=7):
    """sentences (kit rules); a sentence that does not fit one pill (<= 8 words, <= 2 lines) is cut at the comma / colon
    nearest its middle, else at the most balanced point that does not end a chunk on a weak word ("the | video")"""
    out = []
    for piece in _orig_subchunks(s, 99):
        def split(ws):
            if _fits(ws) or len(ws) < 4: return [" ".join(ws)]
            L = len(" ".join(ws)); pos = lambda c: len(" ".join(ws[:c])) / L
            pc = [c for c in range(3, len(ws) - 2) if ws[c - 1][-1] in ",:;"]
            cuts = [c for c in pc if _fits(ws[:c]) and _fits(ws[c:])] or [c for c in pc if 0.25 <= pos(c) <= 0.75]
            if cuts: c = min(cuts, key=lambda c: abs(pos(c) - 0.5))
            else:
                score = lambda c: abs(pos(c) - 0.5) * 4 + (1.5 if ws[c - 1].lower().strip(",.?!") in _WEAK else 0) + (0.0 if _fits(ws[:c]) and _fits(ws[c:]) else 1.0) - (0.8 if ws[c].lower() in ("when", "but", "and", "so", "where", "that's") else 0)
                c = min(range(2, len(ws) - 1), key=score)
            return split(ws[:c]) + split(ws[c:])
        out += split(piece.split())
    return out
rk.subchunks = _subchunks_punct
