"""v5 shared voice pipeline (all-Cartesia rebuilds of fff_v4, thinking_v3, trust_v3, safety_v5).
  process(raw, script, wd): house chain (rubberband pitch 0.9715 formant preserved, bass g2 f135, clean_vo, atempo 1.1, 0.3 s lead)
      -> wd/pre_dry.wav, pre_clean.wav (pre-tempo, sample aligned), restoration of word endings clean_vo ducked (vo_fix logic:
      clean >= 4 dB under dry inside ASR speech chunks -> crossfade to the 90 Hz high-passed dry signal; then words the ASR still
      misses on the fixed voice but hears on the dry voice are force-restored from the dry chain), wd/vo.wav (final narration)
      and wd/words.json (every script word with its start/end in the final narration, from chunk ASR + DP word alignment).
  ASR: sherpa-onnx whisper turbo int8, language en, chunks from silencedetect (<= 28 s each).
  align(): script words <-> ASR words (Needleman-Wunsch on normalised tokens, numbers spelled out), word times inside a chunk
      by character share, snapped to the chunk's internal energy dips."""
import os, re, json, subprocess, difflib, numpy as np, soundfile as sf
from scipy.signal import butter, sosfiltfilt
import sys
sys.path.insert(0, "/home/claude/safety_v4")
import clean_vo as _CV
from clean_vo import clean as clean_vo
def _analyse_blocked(x, sr):
    """clean_vo.analyse with the same results, computed 600 frames at a time (the original holds ~1.5 GB for a 70 s clip)"""
    hop = int(0.01 * sr); win = int(0.03 * sr); n = max(1, (len(x) - win) // hop + 1)
    vbx = sosfiltfilt(butter(4, [80, 1000], "bp", fs=sr, output="sos"), x); hw = np.hanning(win); fr = np.fft.rfftfreq(win, 1 / sr)
    L = np.empty(n); h = np.empty(n); hm = np.empty(n)
    for s0 in range(0, n, 600):
        s1 = min(n, s0 + 600); idx = np.arange(win)[None, :] + hop * np.arange(s0, s1)[:, None]
        F = x[idx] * hw; L[s0:s1] = 10 * np.log10((F ** 2).mean(1) + 1e-12)
        vb = vbx[idx] * hw; S = np.abs(np.fft.rfft(vb, 2 * win)) ** 2
        ac = np.fft.irfft(S)[:, :win]; ac /= ac[:, :1] + 1e-12; h[s0:s1] = ac[:, int(sr / 400):int(sr / 70)].max(1)
        P = np.abs(np.fft.rfft(F)) ** 2
        mid = P[:, (fr > 300) & (fr < 2500)].sum(1) + 1e-12; hi = P[:, (fr > 2500) & (fr < min(7000, sr / 2 - 100))].sum(1) + 1e-12
        hm[s0:s1] = 10 * np.log10(hi / mid)
    return hop, win, n, L, h, hm
_CV.analyse = _analyse_blocked
from num2words import num2words
SR, TEMPO, LEAD = 48000, 1.1, 0.3
WD_ASR = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
_asr = None

def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-800:]; return r.stdout
def load(p, sr=SR):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]), np.float32).astype(np.float64)
def asr():
    global _asr
    if _asr is None:
        import sherpa_onnx
        _asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=WD_ASR + "turbo-encoder.int8.onnx", decoder=WD_ASR + "turbo-decoder.int8.onnx",
                                                          tokens=WD_ASR + "turbo-tokens.txt", language="en", task="transcribe", num_threads=2)
    return _asr
def transcribe16(x16):
    assert len(x16) <= 30 * 16000, "chunk over 30 s"
    s = asr().create_stream(); s.accept_waveform(16000, np.concatenate([x16.astype(np.float32), np.zeros(6400, np.float32)])); asr().decode_stream(s)
    return s.result.text.strip()

# ------------------------------------------------------------------ text normalisation
def spell(s):
    def one(m):
        t = m.group(0).replace(",", "")
        try:
            v = float(t); iv = int(v)
            return num2words(iv, to="year") if v == iv and 1900 <= iv <= 2099 else num2words(v if v != iv else iv)
        except Exception: return t
    s = re.sub(r"\d[\d,]*(\.\d+)?", one, s)
    return s
def norm_tokens(s):
    """-> list of normalised tokens (lower, numbers spelled, hyphens split, punctuation dropped)"""
    s = spell(s).lower().replace("-", " ").replace("’", "'")
    return [w for w in re.findall(r"[a-z0-9']+", s) if w.strip("'")]
def script_words(lines):
    """[(line_idx, surface_word, [norm tokens])] keeping each surface word (for subtitles) with its normalised tokens"""
    out = []
    for li, l in enumerate(lines):
        l = re.sub(r"\[[^\]]*\]", "", l)
        for w in l.split():
            nt = norm_tokens(w)
            out.append((li, w, nt))
    return out

# ------------------------------------------------------------------ chunks
def chunks_of(wav, noise="-38dB", d=0.22, maxlen=28.0):
    r = subprocess.run(["ffmpeg", "-nostdin", "-i", wav, "-af", f"silencedetect=noise={noise}:d={d}", "-f", "null", "-"], capture_output=True, text=True).stderr
    st = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r)]; en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r)]
    dur = float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", wav]).decode())
    b = [0.0] + [x for p in zip(st, en) for x in p] + [dur]
    if len(st) > len(en): b = b[:-1]
    ch = [(b[2 * i], b[2 * i + 1]) for i in range(len(b) // 2) if b[2 * i + 1] - b[2 * i] > 0.12]
    out = []
    for a, e in ch:
        while e - a > maxlen: out.append((a, a + maxlen)); a += maxlen
        out.append((a, e))
    return out
def asr_chunks(wav, chunks=None):
    """runs in a child process (the whisper model is the big memory user; the parent keeps only the audio arrays)"""
    import tempfile
    ch = chunks or chunks_of(wav); fd, jp = tempfile.mkstemp(suffix=".json", dir="/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"); os.close(fd)
    json.dump([list(c) for c in ch], open(jp, "w"))
    import time as _t
    def _free():
        try:
            d = "/sys/fs/cgroup/memory/process_api/01a174e0-54f2-72a1-84fc-c069b960d1c7/claude-code-bash"
            return int(open(d + "/memory.limit_in_bytes").read()) - int(open(d + "/memory.usage_in_bytes").read())
        except Exception: return 1 << 40
    for k in range(40):         # the box is shared: wait for ~2 GB of headroom, retry an out-of-memory kill of the child
        w0 = _t.time()
        while _free() < 2.1e9 and _t.time() - w0 < 300: _t.sleep(3)
        r = subprocess.run(["python3", os.path.abspath(__file__), "asr", wav, jp], capture_output=True)
        if r.returncode == 0: break
        print("asr child failed", r.returncode, r.stderr.decode()[-200:], flush=True); _t.sleep(10)
    assert r.returncode == 0
    res = json.load(open(jp)); os.remove(jp); return res
def _asr_chunks_local(wav, ch):
    x = load(wav, 16000); res = []
    for a, e in ch: res.append([round(a, 3), round(e, 3), transcribe16(x[int(a * 16000):int(e * 16000)])])
    return res

def dips(x, sr, a, e):
    """internal energy dips (>= 50 ms, 22 dB under the chunk's speech level) inside [a, e] -> [(start, end)]"""
    seg = x[int(a * sr):int(e * sr)]
    hop = int(0.01 * sr); n = len(seg) // hop
    if n < 5: return []
    L = 10 * np.log10((seg[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); ref = np.percentile(L, 90)
    low = L < ref - 22; out = []; i = 0
    while i < n:
        if low[i]:
            j = i
            while j < n and low[j]: j += 1
            if j - i >= 5 and i > 3 and j < n - 3: out.append((a + i / 100, a + j / 100))
            i = j
        else: i += 1
    return out

# ------------------------------------------------------------------ alignment
def asr_words(chunks, x=None, sr=SR):
    """ASR tokens with times: char share inside each chunk, boundaries snapped to energy dips"""
    toks = []
    for ci, (a, e, txt) in enumerate(chunks):
        nt = norm_tokens(txt)
        if not nt: continue
        L = np.array([len(t) + 1.0 for t in nt]); cum = np.concatenate([[0], np.cumsum(L)]) / L.sum()
        bt = a + cum * (e - a)                       # boundary times (len+1)
        st = bt[:-1].copy(); en = bt[1:].copy()
        if x is not None:
            used = set()
            for d0, d1 in dips(x, sr, a, e):
                mid = (d0 + d1) / 2; k = int(np.argmin(np.abs(bt[1:-1] - mid))) + 1 if len(bt) > 2 else None
                if k is None or k in used or abs(bt[k] - mid) > 0.35: continue
                used.add(k); en[k - 1] = d0; st[k] = d1
            # re-spread inside the snapped sub-spans
            fixed = sorted(used); edges = [0] + fixed + [len(nt)]
            for p, q in zip(edges, edges[1:]):
                s0 = st[p]; s1 = en[q - 1]; c = np.concatenate([[0], np.cumsum(L[p:q])]) / L[p:q].sum()
                for i in range(p, q): st[i] = s0 + c[i - p] * (s1 - s0); en[i] = s0 + c[i - p + 1] * (s1 - s0)
        for i, t in enumerate(nt): toks.append((t, float(st[i]), float(en[i]), ci))
    return toks
def sim(a, b):
    if a == b: return 1.0
    return difflib.SequenceMatcher(None, a, b).ratio()
def align(lines, chunks, x=None, sr=SR):
    """-> dict(words=[{li, w, t0, t1, ok, heard}], mismatches=[...])"""
    SW = script_words(lines)
    S = [(wi, t) for wi, (_, _, nt) in enumerate(SW) for t in nt]          # flattened script tokens
    A = asr_words(chunks, x, sr)
    n, m = len(S), len(A); INF = 1e9
    D = np.zeros((n + 1, m + 1)); P = np.zeros((n + 1, m + 1), np.int8)
    D[:, 0] = np.arange(n + 1); D[0, :] = np.arange(m + 1); P[1:, 0] = 1; P[0, 1:] = 2
    for i in range(1, n + 1):
        si = S[i - 1][1]
        for j in range(1, m + 1):
            s_ = sim(si, A[j - 1][0]); c_sub = 0.0 if s_ == 1 else (0.4 if s_ >= 0.75 else 1.0)
            best, p = D[i - 1, j - 1] + c_sub, 0
            if D[i - 1, j] + 1 < best: best, p = D[i - 1, j] + 1, 1
            if D[i, j - 1] + 1 < best: best, p = D[i, j - 1] + 1, 2
            D[i, j] = best; P[i, j] = p
    i, j = n, m; pairs = []
    while i > 0 or j > 0:
        p = P[i, j]
        if i > 0 and j > 0 and p == 0: pairs.append((i - 1, j - 1)); i -= 1; j -= 1
        elif i > 0 and (j == 0 or p == 1): pairs.append((i - 1, None)); i -= 1
        else: pairs.append((None, j - 1)); j -= 1
    pairs.reverse()
    tok_t = [None] * n; tok_ok = [False] * n; tok_h = [""] * n; extra = []
    for si, aj in pairs:
        if si is None: extra.append(A[aj]); continue
        if aj is None: continue
        tok_t[si] = (A[aj][1], A[aj][2]); tok_ok[si] = S[si][1] == A[aj][0]; tok_h[si] = A[aj][0]
    # interpolate unmatched tokens
    for k in range(n):
        if tok_t[k] is None:
            pv = next((tok_t[q][1] for q in range(k - 1, -1, -1) if tok_t[q]), LEAD)
            nx = next((tok_t[q][0] for q in range(k + 1, n) if tok_t[q]), pv + 0.2)
            tok_t[k] = (pv, max(pv, nx))
    words = []
    for wi, (li, w, nt) in enumerate(SW):
        ks = [k for k in range(n) if S[k][0] == wi]
        if not ks: words.append(dict(li=li, w=w, t0=None, t1=None, ok=True, heard="")); continue
        words.append(dict(li=li, w=w, t0=round(tok_t[ks[0]][0], 3), t1=round(tok_t[ks[-1]][1], 3), ok=all(tok_ok[k] for k in ks),
                          heard=" ".join(tok_h[k] for k in ks)))
    for k, wd in enumerate(words):            # punctuation-only words: take the neighbour's time
        if wd["t0"] is None: wd["t0"] = wd["t1"] = words[k - 1]["t1"] if k else LEAD
    mism = [dict(i=k, line=wd["li"], word=wd["w"], heard=wd["heard"], t=wd["t0"]) for k, wd in enumerate(words) if not wd["ok"]]
    ins = [dict(heard=a[0], t=round(a[1], 2)) for a in extra]
    return dict(words=words, mismatches=mism, inserted=ins)

# ------------------------------------------------------------------ voice chain
def tempo(y):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                              "-f", "f32le", "pipe:1"], y.astype(np.float32).tobytes()), np.float32).astype(np.float64)
def wr(p, y): sf.write(p, y.astype(np.float32), SR, subtype="FLOAT")
def fin(y): return np.concatenate([np.zeros(int(LEAD * SR)), tempo(y)])
def restore(c, d, chunks, extra_windows=()):
    """vo_fix.py: pre-tempo clean c / dry d; chunks in reel time; extra_windows (reel time) restored fully from the unfiltered dry"""
    pre = lambda t: max(0.0, (t - LEAD) * TEMPO)
    dh = sosfiltfilt(butter(4, 90, "hp", fs=SR, output="sos"), d)
    hop = int(0.01 * SR); n = len(c) // hop
    lev = lambda x: 10 * np.log10((x[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
    Lc, Ld = lev(c), lev(dh); ref = np.percentile(Ld, 95)
    inch = np.zeros(n, bool)
    for a, b, *_ in chunks: a, b = pre(a), pre(b); inch[max(0, int((a - 0.05) * 100)):min(n, int((b + 0.06) * 100))] = True
    m = inch & (Ld - Lc > 4) & (Ld > ref - 40); m = np.convolve(m.astype(float), np.ones(5), "same") > 0
    spans = []; i = 0
    while i < n:
        if m[i]:
            j = i
            while j < n and m[j]: j += 1
            spans.append((i / 100, j / 100)); i = j
        else: i += 1
    r = int(0.015 * SR)
    def mask(sp):
        w = np.zeros(len(c))
        for a, b in sp:
            ia, ib = int(a * SR), min(len(c), int(b * SR)); w[ia:ib] = 1
            lo = max(0, ia - r); w[lo:ia] = np.maximum(w[lo:ia], np.linspace(0, 1, ia - lo))
            hi = min(len(c), ib + r); w[ib:hi] = np.maximum(w[ib:hi], np.linspace(1, 0, hi - ib))
        return w
    w = mask(spans); y = c * (1 - w) + dh * w
    if extra_windows:
        wf = mask([(pre(a), pre(b)) for a, b in extra_windows]); y = y * (1 - wf) + d * wf
    return y, [(round(a / TEMPO + LEAD, 2), round(b / TEMPO + LEAD, 2)) for a, b in spans]

def process(raw, script_lines, wd, log=print):
    os.makedirs(wd, exist_ok=True)
    if os.path.exists(f"{wd}/pre_clean.wav"):            # cached pre-tempo chain (dry / clean_vo), sample aligned
        x = sf.read(f"{wd}/pre_dry.wav")[0]; xc = sf.read(f"{wd}/pre_clean.wav")[0]
    else:
        x = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", raw, "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                               "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
        xc = clean_vo(x, SR); assert len(xc) == len(x); wr(f"{wd}/pre_dry.wav", x); wr(f"{wd}/pre_clean.wav", xc)
        x = sf.read(f"{wd}/pre_dry.wav")[0]; xc = sf.read(f"{wd}/pre_clean.wav")[0]
    vd = fin(x); wr(f"{wd}/vo_dry.wav", vd)
    chd = asr_chunks(f"{wd}/vo_dry.wav"); Ad = align(script_lines, chd, vd)
    log(f"dry ASR: {len(Ad['mismatches'])} mismatched words: " + ", ".join(f"{m['word']}->{m['heard'] or '-'}" for m in Ad["mismatches"]))
    y, spans = restore(xc, x, chd); vf = fin(y)
    wr(f"{wd}/vo_fix1.wav", vf); chf = asr_chunks(f"{wd}/vo_fix1.wav"); Af = align(script_lines, chf, vf)
    dry_bad = {m["i"] for m in Ad["mismatches"]}
    lost = [m for m in Af["mismatches"] if m["i"] not in dry_bad]
    log(f"auto restore: {len(spans)} spans, {sum(b - a for a, b in spans):.2f} s; still lost vs dry: " + ", ".join(f"{m['word']}->{m['heard'] or '-'} @{m['t']:.2f}" for m in lost))
    forced = []
    for it in range(3):
        if not lost: break
        for m in lost:
            wdd = Ad["words"][m["i"]]; forced.append((wdd["t0"] - 0.06, wdd["t1"] + 0.10))
        y, spans = restore(xc, x, chd, forced); vf = fin(y); wr(f"{wd}/vo_fix1.wav", vf)
        chf = asr_chunks(f"{wd}/vo_fix1.wav"); Af = align(script_lines, chf, vf)
        lost = [m for m in Af["mismatches"] if m["i"] not in dry_bad]
        log(f"forced pass {it + 1}: windows {[(round(a, 2), round(b, 2)) for a, b in forced]}; still lost: " + ", ".join(f"{m['word']}->{m['heard'] or '-'}" for m in lost))
    os.replace(f"{wd}/vo_fix1.wav", f"{wd}/vo.wav")
    rep = dict(raw=raw, dur=round(len(vf) / SR, 3), restored_spans=spans, forced=forced, chunks=chf, dry_mismatches=Ad["mismatches"],
               final_mismatches=Af["mismatches"], final_inserted=Af["inserted"], words=Af["words"])
    json.dump(rep, open(f"{wd}/words.json", "w"), indent=1, ensure_ascii=False)
    os.remove(f"{wd}/vo_dry.wav"); os.remove(f"{wd}/pre_dry.wav"); os.remove(f"{wd}/pre_clean.wav")
    log(f"final voice {rep['dur']} s; mismatches: " + ", ".join(f"{m['word']}->{m['heard'] or '-'}" for m in Af["mismatches"]))
    return rep

# ------------------------------------------------------------------ helpers for the builds
def line_spans(words, nlines):
    out = []
    for li in range(nlines):
        ws = [w for w in words if w["li"] == li]; out.append((ws[0]["t0"], ws[-1]["t1"]))
    return out
def phrase_time(words, li, phrase, end=False, occ=0):
    """start (or end) of a phrase (surface words, punctuation ignored) inside line li"""
    ws = [w for w in words if w["li"] == li]; key = norm_tokens(phrase)
    toks = [(k, t) for k, w in enumerate(ws) for t in norm_tokens(w["w"])]
    seq = [t for _, t in toks]; hits = [i for i in range(len(seq) - len(key) + 1) if seq[i:i + len(key)] == key]
    assert len(hits) > occ, (li, phrase, seq)
    i = hits[occ]; return ws[toks[i + len(key) - 1][0]]["t1"] if end else ws[toks[i][0]]["t0"]
def warp_from_pairs(pairs):
    """pairs [(t_new, t_old)] -> monotone piecewise linear f(t_new) = t_old and inverse g(t_old) = t_new (slope 1 outside)"""
    pairs = sorted(pairs); P = []
    for a, b in pairs:
        if not P or (a > P[-1][0] + 1e-3 and b > P[-1][1] + 1e-3): P.append((a, b))
    xn = np.array([p[0] for p in P]); xo = np.array([p[1] for p in P])
    def f(t):
        if t <= xn[0]: return xo[0] + (t - xn[0])
        if t >= xn[-1]: return xo[-1] + (t - xn[-1])
        return float(np.interp(t, xn, xo))
    def g(t):
        if t <= xo[0]: return xn[0] + (t - xo[0])
        if t >= xo[-1]: return xn[-1] + (t - xo[-1])
        return float(np.interp(t, xo, xn))
    return f, g, P
def old_word_times(lines, old_chunks):
    """old narration chunk list [(a, b, text)] -> per script word times via the same aligner (no audio)"""
    return align(lines, old_chunks, None)["words"]

def final_asr(media, words, lines, maxwin=27.0):
    """ASR of the final mix in windows cut at narration pauses (from the word timeline) -> (heard text, mismatches vs script)"""
    ws = sorted(words, key=lambda w: w["t0"]); wins = []; a = max(0, ws[0]["t0"] - 0.25); last = a
    for k in range(len(ws) - 1):
        gap = ws[k + 1]["t0"] - ws[k]["t1"]
        if gap > 0.18 and ws[k + 1]["t0"] - a > maxwin * 0.6 or ws[k + 1]["t1"] - a > maxwin:
            cut = (ws[k]["t1"] + ws[k + 1]["t0"]) / 2; wins.append((a, cut)); a = cut
    wins.append((a, ws[-1]["t1"] + 0.4))
    chunks = asr_chunks(media, wins)
    A = align(lines, chunks, None)
    return " ".join(c[2] for c in chunks), A["mismatches"], A["inserted"], chunks

if __name__ == "__main__" and len(sys.argv) > 3 and sys.argv[1] == "asr":
    _ch = json.load(open(sys.argv[3])); json.dump(_asr_chunks_local(sys.argv[2], [tuple(c[:2]) for c in _ch]), open(sys.argv[3], "w"))
