"""TRUST OR CONFIDENCE (values_2) v3: the whole narration is the new Cartesia recording (cart_trust_raw.wav, cartesia_full_trust.txt)
through the house chain (vo5/trust/vo.wav, word times in vo5/trust/words.json). Visuals as v2 (moving split-screen hook: confidence
wobbles and falls, trust climbs a ladder; then the recoloured engine_v3 cards over the animated silver background). Each card now
starts at its line in the new narration (minus 0.12 s, as the engine); the engine's reading-time rule is applied to the new
pacing (silence added after a line whose card needs more time), and the hook keeps 1.1 s after its last word as v2.
usage: python3 trust_v3.py --snaps 0,1,2 | --render"""
import sys, os, re, io, json, math, argparse, subprocess, time, runpy, types
sys.path.insert(0, "/home/claude/rehook")
from rk import *
from rk import remux
import rk5, v5lib
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); A = ap.parse_args()
DV = "/home/claude/names/values_2"; OUT = f"{RH}/trust_v3.mp4"; VW = f"{RH}/vo5/trust"
C = runpy.run_path(f"{DV}/cfg_v3.py"); CARDS = C["CARDS"]; MUSIC = C["MUSIC"]
VO0 = "/home/claude/vo_v4/out/values_2.wav"; PADDED = f"{DV}/values_2_v3_vo_padded.wav"

# ------------------------------------------------------------------ engine_v3 card code, recoloured
E = open("/home/claude/reels_v3/engine_v3.py").read()
def sect(a, b): i = E.index(a); j = E.index(b, i); return E[i:j]
code = sect("def hx(h, a=255):", "# ---------------------------------------------------------------- fonts") + \
       sect("HEEBO = {w:", "# ---------------------------------------------------------------- rules") + \
       sect("SIZE_RULE = {", "for i, c in enumerate(CARDS):") + \
       sect("EMC = {}", "# ---------------------------------------------------------------- build all cards")
def rp(a, b):
    global code; assert code.count(a) >= 1, a; code = code.replace(a, b)
rp('COLS = {"white": WHITE,', 'COLS = {"white": hx("#163260"), "slate": hx("#5B6E8C"),')
rp('"yel": YEL}', '"yel": hx("#2A88D4")}')
rp('toks.append((w_, YEL if sky else base))', 'toks.append((w_, hx("#2A88D4") if sky else base))')
rp('"src": dict(size=40, w=400, col="white"', '"src": dict(size=40, w=400, col="slate"')
rp('fill=(255, 255, 255, 18), outline=SKY[:3] + (160,), width=4)', 'fill=(255, 255, 255, 190), outline=hx("#2A88D4")[:3] + (200,), width=4)')
rp('d.rounded_rectangle([CX - 70, y, CX + 70, y + 4], 2, fill=YEL[:3] + (220,))', 'd.rounded_rectangle([CX - 70, y, CX + 70, y + 4], 2, fill=hx("#2A88D4")[:3] + (230,))')
rp('d.rounded_rectangle([CX - pw / 2, y, CX + pw / 2, y + ph], int(ph / 2), fill=hx("#0E1E3A"), outline=YEL, width=7)',
   'd.rounded_rectangle([CX - pw / 2, y, CX + pw / 2, y + ph], int(ph / 2), fill=hx("#163260"), outline=hx("#2A88D4"), width=7)')
rp('d.text((CX, y + ph / 2 + 4), k["s"], font=f, fill=col(k["col"]), anchor="mm")', 'd.text((CX, y + ph / 2 + 4), k["s"], font=f, fill=(255, 255, 255, 255), anchor="mm")')
EN = dict(W=W, H=H, FPS=FPS, SAFE0=260, SAFE1=1540, CX=540, MAXW=820, MAPY0=290, MAPH=620, ERR=[], re=re, io=io, math=math, np=np,
          Image=Image, ImageDraw=ImageDraw, ImageFont=ImageFont)
exec(compile(code, "engine_cards", "exec"), EN)
LAYERS = {i: pil2cairo(EN["draw_card"](CARDS[i])) for i in range(1, len(CARDS))}
assert not EN["ERR"], EN["ERR"]

# ------------------------------------------------------------------ new narration timing (engine_v3 rules on the new pacing)
LINES = rk5.lines_of(f"{RH}/cartesia_full_trust.txt"); WORDS = rk5.words_of(VW)["words"]; VO = load(f"{VW}/vo.wav")
assert len(LINES) == len(CARDS)
LW = lambda li: rk5.line_words(WORDS, li)
en_words, card_text = EN["en_words"], EN["card_text"]
need_ = [max(3.0, sum(len(en_words(s_)) for s_ in card_text(c)) / 3 + 1) for c in CARDS]
pads = [0.0] * len(CARDS)
g0 = LW(1)[0]["t0"] - LW(0)[-1]["t1"]
if g0 < 1.1: pads[0] = round(1.1 - g0, 3); VO, WORDS = rk5.pad_after_line(VO, WORDS, 0, pads[0])    # hook: 1.1 s after its last word (v2)
for k in range(1, len(CARDS) - 1):
    have = (LW(k + 1)[0]["t0"] - 0.12) - (LW(k)[0]["t0"] - 0.12)
    if need_[k] > have:
        pads[k] = round(min(1.5, need_[k] - have) + 0.05, 2); VO, WORDS = rk5.pad_after_line(VO, WORDS, k, pads[k])
segs = [(LW(k)[0]["t0"], LW(k)[-1]["t1"]) for k in range(len(CARDS))]
T0 = [0.0] + [max(0.0, s_[0] - 0.12) for s_ in segs[1:]]; T_END = max(len(VO) / SR, segs[-1][1]) + 1.6
print("pads", [(k, p) for k, p in enumerate(pads) if p], "T_END", round(T_END, 2))
HOOK_END = segs[0][1]; T_TR = T0[1]; N = int(round(T_END * FPS)); TR = 0.32
NT0 = T0[1:]; NT1 = NT0[1:] + [T_END]                                     # body cards 1..15
T_TRUST = v5lib.phrase_time(WORDS, 0, "Trust proves it."); T_FALL = T_TRUST + 0.35
print(f"hook end {HOOK_END:.2f}  trust {T_TRUST:.2f}  body from {T_TR:.2f}  T_END {T_END:.2f}")

# ------------------------------------------------------------------ hook drawing
HT = HookText("ביטחון מזייף. אמון מוכיח.", 68, [(0.0, "Confidence\n*fakes* it.", 124), (T_TRUST - 0.05, "Trust\n*proves* it.", 124)], y_he=262)
def jag(text, sz=50):
    t_ = pil2cairo(rich(text, sz, 900, N255)); tw, th = t_.get_width(), t_.get_height(); pw, ph = tw + 70, th + 70
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(pw + 30), int(ph + 70)); c = cairo.Context(s); cx, cy = (pw + 30) / 2, (ph + 30) / 2; n = 22
    for k in range(n * 2 + 1):
        ang = k / (n * 2) * 2 * math.pi; r = 1.0 if k % 2 == 0 else 0.88
        (c.move_to if k == 0 else c.line_to)(cx + r * pw / 2 * math.cos(ang), cy + r * ph / 2 * math.sin(ang))
    c.close_path(); fill(c, PAPER); c.fill_preserve(); stroke(c, RED, 6); c.stroke()
    c.move_to(cx - 10, cy + ph / 2 - 14); c.line_to(cx + 6, cy + ph / 2 + 46); c.line_to(cx + 40, cy + ph / 2 - 16); c.close_path(); fill(c, PAPER); c.fill_preserve(); stroke(c, RED, 6); c.stroke()
    c.rectangle(cx - 8, cy + ph / 2 - 26, 46, 16); fill(c, PAPER); c.fill()
    paste(c, t_, cx, cy, 1.0); s.flush(); return s
GOT = jag("I've got this!")
LAB_L = pil2cairo(rich("CONFIDENCE", 46, 900, R255)); LAB_R = pil2cairo(rich("TRUST", 46, 900, B255))
FLOOR = 1440; LX, RX = 345, 800; RUNG0, RUNGS, RSTEP = FLOOR - 80, 6, 80
def person(c, x, y, s, a=1.0, arms=(-2.5, 2.5), legs=(0.0, 0.0), knees=(0.0, 0.0), rot=0.0, col=NAVY, mouth=0.0):
    """navy figure, feet at (x, y), head at y - 250 s. arms: angle of each arm from straight down (radians, + = to the right)."""
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    stroke(c, col, 24, a)
    for side, (lg, kn) in zip((-1, 1), zip(legs, knees)):
        hipx = 16 * side; kx = hipx + 60 * math.sin(lg); ky = -120 + 60 * math.cos(lg) - 30 * kn
        c.move_to(hipx, -120); c.line_to(kx, ky); c.line_to(hipx + 10 * side + 40 * math.sin(lg) * (1 - kn), -6 - 60 * kn); c.stroke()
    rr(c, -42, -212, 84, 110, 34); fill(c, col, a); c.fill()
    for side, an in zip((-1, 1), arms):
        sx_ = 40 * side; ex = sx_ + 62 * math.sin(an); ey = -200 + 62 * math.cos(an); hx_ = ex + 58 * math.sin(an * 1.05); hy_ = ey + 58 * math.cos(an * 1.05)
        stroke(c, col, 19, a); c.move_to(sx_, -200); c.line_to(ex, ey); c.line_to(hx_, hy_); c.stroke()
    fill(c, col, a); c.arc(0, -252, 40, 0, 2 * math.pi); c.fill()
    if mouth > 0.01: fill(c, PAPER, a * mouth); c.save(); c.translate(0, -238); c.scale(1, 0.8); c.arc(0, 0, 14 * mouth, 0, 2 * math.pi); c.restore(); c.fill()
    c.restore()
def hook_frame(c, t):
    bg_silver(c, t)
    out = ramp(t, T_TR - 0.3, T_TR)
    # split: divider + floor
    stroke(c, RULE, 3, 0.9 * (1 - out)); c.move_to(540, 690); c.line_to(540, 1560); c.stroke()
    for x0, x1 in ((80, 500), (580, 1000)): stroke(c, SLATE, 6, 0.8 * (1 - out)); c.move_to(x0, FLOOR); c.line_to(x1, FLOOR); c.stroke()
    a = 1 - out
    # ---- left: confidence wobbles, then falls
    rr(c, LX - 90, FLOOR - 60, 180, 60, 10); fill(c, SILVER, a); c.fill_preserve(); stroke(c, SLATE, 4, a); c.stroke()
    amp = lerp(0.04, 0.22, ramp(t, 0.0, T_FALL)); wob = amp * math.sin(t * 7.5)
    fall = ramp(t, T_FALL, T_FALL + 0.45) ** 1.6
    rot = wob * (1 - fall) + (-1.52) * fall
    bounce = 0.06 * math.sin((t - T_FALL - 0.45) * 18) * math.exp(-(t - T_FALL - 0.45) * 6) if t > T_FALL + 0.45 else 0
    px = LX - 10 * fall; py = FLOOR - 60 + 38 * fall
    flail = 0.6 * math.sin(t * 16) * fall
    person(c, px, py, 0.95, a, arms=(-2.6 + 0.25 * math.sin(t * 9) + flail, 2.6 - 0.25 * math.sin(t * 9) - flail), legs=(-0.12, 0.12), rot=rot + bounce, mouth=1.0 - 0.5 * fall)
    if t > T_FALL + 0.4:      # dust puffs on impact
        u = ramp(t, T_FALL + 0.4, T_FALL + 1.0)
        for k in range(5):
            dx = (k - 2) * 46 * (0.5 + u); fill(c, SLATE, a * 0.35 * (1 - u)); c.arc(LX - 120 + dx, FLOOR - 16 - 22 * u * (1 + k % 2), 14 + 16 * u, 0, 2 * math.pi); c.fill()
    gb = (1 - ramp(t, T_FALL + 0.1, T_FALL + 0.45)) * a
    paste(c, GOT, LX + 10 + 220 * math.sin(wob) * 0.5, 830 + 30 * fall, gb, lerp(0.92, 1.0, eob(min(1, (t + 0.3) / 0.4))) * (1 - 0.3 * ramp(t, T_FALL + 0.1, T_FALL + 0.45)), rot=wob * 0.4)
    paste(c, LAB_L, LX, 1505, a)
    # ---- right: trust climbs, rung by rung
    for xr in (RX - 80, RX + 80): stroke(c, SLATE, 12, a); c.move_to(xr, FLOOR + 6); c.line_to(xr, RUNG0 - RSTEP * (RUNGS - 1) - 40); c.stroke()
    step_t = [0.05 + 0.45 * k for k in range(RUNGS)]
    lvl = sum(ramp(t, st, st + 0.28) for st in step_t)            # 0 .. RUNGS (feet on rung floor(lvl))
    for k in range(RUNGS):
        lit = ramp(t, step_t[k] + 0.1, step_t[k] + 0.3); y = RUNG0 - RSTEP * k
        stroke(c, tuple(lerp(p, q, lit) for p, q in zip(SLATE, BLUE)), 10, a); c.move_to(RX - 80, y); c.line_to(RX + 80, y); c.stroke()
        if 0 < t - step_t[k] - 0.1 < 0.5: glow(c, RX, y, 70, BLUE, 0.4 * a * (1 - (t - step_t[k] - 0.1) / 0.5))
    fy = FLOOR - RSTEP * min(lvl, RUNGS - 0.0) * 0.98 + 0 if lvl > 0 else FLOOR
    ph = lvl % 1; reach = math.sin(ph * math.pi)
    person(c, RX, fy, 0.8, a, arms=(math.pi - 0.35 - 0.3 * reach, -math.pi + 0.35 + 0.3 * (1 - reach)), legs=(0.18 * reach, -0.18 * (1 - reach)), knees=(0.5 * reach, 0.5 * (1 - reach)))
    top = ramp(t, step_t[-1] + 0.25, step_t[-1] + 0.5)
    if top > 0.01:
        cy_ = RUNG0 - RSTEP * (RUNGS - 1) - 120; fill(c, BLUE, a * top); c.arc(RX + 150, cy_, 36 * eob(top), 0, 2 * math.pi); c.fill()
        stroke(c, PAPER, 8, a * top); c.move_to(RX + 134, cy_); c.line_to(RX + 146, cy_ + 13); c.line_to(RX + 168, cy_ - 12); c.stroke()
    paste(c, LAB_R, RX, 1505, a)
    HT.render(c, t, 1 - ramp(t, T_TR - 0.25, T_TR + 0.05))
    if t > T_TR - 0.15:
        u = ease((t - T_TR + 0.15) / TR); body_card(c, 1, 0.0, NT1[0] - NT0[0], u, 36 * (1 - u))

# ------------------------------------------------------------------ body frames (engine card transitions over the moving silver bg)
def body_card(c, i, lt, dur, a=1.0, dy=0.0):
    if dur > 6.0: dy += 16 - 32 * ease(lt / dur)            # engine: a still card over 6 s drifts
    c.set_source_surface(LAYERS[i], 0, dy); c.paint_with_alpha(a)
def body_frame(c, t):
    bg_silver(c, t)
    k = max(j for j in range(len(NT0)) if NT0[j] <= t + 1e-9); i = k + 1; lt = t - NT0[k]; dur = NT1[k] - NT0[k]
    if k > 0 and lt < TR:
        u = ease(lt / TR); pd = NT1[k - 1] - NT0[k - 1]
        body_card(c, i - 1, pd, pd, 1 - u); body_card(c, i, lt, dur, u, 36 * (1 - u))
    elif k == 0 and lt < TR - 0.15:
        u = ease((lt + 0.15) / TR); body_card(c, i, lt, dur, u, 36 * (1 - u))
    else: body_card(c, i, lt, dur)
# subtitles: body lines (cards 1..15) from the new word times
rk5.MAX_SUB_W = 900      # one-line pills: the cards' source line sits just above the subtitle
SUBL = [rk5.sub_line(LINES[i], LW(i)) for i in range(1, len(CARDS))]
SUBS = sub_items(SUBL, 1600)
def frame(fi, c, surf):
    t = fi / FPS
    if t < T_TR: hook_frame(c, t)
    else: body_frame(c, t)
    if t < T_TR + TR and t >= T_TR - 0.3:     # hook text/scene fade handled in hook_frame; body card fades in
        pass
    draw_subs(c, t, SUBS)

if A.snaps:
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for ts in [float(x) for x in A.snaps.split(",")]: frame(int(round(ts * FPS)), c, surf); surf2pil(surf).save(f"{SCR}/tru3_{ts:05.2f}.png")
    print("snaps in", SCR); sys.exit(0)

def build_audio():
    import soundfile as sf
    NS = int((T_END + 0.1) * SR); v = np.zeros(NS); place(v, VO, 0.0)
    # music + ducking exactly as engine_v3
    mu = load(MUSIC); xf = int(2 * SR); mo = mu.copy()
    while len(mo) < NS: r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:] * (1 - r) + mu[:xf] * r, mu[xf:]])
    mo = mo[:NS]; hop = int(0.02 * SR)
    fr = np.sqrt(np.convolve(v ** 2, np.ones(hop) / hop, "same") + 1e-12); act = 20 * np.log10(fr) > 20 * np.log10(np.abs(v).max() + 1e-9) - 35
    lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)) + 1e-12); lm = 20 * np.log10(np.sqrt(np.mean(mo ** 2)) + 1e-12)
    mm = np.convolve(act.astype(float), np.ones(int(0.25 * SR)), "full")[:NS] > 0
    k_ = np.ones(int(0.12 * SR)) / int(0.12 * SR); mask = np.convolve(mm.astype(float), k_, "same")
    gain = 10 ** ((lv - 10 - lm) / 20) + (10 ** ((lv - 18 - lm) / 20) - 10 ** ((lv - 10 - lm) / 20)) * mask
    out = v + mo * gain
    # hook sfx: wobble creak, slide-whistle fall + thud, wooden ladder taps, ding at the top, whoosh into the body
    S = np.zeros(NS); rng = np.random.default_rng(4); tt = lambda d: np.arange(int(d * SR)) / SR
    from scipy.signal import butter, sosfilt
    t = tt(T_FALL); S[:len(t)] += 0.05 * np.sin(2 * np.pi * (180 + 25 * np.sin(2 * np.pi * 1.19 * t)) * t) * np.minimum(1, t / 0.3) * (0.4 + 0.6 * t / T_FALL)
    t = tt(0.5); place(S, 0.35 * np.sin(2 * np.pi * np.cumsum(1400 - 1100 * (t / 0.5)) / SR) * np.sin(np.pi * t / 0.5), T_FALL)
    t = tt(0.5); place(S, 1.0 * np.sin(2 * np.pi * (45 + 70 * np.exp(-t * 22)) * t) * np.exp(-t * 9) + 0.3 * sosfilt(butter(2, 900, "lp", fs=SR, output="sos"), rng.standard_normal(len(t))) * np.exp(-t * 25), T_FALL + 0.45)
    for k in range(RUNGS):
        t = tt(0.15); place(S, 0.3 * np.sin(2 * np.pi * (300 + 22 * k) * t) * np.exp(-t * 40), 0.05 + 0.45 * k + 0.12)
    for j, m in enumerate((84, 91, 96)):
        t = tt(1.6); f = 440 * 2 ** ((m - 69) / 12); place(S, 0.10 * (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 5)) * np.minimum(1, t / 0.004) * np.exp(-t * 2.4), 0.05 + 0.45 * (RUNGS - 1) + 0.35 + 0.06 * j)
    t = tt(0.7); x = rng.standard_normal(len(t)); sw = np.zeros_like(x)
    for q in range(0, len(x), 480): fc = 300 + 2200 * np.sin(np.pi * min(1, q / len(x))); sw[q:q + 480] = sosfilt(butter(2, [fc * 0.6, fc * 1.4], "bp", fs=SR, output="sos"), x[q:q + 480])
    place(S, 0.25 * sw * np.sin(np.pi * t / 0.7) ** 2, T_TR - 0.35)
    ls = 20 * np.log10(np.sqrt(np.mean(S[S != 0] ** 2)) + 1e-12); out = out + S * 10 ** ((lv - 12 - ls) / 20)
    fi_ = int(0.05 * SR); out[:fi_] *= np.linspace(0.3, 1, fi_); fo = int(1.5 * SR); out[-fo:] *= np.linspace(1, 0, fo)
    out = out / max(1.0, np.abs(out).max() / 0.95)
    m4a = f"{SCR}/trust_v3.m4a"; J = finish_audio(np.stack([out, out]), m4a); return m4a, J

if A.render:
    t0 = time.time(); m4a, J = build_audio(); print("audio", J["final_I"], J["final_TP"], J["steps"], round(time.time() - t0), "s", flush=True)
    enc = Encoder(OUT, m4a, crf=20); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    for fi in range(N):
        frame(fi, c, surf); enc.write(surf)
        if fi % 300 == 0: print("frame", fi, "/", N, round(time.time() - t0), "s", flush=True)
    enc.close(); os.remove(m4a); print("video done", OUT, round(time.time() - t0), "s")
    json.dump(dict(T_TR=T_TR, T_END=T_END, hook=dict(trust=T_TRUST, fall=T_FALL, end=HOOK_END), pads=pads, loudnorm=J,
                   cards=[(CARDS[i]["id"], round(NT0[i - 1], 2), round(NT1[i - 1], 2)) for i in range(1, len(CARDS))],
                   subs=[(round(a, 2), round(b, 2), s) for a, b, *_, s in SUBS], words=WORDS), open(f"{RH}/qa_trust_v3.json", "w"), indent=1, ensure_ascii=False)
