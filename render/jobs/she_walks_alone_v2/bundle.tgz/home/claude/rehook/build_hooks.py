"""Split hooks_raw.wav (Cartesia "Noam Roz - reels") into the three hook lines by silence, apply the house chain
(rubberband pitch 0.9715 formant preserved, bass g=2 f=135, clean_vo, atempo 1.1) and ASR-check each line.
-> vo/hook_A.wav, hook_B.wav, hook_C.wav (48 kHz mono float), vo/hooks_asr.json (word chunks, times in the processed file)"""
import sys, re, json, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/vo_new"); from clean_vo import clean as clean_vo
import sherpa_onnx
D = "/home/claude/rehook"; SR = 48000; TEMPO = 1.1
LINES = {"A": "You know the words. Someone asks you a question in English. And... nothing.",
         "B": "When someone asks you, what do you think, in English, why do you freeze?",
         "C": "Confidence fakes it. Trust proves it."}
def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-600:]; return r.stdout
raw = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", f"{D}/hooks_raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                         "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
x = clean_vo(raw, SR).astype(np.float32)
x = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}", "-f", "f32le", "pipe:1"], x.tobytes()), np.float32)
# split by the two long gaps (on the processed signal)
hop = int(0.01 * SR); e = np.sqrt(np.convolve(x.astype(np.float64) ** 2, np.ones(hop) / hop, "same")[::hop] + 1e-12)
db = 20 * np.log10(e); act = db > db.max() - 40
runs = np.flatnonzero(np.diff(np.r_[0, act.astype(int), 0])).reshape(-1, 2) * 0.01
gaps = sorted(range(len(runs) - 1), key=lambda i: runs[i + 1][0] - runs[i][1], reverse=True)[:2]; gaps.sort()
bounds = [(runs[0][0], runs[gaps[0]][1]), (runs[gaps[0] + 1][0], runs[gaps[1]][1]), (runs[gaps[1] + 1][0], runs[-1][1])]
Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx", tokens=Wd + "turbo-tokens.txt",
                                                 language="en", task="transcribe", num_threads=1)
def toks(s): return re.findall(r"[a-z']+", s.lower())
def f1(a, b):
    from collections import Counter
    a, b = toks(a), toks(b); c = sum((Counter(a) & Counter(b)).values()); return 0 if not c else 2 * c / (len(a) + len(b))
def transcribe(y):
    y16 = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-ar", "16000", "-f", "f32le", "pipe:1"], y.astype(np.float32).tobytes()), np.float32)
    s = asr.create_stream(); s.accept_waveform(16000, np.concatenate([y16, np.zeros(6400, np.float32)])); asr.decode_stream(s); return s.result.text.strip()
out = {}
for (k, line), (a, b) in zip(LINES.items(), bounds):
    a0, b0 = max(0, a - 0.06), b + 0.18; y = x[int(a0 * SR):int(b0 * SR)].copy(); f = int(0.008 * SR); y[:f] *= np.linspace(0, 1, f); y[-f:] *= np.linspace(1, 0, f)
    sf.write(f"{D}/vo/hook_{k}.wav", y, SR, subtype="FLOAT")
    # word-ish chunks inside the line (pauses >= 0.12 s) for subtitle / cue timing
    hop2 = int(0.01 * SR); e2 = 20 * np.log10(np.sqrt(np.convolve(y.astype(np.float64) ** 2, np.ones(hop2) / hop2, "same")[::hop2] + 1e-12))
    act2 = e2 > e2.max() - 36; r2 = np.flatnonzero(np.diff(np.r_[0, act2.astype(int), 0])).reshape(-1, 2) * 0.01
    ch = []
    for s_, e_ in r2:
        if ch and s_ - ch[-1][1] < 0.12: ch[-1][1] = e_
        elif e_ - s_ > 0.05: ch.append([s_, e_])
    chunks = [[round(s_, 3), round(e_, 3), transcribe(y[int(s_ * SR):int((e_ + 0.05) * SR)])] for s_, e_ in ch]
    heard = transcribe(y)
    out[k] = dict(line=line, heard=heard, f1=round(f1(heard, line), 2), dur=round(len(y) / SR, 3), speech=[round(chunks[0][0], 3), round(chunks[-1][1], 3)], chunks=chunks,
                  src_span=[round(a0 * TEMPO, 2), round(b0 * TEMPO, 2)])
    print(k, out[k]["dur"], "s  F1", out[k]["f1"], "|", heard); [print("   ", c) for c in chunks]
json.dump(out, open(f"{D}/vo/hooks_asr.json", "w"), indent=1, ensure_ascii=False)
