"""Shared helpers for the re-hooked reels (fff_v3, thinking_v2, trust_v2).
Silver look tokens (as russian_army.py), text rendering (PIL + raqm for Hebrew), navy subtitle pills, hook VO matching,
two-pass loudnorm (-14 LUFS, -1.5 dBTP, 48 kHz), frame streaming into ffmpeg (no frame dumps), web encode, QA sheet."""
import os, re, io, json, math, subprocess, sys
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
sys.path.insert(0, "/home/claude/reelkit")
from kit import subclean, subchunks          # same subtitle text cleaning and chunking as the series
import kit as _kit; _kit.KEEP.update({'VP', 'PAIRS'})   # keep these caps in subtitles (as the posted trial did)
W, H, FPS, SR = 1080, 1920, 30, 48000
RH = "/home/claude/rehook"; SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/rh"
os.makedirs(SCR, exist_ok=True)
DASHES = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def c255(col): return tuple(int(round(v * 255)) for v in col[:3]) + (255,)
NAVY = hx("#163260"); BLUE = hx("#2A88D4"); BG0 = hx("#F4F5F7"); BG1 = hx("#D9DDE3"); RULE = hx("#A9B1BD")
SLATE = hx("#5B6E8C"); SILVER = hx("#C9CFD8"); PAPER = hx("#FFFFFF"); RED = hx("#E8364F"); ICE = hx("#9FDDF7")
N255, B255, S255, W255, R255 = c255(NAVY), c255(BLUE), c255(SLATE), (255, 255, 255, 255), c255(RED)

def ease(u): u = min(1.0, max(0.0, u)); return u * u * (3 - 2 * u)
def eob(u, s=1.7):
    u = min(1.0, max(0.0, u)) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def win(t, a, b, fi=0.3, fo=0.3): return ramp(t, a, a + fi) * (1 - ramp(t, b - fo, b))
def lerp(a, b, u): return a + (b - a) * u

HEEBO = {w: f"/home/claude/vid/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(HEEBO[w], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def is_he(s): return any("\u0590" <= ch <= "\u05ff" for ch in s)
def nodash(s): assert not any(d in s for d in DASHES), s; return s

def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3:4] / 255
    pre = np.concatenate([a[:, :, 2:3] * al, a[:, :, 1:2] * al, a[:, :, 0:1] * al, a[:, :, 3:4]], 2).astype(np.uint8)
    h, w = pre.shape[:2]; s = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h); st = s.get_stride()
    buf = np.ndarray((h, st // 4, 4), np.uint8, s.get_data()); buf[:, :w] = pre; s.mark_dirty(); return s

def rich(s, sz, w=900, base=N255, hl=B255, maxw=940, lh=1.12, align="c"):
    """'*word*' highlight markup, '\\n' forced breaks -> PIL RGBA, lines centred"""
    nodash(s); f = font(sz, w)
    if is_he(s):
        lines = s.split("\n"); ws = [f.getlength(l) for l in lines]; assert max(ws) <= maxw + 2, ("hebrew too wide", s, max(ws))
        im = Image.new("RGBA", (int(max(ws)) + 24, int(len(lines) * sz * lh + sz * 0.35)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        for k, l in enumerate(lines): d.text((im.size[0] / 2, sz * 0.12 + sz * lh * (k + 0.5)), l, font=f, fill=base, anchor="mm", direction="rtl")
        return im
    toks, on = [], False
    for p in s.replace("*", " * ").replace("\n", " \n ").split(" "):
        if p == "*": on = not on; continue
        if p == "\n": toks.append(("\n", None)); continue
        if p: toks.append((p, hl if on else base))
    lines, cur = [], []
    for t in toks:
        if t[0] == "\n": lines.append(cur); cur = []; continue
        if cur and f.getlength(" ".join(x for x, _ in cur + [t])) > maxw: lines.append(cur); cur = [t]
        else: cur.append(t)
    if cur: lines.append(cur)
    sp = f.getlength(" "); widths = [sum(f.getlength(x) for x, _ in ln) + sp * (len(ln) - 1) for ln in lines]
    im = Image.new("RGBA", (int(max(widths)) + 24, int(len(lines) * sz * lh + sz * 0.35)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for k, (ln, wd) in enumerate(zip(lines, widths)):
        x = (im.size[0] - wd) / 2 if align == "c" else 12; y = sz * 0.12 + sz * lh * (k + 0.5)
        for (x_, c_) in ln: d.text((x, y), x_, font=f, fill=c_, anchor="lm"); x += f.getlength(x_) + sp
    return im
def paste(c, surf, x, y, a=1.0, sc=1.0, anchor="cc", rot=0.0):
    if a <= 0.005 or sc <= 0.005: return
    w, h = surf.get_width(), surf.get_height(); ax = {"l": 0, "c": 0.5, "r": 1}[anchor[1]] if len(anchor) == 2 else 0.5
    ay = {"t": 0, "c": 0.5, "b": 1}[anchor[0]]
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc); c.set_source_surface(surf, -w * ax, -h * ay); c.paint_with_alpha(min(1, a)); c.restore()

# ------------------------------------------------------------------ silver background (russian_army.bg look)
def bg_silver(c, t, rules=True):
    g = cairo.LinearGradient(0, 0, W * 0.25, H); g.add_color_stop_rgba(0, *BG0[:3], 1); g.add_color_stop_rgba(1, *BG1[:3], 1)
    c.set_source(g); c.paint()
    for k, (bx, by, br, sp) in enumerate([(250, 520, 520, 0.17), (860, 1250, 560, 0.13)]):
        x = bx + 70 * math.sin(t * sp + k * 2); y = by + 60 * math.cos(t * sp * 1.3 + k)
        rg = cairo.RadialGradient(x, y, 0, x, y, br); rg.add_color_stop_rgba(0, 1, 1, 1, 0.55); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        c.set_source(rg); c.arc(x, y, br, 0, 2 * math.pi); c.fill()
    if rules:
        c.set_source_rgba(*RULE[:3], 0.7); c.set_line_width(2)
        for y in (215, 1660): c.move_to(70, y); c.line_to(1010, y); c.stroke()
        c.set_source_rgba(*BLUE[:3], 1); c.rectangle(70, 211, 64, 8); c.fill(); c.rectangle(946, 1656, 64, 8); c.fill()
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def stroke(c, col, w, a=1.0):
    c.set_source_rgba(col[0], col[1], col[2], (col[3] if len(col) > 3 else 1) * a); c.set_line_width(w)
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
def fill(c, col, a=1.0): c.set_source_rgba(col[0], col[1], col[2], (col[3] if len(col) > 3 else 1) * a)
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 4, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.arc(x, y, r, 0, 2 * math.pi); c.fill()

# ------------------------------------------------------------------ kinetic hook text: Hebrew on top, English phrase replaced in place
class HookText:
    """he: Hebrew (shown from frame 0, top). phrases: [(t_on, text, size)] English, each replaces the previous (pop-in)."""
    def __init__(s, he, he_sz, phrases, y_he=300, y_en=None, he_lines=None):
        s.he = pil2cairo(rich(he if he_lines is None else he_lines, he_sz, 800, N255, maxw=930, lh=1.22)); s.y_he = y_he
        s.ph = [(t, pil2cairo(rich(txt, sz, 900, N255, B255, maxw=940, lh=1.06))) for t, txt, sz in phrases]
        s.y_en = y_en if y_en is not None else y_he + s.he.get_height() + 30
    def render(s, c, t, a=1.0):
        paste(c, s.he, 540, s.y_he, a, 1.0, "tc")
        cur = [k for k, (t0, _) in enumerate(s.ph) if t0 <= t + 1e-6]
        k = cur[-1] if cur else 0
        for j in (k - 1, k):
            if j < 0: continue
            t0, sf = s.ph[j]
            if j == k:
                u = 1.0 if t0 <= 0 else ramp(t, t0, t0 + 0.22); sc = 1.0 if t0 <= 0 else lerp(0.86, 1.0, eob(min(1, (t - t0) / 0.3)))
                paste(c, sf, 540, s.y_en + 18 * (1 - u), a * u, sc, "tc")
            else:
                t1 = s.ph[k][0]; u = 1 - ramp(t, t1, t1 + 0.09)
                paste(c, sf, 540, s.y_en - 24 * (1 - u), a * u, 1.0, "tc")

# ------------------------------------------------------------------ subtitles (series chunking, navy pill for both looks)
SUBF = None
def sub_items(lines, sub_bottom=1600):
    """lines: [(text, [(frac, time), ...])] piecewise char-fraction -> time map per line -> [(a, b, surf, x, y, text)]"""
    global SUBF
    SUBF = SUBF or ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54)
    def ft(P, fr):
        for (f0, t0), (f1, t1) in zip(P, P[1:]):
            if fr <= f1 + 1e-9: return t0 if f1 - f0 < 1e-9 else t0 + (t1 - t0) * (fr - f0) / (f1 - f0)
        return P[-1][1]
    items = []
    for l, P in lines:
        cs = subchunks(l); L = len(l); pos = 0
        for cc in cs:
            p0 = l.find(cc, pos); p1 = p0 + len(cc); pos = p1; items.append([ft(P, p0 / L), ft(P, p1 / L), cc])
    for a, b in zip(items, items[1:]):
        if b[0] - a[1] < 0.45: a[1] = b[0]
    out = []
    for a, b, cc in items:
        nodash(cc); w = cc.split(); ls, cur = [], ''
        for x in w:
            tr = (cur + ' ' + x).strip()
            if SUBF.getlength(tr) <= 920: cur = tr
            else: ls.append(cur); cur = x
        ls.append(cur); lh = 66; Wd = int(max(SUBF.getlength(x) for x in ls)) + 56; Hd = lh * len(ls) + 28
        im = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(22, 50, 96, 236))
        for k, x in enumerate(ls): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=SUBF, fill=(255, 255, 255), anchor='mm')
        out.append((a, b, pil2cairo(im), (W - Wd) // 2, sub_bottom - Hd, cc))
    return out
def line_map(text, chunks):
    """chunks [(start, end, heard)] covering one line -> char-fraction map weighted by heard length"""
    L = [max(1, len(c[2])) for c in chunks]; tot = sum(L); pts, acc = [], 0
    for (a, b, _), l in zip(chunks, L): pts.append((acc / tot, a)); acc += l; pts.append((acc / tot, b))
    return pts
def draw_subs(c, t, subs):
    for a, b, ss, x, y, _ in subs:
        if a <= t < b:
            al = min(1, (t - a) / 0.08, (b - t) / 0.08); c.set_source_surface(ss, x, y); c.paint_with_alpha(max(0, al))

# ------------------------------------------------------------------ audio
def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-800:]; return r.stdout
def load(p, sr=SR):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"]), np.float32).astype(np.float64)
def active_db(x):
    hop = 480; e = np.sqrt(np.convolve(x ** 2, np.ones(hop) / hop, "same")[::hop] + 1e-12); db = 20 * np.log10(e); m = np.repeat(db > db.max() - 30, hop)[:len(x)]
    return 10 * np.log10(np.mean(x[m] ** 2) + 1e-12)
def matched_hook(key, reel, body_level_db):
    """hook line with the voice_match EQ (firequalizer from the LTAS difference) and its speech level set to the body's"""
    vm = json.load(open(f"{RH}/vo/voice_match.json"))[reel]
    ge = ";".join(f"entry({f},{g})" for f, g in vm["eq_points"])
    y = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", f"{RH}/vo/hook_{key}.wav", "-af", f"firequalizer=gain_entry='{ge}':gain='cubic_interpolate(f)'",
                           "-ar", str(SR), "-ac", "1", "-f", "f32le", "-"]), np.float32).astype(np.float64)
    y *= 10 ** ((body_level_db - active_db(y)) / 20); return y, vm
def place(buf, sig, st, g=1.0, pan=0.0):
    i = int(round(st * SR)); n = buf.shape[-1]
    if i < 0: sig = sig[-i:]; i = 0
    j = min(n, i + len(sig))
    if j <= i: return
    s = g * sig[:j - i]
    if buf.ndim == 1: buf[i:j] += s
    else: buf[0][i:j] += s * (1 - pan); buf[1][i:j] += s * (1 + pan)
def finish_audio(st, out_m4a):
    """stereo float (2, n) -> two-pass loudnorm, AAC 192k 48 kHz; verified on the encoded file (ebur128 true peak) and corrected
    until I = -14 +-0.3 LUFS and true peak <= -1.5 dBTP (limiter only if a gain step would push the peak over)."""
    raw = st.T.astype(np.float32).tobytes()
    meas = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af",
                           "loudnorm=I=-14:TP=-2.2:LRA=11:print_format=json", "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
    J = json.loads(meas[meas.rfind("{"):meas.rfind("}") + 1])
    af = (f"loudnorm=I=-14:TP=-2.2:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
          f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
    y = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af, "-ar", "48000", "-f", "f32le", "-"], raw), np.float32).copy()
    gain_db, lim = 0.0, False; J["steps"] = []
    for it in range(4):
        z = (y * 10 ** (gain_db / 20)).astype(np.float32); chain = ["-af", "alimiter=limit=0.79:attack=1:release=60:level=false"] if lim else []
        run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", "48000", "-ac", "2", "-i", "pipe:0"] + chain + ["-c:a", "aac", "-b:a", "192k", "-ar", "48000", out_m4a], z.tobytes())
        I, TP = loudness(out_m4a); J["steps"].append((round(gain_db, 2), lim, I, TP))
        if abs(I + 14) <= 0.3 and TP <= -1.5: break
        if TP > -1.5 and abs(I + 14) <= 0.3: lim = True; continue
        nxt = gain_db + (-14 - I)
        if TP + (-14 - I) > -1.6: lim = True
        gain_db = nxt
    J["final_I"], J["final_TP"] = I, TP; return J
def remux(video, m4a, out):
    tmp = out + ".tmp.mp4"; run(["ffmpeg", "-v", "error", "-y", "-i", video, "-i", m4a, "-map", "0:v", "-map", "1:a", "-c", "copy", "-shortest", "-movflags", "+faststart", tmp]); os.replace(tmp, out)

# ------------------------------------------------------------------ render
class Encoder:
    def __init__(s, out, m4a, crf=20):
        s.p = subprocess.Popen(["nice", "-n", "15", "ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
                                "-i", "pipe:0", "-i", m4a, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-pix_fmt", "yuv420p",
                                "-profile:v", "high", "-c:a", "copy", "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    def write(s, surf):
        surf.flush(); s.p.stdin.write(np.ndarray((H, surf.get_stride() // 4, 4), np.uint8, surf.get_data())[:, :W].tobytes())
    def write_bgra(s, arr): s.p.stdin.write(np.ascontiguousarray(arr).tobytes())
    def close(s): s.p.stdin.close(); assert s.p.wait() == 0
def web(out, web_out):
    run(["nice", "-n", "15", "ffmpeg", "-nostdin", "-v", "error", "-y", "-i", out, "-c:v", "libx264", "-preset", "medium", "-crf", "26", "-maxrate", "1M",
         "-bufsize", "2M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", web_out])
def surf2pil(surf):
    surf.flush(); a = np.ndarray((H, surf.get_stride() // 4, 4), np.uint8, surf.get_data())[:, :W]; return Image.fromarray(a[:, :, [2, 1, 0]].copy())
def loudness(f):
    lo = subprocess.run(["ffmpeg", "-nostats", "-i", f, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    return float(re.findall(r"I:\s+(-?[\d.]+) LUFS", lo)[-1]), float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", lo)[-1])
def qa_sheet(video, times, out_png, title, notes):
    """contact sheet from the rendered file (phone size thumbs, 390 px) + notes panel"""
    tw, th = 390, 693; cols = 5; ims = []
    for t in times:
        raw = run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", video, "-frames:v", "1", "-vf", f"scale={tw}:{th}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
        ims.append((t, Image.frombytes("RGB", (tw, th), raw)))
    rows = -(-len(ims) // cols); nh = 60 + 46 * len(notes)
    sh = Image.new("RGB", (cols * (tw + 12) + 12, rows * (th + 50) + 12 + nh), (24, 26, 32)); d = ImageDraw.Draw(sh)
    fT = ImageFont.truetype(HEEBO[800], 40); fN = ImageFont.truetype(HEEBO[400], 30); fL = ImageFont.truetype(HEEBO[700], 30)
    d.text((14, 10), title, font=fT, fill=(255, 255, 255))
    for k, nline in enumerate(notes): d.text((14, 62 + 46 * k), nline, font=fN, fill=(215, 222, 235))
    for k, (t, im) in enumerate(ims):
        x = 12 + (k % cols) * (tw + 12); y = nh + 12 + (k // cols) * (th + 50); sh.paste(im, (x, y)); d.text((x + 4, y + th + 6), f"{t:.2f} s", font=fL, fill=(255, 255, 255))
    sh.save(out_png, optimize=True)
def probe(f):
    pr = json.loads(run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height,r_frame_rate,sample_rate", "-of", "json", f]))
    v = [s for s in pr["streams"] if s["codec_type"] == "video"][0]; a = [s for s in pr["streams"] if s["codec_type"] == "audio"][0]
    return dict(dur=round(float(pr["format"]["duration"]), 2), size_mb=round(os.path.getsize(f) / 1e6, 2), res=f"{v['width']}x{v['height']}", fps=v["r_frame_rate"], sr=a["sample_rate"])
def asr_check(m4a_or_wav, a, b, expect):
    import sherpa_onnx
    Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
    asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx", tokens=Wd + "turbo-tokens.txt",
                                                     language="en", task="transcribe", num_threads=1)
    x = load(m4a_or_wav, 16000)[int(a * 16000):int(b * 16000)].astype(np.float32)
    s = asr.create_stream(); s.accept_waveform(16000, np.concatenate([x, np.zeros(6400, np.float32)])); asr.decode_stream(s); heard = s.result.text.strip()
    from collections import Counter
    tk = lambda z: re.findall(r"[a-z']+", z.lower()); A_, B_ = tk(heard), tk(expect); cm = sum((Counter(A_) & Counter(B_)).values())
    return heard, round(0 if not cm else 2 * cm / (len(A_) + len(B_)), 2)
