"""Web encode + QA sheet for one re-hooked reel.  usage: python3 qa_make.py fff_v3|thinking_v2|trust_v2"""
import sys, json, os, re, numpy as np
sys.path.insert(0, "/home/claude/rehook")
import rk
from rk import RH, SR
name = sys.argv[1]; out = f"{RH}/{name}.mp4"; web = f"{RH}/{name}_web.mp4"
Q = json.load(open(f"{RH}/qa_{name}.json")); VM = json.load(open(f"{RH}/vo/voice_match.json")); HA = json.load(open(f"{RH}/vo/hooks_asr.json"))
reel = {"fff_v3": "fff", "thinking_v2": "thinking", "trust_v2": "trust"}[name]; key = VM[reel]["hook_line"]
if not os.path.exists(web) or os.path.getmtime(web) < os.path.getmtime(out): rk.web(out, web)
P, PW = rk.probe(out), rk.probe(web); I, TP = rk.loudness(out); Iw, TPw = rk.loudness(web)
hook_end = Q["HOOK"][-1][1]; T_TR = Q["T_TR"]
heard_h, f1_h = rk.asr_check(out, 0.0, hook_end + 0.25, HA[key]["line"])
first_sub = [s for s in Q["subs"] if s[0] >= T_TR - 1.5][0]
heard_j, f1_j = rk.asr_check(out, hook_end + 0.2, first_sub[1] + 0.3, first_sub[2])
# loudness/spectrum of the hook speech vs the next 10 s of body speech, measured in the final mix
x = rk.load(out); seg = lambda a, b: x[int(a * SR):int(b * SR)]
def bands(y):
    import librosa
    S = np.abs(librosa.stft(y.astype(np.float32), n_fft=4096, hop_length=1024)) ** 2; Pw = S.mean(1); fr = librosa.fft_frequencies(sr=SR, n_fft=4096)
    tot = Pw[(fr > 80) & (fr < 12000)].sum(); return [10 * np.log10(Pw[(fr >= a) & (fr < b)].sum() / tot) for a, b in ((80, 315), (315, 1250), (1250, 5000), (5000, 12000))]
h_seg, b_seg = seg(0.3, hook_end), seg(first_sub[0], first_sub[0] + 10)
dl = float(rk.active_db(h_seg) - rk.active_db(b_seg)); db_ = [round(float(p - q), 1) for p, q in zip(bands(h_seg), bands(b_seg))]
vm = VM[reel]
dash = [f for f in (f"{RH}/{name}.py", f"{RH}/rk.py") if any(ch in open(f).read() for ch in rk.DASHES)]
times = sorted(set([0.0, 0.5, 1.0, 1.8, 2.6, 3.4] + [round(T_TR - 0.15, 2), round(T_TR + 0.4, 2)] + [round(float(v), 2) for v in np.linspace(T_TR + 3, P["dur"] - 1.2, 9)]))
notes = [f"{os.path.basename(out)}: {P['dur']} s, {P['size_mb']} MB, {P['res']}, {P['fps']} fps, {P['sr']} Hz, {I} LUFS, {TP} dBTP   |   web: {PW['size_mb']} MB, {Iw} LUFS, {TPw} dBTP",
         f"Hook (Cartesia line {key}) 0.30 to {hook_end:.2f} s, ASR F1 {f1_h}: {heard_h}",
         f"Body from {T_TR:.2f} s (shift {Q['DELTA']:+.3f} s). Join ASR F1 {f1_j}: {heard_j[:90]}",
         f"Voice match (body = ElevenLabs): before EQ F0 {vm['d_f0_semitones']:+.1f} st, level {vm['d_level_db']:+.1f} dB, bands {vm['d_bands_db'][:4]}",
         f"In the final mix, hook vs next 10 s of body: speech level {dl:+.1f} dB, bands 80-315/315-1.25k/1.25-5k/5-12k Hz {db_} dB",
         f"Subtitles: {len(Q['subs'])} chunks (body), navy pill, bottom edge about y 1600. Dash characters in build scripts: {len(dash)}"]
rk.qa_sheet(out, times, f"{RH}/{name}_qa.png", f"QA  {name}", notes)
rep = dict(main=P, web=PW, loudness=dict(I=I, TP=TP, web_I=Iw, web_TP=TPw), hook_asr=dict(heard=heard_h, f1=f1_h), join_asr=dict(heard=heard_j, f1=f1_j, expect=first_sub[2]),
           mix_hook_vs_body=dict(level_db=round(dl, 2), bands_db=db_), voice_match=vm, sheet_times=times, dash_files=dash)
Q["qa"] = rep; json.dump(Q, open(f"{RH}/qa_{name}.json", "w"), indent=1, ensure_ascii=False)
print(json.dumps(rep, ensure_ascii=False, indent=0)[:1800])
