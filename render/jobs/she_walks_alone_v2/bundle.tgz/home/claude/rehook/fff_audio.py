"""rehook copy of /home/claude/fff/audio.py: cues/VO/out from argv, hook-level tension, hook sfx."""
"""tense pulse (alarm/fork) -> warm bed (fix) + sfx + ducked narration -> mix.wav 48 kHz"""
import json, subprocess, sys, numpy as np, soundfile as sf
from scipy.signal import lfilter, butter, sosfilt, fftconvolve
D = "/home/claude/fff"; SR = 48000
CUE_P, VO_P, OUT_P = sys.argv[1:4]
cue = json.load(open(CUE_P)); T_END = cue["T_END"]; B = cue["B"]
n = int(T_END * SR) + 1; rng = np.random.default_rng(5)
def nf(m): return 440 * 2 ** ((m - 69) / 12)
def lp(x, a): return lfilter([a], [1, a - 1], x)
tt_ = lambda d: np.arange(int(d * SR)) / SR
def place(buf, sig, st, g=1.0, pan=0.0):
    i = int(st * SR); j = min(n, i + len(sig))
    if i < 0: sig = sig[-i:]; i = 0
    if j > i: s = g * sig[:j - i]; buf[0][i:j] += s * (1 - pan); buf[1][i:j] += s * (1 + pan)
def env_curve(points):
    x = np.arange(n) / SR; px, py = zip(*points); return np.interp(x, px, py)
tA = np.arange(n) / SR
# ---------------- tense layer: low drone + pulsing sub (from DANGER to the fix)
TENSE = np.zeros(n)
drone = sum(np.sin(2 * np.pi * nf(m) * 2 ** (dt / 12) * tA + rng.random() * 6) for m in (33, 40, 45) for dt in (-0.08, 0.08))
drone = lp(drone, 0.03)
pulse_rate = env_curve([(0, 1.2), (B[1] + 2, 1.2), (B[2], 2.0), (B[4], 2.4), (B[8], 2.0), (B[9] + 2, 1.1), (T_END, 1.0)])
ph = np.cumsum(pulse_rate) / SR; pul = np.exp(-((ph % 1.0) * 5.0)) * np.sin(2 * np.pi * 49 * tA)
HK = cue["HOOK"]
inten = env_curve([(0, 0.32), (HK["noth"] - 0.1, 0.45), (HK["noth"] + 0.1, 0.85), (B[1] + 2.0, 0.7), (B[1] + 2.4, 0.9), (B[2], 0.6), (B[3], 0.75), (B[4], 1.0), (B[8], 0.95), (B[8] + 3, 0.6), (B[9], 0.35), (B[9] + 3, 0.0), (T_END, 0)])
TENSE = (0.5 * drone + 0.9 * pul) * inten
# ---------------- warm layer (Dmaj9 / Bm9 / Gmaj9 / Aadd9)
WARM = (np.zeros(n), np.zeros(n)); beat = 60 / 70; bar = 4 * beat
prog = [(38, [62, 66, 69, 73, 76]), (35, [62, 66, 69, 71, 73]), (31, [62, 66, 69, 71, 74]), (33, [61, 64, 69, 71, 76])]
st = B[9] - 1.5; b = 0
while st < T_END:
    root, ch = prog[b % 4]; d = bar + 1.6; t = tt_(d); pad = np.zeros_like(t)
    for m in ch:
        for dt in (-0.07, 0.0, 0.07): pad += np.sin(2 * np.pi * nf(m - 12) * 2 ** (dt / 12) * t + rng.random() * 6)
    pad *= np.minimum(1, t / 1.6) * np.minimum(1, (d - t) / 1.4); pad = lp(pad, 0.05); place(WARM, pad, st, 0.018, -0.1)
    t = tt_(bar + 0.5); place(WARM, np.sin(2 * np.pi * nf(root - 12) * t) * np.minimum(1, t / 0.4) * np.exp(-t * 0.45), st, 0.09)
    if b >= 1:
        for q in range(4):
            m = ch[[0, 2, 4, 1][q]] + 12; t = tt_(1.2)
            pl = (np.sin(2 * np.pi * nf(m) * t) + 0.25 * np.sin(2 * np.pi * 2 * nf(m) * t) * np.exp(-t * 8)) * np.minimum(1, t / 0.004) * np.exp(-t * 3.2)
            place(WARM, pl, st + q * beat, 0.026, 0.35 if q % 2 else -0.35)
    st += bar; b += 1
wenv = env_curve([(0, 0), (B[9] - 1.5, 0), (B[9] + 2.5, 1), (T_END, 1)])
BED = np.stack([TENSE * 0.06 + WARM[0] * wenv, TENSE * 0.06 + WARM[1] * wenv])
# intro: faint airy pad under the hook, so the start is not dry
t = tt_(B[1] + 3); intro = lp(sum(np.sin(2 * np.pi * nf(m) * t) for m in (50, 57, 62)), 0.05) * np.minimum(1, t / 0.3) * np.minimum(1, (B[1] + 3 - t) / 1.5)
place(BED, intro, 0, 0.012)
# ---------------- sfx
SFX = (np.zeros(n), np.zeros(n))
def noise(d): return rng.standard_normal(int(d * SR))
def chime(t0, base, g=0.10):
    for k, m in enumerate((base, base + 7, base + 12)):
        t = tt_(2.2); f = nf(m)
        x = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 5)) * np.minimum(1, t / 0.004) * np.exp(-t * 2.2)
        place(SFX, x, t0 + 0.07 * k, g * (1 - 0.2 * k), (-0.3, 0, 0.3)[k])
def whoosh(t0, d=0.9, g=0.25):
    t = tt_(d); x = noise(d); sw = np.zeros_like(x)
    for k in range(0, len(x), 480):
        fc = 300 + 2200 * np.sin(np.pi * min(1, k / len(x))); sw[k:k + 480] = sosfilt(butter(2, [fc * 0.6, fc * 1.4], "bp", fs=SR, output="sos"), x[k:k + 480])
    place(SFX, sw * np.sin(np.pi * t / d) ** 2, t0 - 0.3, g, 0.15)
def thud(t0, g=0.35, f0=48):
    t = tt_(0.5); k = np.sin(2 * np.pi * (f0 + 60 * np.exp(-t * 25)) * t) * np.exp(-t * 8)
    place(SFX, k + 0.2 * sosfilt(butter(2, 900, "lp", fs=SR, output="sos"), noise(0.5)) * np.exp(-t * 30), t0, g)
for tb in cue["BEEPS"]:   # soft alarm beep: two tones
    for j, f in enumerate((880, 740)):
        t = tt_(0.16); place(SFX, np.sin(2 * np.pi * f * t) * np.sin(np.pi * t / 0.16) ** 2, tb + 0.18 * j, 0.06)
h0, h1 = cue["HEART"]; th = h0
while th < h1:   # heartbeat lub-dub, speeding up
    rate = 1.2 + 1.2 * min(1, (th - h0) / 2.5)
    for j, g in ((0, 0.30), (0.16, 0.20)):
        t = tt_(0.25); place(SFX, np.sin(2 * np.pi * (55 + 30 * np.exp(-t * 30)) * t) * np.exp(-t * 18), th + j, g)
    th += 1 / rate
thud(cue["STAMP"], 0.5, 40); whoosh(cue["STAMP"] - 0.05, 0.4, 0.12)
for tf in cue["FLASH"]:   # camera flash / film flick
    place(SFX, sosfilt(butter(2, 3000, "hp", fs=SR, output="sos"), noise(0.12)) * np.exp(-tt_(0.12) * 30), tf, 0.10)
for k, tp in enumerate(cue["STACK"]):
    t = tt_(0.09); f = 420 + 800 * (t / 0.09); place(SFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 0.09), tp, 0.10, rng.random() * 0.6 - 0.3)
for k, tp in enumerate(cue["FORK"]): chime(tp, [57, 60, 64][k], 0.05)
for tf in cue["FIGHT_HIT"]: thud(tf, 0.30, 60)
for tw in cue["FLIGHT"]: whoosh(tw, 0.7, 0.30)
thud(cue["DOOR"], 0.35, 70)
# frost crackle: sparse high clicks + icy shimmer
t0 = cue["FROST"]
for k in range(90):
    tc = t0 + 3.2 * (k / 90) ** 1.3 + 0.02 * rng.random(); t = tt_(0.02)
    place(SFX, sosfilt(butter(2, 4000, "hp", fs=SR, output="sos"), noise(0.02)) * np.exp(-t * 300), tc, 0.25 * rng.random() + 0.05, rng.random() - 0.5)
t = tt_(3.5); place(SFX, sum(np.sin(2 * np.pi * nf(m) * t) for m in (93, 98, 100)) * np.minimum(1, t / 1.0) * np.exp(-t * 0.8), t0, 0.012)
t = tt_(2.5); place(SFX, sum(np.sin(2 * np.pi * nf(m) * t) for m in (69, 76, 81)) * np.minimum(1, t / 0.3) * np.exp(-t * 1.2), cue["SHIELD"], 0.03)
for th_ in cue["HITS"]:
    t = tt_(0.3); place(SFX, np.sin(2 * np.pi * 1200 * t) * np.exp(-t * 20) + 0.3 * np.sin(2 * np.pi * 1800 * t) * np.exp(-t * 25), th_, 0.05, rng.random() - 0.5)
for k, tp in enumerate(cue["PLANKS"]):   # soft wooden knock
    t = tt_(0.15); place(SFX, np.sin(2 * np.pi * (320 + 20 * k) * t) * np.exp(-t * 40), tp, 0.20, -0.4 + 0.1 * k)
for tp in cue["PEN"]:   # red pen scratch
    x = sosfilt(butter(2, [2000, 6000], "bp", fs=SR, output="sos"), noise(0.3)); t = tt_(0.3)
    place(SFX, x * np.sin(np.pi * t / 0.3) * (0.6 + 0.4 * np.sin(2 * np.pi * 18 * t)), tp, 0.18)
for tc in cue["CHIME"]: chime(tc, 79, 0.11)
chime(cue["QUIET"] + 0.3, 74, 0.05)
for tw in cue["WHOOSH"]: whoosh(tw, 0.7, 0.14)
for tc in cue["CARDS"]: whoosh(tc, 0.6, 0.15)

# ---------------- hook sfx (rehook): bubble pop, riser into "and...", blank-out ring + sub drop on "nothing", alarm beeps
HSFX = (np.zeros(n), np.zeros(n))
t = tt_(0.09); f = 420 + 800 * (t / 0.09); place(HSFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 0.09), HK["ask"], 0.5, -0.3)
d = HK["noth"] - HK["and_"] + 0.1; t = tt_(d); x = noise(d); sw = np.zeros_like(x)
for k in range(0, len(x), 480):
    fc = 400 + 3000 * (k / len(x)) ** 2; sw[k:k + 480] = sosfilt(butter(2, [fc * 0.7, fc * 1.3], "bp", fs=SR, output="sos"), x[k:k + 480])
place(HSFX, sw * (t / d) ** 2, HK["and_"] - 0.1, 0.35)
t = tt_(1.2); place(HSFX, (np.sin(2 * np.pi * 3520 * t) + 0.5 * np.sin(2 * np.pi * 5274 * t)) * np.minimum(1, t / 0.01) * np.exp(-t * 2.6), HK["noth"], 0.10)
t = tt_(0.7); place(HSFX, np.sin(2 * np.pi * (38 + 50 * np.exp(-t * 9)) * t) * np.exp(-t * 5), HK["noth"], 0.9)
for k in range(2):
    for j, f in enumerate((880, 740)):
        t = tt_(0.16); place(HSFX, np.sin(2 * np.pi * f * t) * np.sin(np.pi * t / 0.16) ** 2, HK["noth"] + 0.25 + 0.5 * k + 0.18 * j, 0.25)
# ---------------- narration + ducking
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", VO_P, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
v = np.frombuffer(raw, np.float32).astype(np.float64)[:n]; v = np.pad(v, (0, n - len(v)))
hop = int(0.02 * SR); env = np.sqrt(np.abs(fftconvolve(v ** 2, np.ones(hop) / hop, "same")) + 1e-12)
act = 20 * np.log10(env) > 20 * np.log10(np.abs(v).max()) - 35
lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)))
bed = BED; lb = 20 * np.log10(np.sqrt(np.mean(bed[:, int(B[2] * SR):] ** 2)) + 1e-12)
held = fftconvolve(act.astype(float), np.ones(int(0.3 * SR)), "full")[:n] > 0.5
mask = np.clip(fftconvolve(held.astype(float), np.ones(int(0.15 * SR)) / int(0.15 * SR), "same"), 0, 1)
g_sp, g_gap = 10 ** ((lv - 18 - lb) / 20), 10 ** ((lv - 11 - lb) / 20)
gain = g_gap + (g_sp - g_gap) * mask
sfx = np.stack(SFX); ls = 20 * np.log10(np.sqrt(np.mean(sfx[:, sfx[0] != 0] ** 2)) + 1e-12)
sgain = 10 ** ((lv - 10 - ls) / 20) * (1 - 0.35 * mask)
out = np.stack([v, v]) + bed * gain + sfx * sgain
lh = 20 * np.log10(np.sqrt(np.mean(np.stack(HSFX)[:, np.stack(HSFX)[0] != 0] ** 2)) + 1e-12)
out += np.stack(HSFX) * 10 ** ((lv - 12 - lh) / 20)
fi = int(0.05 * SR); out[:, :fi] *= np.linspace(0, 1, fi); fo = int(1.2 * SR); out[:, -fo:] *= np.linspace(1, 0, fo)
out /= max(1.0, np.abs(out).max() / 0.95)
sf.write(OUT_P, out.T.astype(np.float32), SR)
print("voice", round(lv, 1), "bed", round(lb, 1), "sfx", round(ls, 1), "len", out.shape[1] / SR)
