"""process the four new Cartesia narrations with the house chain + ASR restore (v5lib.process)"""
import sys; sys.path.insert(0, "/home/claude/rehook"); import v5lib, time
J = {"fff": ("/home/claude/rehook/cart_fff_raw.wav", "/home/claude/rehook/cartesia_full_fff.txt", "/home/claude/rehook/vo5/fff"),
     "thinking": ("/home/claude/rehook/cart_thinking_raw.wav", "/home/claude/rehook/cartesia_full_thinking.txt", "/home/claude/rehook/vo5/thinking"),
     "trust": ("/home/claude/rehook/cart_trust_raw.wav", "/home/claude/rehook/cartesia_full_trust.txt", "/home/claude/rehook/vo5/trust"),
     "safety": ("/home/claude/safety_v4/vo_raw_v5.wav", "/home/claude/safety_v4/tts.txt", "/home/claude/safety_v4/work5")}
for k in (sys.argv[1:] or J):
    raw, txt, wd = J[k]; t0 = time.time(); print("=====", k, flush=True)
    lines = [l.strip() for l in open(txt) if l.strip()]
    v5lib.process(raw, lines, wd, log=lambda s: print(s, flush=True)); print(k, "done", round(time.time() - t0), "s", flush=True)
