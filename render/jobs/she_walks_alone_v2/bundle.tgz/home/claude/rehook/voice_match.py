"""Compare the Cartesia hook lines with each reel's ElevenLabs body narration: pitch (F0), spectral balance (LTAS bands),
speech level. Also builds the matching EQ (smooth LTAS correction, clipped to +-5 dB) used by the reel builds.
usage: python3 voice_match.py  -> vo/voice_match.json"""
import json, subprocess, numpy as np, librosa
from scipy.signal import butter, sosfiltfilt
SR = 48000; D = "/home/claude/rehook"
def load(p, a=None, b=None):
    x = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout, np.float32).astype(np.float64)
    return x[int((a or 0) * SR): int(b * SR) if b else None]
def active(x):
    hop = 480; e = np.sqrt(np.convolve(x ** 2, np.ones(hop) / hop, "same")[::hop] + 1e-12); db = 20 * np.log10(e)
    m = db > db.max() - 30; return np.repeat(m, hop)[:len(x)]
BANDS = [(80, 160), (160, 315), (315, 630), (630, 1250), (1250, 2500), (2500, 5000), (5000, 8000), (8000, 12000)]
def stats(x):
    m = active(x); xs = x[m]
    lvl = 10 * np.log10(np.mean(xs ** 2) + 1e-12)
    S = np.abs(librosa.stft(xs.astype(np.float32), n_fft=4096, hop_length=1024)) ** 2; P = S.mean(1); fr = librosa.fft_frequencies(sr=SR, n_fft=4096)
    tot = P[(fr > 80) & (fr < 12000)].sum()
    bands = [round(float(10 * np.log10(P[(fr >= a) & (fr < b)].sum() / tot)), 2) for a, b in BANDS]
    cen = float((P * fr).sum() / P.sum())
    y16 = librosa.resample(xs[: 40 * SR].astype(np.float32), orig_sr=SR, target_sr=16000)
    f0, vf, _ = librosa.pyin(y16, fmin=60, fmax=300, sr=16000, frame_length=1024)
    f0 = f0[vf & ~np.isnan(f0)]
    return dict(level_db=round(float(lvl), 2), centroid_hz=round(cen), bands_db=bands, f0_median=round(float(np.median(f0)), 1),
                f0_p10=round(float(np.percentile(f0, 10)), 1), f0_p90=round(float(np.percentile(f0, 90)), 1),
                f0_range_st=round(float(12 * np.log2(np.percentile(f0, 90) / np.percentile(f0, 10))), 2)), P, fr
BODY = {"fff": ("/home/claude/fff/vo/vo.wav", 5.4, None), "thinking": ("/home/claude/thinking_paths/vo/vo.wav", 9.0, None),
        "trust": ("/home/claude/names/values_2/values_2_v3_vo_padded.wav", 3.6, None)}
HOOK = {"fff": "A", "thinking": "B", "trust": "C"}
out = {}
hall = np.concatenate([load(f"{D}/vo/hook_{k}.wav") for k in "ABC"])
hs, hP, fr = stats(hall); out["hooks_all"] = hs
for name, (p, a, b) in BODY.items():
    bs, bP, _ = stats(load(p, a, b)); h1, h1P, _ = stats(load(f"{D}/vo/hook_{HOOK[name]}.wav"))
    # EQ curve: smoothed ratio body/hook (all three hooks pooled for a stable estimate), in dB, clipped
    sm = lambda v: np.convolve(v, np.ones(41) / 41, "same")
    corr = 10 * np.log10(sm(bP / bP[(fr > 80) & (fr < 12000)].sum()) + 1e-20) - 10 * np.log10(sm(hP / hP[(fr > 80) & (fr < 12000)].sum()) + 1e-20)
    pts = [100, 160, 250, 400, 630, 1000, 1600, 2500, 4000, 6300, 10000]
    eq = [(f, round(float(np.clip(np.interp(np.log(f), np.log(fr[1:]), corr[1:]), -5, 5)), 2)) for f in pts]
    ref = np.interp(np.log(1000), np.log(fr[1:]), corr[1:]); eq = [(f, round(float(np.clip(g - ref, -5, 5)), 2)) for f, g in eq]
    out[name] = dict(body=bs, hook=h1, hook_line=HOOK[name], eq_points=eq,
                     d_f0_semitones=round(float(12 * np.log2(h1["f0_median"] / bs["f0_median"])), 2),
                     d_centroid_hz=h1["centroid_hz"] - bs["centroid_hz"], d_level_db=round(h1["level_db"] - bs["level_db"], 2),
                     d_bands_db=[round(x - y, 2) for x, y in zip(h1["bands_db"], bs["bands_db"])])
    print(name, json.dumps({k: out[name][k] for k in ("d_f0_semitones", "d_centroid_hz", "d_level_db", "d_bands_db")}))
    print("   body", bs); print("   hook", h1); print("   eq", eq)
json.dump(out, open(f"{D}/vo/voice_match.json", "w"), indent=1)
