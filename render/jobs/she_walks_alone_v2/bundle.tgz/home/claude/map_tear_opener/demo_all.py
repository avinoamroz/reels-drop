#!/usr/bin/env python3
"""demo_all.py: all openers back to back with a small style label at the bottom, plus a contact sheet."""
import subprocess, os, sys
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

ORDER = ["globe_spin_fast", "globe_spin_reverse", "globe_spin_whip", "globe_spin_night", "globe_unpeel",
         "map_crumple", "map_tear", "map_tear_v2", "map_fold", "map_puzzle"]
D = "/home/claude/openers_ab/demo"; OUT = "/mnt/user-data/outputs"
FONT = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
os.makedirs(OUT, exist_ok=True)


def label(i, s):
    txt = f"{i}  {s}" + ("  (control)" if s == "map_tear" else ""); f = ImageFont.truetype(FONT, 40)
    w = int(f.getlength(txt)) + 56; im = Image.new("RGBA", (w, 72), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, 71), 36, fill=(11, 20, 38, 190)); d.text((w / 2, 36), txt, font=f, fill=(255, 255, 255, 235), anchor="mm")
    p = f"/tmp/claude-0/label_{s}.png"; im.save(p); return p


ins, fc = [], []
for i, s in enumerate(ORDER):
    ins += ["-i", f"{D}/{s}.mp4", "-i", label(i + 1, s)]
for i in range(len(ORDER)):
    fc.append(f"[{2 * i}:v][{2 * i + 1}:v]overlay=x=(W-w)/2:y=1790,fps=30,format=yuv420p,setsar=1[v{i}];[{2 * i}:a]aformat=sample_rates=48000:channel_layouts=stereo[a{i}]")
fc.append("".join(f"[v{i}][a{i}]" for i in range(len(ORDER))) + f"concat=n={len(ORDER)}:v=1:a=1[v][a]")
subprocess.run(["ffmpeg", "-y", "-v", "error", *ins, "-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]",
                "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
                f"{OUT}/openers_all8.mp4"], check=True)

# contact sheet: one row per style, 7 moments
TS = [0.0, 0.3, 0.8, 1.2, 1.6, 2.0, 2.35]; tw, th = 216, 384; rows = []
f = ImageFont.truetype(FONT, 26)
for i, s in enumerate(ORDER):
    cells = []
    for t in TS:
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(t), "-i", f"{D}/{s}.mp4", "-frames:v", "1", "-vf", f"scale={tw}:{th}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], capture_output=True, check=True)
        c = np.frombuffer(r.stdout, np.uint8).reshape(th, tw, 3).copy(); cv2.putText(c, f"{t:.1f}s", (8, 26), 0, 0.7, (255, 255, 255), 2, cv2.LINE_AA); cells.append(c)
    row = np.hstack(cells); hdr = Image.new("RGB", (row.shape[1], 44), (11, 20, 38)); ImageDraw.Draw(hdr).text((12, 22), f"{i + 1}  {s}" + ("  (control)" if s == "map_tear" else ""), font=f, fill=(255, 205, 80), anchor="lm")
    rows.append(np.vstack([np.asarray(hdr)[..., ::-1], row]))
cv2.imwrite(f"{OUT}/openers_all8.jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 86])
print("ok")
