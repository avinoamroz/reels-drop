#!/usr/bin/env python3
"""story_teaser.py: 8 to 10 s @noamroz__ story = a map opener landing on Israel (hook on screen from frame 0) + 6 s teaser
"New reel: This is what colonization looks like. Watch on my profile", Hebrew line under. 1080x1920 H.264 + AAC, -16 LUFS.
  python3 story_teaser.py opener.mp4 out.mp4
"""
import sys, os, json, subprocess, math, wave
import numpy as np, cv2
sys.path.insert(0, "/home/claude/map_tear_opener")
import hook, map_tear as mt
from PIL import Image, ImageDraw, ImageFont

W, H, FPS, SR = 1080, 1920, 30, 48000
HOOK = "This is what|*colonization*|looks like."
TEASE = 6.0
F_EN = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"; F_EN2 = "/usr/share/fonts/opentype/inter/Inter-Bold.otf"
F_HE = "/root/.fonts/Heebo-ExtraBold.ttf"


def text_img(txt, font, size, rgb, rtl=False):
    f = ImageFont.truetype(font, size); kw = dict(direction="rtl", language="he") if rtl else {}
    w = int(f.getlength(txt, **kw)) + 60; h = int(size * 1.5)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); ImageDraw.Draw(im).text((w / 2, h / 2), txt, font=f, fill=rgb + (255,), anchor="mm", **kw)
    return np.asarray(im).astype(np.float32) / 255


def ease(u): u = min(1.0, max(0.0, u)); return 1 - (1 - u) ** 3


def main(src, out):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-f", "rawvideo", "-pix_fmt", "bgr24", "-"], capture_output=True, check=True)
    fr = np.frombuffer(r.stdout, np.uint8).reshape(-1, H, W, 3); n0 = len(fr); T0 = n0 / FPS
    a = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"], capture_output=True, check=True)
    sfx = np.frombuffer(a.stdout, np.float32).reshape(-1, 2).astype(np.float64)
    himg = hook.make(HOOK)
    t_new = text_img("New reel:", F_EN2, 76, (69, 164, 221))
    t_watch = text_img("Watch on my profile", F_EN, 78, (255, 255, 255))
    t_he = text_img("ריל חדש בפרופיל", F_HE, 66, (255, 205, 80), rtl=True)
    last = fr[-1].astype(np.float32); bg_blur = cv2.GaussianBlur(last, (0, 0), 10)
    yy = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    nT = int(TEASE * FPS); tot = n0 + nT
    # audio: opener SFX, then a soft pad bed with a gentle pulse
    n = int(round(tot / FPS * SR)); au = np.zeros((n, 2)); au[: len(sfx)] += sfx
    tt = np.arange(int(TEASE * SR)) / SR
    pad = sum(np.sin(2 * np.pi * f * tt + i) * 0.9 ** i for i, f in enumerate((110.0, 164.81, 220.0, 277.18, 329.63)))
    pad *= np.clip(tt / 0.6, 0, 1) * np.clip((TEASE - tt) / 0.8, 0, 1)
    beat = np.zeros_like(tt)
    for k in np.arange(0.0, TEASE - 0.5, 0.6):
        i = int(k * SR); m = int(0.25 * SR); x = np.arange(m) / SR
        beat[i:i + m] += np.sin(2 * np.pi * (55 + 40 * np.exp(-x / 0.03)) * x) * np.exp(-x / 0.09)
    bed = pad / np.abs(pad).max() * 0.35 + beat / np.abs(beat).max() * 0.45
    i0 = len(sfx) - int(0.05 * SR); au[i0:i0 + bed.size, 0] += bed[: n - i0]; au[i0:i0 + bed.size, 1] += bed[: n - i0]
    au /= np.abs(au).max(); au *= 0.7
    wav = f"/tmp/story_{os.getpid()}.wav"
    with wave.open(wav, "wb") as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((au * 32767).astype(np.int16).tobytes())
    raw = out + ".tmp.mp4"
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-i", wav,
           "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le", "-shortest", raw.replace(".mp4", ".mkv")]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(tot):
        t = i / FPS
        if i < n0:
            f = hook.overlay(fr[i].astype(np.float32), himg, t, T0, 9, False)
        else:
            u = (i - n0) / FPS
            s = 1 + 0.07 * u / TEASE; M = cv2.getRotationMatrix2D((540, 960), 0, s)
            b = cv2.warpAffine(last * (1 - min(1, u / 0.5)) + bg_blur * min(1, u / 0.5), M, (W, H), borderMode=cv2.BORDER_REPLICATE)
            dk = min(1, u / 0.45) * (0.55 + 0.2 * np.abs(yy - 0.5) * 2)
            f = b * (1 - dk) + mt.NIGHT * dk
            e = ease(u / 0.55)
            f = hook.paste(f, himg, 540, 250 + (900 - 250) * e, 0.68 + (0.95 - 0.68) * e, 1.0)
            for img, y, t0 in ((t_new, 600, 0.15), (t_watch, 1250, 0.55), (t_he, 1360, 0.75)):
                k = ease((u - t0) / 0.4)
                if k > 0: f = hook.paste(f, img, 540, y + 40 * (1 - k), 1.0, k)
            # small arrow cue under the Hebrew line, bobbing
            k = ease((u - 0.95) / 0.4)
            if k > 0:
                yb = 1500 + 14 * math.sin(u * 5)
                lay = np.zeros((H, W), np.uint8); pts = np.array([[540 - 34, yb - 16], [540, yb + 18], [540 + 34, yb - 16]], np.float64)
                cv2.polylines(lay, [np.round(pts * 16).astype(np.int32)], False, 255, 9, cv2.LINE_AA, 4)
                m = lay.astype(np.float32)[..., None] / 255 * k; f = f * (1 - m) + 255 * m
        pr.stdin.write(np.clip(f, 0, 255).astype(np.uint8).tobytes())
    pr.stdin.close(); assert pr.wait() == 0
    mkv = raw.replace(".mp4", ".mkv")
    m = subprocess.run(["ffmpeg", "-v", "info", "-i", mkv, "-af", "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], capture_output=True, text=True).stderr
    js = json.loads(m[m.rindex("{"):m.rindex("}") + 1])
    ln = (f"loudnorm=I=-16:TP=-1.5:LRA=11:measured_I={js['input_i']}:measured_TP={js['input_tp']}:measured_LRA={js['input_lra']}:"
          f"measured_thresh={js['input_thresh']}:offset={js['target_offset']}:linear=true")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", mkv, "-c:v", "copy", "-af", ln + ",aresample=48000", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", out], check=True)
    os.remove(mkv); os.remove(wav)
    print(json.dumps(dict(out=out, s=round(tot / FPS, 2))))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
