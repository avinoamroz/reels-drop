"""Bespoke reelkit scene for arab_haredi_race (30 Oct 2026): one 'race' scene for the whole reel.
Year counter climbs election by election (1949 to 2022, then 2025 population); three panels of bars:
share of population (Arab, Haredi), Knesset seats of 120 (Arab-led, Haredi), turnout (all voters, Arab voters).
Then a reveal card (people vs seats), the gap card, the opinion card, the closing question, and an end card < 1 s.
IG safe zone: everything inside x 40..915, y 250..1540 (right 160 px and bottom 380 px clear). Data: data.json."""
import json, math
import render as RD
from render import P, T, pill, PP, fade_in, block, col, clean
from kit import ease, ramp, lerp, St, sa, rr, box, circ, font, W, H

D = json.load(open("/home/claude/arab_haredi_race/data.json"))
E = D["elections"]; N = len(E); LAT = D["latest"]
CX = 478                      # content centre (right 160 px kept clear)
XL, XR = 50, 912              # content left / right edges
X0, XM = 300, 905             # bar track
NAVY, BLUE, GOLD = "navy", "blue", "gold"

# ---- subtitles: inside the safe zone (centre x 478, bottom edge <= 1535, max 4 words, 54 px)
RD.SUB_Y = 1484
_ss, _sp = RD.sub_surfs, RD.sub_pieces
RD.sub_pieces = lambda TL, replace=(), maxw_words=4: _sp(TL, replace, 4)
def _subs(pieces, sz=54, maxw=800):
    return [(a, b, s, x - (540 - CX), y, d, h) for a, b, s, x, y, d, h in _ss(pieces, 54, 800)]
RD.sub_surfs = _subs
END = {"t": 1e9}
_ds = RD.draw_subs
def _draw_subs(c, t, items):
    if t < END["t"]: _ds(c, t, items)
RD.draw_subs = _draw_subs

CAPS = {0: "First Knesset", 2: "Arab turnout: 91%", 5: "Rakah enters", 6: "East Jerusalem, Golan now counted",
        8: "Hadash founded", 10: "Shas arrives", 11: "Haredi seats: 13", 13: "Shas: 10 seats", 14: "Haredi peak: 22 seats",
        15: "Arab turnout: 62%", 19: "Joint List: 13 seats", 20: "April 2019", 21: "September 2019",
        22: "Arab-led record: 15 seats", 23: "Arab turnout: 44.6%", 24: "Election 25"}
SRC_RACE = ["Population: CBS (Arabs incl. East Jerusalem, Golan),", "IDI Haredi Yearbook. Seats: IDI. est. = estimate",
            "Turnout: Elections Committee, Dayan Center, IDI."]

def tm(S, k, d=None):
    return S["times"].get(k, d)

def idx_at(S, t):
    """float election index driven by narration marks"""
    g = lambda k, d: tm(S, k, d)
    k = [(0.0, 0), (g("L3", 12) - 1.4, 0), (g("y55", 13.5), 2), (g("L4", 17.5) + 0.3, 2), (g("y84", 19.5), 10),
         (g("y84", 19.5) + 0.5, 10), (g("y99", 22.5), 14), (g("s22", 24) + 0.4, 14), (g("y20", 26.5), 22), (g("L7", 30), 22),
         (g("L7", 30) + 0.6, 23), (g("L8", 33.5) - 0.9, 23), (g("L8", 33.5) - 0.1, 24)]
    if t <= k[0][0]: return 0.0
    for (t0, v0), (t1, v1) in zip(k, k[1:]):
        if t <= t1: return v0 + (v1 - v0) * ease((t - t0) / max(1e-3, t1 - t0)) if t1 > t0 else v1
    return float(N - 1)

def vals(S, t):
    u = idx_at(S, t); i = min(N - 2, int(u)); f = u - i
    a, b = E[i], E[i + 1]
    L = lambda key: lerp(a[key], b[key], f)
    v = dict(u=u, ap=L("arab_pop_pct"), hp=L("haredi_pop_pct"), as_=L("arab_seats"), hs=L("haredi_seats"),
             tn=L("turnout_national"), ta=L("turnout_arab"), year=lerp(a["year"], b["year"], f), k=int(round(u)))
    v["hest"] = E[v["k"]]["haredi_pop_est"]; v["sest"] = E[v["k"]]["haredi_seats_est"]
    # today: population to the latest CBS / IDI figure
    p = ramp(t, tm(S, "L8", 1e9), tm(S, "L8", 1e9) + 1.1)
    if p > 0:
        v["ap"] = lerp(v["ap"], LAT["arab_pop_pct"], ease(p)); v["hp"] = lerp(v["hp"], LAT["haredi_pop_pct"], ease(p))
        v["year"] = lerp(2022, 2025, ease(p)); v["hest"] = False; v["today"] = p
    # grow in from zero at frame 0
    g0 = 0.45 + 0.55 * ease(min(1.0, t / 1.2))
    for kk in ("ap", "hp", "as_", "hs", "tn", "ta"): v[kk] *= g0
    kmax = max(0, int(math.floor(u + 1e-6)))
    v["mx"] = {kk: max(e[src] for e in E[:kmax + 1]) for kk, src in (("ap", "arab_pop_pct"), ("hp", "haredi_pop_pct"), ("as_", "arab_seats"),
                                                                   ("hs", "haredi_seats"), ("tn", "turnout_national"), ("ta", "turnout_arab"))}
    return v

def bar(c, t, y, label, v, vmax, cc, txt, est=False, ghost=None, flash=None):
    T(c, label, 56, XL + 6, y, P["navy"], 1, 1, 800, anchor="l", maxw=X0 - XL - 20)
    box(c, X0, y - 32, XM - X0, 64, 32, P["silver"], 0.35)
    bw = max(64, (XM - X0) * min(v, vmax) / vmax)
    box(c, X0, y - 32, bw, 64, 32, col(cc))
    if ghost and ghost > v + 0.05:
        gx = X0 + (XM - X0) * min(ghost, vmax) / vmax
        sa(c, P["navy"], 0.45 * St.a); c.set_line_width(5); c.move_to(gx, y - 42); c.line_to(gx, y + 42); c.stroke()
    if flash is not None:
        fa = max(0.0, 1 - abs(t - flash - 0.5) / 0.7)
        if fa > 0:
            sa(c, P["gold2"], fa * St.a); c.set_line_width(8); rr(c, X0 - 8, y - 40, bw + 16, 80, 40); c.stroke()
    tw = font(56, 900).getlength(txt); ew = font(40, 700).getlength(" est.") if est else 0
    if tw + ew + 44 < bw:
        xr = X0 + bw - 22
        if est: T(c, "est.", 40, xr, y + 4, P["white"], 1, 1, 700, anchor="r"); xr -= ew + 4
        T(c, txt, 56, xr, y + 2, P["white"], 1, 1, 900, anchor="r")
    else:
        xl = X0 + bw + 14
        T(c, txt, 56, xl, y + 2, P["navy"], 1, 1, 900, anchor="l")
        if est: T(c, "est.", 40, xl + tw + 10, y + 4, P["grey"], 1, 1, 700, anchor="l")

def panel_title(c, y, left, right=None, rc="gold_text"):
    T(c, left, 56, XL + 6, y, P["navy"], 1, 1, 900, anchor="l", maxw=560)
    if right: T(c, right, 56, XR, y, col(rc), 1, 1, 900, anchor="r", maxw=330)

def fmt1(x): return f"{x:.1f}%"

def panels(c, t, S, v):
    y0 = 560
    fl = lambda k: tm(S, k)
    # A: population
    both = v["ap"] + v["hp"]
    panel_title(c, y0 + 28, "Share of Israelis", f"Both: {round(both)}%")
    bar(c, t, y0 + 100, "Arab", v["ap"], 25, BLUE, fmt1(v["ap"]), ghost=v["mx"]["ap"], flash=fl("a14") if t < tm(S, "L3", 99) else fl("a21"))
    htxt = f"{round(v['hp'])}%" if v["hest"] else fmt1(v["hp"])
    bar(c, t, y0 + 190, "Haredi", v["hp"], 25, GOLD, htxt, est=v["hest"], ghost=v["mx"]["hp"], flash=fl("h3") if t < tm(S, "L3", 99) else fl("h14"))
    # B: seats
    y1 = y0 + 246; sb = round(v["as_"]) + round(v["hs"])
    panel_title(c, y1 + 28, "Knesset seats, of 120", f"Both: {sb}")
    bar(c, t, y1 + 100, "Arab-led", v["as_"], 25, BLUE, f"{round(v['as_'])}", ghost=v["mx"]["as_"], flash=fl("s7") if t < tm(S, "L3", 99) else fl("s15"))
    bar(c, t, y1 + 190, "Haredi", v["hs"], 25, GOLD, f"{round(v['hs'])}", est=v["sest"], ghost=v["mx"]["hs"], flash=fl("s7") if t < tm(S, "L3", 99) else fl("s22"))
    # C: turnout
    y2 = y1 + 246
    panel_title(c, y2 + 28, "Voter turnout")
    bar(c, t, y2 + 100, "All", v["tn"], 100, NAVY, fmt1(v["tn"]), ghost=v["mx"]["tn"])
    fa = fl("t91") if t < tm(S, "L7", 99) else fl("t45")
    bar(c, t, y2 + 190, "Arab", v["ta"], 100, BLUE, fmt1(v["ta"]), ghost=v["mx"]["ta"], flash=fa)

def sources(c, t, lines, a=1.0):
    for k, l in enumerate(lines):
        T(c, l, 36, CX, 1318 + 44 * k, P["grey"], a, 1.0, 700, maxw=860, src=True)

def topband(c, t, S, v):
    hook_end = tm(S, "L2", 6.0) - 0.25
    ha = 1.0 - ramp(t, hook_end, hook_end + 0.3)
    if ha > 0.01:
        old = St.a; St.a *= ha
        pill(c, "Arab or Haredi Israelis", 56, CX, 300, P["navy"], P["white"], 1, 1, outline=P["gold"], w=800)
        T(c, "1949: *1 in 6*", 100, CX, 408, P["navy"], 1, 1, 900, hl=P["blue"], maxw=860)
        tt = tm(S, "today1", 3.0); a2, s2 = PP(t, tt, S, bounce=2.2)
        T(c, "Today: *1 in 3*", 100, CX, 510, P["navy"], 1, 1.0 + 0.08 * max(0.0, 1 - abs(t - tt - 0.3) / 0.4), 900, hl=P["gold"], maxw=860)
        St.a = old
    ya = ramp(t, hook_end, hook_end + 0.3)
    if ya <= 0.01: return
    old = St.a; St.a *= ya
    yr = int(math.floor(v["year"] + 1e-6))
    T(c, str(yr), 150, XL + 4, 345, P["navy"], 1, 1, 900, anchor="l")
    right = "Today" if v.get("today", 0) > 0.5 else f"Election {v['k'] + 1} of {N}"
    T(c, right, 56, XR, 345, P["gold_text"], 1, 1, 900, anchor="r", maxw=440)
    cap = "Population today" if v.get("today", 0) > 0.5 else None
    if cap is None:
        ks = [k for k in CAPS if k <= v["k"]]; cap = CAPS[max(ks)] if ks else ""
    if S.get("_cap") != cap: S["_cap"] = cap; S["_capt"] = t
    a, s = kitpop(t, S.get("_capt", 0))
    if cap: pill(c, cap, 54, CX, 478, P["gold"], P["white"], a, s, w=800)
    St.a = old

def kitpop(t, t0):
    import kit
    return kit.pop(t, t0, 0.4, 0.5, 1.8)

def card(c, a):
    sa(c, P["navy"], 0.12 * a * St.a); rr(c, XL + 4, 574, XR - XL, 720, 40); c.fill()
    box(c, XL, 560, XR - XL, 720, 40, P["white"], a, stroke=P["navy"], sw=5)

def reveal(c, t, S):
    """people vs seats table (line 8)"""
    T(c, "Together, today", 66, CX, 636, P["navy"], 1, 1, 900)
    T(c, "People", 56, 590, 735, P["grey"], 1, 1, 800); T(c, "Seats", 56, 800, 735, P["grey"], 1, 1, 800)
    rows = [("Arab", fmt1(LAT["arab_pop_pct"]), str(E[-1]["arab_seats"]), "a21", BLUE),
            ("Haredi", fmt1(LAT["haredi_pop_pct"]), str(E[-1]["haredi_seats"]), "h14", GOLD)]
    ts = tm(S, "but22", tm(S, "L8") + 4)
    for k, (lab, pp, ss, mk, cc) in enumerate(rows):
        y = 835 + 100 * k; a, s = PP(t, tm(S, mk, tm(S, "L8") + 1 + k), S)
        if a > 0.01:
            circ(c, XL + 46, y, 14, col(cc), a)
            T(c, lab, 60, XL + 76, y, P["navy"], a, 1, 800, anchor="l")
            T(c, pp, 64, 590, y, col(cc), a, s, 900)
        a2, s2 = PP(t, ts + 0.1 * k, S)
        if a2 > 0.01: T(c, ss, 64, 800, y, col(cc), a2, s2, 900)
    tb = tm(S, "h14", tm(S, "L8") + 2) + 0.9; a, s = PP(t, tb, S, bounce=2.2)
    if a > 0.01:
        box(c, XL + 20, 980, XR - XL - 40, 130, 34, P["navy"], a)
        T(c, "Both", 60, XL + 60, 1046, P["white"], a, 1, 800, anchor="l")
        both = LAT["arab_pop_pct"] + LAT["haredi_pop_pct"]
        T(c, f"{round(both)}%", 92, 590, 1048, P["gold2"], a, s, 900)
    a3, s3 = PP(t, tm(S, "s28", ts + 1.2), S, bounce=2.6)
    if a3 > 0.01:
        T(c, "28", 92, 800, 1048, P["gold2"], a3, s3, 900)
        seats = E[-1]["arab_seats"] + E[-1]["haredi_seats"]
        T(c, f"{seats} of 120 seats = *{round(100 * seats / 120)}%*", 60, CX, 1190, P["navy"], a3, 1, 900, hl=P["blue"], maxw=820)

def gap(c, t, S):
    T(c, "Part of the gap", 66, CX, 636, P["navy"], 1, 1, 900)
    a, s = PP(t, tm(S, "ej", tm(S, "L9") + 1.2), S)
    if a > 0.01:
        block(c, "Most East Jerusalem Arabs are *residents, not citizens*", 62, CX, 790, P["navy"], a, s, 900, hl=P["blue"], maxw=800, max_lines=2)
    a, s = PP(t, tm(S, "t53", tm(S, "L9") + 3.5), S, bounce=2.4)
    if a > 0.01:
        T(c, "Arab turnout, 2022", 58, CX, 950, P["navy"], a, 1, 800)
        T(c, "53.2%", 150, CX, 1070, P["blue"], a, s, 900)
        T(c, "All voters: 70.6%", 58, CX, 1190, P["grey"], a, 1, 800)

def opinion(c, t, S):
    a, s = PP(t, tm(S, "L10"), S)
    pill(c, "In my view", 56, CX, 680, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
    T(c, "Turnout is the key.", 80, CX, 800, P["navy"], a, s, 900, maxw=840)
    a, s = PP(t, tm(S, "oth", tm(S, "L10") + 2), S)
    pill(c, "Others say", 56, CX, 990, P["gold"], P["white"], a, s, w=800)
    T(c, "It's about trust.", 80, CX, 1110, P["navy"], a, s, 900, maxw=840)

def closing(c, t, S):
    a, s = PP(t, tm(S, "L11"), S)
    T(c, "*1 in 3* Israelis", 104, CX, 700, P["navy"], a, s, 900, hl=P["blue"], maxw=840)
    a, s = PP(t, tm(S, "under", tm(S, "L11") + 1.2), S)
    T(c, "Under *1 in 4* seats", 90, CX, 860, P["navy"], a, s, 900, hl=P["blue"], maxw=840)
    a, s = PP(t, tm(S, "q", tm(S, "L11") + 2.4), S, bounce=2.4)
    if a > 0.01:
        box(c, XL + 30, 990, XR - XL - 60, 200, 46, P["navy"], a)
        T(c, "Will the gap close?", 74, CX, 1092, P["gold2"], a, s, 900, maxw=720)

def sc_race(c, t, S):
    t_end = S["t1"]; END["t"] = t_end - 0.8
    if t >= t_end - 0.8:      # end card, under 1 s
        a = ramp(t, t_end - 0.8, t_end - 0.65)
        sa(c, P["navy"], a); c.rectangle(0, 0, W, H); c.fill()
        T(c, "@noamroz__", 96, CX, 880, P["white"], a, 1, 900); T(c, "Follow for more data", 56, CX, 990, P["gold2"], a, 1, 800)
        return
    v = vals(S, t)
    topband(c, t, S, v)
    L8 = tm(S, "L8", 1e9); ra = ramp(t, L8 + 0.15, L8 + 0.5)
    old = St.a; St.a *= (1 - 0.85 * ra); panels(c, t, S, v); St.a = old
    if ra > 0.01:
        old = St.a; St.a *= ra; card(c, 1.0)
        ph = [(L8, reveal), (tm(S, "L9", 1e9), gap), (tm(S, "L10", 1e9), opinion), (tm(S, "L11", 1e9), closing)]
        cur = [k for k, (t0, _) in enumerate(ph) if t >= t0 - 0.12]; k = cur[-1]
        t0 = ph[k][0]; ia = ramp(t, t0 - 0.12, t0 + 0.12) if k else 1.0
        St.a *= ia; ph[k][1](c, t, S); St.a = old
    if t < L8 + 0.3: sources(c, t, SRC_RACE, 1 - ra)
    else:
        src = {0: ["Sources: CBS end 2025, IDI Haredi Yearbook 2025,", "IDI 2022 results (Arab-led and Haredi parties)."],
               1: ["Sources: IDI Arab society report (East Jerusalem);", "INSS 2022, Dayan Center (turnout)."],
               2: ["Opinion lines, not data."],
               3: ["Population: CBS, IDI 2025. Seats: 2022, IDI."]}
        ks = [k for k, n in enumerate(("L8", "L9", "L10", "L11")) if t >= tm(S, n, 1e9)]
        sources(c, t, src[ks[-1] if ks else 0])
