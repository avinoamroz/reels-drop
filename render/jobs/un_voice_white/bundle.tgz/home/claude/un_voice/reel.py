"""UN MATH, narrated (un_voice / un_voice_white). Same design as the un_imbalance winner, retimed to Noam's voice.
usage: python3 reel.py --theme dark|white --snaps t1,t2,...  |  --render OUT.mp4 [--audio mix.wav]
timeline.json (voice word times) and mix.wav come from vo_build.py / audio.py in this folder.
"""
import sys, os, json, math, subprocess, argparse
import numpy as np, cairo
from PIL import Image, ImageDraw
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D)
from lib import W, H, FPS, hx, ease, eob, ramp, lerp, font, pil2cairo, rr, paste, stroke_style, is_he, DASHES
from script import LINES

ap = argparse.ArgumentParser(); ap.add_argument("--theme", default="dark"); ap.add_argument("--snaps"); ap.add_argument("--render")
ap.add_argument("--audio"); ap.add_argument("--qa")
A = ap.parse_args(); WHITE = A.theme == "white"
QA = A.qa or os.path.join(D, "qa"); os.makedirs(QA, exist_ok=True)

# ------------------------------------------------------------------ palette
def c255(h, a=255): h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
if not WHITE:
    BG_STOPS = ["#04070E", "#0A1222", "#0E1E3A"]; VIGNETTE = 0.75
    TXT = c255("#EDE6D6"); SUB = (196, 204, 218, 255); HL = (255, 213, 74, 255)
    DEAD_NUM = TXT; DEAD_LBL = (200, 80, 88, 255); ISR_NUM = (214, 92, 100, 255); ISR_COL = hx("#C9454E")
    OTH_COL = hx("#5D6675"); OTH_NUM = (200, 208, 222, 255); STACK_OTH = hx("#9AA4B5"); ZERO = (150, 160, 176, 255)
    LBL = (235, 235, 240, 255); FLAG_OUT = (1, 1, 1, 0.35); DUSTC = hx("#9AA4B5"); AXIS = (1, 1, 1, 0.3)
    CAP_TXT = (255, 255, 255, 255); CAP_FILL = (3, 6, 12, 150); CAP_OUT = (255, 255, 255, 26); CAP_W = 2
    Q_FILL = (10, 18, 34, 235); Q_OUT = HL; Q_TXT = (255, 255, 255, 255); ARROW = HL
    W_HEAD, W_BODY, W_HE = 900, 800, 700
else:
    BG_STOPS = ["#FFFFFF", "#F7F7F5", "#F7F7F5"]; VIGNETTE = 0.0
    NAVY = c255("#163260"); TXT = NAVY; SUB = c255("#3E4A5C"); HL = c255("#F2B705")
    DEAD_NUM = c255("#D7263D"); DEAD_LBL = NAVY; ISR_NUM = c255("#2A88D4"); ISR_COL = hx("#2A88D4")
    OTH_COL = hx("#2F3437"); OTH_NUM = c255("#2F3437"); STACK_OTH = hx("#5A6068"); ZERO = c255("#2F3437")
    LBL = NAVY; FLAG_OUT = (*hx("#163260")[:3], 0.9); DUSTC = hx("#163260"); AXIS = (*hx("#163260")[:3], 0.9)
    CAP_TXT = NAVY; CAP_FILL = (255, 255, 255, 255); CAP_OUT = NAVY; CAP_W = 6
    Q_FILL = NAVY; Q_OUT = HL; Q_TXT = (255, 255, 255, 255); ARROW = c255("#D7263D")
    W_HEAD, W_BODY, W_HE = 900, 900, 800
WOOD = hx("#5A3A22"); WOOD_L = hx("#8A5F3C")
TXT_RGB = tuple(v / 255 for v in TXT[:3])

# ------------------------------------------------------------------ timeline from the voice
TL = json.load(open(f"{D}/timeline.json")); L = TL["lines"]
def word_t(li, w):
    for x in L[li]["words"]:
        if x["w"].strip(".,?!").lower() == w: return x["t0"]
    raise KeyError(w)
T_SY, T_YE, T_SU, T_IL, T_CMP, T_END_CARD = (L[i]["t0"] - 0.15 for i in (1, 5, 9, 12, 15, 17))
T_Q = L[18]["t0"] - 0.1
T_END = round(L[18]["t1"] + 3.2, 2)
N = int(round(T_END * FPS))
CAPS = [(0.0, T_SY, None, None)]
for i in range(1, 17):
    t0 = L[i]["t0"] - 0.1; t1 = (L[i + 1]["t0"] - 0.1) if i < 16 else T_END_CARD
    CAPS.append((t0, t1, LINES[i][1], LINES[i][2]))
T_MEH = L[4]["t0"]
T_80 = word_t(15, "eighty"); T_TWICE = word_t(16, "twice")
ISR_N, REST_N = 173, 80
T_SLAM0, T_SLAM1, NSLAM = L[13]["t0"] + 0.05, L[14]["t1"] - 0.05, 22
SLAMS = [T_SLAM0 + (T_SLAM1 - T_SLAM0) * (k / (NSLAM - 1)) ** 0.7 for k in range(NSLAM)]
w_ = np.arange(1, NSLAM + 1, dtype=float); CUM = np.round(np.cumsum(w_) / w_.sum() * ISR_N).astype(int); CUM[-1] = ISR_N
SY_RES = CAPS[2][0]
json.dump(dict(T_END=T_END, T_SY=T_SY, T_YE=T_YE, T_SU=T_SU, T_IL=T_IL, T_CMP=T_CMP, T_ENDC=T_END_CARD, T_Q=T_Q, T_MEH=T_MEH,
               SLAMS=SLAMS, SYRIA_PAPER=SY_RES + 0.5, T_80=T_80, CAPS=[c[0] for c in CAPS]), open(f"{D}/cues.json", "w"), indent=1)

# ------------------------------------------------------------------ text assets
def check(s): assert not any(d in s for d in DASHES), s
def caption(parts, he_max=930):
    """parts: (kind, text, size). *word* = highlight: gold text (dark) or gold marker behind navy text (white)."""
    blocks = []
    for kind, s, sz in parts:
        check(s)
        if kind == "he":
            assert is_he(s); f = font(sz, W_HE)
            while f.getlength(s) > he_max and sz > 50: sz -= 1; f = font(sz, W_HE)
            assert f.getlength(s) <= he_max, ("hebrew too wide", s)
            blocks.append(("he", [[(s, False)]], sz, f, 1.25)); continue
        f = font(sz, W_HEAD if kind == "head" else W_BODY); toks = []; yel = False
        for p in s.replace("*", " * ").replace("\n", " \n ").split(" "):
            if p == "*": yel = not yel; continue
            if p == "\n": toks.append(("\n", None)); continue
            if p: toks.append((p, yel))
        lines, cur = [], []
        for t in toks:
            if t[0] == "\n": lines.append(cur); cur = []; continue
            if cur and f.getlength(" ".join(x for x, _ in cur + [t])) > 900: lines.append(cur); cur = [t]
            else: cur.append(t)
        if cur: lines.append(cur)
        assert len(lines) <= 3, s
        for ln in lines: assert f.getlength(" ".join(x for x, _ in ln)) <= 940, ("too wide", s)
        blocks.append((kind, lines, sz, f, 1.14 if kind == "head" else 1.2))
    GAPS = {"head": 22, "body": 22, "he": 0}
    hgt = sum(len(ln) * sz * lh + GAPS[k] for k, ln, sz, f, lh in blocks)
    im = Image.new("RGBA", (W, int(hgt) + 12), (0, 0, 0, 0)); d = ImageDraw.Draw(im); y = 6
    for k, ln, sz, f, lh in blocks:
        for line in ln:
            yy = y + sz * lh / 2
            if k == "he": d.text((540, yy), line[0][0], font=f, fill=CAP_TXT, anchor="mm")
            else:
                sp = f.getlength(" "); ws = [f.getlength(w_) for w_, _ in line]; x = 540 - (sum(ws) + sp * (len(ws) - 1)) / 2
                if WHITE:   # marker behind highlighted runs
                    xx = x; run = None
                    for (w_, h_), ww in zip(line, ws):
                        if h_: run = [run[0] if run else xx, xx + ww]
                        elif run: d.rounded_rectangle([run[0] - 12, yy - sz * 0.5, run[1] + 12, yy + sz * 0.5], radius=10, fill=HL); run = None
                        xx += ww + sp
                    if run: d.rounded_rectangle([run[0] - 12, yy - sz * 0.5, run[1] + 12, yy + sz * 0.5], radius=10, fill=HL)
                for (w_, h_), ww in zip(line, ws):
                    d.text((x, yy), w_, font=f, fill=(HL if (h_ and not WHITE) else CAP_TXT), anchor="lm"); x += ww + sp
            y += sz * lh
        y += GAPS[k]
    return im
def boxed(parts, pad=(44, 30)):
    im = caption(parts); bb = im.getbbox(); x0, y0, x1, y1 = bb
    bw, bh = x1 - x0 + 2 * pad[0], y1 - y0 + 2 * pad[1]
    out = Image.new("RGBA", (W, bh + 12), (0, 0, 0, 0)); d = ImageDraw.Draw(out)
    if WHITE: d.rounded_rectangle([540 - bw / 2 + 8, 14, 540 + bw / 2 + 8, 6 + bh + 8], radius=34, fill=(22, 50, 96, 255))   # hard offset shadow
    d.rounded_rectangle([540 - bw / 2, 4, 540 + bw / 2, 4 + bh], radius=34, fill=CAP_FILL, outline=CAP_OUT, width=CAP_W)
    out.alpha_composite(im.crop(bb), (int(540 - (x1 - x0) / 2), 4 + pad[1])); return out
CAP_S = {}
for k, (t0, t1, en, he) in enumerate(CAPS):
    if en is None: continue
    CAP_S[k] = pil2cairo(boxed([("body", en, 86), ("he", he, 66)]))
HOOK = pil2cairo(caption([("head", "How the *UN*\ncounts victims", 148), ("he", "איך האו״ם סופר קורבנות", 70)]))
YAWN = pil2cairo(Image.open(f"{D}/assets/yawn.png").convert("RGBA"))
_tc = {}
def T(s, sz, w=800, fill=(255, 255, 255, 255), track=0):
    k = (s, sz, w, fill, track)
    if k in _tc: return _tc[k]
    check(s); f = font(sz, w)
    if track: ws = [f.getlength(ch) for ch in s]; tw = sum(ws) + track * (len(s) - 1)
    else: tw = f.getlength(s)
    im = Image.new("RGBA", (int(tw) + 24, int(sz * 1.5)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if track:
        x = 12
        for ch, ww in zip(s, ws): d.text((x, sz * 0.75), ch, font=f, fill=fill, anchor="lm"); x += ww + track
    else: d.text((im.size[0] / 2, sz * 0.75), s, font=f, fill=fill, anchor="mm")
    _tc[k] = pil2cairo(im); return _tc[k]
SRC_W = 800 if WHITE else 700

# ------------------------------------------------------------------ background
def make_bg():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H)
    for st, col in zip((0, 0.6, 1), BG_STOPS): g.add_color_stop_rgba(st, *hx(col)[:3], 1)
    c.set_source(g); c.paint()
    if VIGNETTE:
        g = cairo.RadialGradient(540, 900, 200, 540, 960, 1250); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0, 0, 0, VIGNETTE)
        c.set_source(g); c.paint()
    else:   # bold navy frame bars top and bottom
        c.rectangle(0, 0, W, 22); c.set_source_rgba(*hx("#163260")[:3], 1); c.fill()
        c.rectangle(0, H - 22, W, 22); c.fill()
    return s
BG_S = make_bg()
DUST = np.random.default_rng(3).random((36, 5))
def dust(c, t, a=1.0):
    for x0, y0, sp, r, ph in DUST:
        y = (y0 * 2100 + t * (8 + 14 * sp)) % 2100 - 90; x = x0 * W + 14 * math.sin(t * 0.3 + ph * 6)
        al = a * (0.05 + 0.09 * (0.5 + 0.5 * math.sin(t * 1.1 + ph * 9))) * (0.5 if WHITE else 1)
        c.set_source_rgba(*DUSTC[:3], al); c.arc(x, y, 1.2 + 2.5 * r, 0, 2 * math.pi); c.fill()

# ------------------------------------------------------------------ flags
def star5(c, x, y, r):
    for k in range(10):
        rad = r if k % 2 == 0 else r * 0.382; an = -math.pi / 2 + k * math.pi / 5
        (c.move_to if k == 0 else c.line_to)(x + rad * math.cos(an), y + rad * math.sin(an))
    c.close_path()
def flag(c, kind, cx, cy, w, a):
    if a <= 0.01: return
    h = w * (8 / 11 if kind == "il" else 2 / 3); x, y = cx - w / 2, cy - h / 2
    c.push_group(); c.save(); rr(c, x, y, w, h, 6); c.clip()
    def bands(cols):
        for k, col in enumerate(cols): c.rectangle(x, y + k * h / 3, w, h / 3 + 1); c.set_source_rgba(*hx(col)[:3], 1); c.fill()
    if kind == "sy":
        bands(["#007A3D", "#FFFFFF", "#000000"])
        for k in (-1, 0, 1): star5(c, cx + k * w * 0.22, cy, h * 0.12); c.set_source_rgba(*hx("#CE1126")[:3], 1); c.fill()
    elif kind == "ye": bands(["#CE1126", "#FFFFFF", "#000000"])
    elif kind == "sd":
        bands(["#D21034", "#FFFFFF", "#000000"]); c.move_to(x, y); c.line_to(x + w / 3, cy); c.line_to(x, y + h); c.close_path(); c.set_source_rgba(*hx("#007229")[:3], 1); c.fill()
    elif kind == "il":
        c.set_source_rgba(1, 1, 1, 1); c.paint(); blue = hx("#0038B8")
        for yy in (15, 120): c.rectangle(x, y + h * yy / 160, w, h * 25 / 160); c.set_source_rgba(*blue[:3], 1); c.fill()
        r = h * 0.215; stroke_style(c, blue, h * 5.5 / 160); c.set_line_join(cairo.LINE_JOIN_MITER)
        for rot in (0, math.pi):
            for k in range(3):
                an = -math.pi / 2 + rot + k * 2 * math.pi / 3; (c.move_to if k == 0 else c.line_to)(cx + r * math.cos(an), cy + r * math.sin(an))
            c.close_path(); c.stroke()
    c.restore(); rr(c, x, y, w, h, 6); stroke_style(c, FLAG_OUT, 4 if WHITE else 2); c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a)

# ------------------------------------------------------------------ gavel + papers
BLOCK = (300, 1440)
def gavel(c, ang, a, shake=0.0):
    if a <= 0.01: return
    bx, by = BLOCK
    c.push_group()
    rr(c, bx - 120, by - 6, 240, 46, 14); c.set_source_rgba(*hx("#3A2516")[:3], 1); c.fill()
    rr(c, bx - 120, by - 6, 240, 14, 7); c.set_source_rgba(*WOOD_L[:3], 0.8); c.fill()
    px, py = bx + 250, by - 70; R = 250; th = math.pi + ang
    hxp, hyp = px + R * math.cos(th), py + R * math.sin(th)
    stroke_style(c, WOOD, 26); c.move_to(px + 30 * math.cos(th + math.pi), py + 30 * math.sin(th + math.pi)); c.line_to(hxp, hyp); c.stroke()
    stroke_style(c, (*WOOD_L[:3], 0.6), 6); c.move_to(px, py - 6); c.line_to(hxp, hyp - 6); c.stroke()
    c.save(); c.translate(hxp + shake, hyp); c.rotate(th + math.pi / 2)
    rr(c, -46, -82, 92, 164, 20); c.set_source_rgba(*WOOD[:3], 1); c.fill()
    for yy in (-58, 46): rr(c, -50, yy, 100, 14, 6); c.set_source_rgba(*hx("#B8923F")[:3], 0.9); c.fill()
    rr(c, -46, -82, 92, 164, 20); stroke_style(c, (*WOOD_L[:3], 0.9), 4); c.stroke()
    c.restore()
    c.pop_group_to_source(); c.paint_with_alpha(a)
SHEET_W, SHEET_T, STACK_X, STACK_BASE = 270, 3.3, 740, 1480
def sheet(c, x, y, rot, a, col, w=SHEET_W, h=None):
    if a <= 0.01: return
    h = h or w * 1.3
    c.save(); c.translate(x, y); c.rotate(rot); rr(c, -w / 2, -h / 2, w, h, 6); c.set_source_rgba(*col[:3], a); c.fill()
    for k in range(5): rr(c, -w * 0.36, -h * 0.32 + k * h * 0.13, w * (0.72 if k % 2 == 0 else 0.5), 8, 4); c.set_source_rgba(0, 0, 0, 0.25 * a); c.fill()
    c.restore()
def stack(c, n, a, col, x=STACK_X, base=STACK_BASE, t=0.0, wob=0.0):
    if a <= 0.01 or n <= 0: return
    rng = np.random.default_rng(11)
    offs = rng.normal(0, 4, 200); lum = rng.random(200)
    full = int(n); frac = n - full
    for k in range(full + (1 if frac > 0.02 else 0)):
        y = base - (k + 1) * SHEET_T; sway = wob * (k / ISR_N) ** 2 * math.sin(t * 6) * 18
        cc = (lerp(col[0] * 0.72, col[0], lum[k]), lerp(col[1] * 0.72, col[1], lum[k]), lerp(col[2] * 0.72, col[2], lum[k]))
        al = a * (frac if k == full else 1)
        c.rectangle(x - SHEET_W / 2 + offs[k] + sway, y, SHEET_W, SHEET_T - 0.6); c.set_source_rgba(*cc, al); c.fill()
    top = base - n * SHEET_T
    c.rectangle(x - SHEET_W / 2 + offs[max(0, full - 1)], top - 2, SHEET_W, 3); c.set_source_rgba(1, 1, 1, 0.25 * a); c.fill()

# ------------------------------------------------------------------ counters
def fmt(n): return f"{int(round(n)):,}"
def counter(c, val, suffix, y, a, sz=190, fill=TXT, sc=1.0):
    if a <= 0.01: return
    paste(c, T(fmt(val) + suffix, sz, 900, fill), 540, y, a, sc=sc)

# ------------------------------------------------------------------ scenes
COUNTRIES = [  # kind, name, t0, t1, dead, suffix, source, roll
    ("sy", "SYRIA", T_SY, T_YE, 500000, "+", "Dead since 2011. Source: SOHR / UN", 1.8),
    ("ye", "YEMEN", T_YE, T_SU, 377000, "", "Dead by end of 2021, direct and indirect. Source: UNDP", 1.6),
    ("sd", "SUDAN", T_SU, T_IL, 150000, "", "Since April 2023, upper estimate. Source: US envoy, 2024", 1.4),
]
def header(c, kind, name, a, dy=0):
    tw = T(name, 66, 900, TXT if WHITE else SUB, track=10); fw = 130
    total = fw + 30 + tw.get_width(); x0 = 540 - total / 2
    flag(c, kind, x0 + fw / 2, 320 + dy, fw, a); paste(c, tw, x0 + fw + 30, 320 + dy, a, anchor="cl")
def res_panel(c, t, a, kind, k):
    paste(c, T("UNGA resolutions", 50, 900 if WHITE else 800, SUB), STACK_X, 1112, a)
    if kind == "sy":
        u = ramp(t, CAPS[2][0], CAPS[2][0] + 0.4)
        paste(c, T("~1 a year", 104, 900, TXT), STACK_X, 1222, a * u, sc=lerp(1.15, 1, eob(u)))
        n = 10 * ramp(t, SY_RES + 0.3, SY_RES + 1.0); stack(c, n, a, STACK_OTH)
        if SY_RES + 0.1 < t < SY_RES + 0.7:
            v = ease((t - SY_RES - 0.1) / 0.6); sheet(c, STACK_X + 40 * (1 - v), lerp(1290, STACK_BASE - 34, v), 0.4 * (1 - v), a * 0.9, STACK_OTH, 110)
    else:
        u = ramp(t, CAPS[k][0], CAPS[k][0] + 0.4)
        paste(c, T("0", 170, 900, ZERO), STACK_X, 1250, a * u, sc=lerp(1.2, 1, eob(u)))
        c.save(); c.set_dash([14, 10]); rr(c, STACK_X - SHEET_W / 2, STACK_BASE - 40, SHEET_W, 40, 8); stroke_style(c, (*STACK_OTH[:3], 0.6 * a), 3); c.stroke(); c.restore()
    paste(c, T("UN Watch, 2015 to 2024", 40, SRC_W, SUB), STACK_X, 1515, a)

def scene_country(c, t, i):
    kind, name, t0, t1, dead, suf, src, roll = COUNTRIES[i]
    a = ramp(t, t0 - 0.05, t0 + 0.35) * (1 - ramp(t, t1 - 0.3, t1 + 0.05))
    if a <= 0.01: return
    dy = 24 * (1 - ramp(t, t0, t0 + 0.5))
    header(c, kind, name, a, dy)
    v = ease(min(1, max(0, (t - t0 - 0.1) / roll))) ** 0.6 if t > t0 + 0.1 else 0
    pulse = 1 + 0.04 * max(0, 1 - abs(t - (t0 + 0.1 + roll)) / 0.25)
    counter(c, dead * v, suf if v > 0.999 else "", 480 + dy, a, 200 if WHITE else 190, DEAD_NUM, pulse)
    paste(c, T("DEAD", 52 if WHITE else 48, 900 if WHITE else 800, DEAD_LBL, track=14), 540, 624 + dy, a)
    paste(c, T(src, 40, SRC_W, SUB), 540, 682 + dy, a)
    res_panel(c, t, a, kind, {0: 2, 1: 6, 2: 10}[i])

def paper_count(t):
    n = 0.0
    for k, s in enumerate(SLAMS):
        prev = CUM[k - 1] if k else 0
        if t >= s: n = prev + (CUM[k] - prev) * ease((t - s) / 0.22)
    return n
def scene_israel(c, t):
    a = ramp(t, T_IL - 0.05, T_IL + 0.35) * (1 - ramp(t, T_CMP - 0.3, T_CMP + 0.05))
    if a <= 0.01: return
    header(c, "il", "ISRAEL", a)
    n = paper_count(t)
    hit = max([max(0, 1 - (t - s) / 0.18) for s in SLAMS if t >= s] + [0])
    if t >= CAPS[13][0] - 0.2 or n > 0:
        counter(c, n, "", 480, a, 210, ISR_NUM, 1 + 0.07 * hit)
        paste(c, T("UNGA CONDEMNATIONS", 52 if WHITE else 48, 900 if WHITE else 800, DEAD_LBL if WHITE else (200, 80, 88, 255), track=8), 540, 612, a)
        paste(c, T("2015 to 2024. Source: UN Watch, 2025", 40, SRC_W, SUB), 540, 670, a)
    else:
        paste(c, T("?", 210, 900, ISR_NUM), 540, 480, a * (0.6 + 0.4 * math.sin(t * 5) ** 2))
    stack(c, n, a, ISR_COL, t=t, wob=ramp(t, T_SLAM1 - 1.3, T_SLAM1 + 0.1) * (1 - ramp(t, T_SLAM1 + 0.1, T_CMP)))
    for k, s in enumerate(SLAMS):
        for j in range(3):
            u = (t - s - j * 0.04) / 0.32
            if 0 < u < 1:
                top = STACK_BASE - CUM[k] * SHEET_T
                x = lerp(BLOCK[0] + 60, STACK_X + (j - 1) * 30, ease(u)); y = lerp(BLOCK[1] - 40, top - 10, ease(u)) - 260 * math.sin(math.pi * u)
                sheet(c, x, y, (j - 1) * 0.8 + 6 * u * (1 if j % 2 else -1), a * (1 - u ** 4), ISR_COL, 90)
    if hit > 0.01:
        g = cairo.RadialGradient(BLOCK[0], BLOCK[1], 10, BLOCK[0], BLOCK[1], 420); g.add_color_stop_rgba(0, *ISR_COL[:3], 0.35 * hit * a); g.add_color_stop_rgba(1, *ISR_COL[:3], 0)
        c.set_source(g); c.paint()

def gavel_angle(t):
    """returns (raise angle, shake)"""
    if t < T_IL:
        for t0, dur, amp in ((0.45, 1.0, 0.22), (T_MEH, 1.4, 0.16)):   # hook tap (motion by 1.5 s), lazy tap at Meh
            u = (t - t0) / dur
            if 0 < u < 1: return amp * math.sin(math.pi * min(1, u * 1.25)) ** 2, 0
        return 0, 0
    ang = 0.0
    for k, s in enumerate(SLAMS):
        nxt = SLAMS[k + 1] if k + 1 < NSLAM else s + 0.7
        lift = min(0.9, (nxt - s) * 1.6); up_t = s - min(0.45, (s - (SLAMS[k - 1] if k else s - 0.6)) * 0.75)
        if up_t <= t < s:
            u = (t - up_t) / (s - up_t); ang = lift * (math.sin(math.pi * min(1, u / 0.7) / 2) if u < 0.7 else (1 - ((u - 0.7) / 0.3) ** 2))
    shake = 0
    for s in SLAMS:
        if 0 <= t - s < 0.15: shake = 10 * math.sin((t - s) * 120) * (1 - (t - s) / 0.15)
    return ang, shake

def scene_compare(c, t):
    a = ramp(t, T_CMP - 0.05, T_CMP + 0.35) * (1 - ramp(t, T_END_CARD - 0.3, T_END_CARD + 0.05))
    if a <= 0.01: return
    base = 1420; sc = 3.2; bw = 290
    for k, (lab, val, col, x, t0) in enumerate((("Israel", ISR_N, ISR_COL, 330, T_CMP + 0.3), ("Rest of the world", REST_N, OTH_COL, 750, T_80 - 0.5))):
        u = ease((t - t0) / 1.0); hgt = val * sc * u
        if u > 0.002: rr(c, x - bw / 2, base - hgt, bw, hgt + 2, 10); c.set_source_rgba(*col[:3], a); c.fill()
        if u > 0.02: paste(c, T(str(int(round(val * u))), 118, 900, ISR_NUM if k == 0 else OTH_NUM), x, base - hgt - 78, a)
        paste(c, T(lab, 56, 900 if WHITE else 800, LBL), x, base + 52, a)
    stroke_style(c, AXIS[:3] + (AXIS[3] * a,), 4 if WHITE else 3); c.move_to(120, base + 1); c.line_to(960, base + 1); c.stroke()
    paste(c, T("UNGA condemnations, 2015 to 2024. UN Watch, 2025", 38, SRC_W, SUB), 540, base + 108, a)
    # "more than 2x": the rest-of-world bar height ghosted twice, on "twice"
    u = ramp(t, T_TWICE - 0.1, T_TWICE + 0.4)
    if u > 0.01:
        hh = REST_N * sc
        c.save(); c.set_dash([16, 10])
        for m in (1, 2):
            y = base - hh * m; stroke_style(c, (*hx("#F2B705" if WHITE else "#FFD54A")[:3], a * u), 6); c.move_to(330 - bw / 2 - 20, y); c.line_to(750 + bw / 2, y); c.stroke()
        c.restore()
        paste(c, T("x2", 70, 900, HL if not WHITE else c255("#163260")), 330 + bw / 2 + 64, base - hh * 2 + 40, a * u)

def question_img():
    f = font(64, 900); fh = font(46, W_HE)
    lines = ["Beg to differ?", "Tell us where we’re wrong."]; he = "חושבים אחרת? כתבו לנו איפה אנחנו טועים."
    for s in lines + [he]: check(s)
    w = max(max(f.getlength(l) for l in lines), fh.getlength(he)) + 100; h = 64 * 1.22 * 2 + 46 * 1.3 + 74
    im = Image.new("RGBA", (int(w) + 24, int(h) + 24), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if WHITE: d.rounded_rectangle([14, 14, 14 + w, 14 + h], radius=44, fill=(242, 183, 5, 255))
    d.rounded_rectangle([4, 4, 4 + w, 4 + h], radius=44, fill=Q_FILL, outline=Q_OUT, width=6)
    y = 4 + 30
    for k, l in enumerate(lines):
        d.text((4 + w / 2, y + 64 * 1.22 / 2), l, font=f, fill=(HL if k == 0 and not WHITE else Q_TXT), anchor="mm"); y += 64 * 1.22
    d.text((4 + w / 2, y + 8 + 46 * 1.3 / 2), he, font=fh, fill=Q_TXT, anchor="mm")
    return pil2cairo(im)
QCARD = question_img()
END_EN = pil2cairo(caption([("head", "In my view,\nthat’s not human rights.", 76), ("head", "That’s *obsession.*", 128), ("he", "לדעתי, זה לא זכויות אדם. זו אובססיה.", 64)]))
END_SRC = [T("Sources: UN Watch 2025 (UNGA, 2015 to 2024);", 40, SRC_W, SUB), T("SOHR; UNDP 2021; US State Dept. 2024", 40, SRC_W, SUB)]
def arrow(c, x, y, a, t):
    if a <= 0.01: return
    y += 14 * math.sin(t * 5)
    c.save(); c.translate(x, y)
    stroke_style(c, (*[v / 255 for v in ARROW[:3]], a), 22); c.move_to(0, -60); c.line_to(0, 40); c.stroke()
    c.move_to(-46, -6); c.line_to(0, 44); c.line_to(46, -6); c.stroke(); c.restore()
def scene_end(c, t):
    a = ramp(t, T_END_CARD, T_END_CARD + 0.5)
    if a <= 0.01: return
    dy = 30 * (1 - ramp(t, T_END_CARD, T_END_CARD + 0.6))
    paste(c, END_EN, 540, 500 + dy, a)
    u = ramp(t, T_Q, T_Q + 0.4)
    paste(c, QCARD, 540, 1075, u, sc=lerp(1.1, 1, eob(u)))
    arrow(c, 540, 1325, ramp(t, T_Q + 0.5, T_Q + 0.8), t)
    for k, s in enumerate(END_SRC): paste(c, s, 540, 1450 + k * 54, a)

def scene_hook(c, t):
    a = 1 - ramp(t, T_SY - 0.3, T_SY)
    if a <= 0.01: return
    sc = 1 + 0.035 * ease(min(1, t / 1.2))
    paste(c, HOOK, 540, 620 - 10 * ramp(t, 0, T_SY), a, sc=sc)
    # underline sweep under the hook, by 0.4 to 1.1 s
    u = ramp(t, 0.35, 1.1)
    if u > 0.01:
        yy = 620 + HOOK.get_height() / 2 + 14; stroke_style(c, (*hx("#D7263D" if WHITE else "#FFD54A")[:3], a), 14); c.move_to(540 - 300, yy); c.line_to(540 - 300 + 600 * u, yy); c.stroke()

# ------------------------------------------------------------------ frame
def frame(fi):
    t = fi / FPS
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG_S, 0, 0); c.paint(); dust(c, t)
    if t < T_END_CARD + 0.1:
        ga = 1 - ramp(t, T_CMP - 0.3, T_CMP)
        ang, shake = gavel_angle(t); gavel(c, ang, ga, shake)
        if t < T_SY + 0.1: scene_hook(c, t)
        for i in range(3): scene_country(c, t, i)
        scene_israel(c, t); scene_compare(c, t)
    scene_end(c, t)
    for k, (t0, t1, en, he) in enumerate(CAPS):
        if en is None or not (t0 <= t < t1 + 0.2): continue
        u = ramp(t, t0, t0 + 0.22); al = u * (1 - ramp(t, t1 - 0.05, t1 + 0.12))
        if al <= 0.01: continue
        sc = lerp(1.1, 1, eob(u)); cy = 500 if k in (15, 16) else 885
        surf = CAP_S[k]; h = surf.get_height()
        c.save(); c.translate(540, cy); c.scale(sc, sc); c.translate(-540, -h / 2); c.set_source_surface(surf, 0, 0); c.paint_with_alpha(al); c.restore()
        if k == 4:
            v = ramp(t, t0 + 0.3, t0 + 0.6); paste(c, YAWN, 800, cy - 10, al * v, sc=lerp(0.6, 1, eob(v)) * (1 + 0.04 * math.sin(t * 3)))
    s.flush(); return s
def to_rgb(s): return np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1].copy()

if A.snaps:
    for ts in A.snaps.split(","):
        fi = min(N - 1, int(float(ts) * FPS)); Image.fromarray(to_rgb(frame(fi))).save(f"{QA}/{A.theme}_{float(ts):05.1f}.png")
    print("snaps done", N, "frames", T_END, "s"); sys.exit(0)
if A.render:
    import time; t0 = time.time(); out = A.render
    cmd = ["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    if A.audio: cmd += ["-i", A.audio, "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest"]
    cmd += ["-c:v", "libx264", "-threads", "4", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-profile:v", "high", "-movflags", "+faststart", out]
    ff = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for fi in range(N):
        s = frame(fi); ff.stdin.write(np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W].tobytes())
        if fi % 300 == 0: print(f"frame {fi}/{N} {time.time() - t0:.0f}s", flush=True)
    ff.stdin.close(); assert ff.wait() == 0; print("done", out, N, "frames")
