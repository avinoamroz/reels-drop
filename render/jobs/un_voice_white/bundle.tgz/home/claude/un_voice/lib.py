"""shared drawing helpers, extracted from study_vs_learn/reel.py"""
import sys, os, json, math, io, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
W, H, FPS = 1080, 1920, 30
# ------------------------------------------------------------------ helpers
def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def ease(u): u = min(1.0, max(0.0, u)); return u * u * (3 - 2 * u)
def eob(u, s=1.4):
    u = min(1.0, max(0.0, u)) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def win(t, a, b, fi=0.3, fo=0.3): return ramp(t, a, a + fi) * (1 - ramp(t, b - fo, b))
def lerp(a, b, u): return a + (b - a) * u
NAVY = hx("#163261"); NAVYD = hx("#0E1E3A"); ROYAL = hx("#2749D3"); SKY = hx("#45A4DD"); LIGHT = hx("#8FD3FF"); YEL = hx("#FFD54A")
PINK = hx("#FF6B8A"); RED = hx("#FF3B5C"); WHITE = (1, 1, 1, 1); GREY = hx("#8A9BB8")
HEEBO = {w: f"/home/claude/vid/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(HEEBO[w], int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
def cairo2pil(s):
    s.flush(); w, h = s.get_width(), s.get_height()
    a = np.ndarray((h, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :w].astype(np.float32)
    al = a[:, :, 3:4]; rgb = np.where(al > 0, a[:, :, :3] * 255 / np.maximum(al, 1), 0)
    out = np.concatenate([rgb[:, :, ::-1], al], 2).clip(0, 255).astype(np.uint8); return Image.fromarray(out, "RGBA")
def text_img(s, size, w=800, fill=(255, 255, 255, 255), pad=8):
    f = font(size, w); bb = f.getbbox(s, anchor="ls")
    im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls"); return im
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc: _tc[k] = pil2cairo(text_img(s, size, w, fill))
    return _tc[k]
def is_he(s): return any("֐" <= ch <= "׿" for ch in s)
DASHES = ("–", "—", "‒", "―")
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def paste(c, surf, x, y, a=1.0, sc=1.0, anchor="cc"):
    if a <= 0.01 or abs(sc) < 1e-3: return
    w_, h_ = surf.get_width(), surf.get_height(); c.save(); c.translate(x, y); c.scale(sc, sc)
    ox = 0 if anchor[1] == "l" else (-w_ if anchor[1] == "r" else -w_ / 2); oy = -h_ if anchor[0] == "b" else (0 if anchor[0] == "t" else -h_ / 2)
    c.set_source_surface(surf, ox, oy); c.paint_with_alpha(min(1, a)); c.restore()
def stroke_style(c, col, w):
    c.set_source_rgba(*col); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)

# ------------------------------------------------------------------ background
def draw_bg():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 1); g.add_color_stop_rgba(1, *ROYAL[:3], 1)
    c.set_source(g); c.paint()
    g = cairo.RadialGradient(540, 1000, 50, 540, 1000, 760); g.add_color_stop_rgba(0, *SKY[:3], 0.16); g.add_color_stop_rgba(1, *SKY[:3], 0)
    c.set_source(g); c.paint(); return s
BG_S = draw_bg()
DUST = np.random.default_rng(7).random((44, 5))
def dust(c, t, a=1.0):
    for x0, y0, sp, r, ph in DUST:
        y = (y0 * 2100 - t * (12 + 26 * sp)) % 2100 - 90; x = x0 * W + 18 * math.sin(t * 0.4 + ph * 6)
        al = a * (0.10 + 0.16 * (0.5 + 0.5 * math.sin(t * 1.3 + ph * 9)))
        c.set_source_rgba(*LIGHT[:3], al); c.arc(x, y, 1.5 + 3 * r, 0, 2 * math.pi); c.fill()

# ------------------------------------------------------------------ brain (side view, front to the LEFT), pre-rendered layers
BS = 1.0; BW_, BH_ = 980, 760; BOX, BOY = 490, 360   # layer canvas, local origin inside it
def cerebrum_path(c):
    c.move_to(-352, 46)
    c.curve_to(-410, -20, -392, -170, -300, -236)
    c.curve_to(-220, -294, -110, -312, -10, -306)
    c.curve_to(120, -300, 250, -262, 330, -178)
    c.curve_to(398, -106, 410, -6, 376, 64)
    c.curve_to(356, 104, 318, 118, 268, 112)
    c.curve_to(200, 106, 160, 128, 112, 150)
    c.curve_to(40, 184, -60, 206, -148, 176)
    c.curve_to(-212, 152, -228, 102, -226, 74)
    c.curve_to(-262, 60, -312, 70, -352, 46); c.close_path()
def cerebellum_path(c):
    c.move_to(150, 152); c.curve_to(180, 116, 300, 104, 352, 124); c.curve_to(392, 142, 380, 206, 330, 226)
    c.curve_to(270, 250, 186, 236, 160, 206); c.curve_to(146, 190, 142, 168, 150, 152); c.close_path()
def stem_path(c):
    c.move_to(84, 120); c.curve_to(110, 110, 150, 116, 158, 130); c.curve_to(160, 200, 168, 260, 190, 330)
    c.line_to(130, 336); c.curve_to(118, 270, 104, 200, 84, 120); c.close_path()
SULCI = [  # gentle gyri lines
    [(-300, -150), (-250, -190), (-200, -170), (-160, -230)], [(-330, -40), (-280, -80), (-240, -50), (-200, -110)],
    [(-90, -290), (-70, -220), (-30, -180), (-50, -110)], [(40, -300), (60, -240), (100, -210), (90, -150)],
    [(170, -270), (180, -210), (230, -190), (250, -130)], [(300, -150), (300, -90), (340, -60), (350, 10)],
    [(-200, 70), (-120, 40), (0, 50), (120, 10)], [(-150, 140), (-70, 120), (20, 140), (90, 110)],
    [(200, 40), (240, 0), (300, 20), (340, -20)], [(-210, -20), (-160, 10), (-120, -30), (-60, 0)]]
def pfc_path(c):
    c.move_to(-420, -330); c.line_to(-150, -330); c.curve_to(-170, -230, -220, -120, -214, -40); c.curve_to(-210, 10, -230, 50, -250, 70); c.line_to(-420, 80); c.close_path()
def caudate_path(c):
    c.move_to(-150, -40); c.curve_to(-160, -110, -60, -140, 20, -120); c.curve_to(90, -104, 120, -60, 112, -10)
    c.curve_to(106, 30, 80, 56, 56, 70); c.curve_to(76, 40, 86, 10, 82, -16); c.curve_to(76, -70, 30, -90, -20, -90)
    c.curve_to(-80, -90, -110, -60, -110, -20); c.curve_to(-112, 0, -128, 6, -150, -40); c.close_path()
def putamen_path(c):
    c.save(); c.translate(-30, -14); c.rotate(-0.18); c.scale(78, 50); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
def limbic_path(c):   # cingulate arc + fornix/hippocampus loop as one thick band
    c.move_to(-196, -10)
    c.curve_to(-200, -130, -60, -200, 40, -192); c.curve_to(150, -184, 220, -120, 214, -30)
    c.curve_to(210, 40, 160, 90, 90, 104); c.curve_to(30, 116, -40, 112, -76, 96)
    c.line_to(-70, 72); c.curve_to(-20, 86, 60, 82, 110, 64); c.curve_to(170, 40, 186, -10, 184, -40)
    c.curve_to(178, -120, 110, -164, 36, -166); c.curve_to(-50, -170, -170, -110, -166, -10); c.close_path()
def amyg_path(c):
    c.save(); c.translate(-104, 100); c.rotate(-0.5); c.scale(36, 24); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
def layer(fn, blur=0, scale_glow=1.0):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, BW_, BH_); c = cairo.Context(s); c.translate(BOX, BOY); fn(c); s.flush()
    if not blur: return s
    im = cairo2pil(s).filter(ImageFilter.GaussianBlur(blur)); a = np.asarray(im).astype(np.float32); a[:, :, 3] = np.clip(a[:, :, 3] * scale_glow, 0, 255)
    return pil2cairo(Image.fromarray(a.astype(np.uint8), "RGBA"))
def L_base(c):
    # body fill
    g = cairo.LinearGradient(0, -310, 0, 340); g.add_color_stop_rgba(0, *hx("#2A4E92")[:3], 1); g.add_color_stop_rgba(1, *hx("#17305F")[:3], 1)
    stem_path(c); c.set_source_rgba(*hx("#1A3364")[:3], 1); c.fill_preserve(); stroke_style(c, (*LIGHT[:3], 0.55), 5); c.stroke()
    cerebellum_path(c); c.set_source_rgba(*hx("#21417C")[:3], 1); c.fill_preserve(); stroke_style(c, (*LIGHT[:3], 0.6), 5); c.stroke()
    c.save(); cerebellum_path(c); c.clip(); stroke_style(c, (*LIGHT[:3], 0.22), 3)
    for k in range(7): c.move_to(140, 128 + k * 17); c.curve_to(220, 110 + k * 20, 300, 112 + k * 18, 400, 120 + k * 16); c.stroke()
    c.restore()
    cerebrum_path(c); c.set_source(g); c.fill()
    c.save(); cerebrum_path(c); c.clip(); stroke_style(c, (*LIGHT[:3], 0.20), 5)
    for p in SULCI: c.move_to(*p[0]); c.curve_to(*p[1], *p[2], *p[3]); c.stroke()
    c.restore()
def L_rim(c): cerebrum_path(c); stroke_style(c, (*LIGHT[:3], 0.95), 6); c.stroke()
def L_rimglow(c): cerebrum_path(c); stroke_style(c, (*SKY[:3], 0.9), 18); c.stroke()
def L_ghost(c):   # x-ray outlines of deep structures
    stroke_style(c, (*LIGHT[:3], 0.30), 3); c.set_dash([10, 9])
    for f in (caudate_path, putamen_path, limbic_path, amyg_path): f(c); c.stroke()
    c.set_dash([])
def L_pfc(c):
    c.save(); cerebrum_path(c); c.clip(); pfc_path(c); c.clip()
    g = cairo.RadialGradient(-300, -120, 20, -300, -120, 260); g.add_color_stop_rgba(0, *hx("#FFF1B0")[:3], 0.95); g.add_color_stop_rgba(1, *YEL[:3], 0.70)
    c.set_source(g); c.paint(); stroke_style(c, (*hx("#FFF6CF")[:3], 0.55), 5)
    for p in SULCI[:2]: c.move_to(*p[0]); c.curve_to(*p[1], *p[2], *p[3]); c.stroke()
    c.restore(); c.save(); cerebrum_path(c); c.clip(); pfc_path(c); stroke_style(c, (*hx("#FFF6CF")[:3], 0.9), 5); c.stroke(); c.restore()
def L_pfc_glow(c): c.save(); cerebrum_path(c); c.clip(); pfc_path(c); c.set_source_rgba(*YEL[:3], 1); c.fill(); c.restore()
def L_habit(c):
    for f in (caudate_path, putamen_path):
        f(c); c.set_source_rgba(*hx("#9BDcff")[:3], 0.95); c.fill_preserve(); stroke_style(c, WHITE, 4); c.stroke()
    c.save(); cerebellum_path(c); c.clip(); c.set_source_rgba(*SKY[:3], 0.85); c.paint(); stroke_style(c, (1, 1, 1, 0.45), 3)
    for k in range(7): c.move_to(140, 128 + k * 17); c.curve_to(220, 110 + k * 20, 300, 112 + k * 18, 400, 120 + k * 16); c.stroke()
    c.restore(); cerebellum_path(c); stroke_style(c, WHITE, 4); c.stroke()
def L_habit_glow(c):
    for f in (caudate_path, putamen_path, cerebellum_path): f(c); c.set_source_rgba(*SKY[:3], 1); c.fill()
def L_limbic(c):
    limbic_path(c); c.set_source_rgba(*PINK[:3], 0.92); c.fill_preserve(); stroke_style(c, (1, 0.9, 0.92, 1), 4); c.stroke()
def L_limbic_glow(c): limbic_path(c); c.set_source_rgba(*PINK[:3], 1); c.fill()
def L_amyg(c): amyg_path(c); c.set_source_rgba(*RED[:3], 1); c.fill_preserve(); stroke_style(c, (1, 0.95, 0.95, 1), 5); c.stroke()
def L_amyg_glow(c): amyg_path(c); c.set_source_rgba(*RED[:3], 1); c.fill()
BR = dict(base=layer(L_base), rim=layer(L_rim), rimglow=layer(L_rimglow, 22, 1.3), ghost=layer(L_ghost),
          pfc=layer(L_pfc), pfc_g=layer(L_pfc_glow, 30, 1.6), habit=layer(L_habit), habit_g=layer(L_habit_glow, 26, 1.8),
          limbic=layer(L_limbic), limbic_g=layer(L_limbic_glow, 26, 1.6), amyg=layer(L_amyg), amyg_g=layer(L_amyg_glow, 22, 2.4))
REG_PT = {"pfc": (-290, -120), "habit": (10, -60), "cereb": (270, 175), "limbic": (-30, -175), "amyg": (-104, 100)}
def draw_brain(c, cx, cy, sc, a, lit, t, ghost=0.0):
    """lit: dict pfc/habit/limbic/amyg -> 0..1"""
    if a <= 0.01: return
    c.save(); c.translate(cx, cy); c.scale(sc, sc); c.translate(-BOX, -BOY)
    def P(k, al):
        if al > 0.01: c.set_source_surface(BR[k], 0, 0); c.paint_with_alpha(min(1, al))
    P("rimglow", a * (0.35 + 0.1 * math.sin(t * 1.6))); P("base", a); P("ghost", a * ghost)
    for k in ("pfc", "habit", "limbic", "amyg"):
        v = lit.get(k, 0)
        if v > 0.01:
            pul = 0.85 + 0.15 * math.sin(t * (6.0 if k == "amyg" else 2.4))
            P(k + "_g", a * v * pul); P(k, a * v)
    P("rim", a); c.restore()
def brain_xy(cx, cy, sc, key): x, y = REG_PT[key]; return cx + x * sc, cy + y * sc
# ------------------------------------------------------------------ captions (from reel5)
def caption(parts, lh_head=1.12, he_max=930, hl=(255, 213, 74, 255)):
    blocks = []
    for kind, s, sz in parts:
        assert not any(d in s for d in DASHES), s
        if kind == "he":
            assert is_he(s); f = font(sz, 700)
            while f.getlength(s) > he_max and sz > 56: sz -= 1; f = font(sz, 700)
            assert f.getlength(s) <= he_max, ("hebrew too wide", s)
            blocks.append(("he", [[(s, (255, 255, 255, 255))]], sz, f, 1.25)); continue
        f = font(sz, 900 if kind == "head" else 800); toks = []; yel = False
        for p in s.replace("*", " * ").replace("\n", " \n ").split(" "):
            if p == "*": yel = not yel; continue
            if p == "\n": toks.append(("\n", None)); continue
            if p: toks.append((p, hl if yel else (255, 255, 255, 255)))
        lines, cur = [], []
        for t in toks:
            if t[0] == "\n": lines.append(cur); cur = []; continue
            if cur and f.getlength(" ".join(x for x, _ in cur + [t])) > (930 if kind == "head" else 900): lines.append(cur); cur = [t]
            else: cur.append(t)
        if cur: lines.append(cur)
        assert len(lines) <= 3, s
        for ln in lines: assert f.getlength(" ".join(x for x, _ in ln)) <= 940, ("too wide", s)
        blocks.append((kind, lines, sz, f, lh_head if kind == "head" else 1.18))
    GAPS = {"head": 22, "body": 22, "he": 0}
    hgt = sum(len(ln) * sz * lh + GAPS[k] for k, ln, sz, f, lh in blocks)
    im = Image.new("RGBA", (W, int(hgt) + 12), (0, 0, 0, 0)); d = ImageDraw.Draw(im); y = 6
    for k, ln, sz, f, lh in blocks:
        for line in ln:
            yy = y + sz * lh / 2
            if k == "he": d.text((540, yy), line[0][0], font=f, fill=line[0][1], anchor="mm")
            else:
                sp = f.getlength(" "); ws = [f.getlength(w_) for w_, _ in line]; x = 540 - (sum(ws) + sp * (len(ws) - 1)) / 2
                for (w_, c_), ww in zip(line, ws): d.text((x, yy), w_, font=f, fill=c_, anchor="lm"); x += ww + sp
            y += sz * lh
        y += GAPS[k]
    return im
# ------------------------------------------------------------------ labels, pills, bubbles
def pill(s, sz, fg, bg_, outline, w=900, padx=0.9):
    f = font(sz, w); tw = f.getlength(s); pw, ph = int(tw + sz * padx), int(sz * 1.5)
    im = Image.new("RGBA", (pw + 8, ph + 8), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([4, 4, 4 + pw, 4 + ph], radius=ph // 2, fill=bg_, outline=outline, width=4)
    d.text((4 + pw / 2, 4 + ph / 2 + 1), s, font=f, fill=fg, anchor="mm"); return pil2cairo(im)
def label2(lines, sz, col, w=900):
    f = font(sz, w); ws = [f.getlength(l) for l in lines]; im = Image.new("RGBA", (int(max(ws)) + 20, int(len(lines) * sz * 1.12) + 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for k, l in enumerate(lines): d.text((im.size[0] / 2, 8 + sz * 1.12 * (k + 0.5)), l, font=f, fill=col, anchor="mm")
    return pil2cairo(im)
Y255 = (255, 213, 74, 255); S255 = (143, 211, 255, 255); P255 = (255, 160, 180, 255); W255 = (255, 255, 255, 255); N255 = (14, 30, 58, 255)
_bub = {}
def bubble(text, kind="speech", sz=56, fg=N255, bg=(255, 255, 255, 245), outline=None):
    k = (text, kind, sz, fg, bg, outline)
    if k not in _bub:
        t = text_img(text, sz, 800, fg, pad=0); tw, th = t.size; pw, ph = tw + 56, th + 40
        im = Image.new("RGBA", (pw + 12, ph + 52), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        if kind == "thought":
            d.rounded_rectangle([6, 6, 6 + pw, 6 + ph], radius=ph // 2, fill=bg, outline=outline, width=5 if outline else 0)
            d.ellipse([pw * 0.3, ph + 10, pw * 0.3 + 24, ph + 34], fill=bg); d.ellipse([pw * 0.3 - 18, ph + 34, pw * 0.3 - 4, ph + 48], fill=bg)
        else:
            d.rounded_rectangle([6, 6, 6 + pw, 6 + ph], radius=30, fill=bg, outline=outline, width=5 if outline else 0)
            d.polygon([(34, ph), (74, ph), (28, ph + 44)], fill=bg)
        im.alpha_composite(t, (6 + 28, 6 + 20)); _bub[k] = pil2cairo(im)
    return _bub[k]

# ------------------------------------------------------------------ end cards (from reel5)
def emoji_img(code, sz):
    import cairosvg
    return Image.open(io.BytesIO(cairosvg.svg2png(url=f"/tmp/claude-0/package/{code}.svg", output_width=sz, output_height=sz))).convert("RGBA")
def end_card(els):
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im); blocks = []
    for k, s, sz in els:
        assert not any(dd in s for dd in DASHES), s
        if k == "emoji": blocks.append((k, s, sz, sz + 44)); continue
        if k == "pill": blocks.append((k, s, sz, sz * 1.42)); continue
        if k == "he" and "\n" in s:
            f = font(sz, 700); ls_ = s.split("\n"); assert all(f.getlength(x) <= 900 for x in ls_) and len(ls_) <= 3, s
            blocks.append((k, [[(x, (255, 255, 255, 255))] for x in ls_], sz, len(ls_) * sz * 1.25)); continue
        if k == "he":
            f = font(sz, 700)
            while f.getlength(s) > 860 and sz > 56: sz -= 1; f = font(sz, 700)
            if f.getlength(s) <= 900: blocks.append((k, [[(s, (255, 255, 255, 255))]], sz, sz * 1.25)); continue
            ws_ = s.split(" "); best = min(range(1, len(ws_)), key=lambda i: max(f.getlength(" ".join(ws_[:i])), f.getlength(" ".join(ws_[i:]))))
            l1, l2 = " ".join(ws_[:best]), " ".join(ws_[best:]); assert max(f.getlength(l1), f.getlength(l2)) <= 900, s
            blocks.append((k, [[(l1, (255, 255, 255, 255))], [(l2, (255, 255, 255, 255))]], sz, 2 * sz * 1.25)); continue
        f = font(sz, 900 if k == "head" else 700); toks = []; yel = False
        for p in s.replace("*", " * ").split(" "):
            if p == "*": yel = not yel; continue
            if p: toks.append((p, (255, 213, 74, 255) if yel else (255, 255, 255, 255)))
        lines, cur = [], []
        for t in toks:
            if cur and f.getlength(" ".join(x for x, _ in cur + [t])) > 820: lines.append(cur); cur = [t]
            else: cur.append(t)
        if cur: lines.append(cur)
        assert len(lines) <= 3, s
        lh = 1.12 if k == "head" else 1.24; blocks.append((k, lines, sz, len(lines) * sz * lh))
    content = sum(b[3] for b in blocks); y0, y1 = 330, 1470
    gap = min(120, max(40, ((y1 - y0) * 0.78 - content) / max(1, len(blocks) - 1)))
    tot = content + gap * (len(blocks) - 1); y = y0 + ((y1 - y0) - tot) / 2; top = y
    for k, ln, sz, h in blocks:
        if k == "emoji":
            r = sz / 2 + 22; cy = y + h / 2
            d.ellipse([540 - r, cy - r, 540 + r, cy + r], fill=(255, 255, 255, 18), outline=(69, 164, 221, 170), width=4)
            im.alpha_composite(emoji_img(ln, sz), (int(540 - sz / 2), int(cy - sz / 2)))
        elif k == "pill":
            f = font(sz, 900); tw = f.getlength(ln); pw, ph = tw + sz * 0.9, sz * 1.42; assert pw < 900
            d.rounded_rectangle([540 - pw / 2, y, 540 + pw / 2, y + ph], radius=int(ph / 2), fill=(14, 30, 58, 255), outline=(255, 213, 74, 255), width=7)
            d.text((540, y + ph / 2 + 4), ln, font=f, fill=(255, 213, 74, 255), anchor="mm")
        else:
            f = font(sz, 900 if k == "head" else 700); lh = 1.12 if k == "head" else (1.25 if k == "he" else 1.24)
            for j, line in enumerate(ln):
                yy = y + j * sz * lh + sz * lh / 2
                if k == "he": d.text((540, yy), line[0][0], font=f, fill=(255, 255, 255, 255), anchor="mm"); continue
                sp = f.getlength(" "); ws = [f.getlength(w_) for w_, _ in line]; x = 540 - (sum(ws) + sp * (len(ws) - 1)) / 2
                for (w_, c_), ww in zip(line, ws): d.text((x, yy), w_, font=f, fill=c_, anchor="lm"); x += ww + sp
        y += h + gap
    assert top >= 260 and y - gap <= 1540
    return im
def draw_person(c, x, y, s, ph, amp, t, slump=0.0):
    c.save(); c.translate(x, y); c.scale(s, s)
    bob = -amp * 7 * abs(math.sin(ph)) - (1 - amp) * 2 * math.sin(t * 2.2)
    hip = (0, -130 + bob + 40 * slump); sh = (8 + 30 * slump, -212 + bob + 70 * slump); head = (14 + 50 * slump, -252 + bob + 96 * slump)
    def limb(p, a1, l1, a2, l2, col, wdt):
        k = (p[0] + l1 * math.sin(a1), p[1] + l1 * math.cos(a1)); e = (k[0] + l2 * math.sin(a2), k[1] + l2 * math.cos(a2))
        stroke_style(c, col, wdt); c.move_to(*p); c.line_to(*k); c.line_to(*e); c.stroke(); return e
    sw = 0.55 * amp; BACK = (0.70, 0.78, 0.92, 1); FRONT = (0.96, 0.975, 1.0, 1)
    for leg, col in ((1, BACK), (-1, FRONT)):
        a = leg * sw * math.sin(ph) + 0.9 * slump * (1 if leg > 0 else 0.6); kb = max(0, -leg * math.sin(ph + 0.6)) * 0.9 * amp + 1.7 * slump
        limb(hip, a, 66, a - kb, 66, col, 21)
    ba1 = -sw * 0.8 * math.sin(ph) + 0.6 * slump; limb(sh, ba1, 54, ba1 + 0.25 * amp + 0.4 * slump, 52, BACK, 17)
    c.set_source_rgba(*FRONT)
    c.move_to(-27 + sh[0], sh[1] - 8); c.line_to(27 + sh[0], sh[1] - 8); c.line_to(27, hip[1] + 14); c.line_to(-27, hip[1] + 14); c.close_path(); c.fill()
    c.arc(head[0], head[1], 27, 0, 2 * math.pi); c.fill()
    a1 = sw * 0.8 * math.sin(ph) + 0.6 * slump; limb(sh, a1, 54, a1 + 0.25 * amp + 0.4 * slump, 52, FRONT, 17)
    c.restore(); return (x + head[0] * s, y + head[1] * s)
