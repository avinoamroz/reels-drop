"""farming_20k: 23,000 years of farming in the Land of Israel. Map + year counter + crop row (3,000 years family).
python3 engine.py [--frames t1,t2,...] [--out path.mp4]      (DIR = this folder: timing.json, geo.json, icons/, photos/, mix.m4a)
Dark navy map: Israel, West Bank and Gaza in two close navy shades, Green Line green, lakes dark. Site pins light up in order,
a yellow counter runs 23,000 years ago -> Today, a crop row fills (wheat, barley, lentil, olive, grape, date), green field
dots spread from every lit site, free-licence photos slide in as a rounded panel. Circular: the last frame is frame 0."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.6):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u

NAVYD, NAVY, ROYAL, SKY, YEL = hx("#0E1E3A"), hx("#163261"), hx("#2749D3"), hx("#45A4DD"), hx("#FFD54A")
GREEN = (46 / 255, 204 / 255, 113 / 255, 1); SILVER = hx("#C9D1DC"); WHITE = (1, 1, 1, 1)
LAND_IL, LAND_PA, EDGE = hx("#2C5A9C"), hx("#24497F"), hx("#6FB8E8")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])     # surface, x offset of origin, y offset of baseline
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    """draw s with its baseline at y; align c/l/r on x"""
    if a <= 0.01: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def fit(s, size, maxw, w=800, mn=64):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def surf_from(path, w=None):
    im = Image.open(path).convert("RGBA")
    if w: im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    return pil2cairo(im)

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 0.95, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]     # scene i runs CUT[i]..CUT[i+1]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1

# ------------------------------------------------------------------ geography and camera
GEO = json.load(open(f"{D}/geo.json"))
COSF = math.cos(math.radians(31.5))
POSE_IL = (35.05, 31.45, 195.0)          # lon0, lat0, px per degree of latitude
POSE_ME = (41.2, 33.0, 46.0)
MAP_CX, MAP_CY = 540, 915
T_OUT = lt(13) - 0.1                     # zoom out to the Fertile Crescent
T_BACK = LINES[13]["t1"] + 0.05          # back to the land after the Fertile Crescent line (olive groves beat removed 3 Nov)
def pose(t):
    u = ramp(t, T_OUT, T_OUT + 1.3) * (1 - ramp(t, T_BACK, T_BACK + 1.1))
    lo = lerp(POSE_IL[0], POSE_ME[0], u); la = lerp(POSE_IL[1], POSE_ME[1], u)
    k = math.exp(lerp(math.log(POSE_IL[2]), math.log(POSE_ME[2]), u)); return lo, la, k, u
def P(ps, lon, lat):
    lo0, la0, k, _ = ps; return MAP_CX + (lon - lo0) * COSF * k, MAP_CY - (lat - la0) * k
def ring(c, ps, pts):
    for i, (lo, la) in enumerate(pts):
        x, y = P(ps, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
    c.close_path()
def land_path(c, ps):
    for r in GEO["isr"] + GEO["pal"]: ring(c, ps, r)

# field dots: inside the land, each born from the nearest lit site
from matplotlib.path import Path as MPath
_polys = [MPath(np.array(r)) for r in GEO["isr"] + GEO["pal"]]
_rng = np.random.default_rng(11); _cand = np.column_stack([_rng.uniform(34.2, 35.9, 9000), _rng.uniform(29.5, 33.4, 9000)])
_ins = np.zeros(len(_cand), bool)
for p in _polys: _ins |= p.contains_points(_cand)
_lakes = [MPath(np.array(r)) for r in GEO["lakes"]]
for p in _lakes: _ins &= ~p.contains_points(_cand)
DOTS = _cand[_ins][:1400]
DOT_R = _rng.uniform(2.2, 4.2, len(DOTS)); DOT_PH = _rng.uniform(0, 6.28, len(DOTS))

# ------------------------------------------------------------------ the story
# sites: key -> (label, lon, lat, side, line, word)
SITES = {
    "ohalo":   ("Ohalo II", 35.555, 32.725, "r", 0, None),
    "carmel":  ("el-Wad, Carmel", 34.966, 32.668, "l", 2, "Natufians"),
    "jv":      ("Jordan Valley", 35.43, 32.02, "r", 3, "wheat"),
    "jericho": ("Jericho", 35.444, 31.871, "r", 4, "Jericho"),
    "tsaf":    ("Tel Tsaf", 35.505, 32.42, "r", 5, "olive"),
    "kabri":   ("Tel Kabri", 35.137, 33.018, "l", 6, "grapes"),
    "masada":  ("Masada", 35.354, 31.316, "r", 7, "Masada"),
    "avdat":   ("Avdat", 34.773, 30.794, "l", 8, "Negev"),
    "shivta":  ("Shivta", 34.631, 30.881, "l", 8, "desert"),
    "degania": ("Degania", 35.585, 32.705, "r", 9, "Degania"),
    "hatzerim": ("Hatzerim", 34.712, 31.24, "l", 10, "Negev"),
}
def site_t(k):
    _, _, _, _, li, w = SITES[k]
    if k == "ohalo": return -1.0          # on screen from frame 0 (the loop lands on it)
    return wt(li, w) if w else lt(li)
ST = {k: site_t(k) for k in SITES}
SITE_LINE = {k: SITES[k][4] for k in SITES}
ACTIVE = {0: ["ohalo"], 1: ["ohalo"], 2: ["carmel"], 3: ["jv"], 4: ["jericho"], 5: ["tsaf"], 6: ["kabri"], 7: ["masada"],
          8: ["avdat", "shivta"], 9: ["degania"], 10: ["hatzerim"]}

# counter: (value, suffix) per line; value None -> text
CNT = [(23000, " years"), (23000, " years ago"), (15000, " years ago"), (11000, " years ago"), (10000, " years ago"),
       (7000, " years ago"), (3700, " years ago"), (2000, " years ago"), (1500, " years ago"), ("1910", ""), ("1965", ""),
       ("Today", ""), ("Today", ""), ("Today", ""), ("Today", "")]
HEAD = ["of farming here", "The first trial farm", "Villages and sickles", "Wheat, barley, lentils", "One of the first farm towns",
        "The oldest olive grove", "The Bible's seven species", "A seed that woke up", "Farming with flash floods", "The first kibbutz",
        "Drip irrigation", "Almost 90% reused", "It bloomed again", "The Fertile Crescent", "So next time someone asks?"]
SRC = ["", "Ohalo II: Snir et al., PLOS ONE, 2015", "Natufian sickles: Groman-Yaroslavski et al., Sci. Reports, 2026",
       "Founder crops: Zohary, Hopf and Weiss, 2012", "Jericho: Encyclopaedia Britannica",
       "Tel Tsaf olives: Langgut et al., Sci. Reports, 2022", "Deuteronomy 8:8. Tel Kabri wine: Koh et al., PLOS ONE, 2014",
       "Masada date seed: Sallon et al., Science, 2008", "Avdat, Shivta: UNESCO World Heritage, 2005",
       "Degania Alef, founded 1910", "Netafim, Kibbutz Hatzerim, 1965", "Treated wastewater reused: US EPA, 2023", "",
       "Founder crops: Zohary, Hopf and Weiss, 2012", ""]
CROPS = [("wheat", "Wheat", 3, "wheat"), ("barley", "Barley", 3, "barley"), ("lentil", "Lentil", 3, "lentils"),
         ("olive", "Olive", 5, "olive"), ("grape", "Grape", 6, "grapes"), ("date", "Date", 6, "dates")]
CROP_T = {k: wt(li, w) for k, _, li, w in CROPS}
ICON = {k: surf_from(f"{D}/icons/{k}.png", 104) for k, _, _, _ in CROPS}
ICON_O = surf_from(f"{D}/icons/olive.png", 60)

T_BLOOM = wt(12, "It") - 0.1                     # whole land blooms
T_RESET = lt(14) + 0.2                           # the loop: everything settles back to frame 0
T_FADE = END - 0.8                               # last 0.9 s: cross-fade into frame 0
def counter_val(t):
    i = scene_at(t)
    if i == 14:      # rewind Today -> 23,000 years over the lead-in
        u = ramp(t, T_RESET + 0.5, END - 1.05)
        if u <= 0: return "Today", ""
        return int(round(math.exp(lerp(math.log(1500), math.log(23000), u)), -2 if u < 0.98 else -3)), (" years ago" if u < 0.999 else " years")
    v, s = CNT[i]
    if isinstance(v, str) or i == 0: return v, s
    pv = CNT[i - 1][0]
    if isinstance(pv, str): return v, s
    u = eout((t - CUT[i]) / 0.9)
    return int(round(math.exp(lerp(math.log(pv), math.log(v), u)), -2)), s

# photos: (file stem, line, start offset word, credit)
PH = json.load(open(f"{D}/photos.json")) if os.path.exists(f"{D}/photos.json") else []
PHS = {}
for p in PH:
    im = Image.open(f"{D}/photos/{p['name']}.jpg").convert("RGB"); PHS[p["name"]] = im
PW, PHH, PX, PY = 940, 640, 70, 560

# ------------------------------------------------------------------ background
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.6, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1B3C8C")[:3], 1)
    c.set_source(g); c.paint()
    glow(c, 540, 930, 700, SKY, 0.13); return s
BG = bg_surface()

# ------------------------------------------------------------------ map
def draw_map(c, t, a, dim=1.0):
    ps = pose(t); lo0, la0, k, u = ps; kk = k / POSE_IL[2]
    # neighbours (only when zoomed out)
    if u > 0.01:
        c.save()
        for iso, rings in GEO["me"].items():
            for r in rings: ring(c, ps, r)
        c.set_source_rgba(*hx("#1A3360")[:3], a * u); c.fill_preserve(); c.set_source_rgba(*EDGE[:3], 0.35 * a * u); c.set_line_width(1.6); c.stroke()
        # the Fertile Crescent band
        arc = [(35.0, 31.2), (35.9, 33.6), (36.6, 35.6), (38.2, 36.9), (40.6, 37.2), (43.2, 36.8), (45.2, 35.2), (46.6, 33.4), (47.8, 31.6)]
        g_on = ramp(t, wt(13, "Fertile"), wt(13, "Fertile") + 0.8) * u
        if g_on > 0.01:
            n = len(arc); prog = g_on
            m = max(2, int(2 + (n - 2) * prog))
            for i, (x_, y_) in enumerate(arc[:m]):
                x, y = P(ps, x_, y_); (c.move_to if i == 0 else c.line_to)(x, y)
            c.set_source_rgba(*GREEN[:3], 0.42 * a); c.set_line_width(64); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
        for nm, lon, lat, w_ in [("Turkey", 35.0, 38.9, "Turkey"), ("Syria", 38.6, 35.3, "Fertile"), ("Iraq", 43.6, 33.3, "Crescent"), ("Iran", 50.6, 33.4, "Iran")]:
            la_ = a * u * ramp(t, wt(13, w_), wt(13, w_) + 0.35)
            x, y = P(ps, lon, lat); text(c, nm, 52, x, y + 18, 800, WHITE, la_)
        c.restore()
    # land
    c.push_group()
    glow(c, *P(ps, 35.1, 31.6), 520 * kk, SKY, 0.16 * (1 - u))
    for r in GEO["isr"]: ring(c, ps, r)
    g = cairo.LinearGradient(0, MAP_CY - 420 * kk, 0, MAP_CY + 420 * kk); g.add_color_stop_rgba(0, *hx("#3466AD")[:3], 1); g.add_color_stop_rgba(1, *LAND_IL[:3], 1)
    c.set_source(g); c.fill()
    for r in GEO["pal"]: ring(c, ps, r)
    c.set_source_rgba(*LAND_PA[:3], 1); c.fill()
    ol = 0.0   # olive groves beat removed (Noam, 3 Nov)
    if ol > 0.01:
        for r in GEO["pal"]: ring(c, ps, r)
        c.set_source_rgba(0.55, 0.68, 0.25, 0.55 * ol); c.fill()
    bl = ramp(t, T_BLOOM, T_BLOOM + 1.2) * (1 - ramp(t, T_RESET, T_RESET + 1.0))
    if bl > 0.01:
        land_path(c, ps); c.set_source_rgba(*GREEN[:3], 0.30 * bl); c.fill()
    land_path(c, ps); c.set_source_rgba(*EDGE[:3], 0.85); c.set_line_width(max(1.2, 2.4 * kk)); c.stroke()
    for r in GEO["lakes"]: ring(c, ps, r)
    c.set_source_rgba(*hx("#0B1730")[:3], 1); c.fill()
    c.set_source_rgba(*GREEN[:3], 1); c.set_line_width(max(1.5, 3.4 * kk)); c.set_line_cap(cairo.LINE_CAP_ROUND)
    for ln in GEO["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(ps, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    # field dots
    reset = 1 - ramp(t, T_RESET, T_RESET + 1.2)
    if reset > 0.01:
        lit = [(ST[s], SITES[s][1], SITES[s][2]) for s in SITES if ST[s] <= t and s != "ohalo" or (s == "ohalo" and t > lt(1))]
        if lit:
            arr = np.array([[x, y] for _, x, y in lit]); tl = np.array([q for q, _, _ in lit])
            d = np.hypot((DOTS[:, None, 0] - arr[None, :, 0]) * COSF, DOTS[:, None, 1] - arr[None, :, 1])
            birth = (tl[None, :] + d * 9.0).min(1)
        else: birth = np.full(len(DOTS), 1e9)
        birth = np.minimum(birth, T_BLOOM + np.hypot((DOTS[:, 0] - 35.0) * COSF, DOTS[:, 1] - 31.4) * 0.5)
        al = np.clip((t - birth) / 0.5, 0, 1) * reset
        cap = 0.5 + 0.5 * ramp(t, T_BLOOM, T_BLOOM + 1.5)
        for (lo, la), r_, ph_, aa in zip(DOTS, DOT_R, DOT_PH, al):
            if aa <= 0.02: continue
            x, y = P(ps, lo, la)
            c.set_source_rgba(*GREEN[:3], aa * cap * (0.55 + 0.25 * math.sin(t * 2 + ph_))); c.arc(x, y, r_ * max(0.35, kk), 0, 6.283); c.fill()
    # olive marks on the West Bank
    if ol > 0.01:
        for j, (lo, la) in enumerate([(35.25, 32.2), (35.1, 31.6), (35.32, 31.95)]):
            x, y = P(ps, lo, la); ss = max(0.01, eob(clamp((t - wt(13, "Palestinian") - 0.15 * j) / 0.4)))
            c.save(); c.translate(x, y); c.scale(ss, ss); c.set_source_surface(ICON_O, -30, -30); c.paint_with_alpha(ol); c.restore()
    c.pop_group_to_source(); c.paint_with_alpha(a * dim)
    draw_pins(c, t, ps, a * dim * (1 - u))

def draw_pins(c, t, ps, a):
    if a <= 0.01: return
    cur = scene_at(t); act = ACTIVE.get(cur, [])
    reset = 1 - ramp(t, T_RESET, T_RESET + 1.0)
    end_wave = ramp(t, T_BLOOM, T_BLOOM + 0.5) * reset
    for j, (key, (lab, lon, lat, side, li, w)) in enumerate(SITES.items()):
        tp = ST[key]
        if t < tp: continue
        if key != "ohalo" and reset <= 0.01: continue
        x, y = P(ps, lon, lat); u = clamp((t - tp) / 0.45); dy = -60 * (1 - eob(u)) if u < 1 else 0
        on = key in act or (key == "ohalo" and t > T_RESET)
        pa = a * (1 if key == "ohalo" else reset)
        if on or end_wave > 0.01:
            ph = ((t - tp) % 1.4) / 1.4; aa = pa * (1 if on else end_wave * (0.5 + 0.5 * math.sin(t * 3 - j)))
            c.set_source_rgba(*YEL[:3], aa * 0.8 * (1 - ph)); c.set_line_width(4); c.arc(x, y + dy, 16 + 34 * ph, 0, 6.283); c.stroke()
            glow(c, x, y + dy, 48, YEL, 0.45 * aa)
        r_ = 15 if on else 10
        c.set_source_rgba(*NAVYD[:3], pa * min(1, u * 3)); c.arc(x, y + dy, r_ + 4, 0, 6.283); c.fill()
        c.set_source_rgba(*(YEL if on else (1, 0.93, 0.7, 1))[:3], pa * min(1, u * 3)); c.arc(x, y + dy, r_, 0, 6.283); c.fill()
        if on and not (key == "ohalo" and cur >= 13):
            la_ = pa * ramp(t, tp + 0.1, tp + 0.4)
            sz = 46; tw = font(sz, 800).getlength(lab); bx = x + 34 if side == "r" else x - 34 - tw - 36
            bx = min(max(bx, 60), 1020 - tw - 36)
            if key == "degania": by = y + 30          # keep clear of the Ohalo label
            elif key == "shivta": by = y - 100
            else: by = y - 34
            rr(c, bx, by, tw + 36, 66, 33); c.set_source_rgba(*NAVYD[:3], 0.88 * la_); c.fill_preserve()
            c.set_source_rgba(*YEL[:3], 0.9 * la_); c.set_line_width(2.5); c.stroke()
            text(c, lab, sz, bx + 18, by + 49, 800, WHITE, la_, "l")

# ------------------------------------------------------------------ top: counter + headline
def fmt(v): return f"{v:,}" if isinstance(v, int) else v
def draw_top(c, t):
    v, suf = counter_val(t); s = fmt(v)
    i = scene_at(t)
    bsz = 156; ssz = 74
    w1 = font(bsz, 900).getlength(s); w2 = font(ssz, 800).getlength(suf) if suf else 0
    x0 = 540 - (w1 + w2) / 2
    pulse = 1 + 0.06 * math.sin(math.pi * clamp((t - CUT[i]) / 0.5)) if i > 0 else 1.0
    text(c, s, bsz, x0 + w1 / 2, 392, 900, YEL, 1.0, "c", pulse)
    if suf: text(c, suf, ssz, x0 + w1 + 4, 392, 800, WHITE, 1.0, "l")
    # headline: the hook line at frame 0 (and again at the very end), else the scene headline
    if i == 0 or t >= END - 1.05:
        a = 1.0 if i == 0 else ramp(t, END - 1.05, END - 0.8)
        text(c, "of farming here", 112, 540, 530, 900, WHITE, a)
        return
    hs = HEAD[i]; a = ramp(t, CUT[i] + 0.05, CUT[i] + 0.35)
    if i == 14: a *= 1 - ramp(t, END - 1.25, END - 1.05)
    sz = fit(hs, 84, 960, 900, 64)
    col = YEL if i in (11, 12) else WHITE
    dy = (1 - eout((t - CUT[i]) / 0.35)) * 24
    text(c, hs, sz, 540, 520 + dy, 900, col, a)

def draw_source(c, t):
    i = scene_at(t); s = SRC[i]
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1]))
    sz = fit(s, 38, 960, 700, 36); text(c, s, sz, 540, 1352, 700, SILVER, a)

# crop row
CROW_Y = 1432
def draw_crops(c, t):
    n = len(CROPS); step = 156; x0 = 540 - step * (n - 1) / 2
    reset = 1 - ramp(t, T_RESET + 0.4, T_RESET + 1.4)
    for j, (k, lab, li, w) in enumerate(CROPS):
        x = x0 + step * j; tc = CROP_T[k]
        on = clamp((t - tc) / 0.4) * reset
        c.set_source_rgba(1, 1, 1, 0.07); c.arc(x, CROW_Y, 64, 0, 6.283); c.fill()
        c.set_source_rgba(1, 1, 1, 0.20); c.set_line_width(2.5); c.set_dash([7, 7]); c.arc(x, CROW_Y, 64, 0, 6.283); c.stroke(); c.set_dash([])
        if on > 0.01:
            s = max(0.01, eob(on)); glow(c, x, CROW_Y, 90, YEL, 0.35 * on * (1 - clamp((t - tc - 0.6) / 0.8)) + 0.08 * on)
            c.set_source_rgba(*hx("#1F4C8F")[:3], on); c.arc(x, CROW_Y, 64 * s, 0, 6.283); c.fill()
            c.save(); c.translate(x, CROW_Y); c.scale(s, s); c.set_source_surface(ICON[k], -52, -52); c.paint_with_alpha(on); c.restore()
        text(c, lab, 38, x, CROW_Y + 112, 800, WHITE if on > 0.5 else SILVER, 0.55 + 0.45 * on)

# photo panel
_pc = {}
def photo_frame(name, zoom, pan):
    im = PHS[name]; r = PW / PHH; iw, ih = im.size
    if iw / ih > r: cw_, ch_ = ih * r, ih
    else: cw_, ch_ = iw, iw / r
    cw_ /= zoom; ch_ /= zoom
    cx = iw / 2 + pan[0] * (iw - cw_) / 2; cy = ih / 2 + pan[1] * (ih - ch_) / 2
    box = (cx - cw_ / 2, cy - ch_ / 2, cx + cw_ / 2, cy + ch_ / 2)
    return pil2cairo(im.resize((PW, PHH), Image.BICUBIC, box=box))
def photo_window(p):
    """end-anchored: the photo leaves 0.1 s before the next scene and stays at least 3 s (starts no earlier than 0.35 s into the line)"""
    t1 = CUT[p["line"] + 1] - 0.45
    t0 = max(lt(p["line"]) + 0.35, t1 - p.get("dur", 3.0))
    return t0, t1
def draw_photo(c, t):
    for p in PH:
        t0, t1 = photo_window(p)
        if not (t0 <= t <= t1 + 0.35): continue
        a = eout((t - t0) / 0.35) * (1 - ease((t - t1) / 0.35))
        u = clamp((t - t0) / max(0.1, t1 - t0 + 0.35)); z = lerp(1.0, 1.08, u)
        surf = photo_frame(p["name"], z, (lerp(-0.25, 0.25, u) * p.get("panx", 1), p.get("pany", 0.0)))
        y = PY + (1 - a) * 60
        c.save(); rr(c, PX, y, PW, PHH, 38); c.clip()
        c.set_source_surface(surf, PX, y); c.paint_with_alpha(a)
        g = cairo.LinearGradient(0, y + PHH - 150, 0, y + PHH); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0.02, 0.05, 0.12, 0.85 * a)
        c.set_source(g); c.paint()
        c.restore()
        rr(c, PX, y, PW, PHH, 38); c.set_source_rgba(1, 1, 1, 0.55 * a); c.set_line_width(3); c.stroke()
        if p.get("title"): text(c, p["title"], 56, PX + 34, y + PHH - 70, 900, WHITE, a, "l")
        cr = p["credit"]; sz = fit(cr, 36, PW - 68, 700, 36)
        text(c, cr, 36, PX + 34, y + PHH - 24, 700, SILVER, a, "l")
        return a
    return 0.0
def photo_dim(t):
    m = 0.0
    for p in PH:
        t0, t1 = photo_window(p)
        m = max(m, ramp(t, t0, t0 + 0.35) * (1 - ramp(t, t1, t1 + 0.35)))
    return m

# 90% gauge for line 11
def draw_ninety(c, t):
    t0 = wt(11, "ninety") - 0.3
    a = ramp(t, t0, t0 + 0.4) * (1 - ramp(t, CUT[12], CUT[12] + 0.3))
    if a <= 0.01: return
    x, y = 820, 1110; r = 118
    c.set_source_rgba(*NAVYD[:3], 0.9 * a); c.arc(x, y, r + 24, 0, 6.283); c.fill()
    c.set_source_rgba(1, 1, 1, 0.15 * a); c.set_line_width(22); c.arc(x, y, r, 0, 6.283); c.stroke()
    u = 0.9 * eout((t - t0) / 1.1)
    c.set_source_rgba(*SKY[:3], a); c.set_line_cap(cairo.LINE_CAP_ROUND); c.arc(x, y, r, -math.pi / 2, -math.pi / 2 + 6.283 * u); c.stroke()
    text(c, f"{int(round(u * 100))}%", 76, x, y + 26, 900, YEL, a)

# same-lake chip for Degania
def draw_chip(c, t):
    t0 = wt(9, "first") ; a = ramp(t, t0, t0 + 0.3) * (1 - ramp(t, CUT[10] - 0.3, CUT[10]))
    if a <= 0.01: return
    s = "Same lake as Ohalo II"; sz = 48; tw = font(sz, 800).getlength(s)
    x0 = 540 - tw / 2 - 30; y0 = 1225
    rr(c, x0, y0, tw + 60, 76, 38); c.set_source_rgba(*GREEN[:3], 0.92 * a); c.fill()
    text(c, s, sz, 540, y0 + 54, 800, NAVYD if False else WHITE, a)

# ------------------------------------------------------------------ subtitles
REPL = [("Twenty-three thousand", "23,000"), ("Fifteen thousand", "15,000"), ("eleven thousand", "11,000"), ("Seven thousand", "7,000"),
        ("two thousand year old", "2,000 year old"), ("Nineteen ten:", "1910:"), ("Nineteen sixty-five:", "1965:"), ("ninety percent", "90%"),
        ("Ohalo Two", "Ohalo II")]
SUB_BOTTOM = 1722
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower() == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs()
SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    pd = photo_dim(t)
    draw_map(c, t, 1.0, 1 - 0.75 * pd)
    draw_ninety(c, t)
    draw_photo(c, t)
    draw_top(c, t); draw_source(c, t); draw_crops(c, t)
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

def frame0_blend(t, img):
    """last 0.9 s: cross-fade into frame 0 so the replay is seamless"""
    if t < T_FADE: return img
    u = ease((t - T_FADE) / (END - T_FADE)); f0 = frame(0.0)
    return (img.astype(np.float32) * (1 - u) + f0.astype(np.float32) * u).astype(np.uint8)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); Image.fromarray(frame0_blend(tt, frame(tt))).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= T_FADE:
            u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
