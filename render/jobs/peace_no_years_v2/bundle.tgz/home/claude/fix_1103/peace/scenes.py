"""Bespoke reelkit scenes for peace_no_years: the year counter with offer cards and answer stamps, the fair line, the ask."""
import math
import render as RD
from render import P, T, pill, PP, fade_in, source, shadow_box, draw_emoji, flag_emoji, block, block_h, col
from kit import ease, ramp, lerp, St, sa, rr, box, circ

Y0, Y1 = 1947, 2020
TRK_X0, TRK_X1, TRK_Y = 120, 960, 372

def _eout(u):
    u = min(1.0, max(0.0, u)); return 1 - (1 - u) ** 3

def _year_at(t, S):
    """the counter value: holds at each stop, runs fast and eases out between stops"""
    tm = S["times"]; st = S["stops"]; v = S.get("start", st[0]["year"])
    for k, s in enumerate(st):
        ty = tm[f"y{k}"]
        if k == 0: v = s["year"]; continue
        a = tm[f"n{k - 1}e"]; b = ty + 0.32
        if t <= a: break
        v = lerp(st[k - 1]["year"], s["year"], _eout((t - a) / max(0.2, b - a)))
    return v

def _cur(t, S):
    tm = S["times"]; k = 0
    for i in range(len(S["stops"])):
        if t >= tm[f"y{i}"] - 0.05: k = i
    return k

def _track(c, t, S, a):
    st = S["stops"]; tm = S["times"]; v = _year_at(t, S)
    X = lambda y: lerp(TRK_X0, TRK_X1, (y - Y0) / (Y1 - Y0))
    old = St.a; St.a *= a
    box(c, TRK_X0, TRK_Y - 5, TRK_X1 - TRK_X0, 10, 5, P["silver"])
    box(c, TRK_X0, TRK_Y - 5, max(10, X(v) - TRK_X0), 10, 5, P["navy"])
    for k, s in enumerate(st):
        if k and s["year"] == st[k - 1]["year"]: continue
        x = X(s["year"]); done = t >= tm[f"n{k}"]
        circ(c, x, TRK_Y, 13 if done else 9, P["red"] if done else P["white"], stroke=P["navy"], sw=3)
    T(c, "1947", 30, TRK_X0, TRK_Y + 42, P["grey"], 1, 1, 800)
    T(c, "2020", 30, TRK_X1, TRK_Y + 42, P["grey"], 1, 1, 800)
    x = X(v); pul = 1 + 0.15 * math.sin(t * 6)
    circ(c, x, TRK_Y, 18 * pul, P["gold"], stroke=P["navy"], sw=4)
    St.a = old

def _stamp(c, t, tn, s, cx, cy):
    if t < tn - 0.02: return
    u = min(1.0, (t - tn) / 0.28); sc = lerp(2.4, 1.0, _eout(u)); a = min(1.0, u * 2.5)
    shake = 6 * math.sin((t - tn) * 60) * max(0, 1 - (t - tn) / 0.3)
    cc = col(s.get("ans_color"), "red")
    txt = s["ans"]; z = 130 if len(txt) <= 3 else (104 if len(txt) <= 9 else 88)
    f = RD.font(z, 900); w = f.getlength(txt) + 90; h = z * 1.35
    c.save(); c.translate(cx + shake, cy); c.rotate(-0.07); c.scale(sc, sc)
    old = St.a; St.a *= a
    sa(c, cc, 0.12); rr(c, -w / 2, -h / 2, w, h, 26); c.fill()
    sa(c, cc); c.set_line_width(10); rr(c, -w / 2, -h / 2, w, h, 26); c.stroke()
    St.a = old
    T(c, txt, z, 0, 6, cc, a, 1, 900, maxw=900)
    c.restore()


# 3 Nov 2026 (Noam: show the Palestinian side reacting): named stick figures, no faces. Orange = the side answering.
ORANGE = (0xF2 / 255, 0x8C / 255, 0x28 / 255, 1.0)
def _ln(c, pts, w, color):
    sa(c, color, St.a); c.set_line_width(w); c.set_line_cap(1); c.set_line_join(1)
    c.move_to(*pts[0])
    for q in pts[1:]: c.line_to(*q)
    c.stroke()
def _fig(c, x, yf, h, color, t, mode, ph=0.0):
    """stick figure, feet at (x, yf). modes: listen, no (arms crossed, head shake), yesbut (one hand up), shrug (silent, palms out)"""
    lw = h * 0.055; hr = h * 0.12
    shake = h * 0.03 * math.sin(t * 14 + ph) if mode == "no" else 0.0
    hip = (x, yf - h * 0.45); neck = (x, yf - h * 0.80); head = (x + shake, neck[1] - hr * 1.05)
    _ln(c, [(hip[0] - h * 0.11, yf), hip, (hip[0] + h * 0.11, yf)], lw, color); _ln(c, [hip, neck], lw, color)
    sh = (neck[0], neck[1] + h * 0.05)
    if mode == "no":
        for s_ in (1, -1): _ln(c, [sh, (sh[0] + s_ * h * 0.14, sh[1] + h * 0.14), (sh[0] - s_ * h * 0.10, sh[1] + h * 0.17)], lw, color)
    elif mode == "yesbut":
        _ln(c, [sh, (sh[0] + h * 0.14, sh[1] + h * 0.02), (sh[0] + h * 0.16, sh[1] - h * 0.16)], lw, color)
        _ln(c, [sh, (sh[0] - h * 0.09, sh[1] + h * 0.17), (sh[0] - h * 0.07, sh[1] + h * 0.33)], lw, color)
    elif mode == "shrug":
        for s_ in (1, -1): _ln(c, [sh, (sh[0] + s_ * h * 0.13, sh[1] + h * 0.12), (sh[0] + s_ * h * 0.22, sh[1] + h * 0.04)], lw, color)
    else:
        for s_ in (1, -1): _ln(c, [sh, (sh[0] + s_ * h * 0.09, sh[1] + h * 0.17), (sh[0] + s_ * h * 0.07, sh[1] + h * 0.33)], lw, color)
    sa(c, color, St.a); c.set_line_width(lw); c.new_sub_path(); c.arc(head[0], head[1], hr, 0, 2 * math.pi); c.stroke()
    ex, ey = head[0] + hr * 0.1, head[1] - hr * 0.12
    for dx in (-hr * 0.3, hr * 0.3): c.new_sub_path(); c.arc(ex + dx, ey, hr * 0.1, 0, 2 * math.pi); c.fill()
    c.set_line_width(lw * 0.7)
    if mode == "no": c.move_to(ex - hr * 0.32, head[1] + hr * 0.45); c.line_to(ex + hr * 0.32, head[1] + hr * 0.45); c.stroke()
    elif mode == "shrug": c.new_sub_path(); c.arc(ex, head[1] + hr * 0.45, hr * 0.14, 0, 2 * math.pi); c.stroke()
    else: c.new_sub_path(); c.arc(ex, head[1] + hr * 0.05, hr * 0.42, 0.25 * math.pi, 0.75 * math.pi); c.stroke()
def _react(c, t, s, tn, x, y_top, y_feet, a):
    """the named leader (or a group of three for a body) reacting when the answer lands"""
    if a <= 0.01: return
    m = "listen" if t < tn - 0.02 else {"amber": "yesbut"}.get(s.get("ans_color"), "shrug" if "ANSWER" in s["ans"] else "no")
    h = min(240, y_feet - y_top); old = St.a; St.a *= a
    if s.get("group"):
        for k, dx in enumerate((-58, 58, 0)):
            _fig(c, x + dx, y_feet - (0 if k < 2 else 8), h * (0.78 if k < 2 else 0.86), ORANGE, t, m, ph=k)
    else:
        _fig(c, x, y_feet, h, ORANGE, t, m)
    St.a = old
    T(c, s["fig_name"], 36, x, y_feet + 34, P["navy"], a, 1, 800, maxw=260)

def _card(c, t, S, k, a_out):
    s = S["stops"][k]; tm = S["times"]; ty = tm[f"y{k}"]; to = tm[f"o{k}"]; tn = tm[f"n{k}"]
    u = _eout((t - (ty - 0.05)) / 0.35); a = min(1.0, u * 1.5) * a_out
    if a <= 0.01: return
    dx = 260 * (1 - u)
    y0 = 660
    hb = block_h(s["en"], 50, 900, 860, 2); hh = block_h(s["he"], 40, 700, 860, 2)
    h = 118 + 18 + hb + 10 + hh + 24 + 104
    old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
    shadow_box(c, 70, y0, 940, h, 30, P["card"], stroke=P["navy"], sw=4)
    box(c, 70, y0, 940, 118, 30, P["navy"]); box(c, 70, y0 + 88, 940, 30, 0, P["navy"])
    fl = s.get("offer_flags", [])
    for i, f in enumerate(fl): draw_emoji(c, flag_emoji(f), 130 + i * 62, y0 + 38, 50)
    xl = 130 + len(fl) * 62 - 10
    T(c, "OFFER: " + s["offer_by"], 34, xl, y0 + 38, P["white"], 1, 1, 900, anchor="l", maxw=960 - xl)
    T(c, "הצעה: " + s["offer_by_he"], 32, 955, y0 + 86, P["gold2"], 1, 1, 700, anchor="r", maxw=820)
    yy = y0 + 118 + 18
    ao = ramp(t, to - 0.1, to + 0.2)
    block(c, s["en"], 50, 540, yy + hb / 2, P["navy"], ao, 1, 900, hl=P["blue"], maxw=860, max_lines=2); yy += hb + 10
    block(c, s["he"], 40, 540, yy + hh / 2, P["blue"], ao, 1, 700, maxw=860, max_lines=2); yy += hh + 24
    box(c, 120, yy, 840, 3, 1, P["silver"])
    draw_emoji(c, s["who_icon"], 160, yy + 52, 60)
    T(c, s["who"], 40, 215, yy + 34, P["navy"], 1, 1, 900, anchor="l", maxw=740)
    T(c, s["who_he"], 34, 955, yy + 78, P["gold_text"], 1, 1, 700, anchor="r", maxw=700)
    c.restore(); St.a = old
    cb = y0 + h; yb = cb + 100
    _react(c, t, s, tn, 170 + dx, cb + 36, min(1400, cb + 262), a)
    XS = 660
    _stamp(c, t, tn, s, XS + dx, yb)
    an = ramp(t, tn + 0.25, tn + 0.5) * a
    sub = s.get("ans_sub") or s.get("note")
    sub_he = s["ans_he"] if (s.get("ans_sub") or not s.get("note")) else s["ans_he"] + ". " + s["note_he"]
    yb = cb + 208
    if sub:
        z_, ls_ = RD.wrap(sub, 38, 800, 680, 2, 0.95)
        for j, l in enumerate(ls_): T(c, l, z_, XS + dx, yb + 46 * j, P["navy"], an, 1, 800, maxw=680)
        yb += 46 * len(ls_) + 4
    if sub_he: T(c, sub_he, 38, XS + dx, yb, col(s.get("ans_color"), "red"), an, 1, 800, maxw=680)

def sc_years(c, t, S):
    tm = S["times"]; st = S["stops"]
    # derived times: end of each answer = start of the next year word minus the pause
    if "n0e" not in tm:
        for k in range(len(st)):
            tm[f"n{k}e"] = (tm[f"y{k + 1}"] - 0.42) if k + 1 < len(st) else tm[f"n{k}"] + 1.0
    # caption (hook, on screen at frame 0)
    T(c, S["caption"], 52, 540, 240, P["navy"], 1, 1 + 0.01 * math.sin(t * 2.2), 900, maxw=940)
    T(c, S["caption_he"], 46, 540, 300, P["blue"], 1, 1, 700, maxw=940)
    u = ease(t / 0.9); box(c, 540 - 300 * u, 334, 600 * u, 7, 4, P["gold"])
    _track(c, t, S, 1.0)
    # the year panel
    v = _year_at(t, S); k = _cur(t, S); s = st[k]
    moving = abs(v - round(v)) > 0.02 or (k and t < tm[f"y{k}"] + 0.32 and t > tm[f"n{k - 1}e"])
    py, ph = 436, 190
    shadow_box(c, 170, py, 740, ph, 40, P["navy"], stroke=P["gold"], sw=6)
    yr = str(int(round(v)))
    lab = s.get("label") if (s.get("label") and not moving) else None
    z = 165 * (1 + (0.05 * math.sin(t * 5) if t < 2.6 else 0))
    land = tm[f"y{k}"] + 0.32
    if k and 0 <= t - land < 0.25: z *= 1 + 0.12 * (1 - (t - land) / 0.25)
    T(c, yr if not lab else lab, z if not lab else 132, 540, py + ph / 2 + 8, P["gold2"], 1, 1, 900, maxw=700)
    # card: card k shows from its year word until the counter starts moving again
    for i in range(len(st)):
        a_out = 1.0 - ramp(t, tm[f"n{i}e"], tm[f"n{i}e"] + 0.18) if i + 1 < len(st) else 1.0
        if t >= tm[f"y{i}"] - 0.06 and a_out > 0.01: _card(c, t, S, i, a_out)
    # per stop source line
    a = fade_in(t, tm[f"y{k}"] + 0.3, S) * (1.0 - ramp(t, tm[f"n{k}e"], tm[f"n{k}e"] + 0.15) if k + 1 < len(st) else 1.0)
    if t >= tm["y0"] - 0.06:
        z_, ls = RD.wrap("Source: " + s["source"], 30, 700, 960, 2, 0.85)
        for j, l in enumerate(ls): T(c, l, z_, 540, RD.SOURCE_Y + 20 - 20 * (len(ls) - 1) + 40 * j, P["grey"], a, 1.0, 700, src=True)

def sc_fair(c, t, S):
    t0 = S["t0"]; y = 330
    a, s = PP(t, t0 + 0.05, S); draw_emoji(c, S["icon"], 540, y + 90 + 8 * math.sin(t * 2.4), 170, a, s); y += 220
    pill(c, S["label"], 44, 540, y, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
    T(c, S["label_he"], 40, 540, y + 70, P["navy"], a, s, 700); y += 150
    he_ = block_h(S["en"], 66, 900, 920, 3); a, s = PP(t, t0 + 0.25, S, s0=0.7, bounce=1.4)
    block(c, S["en"], 66, 540, y + he_ / 2, P["navy"], a, s, 900, hl=P["blue"], maxw=920, max_lines=3); y += he_ + 24
    hh = block_h(S["he"], 50, 700, 920, 2); a, s = PP(t, t0 + 0.45, S)
    block(c, S["he"], 50, 540, y + hh / 2, P["blue"], a, s, 700, maxw=920, max_lines=2); y += hh + 70
    a = fade_in(t, t0 + 1.4, S)
    if not S.get("note"): source(c, t, S); return
    box(c, 140, y - 30, 800, 3, 1, P["silver"], a)
    T(c, S["note"], 40, 540, y + 20, P["gold_text"], a, 1, 800, maxw=940)
    T(c, S["note_he"], 38, 540, y + 76, P["gold_text"], a, 1, 700, maxw=940)
    source(c, t, S)

def sc_ask(c, t, S):
    t0 = S["t0"]; tm = S["times"]; y = 520
    a, s = PP(t, t0 + 0.05, S, bounce=2.2)
    T(c, S["en"], 104, 540, y, P["navy"], a, s, 900); T(c, S["he"], 72, 540, y + 110, P["blue"], a, s, 700); y += 280
    a, s = PP(t, tm.get("two", t0 + 0.6), S, bounce=2.2)
    block(c, S["en2"], 76, 540, y, P["navy"], a, s, 900, hl=P["gold_text"], maxw=940, max_lines=2)
    T(c, S["he2"], 58, 540, y + 110, P["blue"], a, s, 700); y += 300
    a, s = PP(t, tm.get("two", t0 + 0.6) + 0.3, S)
    T(c, S["follow"], 54, 540, y, P["navy"], a, s, 800, hl=P["gold_text"]); T(c, S["follow_he"], 44, 540, y + 66, P["gold_text"], a, s, 700)
