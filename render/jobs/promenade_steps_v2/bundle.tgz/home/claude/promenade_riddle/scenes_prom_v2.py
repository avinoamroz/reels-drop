"""promenade_steps_v2 (30 Oct 2026): full-bleed and circular version of the Tel Aviv promenade steps riddle.
- The map is the background of every frame (1080x1920, edge to edge), drawn from one global camera cam(t) and one walker
  position walk(t), so the last frame (t = T_END) equals frame 0: same map position, zoom and walker spot.
- Text is left-aligned across the width; critical content stays in x 40..940 (right 140 px clear) and y <= 1590 (bottom 330 clear);
  bands and the map run under the margins.
- Music: mix.bed is replaced by a seamless loop of the playful bed (26 bars, tempo locked to T_END, no intro, no outro, the
  decay past the end wrapped onto the start).
Scene types: hook, options, calc, reveal, coast, endcard. Shoreline is schematic (approximate landmark points)."""
import math
import cairo, numpy as np
from PIL import Image, ImageDraw, ImageFont
import render as RD
from render import P, T, pill, PP, fade_in, draw_emoji, shadow_box, col, pil2cairo, wrap
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, font
import kit

L0, R0 = 40, 940          # critical content x range
CX = 490; SUBY = 1546; BAND_TOP = 100; BAND_BOT = 640
G = {}                    # the Reel (set by the draw patch)

# ---------------------------------------------------------------- patches: Reel.draw stores the reel; background = the map
_orig_draw = RD.Reel.draw
def _draw(s, c, t):
    G["R"] = s; return _orig_draw(s, c, t)
RD.Reel.draw = _draw

def _bg(c, t):
    R = G.get("R")
    if R is None: c.set_source_rgb(1, 1, 1); c.paint(); return
    world(c, t, R)
RD.background = _bg

# ---------------------------------------------------------------- subtitles (centred on the safe width, last one cut at the loop)
def sub_surfs(pieces, sz=48, maxw=860):
    F = ImageFont.truetype(RD.SUB_FONT, sz); out = []
    for idx, (t0, t1, d) in enumerate(pieces):
        if idx == len(pieces) - 1: t1 -= 0.5          # do not hang over the loop point
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 22
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=RD.P255["navy"][:3] + (238,), outline=RD.P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 11 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        y = int(SUBY - Hd / 2) if len(lines) == 1 else int(SUBY + 41 - Hd)
        out.append((t0, t1, pil2cairo(im), int(CX - Wd / 2), y, d, Hd))
    return out
RD.sub_surfs = sub_surfs

# ---------------------------------------------------------------- seamless loop music
import mix as MX
def loop_bed(name, dur, end_at=None, bars=26):
    import sfx2 as S2
    from sfx2 import Bus, ksc, kick, shaker, tt, hz
    SR = S2.SR; n = int(round(dur * SR)); bar = dur / bars; beat = bar / 4
    prog = [(41, [65, 69, 72]), (38, [62, 65, 69]), (34, [62, 65, 70]), (36, [64, 67, 72])]
    mel = [77, None, 76, 77, 79, None, 77, None, 74, None, 72, 74, 76, None, None, None]
    def marimba(m, d=0.5):
        t = tt(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 40)) * np.exp(-t * 8) * np.minimum(1, t / 0.002)
    B = Bus(dur + 3.0)
    for b in range(bars):
        st = b * bar; idx = b % 4
        if b == bars - 2: idx = 2          # Bb, C at the end so the loop resolves onto F at bar 0
        if b == bars - 1: idx = 3
        root, ch = prog[idx]
        for off, mm in ((0, root), (1.5, root + 7), (2, root + 12), (3, root + 7)): B.put(ksc(mm - 12 if mm > 45 else mm, 0.5, 0.35), st + off * beat, 0.55)
        pat = [0, 1, 2, 1, 2, 1, 0, 2]
        for q in range(8): B.put(marimba(ch[pat[q]] + 12 * (q % 4 == 3), 0.45), st + q * beat / 2, 0.16 if q % 2 else 0.2, pan=0.3 * (1 if q % 2 else -1))
        ph = mel[(b % 2) * 8:(b % 2) * 8 + 8]
        for q, m in enumerate(ph):
            if m: B.put(ksc(m, 0.4, 0.7), st + q * beat / 2, 0.16, pan=-0.2)
        for q in (0, 2): B.put(kick(), st + q * beat, 0.35)
        for q in range(8): B.put(shaker(), st + q * beat / 2, 0.05 if q % 2 else 0.035, 0.35)
    x = B.out(1e-3, 1e-3, (0.6, 0.15))
    y = x[:, :n].copy(); tail = x[:, n:]; k = min(n, tail.shape[1]); y[:, :k] += tail[:, :k]    # wrap the decay onto the start
    return y / (np.abs(y).max() + 1e-12)
MX.bed = loop_bed

# ---------------------------------------------------------------- world: schematic shoreline (lat, lon), north to south
COAST = [(32.400, 34.8600), (32.300, 34.8380), (32.200, 34.8120), (32.175, 34.8040), (32.160, 34.7990), (32.146, 34.7950), (32.135, 34.7905), (32.125, 34.7870),
         (32.115, 34.7825), (32.108, 34.7790), (32.1030, 34.7760),
         (32.0985, 34.7730),                                    # 9: Tel Aviv Port
         (32.0930, 34.7703), (32.0880, 34.7686), (32.0830, 34.7672), (32.0780, 34.7658), (32.0730, 34.7642), (32.0680, 34.7620),
         (32.0630, 34.7586), (32.0590, 34.7552),
         (32.0550, 34.7514),                                    # 18: Jaffa Port
         (32.0515, 34.7500), (32.0465, 34.7490), (32.0400, 34.7472), (32.0330, 34.7445), (32.0250, 34.7415),
         (32.0100, 34.7370), (31.9900, 34.7300), (31.9600, 34.7210), (31.9300, 34.7110), (31.8800, 34.6930), (31.8000, 34.6600), (31.7000, 34.6200)]
I0, I1 = 11, 20
HZ, BY = 5, 25            # Hatzuk / Herzliya border, Bat Yam border
LON0 = 34.766; COS = math.cos(math.radians(32.07))

# cameras: (lat at screen y 960, px per degree of latitude, x offset)
def cam_fit(lat_top, lat_bot, y_top, y_bot, xo=-60):
    k = (y_bot - y_top) / (lat_top - lat_bot); lat_mid = (lat_top + lat_bot) / 2; y_mid = (y_top + y_bot) / 2
    return (lat_mid + (y_mid - 960) / k, k, xo)
PT, PB = 32.0985, 32.0550
CAM_A = cam_fit(PT, PB, 700, 1420)
CAM_A2 = (CAM_A[0] + 0.0010, CAM_A[1] * 1.12, -60)
CAM_A3 = (CAM_A[0] + 0.0018, CAM_A[1] * 1.20, -60)
CAM_B = cam_fit(PT, PB, 330, 780)
CAM_C = cam_fit(PT, PB, 300, 640)
CAM_D = cam_fit(32.146, 32.025, 270, 1000, xo=-40)

def cam_lerp(a, b, u):
    return (lerp(a[0], b[0], u), math.exp(lerp(math.log(a[1]), math.log(b[1]), u)), lerp(a[2], b[2], u))
def times(R):
    if "_tk" not in G or G.get("_rid") is not R:
        G["_tk"] = [S["t0"] for S in R.scenes] + [R.T_END]; G["_rid"] = R
    return G["_tk"]
def cam(t, R):
    T0, T1, T2, T3, T4, T5, TE = times(R)
    if t < T1: return cam_lerp(CAM_A, CAM_A2, ease(t / T1))
    if t < T2: return cam_lerp(CAM_A2, CAM_A3, (t - T1) / (T2 - T1))
    if t < T3: return cam_lerp(CAM_A3, CAM_B, ease((t - T2) / 1.2))
    if t < T4: return cam_lerp(CAM_B, CAM_C, ease((t - T3) / 1.0))
    if t < T5: return cam_lerp(CAM_C, CAM_D, ease((t - T4) / 1.3))
    return cam_lerp(CAM_D, CAM_A, ease((t - T5) / (TE - T5)))
WALK_V = 0.008
def walk(t, R):
    T0, T1, T2, T3, T4, T5, TE = times(R)
    u0 = 0.03
    if t < T2: return u0 + WALK_V * t
    if t < T3:
        a = u0 + WALK_V * T2; return lerp(a, 1.0, min(1.0, (t - T2) / (T3 - 0.3 - T2)))
    if t < T4: return 1.0
    if t < T5: return None
    return max(0.0, u0 + WALK_V * (t - TE))
def steps_at(u): return u * 10400

def proj(lat, lon, cm):
    clat, k, xo = cm
    return (540 + xo + (lon - LON0) * COS * k, 960 - (lat - clat) * k)

def poly_len(pts): return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:]))
def along(pts, u):
    L = poly_len(pts); d = u * L
    for a, b in zip(pts, pts[1:]):
        l = math.hypot(b[0] - a[0], b[1] - a[1])
        if d <= l or b is pts[-1]:
            f = 0 if l == 0 else min(1, d / l); return (lerp(a[0], b[0], f), lerp(a[1], b[1], f))
        d -= l
    return pts[-1]
def sub_poly(pts, u):
    L = poly_len(pts); d = u * L; out = [pts[0]]
    for a, b in zip(pts, pts[1:]):
        l = math.hypot(b[0] - a[0], b[1] - a[1])
        if d >= l: out.append(b); d -= l
        else:
            f = 0 if l == 0 else d / l; out.append((lerp(a[0], b[0], f), lerp(a[1], b[1], f))); break
    return out
def stroke(c, pts, cc, w, a=1.0):
    if len(pts) < 2: return
    sa(c, cc, a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.stroke()

def per(t, R, f):
    """angular frequency close to f whose period divides T_END (so periodic motion matches at the loop)"""
    n = max(1, round(f * R.T_END / (2 * math.pi))); return 2 * math.pi * n / R.T_END

def world(c, t, R):
    cm = cam(t, R); old = St.a; St.a = 1.0
    g = cairo.LinearGradient(0, 0, W, 0); g.add_color_stop_rgb(0, 0.62, 0.79, 0.94); g.add_color_stop_rgb(1, 0.78, 0.88, 0.97)
    c.set_source(g); c.paint()
    pts = [proj(la, lo, cm) for la, lo in COAST]
    # waves (screen space, periodic in T_END)
    w1 = per(t, R, 1.3); w2 = per(t, R, 0.8)
    for k in range(14):
        yy = 60 + k * 140 + 14 * math.sin(t * w1 + k); xx = 30 + 120 * ((k * 37) % 5) / 5 + 30 * math.sin(t * w2 + k * 1.7)
        sa(c, P["white"], 0.5); c.set_line_width(4); c.move_to(xx, yy)
        for j in range(3): c.rel_curve_to(14, -11, 28, -11, 42, 0)
        c.stroke()
    # land
    c.move_to(pts[0][0] + 3000, pts[0][1]); [c.line_to(*p) for p in pts]; c.line_to(pts[-1][0] + 3000, pts[-1][1]); c.close_path()
    sa(c, kit.hx("#F1EBDD")); c.fill()
    # streets: lines inland, tied to the map so they move with the camera
    sa(c, P["border"], 0.45); c.set_line_width(max(1.5, cm[1] / 9000))
    lat = 31.93
    while lat < 32.20:
        a = proj(lat, 34.70, cm); b = proj(lat + 0.006, 34.90, cm)
        # start each cross street at the coast
        cx_ = None
        for (la1, lo1), (la2, lo2) in zip(COAST, COAST[1:]):
            if la2 <= lat <= la1:
                f = (la1 - lat) / max(1e-9, la1 - la2); cx_ = lerp(lo1, lo2, f) + 0.002; break
        if cx_ is not None:
            p0 = proj(lat, cx_, cm); p1 = proj(lat + 0.004, cx_ + 0.06, cm); c.move_to(*p0); c.line_to(*p1); c.stroke()
        lat += 0.0045
    for off in (0.006, 0.013, 0.021):
        sl = [proj(la, lo + off, cm) for la, lo in COAST]; c.move_to(*sl[0]); [c.line_to(*p) for p in sl[1:]]; c.stroke()
    stroke(c, pts, kit.hx("#E3D3A8"), max(10, cm[1] / 900))      # sand
    stroke(c, pts, P["border"], 3)
    prom = pts[I0:I1 + 1]; lw = max(9, min(16, cm[1] / 1400))
    D = times(R); coast_on = D[4] + 0.9 <= t < D[5] + 0.4
    if coast_on:
        a = ramp(t, D[4] + 0.9, D[4] + 1.3) * (1 - ramp(t, D[5], D[5] + 0.4))
        full = pts[HZ:BY + 1]; stroke(c, full, P["white"], lw + 9, a); stroke(c, full, P["gold"], lw, a)
    stroke(c, prom, P["white"], lw + 9); stroke(c, prom, P["blue"], lw)
    u = walk(t, R)
    if u is not None and u > 0: stroke(c, sub_poly(prom, u), P["gold"], lw)
    for i, cc in ((I0, "navy"), (I1, "gold")):
        px, py = pts[i]; circ(c, px, py, 18, P["white"]); circ(c, px, py, 12, col(cc))
    if coast_on:
        a = ramp(t, D[4] + 0.9, D[4] + 1.3) * (1 - ramp(t, D[5], D[5] + 0.4))
        for i in (HZ, BY): px, py = pts[i]; circ(c, px, py, 16, P["white"], a); circ(c, px, py, 10, P["gold"], a)
    G["pts"] = pts; G["cm"] = cm
    # labels
    for i, txt in ((I0, "Tel Aviv Port"), (I1, "Jaffa Port")):
        px, py = pts[i]
        if 150 < py < 1500 and not (coast_on and t > D[4] + 1.0):
            sz = 42; tw = font(sz, 800).getlength(txt)
            lx = min(px + 50 + tw / 2 + 25, R0 - tw / 2 - 25)
            pill(c, txt, sz, lx, py, P["white"], P["navy"], 1, 1, outline=P["navy"] if i == I0 else P["gold"], w=800, padx=0.45, padh=1.4)
    if u is not None:
        wx, wy = along(prom, max(0.0, min(1.0, u))); wb = per(t, R, 9.0)
        bob = abs(math.sin(t * wb / 2)) * 12
        circ(c, wx, wy, 34, P["white"], 0.85)
        draw_emoji(c, "\U0001F6B6", wx - 4, wy - 56 - bob, 112, 1.0, 1.0, 0.08 * math.sin(t * wb / 2))
    St.a = old

# ---------------------------------------------------------------- overlay helpers
def band(c, y0, y1, a=0.92, color="white", stripe=True):
    if a <= 0.01: return
    sa(c, P[color], a); c.rectangle(0, y0, W, y1 - y0); c.fill()
    if stripe: sa(c, P["gold"], a); c.rectangle(0, y1 - 8, W, 8); c.fill()
def ltext(c, s, sz, x, ytop, color, a=1.0, maxw=880, max_lines=4, lh=1.06, hl=None, w=900):
    """left-aligned wrapped text from ytop; returns height"""
    z, ls = wrap(s, sz, w, maxw, max_lines); step = z * lh
    for k, l in enumerate(ls): T(c, l, z, x, ytop + step * (k + 0.5), color, a, 1.0, w, hl or P["blue"], maxw + 4, anchor="l")
    return step * len(ls)
def src(c, t, S, y=1442):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + 0.5, S); ls = s if isinstance(s, list) else [s]
    sa(c, P["white"], 0.86 * a * St.a); rr(c, L0 - 14, y - 26, R0 - L0 + 28, 40 * len(ls) + 12, 16); c.fill()
    for k, l in enumerate(ls): T(c, l, 34, L0, y + 40 * k, P["grey"], a, 1.0, 700, maxw=R0 - L0, anchor="l", src=True)
def tm(S, k, d=None):
    return S["times"].get(k, None if d is None else S["t0"] + d)
def counter(c, t, R, y=130):
    u = walk(t, R)
    if u is None: return
    txt = f"{int(round(steps_at(min(1, u)))):,} steps"; sz = 92; tw = font(sz, 900).getlength(txt)
    pw = tw + 190; ph = 140; x = L0
    shadow_box(c, x, y, pw, ph, ph / 2, P["navy"], stroke=P["gold"], sw=5, sh=8)
    draw_emoji(c, "\U0001F463", x + 72, y + ph / 2, 76)
    T(c, txt, sz, x + 128, y + ph / 2 + 3, P["white"], 1, 1, 900, maxw=760, anchor="l")

# ---------------------------------------------------------------- scenes
def title_band(c, t, S, en, a=1.0, s=1.0):
    band(c, BAND_TOP, BAND_BOT, 0.93)
    pill(c, S.get("chip", "TEL AVIV RIDDLE"), 38, L0 + 170, BAND_TOP + 58, P["gold"], P["white"], a, 1, w=800)
    z, ls = wrap(en, 104, 900, 880, 4); h = z * 1.06 * len(ls)
    ltext(c, en, 104, L0 + 10, BAND_TOP + 100 + (BAND_BOT - BAND_TOP - 120 - h) / 2, P["navy"], a, 880, 4)

def sc_hook(c, t, S):
    a, s = PP(t, S["t0"], S)
    title_band(c, t, S, S["en"], a)

def sc_endcard(c, t, S):
    a = fade_in(t, S["t0"], S, 0.25)
    title_band(c, t, S, S["en"], a)

def sc_options(c, t, S):
    sa(c, P["white"], 0.5 * St.a); c.paint()
    band(c, BAND_TOP, 270, 0.93)
    a, s = PP(t, S["t0"] + 0.05, S)
    ltext(c, S.get("title", "How many *steps?*"), 120, L0 + 10, BAND_TOP + 8, P["navy"], a, 880, 1)
    opts = S["options"]; ch = 248; gap = 22; ytop = 300
    for k, (letter, val) in enumerate(opts):
        tk = tm(S, f"o{k}", 0.4 + 1.4 * k); a, s = PP(t, tk, S)
        if a <= 0.01: continue
        y = ytop + k * (ch + gap); old = St.a; St.a *= a
        c.save(); c.translate(540, y + ch / 2); c.scale(s, s); c.translate(-540, -(y + ch / 2))
        shadow_box(c, 24, y, W - 48, ch, 48, P["card"], stroke=P["silver"], sw=4, sh=10)
        circ(c, L0 + 110, y + ch / 2, 92, P["navy"]); T(c, letter, 124, L0 + 110, y + ch / 2 + 5, P["white"], 1, 1, 900)
        T(c, val, 168, L0 + 250, y + ch / 2 + 6, P["navy"], 1, 1, 900, maxw=R0 - L0 - 250, anchor="l")
        c.restore(); St.a = old
    tp = tm(S, "pick", 6.0); tw = tm(S, "walk", 7.5)
    walking = t >= tw - 0.07
    txt, em = ("Now let's walk it", "\U0001F6B6") if walking else ("Pick one", "\U0001F447")
    a, s = PP(t, tp, S, bounce=2.4)
    pw = pill(c, txt, 84, CX - 45, 1428, P["gold"], P["white"], a, s, w=900)
    if a > 0.01: draw_emoji(c, em, CX - 45 + pw / 2 + 60, 1428, 96, a, s)

def row(c, t, y, h, icon, small, big, t_in, t_big=None, big2=None, color="silver", S=None, replace=False):
    if t < t_in - 0.07: return
    a = fade_in(t, t_in - 0.07, S, 0.2); u = ease((t - t_in + 0.07) / 0.35); dx = 260 * (1 - u)
    old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
    shadow_box(c, 24, y, W - 48, h - 12, 30, P["card"], stroke=col(color, "silver"), sw=4, sh=6)
    draw_emoji(c, icon, L0 + 50, y + (h - 12) / 2, 74)
    T(c, small, 38, L0 + 118, y + 38, P["grey"], 1, 1, 800, maxw=R0 - L0 - 118, anchor="l")
    show2 = t_big is not None and t >= t_big - 0.07
    bt = (big2 if replace else big + " " + big2) if (big2 and show2) else big
    T(c, bt, 80, L0 + 118, y + 98, P["navy"], 1, 1, 900, hl=P["gold_text"], maxw=R0 - L0 - 118, anchor="l")
    c.restore(); St.a = old

def sc_calc(c, t, S):
    R = G["R"]; counter(c, t, R)
    rh = 146; y = 826
    for k, r in enumerate(S["rows"]):
        row(c, t, y + k * rh, rh, r["icon"], r["small"], r["big"], tm(S, f"r{k}", 0.5 + 3 * k), tm(S, f"r{k}b"),
            r.get("big2"), r.get("color", "silver"), S, r.get("replace", False))
    src(c, t, S, 1446)

def sc_reveal(c, t, S):
    R = G["R"]; counter(c, t, R)
    ch = 232; y = 668
    for k, cd in enumerate(S["cards"]):
        tk = tm(S, f"c{k}", 0.3 + 3 * k); a, s = PP(t, tk, S, bounce=2.4)
        if a <= 0.01: continue
        yy = y + k * (ch + 14); old = St.a; St.a *= a
        c.save(); c.translate(540, yy + ch / 2); c.scale(s, s); c.translate(-540, -(yy + ch / 2))
        shadow_box(c, 24, yy, W - 48, ch, 44, P["navy"], stroke=P["gold"], sw=6, sh=10)
        draw_emoji(c, cd["icon"], L0 + 76, yy + ch / 2, 120)
        T(c, cd["label"], 46, L0 + 170, yy + 50, P["gold2"], 1, 1, 800, maxw=R0 - L0 - 170, anchor="l")
        T(c, cd["value"], 156, L0 + 170, yy + ch - 82, P["white"], 1, 1, 900, maxw=R0 - L0 - 170, anchor="l")
        c.restore(); St.a = old
    tw = tm(S, "win", 6.5); yo = y + 2 * (ch + 14) + 6; th = 236
    opts = S["options"]; wx = (R0 - L0 + 20) / 4
    for k, (letter, val) in enumerate(opts):
        x0 = L0 - 16 + wx * k; xx = x0 + wx / 2
        win = S["winners"].get(letter); lit = bool(win) and t >= tw - 0.07
        a, s = (PP(t, tw + 0.15 * (letter == "C"), S, bounce=2.6) if lit else (1.0, 1.0))
        bg = P["gold"] if lit else P["card"]; fg = P["white"] if lit else P["navy"]
        shadow_box(c, x0 + 6, yo, wx - 12, th, 30, bg, stroke=P["gold"] if lit else P["silver"], sw=4, sh=6)
        T(c, letter, 104, xx, yo + 66, fg, 1, 1, 900)
        T(c, val, 62, xx, yo + 152, fg, 1, 1, 900, maxw=wx - 30)
        if lit: T(c, win, 44, xx, yo + 208, P["navy"], a, s, 900, maxw=wx - 20)
    src(c, t, S, 1442)

def sc_coast(c, t, S):
    band(c, BAND_TOP, 250, 0.93)
    a, s = PP(t, S["t0"] + 0.05, S)
    ltext(c, S["title"], 112, L0 + 10, BAND_TOP + 8, P["navy"], a, 880, 1)
    pts = G.get("pts")
    if pts:
        al = ramp(t, S["t0"] + 1.0, S["t0"] + 1.4)
        for i, txt in ((HZ, "Hatzuk Beach"), (BY, "Bat Yam border")):
            px, py = pts[i]; tw = font(42, 800).getlength(txt)
            pill(c, txt, 42, min(px + 60 + tw / 2 + 25, R0 - tw / 2 - 25), py, P["white"], P["navy"], al, 1, outline=P["gold"], w=800, padx=0.45, padh=1.4)
    tk = tm(S, "v", 1.6); a, s = PP(t, tk, S, bounce=2.4); y = 1030; hh = 360
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(540, y + hh / 2); c.scale(s, s); c.translate(-540, -(y + hh / 2))
        shadow_box(c, 24, y, W - 48, hh, 44, P["navy"], stroke=P["gold"], sw=6, sh=10)
        T(c, S["label"], 48, L0 + 20, y + 62, P["gold2"], 1, 1, 800, maxw=R0 - L0 - 20, anchor="l")
        T(c, S["value"], 136, L0 + 20, y + 178, P["white"], 1, 1, 900, maxw=R0 - L0 - 20, anchor="l")
        T(c, S["sub"], 60, L0 + 20, y + 298, P["gold2"], 1, 1, 900, maxw=R0 - L0 - 20, anchor="l")
        c.restore(); St.a = old
    src(c, t, S, 1424)
