"""v4: loop-clean music bed + SFX under vo_final.wav -> mix.m4a (-14 LUFS, -1.5 dBTP)"""
import sys, os, json, numpy as np, soundfile as sf, subprocess
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/bangers_1102/mena_rights_rehook")
import mix as MX
import engine as E
vo, sr = sf.read(f"{E.D}/vo_final.wav"); dur = E.END
# loop-clean bed: render the piano past the end (no end fade inside the reel), then crossfade the
# overflow into the opening so the last sample flows straight into the first one when the reel loops
m = MX._mod(*MX.BEDS["doc_piano"][:2]); n = int(dur * MX.SR); f = int(0.8 * MX.SR)
x = np.asarray(m.doc_music(dur + 4.5), np.float64)
if x.ndim == 1: x = np.vstack([x, x])
music = x[:, :n].copy(); g = np.sin(np.linspace(0, np.pi / 2, f))
music[:, :f] = x[:, :f] * g + x[:, n:n + f] * np.cos(np.linspace(0, np.pi / 2, f))
music /= np.abs(music).max() + 1e-12
ev = []
for gk in E.ORDER:
    g = E.G[gk]; ev.append((g["t_in"] - 0.1, "whoosh", 0))
    for c, tf in g["fill"].items():
        if tf > 0: ev.append((tf, "pop", 0))
ev.append((E.T_ISR + 0.2, "ding", 2)); ev.append((E.T_SB, "whoosh", 0)); ev.append((E.T_Q, "whoosh", -2))
rep = MX.mix(vo, dur, music, ev, f"{E.D}/mix.wav", music_db=-19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{E.D}/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{E.D}/mix.m4a"], check=True)
os.remove(f"{E.D}/mix.wav"); print(rep)
