"""mena_rights_rehook: voice ONLY the new hook line through the same house chain as v4 (tempo 1.1), splice it into
v4's vo_final.wav in place of line 0 (first word at the same 0.336 s), update timing.json line 0. Everything else untouched."""
import sys, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice
from clean_vo import clean as clean_vo
D = "/home/claude/bangers_1102/mena_rights_rehook"; voice.TEMPO = 1.1
W = json.load(open("/home/claude/bangers_1102/mena_hook_words.json"))
dry = voice.chain_dry("/home/claude/bangers_1102/mena_hook.wav"); cl = clean_vo(dry, voice.SR)
y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); hk = voice.post(y)
k = (len(hk) / voice.SR - voice.LEAD) / (len(dry) / voice.SR); tm = lambda x: voice.LEAD + x * k
vo, sr = sf.read(f"{D}/vo_final.wav"); assert sr == voice.SR
T = json.load(open(f"{D}/timing.json")); L0, L1 = T["lines"][0], T["lines"][1]
shift = L0["t0"] - tm(W[0]["start"])                       # first word lands where the old hook began
cut = int((L1["t0"] - 0.12) * sr)                         # clear the old hook up to just before line 1
vo[:cut] = 0.0
a = int(round(shift * sr)); hk = hk[max(0, -a):]; a = max(0, a)
end = min(cut, a + len(hk)); vo[a:end] += hk[:end - a]
words = [dict(w=w["word"], t0=round(tm(w["start"]) + shift, 3), t1=round(tm(w["end"]) + shift, 3)) for w in W]
assert words[-1]["t1"] < L1["t0"] - 0.15, words[-1]
T["lines"][0] = dict(i=0, text="Muslims are freest here. Guess where.", t0=words[0]["t0"], t1=words[-1]["t1"], words=words)
sf.write(f"{D}/vo_final.wav", vo.astype(np.float32), sr); json.dump(T, open(f"{D}/timing.json", "w"), indent=0)
print("hook", words[0]["t0"], "to", words[-1]["t1"], "line1 at", L1["t0"])
