"""rk.py (REMAKES 6c): reelkit in two stages. prep runs locally (voice chain, Cartesia SSE timing, mix); render runs on GitHub.
  prep   SPEC SSE_PREFIX OUT [--preview]     render SPEC OUT/timing.json OUT/mix.wav OUT.mp4"""
import os, sys, json
sys.path.insert(0, "/home/claude/reelkit")
def prep(spec_p, pre, out, preview):
    import voice, render as RD, mix as MX, make_reel_sse as MRS
    os.makedirs(out, exist_ok=True)
    spec = RD.load_spec(spec_p); sdir = os.path.dirname(os.path.abspath(spec_p))
    sp = spec["script"]; sp = sp if os.path.isabs(sp) else os.path.join(sdir, sp)
    lines = voice.read_script(sp)
    if not os.path.exists(f"{out}/timing.json"):
        r = MRS.sse_process(voice, pre, lines, print)
        vo, tim = voice.select(r["vo"], r["timing"], None, gap_max=spec.get("gap_max", 0.6), gap_new=spec.get("gap_new", 0.45))
        ex = {int(k): float(v) for k, v in (spec.get("gap_extra") or {}).items()}
        if ex:   # extra dramatic pause before 1-based line k (after select): shift the voice and the timing from that line on
            import numpy as np
            SR = voice.SR; L = tim["lines"]; cuts = [((L[k - 1]["t0"] + L[k - 2]["t1"]) / 2, ex[k]) for k in sorted(ex)]
            parts, last = [], 0.0
            for tc, d in cuts:
                parts += [vo[int(last * SR):int(tc * SR)], np.zeros(int(d * SR))]; last = tc
            parts.append(vo[int(last * SR):]); vo = np.concatenate(parts)
            sh = lambda x: x + sum(d for tc, d in cuts if x > tc)
            for w in tim["words"]: w["t0"] = round(sh(w["t0"]), 3); w["t1"] = round(sh(w["t1"]), 3)
            for l in L: l["t0"] = round(sh(l["t0"]), 3); l["t1"] = round(sh(l["t1"]), 3)
            tim["dur"] = round(len(vo) / SR, 3)
        voice.write(out, vo, tim, r["report"])
    else:
        import soundfile as sf
        tim = json.load(open(f"{out}/timing.json")); vo, _ = sf.read(f"{out}/vo.wav")
    R = RD.Reel(spec, tim); print("T_END", R.T_END, "warn", R.warn)
    RD.preview(R, R.keytimes(), f"{out}/preview.png")
    if preview: return
    end_at = R.T_END - 2.0
    bed = MX.bed(spec.get("music", "doc_piano"), R.T_END, end_at); ev = [(tt, k, 0.0) for tt, k in R.sfx_events()]
    MX.mix(vo, R.T_END, bed, ev, f"{out}/mix.wav", music_db=spec.get("music_db", -17.0), log=print)
def render(spec_p, tim_p, wav, mp4):
    import render as RD
    os.makedirs(os.path.dirname(mp4), exist_ok=True)
    R = RD.Reel(RD.load_spec(spec_p), json.load(open(tim_p)))
    v = RD.render_video(R, wav, mp4, log=print); print("rendered", v["sec"], "s", v["frames"], "frames")
if __name__ == "__main__":
    a = sys.argv[1:]
    if a[0] == "prep": prep(a[1], a[2], a[3], "--preview" in a)
    else: render(*a[1:5])
