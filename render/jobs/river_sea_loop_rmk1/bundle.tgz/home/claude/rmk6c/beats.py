"""beats.py (REMAKES 6c, 1 Nov 2026): shared scene module for river_sea_loop_rmk1, not_math_v3_rmk1, x_express10_en_v5_rmk1.
Brand background: navy gradient #0E1E3A to #2749D3 with a slow sky glow. One idea on screen at a time.
Scene "beats": S["beats"] = [{mark (name in S["marks"], else scene start), kicker, emoji, ring {pct, dec, label},
  num {to, from, prefix, suffix, dec, dur, size, year}, photo {src, credit}, lines [[text, size, color]], he, source, strike}]
Each beat replaces the previous one on its spoken word (cross-fade + small rise).
Scene "rivermap": the regional map (guess phase) or the Israel map (answer, Belgium, waist), phase marks in S["marks"].
Circular ending: looplib (last loop_xfade s cross-fade into frame 0, looping bed)."""
import sys, math, os
sys.path.insert(0, "/home/claude/reelkit")
sys.path.append("/home/claude/fix6/lib")
import looplib; looplib.wrap(globals())
import cairo
import render as RD
import kit
from kit import ease, St, sa, rr, ramp, lerp
import ovl5 as O
W, H = 1080, 1920
NAVY0, NAVY1 = kit.hx("#0E1E3A"), kit.hx("#2749D3"); SKY = kit.hx("#45A4DD"); YEL = kit.hx("#F5C518")
WHITE = kit.hx("#FFFFFF"); RED = kit.hx("#FF5A64"); GREEN = kit.hx("#2ECC71"); NAVY = kit.hx("#163261"); SOFT = kit.hx("#C9D6F2")
COL = dict(white=WHITE, yellow=YEL, sky=SKY, red=RED, green=GREEN, soft=SOFT)
_BG = {}

def bg(c, t):
    if "g" not in _BG:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(s)
        g = cairo.LinearGradient(0, 0, W * 0.3, H); g.add_color_stop_rgb(0, *NAVY0[:3]); g.add_color_stop_rgb(1, *NAVY1[:3])
        cc.set_source(g); cc.paint(); _BG["g"] = s
    c.set_source_surface(_BG["g"], 0, 0); c.paint()
    for k, (bx, by, br) in enumerate([(300, 650, 560), (800, 1350, 640)]):
        gx, gy = bx + 120 * math.sin(t * 0.31 + k * 2.1), by + 110 * math.cos(t * 0.26 + k)
        rg = cairo.RadialGradient(gx, gy, 0, gx, gy, br)
        rg.add_color_stop_rgba(0, SKY[0], SKY[1], SKY[2], 0.20); rg.add_color_stop_rgba(1, SKY[0], SKY[1], SKY[2], 0)
        c.rectangle(0, 0, W, H); c.set_source(rg); c.fill()

def _col(x, d="white"): return COL.get(x or d, None) or kit.hx(x)

def lines_block(c, lines, y, a, s):
    """lines: [[text, size, colour]] stacked and centred on y; returns the block height"""
    if a <= 0.01: return 0
    lay = []
    for ln in lines:
        txt, sz = ln[0], ln[1]; cl = _col(ln[2] if len(ln) > 2 else "white")
        z, ls = RD.wrap(txt, sz, 900, 960, 3); lay += [(l, z, cl) for l in ls]
    hh = sum(z * 1.2 for _, z, _ in lay); yy = y - hh / 2
    for l, z, cl in lay:
        RD.T(c, l, z, 540, yy + z * 0.6, cl, a, s, 900, hl=YEL, maxw=980); yy += z * 1.2
    return hh

def ring(c, cx, cy, r, u, pct, col, a):
    c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.set_line_width(46); c.set_source_rgba(1, 1, 1, 0.14 * a); c.arc(cx, cy, r, 0, 2 * math.pi); c.stroke()
    e = -math.pi / 2 + 2 * math.pi * pct / 100 * u
    if u > 0.001:
        c.set_source_rgba(col[0], col[1], col[2], a); c.arc(cx, cy, r, -math.pi / 2, e); c.stroke()

def numtxt(v, n):
    d = n.get("dec", 0)
    s = f"{v:.{d}f}" if n.get("year") else f"{v:,.{d}f}"
    return f"{n.get('prefix', '')}{s}{n.get('suffix', '')}"

def photo(c, p, t, t0, t1, a, y0=420, h=720):
    if a <= 0.01 or not os.path.exists(p["src"]): return False
    w = 920; x0 = 80; u = ramp(t, t0, max(t0 + 1, t1)); z = lerp(1.0, 1.08, u)
    sf = RD.image_surf(p["src"], int(w * 1.1), int(h * 1.1))
    c.save(); rr(c, x0, y0, w, h, 36); c.clip()
    c.translate(x0 + w / 2, y0 + h / 2); c.scale(z / 1.1, z / 1.1); c.translate(-sf.get_width() / 2, -sf.get_height() / 2)
    c.set_source_surface(sf, 0, 0); c.paint_with_alpha(a); c.restore()
    c.set_line_width(5); c.set_source_rgba(1, 1, 1, 0.85 * a); rr(c, x0, y0, w, h, 36); c.stroke()
    if p.get("credit"): RD.T(c, p["credit"], 36, 540, y0 + h + 40, SOFT, a, 1.0, 700, maxw=960, src=True)
    return True

def sc_beats(c, t, S):
    bg(c, t)
    tm = S["times"]; hook = S["hook"]; t0s = S["t0"]; t1s = S["t1"] or (t0s + 4)
    bs = S["beats"]; times = [(tm.get(b.get("mark"), t0s) if b.get("mark") else t0s) for b in bs]
    if hook: times[0] = 0.0
    for k, b in enumerate(bs):
        tb = times[k]; te = times[k + 1] if k + 1 < len(bs) else t1s + 0.3
        if t < tb - 0.05 or t > te + 0.3: continue
        first = hook and k == 0
        ai = 1.0 if first else ease(ramp(t, tb, tb + 0.35)); ao = 1 - ease(ramp(t, te - 0.05, te + 0.25)) if k + 1 < len(bs) else 1.0
        a = ai * ao * St.a; s = 1.0 if first else lerp(0.94, 1.0, ai); dy = 0 if first else 40 * (1 - ai)
        c.save(); c.translate(0, dy)
        OFF = S.get("off", 130); y = 360
        if b.get("kicker"):
            RD.T(c, b["kicker"], 48, 540, y, SKY, a, 1.0, 800, maxw=960); y += 90
        vis_y = b.get("vis_y", 720) + OFF
        if b.get("photo") and photo(c, b["photo"], t, tb, te, a, y0=b["photo"].get("y0", y + 10) + OFF - 60, h=b["photo"].get("h", 700)):
            y = b["photo"].get("y0", y + 10) + OFF - 60 + b["photo"].get("h", 700) + 110
        elif b.get("ring"):
            rgd = b["ring"]; u = 1.0 if first else ease(ramp(t, tb + 0.1, tb + 1.3)); cl = _col(rgd.get("color"), "yellow")
            ring(c, 540, vis_y, 300, u, rgd["pct"], cl, a)
            v = rgd["pct"] * u; RD.T(c, f"{v:.{rgd.get('dec', 0)}f}%", rgd.get("size", 220), 540, vis_y + 8, cl, a, 1.0, 900, maxw=440)
            y = vis_y + 400
        elif b.get("num"):
            n = b["num"]; d = n.get("dur", 1.4); u = 1.0 if first else ease(ramp(t, tb + 0.05, tb + d))
            v = lerp(n.get("from", 0), n["to"], u)
            if n.get("int", True) and not n.get("dec"): v = round(v)
            RD.T(c, numtxt(v, n), n.get("size", 230), 540, vis_y, _col(n.get("color"), "yellow"), a, s, 900, maxw=1000)
            y = vis_y + n.get("size", 230) * 0.5 + 90
        elif b.get("emoji"):
            RD.draw_emoji(c, b["emoji"], 540, vis_y + 8 * math.sin(t * 2.2), b.get("emoji_px", 300), a, s)
            y = vis_y + 250
        if b.get("strike") and b.get("lines"):
            pass
        if b.get("lines"):
            ly = b.get("lines_y"); ly = ly + OFF if ly is not None else None
            if ly is None:
                hh = sum(RD.block_h(l[0], l[1], 900, 960, 3) * 1.05 for l in b["lines"])
                ly = y + hh / 2
            hh = lines_block(c, b["lines"], ly, a, s); y = ly + hh / 2 + 50
        if b.get("strike"):
            sx = b["strike"]; u = ease(ramp(t, tm.get(sx["mark"], tb + 0.6), tm.get(sx["mark"], tb + 0.6) + 0.3))
            yy = sx["y"]; c.set_line_width(14); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_source_rgba(RED[0], RED[1], RED[2], a)
            c.move_to(sx["x0"], yy); c.line_to(lerp(sx["x0"], sx["x1"], u), yy); c.stroke()
        if b.get("he"):
            RD.T(c, b["he"], 58, 540, (b["he_y"] + OFF if b.get("he_y") else min(y + 100, 1460)), SOFT, a, 1.0, 700, maxw=960)
        if b.get("pills"):
            for j, pl in enumerate(b["pills"]):
                tp = tm.get(pl.get("mark"), tb + 0.3 + 0.4 * j); pa, ps = (1.0, 1.0) if first else kit.pop(t, tp, 0.45, 0.15, 2.0)
                if pa * a <= 0.01: continue
                yy = pl["y"] + OFF; old = St.a; St.a = a
                O.pill_at(c, pl["text"], pl.get("size", 84), 540, yy, pa * a, bg=_col(pl.get("bg"), "white"), fg=_col(pl.get("fg"), "white") if pl.get("fg") else NAVY, outline=_col(pl.get("bg"), "white"))
                if pl.get("he"): RD.T(c, pl["he"], 52, 540, yy + 100, SOFT, pa * a, 1.0, 700, maxw=900)
                St.a = old
        if b.get("source"):
            z, ls = RD.wrap(b["source"], 36, 700, 960, 2, 0.98)
            for j, l in enumerate(ls): RD.T(c, l, 36, 540, 1535 - 24 * (len(ls) - 1) + 48 * j, SOFT, a * 0.95, 1.0, 700, maxw=980, src=True)
        c.restore()

# ------------------------------------------------------------------ maps (river reel)
VIEW_REG = [26.5, 21.5, 49.5, 38.5]; VIEW_IL = [33.2, 29.3, 37.0, 33.6]
JORDAN = [(35.64, 33.20), (35.61, 32.95), (35.57, 32.71), (35.565, 32.55), (35.555, 32.35), (35.545, 32.12), (35.55, 31.92), (35.56, 31.76)]
NILE = [(31.0, 31.45), (31.05, 30.2), (31.25, 29.2), (30.8, 28.1), (31.2, 27.2), (32.7, 26.0), (32.9, 24.8), (32.9, 23.8), (31.9, 21.9)]
EUPH = [(38.3, 37.6), (38.2, 36.9), (38.0, 36.5), (39.0, 36.0), (40.1, 35.3), (41.1, 34.5), (42.2, 34.2), (43.2, 33.4), (44.4, 32.4), (45.5, 31.6), (46.6, 31.0), (47.5, 30.9)]
_M = {}
def mapbase(view):
    k = tuple(view)
    if k not in _M: _M[k] = O.base_map(view, W * 1.08, H * 1.08)
    return _M[k]

def polyline(c, M, pts, col, w, a, u=1.0, dash=None):
    if a <= 0.01 or u <= 0.001: return
    P = [M(*p) for p in pts]; n = max(2, int(math.ceil(len(P) * u)))
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for ww, cc in ((w + 10, (1, 1, 1, 0.9 * a)), (w, (col[0], col[1], col[2], a))):
        c.set_source_rgba(*cc); c.set_line_width(ww)
        if dash: c.set_dash(dash)
        c.move_to(*P[0]); [c.line_to(*p) for p in P[1:n]]; c.stroke(); c.set_dash([])

def sc_rivermap(c, t, S):
    tm = S["times"]; view = S.get("view", VIEW_IL); s, pr = mapbase(view)
    t0 = S["t0"]; t1 = S["t1"] or t0 + 6; z = 1.0 + 0.035 * ease(ramp(t, t0, t1)); k = z / 1.08
    def M(lon, lat):
        px, py = pr.P(lon, lat); return W / 2 + (px - s.get_width() / 2) * k, H / 2 + (py - s.get_height() / 2) * k
    c.save(); c.translate(W / 2, H / 2); c.scale(k, k); c.translate(-s.get_width() / 2, -s.get_height() / 2)
    c.set_source_surface(s, 0, 0); c.paint_with_alpha(St.a); c.restore()
    a0 = St.a
    sa(c, NAVY, 0.94 * a0); rr(c, 50, 250, 980, 170, 44); c.fill()
    ph = S.get("phase")
    if ph == "guess":
        RD.T(c, "Their *guesses*", 110, 540, 330, WHITE, a0, 1.0, 900, hl=YEL, maxw=980)
        for nm, pts, lab, ll, mk in (("nile", NILE, "The Nile?", (29.2, 25.2), "n"), ("euph", EUPH, "The Euphrates?", (40.6, 32.6), "e")):
            tt = tm.get(mk, t0 + 0.4); u = ease(ramp(t, tt - 0.1, tt + 0.9)); aa = ramp(t, tt - 0.1, tt + 0.2) * a0
            polyline(c, M, pts, RED, 12, aa, u)
            x, y = M(*ll); O.pill_at(c, lab, 64, min(max(x, 260), 820), y, aa, bg=RED, fg=WHITE, outline=RED)
            xx = ease(ramp(t, tt + 1.0, tt + 1.3)) * aa
            if xx > 0.01:
                cx, cy = M(*pts[len(pts) // 3]); c.set_line_width(16); c.set_source_rgba(1, 1, 1, xx)
                for dx in (-1, 1): c.move_to(cx - 38, cy - 38 * dx); c.line_to(cx + 38, cy + 38 * dx)
                c.stroke()
        x, y = M(35.2, 31.6); O.pill_at(c, "Israel", 44, x + 120, y + 10, a0, bg=WHITE, fg=NAVY, outline=WHITE)
        RD.T(c, "Rivers: Natural Earth map, traced", 36, 540, 1535, NAVY, a0, 1.0, 700, maxw=960, src=True)
        return
    # answer / belgium / waist
    ta = tm.get("ans", t0 + 0.3); tj = tm.get("jor", ta + 0.4); tmed = tm.get("med", tj + 1.0)
    tbel = tm.get("be", 1e9); tw = tm.get("w", 1e9)
    fa = 1 - ramp(t, tw - 0.2, tw + 0.2); fb = fa * (1 - ramp(t, tbel - 0.2, tbel + 0.2))
    u = ease(ramp(t, tj - 0.1, tj + 0.9)); polyline(c, M, JORDAN, SKY, 13, a0, u)
    if u > 0.05:
        x, y = M(35.75, 32.4); O.pill_at(c, "Jordan River", 52, min(x + 60, 840), y - 70, ramp(t, tj, tj + 0.3) * a0 * fb, bg=SKY, fg=WHITE, outline=SKY)
    am = ramp(t, tmed - 0.05, tmed + 0.3) * a0 * fb
    if am > 0.01:
        x, y = M(34.45, 32.45); pulse = 1 + 0.08 * math.sin((t - tmed) * 4)
        c.arc(x, y, 70 * pulse, 0, 2 * math.pi); c.set_source_rgba(SKY[0], SKY[1], SKY[2], 0.35 * am); c.fill()
        O.pill_at(c, "Mediterranean Sea", 52, max(x + 40, 270), y - 120, am, bg=SKY, fg=WHITE, outline=SKY)
    title = "The *answer*" if t < tbel - 0.1 else ("Smaller than *Belgium*" if t < tw - 0.1 else "Israel's waist, before 1967")
    RD.T(c, title, 104, 540, 330, WHITE, a0, 1.0, 900, hl=YEL, maxw=980)
    ab = ramp(t, tbel - 0.05, tbel + 0.5) * a0 * fa
    if ab > 0.01:
        G = O.geo(); be = G["BE"]; ps = list(getattr(be, "geoms", [be])); ps = max(ps, key=lambda p: p.area)
        bc = be.centroid; ox, oy = 35.0 - bc.x, 31.45 - bc.y
        sh = ease(ramp(t, tbel, tbel + 0.9)); ox2 = lerp(ox + 1.6, ox, sh)
        cosr = math.cos(math.radians(bc.y)) / math.cos(math.radians(31.4))
        pts = [M(35.0 + (x - bc.x) * cosr + (ox2 - ox), y + oy) for x, y in ps.exterior.coords]
        c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.close_path()
        c.set_source_rgba(RED[0], RED[1], RED[2], 0.22 * ab); c.fill_preserve(); c.set_line_width(7); c.set_source_rgba(RED[0], RED[1], RED[2], ab); c.stroke()
        O.pill_at(c, "Belgium, to scale", 54, 540, 1250, ab, bg=RED, fg=WHITE, outline=RED)
        O.pill_at(c, "Israel, West Bank, Gaza: under 30,000 km²", 42, 540, 1350, ab, bg=WHITE, fg=NAVY, outline=WHITE)
        O.pill_at(c, "Belgium: 30,689 km²", 42, 540, 1440, ab, bg=NAVY, fg=YEL, outline=YEL)
    aw = ramp(t, tw - 0.05, tw + 0.3) * a0
    if aw > 0.01:
        uu = ease(ramp(t, tw + 0.1, tw + 1.1)); (ax, ay), (bx, by) = M(34.805, 32.2), M(34.970, 32.2); ex = lerp(ax, bx, uu)
        c.set_line_cap(cairo.LINE_CAP_ROUND)
        for ww, cc in ((24, (1, 1, 1, 0.95 * aw)), (12, (RED[0], RED[1], RED[2], aw))):
            c.set_line_width(ww); c.set_source_rgba(*cc); c.move_to(ax, ay); c.line_to(ex, ay); c.stroke()
        mx = (ax + bx) / 2; pr_ = 1 + 0.1 * math.sin((t - tw) * 4)
        c.arc(mx, ay, 70 * pr_, 0, 2 * math.pi); c.set_source_rgba(RED[0], RED[1], RED[2], 0.9 * aw); c.set_line_width(7); c.stroke()
        O.pill_at(c, f"{15 * uu:.0f} km", 96, 540, 1250, aw, bg=NAVY, fg=YEL, outline=YEL)
        th = tm.get("half", tw + 2.5); ah = ramp(t, th, th + 0.3) * aw
        O.pill_at(c, "Coast to the Green Line", 48, 540, 1355, aw, bg=WHITE, fg=NAVY, outline=WHITE)
        if ah > 0.01: O.pill_at(c, "A half marathon: 21.1 km", 56, 540, 1445, ah, bg=WHITE, fg=NAVY, outline=WHITE)
    RD.T(c, S.get("source", ""), 36, 540, 1535, NAVY, a0, 1.0, 700, maxw=980, src=True)
