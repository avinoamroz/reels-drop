"""scenes_river.py (fix batch 6, river_sea_loop_rmk1): one full-bleed map scene for "From the river to the sea. How far is it?"
Natural Earth 1:50m via ovl5.base_map: the whole land of Israel in gold, Judea/Samaria and Gaza #B8923F, Green Line green.
Widths measured on the same Natural Earth polygons (fix6 measurement, 1 Nov 2026): river to sea at its narrowest, lat 32.6,
34.918E (coast) to 35.567E (Jordan River) = 60.9 km; Israel's pre-1967 waist, lat 32.2, 34.805E to 34.970E (Green Line) = 15.6 km.
Marks: km (counter 1), mar (marathon line), waist (ruler 2), fif (counter 2), so (lead-in)."""
import sys, math, os
sys.path.append("/home/claude/fix6/lib")
import looplib; looplib.wrap(globals())
sys.path.append("/home/claude/fix6/lib")
import ovl5 as O
import cairo
import render as RD
from render import P, T, PP
from kit import ease, St, sa, rr, ramp, lerp
import kit
W, H = 1080, 1920
VIEW = [33.5, 29.4, 36.9, 34.6]
_B = {}
def base():
    if not _B:
        s, pr = O.base_map(VIEW, W * 1.06, H * 1.06); _B["s"], _B["pr"] = s, pr
    return _B["s"], _B["pr"]
JORDAN = [(35.64, 33.20), (35.61, 32.95), (35.57, 32.71), (35.565, 32.55), (35.555, 32.35), (35.545, 32.12), (35.55, 31.92), (35.56, 31.76)]
NAVY = kit.hx("#163261"); SKY = kit.hx("#45A4DD"); YEL = kit.hx("#F5C518"); WHITE = kit.hx("#FFFFFF"); RED = kit.hx("#D63A4A")

def _pill(c, txt, sz, x, y, a, bg=WHITE, fg=NAVY):
    O.pill_at(c, txt, sz, x, y, a, bg=bg, fg=fg, outline=bg)

def sc_rivermap(c, t, S):
    tm = S["times"]; T_END = S.get("t1") or 14.0
    s, pr = base(); z = 1.0 + 0.04 * min(1, t / max(1, T_END))
    k = z / 1.06
    def M(lon, lat):
        px, py = pr.P(lon, lat); return W / 2 + (px - s.get_width() / 2) * k, H / 2 + (py - s.get_height() / 2) * k
    St.a = 1.0
    c.save(); c.translate(W / 2, H / 2); c.scale(k, k); c.translate(-s.get_width() / 2, -s.get_height() / 2)
    c.set_source_surface(s, 0, 0); c.paint(); c.restore()
    # the river, always lit (frame 0 shows river and sea)
    pts = [M(*p) for p in JORDAN]
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for wdt, col in ((20, (1, 1, 1, 0.9)), (11, (SKY[0], SKY[1], SKY[2], 1))):
        c.set_source_rgba(*col); c.set_line_width(wdt); c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.stroke()
    x, y = M(35.95, 32.95); _pill(c, "THE RIVER", 46, x + 60, y, 1.0, bg=SKY, fg=WHITE)
    x, y = M(34.25, 32.95); _pill(c, "THE SEA", 46, x, y, 1.0, bg=SKY, fg=WHITE)
    # top band and hook
    g = cairo.LinearGradient(0, 330, 0, 640); g.add_color_stop_rgba(0, 1, 1, 1, 0.94); g.add_color_stop_rgba(1, 1, 1, 1, 0)
    c.rectangle(0, 0, W, 720); c.set_source(g); c.fill()
    RD.T(c, "FROM THE RIVER TO THE SEA", 44, 540, 290, kit.hx("#96702A"), 1.0, 1.0, 900, maxw=900)
    RD.T(c, "How *far* is it?", 128, 540, 420, NAVY, 1.0, 1.0 + 0.012 * math.sin(t * 2.2), 900, hl=SKY, maxw=960)
    # ruler 1: river to sea at its narrowest
    t1 = tm.get("km", 2.6); u1 = ease(ramp(t, t1 - 0.6, t1 + 0.9)); f1 = 1 - ramp(t, tm.get("waist", 8) - 0.2, tm.get("waist", 8) + 0.3)
    def ruler(lat, lon0, lon1, u, a, col, lab, val, unit_y):
        if a <= 0.01 or u <= 0.001: return
        (ax, ay), (bx, by) = M(lon0, lat), M(lon1, lat); ex = ax + (bx - ax) * u
        c.set_source_rgba(1, 1, 1, 0.95 * a); c.set_line_width(22); c.move_to(ax, ay); c.line_to(ex, ay); c.stroke()
        c.set_source_rgba(col[0], col[1], col[2], a); c.set_line_width(12); c.move_to(ax, ay); c.line_to(ex, ay); c.stroke()
        for xx in (ax, ex):
            c.set_line_width(8); c.move_to(xx, ay - 30); c.line_to(xx, ay + 30); c.stroke()
        v = val * u
        _pill(c, f"{v:,.0f} km", 96, (ax + ex) / 2, ay + 105, a, bg=NAVY, fg=YEL)
        if lab: _pill(c, lab, 40, (ax + bx) / 2, ay - 62, a)
    ruler(32.6, 34.918, 35.567, u1, f1, RED, "at the narrowest", 61, 0)
    # marathon line
    tmr = tm.get("mar", 5.0); am = ramp(t, tmr - 0.1, tmr + 0.25) * f1
    if am > 0.01:
        _pill(c, "Less than 1.5 marathons", 64, 540, 1225, am, bg=WHITE, fg=NAVY)
        _pill(c, "1 marathon = 42.2 km", 40, 540, 1320, am)
    # ruler 2: the pre-1967 waist (coast to the Green Line)
    t2 = tm.get("fif", 9.5); u2 = ease(ramp(t, t2 - 0.9, t2 + 0.25)); a2 = ramp(t, tm.get("waist", 8) - 0.1, tm.get("waist", 8) + 0.3)
    if a2 > 0.01:
        x, y = M(34.98, 32.2)
        ruler(32.2, 34.805, 34.970, u2, a2, kit.hx("#1E9E62"), None, 15, 0)
        _pill(c, "Israel's waist, before 1967", 60, 540, 1225, a2, bg=WHITE, fg=NAVY)
        _pill(c, "coast to the Green Line", 40, 540, 1320, a2)
    # labels, small
    for lon, lat, txt in ((34.85, 30.45, "ISRAEL"), (36.35, 31.5, "JORDAN"), (33.75, 30.8, "EGYPT")):
        x, y = M(lon, lat); RD.T(c, txt, 44, x, y, NAVY, 0.9, 1.0, 900, maxw=400)
    x, y = M(35.3, 31.75); RD.T(c, "West Bank", 38, x + 20, y, NAVY, 0.85, 1.0, 800, maxw=300)
    x, y = M(34.33, 31.42); RD.T(c, "Gaza", 38, x - 50, y, NAVY, 0.85, 1.0, 800, maxw=200)
    RD.T(c, "Map: Natural Earth. Widths measured on its borders.", 36, 600, 1592, NAVY, 0.9, 1.0, 700, maxw=960)
