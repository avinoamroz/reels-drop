# shared map geometry and CTA lines (from /home/claude/vid/cfg_pop.py MAP)
import runpy
P1=runpy.run_path("/home/claude/vid/cfg_pop.py")
OUTLINE=P1["MAP"]["outline"]; DASHED=P1["MAP"]["dashed"]
WB=DASHED[0]+[(35.58,31.40),(35.55,31.76),(35.52,32.00),(35.55,32.40)]
GAZA=DASHED[1]+[(34.22,31.32),(34.35,31.45),(34.49,31.60)]
GOLD="#ffd166"; ACC="#7dd3fc"; SUBC="#9aa4bf"
def end_lines(balance_en,balance_he,next_en,next_he,y0=0.675):
    if isinstance(balance_en,(list,tuple)):
        y0=0.69
        return [(y0,balance_en[0],"white",26),(y0-0.026,balance_en[1],"white",24),(y0-0.058,balance_he[0],SUBC,23),(y0-0.084,balance_he[1],SUBC,23),
                (y0-0.135,"Comment HISTORY for the sources",GOLD,34),(y0-0.168,"כתבו HISTORY בתגובות ואשלח לכם את המקורות",GOLD,26),
                (y0-0.222,next_en,ACC,36),(y0-0.257,next_he,ACC,32)]
    return [(y0,balance_en,"white",26),(y0-0.03,balance_he,SUBC,25),
            (y0-0.088,"Comment HISTORY for the sources",GOLD,34),(y0-0.124,"כתבו HISTORY בתגובות ואשלח לכם את המקורות",GOLD,26),
            (y0-0.185,next_en,ACC,36),(y0-0.222,next_he,ACC,32)]
END_BOX2=(0.05,0.41,0.90,0.315)
