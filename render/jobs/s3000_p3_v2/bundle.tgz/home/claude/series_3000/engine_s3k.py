"""3,000 years series engine (Part 1b, 2, 3). Derived from /home/claude/vid/engine.py (the pop_race_v4 look).
usage: nice -n 10 python3 engine_s3k.py cfg.py            -> silent mp4 at C["OUT"]
       SNAPS=0,1.5,20 SD=dir nice -n 10 python3 engine_s3k.py cfg.py   -> stills only
Adds: Part chip, configurable hook (duration, dim), gold land map (#B8923F) with the Green Line in green from
GREEN_FROM, ruler banner + map outline colour (Part 2), gaps / intro / share labels (Part 3), timed overlay cards."""
import sys, os, runpy, numpy as np, matplotlib, subprocess
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch as FB, Rectangle as RX, Polygon as PG
from matplotlib.path import Path
matplotlib.rcParams["font.family"]=["Inter","Liberation Sans","DejaVu Sans"]
C=runpy.run_path(sys.argv[1])
BG="#0b1020"; GRID="#1e2740"; ACC="#7dd3fc"; TICK="#5c6680"; FG="white"; GOLD="#ffd166"; SUBC="#9aa4bf"; DISCC="#7a84a0"
LAND="#B8923F"; LAND2="#CFAE66"; GREEN="#22c55e"
G=C["G"]; EVENTS=C["EVENTS"]; TL=C["TL"]; ROWS=C.get("ROWS",7); HOLD=C.get("HOLD",5)
W,H,FPS=1080,1920,30
ty=[t for _,t in TL]; yy=[y for y,_ in TL]; T_END=TL[-1][1]+HOLD; N=int(round(T_END*FPS))
SNAPS=[int(round(float(x)*FPS)) for x in os.environ["SNAPS"].split(",")] if os.environ.get("SNAPS") else None
def val(pts,y):
    if y<pts[0][0]: return 0.0
    if y>pts[-1][0]: return float(pts[-1][1])
    return float(np.interp(y,[p[0] for p in pts],[p[1] for p in pts]))
def fmt_year(y):
    y=int(round(y)); return f"{-y} BCE" if y<0 else (f"{y} CE" if y<1000 else str(y))
def fmt_n(v):
    if C.get("FMT")=="years": return f"{int(round(v))}"
    if v<1000: return f"{int(round(v)):,}"
    return f"{v/1e6:.2f}M" if v>=1e6 else f"{int(round(v,-3 if v>=10000 else -2)):,}"
def in_gap(y): return any(a<y<b for a,b in C.get("GAPS",[]))
def AX(r):
    x,y,w,h=r; k=(0.748-0.43)/0.51
    return [0.03+x*0.85, 0.43+(y-0.32)*k, w*0.85, h*k]
L=C.get("LAYOUT",{})
Y_PART=L.get("part",0.866); Y_TEN=L.get("t_en",0.830); Y_THE=L.get("t_he",0.799); Y_SUB=L.get("sub",0.776)
Y_CLAB=L.get("clab",0.392); Y_CVAL=L.get("cval",0.352); Y_YEAR=L.get("year",0.355); Y_ERA=L.get("era",0.333)
Y_EV1=L.get("ev1",0.298); Y_EV2=L.get("ev2",0.273); Y_DISC=L.get("disc",0.247)
names=list(G); pos={n:None for n in names}
M=C.get("MAP")
DOTS=None
if M and M.get("mode")=="dots":
    poly=Path(np.array(M["outline"])); DOT=M["dot"]; DOTS={}
    for gi,n in enumerate(names):
        if n not in M["coords"]: continue
        P=int(max(p[1] for p in G[n][2])/DOT)+3; arrs=[]
        for ki,(yr,lo,la,sx,sy) in enumerate(M["coords"][n]):
            rng=np.random.default_rng(gi*100+ki); pts=[]
            while len(pts)<P:
                q=rng.normal([lo,la],[sx,sy],size=(P*3,2)); q=q[poly.contains_points(q)]; pts.extend(q.tolist())
            arrs.append(np.array(pts[:P]))
        DOTS[n]=([k[0] for k in M["coords"][n]],arrs)
def cur_ruler(year):
    r=[x for x in C.get("RULERS",[]) if x[0]<=year]
    return r[-1] if r else None
def draw_lines(lines,a,z=52):
    for ln in lines:
        yy_,tx,cc,fz=ln[:4]; wt=ln[4] if len(ln)>4 else "bold"
        fig.text(0.5,yy_,tx,ha="center",va="center",color=cc,fontsize=fz,fontweight=wt,alpha=a,zorder=z)
fig=plt.figure(figsize=(W/100,H/100),dpi=100)
ff=None if SNAPS else subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgba","-s",f"{W}x{H}","-r",str(FPS),"-i","-",
 "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-preset","medium",C["OUT"]],stdin=subprocess.PIPE)
RACE_Y0=C.get("RACE_YEAR0",-99999)
fs=C.get("FS",22 if ROWS<=7 else 18)
for f in range(N):
    t=f/FPS; year=float(np.interp(min(t,TL[-1][1]),ty,yy)); race=year>=RACE_Y0
    vals={n:val(G[n][2],year) for n in names}
    alive=[n for n in names if vals[n]>=C.get("MIN",1)] if race else []
    ranked=sorted(alive,key=lambda n:(-vals[n],names.index(n)))[:ROWS]
    for i,n in enumerate(ranked): pos[n]=i if pos[n] is None else pos[n]+(i-pos[n])*0.15
    for n in names:
        if n not in ranked: pos[n]=None
    if SNAPS and f not in SNAPS: continue
    fig.clf(); fig.patch.set_facecolor(BG)
    # header + part chip
    if C.get("PART"):
        pe,ph=C["PART"]
        fig.patches.append(FB((0.36,Y_PART-0.0115),0.28,0.023,boxstyle="round,pad=0.003,rounding_size=0.011",transform=fig.transFigure,facecolor="#16223f",edgecolor=GOLD,lw=2))
        fig.text(0.5,Y_PART,f"{pe}  |  {ph}",ha="center",va="center",color=GOLD,fontsize=20,fontweight="bold")
    fig.text(0.5,Y_TEN,C["T_EN"],ha="center",color=FG,fontsize=C.get("T_FS",46)-6,fontweight="bold")
    fig.text(0.5,Y_THE,C["T_HE"],ha="center",color=GOLD,fontsize=C.get("T_FS",46)-9,fontweight="bold")
    fig.text(0.5,Y_SUB,C["SUB"],ha="center",color=SUBC,fontsize=19)
    # bars
    ax=fig.add_axes(AX(C.get("BAR_AX",[0.05,0.33,0.58,0.50]))); ax.set_facecolor(BG)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_yticks([])
    if race and ranked:
        mx=max([vals[n] for n in ranked]+[C.get("FLOOR",5000)]); xmax=mx*C.get("XMAXF",1.5)
        ax.set_xlim(0,xmax); ax.set_ylim(ROWS-0.4,-0.6)
        ax.xaxis.tick_top(); ax.tick_params(axis="x",colors=TICK,labelsize=17,length=0)
        if C.get("FMT")=="years": ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v,p:f"{int(v)}"))
        else: ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v,p:(f"{v/1e6:g}M" if v>=1e6 else (f"{int(v/1000)}k" if v>=1000 else str(int(v))))))
        ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(4)); ax.grid(axis="x",color=GRID,lw=1.5); ax.set_axisbelow(True)
        gap=in_gap(year); tot=sum(vals.values()); cr=cur_ruler(year)
        for n in ranked:
            v=vals[n]; p=pos[n]; heb,c,_=G[n][:3]; star=" ★" if n in C.get("STARS",[]) else ""
            lab=f"{C.get('EN',{}).get(n,n)}{star}  {heb}"
            now=cr is not None and n in cr[1]
            ax.barh(p,v,height=0.78,color=c,alpha=0.30 if gap else 1.0,edgecolor=("white" if now else "none"),lw=(2.5 if now else 0))
            num="?" if gap else (fmt_n(v)+(f"  ({v/tot*100:.0f}%)" if C.get("SHARE") and tot>0 else ""))
            if C.get("ONELINE"):
                t1=ax.text(v+xmax*0.012,p,f"{C.get('EN',{}).get(n,n)}{star}",va="center",ha="left",color=c,fontsize=fs,fontweight="bold")
                t2=ax.annotate(num,xy=(1,0.5),xycoords=t1,xytext=(7,0),textcoords="offset points",va="center",ha="left",color=FG,fontsize=fs,fontweight="bold")
                ax.annotate(heb,xy=(1,0.5),xycoords=t2,xytext=(9,0),textcoords="offset points",va="center",ha="left",color=c,fontsize=fs,fontweight="bold")
                continue
            if v>xmax*0.5:
                ax.text(xmax*0.012,p,lab,va="center",ha="left",color=BG,fontsize=fs,fontweight="bold")
                ax.text(v+xmax*0.015,p,num,va="center",ha="left",color=FG,fontsize=fs+1,fontweight="bold")
            else:
                ax.text(v+xmax*0.015,p-0.07,lab,va="center",ha="left",color=c,fontsize=fs,fontweight="bold")
                ax.text(v+xmax*0.015,p+0.3,num,va="center",ha="left",color=FG,fontsize=fs-4)
    else:
        ax.set_xlim(0,1); ax.set_ylim(0,1); ax.set_xticks([])
    if not race and C.get("INTRO"):
        I=C["INTRO"]; est=[e for e in C.get("ANCIENT_EST",[]) if e[0]<=year<e[1]]
        bx=AX(C.get("BAR_AX"))
        fig.patches.append(FB((bx[0]+0.01,bx[1]+0.04),bx[2]-0.02,bx[3]-0.08,boxstyle="round,pad=0.01,rounding_size=0.025",transform=fig.transFigure,facecolor="#121a33",edgecolor=GRID,lw=2))
        cx=bx[0]+bx[2]/2; cy=bx[1]+bx[3]/2
        lines=[I[0],I[1]]+(list(est[0][2:]) if est else list(I[2:]))
        for i,l in enumerate(lines):
            fig.text(cx,cy+0.09-0.036*i,l,ha="center",va="center",color=(ACC if i==0 else GOLD if i==1 else (FG if i%2==0 else SUBC)),fontsize=(28 if i<2 else 21),fontweight="bold")
    # map
    if M:
        mx2=fig.add_axes(AX(M["ax"])); mx2.set_facecolor(BG); mx2.set_aspect(1/np.cos(np.radians(31.5)))
        o=np.array(M["outline"]); green=year>=C.get("GREEN_FROM",99999)
        cr=cur_ruler(year); edge=G[cr[1][0]][1] if (cr and M.get("ruler_edge")) else LAND
        mx2.fill(o[:,0],o[:,1],color=LAND,alpha=M.get("land_alpha",1.0),lw=0,zorder=1)
        if green:
            for pg in (M["wb"],M["gaza"]):
                pg=np.array(pg); mx2.fill(pg[:,0],pg[:,1],color=LAND2,alpha=M.get("land_alpha",1.0),lw=0,zorder=1.5)
            for d in M["dashed"]:
                d=np.array(d); mx2.plot(d[:,0],d[:,1],color=GREEN,lw=2.6,zorder=4)
        mx2.plot(o[:,0],o[:,1],color=edge,lw=(4 if M.get("ruler_edge") else 2),zorder=2)
        if DOTS is not None:
            allp=[]; allc=[]
            for n in names:
                if n not in DOTS: continue
                v=vals[n]; cnt=0 if v<C.get("MIN",1) else max(1,int(round(v/M["dot"])))
                if cnt==0: continue
                yrs,arrs=DOTS[n]
                if year<=yrs[0] or len(yrs)==1: A=arrs[0]
                elif year>=yrs[-1]: A=arrs[-1]
                else:
                    j=max(i for i in range(len(yrs)) if yrs[i]<=year); fr_=(year-yrs[j])/(yrs[j+1]-yrs[j]); A=arrs[j]*(1-fr_)+arrs[j+1]*fr_
                A=A[:cnt]; allp.append(A); allc+=[G[n][1]]*len(A)
            if allp:
                P_=np.vstack(allp); order=np.random.default_rng(1).permutation(len(P_)); cs=np.array(allc)[order]
                mx2.scatter(P_[order,0],P_[order,1],s=M.get("ds",7),c=cs,alpha=0.95,linewidths=0,zorder=3)
            mx2.text(0.98,0.02,M["legend"],transform=mx2.transAxes,ha="right",va="bottom",color=SUBC,fontsize=16)
        for (y0,y1,lo,la,txt,cc,fz) in M.get("labels",[]):
            if y0<=year<y1: mx2.text(lo,la,txt,ha="center",va="center",color=cc,fontsize=fz,fontweight="bold",zorder=6)
        if M.get("pin"):
            lo,la,txt=M["pin"]; pulse=0.5+0.5*np.sin(t*4)
            mx2.scatter([lo],[la],s=900+500*pulse,color="#ef4444",alpha=0.25,lw=0,zorder=7)
            mx2.scatter([lo],[la],s=170,color="#ef4444",edgecolors="white",linewidths=2.5,zorder=8)
            mx2.text(lo-0.09,la+0.06,txt,ha="right",va="bottom",color=FG,fontsize=20,fontweight="bold",zorder=8)
        mx2.set_xlim(*M["xlim"]); mx2.set_ylim(*M["ylim"]); mx2.axis("off")
    # ruler banner (Part 2)
    cr=cur_ruler(year)
    if cr:
        _,keys,be,bh,fe,fh=cr; col=G[keys[0]][1]
        yb=L.get("banner",0.405)
        fig.patches.append(FB((0.05,yb-0.019),0.90,0.038,boxstyle="round,pad=0.004,rounding_size=0.012",transform=fig.transFigure,facecolor="#121a33",edgecolor=col,lw=3))
        fig.text(0.07,yb+0.0075,be,ha="left",va="center",color=col,fontsize=19,fontweight="bold")
        fig.text(0.07,yb-0.0095,fe,ha="left",va="center",color=FG,fontsize=15.5,fontweight="bold")
        fig.text(0.93,yb+0.0075,bh,ha="right",va="center",color=col,fontsize=19,fontweight="bold")
        fig.text(0.93,yb-0.0095,fh,ha="right",va="center",color=FG,fontsize=15.5,fontweight="bold")
    # callouts
    for (y0,y1,ce,ch) in C.get("CALLOUTS",[]):
        if race and y0<=year<=y1:
            yc=L.get("callout",0.405)
            fig.patches.append(FB((0.05,yc-0.019),0.90,0.038,boxstyle="round,pad=0.004,rounding_size=0.012",transform=fig.transFigure,facecolor="#0f172a",edgecolor=ACC,lw=2,alpha=0.96))
            fig.text(0.5,yc+0.008,ce,ha="center",va="center",color=ACC,fontsize=17,fontweight="bold")
            fig.text(0.5,yc-0.010,ch,ha="center",va="center",color=FG,fontsize=17,fontweight="bold"); break
    # year + counter
    fig.text(0.92,Y_YEAR,fmt_year(year),ha="right",color=FG,fontsize=(54 if year<0 else 64),fontweight="bold",alpha=0.92)
    fig.text(0.92,Y_ERA,"לפני הספירה" if year<0 else "לספירה",ha="right",color=GOLD,fontsize=28,fontweight="bold")
    if C.get("COUNTER"):
        le,lh,kind=C["COUNTER"]
        if kind=="sum": cv="?" if in_gap(year) or not race else f"{int(round(sum(vals.values()),-3 if sum(vals.values())>=10000 else -2)):,}"
        else: cv=str(len([n for n in names if vals[n]>0]))
        fig.text(0.07,Y_CLAB,le+"  |  "+lh,ha="left",color=SUBC,fontsize=19,fontweight="bold")
        fig.text(0.07,Y_CVAL,cv,ha="left",color=ACC,fontsize=42,fontweight="bold")
    ev=[e for e in EVENTS if e[0]<=year]
    if ev:
        fig.text(0.5,Y_EV1,ev[-1][1],ha="center",color=GOLD,fontsize=C.get("EV_FS",24),fontweight="bold")
        fig.text(0.5,Y_EV2,ev[-1][2],ha="center",color=FG,fontsize=C.get("EV_FS",24),fontweight="bold")
    for i,l in enumerate(C["DISC"]): fig.text(0.5,Y_DISC-0.0125*i,l,ha="center",color=DISCC,fontsize=C.get("DISC_FS",13.5))
    # timed cards (payoff, end card)
    for cd in C.get("CARDS",[]):
        if cd["t0"]<=t<cd.get("t1",1e9):
            a=min(1,(t-cd["t0"])/0.3)
            if cd.get("dim"): fig.patches.append(RX((0,0),1,1,transform=fig.transFigure,color="#050914",alpha=cd["dim"]*a,zorder=49))
            x,y,w,h=cd["box"]
            fig.patches.append(FB((x,y),w,h,boxstyle="round,pad=0.01,rounding_size=0.03",transform=fig.transFigure,facecolor="#0f1a33",edgecolor=cd.get("edge",GOLD),lw=4,alpha=a,zorder=51))
            draw_lines(cd["lines"],a)
    # hook
    hk=C["HOOK"]
    if t<hk["dur"]:
        fd=hk.get("fade",0.25); a=1.0 if t<hk["dur"]-fd else min(1.0,max(0.0,(hk["dur"]-t)/fd))
        fig.patches.append(RX((0,0),1,1,transform=fig.transFigure,color="#050914",alpha=hk.get("dim",0.86)*a,zorder=50))
        x,y,w,h=hk["box"]
        fig.patches.append(FB((x,y),w,h,boxstyle="round,pad=0.01,rounding_size=0.03",transform=fig.transFigure,facecolor="#0f1a33",edgecolor=hk.get("edge",GOLD),lw=4,alpha=a,zorder=51))
        draw_lines(hk["lines"],a)
    fig.canvas.draw()
    if SNAPS: fig.savefig(os.environ["SD"]+f"/s_{t:05.2f}.png"); continue
    ff.stdin.write(fig.canvas.buffer_rgba().tobytes())
if ff: ff.stdin.close(); ff.wait()
print("done",C.get("OUT"),N/FPS)
