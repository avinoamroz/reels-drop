# 3,000 years series: facts and sources (26 Oct 2026)

Every number on screen in Parts 1b, 2 and 3, with where it comes from. Nothing invented; where sources disagree it is said on screen.

## Part 1 (re-post, s3000_p1b): "Who was here first? Watch 3,000 years."

Data is unchanged from the posted winner (pop_race_v4, https://www.instagram.com/reel/Dei8qQKkQCC/), config /home/claude/vid/cfg_pop.py.
- Population by religious community, 1200 BCE to 2026, land between the Jordan and the sea incl. West Bank and Gaza. Ancient values are rounded scholarly estimates with wide ranges.
- 2026 end values on screen: Jews 7.60M, Muslims 6.90M, Others 250k, Christians 230k, Druze 155k, Samaritans about 900; total 15.1M.
- Sources (as on the original caption): Magen Broshi (ancient population estimates); Sergio DellaPergola (Jewish demography); Justin McCarthy, The Population of Palestine (Ottoman era); British Mandate censuses 1922 and 1931; Israel Central Bureau of Statistics; Palestinian Central Bureau of Statistics.
- Event captions (Merneptah Stele 1208 BCE, 586 BCE, 70 CE, 135, 638, 1099, 1517, 1882, 1917, 1948 incl. "about 700k Arabs flee or are expelled", 1950, 1967, 1990): standard dates, as in the original.
- New in this cut: hook card (2 s), Part 1 chip, land in gold, Green Line in green from 1949, end card (fair balance line, Comment HISTORY, Part 2 on my profile).

## Part 2 (s3000_p2): "3,000 years. Who RULED this land?"

Bar = years each power ruled all or part of the land. Periods overlap (vassal kingdoms, the Crusader coast). Years counted astronomically (no year zero). Dates rounded, mainstream textbook dates.

| Ruler | Period on screen | Years | Ruled from | Notes |
|---|---|---|---|---|
| Israelite kingdoms (United Monarchy, then Israel and Judah) ★ | c. 1000 to 586 BCE | 414 | Jerusalem, Samaria | United Monarchy dating is debated (Finkelstein); Israel fell 722 BCE; Judah was a vassal of Assyria (c. 732 to 630) and Babylon (604 to 586) |
| Assyria | c. 732 to c. 630 BCE | 102 | Nineveh | Tiglath-pileser III annexes Galilee 732; Assyrian grip fades in the 630s to 620s |
| Babylon | 604 to 539 BCE | 65 | Babylon | after Carchemish (605); brief Egyptian control 609 to 605 left out |
| Persia (Achaemenid, plus Sasanian 614 to 628 CE) | 539 to 332 BCE; 614 to 628 CE | 221 | Persepolis/Susa; Ctesiphon | Sasanian interlude folded into the same bar |
| Greeks (Alexander, Ptolemies, Seleucids) | 332 to 140 BCE | 192 | Alexandria, then Antioch | |
| Hasmoneans ★ | 140 to 63 BCE | 77 | Jerusalem | independence dated 142 or 140 BCE (Simon); ends with Pompey 63 BCE |
| Rome (incl. Herodian client kings) | 63 BCE to 395 CE | 457 | Rome | 395 = split of the empire (convention) |
| Byzantium | 395 to 614, 628 to 636 | 227 | Constantinople | |
| Muslim caliphates and dynasties (Rashidun, Umayyad, Abbasid, Tulunid, Ikhshidid, Fatimid; Seljuks 1073 to 1098) | 636 to 1099 | 463 | Medina, Damascus, Baghdad, Cairo | |
| Crusaders ★ (Kingdom of Jerusalem) | 1099 to 1291 | 192 | Jerusalem, later Acre | settlers from Europe; Jerusalem itself held 1099 to 1187 and 1229 to 1244 |
| Ayyubids | 1187 to 1260 | 73 | Cairo, Damascus | |
| Mamluks | 1260 to 1516 | 256 | Cairo | |
| Ottomans | 1516 to 1917 | 401 | Istanbul | Egyptian occupation 1831 to 1840 not split out |
| Britain | 1917 to 1948 | 31 | London | military rule 1917 to 1920, Mandate after |
| Jordan (West Bank) and Egypt (Gaza) | 1948 to 1967 | 19 | Amman, Cairo | |
| Israel ★ | 1948 to 2026 | 78 | Jerusalem | West Bank and Gaza from 1967; Gaza left 2005; PA self-rule areas since 1994; Hamas in Gaza since 2007 |

Punch line, phrased as a checkable definition: "Independent states that ruled this land from inside it, in 3,000 years: 4. Israelite kingdoms, Hasmoneans, Israel. 3 of the 4 were Jewish. The 4th: Crusaders, settlers from Europe. Every other ruler governed it from abroad."
- Fairness caveats shown on screen: small city states (Philistine, Phoenician) and autonomous local rulers (Zahir al-Umar, Galilee, c. 1730s to 1775, nominally Ottoman) held parts of the land. Not counted as independent states ruling the land.
- Not counted: Palestinian Authority (self-rule in parts since 1994, not a sovereign state in control), Hamas in Gaza (de facto since 2007); both shown as event captions.
- Opinion in the caption is marked "In my view".
- Fair balance line: "Who ruled is not who lived here. Arabs have lived here for 1,300+ years." (Muslim conquest 636; Arab presence in the Negev and south is older, so "1,300+" is conservative.)
- Sources: Encyclopaedia Britannica (Palestine; Israel and Judah; Hasmonean dynasty; Mamluk; Ottoman Empire; Zahir al-Umar); Oxford History of the Biblical World (Coogan, ed.); Cambridge History of Judaism; Encyclopaedia of Islam; Finkelstein and Silberman, The Bible Unearthed; Wikipedia, Hasmonean dynasty (https://en.wikipedia.org/wiki/Hasmonean_dynasty), Zahir al-Umar's revolt (https://en.wikipedia.org/wiki/Zahir_al_Umar%27s_revolt).

## Part 3 (s3000_p3): "3,000 years. Who lived in JERUSALEM?"

Residents by religious community, city limits of each era. No counts by group survive before 1525, so the race starts then. Compiled in Wikipedia, Demographic history of Jerusalem (https://en.wikipedia.org/wiki/Demographic_history_of_Jerusalem), checked 26 Oct 2026, and the earlier build /home/claude/vid/cfg_pop_jlm.py.

| Year | Jews | Muslims | Christians | Source |
|---|---|---|---|---|
| 1525 | 1,194 | 3,704 | 714 | Ottoman tax registers (Cohen and Lewis) |
| 1538 | 1,363 | 7,287 | 884 | Ottoman tax registers |
| 1553 | 1,958 | 12,154 | 1,956 | Ottoman tax registers (Muslims 76%: "3 in 4") |
| about 1560 to 1800 | no reliable counts (shown as "?", faded bars) | | | |
| 1806 | 2,000 | 4,000 | 2,774 | Seetzen (total 8,774: "under 9,000") |
| 1838 | 3,000 | 4,500 | 3,500 | Robinson |
| 1844 | 7,120 | 5,000 | 3,390 | Schultz |
| 1864 | 8,000 | 4,500 | 2,500 | British consulate |
| 1874 | 10,000 | 5,000 | 5,500 | British consul |
| 1896 | 28,112 | 8,560 | 8,748 | Calendar of Palestine |
| 1922 | 33,971 | 13,413 | 14,699 | British census |
| 1931 | 51,222 | 19,894 | 19,335 | British census |
| 1944 | 97,000 | 30,600 | 29,400 | Survey of Palestine (official estimate) |
| 1967 | 195,700 | 54,963 | 12,646 | Israel CBS 1967 census (Harrel) |
| 1990 | 378,200 | 131,800 | 14,400 | Jerusalem Municipality |
| 2011 | 497,000 | 281,000 | 14,000 | Israel CBS |
| 2020 | 570,100 | 353,800 | 16,300 | Jerusalem Institute for Policy Research |

- "Jews the largest group since about the 1860s, in most counts": in the 1860s Jews lead in most estimates (1862, 1864, 1866, 1869 x2); the 1840s and 1870s are contested (1872 Ottoman salname, Ottoman subjects only, shows Muslims ahead; foreign Jews were not counted). From the 1880s every listed count has Jews first. On screen: "Counts disagree, 1840s to 1870s. Ottoman registers left out foreign Jews."
- End of 2024: over 1,050,200 residents; Jews and others 596,400 (60%), Arabs 401,400 (40%); the remaining about 52,000 are not classified in either (Jerusalem Statistical Yearbook, JIPR, via Israel Hayom / Yeshiva World, May 2026: https://www.theyeshivaworld.com/news/israel-news/2547517/jerusalem-has-over-1-million-residents-how-many-are-jewish-the-capital-in-numbers.html).
- First Aliyah 1882; Israel 1948; city divided 1948 to 1967; limits expanded 1967.
- Fair balance line: "Today: 60% Jews and others, 40% Arabs. A city that is home to both." plus "Fair to say: in 1553, 3 in 4 residents were Muslim."
- Left out on purpose: 1948 figures (no solid single source), the 2024 split by religion (only the Jews and others / Arabs split is published in the source I could check), ancient estimates (70 CE: 20,000 Geva to 80,000 Broshi) to keep the intro readable.
