#!/bin/bash
# s3000_p3_v2: no Part chip, no Comment HISTORY / Follow; last card ends on the hook question
set -e; cd /home/claude/series_3000
python3 engine_s3k.py cfg_p3_v2.py > render_p3v2.log 2>&1
ffmpeg -y -v error -i p3v2_silent.mp4 -i p3v2_mus.m4a -map 0:v -map 1:a -c:v copy -c:a copy -shortest -movflags +faststart s3000_p3_v2.mp4
