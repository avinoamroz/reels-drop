import json
for pid,cap in [("s3000_p1b","p1b"),("s3000_p2","p2"),("s3000_p3","p3")]:
    caption=open(f"/home/claude/series_3000/captions/{cap}.txt",encoding="utf-8").read().strip()
    body={"media_type":"REELS","video_url":f"https://raw.githubusercontent.com/avinoamroz/reels-drop/main/{pid}.mp4","caption":caption,
          "share_to_feed":True,"is_ai_generated":True,"trial_params":{"graduation_strategy":"MANUAL"}}
    d={"action":"init","account":"noam","tag":f"{pid}-gh","body":json.dumps(body,ensure_ascii=False)}
    json.dump(d,open(f"/home/claude/posting/queue/gh/{pid}.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
    print(pid,len(caption),caption.count("#"))
