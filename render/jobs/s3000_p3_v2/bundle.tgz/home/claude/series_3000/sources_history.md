# HISTORY: the sources behind "3,000 years" (Parts 1, 2, 3)

Thanks for asking! Here is where every number comes from. 📚
תודה ששאלתם! הנה המקורות לכל המספרים בסדרה.

## Part 1: Who lived in this land?
Population by community, 1200 BCE to today, between the Jordan and the sea (incl. West Bank and Gaza). Ancient figures are scholarly estimates with wide ranges.
- Magen Broshi, ancient population estimates of the land
- Sergio DellaPergola, Jewish demography (Hebrew University)
- Justin McCarthy, The Population of Palestine (Ottoman and Mandate records)
- British Mandate censuses, 1922 and 1931
- Israel Central Bureau of Statistics; Palestinian Central Bureau of Statistics

## Part 2: Who ruled this land?
Years each power ruled all or part of the land (periods overlap, dates rounded, early monarchy dates debated).
- Encyclopaedia Britannica: Palestine; Israel and Judah; Hasmonean dynasty; Mamluk; Ottoman Empire; Zahir al-Umar
- Michael Coogan (ed.), The Oxford History of the Biblical World
- The Cambridge History of Judaism
- Encyclopaedia of Islam (caliphates, Ayyubids, Mamluks)
- Israel Finkelstein and Neil Asher Silberman, The Bible Unearthed (on the early monarchy debate)
- "Ruled from inside the land, as an independent state": Israelite kingdoms, Hasmoneans, the Crusader kingdom (settlers from Europe) and Israel. City states and local rulers (e.g. Zahir al-Umar, 1700s) held parts of the land.

## Part 3: Who lived in Jerusalem?
- Ottoman tax registers 1525 to 1553: Amnon Cohen and Bernard Lewis, Population and Revenue in the Towns of Palestine in the Sixteenth Century
- Travellers: Seetzen 1806, Robinson 1838, Schultz 1844; British consular reports 1864 and 1874; Calendar of Palestine 1896
- British censuses 1922 and 1931; Survey of Palestine (1944 estimate)
- Israel CBS (1967 census, 2011); Jerusalem Municipality (1990)
- Jerusalem Institute for Policy Research, Jerusalem Statistical Yearbook (2020; end of 2024: 1,050,200 residents, 60% Jews and others, 40% Arabs)
- Overview of all counts: Wikipedia, Demographic history of Jerusalem
- Note: counts in the 1840s to 1870s disagree (Ottoman registers left out foreign Jews); from the 1860s most counts show Jews as the largest group.

Which part surprised you the most? 👇
איזה חלק הכי הפתיע אתכם?
