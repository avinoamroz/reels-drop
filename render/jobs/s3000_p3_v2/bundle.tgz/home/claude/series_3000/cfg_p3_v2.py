import sys; sys.path.insert(0,"/home/claude/series_3000")
from common import *
OUT="/home/claude/series_3000/p3v2_silent.mp4"
PART=None
T_EN="3,000 years. Who lived in JERUSALEM?"; T_HE="3,000 שנה. מי חי בירושלים?"; T_FS=41
SUB="Residents by community, city limits of each era  |  תושבים לפי קהילה"
Y=[1525,1538,1553,1806,1838,1844,1864,1874,1896,1922,1931,1944,1967,1990,2011,2020]
J=[1194,1363,1958,2000,3000,7120,8000,10000,28112,33971,51222,97000,195700,378200,497000,570100]
Mu=[3704,7287,12154,4000,4500,5000,4500,5000,8560,13413,19894,30600,54963,131800,281000,353800]
Ch=[714,884,1956,2774,3500,3390,2500,5500,8748,14699,19335,29400,12646,14400,14000,16300]
G={"Jews":("יהודים","#3b82f6",list(zip(Y,J))),"Muslims":("מוסלמים","#10b981",list(zip(Y,Mu))),"Christians":("נוצרים","#a855f7",list(zip(Y,Ch)))}
ROWS=3; MIN=1; FLOOR=2000; XMAXF=2.1; SHARE=True; FS=25
BAR_AX=[0.05,0.33,0.60,0.50]
RACE_YEAR0=1525; GAPS=[(1553,1806)]
COUNTER=("Residents (3 groups)","תושבים (3 הקבוצות)","sum")
LAYOUT={"callout":0.405,"clab":0.372,"cval":0.334,"year":0.336,"era":0.316,"ev1":0.281,"ev2":0.257,"disc":0.236}
INTRO=("Ancient Jerusalem","ירושלים העתיקה","No headcounts by group survive.","לא שרדו ספירות לפי קבוצות.","Real counts start in 1525.","ספירות אמיתיות מתחילות ב-1525.")
EVENTS=[(-1000,"King David makes it his capital (by tradition)","דוד המלך הופך אותה לבירתו (לפי המסורת)"),
 (-586,"Babylon destroys the First Temple","בבל מחריבה את בית המקדש הראשון"),
 (70,"Rome destroys the Second Temple","רומא מחריבה את בית המקדש השני"),
 (638,"The Muslim conquest","הכיבוש המוסלמי"),
 (1099,"The Crusaders take the city","הצלבנים כובשים את העיר"),
 (1187,"Saladin takes the city","צלאח א-דין כובש את העיר"),
 (1517,"Ottoman rule begins","תחילת השלטון העות'מאני"),
 (1525,"Ottoman tax records: the first real counts","רישומי המס העות'מאניים: הספירה האמיתית הראשונה"),
 (1538,"Suleiman builds the Old City walls","סולימאן בונה את חומות העיר העתיקה"),
 (1554,"About 1560 to 1800: no reliable counts","בערך 1560 עד 1800: אין ספירות אמינות"),
 (1806,"1806: a traveller counts under 9,000 residents","1806: נוסע סופר פחות מ-9,000 תושבים"),
 (1838,"1838 to 1846: travellers' counts","1838 עד 1846: ספירות של נוסעים"),
 (1860,"1860s: Jews are the largest group in most counts","שנות ה-60: היהודים הקבוצה הגדולה ברוב הספירות"),
 (1882,"The First Aliyah begins","העלייה הראשונה מתחילה"),
 (1917,"British rule begins","תחילת השלטון הבריטי"),
 (1922,"British census","מפקד האוכלוסין הבריטי"),
 (1948,"War: the city is divided, west and east","מלחמה: העיר מחולקת למערב ולמזרח"),
 (1967,"Six-Day War: one city, wider limits","מלחמת ששת הימים: עיר אחת, גבולות רחבים יותר"),
 (1990,"Immigration from the former USSR","עלייה מברית המועצות לשעבר"),
 (2020,"End of 2024: over 1,050,000 residents","סוף 2024: יותר מ-1,050,000 תושבים")]
CALLOUTS=[(1554,1805,"No reliable counts for 250 years: bars are a bridge, not data","אין ספירות אמינות במשך 250 שנה: הקטע הזה הוא גשר, לא נתונים"),
 (1838,1880,"Counts disagree, 1840s to 1870s. Ottoman registers left out foreign Jews","הספירות חלוקות בשנות ה-40 עד ה-70. הרישום העות'מאני לא כלל יהודים זרים"),
 (1946,1966,"1948 to 1967: Israel holds the west, Jordan the east","1948 עד 1967: ישראל במערב העיר, ירדן במזרחה"),
 (1967,1985,"1967: city limits expanded, adding East Jerusalem and nearby villages","1967: גבולות העיר הורחבו וכוללים את מזרח העיר וכפרים סמוכים"),
 (2011,2020,"2020: Jewish count incl. some with no religion listed","2020: היהודים כוללים חלק ממי שללא סיווג דת")]
TL=[(-1000,0.0),(-586,0.9),(70,1.8),(638,2.7),(1099,3.4),(1187,3.9),(1517,4.6),(1525,5.4),(1553,8.0),(1806,10.5),(1838,12.0),(1844,13.0),(1864,15.5),(1874,17.0),(1896,19.5),(1922,22.0),(1931,23.2),(1944,24.8),(1967,28.0),(1990,31.0),(2011,33.5),(2020,35.5)]
HOLD=12.0
GREEN_FROM=1949
MAP={"ax":[0.64,0.34,0.38,0.49],"xlim":(34.15,35.95),"ylim":(29.45,33.35),"outline":OUTLINE,"dashed":DASHED,"wb":WB,"gaza":GAZA,"pin":(35.21,31.78,"Jerusalem")}
DISC=["Sources: Ottoman tax registers (Cohen and Lewis); Seetzen 1806; Robinson 1838; Schultz 1844;",
      "British consular reports 1864, 1874; Calendar of Palestine 1896; British censuses 1922, 1931;",
      "Survey of Palestine 1944; Israel CBS 1967, 2011; Jerusalem Institute for Policy Research 2020, 2024.",
      "19th century figures are estimates. City limits changed over time. נתוני המאה ה-19 הם הערכות."]
DISC_FS=13; EV_FS=23
HOOK={"dur":1.0,"fade":0.25,"dim":0.80,"box":(0.06,0.50,0.88,0.20),"lines":[
 (0.663,"3,000 years.","white",46),(0.618,"Who lived in JERUSALEM?",GOLD,46),
 (0.565,"3,000 שנה.","white",42),(0.522,"מי חי בירושלים?",GOLD,42)]}
CARDS=[{"t0":36.0,"t1":43.0,"dim":0.5,"box":(0.04,0.42,0.92,0.315),"lines":[
  (0.705,"Jews: the largest group in Jerusalem","white",30),(0.672,"since about the 1860s, in most counts.",GOLD,28),
  (0.632,"Before the first Zionist immigrants (1882). Before Israel (1948).","white",21),
  (0.590,"היהודים: הקבוצה הגדולה בירושלים","white",27),(0.560,"מאז שנות ה-60 של המאה ה-19 בערך, ברוב הספירות.",GOLD,23),
  (0.528,"לפני העלייה הציונית הראשונה (1882). לפני המדינה (1948).","white",20),
  (0.482,"Fair to say: in 1553, 3 in 4 residents were Muslim.",SUBC,21),(0.452,"וגם: ב-1553, שלושה מכל ארבעה תושבים היו מוסלמים.",SUBC,20)]},
 {"t0":43.0,"dim":0.5,"box":END_BOX2,"lines":[
  (0.690,"Today: 60% Jews and others, 40% Arabs.","white",26),(0.664,"A city that is home to both.","white",24),
  (0.632,"היום: 60% יהודים ואחרים, 40% ערבים.",SUBC,23),(0.606,"עיר שהיא בית לשניהם.",SUBC,23),
  (0.540,"Who lived in JERUSALEM?",GOLD,40),(0.500,"Did you guess right?",GOLD,34),(0.455,"מי חי בירושלים? ניחשתם נכון?",ACC,30)]}]
