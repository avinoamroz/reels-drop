#!/bin/bash
# usage: finish.sh id   (id = p1b|p2|p3)  -> s3000_<id>.mp4, _web.mp4, QA lines
set -e; cd /home/claude/series_3000; id=$1
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 ${id}_silent.mp4)
# two-pass loudnorm to -14 LUFS
J=$(nice -n 10 ffmpeg -hide_banner -i ${id}_mus.wav -t $D -af "afade=t=out:st=$(python3 -c "print($D-1.5)"):d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json" -f null - 2>&1 | sed -n '/{/,/}/p')
MI=$(echo "$J"|python3 -c "import json,sys;d=json.load(sys.stdin);print(f\"measured_I={d['input_i']}:measured_TP={d['input_tp']}:measured_LRA={d['input_lra']}:measured_thresh={d['input_thresh']}:offset={d['target_offset']}\")")
nice -n 10 ffmpeg -v error -y -i ${id}_silent.mp4 -i ${id}_mus.wav -t $D -filter_complex "[1:a]afade=t=out:st=$(python3 -c "print($D-1.5)"):d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11:linear=true:$MI,aresample=44100[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -movflags +faststart s3000_${id}.mp4
nice -n 10 ffmpeg -v error -y -i s3000_${id}.mp4 -vf scale=540:960 -c:v libx264 -crf 30 -preset medium -c:a aac -b:a 96k -movflags +faststart s3000_${id}_web.mp4
echo "== $id dur $(ffprobe -v error -show_entries format=duration -of csv=p=0 s3000_${id}.mp4) size $(du -h s3000_${id}.mp4|cut -f1) web $(du -h s3000_${id}_web.mp4|cut -f1)"
ffmpeg -hide_banner -i s3000_${id}.mp4 -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+I:|Peak:" | tail -2
mkdir -p qa; ffmpeg -v error -y -i s3000_${id}.mp4 -frames:v 1 qa/${id}_f0.png
for t in 0.5 1.5; do ffmpeg -v error -y -ss $t -i s3000_${id}.mp4 -frames:v 1 -vf "crop=1080:620:0:820,format=gray" qa/${id}_m$t.png; done
python3 -c "
import numpy as np,matplotlib.pyplot as plt
a=plt.imread('qa/${id}_m0.5.png').astype(float);b=plt.imread('qa/${id}_m1.5.png').astype(float)
print('motion 0.5s vs 1.5s mean abs diff (chart+counter zone):',round(float(abs(a-b).mean()),4))"
