import sys; sys.path.insert(0,"/home/claude/series_3000")
from common import *
G=P1["G"]; EVENTS=P1["EVENTS"]; TL=P1["TL"]; ROWS=7; MIN=100; FLOOR=50000; XMAXF=2.2; BAR_AX=P1["BAR_AX"]; HOLD=5
OUT="/home/claude/series_3000/p1b_silent.mp4"
PART=("PART 1","חלק 1")
T_EN=P1["T_EN"]; T_HE=P1["T_HE"]; T_FS=46; SUB=P1["SUB"]
COUNTER=("Total population","סך התושבים","sum")
DISC=P1["DISC"]+["Sources: Broshi; DellaPergola; McCarthy; British censuses 1922, 1931; Israel CBS; PCBS."]
GREEN_FROM=1949
MAP=dict(P1["MAP"]); MAP.update(wb=WB,gaza=GAZA,land_alpha=0.38)
HOOK={"dur":2.0,"fade":0.3,"dim":0.55,"box":(0.06,0.50,0.88,0.20),"lines":[
 (0.663,"Who was here first?","white",50),(0.618,"Watch 3,000 years.",GOLD,44),
 (0.565,"מי היה כאן קודם?","white",44),(0.522,"צפו ב-3,000 שנה.",GOLD,40)]}
CARDS=[{"t0":40.6,"dim":0.55,"box":(0.05,0.425,0.90,0.285),
 "lines":end_lines("Jews and Arabs both have deep roots here.","ליהודים ולערבים יש שורשים עמוקים כאן.","Part 2 on my profile","חלק 2 בפרופיל שלי")}]
