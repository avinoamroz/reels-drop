import sys; sys.path.insert(0,"/home/claude/series_3000")
from common import *
OUT="/home/claude/series_3000/p2_silent.mp4"
PART=("PART 2","חלק 2")
T_EN="3,000 years. Who RULED this land?"; T_HE="3,000 שנה. מי שלט בארץ הזאת?"; T_FS=44
SUB="From the Jordan to the sea  |  מהירדן ועד הים"
def ast(y): return y+1 if y<0 else y        # astronomical year: no year 0 between 1 BCE and 1 CE
def kf(iv):
    pts=[]; acc=0
    for s,e in iv:
        pts+= [(s,acc),(e,acc+ast(e)-ast(s))]; acc+=ast(e)-ast(s)
    return pts
# name: (hebrew, colour, keyframes, intervals)   bars = years ruling all or part of the land (periods overlap)
R={
 "Israelite kingdoms":("ממלכות ישראל","#2563eb",[(-1000,-586)]),
 "Assyria":("אשור","#b45309",[(-732,-630)]),
 "Babylon":("בבל","#f97316",[(-604,-539)]),
 "Persia":("פרס","#e11d48",[(-539,-332),(614,628)]),
 "Greeks":("היוונים","#06b6d4",[(-332,-140)]),
 "Hasmoneans":("החשמונאים","#3b82f6",[(-140,-63)]),
 "Rome":("רומא","#dc2626",[(-63,395)]),
 "Byzantium":("ביזנטיון","#a855f7",[(395,614),(628,636)]),
 "Caliphates":("הח'ליפויות","#10b981",[(636,1099)]),
 "Crusaders":("הצלבנים","#e5e7eb",[(1099,1291)]),
 "Ayyubids":("האיובים","#84cc16",[(1187,1260)]),
 "Mamluks":("הממלוכים","#f59e0b",[(1260,1516)]),
 "Ottomans":("העות'מאנים","#ef4444",[(1516,1917)]),
 "Britain":("בריטניה","#94a3b8",[(1917,1948)]),
 "Jordan and Egypt":("ירדן ומצרים","#d946ef",[(1948,1967)]),
 "Israel":("ישראל","#60a5fa",[(1948,2026)]),
}
G={n:(h,c,kf(iv)) for n,(h,c,iv) in R.items()}
STARS=["Israelite kingdoms","Hasmoneans","Crusaders","Israel"]
ROWS=16; MIN=1; FLOOR=60; XMAXF=2.35; FMT="years"; ONELINE=True; FS=16.5
BAR_AX=[0.03,0.33,0.62,0.50]
COUNTER=("Rulers so far","שליטים עד כה","count")
SUB="Years in control, Jordan to the sea  |  שנות שליטה, מהירדן ועד הים"
LAYOUT={"banner":0.405,"clab":0.372,"cval":0.334,"year":0.336,"era":0.316,"ev1":0.281,"ev2":0.257,"disc":0.236}
# (from year, [bar keys highlighted], line 1 EN, line 1 HE, line 2 EN, line 2 HE)
RULERS=[
 (-1000,["Israelite kingdoms"],"Israelite kingdoms ★","ממלכות ישראל ויהודה","Ruled from here: Jerusalem, Samaria","נשלטה מכאן: ירושלים, שומרון"),
 (-732,["Assyria","Israelite kingdoms"],"Assyria (Judah: a vassal kingdom)","אשור (יהודה: ממלכת חסות)","Ruled from Nineveh","נשלטה מנינווה"),
 (-630,["Israelite kingdoms"],"Kingdom of Judah ★","ממלכת יהודה","Ruled from here: Jerusalem","נשלטה מכאן: ירושלים"),
 (-604,["Babylon","Israelite kingdoms"],"Babylon (Judah: a vassal until 586)","בבל (יהודה: ממלכת חסות עד 586)","Ruled from Babylon","נשלטה מבבל"),
 (-539,["Persia"],"Persia","פרס","Ruled from Persepolis and Susa","נשלטה מפרספוליס ומשושן"),
 (-332,["Greeks"],"Greeks: Alexander, Ptolemies, Seleucids","היוונים: אלכסנדר, תלמיים, סלווקים","Ruled from Alexandria, then Antioch","נשלטה מאלכסנדריה, אחר כך מאנטיוכיה"),
 (-140,["Hasmoneans"],"Hasmonean kingdom ★","ממלכת החשמונאים","Ruled from here: Jerusalem","נשלטה מכאן: ירושלים"),
 (-63,["Rome"],"Rome","רומא","Ruled from Rome","נשלטה מרומא"),
 (395,["Byzantium"],"Byzantium","ביזנטיון","Ruled from Constantinople","נשלטה מקונסטנטינופול"),
 (614,["Persia"],"Persia (Sasanian)","פרס (הסאסאנים)","Ruled from Ctesiphon","נשלטה מקטסיפון"),
 (628,["Byzantium"],"Byzantium","ביזנטיון","Ruled from Constantinople","נשלטה מקונסטנטינופול"),
 (636,["Caliphates"],"Muslim caliphates","הח'ליפויות המוסלמיות","Ruled from Medina, Damascus, Baghdad, Cairo","נשלטה ממדינה, דמשק, בגדאד, קהיר"),
 (1099,["Crusaders"],"Crusader Kingdom of Jerusalem ★","ממלכת ירושלים הצלבנית","Ruled from here, by settlers from Europe","נשלטה מכאן, בידי מתיישבים מאירופה"),
 (1187,["Ayyubids","Crusaders"],"Ayyubids (Crusaders keep the coast)","האיובים (הצלבנים נשארים בחוף)","Ruled from Cairo and Damascus","נשלטה מקהיר ומדמשק"),
 (1260,["Mamluks","Crusaders"],"Mamluks (Crusaders keep the coast)","הממלוכים (הצלבנים נשארים בחוף)","Ruled from Cairo","נשלטה מקהיר"),
 (1291,["Mamluks"],"Mamluks","הממלוכים","Ruled from Cairo","נשלטה מקהיר"),
 (1516,["Ottomans"],"Ottomans","העות'מאנים","Ruled from Istanbul","נשלטה מאיסטנבול"),
 (1917,["Britain"],"Britain","בריטניה","Ruled from London","נשלטה מלונדון"),
 (1948,["Israel","Jordan and Egypt"],"Israel ★  West Bank: Jordan  Gaza: Egypt","ישראל, הגדה: ירדן, עזה: מצרים","Ruled from Jerusalem, Amman, Cairo","נשלטה מירושלים, עמאן, קהיר"),
 (1967,["Israel"],"Israel ★","ישראל","Ruled from here: Jerusalem","נשלטה מכאן: ירושלים"),
]
EVENTS=[(-1000,"c. 1000 BCE: Kingdom of David (by tradition)","ממלכת דוד (לפי המסורת)"),
 (-930,"The kingdom splits: Israel and Judah","הממלכה מתפצלת: ישראל ויהודה"),
 (-732,"Assyria conquers. Israel falls in 722 BCE","אשור כובשת. ממלכת ישראל נופלת ב-722"),
 (-630,"Assyria fades. Judah stands alone","אשור נחלשת. יהודה לבדה"),
 (-586,"Babylon destroys Jerusalem and the Temple","בבל מחריבה את ירושלים ואת המקדש"),
 (-539,"Cyrus of Persia lets the exiles return","כורש מלך פרס מתיר לגולים לשוב"),
 (-332,"Alexander the Great","אלכסנדר מוקדון"),
 (-140,"The Hasmoneans: independent again","החשמונאים: שוב עצמאיים"),
 (-63,"Pompey takes Jerusalem for Rome","פומפיוס כובש את ירושלים עבור רומא"),
 (70,"Rome destroys the Second Temple","רומא מחריבה את בית המקדש השני"),
 (395,"The empire splits: Byzantium rules","האימפריה מתפצלת: ביזנטיון שולטת"),
 (614,"Persian invasion, 614 to 628","הפלישה הפרסית, 614 עד 628"),
 (636,"The Muslim conquest","הכיבוש המוסלמי"),
 (1099,"The Crusaders take Jerusalem","הצלבנים כובשים את ירושלים"),
 (1187,"Saladin takes Jerusalem","צלאח א-דין כובש את ירושלים"),
 (1260,"The Mamluks","הממלוכים"),
 (1291,"Acre falls: the Crusaders' end","נפילת עכו: סוף הצלבנים"),
 (1516,"The Ottomans: 400 years","העות'מאנים: 400 שנה"),
 (1917,"Britain takes the land","בריטניה כובשת את הארץ"),
 (1948,"Israel founded. Jordan takes the West Bank, Egypt Gaza","קום המדינה. ירדן בגדה המערבית, מצרים בעזה"),
 (1967,"Six-Day War: Israel takes the West Bank and Gaza","מלחמת ששת הימים: ישראל בגדה ובעזה"),
 (1994,"Palestinian Authority: self-rule in parts","הרשות הפלסטינית: שלטון עצמי בחלקים"),
 (2005,"Israel leaves Gaza. Hamas takes over in 2007","ישראל יוצאת מעזה. חמאס משתלט ב-2007"),
 (2026,"Today","היום")]
TL=[(-1000,0.0),(-732,4.2),(-586,6.2),(-539,7.2),(-332,9.6),(-140,12.0),(-63,13.6),(395,17.6),(636,20.6),(1099,24.2),(1187,25.6),(1291,27.2),(1516,29.6),(1917,33.0),(1948,35.0),(1967,36.6),(2026,39.0)]
HOLD=15.5
GREEN_FROM=1949
MAP={"ax":[0.70,0.36,0.31,0.47],"xlim":(34.15,35.95),"ylim":(29.45,33.35),"outline":OUTLINE,"dashed":DASHED,"wb":WB,"gaza":GAZA,"ruler_edge":True,
 "labels":[(1948,1967,35.32,31.95,"Jordan","#f0abfc",14),(1948,1967,34.25,31.50,"Egypt","#f0abfc",13),
           (1967,9999,35.32,31.95,"West\nBank","#1a2440",13),(1967,9999,34.22,31.55,"Gaza","#e5e7eb",13)]}
DISC=["Bars: years ruling all or part of the land. Periods overlap; dates rounded (c.). Early monarchy dates debated.",
      "Sources: Britannica; Oxford History of the Biblical World; Cambridge History of Judaism; Encyclopaedia of Islam.",
      "★ = ruled from inside the land.  ★ = נשלטה מתוך הארץ"]
DISC_FS=13.5; EV_FS=23
HOOK={"dur":1.0,"fade":0.25,"dim":0.80,"box":(0.06,0.50,0.88,0.20),"lines":[
 (0.663,"3,000 years.","white",46),(0.618,"Who RULED this land?",GOLD,46),
 (0.565,"3,000 שנה.","white",42),(0.522,"מי שלט בארץ הזאת?",GOLD,42)]}
CARDS=[{"t0":39.6,"t1":48.5,"dim":0.5,"box":(0.04,0.425,0.92,0.33),"lines":[
  (0.728,"Independent states that ruled this land","white",28),(0.700,"from inside it, in 3,000 years: 4","white",28),
  (0.662,"Israelite kingdoms ★  Hasmoneans ★  Israel ★","#93c5fd",27),(0.630,"3 of the 4 were Jewish.",GOLD,36),
  (0.596,"The 4th: Crusaders, settlers from Europe.","white",24),
  (0.556,"מדינות עצמאיות ששלטו בארץ מתוכה: 4","white",25),(0.526,"שלוש מהן יהודיות. הרביעית: הצלבנים, מאירופה.",GOLD,25),
  (0.487,"Every other ruler governed it from abroad.",SUBC,22),(0.462,"Parts were held by city states and local rulers (e.g. Zahir al-Umar, 1700s).",SUBC,16.5),
  (0.441,"חלקים מהארץ החזיקו ערי מדינה ושליטים מקומיים, כמו דאהר אל-עומר.",SUBC,16.5)]},
 {"t0":48.5,"dim":0.5,"box":END_BOX2,"lines":end_lines(
  ("Who ruled is not who lived here.","Arabs have lived here for 1,300+ years."),("מי ששלט הוא לא מי שחי כאן.","ערבים חיים כאן יותר מ-1,300 שנה."),"Part 3 on my profile","חלק 3 בפרופיל שלי")}]
