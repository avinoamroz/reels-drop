SRC_FAIR_EN = "🇮🇱 Since May 2024, Israel holds the Gaza side of Rafah. The crossing reopened on 2 February 2026 for limited foot traffic (Israeli and Egyptian security approval) and has been shut again several times since."
SRC_FAIR_HE = "🇮🇱 מאז מאי 2024 ישראל מחזיקה בצד העזתי של רפיח. ב-2 בפברואר 2026 המעבר נפתח מחדש למעבר מוגבל של הולכי רגל (באישור ביטחוני של ישראל ומצרים), ומאז נסגר שוב כמה פעמים."
CAP = {
"border_knock_1": dict(share="Send this to someone who only knows about one of Gaza's borders.", en=f"""Knock knock. Who's there? Egypt. 🚪

Gaza has two borders. One gets every headline. The other is 12.6 km long, at Rafah, and almost nobody asks about it.

🔒 After HAMAS took over Gaza in 2007, Egypt kept the Rafah crossing shut for long stretches. UN OCHA counted only 34 opening days between October 2014 and September 2015.
🌊 In September 2015, Egypt pumped seawater into the smuggling tunnels under the border.
{SRC_FAIR_EN}

Two borders. Only one gets the blame.

Sources: UN OCHA (2015); Al Jazeera (Sep 2015); AP (May 2024, Feb 2026).

Send this to someone who only knows about one of Gaza's borders.

#Israel #Gaza #Egypt""", he=f"""נוק נוק. מי שם? מצרים. 🚪
לעזה יש שני גבולות. אחד מקבל את כל הכותרות. השני, 12.6 ק"מ ברפיח, וכמעט אף אחד לא שואל עליו.
🔒 אחרי שחמאס השתלט על עזה ב-2007, מצרים החזיקה את מעבר רפיח סגור לתקופות ארוכות. לפי OCHA של האו"ם, בין אוקטובר 2014 לספטמבר 2015 הוא נפתח רק 34 ימים.
🌊 בספטמבר 2015 מצרים הציפה במי ים את מנהרות ההברחה שמתחת לגבול.
{SRC_FAIR_HE}
שני גבולות. רק אחד מקבל את האשמה.
שלחו את זה למישהו שמכיר רק גבול אחד של עזה."""),
"border_knock_2": dict(share="Send this to the friend who has never heard of the Philadelphi corridor.", en=f"""Knock knock. Who's there? Nobody. 🚪

Nobody. That's who talks about Gaza's border with Egypt.

🏜️ 18 October 2023: Egypt's president rejected moving Gazans into Sinai and said they could be moved to Israel's Negev "till the militants are dealt with" (Reuters).
🕳️ 29 May 2024: the IDF says it found about 20 tunnels in the Philadelphi corridor, the strip along the Gaza and Egypt border. Egypt called the Israeli allegations false.
{SRC_FAIR_EN}

Two borders. Only one gets the knock.

Sources: Reuters (18 Oct 2023); IDF spokesman via The Defense Post (30 May 2024); Egypt Today (2024); AP (May 2024, Feb 2026).

Send this to the friend who has never heard of the Philadelphi corridor.

#Israel #Gaza #Egypt""", he=f"""נוק נוק. מי שם? אף אחד. 🚪
אף אחד. זה מי שמדבר על הגבול של עזה עם מצרים.
🏜️ 18 באוקטובר 2023: נשיא מצרים דחה העברת עזתים לסיני, ואמר שאפשר להעביר אותם לנגב הישראלי "עד שיטפלו במחבלים" (רויטרס).
🕳️ 29 במאי 2024: צה"ל מסר שמצא כ-20 מנהרות בציר פילדלפי, הרצועה שלאורך גבול עזה ומצרים. מצרים הכחישה את הטענות.
{SRC_FAIR_HE}
שני גבולות. רק באחד דופקים בדלת.
שלחו את זה לחבר שלא שמע אף פעם על ציר פילדלפי."""),
"border_question_1": dict(share="Send this to someone who has an answer. We're still waiting.", en=f"""The hardest question on earth. 🎙️

8 questions. 0 correct answers. Why is Gaza's border with Egypt closed, and why does nobody ask Egypt?

✅ The answer:
🔒 After HAMAS took over Gaza in 2007, Egypt kept Rafah shut for long stretches (UN OCHA: open 34 days between Oct 2014 and Sep 2015).
🌊 2015: Egypt flooded the smuggling tunnels with seawater (Al Jazeera, Sep 2015).
🏜️ 2023: Egypt's president rejected moving Gazans into Sinai (Reuters, 18 Oct 2023).
{SRC_FAIR_EN}

Two borders. Only one gets the questions.

Sources: UN OCHA (2015); Al Jazeera (2015); Reuters (2023); AP (2024, 2026).

Send this to someone who has an answer. We're still waiting.

#Israel #Gaza #Egypt""", he=f"""השאלה הכי קשה בעולם. 🎙️
8 שאלות. 0 תשובות נכונות. למה הגבול של עזה עם מצרים סגור, ולמה אף אחד לא שואל את מצרים?
✅ התשובה:
🔒 אחרי שחמאס השתלט על עזה ב-2007, מצרים החזיקה את רפיח סגור לתקופות ארוכות (OCHA: נפתח 34 ימים בין אוקטובר 2014 לספטמבר 2015).
🌊 2015: מצרים הציפה במי ים את מנהרות ההברחה.
🏜️ 2023: נשיא מצרים דחה העברת עזתים לסיני.
{SRC_FAIR_HE}
שני גבולות. רק אחד מקבל את השאלות.
שלחו את זה למישהו שיש לו תשובה. אנחנו עדיין מחכים."""),
"border_collie": dict(share="Send this to a dog person who reads the news.", en=f"""What's the difference between a border collie and the Gaza and Egypt border? 🐕

🐕 A border collie: the No. 26 most popular dog in America (AKC, 2025). Everyone talks about it. It always has an owner.
🚧 The Rafah border: nobody talks about it, and nobody takes ownership. HAMAS says blah blah blah. Critics say "Israel's blockade!"

Meanwhile:
🔒 After HAMAS took over Gaza in 2007, Egypt kept Rafah shut for long stretches (UN OCHA: open 34 days between Oct 2014 and Sep 2015).
🌊 Smuggling tunnels ran under the border from Sinai. Egypt flooded them with seawater in 2015 (Al Jazeera).
🕳️ In May 2024, the IDF says it found about 20 tunnels in the Philadelphi corridor. Egypt called the Israeli allegations false.
{SRC_FAIR_EN}

A border collie brings the ball back. With that border, everyone throws it at Israel.

Sources: AKC (2025); UN OCHA (2015); Al Jazeera (2015); IDF spokesman via The Defense Post (2024); Egypt Today (2024); AP (2024, 2026).

Send this to a dog person who reads the news.

#Israel #Gaza #BorderCollie""", he=f"""מה ההבדל בין בורדר קולי לגבול בין עזה למצרים? 🐕
🐕 בורדר קולי: הכלב ה-26 הכי פופולרי בארה"ב (AKC, 2025). כולם מדברים עליו, ותמיד יש לו בעלים.
🚧 גבול רפיח: אף אחד לא מדבר עליו, ואף אחד לא לוקח עליו אחריות. חמאס אומר בלה בלה בלה. המבקרים אומרים "המצור של ישראל!"
ובינתיים:
🔒 אחרי שחמאס השתלט על עזה ב-2007, מצרים החזיקה את רפיח סגור לתקופות ארוכות.
🌊 מנהרות הברחה עברו מתחת לגבול מסיני. ב-2015 מצרים הציפה אותן במי ים.
🕳️ במאי 2024 צה"ל מסר שמצא כ-20 מנהרות בציר פילדלפי. מצרים הכחישה.
{SRC_FAIR_HE}
בורדר קולי מחזיר את הכדור. עם הגבול הזה, כולם זורקים אותו על ישראל.
שלחו את זה לחובב כלבים שקורא חדשות."""),
}
