"""israel_ai_capita scenes (1 Nov 2026): the daily_1101 house scenes (dark keynote stage, photo, label, circular loop, bar-cut
music) plus sc_race, a per-capita bar race: bars appear on their spoken word, grow and count up, glide to their sorted rank
(best first), a dashed 1x line marks "what the population predicts", and an optional mystery bar ("?") is revealed with its
flag and name on the "reveal" mark."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))

GOLD = kit.hx("#FFC93C")
def _flag(iso): return "".join(chr(0x1F1E6 + ord(ch) - 65) for ch in iso.upper())
def _fmtv(v, unit, dec):
    if unit == "x":
        s = f"{v:.2f}".rstrip("0").rstrip(".") if dec is None else f"{v:.{dec}f}"
        return s + "x"
    return f"{v:.{2 if dec is None else dec}f}" + unit

def sc_race(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S)
    a1, s1 = PP(t, t0 + 0.05, S)
    hT = _wtext(c, S.get("title", ""), 92, 0, max_lines=2, a=0) or 0
    _wtext(c, S.get("title", ""), 92, TOP + hT / 2, a=a1, sc=s1, max_lines=2)
    bars = S["bars"]; tm = S["times"]; full = S.get("full")
    unit = S.get("unit", "x"); dec = S.get("dec"); vmax = S["vmax"]
    tin = {b["key"]: (t0 - 5.0 if full else tm.get(b["key"], t0 + 0.3)) for b in bars}
    trev = tm.get("reveal")
    vis = [b for b in bars if t >= tin[b["key"]] - 0.05]
    n = len(bars); top0 = TOP + hT + 70; avail = 1372 - top0; step = min(200, avail / max(1, n)); top = top0 + (avail - step * n) / 2 + 20
    # rank slots: sort visible bars by final value (best first); glide 0.55 s after each new arrival
    events = sorted(set(tin[b["key"]] for b in bars))
    last = max([e for e in events if e <= t + 0.05] or [t0]); prev = [e for e in events if e < last - 1e-6]
    def order(at): return [b["key"] for b in sorted([b for b in bars if at >= tin[b["key"]] - 0.05], key=lambda b: -b["v"])]
    o_now = order(t); o_prev = order(prev[-1]) if prev else o_now; u = ease((t - last) / 0.55)
    X0 = 160; BW = 700
    # 1x reference line (expected by population)
    if unit == "x":
        x1 = X0 + BW * 1.0 / vmax; la = RD.fade_in(t, t0 + 0.3, S)
        c.set_dash([10, 10]); sa(c, WHITE, 0.45 * la); c.set_line_width(3); c.move_to(x1, top - 40); c.line_to(x1, top + step * n - 10); c.stroke(); c.set_dash([])
        kit.tx(c, "1x = expected", 36, x1 + 12, top - 64, w=700, col=RD.c255(WHITE), a=0.8 * la, shadow=False, src=True, maxw=400, anchor="l")
    for b in vis:
        k = b["key"]; r_now = o_now.index(k); r_prev = o_prev.index(k) if k in o_prev else r_now
        y = top + step * (r_prev + (r_now - r_prev) * u)
        a, s = PP(t, tin[k], S, s0=0.7, bounce=1.2)
        g = ease((t - tin[k]) / 0.9) if not full else 1.0
        if S.get("hook") and tin[k] <= RD.HOOK_GRACE: g = 1.0
        myst = b.get("mystery") and (trev is None or t < trev - 0.02)
        rv = 0.0 if trev is None else ease((t - trev) / 0.35)
        hl = b.get("hl") or (b.get("mystery") and not myst)
        v = b["v"] * g; w = max(8, BW * v / vmax)
        # name + flag
        if myst:
            circ(c, 96, y + 64, 44, SKY, 0.9 * a)
            kit.tx(c, "?", 70, 96, y + 66, w=900, col=RD.c255(WHITE), a=a, shadow=False, maxw=80)
            name = "?"
        else:
            sc_ = s * (1 + 0.25 * (1 - rv) * (1 if b.get("mystery") else 0))
            draw_emoji(c, _flag(b["flag"]), 96, y + 64, 88, a, sc_)
            name = b["en"]
        kit.tx(c, name, 60, X0, y + 4, w=800, col=RD.c255(GOLD if hl else WHITE), a=a, shadow=False, maxw=700, anchor="l")
        col = GOLD if hl else SKY
        sa(c, col, (0.95 if hl else 0.85) * a); rr(c, X0, y + 42, w, 58, 29); c.fill()
        if hl and not myst:
            sa(c, GOLD, 0.25 * a * (0.6 + 0.4 * math.sin(t * 4))); rr(c, X0 - 7, y + 35, w + 14, 72, 36); c.fill()
        kit.tx(c, _fmtv(v, unit, b.get("dec", dec)), 66, X0 + w + 18, y + 71, w=900, col=RD.c255(YEL), a=a, shadow=False, maxw=300, anchor="l")
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)

def sc_hook(c, t, S):
    """hook card: stage + big question + a bobbing row of the race's flags with the mystery '?' (motion from frame 0)"""
    sc_stage(c, t, S)
    fl = S.get("flags", []); n = len(fl) + 1; gap = 150; x0 = 540 - gap * (n - 1) / 2; y0 = S.get("flags_y", 1200); a = St.a
    for i in range(n):
        x = x0 + gap * i; y = y0 + 14 * math.sin(t * 2.4 + i * 0.9)
        if i < len(fl): draw_emoji(c, _flag(fl[i]), x, y, 104, 1.0, 1.0)
        else:
            circ(c, x, y, 56, SKY, 0.95)
            kit.tx(c, "?", 84, x, y + 3, w=900, col=RD.c255(WHITE), a=1.0, shadow=False, maxw=100)
