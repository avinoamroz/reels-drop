"""reelkit scenes for israel_drinks_v3 (31 Oct 2026).
Centred layout: everything is symmetric about x = 540, content inside x 90..990, nothing below y 1540.
Circular reel:
  * LOOP = T_END - 1/30 (set after the Reel is built). Every animated phase uses (t % LOOP), so the last frame
    (t = LOOP) draws exactly what frame 0 draws.
  * the background is a periodic version of the house silver background.
  * the last scene ("coffee_hook" with "end": true) draws the hook at local time t - LOOP <= 0 and arrives at the
    frame-0 state on the last frame; subtitles are clamped off before the last frame.
  * music "loop_playful": the playful bed re-tempoed so the file length is a whole number of 4-bar phrases, rendered
    3x long and the middle period kept, so it loops seamlessly with a downbeat on frame 0."""
import math, random
import numpy as np
import cairo
from PIL import Image, ImageDraw, ImageFont
import render as RD
import mix as MX
from render import P, T, pill, PP, fade_in, draw_emoji
from kit import ease, ramp, lerp, St, sa, rr, circ, box, font, W, H, FPS, pil2cairo

CX = 540; XL, XR = 90, 990
SUB_Y = 1470
LOOP = [None]

def tl(t):
    """loop clock"""
    return t % LOOP[0] if LOOP[0] else t

# ------------------------------------------------------------------ Reel patch: loop period + subtitle clamp
# (the module is loaded inside Reel.__init__, so the loop period is taken from the Reel when the subtitles are built,
#  which is the last step of Reel.__init__, after T_END is known)
import sys as _sys

# ------------------------------------------------------------------ subtitles, centred
def sub_surfs(pieces, sz=46, maxw=820):
    reel = _sys._getframe(1).f_locals.get("s")
    if reel is not None and getattr(reel, "T_END", None):
        LOOP[0] = reel.T_END - 1.0 / FPS
        pieces = [(t0, min(t1, LOOP[0] - 0.05), d) for t0, t1, d in pieces]
    F = ImageFont.truetype(RD.SUB_FONT, sz); out = []
    for t0, t1, d in pieces:
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 24
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=RD.P255["navy"][:3] + (232,), outline=RD.P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 12 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        out.append((t0, t1, pil2cairo(im), int(CX - Wd / 2), int(SUB_Y - Hd / 2), d, Hd))
    return out
RD.sub_surfs = sub_surfs

# ------------------------------------------------------------------ periodic background (house look)
_bg = {}
def background(c, t):
    Pd = LOOP[0] or 60.0; u = (t % Pd) / Pd; TAU = 2 * math.pi
    if "base" not in _bg:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(s)
        g = cairo.LinearGradient(0, 0, W * 0.4, H); g.add_color_stop_rgb(0, *P["bg0"][:3]); g.add_color_stop_rgb(1, *P["bg1"][:3])
        cc.set_source(g); cc.paint(); _bg["base"] = s
        R = random.Random(3); _bg["sp"] = [(R.uniform(40, 1040), R.uniform(0, H), R.uniform(6, 13), R.choice((1, 1, 2)), R.random() * 6) for _ in range(24)]
        gl = cairo.ImageSurface(cairo.FORMAT_ARGB32, 1200, 1200); gc = cairo.Context(gl)
        rg = cairo.RadialGradient(600, 600, 0, 600, 600, 600); rg.add_color_stop_rgba(0, 1, 1, 1, 0.75); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        gc.set_source(rg); gc.paint(); _bg["glow"] = gl
    c.set_source_surface(_bg["base"], 0, 0); c.paint()
    for k, (bx, by, br) in enumerate([(300, 520, 560), (780, 1350, 620)]):
        x = bx + 60 * math.sin(TAU * 2 * u + k * 2); y = by + 50 * math.cos(TAU * 3 * u + k); s = br / 600
        c.save(); c.translate(x - br, y - br); c.scale(s, s); c.set_source_surface(_bg["glow"], 0, 0); c.paint(); c.restore()
    for k, (x0, y0, r, laps, ph) in enumerate(_bg["sp"]):
        y = (y0 - (H + 60) * laps * u) % (H + 60) - 30; x = x0 + 14 * math.sin(TAU * 7 * u + k); tw = 0.5 + 0.5 * math.sin(TAU * 19 * u + ph)
        RD.diamond(c, x, y, r, P["silver"] if k % 4 else P["gold"], 0.35 + 0.35 * tw)
RD.background = background

# ------------------------------------------------------------------ seamless music bed
_bed = MX.bed
def bed(name, dur, end_at=None):
    if name != "loop_playful": return _bed(name, dur, end_at)
    n = int(dur * MX.SR); bar0 = 4 * 60 / 112.0
    nb = max(4, int(round(dur / bar0 / 4)) * 4); bpm = nb * 4 * 60 / dur
    m = MX._mod("sfx2", "/home/claude/reelkit/sfx2.py")
    x = np.asarray(m.music_playful(3 * dur + 1, 10 * dur, bpm=bpm), np.float64)
    if x.ndim == 1: x = np.vstack([x, x])
    sr_m = x.shape[1] / (3 * dur + 1)
    i0 = int(round(dur * sr_m)); seg = x[:, i0:i0 + int(round(dur * sr_m))]
    if abs(sr_m - MX.SR) > 5:   # resample to the mix rate if the bed module runs at another rate
        idx = np.linspace(0, seg.shape[1] - 1, n); seg = np.vstack([np.interp(idx, np.arange(seg.shape[1]), ch) for ch in seg])
    seg = seg[:, :n]
    if seg.shape[1] < n: seg = np.pad(seg, ((0, 0), (0, n - seg.shape[1])), mode="wrap")
    print(f"[loop bed] {nb} bars at {bpm:.2f} BPM over {dur:.3f} s")
    return seg / (np.abs(seg).max() + 1e-12)
MX.bed = bed

def src_line(c, s, a, y=1385):
    if s and a > 0.01: T(c, s, 34, CX, y, P["grey"], a, 1.0, 700, maxw=880, src=True)

# ------------------------------------------------------------------ glass
LIQ = dict(cola="#3A1E12", beer="#E8A825", coffee="#5A3A22", water="#2A88D4", wine="#8E1B3A", milk="#FFFFFF", tea="#B8652A", soda="#3A1E12")
def hx(h): return RD.kit.hx(h)

def glass(c, x, y, w, h, level, kind, t, seed=0):
    tw, bw = w, w * 0.8
    def outline():
        c.new_path(); c.move_to(x - tw / 2, y); c.line_to(x - bw / 2, y + h - 18)
        c.curve_to(x - bw / 2, y + h, x - bw / 2 + 10, y + h, x - bw / 2 + 24, y + h)
        c.line_to(x + bw / 2 - 24, y + h); c.curve_to(x + bw / 2 - 10, y + h, x + bw / 2, y + h, x + bw / 2, y + h - 18)
        c.line_to(x + tw / 2, y); c.close_path()
    tt = tl(t); TAU = 2 * math.pi; Pd = LOOP[0] or 60.0
    outline(); sa(c, P["white"], 0.55); c.fill()
    c.save(); outline(); c.clip()
    ly = y + h - (h - 12) * level; lc = hx(LIQ[kind])
    sx = x + 6 * math.sin(TAU * 9 * tt / Pd + seed)
    sa(c, lc, 0.95); rr(c, sx - 11, y - 220, 22, ly - (y - 220) + 10, 11); c.fill()
    c.new_path(); c.move_to(x - tw, y + h + 5)
    ph1 = TAU * 40 * tt / Pd; ph2 = TAU * 55 * tt / Pd
    for k in range(0, 41):
        xx = x - tw / 2 + tw * k / 40
        c.line_to(xx, ly + 8 * math.sin(xx / 28 + ph1 + seed) + 4 * math.sin(xx / 12 - ph2))
    c.line_to(x + tw, y + h + 5); c.close_path()
    if kind == "coffee":
        g = cairo.LinearGradient(0, ly, 0, y + h); g.add_color_stop_rgb(0, *hx("#C89B6D")[:3]); g.add_color_stop_rgb(0.25, *hx("#8A5A35")[:3]); g.add_color_stop_rgb(1, *lc[:3])
        c.set_source(g)
    else: sa(c, lc, 1.0)
    c.fill()
    R = random.Random(seed)
    for k in range(10):
        bx = x - bw / 2 + 24 + R.random() * (bw - 48); laps = 3 + int(4 * R.random()); ph = R.random()
        by = y + h - ((laps * tt / Pd + ph) % 1.0) * (y + h - ly)
        if by > ly + 14: circ(c, bx, by, 5 + 3 * R.random(), P["white"], 0.5)
    c.restore()
    outline(); sa(c, P["navy"], 0.9); c.set_line_width(8); c.stroke()
    sa(c, P["white"], 0.6); c.set_line_width(7); c.move_to(x - tw / 2 + 26, y + 34); c.line_to(x - bw / 2 + 28, y + h - 46); c.stroke()

# ------------------------------------------------------------------ hook (and the loop end)
def sc_coffee_hook(c, t, S):
    """frame 0: the question + a coffee glass already filling. Line 2: guesses pop. Line 3: the answer, 3 flags.
    "end": true draws the hook at local time t - LOOP (<= 0): the glass refills to the frame-0 level and nothing else shows."""
    end = S.get("end"); tau = (t - LOOP[0]) if (end and LOOP[0]) else t
    tm = S["times"]
    for k, ln in enumerate(S["en"]):
        T(c, ln, 96, CX, 300 + k * 108, P["navy"], 1.0, 1.0, 900, hl=P["blue"], maxw=900)
    if tau >= 0: lev = 0.30 + 0.48 * ease(min(1.0, tau / 7.0))
    else: lev = 0.30 * (1 - ease(min(1.0, -tau / 3.0)))
    gx, gy, gw, gh = CX, 700, 300, 470
    glass(c, gx, gy, gw, gh, lev, "coffee", t, seed=5)
    if end: return
    # counter inside the glass: ? until the answer, then counts to 100 L
    ta = tm.get("ans", 6.0)
    if t >= tm.get("q", 2.5) - 0.1:
        if t < ta:
            a, s = PP(t, tm.get("q", 2.5), S, bounce=2.6)
            pill(c, "? L", 72, gx, gy + gh * 0.55, P["white"], P["navy"], a, s, outline=P["gold"], w=900)
        else:
            v = 100 * ease((t - ta) / 0.9); a, s = PP(t, ta, S, bounce=2.6)
            pill(c, f"{v:.0f} L", 72, gx, gy + gh * 0.55, P["gold"], P["white"], a, s, outline=P["navy"], w=900)
    # guesses around the glass
    gs = S["guesses"]
    for k, (txt, x, y) in enumerate(gs):
        tk = tm.get(f"g{k}", 3.6 + 0.3 * k)
        if t < tk - 0.1: continue
        win = txt.startswith("100") and t >= ta
        if t >= ta and not win: a, s = max(0.25, 1 - (t - ta) / 0.4), 1.0
        else: a, s = PP(t, tk, S, bounce=2.6)
        pill(c, txt, 60, x, y, P["gold"] if win else P["navy"], P["white"], a, s, outline=P["gold"] if not win else P["navy"], w=900)
    # the answer line
    tf = tm.get("flags", ta + 1.2)
    if t >= tf - 0.1:
        a, s = PP(t, tf, S, bounce=2.2)
        T(c, "Less than", 64, CX, 1270, P["navy"], a, s, 900, maxw=900)
        for k, code in enumerate(("DE", "GB", "US")):
            a2, s2 = PP(t, tf + 0.15 + 0.18 * k, S, bounce=2.6)
            if a2 > 0.01: draw_emoji(c, RD.flag_emoji(code), CX - 170 + 170 * k, 1365, 96 * s2, a2)

# ------------------------------------------------------------------ the Israel race (centred)
def _fmt(v): return f"{v:,.0f}"

def sc_glass_race(c, t, S):
    t0 = S["t0"]; rows = S["rows"]; n = len(rows); tm = S["times"]; tt = tl(t)
    a, s = PP(t, t0 + 0.05, S)
    T(c, S["title"], 60, CX, 262, P["navy"], a, s, 900, hl=P["blue"], maxw=900)
    top, rh = 340, 128; LX, TX0, TX1 = 92, 470, 990
    ts = [tm.get(f"d{k}", t0 + 0.5 + 2.5 * k) for k in range(n)]
    tq = tm.get("q", ts[-1] - 1.0)
    vis = [k for k in range(n) if t >= ts[k] - 0.1]
    mystery = t >= tq - 0.1 and t < ts[-1] - 0.1
    cur = {k: rows[k]["value"] * ease((t - ts[k]) / 0.9) for k in vis}
    target = max([rows[k]["value"] for k in vis] + [1]) * 1.10
    if "_vm" not in S: S["_vm"] = target; S["_rk"] = {}
    S["_vm"] += (target - S["_vm"]) * 0.10; vm = S["_vm"]
    order = sorted(vis, key=lambda k: -rows[k]["value"])
    if mystery: order = [n - 1] + order
    for r_, k in enumerate(order):
        S["_rk"][k] = S["_rk"].get(k, float(r_)) + (r_ - S["_rk"].get(k, float(r_))) * 0.22
    for k in order:
        row = rows[k]; yy = top + rh * S["_rk"][k] + rh / 2
        is_q = (k == n - 1 and mystery); ta = ts[k] if not is_q else tq
        al, sc_ = PP(t, ta, S, bounce=2.2)
        if al <= 0.01: continue
        old = St.a; St.a *= al
        c.save(); c.translate(CX, yy); c.scale(sc_, sc_); c.translate(-CX, -yy)
        win = (k == n - 1 and not is_q); th = 90; tw_ = TX1 - TX0
        box(c, TX0, yy - th / 2, tw_, th, th / 2, P["bg1"], 0.9, stroke=P["gold"] if win else P["silver"], sw=6 if win else 4)
        if is_q:
            pu = 0.5 + 0.5 * math.sin(tt * 8)
            draw_emoji(c, "❓", LX + 34, yy, 64)
            T(c, "Number 1?", 56, LX + 78, yy, P["navy"], 1, 1, 900, anchor="l", maxw=300)
            T(c, "?", 64, TX0 + tw_ / 2, yy + 2, P["gold_text"], 0.6 + 0.4 * pu, 1, 900)
        else:
            v = cur[k]; fw = max(24, tw_ * min(1.0, v / vm)) if v > 0 else 0; lc = hx(LIQ[row["kind"]])
            if fw > 0:
                c.save(); rr(c, TX0, yy - th / 2, tw_, th, th / 2); c.clip()
                c.new_path(); c.move_to(TX0 - 5, yy - th / 2 - 5); ex = TX0 + fw
                for j in range(0, 21):
                    yy2 = yy - th / 2 + th * j / 20; c.line_to(ex + 6 * math.sin(yy2 / 9 + tt * 6 + k), yy2)
                c.line_to(TX0 - 5, yy + th / 2 + 5); c.close_path(); sa(c, lc, 1.0); c.fill(); c.restore()
            draw_emoji(c, row["icon"], LX + 34, yy, 64)
            T(c, row["label"], 56, LX + 78, yy, P["navy"], 1, 1, 900, anchor="l", maxw=300)
            lab = f"{_fmt(v)} L"; dark = row["kind"] != "milk"
            if font(56, 900).getlength(lab) + 50 < fw: T(c, lab, 56, TX0 + fw - 26, yy + 2, P["white"] if dark else P["navy"], 1, 1, 900, anchor="r", maxw=400)
            else: T(c, lab, 56, TX0 + fw + 16, yy + 2, P["navy"], 1, 1, 900, anchor="l", maxw=400)
            if win:
                a4, s4 = PP(t, ts[k] + 0.5, S, bounce=2.6); pill(c, "#1", 44, TX0 - 2, yy - th / 2 - 4, P["gold"], P["white"], a4, s4, w=900)
        c.restore(); St.a = old
    newest = max(vis, key=lambda k: ts[k]) if vis else None
    src = S.get("source")
    if mystery: src = S.get("q_source", src)
    elif newest is not None and rows[newest].get("source"): src = rows[newest]["source"]
    src_line(c, src, fade_in(t, t0 + 0.5, S))

# ------------------------------------------------------------------ pools
def pool(c, x, y, w, h, lev, t, k):
    box(c, x, y, w, h, 14, P["white"], 0.75, stroke=P["navy"], sw=5)
    c.save(); rr(c, x + 5, y + 5, w - 10, h - 10, 10); c.clip()
    ly = y + h - 5 - (h - 10) * lev; tt = tl(t)
    c.new_path(); c.move_to(x, y + h)
    for j in range(0, 21):
        xx = x + w * j / 20; c.line_to(xx, ly + 4 * math.sin(xx / 12 + tt * 5 + k))
    c.line_to(x + w, y + h); c.close_path(); sa(c, P["blue"]); c.fill()
    for j in range(1, 5):
        lx = y + h * j / 5
        sa(c, P["white"], 0.55 if lev > 0.1 else 0); c.set_line_width(3); c.set_dash([10, 8]); c.move_to(x + 8, lx); c.line_to(x + w - 8, lx); c.stroke(); c.set_dash([])
    c.restore()

def sc_pools(c, t, S):
    t0 = S["t0"]; tm = S["times"]; a, s = PP(t, t0 + 0.05, S)
    T(c, "All together", 64, CX, 300, P["navy"], a, s, 900, maxw=900)
    tn = tm.get("num", t0 + 0.2); v = 25 * ease((t - tn) / 1.0) if t >= tn else 0.0
    a2, s2 = PP(t, tn, S, bounce=2.2)
    T(c, f"{v:,.0f} million", 120, CX, 445, P["gold_text"], a2, s2, 900, maxw=900)
    T(c, "liters a day", 64, CX, 560, P["navy"], a2, s2, 900, maxw=900)
    tp = tm.get("pools", t0 + 1.2); a3, s3 = PP(t, tp - 0.2, S, bounce=2.2)
    T(c, "= 10 Olympic pools", 72, CX, 690, P["blue"], a3, s3, 900, maxw=900)
    pw, ph, gx, gy = 156, 104, 20, 30; x0 = CX - (5 * pw + 4 * gx) / 2; y0 = 780
    for k in range(10):
        tk = tp + 0.08 * k
        if t < tk - 0.1: continue
        al = ramp(t, tk - 0.1, tk + 0.15); old = St.a; St.a *= al
        r_, q = divmod(k, 5); lev = 0.12 + 0.85 * ease((t - tk) / 1.1)
        pool(c, x0 + q * (pw + gx), y0 + r_ * (ph + gy), pw, ph, lev, t, k); St.a = old
    a4, s4 = PP(t, tm.get("every", tp + 0.9), S, bounce=2.4)
    pill(c, "Every single day", 56, CX, 1100, P["gold"], P["white"], a4, s4, w=900)
    T(c, "Olympic pool = 2.5 million liters", 40, CX, 1205, P["grey"], a3, 1, 700, maxw=900)
    src_line(c, S.get("source"), fade_in(t, t0 + 0.5, S), y=1340)

# ------------------------------------------------------------------ Israel compared to the world
NAMES = dict(IL="Israel", US="USA", DE="Germany", GB="UK", TR="Turkey")

def sc_compare_intro(c, t, S):
    t0 = S["t0"]; a, s = PP(t, t0 + 0.05, S, bounce=2.2)
    a3, s3 = PP(t, t0 + 0.15, S, bounce=2.6)
    if a3 > 0.01: draw_emoji(c, RD.flag_emoji("IL"), CX, 430, 150 * s3, a3)
    T(c, "Israel", 110, CX, 600, P["gold_text"], a, s, 900, maxw=900)
    T(c, "compared to the world", 80, CX, 720, P["navy"], a, s, 900, hl=P["blue"], maxw=900)
    for k, code in enumerate(("US", "DE", "GB", "TR")):
        a2, s2 = PP(t, t0 + 0.35 + 0.15 * k, S, bounce=2.6)
        if a2 > 0.01: draw_emoji(c, RD.flag_emoji(code), CX - 300 + 200 * k, 900, 120 * s2, a2)
    T(c, "4 drinks, 5 countries", 60, CX, 1060, P["navy"], fade_in(t, t0 + 0.8, S), 1, 900, maxw=900)

def sc_country_round(c, t, S):
    t0 = S["t0"]; tm = S["times"]; a, s = PP(t, t0 + 0.02, S, bounce=2.2)
    head_w = font(96, 900).getlength(S["drink"]) + 120
    draw_emoji(c, S["icon"], CX - head_w / 2 + 48, 300, 96, a, s)
    T(c, S["drink"], 96, CX - head_w / 2 + 120, 300, P["navy"], a, s, 900, anchor="l", maxw=700)
    T(c, S["unit"], 56, CX, 395, P["blue"], a, s, 900, maxw=900)
    y0 = 470
    if S.get("note"):
        for j, nl in enumerate(S["note"]): T(c, nl, 40, CX, 462 + 50 * j, P["grey"], fade_in(t, t0 + 0.2, S), 1, 700, maxw=900)
        y0 = 500 + 50 * len(S["note"])
    rows = sorted(S["rows"], key=lambda r: -r["value"]); n = len(rows)
    rh = min(150, (1250 - y0) / n); vmax = rows[0]["value"] * 1.04
    TX0, TX1 = 470, 990; tw_ = TX1 - TX0; tb = tm.get("bars_t", t0 + 0.25)
    for k, r in enumerate(rows):
        tk = tb + 0.09 * k; yy = y0 + rh * k + rh / 2
        if t < tk - 0.05: continue
        al = fade_in(t, tk - 0.05, S, 0.2); old = St.a; St.a *= al
        isr = r["code"] == "IL"; u = ease((t - tk) / 0.8)
        if isr: box(c, XL - 10, yy - rh / 2 + 10, XR - XL + 20, rh - 20, 30, P["gold2"], 0.35, stroke=P["gold"], sw=5)
        draw_emoji(c, RD.flag_emoji(r["code"]), XL + 44, yy, 72)
        T(c, NAMES[r["code"]], 56, XL + 98, yy, P["navy"], 1, 1, 900, anchor="l", maxw=270)
        th = 88; box(c, TX0, yy - th / 2, tw_, th, th / 2, P["bg1"], 0.9)
        fw = max(24, tw_ * r["value"] * u / vmax)
        c.save(); rr(c, TX0, yy - th / 2, tw_, th, th / 2); c.clip()
        box(c, TX0, yy - th / 2, fw, th, th / 2, P["gold"] if isr else hx(S["color"]), 1.0); c.restore()
        lab = f"{r['value'] * u:,.0f} L"
        if font(56, 900).getlength(lab) + 50 < fw: T(c, lab, 56, TX0 + fw - 24, yy + 2, P["white"], 1, 1, 900, anchor="r", maxw=400)
        else: T(c, lab, 56, TX0 + fw + 16, yy + 2, P["navy"], 1, 1, 900, anchor="l", maxw=400)
        St.a = old
    a4, s4 = PP(t, tm.get("rank", t0 + 2.0), S, bounce=2.6)
    pill(c, S["rank_text"], 64, CX, 1300, P["gold"], P["white"], a4, s4, outline=P["navy"], w=900)
    src_line(c, S.get("source"), fade_in(t, t0 + 0.4, S))

# ------------------------------------------------------------------ v4: real WORLD ranks
WNAMES = dict(IL="Israel", US="USA", DE="Germany", CZ="Czech Republic", YE="Yemen", HK="Hong Kong", PK="Pakistan", TR="Turkey", CO="Colombia")

def sc_world_round(c, t, S):
    """one drink, one world table: #1 in the world, Germany, USA, Israel (gold), last in the world.
    rows [{rank, code, value, note}] in rank order; header pill "Israel: #79 of 174 in the world" on mark 'rank'."""
    t0 = S["t0"]; tm = S["times"]; a, s = PP(t, t0 + 0.02, S, bounce=2.2)
    head_w = font(96, 900).getlength(S["drink"]) + 120
    draw_emoji(c, S["icon"], CX - head_w / 2 + 48, 290, 96, a, s)
    T(c, S["drink"], 96, CX - head_w / 2 + 120, 290, P["navy"], a, s, 900, anchor="l", maxw=700)
    T(c, S["unit"], 56, CX, 385, P["blue"], a, s, 900, maxw=900)
    T(c, S["count_text"], 44, CX, 450, P["grey"], fade_in(t, t0 + 0.2, S), 1, 800, maxw=900)
    rows = S["rows"]; n = len(rows); y0 = 490; rh = 146
    vmax = max(r["value"] for r in rows) * 1.02
    TX0, TX1 = XL + 10, XR - 10; tw_ = TX1 - TX0; tb = tm.get("bars_t", t0 + 0.25)
    for k, r in enumerate(rows):
        tk = tb + 0.12 * k; ytop = y0 + rh * k
        if t < tk - 0.05: continue
        al = fade_in(t, tk - 0.05, S, 0.2); old = St.a; St.a *= al
        isr = r["code"] == "IL"; u = ease((t - tk) / 0.8)
        if isr: box(c, XL - 12, ytop + 2, XR - XL + 24, rh - 6, 26, P["gold2"], 0.35, stroke=P["gold"], sw=5)
        ly = ytop + 38
        rk = f"#{r['rank']}"; rw = font(56, 900).getlength(rk)
        T(c, rk, 56, XL + 6, ly, P["gold_text"] if isr else P["blue"], 1, 1, 900, anchor="l", maxw=200)
        draw_emoji(c, RD.flag_emoji(r["code"]), XL + rw + 50, ly, 58)
        nm = r.get("name") or WNAMES[r["code"]]
        T(c, nm + (f"  ({r['note']})" if r.get("note") else ""), 56, XL + rw + 92, ly, P["navy"], 1, 1, 900, anchor="l", maxw=XR - XL - rw - 100)
        by = ytop + 104; th = 62
        box(c, TX0, by - th / 2, tw_, th, th / 2, P["bg1"], 0.9)
        fw = max(20, tw_ * r["value"] * u / vmax) if r["value"] > 0 else 0
        if fw:
            c.save(); rr(c, TX0, by - th / 2, tw_, th, th / 2); c.clip()
            box(c, TX0, by - th / 2, fw, th, th / 2, P["gold"] if isr else hx(S["color"]), 1.0); c.restore()
        v = r["value"] * u; lab = f"{v:,.0f} L" if (r["value"] >= 1 or r["value"] == 0) else f"{v:.1f} L"
        if font(56, 900).getlength(lab) + 46 < fw: T(c, lab, 56, TX0 + fw - 22, by + 2, P["white"], 1, 1, 900, anchor="r", maxw=400)
        else: T(c, lab, 56, TX0 + fw + 14, by + 2, P["navy"], 1, 1, 900, anchor="l", maxw=400)
        St.a = old
    a4, s4 = PP(t, tm.get("rank", t0 + 2.0), S, bounce=2.6)
    pill(c, S["rank_text"], 60, CX, 1272, P["gold"], P["white"], a4, s4, outline=P["navy"], w=900)
    src_line(c, S.get("source"), fade_in(t, t0 + 0.4, S), y=1350)
    if S.get("source2"): src_line(c, S["source2"], fade_in(t, t0 + 0.4, S), y=1392)

def sc_compare_intro(c, t, S):
    """v4: Israel compared to the world, world rankings for 3 drinks"""
    t0 = S["t0"]; a, s = PP(t, t0 + 0.05, S, bounce=2.2)
    a3, s3 = PP(t, t0 + 0.15, S, bounce=2.6)
    if a3 > 0.01:
        draw_emoji(c, RD.flag_emoji("IL"), CX - 110, 440, 150 * s3, a3); draw_emoji(c, "\U0001F30D", CX + 110, 440, 150 * s3, a3)
    T(c, "Israel", 110, CX, 620, P["gold_text"], a, s, 900, maxw=900)
    T(c, "compared to the world", 80, CX, 740, P["navy"], a, s, 900, hl=P["blue"], maxw=900)
    for k, em in enumerate(("☕", "\U0001F37A", "\U0001F375")):
        a2, s2 = PP(t, t0 + 0.35 + 0.15 * k, S, bounce=2.6)
        if a2 > 0.01: draw_emoji(c, em, CX - 200 + 200 * k, 920, 120 * s2, a2)
    T(c, "Real world rankings", 60, CX, 1080, P["navy"], fade_in(t, t0 + 0.8, S), 1, 900, maxw=900)
