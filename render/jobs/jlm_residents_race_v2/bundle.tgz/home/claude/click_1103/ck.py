# -*- coding: utf-8 -*-
"""ck.py: shared helpers for the 3 Nov click-study reels (scoreboard at frame 0, big English text, narration timing,
burned-in subtitles, loop crossfade into frame 0). Render only: no TTS, no ASR, no network."""
import json, math, os, re, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1080, 1920, 30
HERE = "/home/claude/click_1103"
FONTD = "/home/claude/vid/fonts"
def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY_T, NAVY_B = hx("#0A1530"), hx("#163261")
SKY = hx("#45A4DD"); SKY_L = hx("#7CC3EE"); YEL = hx("#FFD166"); WHITE = hx("#FFFFFF")
SILVER = hx("#C9D3E3"); GREY = hx("#7D8BA3"); GOLD = hx("#C9A24A"); GREEN = hx("#2FBF71"); RED = hx("#E0605E")
_fc = {}
def font(sz, w=800):
    k = (int(round(sz)), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTD}/Heebo-{w}.ttf", k[0])
    return _fc[k]
DASH = re.compile("[‐-―]")
def clean(s):
    assert not DASH.search(s), "dash in on-screen text: " + s
    assert not re.search("[֐-׿]", s), "Hebrew on screen: " + s
    return s
def tw(s, sz, w=800): return font(sz, w).getlength(s)
def fit(s, sz, maxw, w=800, mn=None):
    mn = mn or sz * 0.6
    while tw(s, sz, w) > maxw and sz > mn: sz -= 1
    return sz
def txt(d, x, y, s, sz, col, w=800, anchor="la", alpha=1.0, stroke=0):
    c = col[:3] + (int(col[3] * max(0, min(1, alpha))),)
    kw = dict(stroke_width=stroke, stroke_fill=(5, 12, 28, int(220 * alpha))) if stroke else {}
    d.text((x, y), clean(s), font=font(sz, w), fill=c, anchor=anchor, **kw)
def wrap(s, sz, maxw, w=800):
    words, lines, cur = s.split(), [], ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if tw(t, sz, w) <= maxw or not cur: cur = t
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines
def ease(u): u = max(0.0, min(1.0, u)); return u * u * (3 - 2 * u)

# ------------------------------------------------------------------ timing
class Timing:
    def __init__(self, rid):
        T = json.load(open(f"{HERE}/{rid}/timing.json")); self.dur = T["dur"]; self.lines = T["lines"]
    def norm(self, s): return re.sub(r"[^\w]", "", s.lower())
    def at(self, m):
        """'L' line start, 'L$' line end, 'L:phrase' first word of phrase in line L (1-based)"""
        if isinstance(m, (int, float)) and not isinstance(m, bool): m = str(int(m))
        if m.endswith("$"): return self.lines[int(m[:-1]) - 1]["t1"]
        if ":" not in m: return self.lines[int(m) - 1]["t0"] - 0.1
        L, ph = m.split(":", 1); ws = self.lines[int(L) - 1]["words"]; p = [self.norm(x) for x in ph.split()]
        for i in range(len(ws) - len(p) + 1):
            if all(self.norm(ws[i + j]["w"]) == p[j] for j in range(len(p))): return ws[i]["t0"] - 0.05
        raise KeyError(m)

# ------------------------------------------------------------------ subtitles
def sub_chunks(tim, repl):
    """[(t0, t1, text)] pieces of at most 6 words, split at punctuation, display text via repl (spoken -> shown)"""
    out = []
    for L in tim.lines:
        ws = L["words"]; cur = []
        for i, w in enumerate(ws):
            cur.append(w)
            end = re.search(r"[.,?!;:]$", w["w"]) or len(cur) >= 6 or i == len(ws) - 1
            if end:
                out.append([cur[0]["t0"], cur[-1]["t1"], " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(out) - 1): out[k][1] = min(max(out[k][1] + 0.25, out[k][1]), out[k + 1][0])
    res = []; repl = sorted(repl, key=lambda r: -len(r[0]))
    for a, b, s in out:
        s = s.replace("...", "")
        for x, y in repl: s = re.sub(r"\b" + re.escape(x) + r"\b", y, s)
        s = s.strip(); ws = s.split()
        if tw(s, 54, 800) > 900 and len(ws) > 1:
            h = len(ws) // 2; m = a + (b - a) * len(" ".join(ws[:h])) / len(s)
            res.append((a, m, " ".join(ws[:h]))); res.append((m, b, " ".join(ws[h:])))
        else: res.append((a, b, s))
    return res
SUB_Y = 1556
def draw_sub(im, chunks, t):
    for a, b, s in chunks:
        if a - 0.02 <= t <= b:
            d = ImageDraw.Draw(im); sz = 54; lines = wrap(s, sz, 900, 800)
            wmax = max(tw(l, sz, 800) for l in lines); hh = 66 * len(lines) + 26
            x0, y0 = (W - wmax) / 2 - 28, SUB_Y - hh
            d.rounded_rectangle([x0, y0, x0 + wmax + 56, y0 + hh], 22, fill=(6, 14, 34, 215), outline=SKY[:3] + (200,), width=3)
            for i, l in enumerate(lines): txt(d, W / 2, y0 + 13 + 66 * i + 33, l, sz, WHITE, 800, "mm")
            return

# ------------------------------------------------------------------ stage
_bg = None
def stage():
    global _bg
    if _bg is None:
        r = np.linspace(0, 1, H)[:, None, None]
        a = (np.array(NAVY_T)[None, None, :] * (1 - r) + np.array(NAVY_B)[None, None, :] * r) * np.ones((1, W, 1))
        _bg = Image.fromarray(a.astype(np.uint8), "RGBA")
    return _bg.copy()
def hook(d, lines, t, y=232, sz=104, cols=(WHITE, YEL)):
    for i, s in enumerate(lines):
        z = fit(s, sz, 980, 900, 80); txt(d, W / 2, y + i * sz * 1.08, s, z, cols[i % len(cols)], 900, "ma")
    u = ease(t / 1.0); ul = 260 * u; yy = y + len(lines) * sz * 1.08 + 8
    d.rounded_rectangle([W / 2 - ul, yy, W / 2 + ul, yy + 7], 3, fill=SKY)
    return yy + 20
def source(d, s, y=1576):
    txt(d, W / 2, y, s, fit(s, 36, 1000, 400, 30), SILVER, 400, "ma", 0.95)

# ------------------------------------------------------------------ output
class Out:
    def __init__(self, rid, dur, snaps=None):
        self.rid, self.dur, self.snaps = rid, dur, snaps; self.N = int(round(dur * FPS))
        self.silent = f"{HERE}/{rid}/out/silent.mp4"; self.final = f"{HERE}/{rid}/out/{rid}.mp4"
        os.makedirs(f"{HERE}/{rid}/out", exist_ok=True); self.ff = None; self.f0 = None
        if not snaps:
            self.ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                                        "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", self.silent], stdin=subprocess.PIPE)
    def frames(self):
        if self.snaps:
            for s in self.snaps: yield int(round(s * FPS)), s
        else:
            for f in range(self.N): yield f, f / FPS
    def put(self, f, t, im, loop=0.5):
        rgb = im.convert("RGB")
        if f == 0: self.f0 = rgb.copy()
        if self.f0 is not None and t > self.dur - loop:
            rgb = Image.blend(rgb, self.f0, ease((t - (self.dur - loop)) / loop))
        if self.snaps:
            os.makedirs(f"{HERE}/{self.rid}/snaps", exist_ok=True); rgb.save(f"{HERE}/{self.rid}/snaps/{t:05.2f}.png")
        else: self.ff.stdin.write(rgb.tobytes())
    def close(self):
        if self.snaps: return
        self.ff.stdin.close(); self.ff.wait()
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", self.silent, "-i", f"{HERE}/{self.rid}/audio.m4a", "-map", "0:v", "-map", "1:a",
                        "-c:v", "copy", "-c:a", "copy", "-t", f"{self.dur:.2f}", "-movflags", "+faststart", self.final], check=True)
        os.remove(self.silent); print("final", self.final)
def snaps_arg():
    for a in sys.argv[1:]:
        if a.startswith("--snaps="): return [float(x) for x in a[8:].split(",")]
    return None

# ------------------------------------------------------------------ maps
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
_feat = None
def features():
    global _feat
    if _feat is None:
        _feat = {}
        for f in json.load(open(GEO))["features"]:
            p = f["properties"]; k = p["ADM0_A3"]; g = f["geometry"]
            if p.get("UN_PARENT"):   # UN borders: N. Cyprus, Kosovo, Taiwan, Somaliland are drawn inside their UN member state
                _feat[k] = dict(name=p["NAME"], polys=[], lx=None, ly=None, un_parent=p["UN_PARENT"]); continue
            polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
            _feat[k] = dict(name=p["NAME"], polys=polys, lx=p.get("LABEL_X"), ly=p.get("LABEL_Y"))
    return _feat
class Proj:
    """equirectangular with cos(lat0) x-scale; lon/lat box -> screen rect (x0, y0, x1, y1)"""
    def __init__(self, box, rect, lat0=None):
        self.lo0, self.la0, self.lo1, self.la1 = box; self.r = rect
        self.c = math.cos(math.radians(lat0 if lat0 is not None else (self.la0 + self.la1) / 2))
        sx = (rect[2] - rect[0]) / ((self.lo1 - self.lo0) * self.c); sy = (rect[3] - rect[1]) / (self.la1 - self.la0)
        self.s = min(sx, sy); self.cx = (rect[0] + rect[2]) / 2; self.cy = (rect[1] + rect[3]) / 2
        self.clo = (self.lo0 + self.lo1) / 2; self.cla = (self.la0 + self.la1) / 2
    def __call__(self, lo, la): return (self.cx + (lo - self.clo) * self.c * self.s, self.cy - (la - self.cla) * self.s)
def mask(polys, P, ss=2, clip=None):
    """alpha mask (float32 0..1) of polygons, as (x0, y0, arr); drawn at ss x and reduced (antialiased)"""
    pts_all = []
    for poly in polys:
        for ring in poly[:1]: pts_all.append([P(*q) for q in ring])
    if not pts_all: return None
    xs = [x for r in pts_all for x, _ in r]; ys = [y for r in pts_all for _, y in r]
    x0, y0 = max(0, int(min(xs)) - 2), max(0, int(min(ys)) - 2); x1, y1 = min(W, int(max(xs)) + 3), min(H, int(max(ys)) + 3)
    if clip: x0, y0, x1, y1 = max(x0, clip[0]), max(y0, clip[1]), min(x1, clip[2]), min(y1, clip[3])
    if x1 <= x0 or y1 <= y0: return None
    im = Image.new("L", ((x1 - x0) * ss, (y1 - y0) * ss), 0); d = ImageDraw.Draw(im)
    for poly in polys:
        for j, ring in enumerate(poly):
            q = [((x - x0) * ss, (y - y0) * ss) for x, y in (P(*p) for p in ring)]
            if len(q) > 2: d.polygon(q, fill=255 if j == 0 else 0)
    im = im.resize((x1 - x0, y1 - y0), Image.BOX)
    return (x0, y0, np.asarray(im, np.float32) / 255.0)
def comp(arr, m, col, a=1.0):
    """composite colour col (rgb) into float arr (H, W, 3) through mask m at opacity a"""
    if m is None or a <= 0: return
    x0, y0, A = m; h, w = A.shape; reg = arr[y0:y0 + h, x0:x0 + w]; k = (A * a)[..., None]
    reg *= (1 - k); reg += k * np.array(col[:3], np.float32)
def outline(d, polys, P, col, width=2):
    for poly in polys:
        q = [P(*p) for p in poly[0]]
        if len(q) > 2: d.line(q + [q[0]], fill=col, width=width, joint="curve")
ISRAEL_GOLD = hx("#C9A24A"); PAL_GOLD = hx("#A8853C")
def israel_layer(P, arr, d=None, a=1.0, glow=False):
    """whole land of Israel: Israel gold, West Bank and Gaza a slightly different shade, Green Line in green"""
    F = features()
    comp(arr, mask(F["ISR"]["polys"], P), ISRAEL_GOLD, a); comp(arr, mask(F["PSX"]["polys"], P), PAL_GOLD, a)
def israel_lines(d, P, a=1.0):
    outline(d, features()["PSX"]["polys"], P, GREEN[:3] + (int(255 * a),), 3)
