ID = "jlm_residents_race_v2"
HOOK = ["Who lived in", "Jerusalem?"]
SHAPE = "Every count from 1806 to 2020"
k = 1
G = {
 "Jews":       dict(col="#45A4DD", pts=[(1806,2000),(1844,7120),(1876,13000),(1896,28112),(1922,33971),(1931,51200),(1944,97000),(1967,195700),(1987,340000),(1995,417100),(2011,497000),(2020,570100)]),
 "Muslims":    dict(col="#2FBF71", pts=[(1806,4000),(1844,5000),(1876,15000),(1896,8560),(1922,13413),(1931,19900),(1944,30600),(1967,54963),(1987,121000),(1995,182700),(2011,281000),(2020,353800)]),
 "Christians": dict(col="#B48CF0", pts=[(1806,2774),(1844,3390),(1876,8000),(1896,8748),(1922,14669),(1931,19300),(1944,29400),(1967,12646),(1987,14000),(1995,14100),(2011,14000),(2020,16300)]),
}
KF = [(1806, 0.0), (1844, "2:counts"), (1844, "4"), (1876, "4:finds"), (1876, "5:Then"), (1896, "6:Twenty"), (1922, "7:The"), (1931, "8"), (1944, "8:Ninety"),
      (1967, "9:The"), (1995, "10:By"), (2020, "10:more"), (2020, 99.0)]
def FMT(v): return f"{int(round(v)):,}"
LAYOUT = dict(y0=566, row_h=212, lab=68, bar_t=92, val=66, inline=False, y_year=1200, year_sz=160, y_ev=1384, y_rev=1206, ev_lines=1)
def _tot(vals, y): return f"{int(round(sum(v for v in vals.values() if v))):,}"
def _share(vals, y):
    s = sum(v for v in vals.values() if v); return f"{100 * vals['Jews'] / s:.0f}% Jewish"
SIDE = ("Counted residents", lambda v, y: _tot(v, y))
EVENTS = [("2:counts", "1844: the Prussian consul's count"),
          ("4:finds", "1876: another count, more Muslims"), ("5:Then", "Building beyond the Old City walls"),
          ("7:The", "1922: first British census"), ("9:The", "1967: city reunited, new borders"),
          ("10:more", "2020: about 951,000 residents"), ("14:In", "2022: 1,005,900 residents")]
REVEALS = [("12:A", "13", ["Jewish majority in every", "census for 100+ years"]),
           ("13:And", "14", ["About 4 in 10 are Arab", "Almost 400,000 people (2022)"])]
SRC = "Source: Wikipedia, Demographic history of Jerusalem"
SRC_BY_YEAR = [(1806, "Count: U. J. Seetzen 1806 (via Wikipedia). City borders change over time."),
               (1844, "Count: E. G. Schultz, Prussian consul, 1844 (via Wikipedia)"),
               (1876, "Count: B. Neumann 1876; Calendar of Palestine 1896 (via Wikipedia)"),
               (1922, "British censuses 1922, 1931; 1944 estimate (Harrel and Stendel 1974)"),
               (1967, "1967: Harrel 1974. Later: Jerusalem Municipality, Israel CBS"),
               (2011, "Israel CBS; Jerusalem Institute for Policy Research (JIPR) 2020"),
               (2020, "JIPR 2020 table; 2022: JIPR Statistical Yearbook 2024")]
SUBS = [("Eighteen forty four", "1844"), ("Seven thousand", "7,000"), ("Five thousand", "5,000"), ("Three thousand", "3,000"),
        ("Thirty years", "30 years"), ("Eighteen ninety six", "1896"), ("Twenty eight thousand", "28,000"), ("forty five thousand", "45,000"),
        ("Nineteen twenty two", "1922"), ("Nineteen forty four", "1944"), ("Ninety seven thousand", "97,000"), ("Nineteen sixty seven", "1967"),
        ("twenty twenty two", "2022"), ("twenty twenty", "2020"), ("nine hundred thousand", "900,000"), ("a hundred years", "100 years"),
        ("six in ten", "6 in 10"), ("four in ten", "4 in 10"), ("four hundred thousand", "400,000"), ("one million", "1 million")]
