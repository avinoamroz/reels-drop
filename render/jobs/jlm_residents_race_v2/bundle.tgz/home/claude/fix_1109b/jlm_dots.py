# -*- coding: utf-8 -*-
"""Jerusalem map with population dots for jlm_residents_race_v2 (Noam 3 Nov: '[0:23] map of jerusalem and dots of the jews and arabs').
Dots follow the race values of the current year: 1 dot = 5,000 people, placed by neighbourhood (illustrative).
Border: Jerusalem municipality polygon (israel-municipalities-polygons); East Jerusalem and the 1949 line: Natural Earth 10m disputed areas."""
import json, math, random
import numpy as np
from PIL import Image, ImageDraw
from ck import *
GD = "/home/claude/fix_1109b/geo"
PER = 5000
MR = (36, 584, 600, 1150)                        # map rect
BOX = (35.079, 31.703, 35.273, 31.890)
P = Proj(BOX, MR, lat0=31.78)
def _polys(fn, names=None):
    out = []
    for f in json.load(open(f"{GD}/{fn}"))["features"]:
        if names and (f["properties"].get("NAME") not in names): continue
        g = f["geometry"]; out += [g["coordinates"]] if g["type"] == "Polygon" else g["coordinates"]
    return out
CITY = _polys("jlm.geojson"); EJ = _polys("ej.geojson", ("East Jerusalem",)); WB = _polys("ej.geojson", ("West Bank",))
NML = _polys("ej.geojson", ("No Man's Land (Jerusalem)",))
# neighbourhood anchors: (lon, lat, weight, [(from, to)]) per group
NB = {
 "Jews": [(35.2315, 31.7755, 3, [(1806, 1948), (1967, 2100)]), (35.2215, 31.7875, 4, [(1875, 2100)]), (35.2100, 31.7835, 4, [(1875, 2100)]),
          (35.2170, 31.7810, 3, [(1890, 2100)]), (35.2120, 31.7745, 3, [(1920, 2100)]), (35.1920, 31.7790, 3, [(1922, 2100)]),
          (35.2180, 31.7520, 3, [(1922, 2100)]), (35.2000, 31.7890, 3, [(1922, 2100)]), (35.2050, 31.7630, 4, [(1948, 2100)]),
          (35.1750, 31.7650, 5, [(1950, 2100)]), (35.1830, 31.7880, 5, [(1950, 2100)]), (35.1850, 31.7680, 4, [(1950, 2100)]),
          (35.1630, 31.7570, 4, [(1955, 2100)]), (35.1900, 31.7520, 3, [(1955, 2100)]), (35.2300, 31.8030, 5, [(1969, 2100)]),
          (35.1860, 31.7330, 7, [(1972, 2100)]), (35.2430, 31.8430, 5, [(1972, 2100)]), (35.1980, 31.8180, 9, [(1975, 2100)]),
          (35.2320, 31.7520, 4, [(1975, 2100)]), (35.2400, 31.8270, 8, [(1985, 2100)]), (35.2180, 31.8080, 5, [(1995, 2100)]),
          (35.2220, 31.7220, 5, [(2000, 2100)])],
 "Muslims": [(35.2330, 31.7795, 4, [(1806, 2100)]), (35.2300, 31.7910, 4, [(1880, 2100)]), (35.2370, 31.7690, 5, [(1900, 2100)]),
             (35.2240, 31.7840, 2, [(1900, 1948)]), (35.2140, 31.7600, 2, [(1910, 1948)]), (35.2450, 31.7780, 4, [(1967, 2100)]),
             (35.2430, 31.7670, 4, [(1967, 2100)]), (35.2180, 31.8300, 7, [(1967, 2100)]), (35.2290, 31.8170, 7, [(1967, 2100)]),
             (35.2490, 31.8120, 4, [(1967, 2100)]), (35.2540, 31.7970, 4, [(1967, 2100)]), (35.2400, 31.7520, 5, [(1967, 2100)]),
             (35.2320, 31.7370, 6, [(1967, 2100)]), (35.1970, 31.7480, 3, [(1967, 2100)]), (35.2220, 31.8680, 6, [(1967, 2100)])],
 "Christians": [(35.2285, 31.7785, 5, [(1806, 2100)]), (35.2120, 31.7640, 4, [(1890, 1948)]), (35.2250, 31.7845, 2, [(1890, 1948)]),
                (35.2180, 31.8300, 2, [(1967, 2100)])],
}
def _inside(lo, la):
    for poly in CITY:
        r = poly[0]; c = False; j = len(r) - 1
        for i in range(len(r)):
            xi, yi = r[i][:2]; xj, yj = r[j][:2]
            if ((yi > la) != (yj > la)) and (lo < (xj - xi) * (la - yi) / (yj - yi + 1e-12) + xi): c = not c
            j = i
        if c: return True
    return False
rnd = random.Random(7); SLOTS = {}; SG = {"Jews": 1.5, "Muslims": 1.0, "Christians": 1.0}
for g in ("Christians", "Muslims", "Jews"):
    L = NB[g]; s = []
    for k, (lo, la, w, rng) in enumerate(L):
        n = w * {"Jews": 3, "Muslims": 4, "Christians": 3}[g]
        got = 0; tries = 0
        while got < n and tries < 4000:
            tries += 1; a, b = lo + rnd.gauss(0, 0.0075 * SG[g]), la + rnd.gauss(0, 0.0065 * SG[g])
            x, y = P(a, b)
            if not _inside(a, b): continue
            if any((x - q[0]) ** 2 + (y - q[1]) ** 2 < 14 ** 2 for gg in list(SLOTS.values()) + [s] for q in gg): continue
            s.append((x, y, rng, k, got)); got += 1
    s.sort(key=lambda q: (q[4], q[3]))     # round robin across neighbourhoods; only those built by that year are used
    SLOTS[g] = s
def _ok(rng, y): return any(a <= y < b for a, b in rng)
_base = None
def base():
    global _base
    if _base is None:
        arr = np.zeros((H, W, 3), np.float32); arr[:] = (12, 24, 52)
        comp(arr, mask(WB, P, 2, MR), (34, 50, 80), 1.0)
        comp(arr, mask(CITY, P, 2, MR), hx("#26385C"), 1.0)
        comp(arr, mask(EJ, P, 2, MR), hx("#33405F"), 1.0)
        im = Image.fromarray(arr.clip(0, 255).astype(np.uint8)).convert("RGBA")
        d = ImageDraw.Draw(im)
        for poly in CITY: d.line([P(*p[:2]) for p in poly[0]] + [P(*poly[0][0][:2])], fill=(150, 170, 205, 255), width=3)
        # 1949 line: western edge of East Jerusalem, drawn in green
        for poly in EJ + NML: d.line([P(*p[:2]) for p in poly[0]] + [P(*poly[0][0][:2])], fill=GREEN[:3] + (255,), width=4)
        m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).rounded_rectangle(MR, 28, fill=255)
        crop = Image.new("RGBA", (W, H), (0, 0, 0, 0)); crop.paste(im, (0, 0), m)
        ImageDraw.Draw(crop).rounded_rectangle(MR, 28, outline=SKY[:3] + (200,), width=3)
        ox, oy = P(35.2340, 31.7770); od = ImageDraw.Draw(crop)
        od.line([(ox, oy), (ox - 30, oy + 150)], fill=WHITE, width=3); txt(od, ox - 30, oy + 178, "Old City", 38, WHITE, 800, "mm", stroke=4)
        gx, gy = MR[0] + 30, MR[1] + 40; od.line([(gx, gy), (gx + 50, gy)], fill=GREEN[:3] + (255,), width=5); txt(od, gx + 62, gy, "1949 line", 38, GREEN, 800, "lm", stroke=4)
        _base = crop
    return _base
A0, A1 = "8", "11"
def alpha(t, T):
    a, b = T.at(A0) - 0.45, T.at(A1) - 0.35
    return max(0.0, min(1.0, (t - a) / 0.4, (b - t) / 0.4))
COL = {"Jews": "#45A4DD", "Muslims": "#2FBF71", "Christians": "#B48CF0"}
def draw(im, t, y, vals, a, G):
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    ld.rectangle([0, MR[1] - 12, W, MR[3] + 12], fill=(10, 22, 50, 255))
    lay.alpha_composite(base()); ld = ImageDraw.Draw(lay)
    for g, s in SLOTS.items():
        v = vals.get(g) or 0.0; n = v / PER
        ok = [q for q in s if _ok(q[2], y)]
        for i, (x, yy, _, _, _) in enumerate(ok):
            if i >= math.ceil(n): break
            f = min(1.0, n - i) if i == math.ceil(n) - 1 else 1.0
            r = 8.5 * (0.4 + 0.6 * f); c = hx(COL[g])
            ld.ellipse([x - r, yy - r, x + r, yy + r], fill=c[:3] + (int(255 * f),), outline=(255, 255, 255, int(150 * f)), width=1)
    # legend (right column)
    X = 640; Y = 600
    txt(ld, X, Y, "Jerusalem", 60, WHITE, 900, "la"); Y += 100
    for g in ("Jews", "Muslims", "Christians"):
        v = vals.get(g) or 0.0; c = hx(COL[g])
        ld.ellipse([X, Y + 14, X + 34, Y + 48], fill=c, outline=WHITE, width=2)
        txt(ld, X + 50, Y + 30, g, 58, c, 800, "lm"); txt(ld, X + 2, Y + 96, f"{int(round(v)):,}", 64, WHITE, 900, "lm"); Y += 160
    lay.putalpha(Image.fromarray((np.asarray(lay.split()[3], np.float32) * a).astype(np.uint8)))
    im.alpha_composite(lay)
def label(d, a):
    s = "1 dot = 5,000 people, placed by neighbourhood (illustrative)"
    txt(d, W / 2, 1168, s, fit(s, 38, 1000, 700, 36), SILVER, 700, "ma", a)
    s2 = "Map: Jerusalem municipal border today; 1949 line: Natural Earth"
    txt(d, W / 2, 1622, s2, fit(s2, 36, 1000, 400, 36), SILVER, 400, "ma", a)
