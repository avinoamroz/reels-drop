"""Beat sheet for the express_method reel. narration.txt has one line per entry here, in this order.
To change the script: edit the line in narration.txt, and (if the meaning changed) the on-screen captions below.
To add or drop a beat: add or drop BOTH the narration line and the entry here (align.py and render.py read this file).

scene: which picture runs under the line. Stages run across all their beats:
  hook   = giant highway, day one (the first 1 s is the hook caption, then the title caption)
  freeze = same highway, you freeze
  P, N, C, H = parking lot, neighborhood, city, highway (the world zooms out at the first beat of each stage)
  map    = the four stages as one route      cta = end card
cap: on-screen captions [(fraction of the beat when it appears, English, Hebrew)]
"""
BEATS = [
    dict(key="hook", scene="hook", cap=[
        (0.0, "Speaking English with Americans on day one?", "לדבר אנגלית עם אמריקאים כבר ביום הראשון?"),
        (1.0, "It's like learning to drive on the highway", "זה כמו ללמוד לנהוג על הכביש המהיר")]),   # 1.0 here = seconds: hook caption is 1 s max
    dict(key="freeze", scene="freeze", cap=[
        (0.0, "Fast. Scary. You freeze.", "מהיר. מפחיד. ואתה קופא."),
        (0.52, "So we never start here", "אז אנחנו לא מתחילים כאן")]),
    dict(key="park1", scene="P", cap=[
        (0.0, "Nobody bothers you", "אף אחד לא מפריע לך"),
        (0.5, "Just you and the car", "רק אתה והרכב")]),
    dict(key="park2", scene="P", cap=[
        (0.0, "You get used to it", "מתרגלים"),
        (0.35, "Then you lift your head and look around", "ואז מרימים את הראש ומסתכלים מסביב")]),
    dict(key="hood1", scene="N", cap=[
        (0.0, "People, one at a time", "אנשים, אחד בכל פעם"),
        (0.62, "A coach, a buddy, a colleague", "מאמן, באדי, קולגה")]),
    dict(key="hood2", scene="N", cap=[
        (0.0, "Every conversation teaches you something", "כל שיחה מלמדת משהו"),
        (0.5, "Five, six, seven conversations", "חמש, שש, שבע שיחות")]),
    dict(key="city", scene="C", cap=[
        (0.0, "Many cars at once, medium speed", "הרבה רכבים בבת אחת, מהירות בינונית"),
        (0.55, "Again and again, in different places", "שוב ושוב, במקומות שונים")]),
    dict(key="highway", scene="H", cap=[
        (0.0, "Still fast, but almost automatic", "עדיין מהיר, אבל כמעט אוטומטי"),
        (0.5, "Talk and respond without thinking", "מדברים ומגיבים בלי לחשוב")]),
    dict(key="close", scene="map", cap=[
        (0.0, "That's how we coach at English Express", "ככה אנחנו מאמנים באינגליש אקספרס")],
        names=[0.47, 0.60, 0.72, 0.84]),        # when each stage name is spoken (fraction of the line)
    dict(key="cta", scene="cta", cap=[]),
]
KEYS = [b["key"] for b in BEATS]

# the four stages: Noam's method names only
STAGES = [("P", "PARKING LOT", "מגרש חנייה"), ("N", "NEIGHBORHOOD", "שכונה"), ("C", "CITY", "עיר"), ("H", "HIGHWAY", "כביש מהיר")]

# speech bubbles get more complex stage by stage
BUBBLES_P = ["Hi.", "Hi, nice to meet you."]
CONVOS_N = [  # (label, you, them)
    ("coach", "How was your weekend?", "Great! We went north."),
    ("buddy", "Want to grab a coffee?", "Sure, let's go!"),
    ("colleague", "How's the project going?", "Almost done!"),
    ("neighbor", "Nice weather today!", "Finally, right?"),
    ("friend", "Did you see the game?", "What a finish!"),
    ("client", "Thanks for your patience.", "No problem at all."),
    ("manager", "Can we talk tomorrow?", "Sure, 10 works."),
]
MEETING_C = [  # (speaker, line): "you" or a label
    ("you", "Let's go over the numbers."),
    ("client", "Can we launch in Q3?"),
    ("team", "If we move fast, yes."),
    ("you", "Then let's lock it in."),
]
PITCH_H = [
    ("you", "Here's our plan to win this market."),
    ("investor", "Love it. Who's leading?"),
    ("you", "I am. Let's start Monday."),
]
HOOK_TRUCKS = ["LET'S CIRCLE BACK", "QUICK SYNC?", "BALLPARK IT", "TOUCH BASE", "ASAP"]
