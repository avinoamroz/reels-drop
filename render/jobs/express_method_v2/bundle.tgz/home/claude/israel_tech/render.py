#!/usr/bin/env python3
"""10 Israeli technologies the whole world uses: vertical reel renderer for @noamroz__.

Timing is driven by narration.txt (one line per beat: hook, title, 10 items, CTA).

  python3 render.py                       music-only v1, timing estimated from narration.txt word counts
  python3 render.py --vo DIR              re-time to per-line clips DIR/<key>.wav (keys: hook,title,i01..i10,cta)
  python3 render.py --vo noam.wav         re-time to ONE narration file: split at its 12 longest pauses
                                          into the 13 narration lines, original timing kept
  python3 render.py --frames 0.5,3,10     save check/f_<t>.png and print the timeline, no encode
  --out FILE                              output path (default israel_tech_v1.mp4, or israel_tech_vo.mp4 with --vo)

Hebrew is shaped with Pillow's RAQM layout and direction="rtl" (same approach as names/render.py and
hatikvah/render_v2.py). Every icon is drawn here with PIL shapes; no logos, no photos.
"""
import sys, os, math, json, argparse, subprocess, re, time
import numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("--vo", default=None)
ap.add_argument("--out", default=None)
ap.add_argument("--frames", default=None)
ap.add_argument("--cues", default=None, help="with a single --vo file: cues.json from align.py (ASR split) instead of the longest-pause split")
ap.add_argument("--gap", type=float, default=None, help="with a single --vo file: re-lay the lines with this break in seconds (default: keep the recording's own timing)")
ap.add_argument("--wps", type=float, default=3.3, help="words per second for the estimated (no voice) timing")
A = ap.parse_args()

W, H, FPS, SR = 1080, 1920, 30, 44100
CX = W / 2
FD = "/home/claude/quran/fonts/"
_FC = {}
def F(w, s):
    k = (w, int(s))
    if k not in _FC: _FC[k] = ImageFont.truetype(FD + f"Heebo-{w}.ttf", int(s), layout_engine=ImageFont.Layout.RAQM)
    return _FC[k]
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
NAVY0, NAVY1 = hx("#070F22"), hx("#0E1D3D")
WHITE, MUTED, DIM = hx("#F5F7FA"), hx("#93A4C0"), hx("#56688A")
PANEL, PANEL2 = hx("#16264A"), hx("#22355F")
ACC = hx("#3EC8FF")          # the one accent colour

def clamp(x): return max(0.0, min(1.0, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def smooth(x): x = clamp(x); return x * x * (3 - 2 * x)
def is_he(s): return any("֐" <= c <= "׿" for c in s)

# ------------------------------------------------------------------ content
ITEMS = [
 dict(key="i01", icon="chip", name="Intel chips", he="שבבי אינטל", what="The 8088, brain of the first IBM PC",
      pill="DESIGNED IN HAIFA  ·  1979", big="Almost every PC", sub="runs on a CPU descended from the 8088", src="IEEE Spectrum, Chip Hall of Fame"),
 dict(key="i02", icon="phone", name="Phone zoom", he="זום במצלמת הטלפון", what="Dual lens and periscope zoom",
      pill="COREPHOTONICS, TEL AVIV  ·  2012", big="Bought by Samsung", sub="in 2019, with about 150 patents filed", src="Calcalist, SamMobile (2019)"),
 dict(key="i03", icon="usb", name="USB flash drive", he="דיסק און קי", what="DiskOnKey, one of the very first",
      pill="M SYSTEMS, ISRAEL  ·  2000", big="$1.55 billion", sub="what SanDisk paid for M Systems in 2006", src="Computer History Museum, Globes"),
 dict(key="i04", icon="pin", name="Waze", he="וייז", what="Crowdsourced traffic navigation",
      pill="FREEMAP ISRAEL  ·  2006", big="151 million", sub="people using it every month (2022)", src="Thurrott, Wikipedia"),
 dict(key="i05", icon="car", name="Mobileye", he="מובילאיי", what="Camera based driver assistance",
      pill="FOUNDED IN ISRAEL  ·  1999", big="200 million+", sub="vehicles with its chips on board", src="Mobileye annual report 2024"),
 dict(key="i06", icon="shield", name="The firewall", he="חומת אש", what="Check Point's stateful inspection",
      pill="RAMAT GAN  ·  1993", big="100,000+", sub="organizations protected", src="Check Point, Wikipedia"),
 dict(key="i07", icon="chat", name="ICQ", he="אייסיקיו", what="Instant messaging for everyone",
      pill="MIRABILIS, ISRAEL  ·  1996", big="100 million+", sub="registered accounts by 2001", src="Wikipedia, ICQ"),
 dict(key="i08", icon="drip", name="Drip irrigation", he="השקיה בטפטוף", what="Water dripped straight to the roots",
      pill="NETAFIM, KIBBUTZ HATZERIM  ·  1965", big="110 countries", sub="and over 30% of the global drip market", src="Netafim, Wikipedia"),
 dict(key="i09", icon="capsule", name="PillCam", he="גלולת מצלמה", what="A camera you swallow",
      pill="GIVEN IMAGING, ISRAEL  ·  2001", big="60+ countries", sub="1 million capsules sold by 2009", src="Wikipedia, Given Imaging"),
 dict(key="i10", icon="molecule", name="Copaxone", he="קופקסון", what="A multiple sclerosis treatment",
      pill="WEIZMANN INSTITUTE  ·  1996", big="$4.3 billion", sub="in global sales in 2013 alone", src="Weizmann Institute, Globes"),
]
KEYS = ["hook", "title"] + [it["key"] for it in ITEMS] + ["cta"]
NARR = [l.strip() for l in open(os.path.join(HERE, "narration.txt"), encoding="utf8") if l.strip()]
assert len(NARR) == len(KEYS), (len(NARR), len(KEYS))
BYKEY = {it["key"]: it for it in ITEMS}

# ------------------------------------------------------------------ timeline
LEAD, GAP, TAIL, HOOK_MAX = 0.10, 0.35, 2.4, 1.0
def load_audio(p):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)

def spoken_units(line):
    n = 0.0
    for w in line.split():
        d = re.sub(r"[^\d]", "", w)
        if not d: n += 1; continue
        v = int(d)
        n += 1 if v < 20 else 1.6 if v < 100 else 2.6 if v < 1000 else 3 if (1100 <= v <= 2099 and "," not in w) else 3.2
    return n + 0.35 * len(re.findall(r"[.?!]", line))

def split_single(x):
    """Find the 12 longest pauses in one narration file -> 13 (v0, v1) speech spans."""
    hop = int(0.02 * SR); n = len(x) // hop
    rms = np.sqrt(np.mean(x[:n * hop].reshape(n, hop) ** 2, 1) + 1e-12)
    db = 20 * np.log10(rms / (rms.max() + 1e-12))
    sil = db < -38
    runs = []; i = 0
    while i < n:
        if sil[i]:
            j = i
            while j < n and sil[j]: j += 1
            runs.append((i, j)); i = j
        else: i += 1
    first = int(np.argmax(~sil)); last = n - int(np.argmax(~sil[::-1]))
    inner = [(a, b) for a, b in runs if a > first and b < last]
    need = len(KEYS) - 1
    if len(inner) < need: sys.exit(f"only {len(inner)} pauses found in the voice file, need {need}")
    cut = sorted(sorted(inner, key=lambda r: r[1] - r[0], reverse=True)[:need])
    edges = [first] + [v for a, b in cut for v in (a, b)] + [last]
    return [(edges[2 * k] * hop / SR, edges[2 * k + 1] * hop / SR) for k in range(len(KEYS))]

VOICE = None          # mono voice track on the final timeline, or None for music-only
if A.vo and os.path.isdir(A.vo):
    segs, t = [], 0.05
    for k in KEYS:
        p = os.path.join(A.vo, f"{k}.wav")
        if not os.path.exists(p): sys.exit(f"missing voice clip {p}")
        x = load_audio(p); segs.append(dict(key=k, v0=t, v1=t + len(x) / SR, x=x)); t += len(x) / SR + GAP
    TT = segs[-1]["v1"] + TAIL
    VOICE = np.zeros(int((TT + 0.3) * SR))
    for s in segs: i = int(s["v0"] * SR); VOICE[i:i + len(s["x"])] += s["x"]
elif A.vo:
    x = load_audio(A.vo)
    if A.cues:
        C = {c["key"]: c for c in json.load(open(A.cues))}; spans = [(C[k]["v0"], C[k]["v1"]) for k in KEYS]
    else:
        spans = split_single(x)
    if A.gap is None:
        off = 0.05 - spans[0][0]                              # voice starts at 0.05 s, recording timing kept
        segs = [dict(key=k, v0=a + off, v1=b + off) for k, (a, b) in zip(KEYS, spans)]
        TT = segs[-1]["v1"] + TAIL
        VOICE = np.zeros(int((TT + 0.3) * SR)); src = x[max(0, int(-off * SR)):]
        i0 = max(0, int(off * SR)); L = min(len(src), len(VOICE) - i0); VOICE[i0:i0 + L] = src[:L]
    else:
        segs, t, clips = [], 0.05, []
        for k, (a, b) in zip(KEYS, spans):
            c = x[int(max(0, a - 0.04) * SR):int((b + 0.08) * SR)].copy(); f = int(0.02 * SR)
            c[:f] *= np.linspace(0, 1, f); c[-f:] *= np.linspace(1, 0, f)
            segs.append(dict(key=k, v0=t + 0.04, v1=t + 0.04 + (b - a))); clips.append((t, c)); t += len(c) / SR + A.gap
        TT = segs[-1]["v1"] + TAIL
        VOICE = np.zeros(int((TT + 0.3) * SR))
        for t0, c in clips: i = int(t0 * SR); VOICE[i:i + len(c)] += c[:len(VOICE) - i]
else:
    segs, t = [], 0.05
    for k, line in zip(KEYS, NARR):
        d = spoken_units(line) / A.wps + 0.2
        segs.append(dict(key=k, v0=t, v1=t + d)); t += d + GAP
    TT = segs[-1]["v1"] + TAIL
SEG = {s["key"]: s for s in segs}

# card schedule: hook 0..1 s, title until item 1, item cards on their lines, end card on the CTA
SCHED = [(0.0, "hook"), (min(HOOK_MAX, SEG["title"]["v0"]), "title")]
for k in KEYS[2:]: SCHED.append((SEG[k]["v0"] - LEAD, k))
STARTS = [s for s, _ in SCHED] + [TT]
def at(t):
    for i in range(len(SCHED) - 1, -1, -1):
        if SCHED[i][0] <= t: return SCHED[i][1], t - SCHED[i][0], STARTS[i + 1] - SCHED[i][0]
    return "hook", t, STARTS[1]
NF = int(round(TT * FPS))

# ------------------------------------------------------------------ text sprites
_TC = {}
def timg(s, w, size, col, shadow=False):
    k = (s, w, int(size), col, shadow)
    if k in _TC: return _TC[k]
    f = F(w, size); kw = dict(direction="rtl", language="he") if is_he(s) else {}
    dd = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    tw = int(dd.textlength(s, font=f, **kw)) + 40; th = int(f.size * 1.6)
    im = Image.new("RGBA", (tw, th), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((tw / 2, th / 2), s, font=f, fill=col + (255,), anchor="mm", **kw)
    if shadow:
        sh = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        ImageDraw.Draw(sh).text((tw / 2, th / 2 + 5), s, font=f, fill=(0, 4, 14, 160), anchor="mm", **kw)
        sh = sh.filter(ImageFilter.GaussianBlur(8)); sh.alpha_composite(im); im = sh
    _TC[k] = im; return im
def tw_(s, w, size): return timg(s, w, size, WHITE).width - 40
def fitsize(s, w, size, maxw):
    while tw_(s, w, size) > maxw and size > 20: size -= 2
    return size
def put(dst, im, cx, cy, alpha=1.0, scale=1.0):
    if alpha <= 0.01: return
    if abs(scale - 1) > 0.004:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BICUBIC)
    if alpha < 0.99:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im = im.copy(); im.putalpha(a)
    dst.paste(im, (int(round(cx - im.width / 2)), int(round(cy - im.height / 2))), im)
def txt(dst, s, w, size, col, cx, cy, alpha=1.0, scale=1.0, shadow=False, maxw=960):
    size = fitsize(s, w, size, maxw); put(dst, timg(s, w, size, col, shadow), cx, cy, alpha, scale)

# ------------------------------------------------------------------ background
def make_bg():
    yy, xx = np.mgrid[0:H, 0:W]; g = (yy / H)[..., None]
    b = np.array(NAVY0) * (1 - g) + np.array(NAVY1) * g
    b = b + np.exp(-(((xx - CX) / 640) ** 2 + ((yy - 600) / 620) ** 2))[..., None] * np.array([14, 30, 58])
    b = b * (1 - 0.25 * np.clip(((xx - CX) / (W * 0.8)) ** 2 + ((yy - H / 2) / (H * 0.65)) ** 2, 0, 1))[..., None]
    return Image.fromarray(np.clip(b, 0, 255).astype(np.uint8), "RGB")
BG = make_bg()

# ------------------------------------------------------------------ dotted world map
MAP_W, LON0, LON1, LAT0, LAT1 = 900, -170.0, 190.0, -56.0, 76.0
MAP_H = int(MAP_W * (LAT1 - LAT0) / (LON1 - LON0))
def land_mask():
    t = json.load(open("/home/claude/geo/package/countries-50m.json")); sc, tr = t["transform"]["scale"], t["transform"]["translate"]
    arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    m = Image.new("L", (MAP_W * 2, MAP_H * 2), 0); d = ImageDraw.Draw(m)
    def P(lon, lat): return ((lon - LON0) / (LON1 - LON0) * MAP_W * 2, (LAT1 - lat) / (LAT1 - LAT0) * MAP_H * 2)
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        polys = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]
        for poly in polys:
            ring = []
            for i in poly[0]: ring.extend(arc(i))
            if len(ring) < 3: continue
            for shift in (0, 360):
                d.polygon([P(lo + shift, la) for lo, la in ring], fill=255)
    return np.array(m.resize((MAP_W, MAP_H), Image.BILINEAR)) > 100
MASK = land_mask()
STEP = 14
DOTS = [(x, y) for y in range(STEP // 2, MAP_H, STEP) for x in range(STEP // 2, MAP_W, STEP) if MASK[y, x]]
def mp(lon, lat): return ((lon - LON0) / (LON1 - LON0) * MAP_W, (LAT1 - lat) / (LAT1 - LAT0) * MAP_H)
ISR = mp(34.9, 31.5)
_rng = np.random.default_rng(7)
_far = [p for p in DOTS if math.hypot(p[0] - ISR[0], p[1] - ISR[1]) > 60]
_order = list(_rng.permutation(len(_far)))
PER = 26
LIT = [[_far[i] for i in _order[k * PER:(k + 1) * PER]] for k in range(10)]   # decorative: new dots per item
def map_base():
    im = Image.new("RGBA", (MAP_W, MAP_H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for x, y in DOTS: d.ellipse([x - 2.6, y - 2.6, x + 2.6, y + 2.6], fill=DIM + (150,))
    return im
MAPBASE = map_base()
MAP_X0 = int(CX - MAP_W / 2)

def bez(p0, p2, u):
    mx, my = (p0[0] + p2[0]) / 2, min(p0[1], p2[1]) - 40 - 0.25 * abs(p2[0] - p0[0])
    return ((1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * mx + u * u * p2[0], (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * my + u * u * p2[1])

def draw_map(im, cy, t, n_done, new_k=None, el=0.0, alpha=1.0):
    """n_done: items fully lit; new_k: item index whose dots arc in now (el = seconds into that card)."""
    if alpha <= 0.01: return
    lay = MAPBASE.copy(); d = ImageDraw.Draw(lay)
    for k in range(n_done):
        for x, y in LIT[k]: d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=ACC + (150,))
    if new_k is not None:
        for j, p in enumerate(LIT[new_k]):
            u = clamp((el - 0.35 - j * 0.035) / 0.55)
            if u <= 0: continue
            if u < 1:
                pts = [bez(ISR, p, v * u) for v in np.linspace(0, 1, 14)]
                d.line(pts, fill=ACC + (int(120 * (1 - u * 0.5)),), width=2)
            else:
                pop = 1 + 0.8 * max(0, 1 - (el - 0.9 - j * 0.035) / 0.3)
                r = 3.2 * pop; d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=ACC + (235,))
    pr = 9 + 5 * (0.5 + 0.5 * math.sin(t * 4))
    d.ellipse([ISR[0] - pr * 2.2, ISR[1] - pr * 2.2, ISR[0] + pr * 2.2, ISR[1] + pr * 2.2], outline=ACC + (90,), width=2)
    d.ellipse([ISR[0] - 7, ISR[1] - 7, ISR[0] + 7, ISR[1] + 7], fill=WHITE + (255,))
    if alpha < 0.99: lay.putalpha(lay.getchannel("A").point(lambda v: int(v * alpha)))
    im.paste(lay, (MAP_X0, int(cy - MAP_H / 2)), lay)

# ------------------------------------------------------------------ icons (drawn at 2x, then downscaled)
S2 = 880; C2 = S2 / 2
def rr(d, box, r, **kw): d.rounded_rectangle(box, radius=r, **kw)
def A_(c, a): return c + (int(255 * clamp(a)),)

def ic_chip(d, t, lay):
    rr(d, [250, 250, 630, 630], 46, fill=PANEL, outline=WHITE, width=10)
    for k in range(6):
        o = 290 + k * 60
        for box in ([o - 12, 170, o + 12, 250], [o - 12, 630, o + 12, 710], [170, o - 12, 250, o + 12], [630, o - 12, 710, o + 12]):
            rr(d, box, 8, fill=WHITE)
    g = 0.55 + 0.45 * math.sin(t * 3)
    rr(d, [330, 330, 550, 550], 26, fill=PANEL2, outline=A_(ACC, 0.6 + 0.4 * g), width=8)
    for k in range(4):                       # signal pulses travelling out along the pins
        u = (t * 0.9 + k * 0.25) % 1; o = 290 + ((k * 2 + 1) % 6) * 60
        y = 250 - u * 80; d.ellipse([o - 9, y - 9, o + 9, y + 9], fill=A_(ACC, 1 - u))
        x = 630 + u * 80; o2 = 290 + ((k * 3 + 2) % 6) * 60; d.ellipse([x - 9, o2 - 9, x + 9, o2 + 9], fill=A_(ACC, 1 - u))
    f = F(900, 64); d.text((C2, C2), "8088", font=f, fill=WHITE, anchor="mm")

def ic_phone(d, t, lay):
    rr(d, [255, 110, 625, 770], 70, fill=PANEL, outline=WHITE, width=10)
    rr(d, [290, 150, 500, 360], 56, fill=PANEL2)
    lens = [(350, 210, 44), (440, 300, 44), (350, 300, 34)]
    for k, (x, y, r) in enumerate(lens):
        d.ellipse([x - r, y - r, x + r, y + r], fill=(8, 14, 30), outline=WHITE, width=6)
        d.ellipse([x - r * 0.45, y - r * 0.45, x + r * 0.45, y + r * 0.45], fill=A_(ACC, 0.85))
    d.ellipse([445 - 14, 210 - 14, 445 + 14, 210 + 14], fill=WHITE)
    z = (t * 0.6) % 1                        # zoom rings radiate from the tele lens
    for k in range(3):
        u = (z + k / 3) % 1; r = 50 + u * 230
        d.ellipse([440 - r, 300 - r, 440 + r, 300 + r], outline=A_(ACC, 0.55 * (1 - u)), width=5)
    lv = ["1x", "2x", "5x"][int(t * 1.2) % 3]
    rr(d, [370, 610, 510, 690], 40, fill=A_(ACC, 1)); d.text((440, 650), lv, font=F(900, 52), fill=NAVY0, anchor="mm")

def ic_usb(d, t, lay):
    tmp = Image.new("RGBA", (S2, S2), (0, 0, 0, 0)); e = ImageDraw.Draw(tmp)
    rr(e, [170, 350, 560, 530], 50, fill=PANEL, outline=WHITE, width=10)
    rr(e, [555, 375, 745, 505], 10, fill=PANEL2, outline=WHITE, width=10)
    for y in (410, 450):
        rr(e, [610, y, 640, y + 26], 4, fill=WHITE); rr(e, [670, y, 700, y + 26], 4, fill=WHITE)
    blink = 0.25 + 0.75 * (0.5 + 0.5 * math.sin(t * 6))
    e.ellipse([230 - 16, 440 - 16, 230 + 16, 440 + 16], fill=A_(ACC, blink))
    rr(e, [300, 420, 500, 460], 20, fill=A_(ACC, 0.25))
    for k in range(3):                     # data flowing into the plug
        u = (t * 0.8 + k / 3) % 1; x = 300 + u * 420
        e.ellipse([x - 8, 432, x + 8, 448], fill=A_(ACC, 0.9 * math.sin(math.pi * u)))
    tmp = tmp.rotate(28, resample=Image.BICUBIC, center=(C2, C2))
    lay.alpha_composite(tmp)

def ic_pin(d, t, lay):
    pts = [(x, 640 + 70 * math.sin((x - 100) / 680 * math.pi * 1.6)) for x in range(100, 790, 10)]
    d.line(pts, fill=PANEL2, width=70, joint="curve")
    off = (t * 120) % 60
    for i in range(len(pts) - 1):
        if ((i * 10 + off) % 60) < 30: d.line([pts[i], pts[i + 1]], fill=WHITE, width=8)
    b = abs(math.sin(t * 3.2)) * 26
    cx, cy = 440, 330 - b
    d.ellipse([cx - 70 + b / 3, 600 - 14, cx + 70 - b / 3, 600 + 14], fill=(0, 0, 0, 90))
    d.polygon([(cx - 110, cy + 40), (cx + 110, cy + 40), (cx, cy + 250)], fill=ACC)
    d.ellipse([cx - 130, cy - 130, cx + 130, cy + 130], fill=ACC)
    d.ellipse([cx - 55, cy - 55, cx + 55, cy + 55], fill=NAVY0)

def ic_car(d, t, lay):
    ox = -60
    body = [(140 + ox, 560), (150 + ox, 470), (230 + ox, 450), (300 + ox, 360), (520 + ox, 350), (600 + ox, 440), (690 + ox, 470), (700 + ox, 560)]
    d.polygon(body, fill=PANEL, outline=WHITE, width=10)
    d.polygon([(318 + ox, 380), (405 + ox, 378), (405 + ox, 445), (265 + ox, 448)], fill=PANEL2)
    d.polygon([(425 + ox, 378), (510 + ox, 376), (570 + ox, 445), (425 + ox, 445)], fill=PANEL2)
    for x in (260 + ox, 580 + ox):
        d.ellipse([x - 62, 560 - 62, x + 62, 560 + 62], fill=(8, 14, 30), outline=WHITE, width=10)
        d.ellipse([x - 20, 540, x + 20, 580], fill=WHITE)
    d.ellipse([680 + ox - 12, 485 - 12, 680 + ox + 12, 485 + 12], fill=ACC)
    sx, sy = 700 + ox, 485
    for k in range(4):
        u = (t * 0.9 + k / 4) % 1; r = 40 + u * 200
        d.arc([sx - r, sy - r, sx + r, sy + r], -32, 32, fill=A_(ACC, 0.9 * (1 - u)), width=9)
    d.line([(100, 640), (780, 640)], fill=DIM, width=6)

def ic_shield(d, t, lay):
    shp = [(C2, 120), (700, 210), (690, 450), (C2, 780), (190, 450), (180, 210)]
    m = Image.new("L", (S2, S2), 0); ImageDraw.Draw(m).polygon(shp, fill=255)
    br = Image.new("RGBA", (S2, S2), PANEL + (255,)); bd = ImageDraw.Draw(br)
    for r in range(12):
        y = 120 + r * 56; o = 0 if r % 2 else 60
        bd.line([(0, y), (S2, y)], fill=PANEL2, width=8)
        for x in range(-60 + o, S2, 120): bd.line([(x, y), (x, y + 56)], fill=PANEL2, width=8)
    u = (t * 0.55) % 1.3; y = 100 + u * 600
    for k in range(40): bd.line([(0, y - k * 3), (S2, y - k * 3)], fill=A_(ACC, 0.45 * (1 - k / 40)), width=3)
    lay.paste(br, (0, 0), m)
    d.polygon(shp, outline=WHITE, width=12)
    d.line([(330, 450), (410, 535), (560, 365)], fill=ACC, width=34, joint="curve")
    for p in [(330, 450), (410, 535), (560, 365)]: d.ellipse([p[0] - 17, p[1] - 17, p[0] + 17, p[1] + 17], fill=ACC)

def ic_chat(d, t, lay):
    rr(d, [130, 180, 600, 470], 80, fill=PANEL, outline=WHITE, width=10)
    d.polygon([(210, 455), (300, 455), (190, 560)], fill=PANEL)
    d.line([(210, 462), (190, 560), (300, 466)], fill=WHITE, width=10, joint="curve")
    for k in range(3):
        a = 0.35 + 0.65 * max(0, math.sin(t * 5 - k * 0.8))
        x = 270 + k * 95; d.ellipse([x - 26, 325 - 26 - 10 * a, x + 26, 325 + 26 - 10 * a], fill=A_(WHITE, a))
    pop = ease(((t % 2.4) - 0.6) / 0.35)
    if pop > 0:
        s = 0.7 + 0.3 * pop
        bx0, by0, bx1, by1 = 330, 470, 750, 700; cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
        q = lambda x, y: (cx + (x - cx) * s, cy + (y - cy) * s)
        b0, b1 = q(bx0, by0), q(bx1, by1)
        rr(d, [b0[0], b0[1], b1[0], b1[1]], int(70 * s), fill=A_(ACC, pop))
        d.polygon([q(640, 690), q(720, 690), q(745, 780)], fill=A_(ACC, pop))
        for k in range(3): d.line([q(400, 545 + k * 55), q(680 - k * 90, 545 + k * 55)], fill=A_(NAVY0, pop), width=int(22 * s))

def leaf(d, base, side, L, g):
    """lens-shaped leaf from base, pointing up and out to one side"""
    ang = math.radians(-90 + side * 50); ux, uy = math.cos(ang), math.sin(ang); px, py = -uy, ux
    pts = []
    for s_ in (1, -1):
        for v in np.linspace(0, 1, 12) if s_ == 1 else np.linspace(1, 0, 12):
            w = math.sin(math.pi * v) * L * 0.28 * s_
            pts.append((base[0] + ux * L * v * g + px * w, base[1] + uy * L * v * g + py * w))
    d.polygon(pts, fill=WHITE)

def ic_drip(d, t, lay):
    rr(d, [90, 250, 790, 320], 35, fill=PANEL, outline=WHITE, width=8)
    xs = [230, 440, 650]
    for x in xs: rr(d, [x - 26, 300, x + 26, 350], 10, fill=WHITE)
    d.line([(90, 690), (790, 690)], fill=DIM, width=8)
    for i, x in enumerate(xs):
        u = (t * 0.75 + i * 0.33) % 1
        y = 370 + u * 300
        if u < 0.92:
            d.ellipse([x - 18, y - 18, x + 18, y + 18], fill=ACC); d.polygon([(x - 16, y - 8), (x + 16, y - 8), (x, y - 44)], fill=ACC)
        else:
            r = (u - 0.92) / 0.08 * 60; d.arc([x - r, 690 - r / 3, x + r, 690 + r / 3], 180, 360, fill=A_(ACC, 1 - (u - 0.92) / 0.08), width=6)
        g = 0.75 + 0.25 * math.sin(t * 2 + i)
        st = 690; top = 690 - 110 * g
        d.line([(x, st), (x, top)], fill=WHITE, width=10)
        leaf(d, (x, top + 8), -1, 95, g); leaf(d, (x, top + 40), 1, 80, g)
    d.line([(150, 740), (730, 740)], fill=DIM, width=4)

def ic_capsule(d, t, lay):
    tmp = Image.new("RGBA", (S2, S2), (0, 0, 0, 0)); e = ImageDraw.Draw(tmp)
    e.polygon([(650, 440), (870, 300), (870, 580)], fill=A_(ACC, 0.18 + 0.1 * math.sin(t * 5)))
    rr(e, [170, 340, 690, 540], 100, fill=PANEL, outline=WHITE, width=10)
    rr(e, [170, 340, 430, 540], 100, fill=WHITE)
    e.rectangle([330, 345, 430, 535], fill=WHITE)
    e.line([(430, 345), (430, 535)], fill=PANEL2, width=8)
    e.ellipse([590, 395, 680, 485], fill=(8, 14, 30), outline=ACC, width=8)
    e.ellipse([618, 423, 652, 457], fill=ACC)
    for k in range(3): rr(e, [470 + k * 34, 420, 490 + k * 34, 460], 6, fill=A_(ACC, 0.6))
    tmp = tmp.rotate(22 + 6 * math.sin(t * 1.4), resample=Image.BICUBIC, center=(C2, C2))
    lay.alpha_composite(tmp)

def ic_molecule(d, t, lay):
    pts = [(130 + k * 77.5, C2 + 150 * math.sin(k * 0.9 + t * 1.6) * (0.6 + 0.4 * math.sin(k * 1.7))) for k in range(9)]
    d.line(pts, fill=WHITE, width=12, joint="curve")
    cols = [ACC, WHITE, MUTED, ACC, WHITE, ACC, MUTED, WHITE, ACC]
    for k, (x, y) in enumerate(pts):
        r = 46 if cols[k] == ACC else 38
        d.ellipse([x - r, y - r, x + r, y + r], fill=cols[k], outline=NAVY0, width=6)
        if k % 3 == 1:
            x2, y2 = x + 20, y - 120 if y > C2 else y + 120
            d.line([(x, y), (x2, y2)], fill=WHITE, width=8); d.ellipse([x2 - 24, y2 - 24, x2 + 24, y2 + 24], fill=PANEL2, outline=WHITE, width=6)

ICONS = dict(chip=ic_chip, phone=ic_phone, usb=ic_usb, pin=ic_pin, car=ic_car, shield=ic_shield, chat=ic_chat, drip=ic_drip, capsule=ic_capsule, molecule=ic_molecule)
def icon(name, t, size):
    lay = Image.new("RGBA", (S2, S2), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    ICONS[name](d, t, lay)
    return lay.resize((size, size), Image.LANCZOS)

# glow disc behind each icon
def disc(r):
    s = 2 * r; yy, xx = np.mgrid[0:s, 0:s]; g = np.exp(-(((xx - r) ** 2 + (yy - r) ** 2) / (r * 0.5) ** 2))
    im = np.zeros((s, s, 4), np.uint8); im[..., :3] = ACC; im[..., 3] = (g * 60).astype(np.uint8)
    return Image.fromarray(im, "RGBA")
GLOW = disc(330)

# ------------------------------------------------------------------ cards
MAP_CY = 1500
def pill(im, d, label, cx, cy, alpha, fill=None, col=None, size=30, h=64):
    sz = fitsize(label, 800, size, 880); w = tw_(label, 800, sz) + 64
    if fill is None:
        d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], radius=h // 2, outline=A_(ACC, alpha), width=3)
        txt(im, label, 800, sz, col or ACC, cx, cy - 1, alpha)
    else:
        d.rounded_rectangle([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], radius=h // 2, fill=A_(fill, alpha))
        txt(im, label, 800, sz, col, cx, cy - 1, alpha)

def counter(im, d, k, el):
    txt(im, f"{k + 1:02d} / 10", 800, 34, WHITE, CX, 196, 1)
    x0, x1, gap = 190, 890, 10; sw = (x1 - x0 - gap * 9) / 10
    for i in range(10):
        x = x0 + i * (sw + gap)
        d.rounded_rectangle([x, 244, x + sw, 252], radius=4, fill=DIM + (140,))
        fr = 1 if i < k else (ease(el / 0.5) if i == k else 0)
        if fr > 0: d.rounded_rectangle([x, 244, x + sw * fr, 252], radius=4, fill=ACC + (255,))

def hook_card(t):
    im = BG.copy(); d = ImageDraw.Draw(im, "RGBA")
    draw_map(im, MAP_CY, t, 0, alpha=0.6)
    s = 1 + 0.03 * t
    txt(im, "You probably used", 900, 96, WHITE, CX, 700, 1, s)
    txt(im, "Israeli tech", 900, 150, ACC, CX, 840, 1, s)
    txt(im, "today.", 900, 96, WHITE, CX, 980, 1, s)
    txt(im, "השתמשת היום בטכנולוגיה ישראלית", 700, 46, MUTED, CX, 1110, 1)
    return im

def title_card(t, el, dur):
    im = BG.copy(); d = ImageDraw.Draw(im, "RGBA")
    out = 1 - smooth((el - dur + 0.25) / 0.25)
    a = ease(el / 0.4) * out
    put(im, GLOW, CX, 560, 0.8 * a)
    txt(im, "10", 900, 340, ACC, CX, 560 + 30 * (1 - a), a, 1 + 0.02 * el)
    b = ease((el - 0.2) / 0.4) * out
    txt(im, "Israeli technologies", 900, 92, WHITE, CX, 830 + 18 * (1 - b), b)
    txt(im, "the whole world uses", 900, 92, WHITE, CX, 935 + 18 * (1 - b), b)
    c = ease((el - 0.5) / 0.4) * out
    txt(im, "10 טכנולוגיות ישראליות שכל העולם משתמש בהן", 700, 46, MUTED, CX, 1060, c)
    draw_map(im, MAP_CY, t, 0, alpha=ease(el / 0.6))
    return im

def item_card(t, k, el, dur):
    it = ITEMS[k]
    im = BG.copy(); d = ImageDraw.Draw(im, "RGBA")
    out = 1 - smooth((el - dur + 0.22) / 0.22)
    counter(im, d, k, el)
    a = ease(el / 0.35) * out
    put(im, GLOW, CX, 560, 0.9 * a)
    sc = 0.82 + 0.18 * ease(el / 0.4)
    put(im, icon(it["icon"], el, 440), CX, 560 + 30 * (1 - ease(el / 0.4)), a, sc)
    b = ease((el - 0.12) / 0.35) * out
    txt(im, it["name"], 900, 104, WHITE, CX, 875 + 20 * (1 - b), b, shadow=True)
    c = ease((el - 0.25) / 0.35) * out
    txt(im, it["he"], 700, 54, MUTED, CX, 968 + 14 * (1 - c), c)
    txt(im, it["what"], 400, 38, WHITE, CX, 1040 + 14 * (1 - c), c * 0.92)
    p = ease((el - 0.45) / 0.35) * out
    pill(im, d, it["pill"], CX, 1120, p)
    s_ = ease((el - 0.85) / 0.4) * out
    txt(im, it["big"], 900, 92, ACC, CX, 1230 + 24 * (1 - s_), s_, 0.94 + 0.06 * s_)
    txt(im, it["sub"], 400, 38, MUTED, CX, 1310, ease((el - 1.05) / 0.4) * out)
    draw_map(im, MAP_CY + 20, t, k, new_k=k, el=el)
    txt(im, "Source: " + it["src"], 400, 24, DIM, CX, 1720, ease((el - 1.2) / 0.4) * out)
    return im

def end_card(t, el):
    im = BG.copy(); d = ImageDraw.Draw(im, "RGBA")
    a = ease(el / 0.4); b = ease((el - 0.35) / 0.4); c = ease((el - 0.8) / 0.4)
    txt(im, "Which one", 900, 120, WHITE, CX, 560 + 20 * (1 - a), a)
    txt(im, "surprised you?", 900, 120, ACC, CX, 690 + 20 * (1 - a), a)
    txt(im, "איזו מהן הפתיעה אותך?", 700, 52, MUTED, CX, 815, b)
    txt(im, "Comment below", 700, 60, WHITE, CX, 920, b)
    pill(im, d, "Follow @noamroz__", CX, 1070, c, fill=ACC, col=NAVY0, size=50, h=118)
    draw_map(im, MAP_CY, t, 10, alpha=1)
    return im

def frame(t):
    kind, el, dur = at(t)
    if kind == "hook": return hook_card(t)
    if kind == "title": return title_card(t, el, dur)
    if kind == "cta": return end_card(t, el)
    return item_card(t, KEYS.index(kind) - 2, el, dur)

# ------------------------------------------------------------------ audio
def build_audio(path):
    n = int((TT + 0.3) * SR); rng = np.random.default_rng(3)
    mu = load_audio(os.path.join(HERE, "music_it.wav"))
    if len(mu) < n: mu = np.concatenate([mu, np.zeros(n - len(mu))])
    mu = mu[:n] / (np.sqrt(np.mean(mu[: int(20 * SR)] ** 2)) + 1e-9) * 10 ** (-21 / 20)   # music bed at about -21 dBFS RMS
    gain = np.ones(n)
    if VOICE is not None:
        v = np.zeros(n); L = min(n, len(VOICE)); v[:L] = VOICE[:L]
        v = v / (np.sqrt(np.mean(v[np.abs(v) > 0.01] ** 2)) + 1e-9) * 10 ** (-16 / 20)     # voice at about -16 dBFS RMS
        hop = int(0.02 * SR); m = np.convolve(np.abs(v), np.ones(hop) / hop, "same") > 0.01
        m = np.convolve(m.astype(float), np.ones(int(0.3 * SR)), "same") > 0
        k = int(0.15 * SR); g = np.where(m, 10 ** (-12 / 20), 1.0)
        gain = np.convolve(np.pad(g, k, mode="edge"), np.ones(2 * k + 1) / (2 * k + 1), "same")[k:-k][:n]
    else:
        v = np.zeros(n)
    fi = int(0.25 * SR); gain[:fi] *= np.linspace(0, 1, fi)
    fo = int(2.2 * SR); gain[-fo:] *= np.linspace(1, 0, fo)
    out = mu * gain
    sfx = np.zeros(n)
    def add(sig, at_s, g):
        i = int(at_s * SR); j = min(n, i + len(sig))
        if 0 <= i < n: sfx[i:j] += g * sig[:j - i]
    tw = np.arange(int(0.42 * SR)) / SR                      # whoosh: noise through a rising resonant sweep
    nz = rng.standard_normal(len(tw)); y = np.zeros_like(nz); s1 = s2 = 0.0
    fc = 300 + 2600 * (tw / tw[-1]) ** 1.5
    for i in range(len(nz)):
        f = 2 * math.sin(math.pi * fc[i] / SR); s1 += f * (nz[i] - s1 - 0.6 * s2); s2 += f * s1; y[i] = s2
    whoosh = y / np.abs(y).max() * np.sin(np.pi * tw / tw[-1]) ** 2
    tc = np.arange(int(0.05 * SR)) / SR; tick = np.sin(2 * np.pi * 2400 * tc) * np.exp(-tc * 120)
    tp = np.arange(int(0.16 * SR)) / SR; popf = 700 + 600 * np.minimum(1, tp / 0.05)
    pop = np.sin(2 * np.pi * np.cumsum(popf) / SR) * np.exp(-tp * 26)
    tb = np.arange(int(1.8 * SR)) / SR
    chime = sum(np.sin(2 * np.pi * f * tb) * np.exp(-tb * (2.5 + j)) for j, f in enumerate([880, 1318.5, 1760])) * np.minimum(1, tb / 0.005)
    for st, kind in SCHED[1:]:
        add(whoosh, st - 0.18, 0.05)
        if kind.startswith("i"): add(tick, st + 0.05, 0.05); add(pop, st + 0.85, 0.045)
        if kind == "cta": add(chime, st + 0.1, 0.035)
    sw = np.sin(np.pi * np.clip(np.arange(int(1.0 * SR)) / SR, 0, 1)) * np.sin(2 * np.pi * 73.4 * np.arange(int(1.0 * SR)) / SR)
    add(sw, 0.0, 0.08)                                       # soft low swell under the hook
    mix = out + sfx + v
    mix = mix / max(1.0, np.abs(mix).max() / 0.95)
    sf.write(path, np.stack([mix, mix], 1).astype(np.float32), SR)

# ------------------------------------------------------------------ main
if __name__ == "__main__":
    print("total", round(TT, 2), "s;", [(k, round(s, 2)) for s, k in SCHED])
    if A.frames:
        os.makedirs(os.path.join(HERE, "check"), exist_ok=True)
        for s in A.frames.split(","):
            frame(float(s)).save(os.path.join(HERE, "check", f"f_{float(s):05.2f}.png"))
        sys.exit()
    out = os.path.abspath(A.out) if A.out else os.path.join(HERE, "israel_tech_vo.mp4" if A.vo else "israel_tech_v1.mp4")
    mixw = os.path.join(HERE, "mix.wav"); build_audio(mixw)
    json.dump(dict(total=TT, schedule=SCHED, lines=[(s["key"], round(s["v0"], 3), round(s["v1"], 3)) for s in segs], voice=bool(A.vo)),
              open(os.path.join(HERE, "timeline.json"), "w"), indent=1)
    p = subprocess.Popen(["nice", "-n", "15", "ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-i", mixw, "-c:v", "libx264", "-preset", "medium", "-crf", "21", "-pix_fmt", "yuv420p", "-threads", "2",
                          "-c:a", "aac", "-b:a", "160k", "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    t0 = time.time()
    for i in range(NF):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 300 == 0: print(i, NF, round(time.time() - t0), flush=True)
    p.stdin.close(); p.wait(); print("done", out, round(time.time() - t0), "s")
