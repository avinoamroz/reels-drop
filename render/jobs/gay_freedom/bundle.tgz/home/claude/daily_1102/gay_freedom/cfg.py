"""gay_freedom: Where do gay people have the most freedom in the Middle East? (sibling of lib_mena_rights_v4 / crime_punish)
Rows (V = yes): same sex relations legal | no death penalty | Pride allowed | protected at work by law | couples recognised.
Sources: ILGA World database; Human Dignity Trust (death penalty: implemented in Iran, Saudi Arabia, Yemen; a legal possibility in
Qatar and the UAE); Reuters / Amnesty (Iraq law, 27 Apr 2024, 10 to 15 years); HRW (Egypt, Lebanon arrests; Lebanon art. 534
amber, courts split); Istanbul Pride banned since 2015; Lebanon interior ministry ban 2022; Jordan penal code 1951; Israel: 1988
repeal, 1992 Equal Employment Opportunities Law amendment, 2006 High Court (Ben Ari) registration of marriages abroad, Amir Ohana
elected Knesset Speaker 29 Dec 2022."""
WHITE, GOLD, NAVY2, SILVER, YELLOW, PANEL, SKY = "#FFFFFF", "#D2AA53", "#0C1E3E", "#C9D1DC", "#FFD54A", "#1D3E73", "#45A4DD"


def build(wt, lt, LINES):
    CC = {"Israel": "il", "Turkey": "tr", "Jordan": "jo", "Lebanon": "lb", "Egypt": "eg", "Iraq": "iq", "UAE": "ae", "Qatar": "qa",
          "Saudi Arabia": "sa", "Iran": "ir", "Yemen": "ye"}
    TAB = {
        "Israel":       ["V", "V", "V", "V", "V"],
        "Turkey":       ["V", "V", "X", "X", "X"],
        "Jordan":       ["V", "V", "X", "X", "X"],
        "Lebanon":      ["~", "V", "X", "X", "X"],
        "Egypt":        ["~", "V", "X", "X", "X"],
        "Iraq":         ["X", "V", "X", "X", "X"],
        "UAE":          ["X", "~", "X", "X", "X"],
        "Qatar":        ["X", "~", "X", "X", "X"],
        "Saudi Arabia": ["X", "X", "X", "X", "X"],
        "Iran":         ["X", "X", "X", "X", "X"],
        "Yemen":        ["X", "X", "X", "X", "X"],
    }
    EXPECT = {"Israel": 5, "Turkey": 2, "Jordan": 2, "Lebanon": 1, "Egypt": 1, "Iraq": 1, "UAE": 0, "Qatar": 0, "Saudi Arabia": 0, "Iran": 0, "Yemen": 0}
    LABELS = [("Gay sex", "legal"), ("No death", "penalty"), ("Pride", "allowed"), ("Protected", "at work"), ("Couples", "recognised")]
    G = {}
    G["A"] = dict(cols=["Turkey", "Jordan", "Lebanon", "Egypt"], t_in=lt(4) - 0.45,
                  fill={"Turkey": wt(4, "Turkey,"), "Jordan": wt(5, "Jordan,"), "Lebanon": wt(6, "Lebanon"), "Egypt": wt(6, "Egypt,")},
                  score={"Turkey": wt(4, "two"), "Jordan": wt(5, "two."), "Lebanon": wt(6, "one"), "Egypt": wt(6, "each.")},
                  pulse=[("Turkey", 2, wt(4, "Pride")), ("Jordan", 0, wt(5, "Legal"))], stagger=0.1)
    G["B"] = dict(cols=["Iraq", "UAE", "Qatar"], t_in=lt(7) - 0.45,
                  fill={"Iraq": wt(7, "Iraq,"), "UAE": wt(8, "UAE"), "Qatar": wt(8, "Qatar,")},
                  score={"Iraq": wt(7, "one."), "UAE": wt(8, "zero."), "Qatar": wt(8, "zero.")},
                  pulse=[("Iraq", 0, wt(7, "ten"))], stagger=0.1)
    G["C"] = dict(cols=["Saudi Arabia", "Iran", "Yemen"], t_in=lt(9) - 0.45,
                  fill={"Saudi Arabia": wt(9, "Saudi"), "Iran": wt(9, "Iran"), "Yemen": wt(9, "Yemen,")},
                  score={"Saudi Arabia": wt(9, "zero."), "Iran": wt(9, "zero."), "Yemen": wt(9, "zero.")},
                  pulse=[("Saudi Arabia", 1, wt(9, "death.")), ("Iran", 1, wt(9, "death.")), ("Yemen", 1, wt(9, "death."))], stagger=0.1)
    T_ISR = wt(11, "Israel.")
    G["D"] = dict(cols=["Israel", "Turkey", "Jordan", "Lebanon"], t_in=lt(10) - 0.3,
                  fill={"Israel": T_ISR + 0.25, "Turkey": -9, "Jordan": -9, "Lebanon": -9},
                  score={"Israel": wt(11, "Five"), "Turkey": -9, "Jordan": -9, "Lebanon": -9}, mystery=["Israel"], stagger=0.09)
    ROWT = [wt(2, "legal?"), wt(2, "death"), wt(2, "Pride"), wt(3, "Protected"), wt(3, "Couples")]
    BADGES = [
        (wt(4, "Pride"), lt(5) - 0.2, "Istanbul Pride banned since 2015", "Istanbul governor's office, 2015 to 2026"),
        (wt(6, "Men"), lt(7) - 0.2, "Egypt, Lebanon: men arrested", "Human Rights Watch"),
        (wt(7, "In"), lt(8) - 0.2, "10 to 15 years in prison", "Iraq, April 2024. Reuters, Amnesty"),
        (wt(8, "Both"), lt(9) - 0.2, "UAE, Qatar: prison by law", "ILGA World; Human Dignity Trust"),
        (wt(9, "All"), lt(10) - 0.1, "Death penalty: applied", "Human Dignity Trust"),
    ]
    def ch(*parts): return [(len(sp.split()), tx) for sp, tx in parts]
    SUBS = {
        1: ch(("Five questions. Eleven countries.", "5 questions. 11 countries.")),
        2: ch(("Is it legal? No death penalty?", "Is it legal? No death penalty?"), ("Pride allowed?", "Pride allowed?")),
        3: ch(("Protected at work? Couples recognised?", "Protected at work? Couples recognised?")),
        4: ch(("Turkey, two out of five.", "Turkey, 2 out of 5."), ("Pride in Istanbul has been banned", "Pride in Istanbul has been banned"), ("since twenty fifteen.", "since 2015.")),
        5: ch(("Jordan, two.", "Jordan, 2."), ("Legal since nineteen fifty one,", "Legal since 1951,"), ("but nothing more.", "but nothing more.")),
        6: ch(("Lebanon and Egypt, one each.", "Lebanon and Egypt, 1 each."), ("Men are still arrested in both.", "Men are still arrested in both.")),
        7: ch(("Iraq, one.", "Iraq, 1."), ("In twenty twenty four, it set", "In 2024, it set"), ("ten to fifteen years in prison.", "10 to 15 years in prison.")),
        8: ch(("The UAE and Qatar, zero.", "The UAE and Qatar, 0."), ("Both can jail you for it.", "Both can jail you for it.")),
        9: ch(("Saudi Arabia, Iran and Yemen, zero.", "Saudi Arabia, Iran and Yemen, 0."), ("All three can sentence you to death.", "All three can sentence you to death.")),
        10: ch(("One country left.", "One country left.")),
        11: ch(("Israel. Five out of five.", "Israel. 5 out of 5.")),
        12: ch(("Legal since nineteen eighty eight.", "Legal since 1988."), ("Protected at work since ninety two.", "Protected at work since 1992.")),
        13: ch(("And in twenty twenty two,", "And in 2022,"), ("an openly gay man became", "an openly gay man became"), ("Speaker of the Knesset.", "Speaker of the Knesset.")),
        14: ch(("Not perfect either.", "Not perfect either."), ("Israel performs no same sex weddings.", "Israel performs no same sex weddings."),
               ("Couples marry abroad,", "Couples marry abroad,"), ("and Israel registers them.", "and Israel registers them.")),
    }
    T_FAIR = lt(14) - 0.15
    t_88, t_92, t_22 = wt(12, "nineteen"), wt(12, "ninety"), wt(13, "twenty")

    def wrap(txt, font, maxw):
        out, cur = [], ""
        for w_ in txt.split():
            tst = (cur + " " + w_).strip()
            if font.getlength(tst) <= maxw: cur = tst
            else: out.append(cur); cur = w_
        out.append(cur); return out

    def stat_card(base, t, E):
        F, hexa, DR, clamp, ease, back, paste_c = E["F"], E["hexa"], E["DR"], E["clamp"], E["ease"], E["back"], E["paste_c"]
        T0, TQ = E["T_STAT"], E["T_Q"]
        a = clamp((t - T0) / 0.3) * (1 - clamp((t - TQ) / 0.3))
        if a <= 0: return
        d = DR(base); d.rectangle((0, 0, 1080, 1920), fill=hexa(NAVY2, int(255 * a)))
        a1 = a * (1 - clamp((t - T_FAIR) / 0.3))
        if a1 > 0:
            d.text((60, 360), "Israel", font=F(130, 900), fill=hexa(GOLD, int(255 * a1)), anchor="ls")
            paste_c(base, E["FLAG"]["Israel"], 930, 320, a1)
            def row(y, big, txt, k, col):
                if k <= 0: return
                al = int(255 * a1 * clamp(k * 2)); xo = (1 - ease(k)) * 60
                d.text((60 + xo, y), big, font=F(int(130 * max(0.4, back(k))), 900), fill=hexa(col, al), anchor="ls")
                yy = y + 76
                for ln in wrap(txt, F(66, 800), 940):
                    d.text((60 + xo, yy), ln, font=F(66, 800), fill=hexa(WHITE, al), anchor="ls"); yy += 78
            row(600, "1988", "Gay sex legal", clamp((t - t_88 + 0.1) / 0.35), SKY)
            row(880, "1992", "Protected at work, by law", clamp((t - t_92 + 0.1) / 0.35), YELLOW)
            row(1160, "2022", "An openly gay Speaker of the Knesset", clamp((t - t_22 + 0.1) / 0.35), GOLD)
            d.text((60, 1400), "Penal Law 1988; Equal Employment Opportunities Law 1992.", font=F(36, 700), fill=hexa(SILVER, int(230 * a1)), anchor="lm")
        a2 = a * clamp((t - T_FAIR) / 0.3)
        if a2 > 0:
            X0 = 60; y0 = 520 - 30 * (1 - ease((t - T_FAIR) / 0.35))
            d.rounded_rectangle((X0 - 14, y0, 1020, y0 + 860), 28, fill=hexa(PANEL, int(250 * a2)), outline=hexa(GOLD, int(255 * a2)), width=4)
            d.text((X0 + 26, y0 + 70), "Not perfect either:", font=F(72, 900), fill=hexa(GOLD, int(255 * a2)), anchor="lm")
            y = y0 + 190
            for ln in wrap("No same sex weddings in Israel. There is no civil marriage at all.", F(66, 800), 900):
                d.text((X0 + 26, y), ln, font=F(66, 800), fill=hexa(WHITE, int(255 * a2)), anchor="lm"); y += 80
            y += 30
            for ln in wrap("Couples marry abroad, and Israel registers the marriage.", F(56, 700), 900):
                d.text((X0 + 26, y), ln, font=F(56, 700), fill=hexa(SILVER, int(255 * a2)), anchor="lm"); y += 68
            d.text((X0 + 26, y0 + 800), "Source: Israel High Court, Ben Ari ruling, 2006", font=F(36, 700), fill=hexa(SILVER, int(235 * a2)), anchor="lm")

    return dict(CC=CC, TAB=TAB, EXPECT=EXPECT, LABELS=LABELS, NSCORED=5, RH=140, LABEL_SZ=52, LABEL_GAP=27, ICON=0.95,
                G=G, ORDER=["A", "B", "C", "D"], ROWT=ROWT, MYSTERY={"Israel": T_ISR}, BADGES=BADGES, BADGE_Y=1352,
                T_ISR=T_ISR, T_SB=wt(11, "five.", nth=1, end=True) + 0.3, T_STAT=lt(12) - 0.2, T_Q=lt(15) - 0.2,
                HOOK=[("Where are", WHITE), ("gay people", WHITE), ("most ", WHITE, "free?", GOLD)],
                END_Q=[("So… next time", WHITE), ("someone says", WHITE), ("pinkwashing?", GOLD)],
                COUNT_LINE="11 Middle East countries", TITLE="Where are gay people freest?",
                SRC=["ILGA World, Human Dignity Trust, HRW,", "national laws. Amber = partly, no point."],
                SB_TITLE="Score out of 5", SB_HI={}, SB_SRC=["Score = full yes answers. Sources in caption."],
                SUBS=SUBS, stat_card=stat_card)
