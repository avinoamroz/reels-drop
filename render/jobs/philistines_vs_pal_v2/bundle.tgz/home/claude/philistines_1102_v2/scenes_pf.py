"""philistines_1102 scenes (2 Nov 2026), copied from druze_1102 scenes: the arabia_map house scenes (dark stage, label chip, circular loop, bar-cut music,
sc_amap with the whole land of Israel in gold, West Bank and Gaza a slightly different shade, Green Line in green) plus
- brand gold #FFCD50 for numbers and highlights
- sc_dzmap: sc_amap with animated travel arrows. Extra fields: arrows [{a: [lon, lat], b: [lon, lat], bend}] timed by
  marks a0, a1, ... (each arrow draws itself in 0.9 s with an arrow head)."""
exec(compile(open("/home/claude/arabia_map/scenes_am.py").read(), "/home/claude/arabia_map/scenes_am.py", "exec"))
YEL = kit.hx("#FFCD50")
_wtext.__defaults__ = (WHITE, YEL, 1000, 3, 1.0, 1.0, False)

def _arrow(c, p0, p1, bend, u, a):
    (x0, y0), (x1, y1) = p0, p1
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2; dx, dy = x1 - x0, y1 - y0
    cx, cy = mx - dy * bend, my + dx * bend
    n = 40; k = max(2, int(n * u))
    pts = [((1 - t) ** 2 * x0 + 2 * (1 - t) * t * cx + t * t * x1, (1 - t) ** 2 * y0 + 2 * (1 - t) * t * cy + t * t * y1)
           for t in [i / n for i in range(k + 1)]]
    pts = pts[:k + 1]
    c.save(); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for wdt, colr, al in ((16, INK, 0.55), (9, YEL, 1.0)):
        c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; sa(c, colr, al * a); c.set_line_width(wdt); c.stroke()
    if len(pts) >= 2:
        (ax, ay), (bx, by) = pts[-2], pts[-1]; ang = math.atan2(by - ay, bx - ax); L = 34
        c.move_to(bx + 8 * math.cos(ang), by + 8 * math.sin(ang))
        c.line_to(bx - L * math.cos(ang - 0.5), by - L * math.sin(ang - 0.5))
        c.line_to(bx - L * math.cos(ang + 0.5), by - L * math.sin(ang + 0.5)); c.close_path()
        sa(c, YEL, a); c.fill()
    c.restore()

def sc_dzmap(c, t, S):
    sc_amap(c, t, S)
    mv = S["_mv"]
    for i, ar in enumerate(S.get("arrows") or []):
        tk = S["times"].get(f"a{i}", S["t0"] + 0.4 + 0.9 * i)
        if t < tk - 0.05: continue
        u = ease(min(1.0, max(0.0, (t - tk) / 0.9)))
        _arrow(c, mv.P(*ar["a"]), mv.P(*ar["b"]), ar.get("bend", 0.18), max(0.05, u), 1.0)


# ================================================================== philistines_1102 additions
# - Green Line in brand green #3FBF7F
# - zones on sc_dzmap: [{poly: [[lon, lat], ...], color, at (mark name)}] translucent fill + outline
# - top overlay drawn on top of everything (incl. the loop cross-fade):
#   year counter chip (scene "yr", rolls from the previous scene's year in 1.0 s; BCE / CE) and a
#   FACT CHECK n/4 chip (scene "fc": [before, after, mark] or an int; hidden when the scene has no "fc")
GLINE = kit.hx("#3FBF7F")
_dzmap0 = sc_dzmap
def sc_dzmap(c, t, S):
    _dzmap0(c, t, S)
    mv = S["_mv"]
    for i, zn in enumerate(S.get("zones") or []):
        tk = S["times"].get(zn.get("at", f"z{i}"), S["t0"] + 0.3)
        u = 1.0 if (S.get("hook") and tk <= RD.HOOK_GRACE) else ease(min(1.0, max(0.0, (t - tk) / 0.6)))
        if u <= 0.01: continue
        pts = [mv.P(x, y) for x, y in zn["poly"]]
        c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.close_path()
        cz = kit.hx(zn.get("color", "#45A4DD")); sa(c, cz, 0.42 * u * St.a); c.fill_preserve()
        sa(c, cz, 0.95 * u * St.a); c.set_line_width(4); c.stroke()

def _yfmt(v):
    v = int(round(v))
    if v <= 0: return f"{max(1, -v)} BCE"
    return f"{v} CE" if v < 1000 else f"{v}"

def _cur_scene(self, t):
    i = 0
    for k, S in enumerate(self.scenes):
        if t >= S["t0"] - 0.01: i = k
    return i

_draw_top0 = RD.Reel.draw
def _draw_top(self, c, t):
    _draw_top0(self, c, t)
    sc = self.scenes; i = _cur_scene(self, t); S = sc[i]
    keep = St.a; St.a = 1.0
    # fact check chip
    def fc_val(Sx):
        f = Sx.get("fc")
        if f is None: return None
        if isinstance(f, int): return f
        a, b, m = f; tm = Sx.get("times", {}).get(m, Sx["t0"] + 0.5)
        return b if t >= tm else a
    def fc_pop(Sx):
        f = Sx.get("fc")
        if not isinstance(f, list): return 1.0
        tm = Sx.get("times", {}).get(f[2], Sx["t0"] + 0.5)
        return kit.pop(t, tm, 0.45, 0.6, 1.6)[1] if t >= tm else 1.0
    v = fc_val(S); pv = fc_val(sc[i - 1]) if i else None
    if v is not None: af = 1.0 if pv is not None else ramp(t, S["t0"], S["t0"] + 0.35)
    elif pv is not None: af = 1.0 - ramp(t, S["t0"], S["t0"] + 0.35); v = pv
    else: af = 0.0
    # year chip
    y1 = S.get("yr"); y0 = sc[i - 1].get("yr", y1) if i else y1
    ry = S.get("yr_roll", 1.0)
    u = 1.0 if i == 0 else ease(min(1.0, max(0.0, (t - S["t0"]) / ry)))
    yv = y0 + (y1 - y0) * u if (y1 is not None and y0 is not None) else y1
    xy = lerp(540, 285, ease(af)); xf = lerp(1080 + 300, 790, ease(af))
    if yv is not None:
        s_ = _yfmt(yv); f = kit.font(58, 900); tw = max(f.getlength("8888 BCE"), f.getlength(s_))
        sa(c, INK, 0.78); rr(c, xy - tw / 2 - 34, 262 - 42, tw + 68, 84, 42); c.fill()
        sa(c, YEL, 0.95); c.set_line_width(3); rr(c, xy - tw / 2 - 34, 262 - 42, tw + 68, 84, 42); c.stroke()
        kit.tx(c, s_, 58, xy, 262, w=900, col=RD.c255(YEL), a=1.0, shadow=False, maxw=1000)
    if af > 0.01 and v is not None:
        s_ = f"FACT CHECK {v}/4"; f = kit.font(44, 900); tw = f.getlength(s_); sc_ = fc_pop(S)
        c.save(); c.translate(xf, 262); c.scale(sc_, sc_); c.translate(-xf, -262)
        sa(c, INK, 0.78 * af); rr(c, xf - tw / 2 - 30, 262 - 42, tw + 60, 84, 42); c.fill()
        sa(c, SKY, 0.95 * af); c.set_line_width(3); rr(c, xf - tw / 2 - 30, 262 - 42, tw + 60, 84, 42); c.stroke()
        kit.tx(c, s_, 44, xf, 262, w=900, col=RD.c255(WHITE), a=af, shadow=False, maxw=1000)
        c.restore()
    St.a = keep
RD.Reel.draw = _draw_top
