"""jews_converted: how did each faith spread? World map race (Christians, Muslims, Jews) with a year counter and a
three-row counter panel. Pew 2025 (2020 data). Circular: the last 0.9 s cross-fades into frame 0.
python3 engine.py [--frames t1,t2,...] [--out path.mp4]   (DIR = this folder: timing.json, geo_world.json, geo_il.json, mix.m4a)"""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.6):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u

NAVYD, NAVY, ROYAL, SKY, YEL = hx("#0E1E3A"), hx("#163261"), hx("#2749D3"), hx("#45A4DD"), hx("#FFD54A")
GREEN = (46 / 255, 204 / 255, 113 / 255, 1); SILVER = hx("#C9D1DC"); WHITE = (1, 1, 1, 1)
LAND_IL, LAND_PA, EDGE = hx("#2C5A9C"), hx("#24497F"), hx("#6FB8E8")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])     # surface, x offset of origin, y offset of baseline
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    """draw s with its baseline at y; align c/l/r on x"""
    if a <= 0.01: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def fit(s, size, maxw, w=800, mn=64):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def surf_from(path, w=None):
    im = Image.open(path).convert("RGBA")
    if w: im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    return pil2cairo(im)

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 0.95, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1
T_FADE = END - 0.9

# ------------------------------------------------------------------ colours
C_CHR, C_MUS, C_JEW = hx("#45A4DD"), hx("#2FBF9F"), hx("#E6C77E")
IL_GOLD, PA_GOLD = hx("#D4A94E"), hx("#B8923F")
LAND, LAND_E = hx("#1D3766"), hx("#3B5D93")
RED = hx("#FF7A59")

# ------------------------------------------------------------------ geography and camera
GW = json.load(open(f"{D}/geo_world.json")); GI = json.load(open(f"{D}/geo_il.json"))
MAP_CX, MAP_CY = 540, 905
XS = 0.95
WORLD = (12.0, 20.0, 3.25); MED = (27.0, 37.0, 9.5); ME = (44.0, 27.0, 6.2); IL = (35.05, 31.35, 175.0)

# spread clocks: year(t) is piecewise linear; country fill time = inverse
T_C0 = wt(3, "Rome") - 0.2; T_C1 = CUT[4] - 0.35
CK = [(0.0, 380), (0.22, 1000), (0.42, 1500), (0.62, 1700), (0.8, 1900), (1.0, 2020)]
T_M0 = lt(4) + 0.1; T_M1 = CUT[5] - 0.35
MK = [(0.0, 632), (0.25, 750), (0.45, 1100), (0.7, 1400), (0.88, 1600), (1.0, 2020)]
def year_at(t, t0, t1, K):
    u = clamp((t - t0) / (t1 - t0))
    for (a, ya), (b, yb) in zip(K, K[1:]):
        if u <= b: return ya + (yb - ya) * (u - a) / (b - a)
    return K[-1][1]
def time_of(y, t0, t1, K):
    for (a, ya), (b, yb) in zip(K, K[1:]):
        if y <= yb: return t0 + (a + (b - a) * (y - ya) / (yb - ya)) * (t1 - t0)
    return t1
for g in GW:
    if g["r"] == "c": g["t"] = time_of(g["y"], T_C0, T_C1, CK)
    elif g["r"] == "m": g["t"] = time_of(g["y"], T_M0, T_M1, MK)
    g["t"] = g.get("t", 1e9) + (abs(hash(g["a"])) % 7) * 0.04
N_C = sum(g["r"] == "c" for g in GW); N_M = sum(g["r"] == "m" for g in GW)

T_RESET0 = wt(1, "spread") - 0.2; T_RESET1 = CUT[2] + 0.2         # "how did each spread": today's map rewinds
T_TODAY2 = CUT[11]                                                 # back to today's map
def fill_amount(g, t):
    if g["r"] is None: return 0.0
    if t < T_RESET1:                       # frame 0 = today's map, then rewind
        return 1 - ramp(t, T_RESET0, T_RESET1)
    if t >= T_TODAY2: return 1.0
    return eout((t - g["t"]) / 0.45)

CAM = [  # (time, pose) keyframes, eased between
    (0.0, WORLD), (CUT[2] + 0.05, WORLD), (CUT[2] + 1.5, MED),
    (time_of(1000, T_C0, T_C1, CK), MED), (time_of(1600, T_C0, T_C1, CK), WORLD),
    (CUT[4], WORLD), (CUT[4] + 1.0, ME), (time_of(900, T_M0, T_M1, MK), ME), (time_of(1350, T_M0, T_M1, MK), WORLD),
    (CUT[8], WORLD), (CUT[8] + 1.6, IL), (CUT[11], IL), (CUT[11] + 1.5, WORLD), (END + 5, WORLD)]
def pose(t):
    for (ta, pa), (tb, pb) in zip(CAM, CAM[1:]):
        if t <= tb:
            u = ease((t - ta) / max(1e-6, tb - ta))
            ka, kb = math.log(pa[2]), math.log(pb[2]); k = math.exp(lerp(ka, kb, u))
            # centre follows the zoom so the target stays put (fraction of the log zoom done)
            v = (k - pa[2]) / (pb[2] - pa[2]) if abs(pb[2] - pa[2]) > 1e-6 else u
            v = clamp(v if pb[2] > pa[2] else 1 - (pb[2] / k - 1) / (pb[2] / pa[2] - 1) if abs(pb[2] / pa[2] - 1) > 1e-6 else u)
            return lerp(pa[0], pb[0], v), lerp(pa[1], pb[1], v), k
    return CAM[-1][1]
def P(ps, lon, lat):
    lo0, la0, k = ps; return MAP_CX + (lon - lo0) * k * XS, MAP_CY - (lat - la0) * k
def ring(c, ps, pts):
    for i, (lo, la) in enumerate(pts):
        x, y = P(ps, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
    c.close_path()
def vis(ps, g):
    x, y = P(ps, g["cx"], g["cy"]); return -900 < x < W + 900 and -900 < y < H + 900

JER = (35.23, 31.78); ROME = (12.5, 41.9); MECCA = (39.83, 21.42)
IDUMEA = [(34.72, 31.66), (35.15, 31.66), (35.37, 31.5), (35.36, 31.12), (35.0, 30.98), (34.72, 31.12), (34.62, 31.38)]
DIASPORA = [(-74, 40.7, 1.6), (-118.2, 34.0, 1.1), (-80.2, 26.0, 0.9), (-87.6, 41.9, 0.8), (-79.4, 43.7, 0.9), (-73.6, 45.5, 0.7),
            (-58.4, -34.6, 0.9), (-46.6, -23.5, 0.6), (-99.1, 19.4, 0.5), (-0.1, 51.5, 0.9), (2.35, 48.9, 1.1), (13.4, 52.5, 0.5),
            (37.6, 55.75, 0.7), (30.5, 50.45, 0.5), (19.0, 47.5, 0.6), (28.0, -26.2, 0.7), (145.0, -37.8, 0.7), (151.2, -33.9, 0.6),
            (4.4, 51.2, 0.5), (12.5, 41.9, 0.4), (29.0, 41.0, 0.4), (51.4, 35.7, 0.4), (-7.6, 33.6, 0.4), (-77.0, 38.9, 0.7), (-75.2, 39.95, 0.6)]
T_DIA = wt(6, "scattered") - 0.3

# ------------------------------------------------------------------ background
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.6, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1B3C8C")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 905, 720, SKY, 0.12); return s
BG = bg_surface()

def pin(c, x, y, col, t0, t, label=None, side="r", a=1.0):
    if t < t0 or a <= 0.01: return
    u = clamp((t - t0) / 0.4); ph = ((t - t0) % 1.3) / 1.3
    c.set_source_rgba(*col[:3], a * 0.85 * (1 - ph)); c.set_line_width(4); c.arc(x, y, 14 + 40 * ph, 0, 6.283); c.stroke()
    glow(c, x, y, 50, col, 0.5 * a)
    c.set_source_rgba(*NAVYD[:3], a * u); c.arc(x, y, 17, 0, 6.283); c.fill()
    c.set_source_rgba(*col[:3], a * u); c.arc(x, y, 12 * eob(u), 0, 6.283); c.fill()
    if label:
        la = a * ramp(t, t0 + 0.1, t0 + 0.4); sz = 48; tw = font(sz, 800).getlength(label)
        bx = x + 32 if side == "r" else x - 32 - tw - 36; bx = min(max(bx, 60), 1020 - tw - 36)
        rr(c, bx, y - 36, tw + 36, 68, 34); c.set_source_rgba(*NAVYD[:3], 0.9 * la); c.fill_preserve()
        c.set_source_rgba(*col[:3], 0.95 * la); c.set_line_width(2.5); c.stroke()
        text(c, label, sz, bx + 18, y + 14, 800, WHITE, la, "l")

def draw_map(c, t):
    ps = pose(t); k = ps[2]
    dimj = ramp(t, T_DIA - 0.2, T_DIA + 0.5) * (1 - ramp(t, CUT[8], CUT[8] + 0.6))       # dim fills for the Jews beat
    lw = max(0.8, min(2.2, k / 5))
    for g in GW:
        if not vis(ps, g): continue
        for r in g["rings"]: ring(c, ps, r)
        f = fill_amount(g, t)
        if f > 0.01:
            col = C_CHR if g["r"] == "c" else C_MUS
            c.set_source_rgba(*LAND[:3], 1); c.fill_preserve()
            flash = 1 - clamp((t - g["t"] - 0.2) / 0.8) if T_RESET1 <= t < T_TODAY2 else 0
            zd = clamp((k - 12) / 30)
            c.set_source_rgba(*[lerp(v, 1, 0.35 * flash) for v in col[:3]], f * (0.92 - 0.55 * dimj) * (1 - 0.72 * zd)); c.fill_preserve()
        else:
            c.set_source_rgba(*LAND[:3], 1); c.fill_preserve()
        c.set_source_rgba(*LAND_E[:3], 0.7); c.set_line_width(lw); c.stroke()
    # the land of Israel: gold, West Bank and Gaza a slightly different gold, Green Line green
    zi = clamp((k - 20) / 60)
    glow(c, *P(ps, 35.0, 31.5), 60 + 260 * zi, C_JEW, 0.35 * (1 - zi) + 0.12)
    for r in GI["isr"]: ring(c, ps, r)
    c.set_source_rgba(*IL_GOLD[:3], 1); c.fill()
    for r in GI["pal"]: ring(c, ps, r)
    c.set_source_rgba(*PA_GOLD[:3], 1); c.fill()
    if k > 20:
        for r in GI["lakes"]: ring(c, ps, r)
        c.set_source_rgba(*hx("#0B1730")[:3], 1); c.fill()
        c.set_source_rgba(46 / 255, 204 / 255, 113 / 255, zi); c.set_line_width(max(1.5, 3.2 * k / 150)); c.set_line_cap(cairo.LINE_CAP_ROUND)
        for ln in GI["green"]:
            for i, (lo, la) in enumerate(ln):
                x, y = P(ps, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
            c.stroke()
    if k < 20:   # tiny Israel needs a marker so it reads at world zoom
        x, y = P(ps, 35.0, 31.5); c.set_source_rgba(*C_JEW[:3], 1); c.arc(x, y, max(3.5, 0.6 * k), 0, 6.283); c.fill()
    # diaspora communities: small gold dots, no fill
    da = ramp(t, T_DIA, T_DIA + 0.6) * (1 - ramp(t, CUT[8], CUT[8] + 0.5))
    if da > 0.01:
        for j, (lo, la, s) in enumerate(DIASPORA):
            u = clamp((t - T_DIA - 0.05 * j) / 0.35)
            if u <= 0: continue
            x, y = P(ps, lo, la); glow(c, x, y, 26 * s + 8, C_JEW, 0.4 * da * u)
            c.set_source_rgba(*C_JEW[:3], da * u); c.arc(x, y, (4 + 4 * s) * eob(u), 0, 6.283); c.fill()
    # Idumea (balance beat)
    ia = ramp(t, lt(9) + 0.2, lt(9) + 0.7) * (1 - ramp(t, CUT[11] - 0.3, CUT[11] + 0.2))
    if ia > 0.01:
        ring(c, ps, IDUMEA); c.set_source_rgba(*RED[:3], 0.45 * ia); c.fill_preserve()
        c.set_source_rgba(*RED[:3], ia); c.set_line_width(4); c.set_dash([14, 9]); c.stroke(); c.set_dash([])
        x, y = P(ps, 35.36, 31.3); tw = font(54, 900).getlength("Idumea")
        rr(c, x + 30, y - 44, tw + 40, 76, 38); c.set_source_rgba(*NAVYD[:3], 0.92 * ia); c.fill_preserve(); c.set_source_rgba(*RED[:3], ia); c.set_line_width(3); c.stroke()
        text(c, "Idumea", 54, x + 50, y + 16, 900, WHITE, ia, "l")
    # pins
    pin(c, *P(ps, *JER), C_CHR, CUT[2] + 0.5, t, "Jerusalem", "r", 1 - ramp(t, CUT[4] - 0.4, CUT[4]))
    pin(c, *P(ps, *ROME), C_CHR, wt(3, "Rome"), t, "Rome", "l", 1 - ramp(t, time_of(1500, T_C0, T_C1, CK), time_of(1600, T_C0, T_C1, CK)))
    pin(c, *P(ps, *MECCA), C_MUS, lt(4) + 0.3, t, "Mecca", "r", 1 - ramp(t, time_of(1400, T_M0, T_M1, MK), CUT[5]))
    # Israel = New Jersey chip
    na = ramp(t, wt(8, "size") - 0.2, wt(8, "size") + 0.2) * (1 - ramp(t, CUT[9] - 0.3, CUT[9]))
    if na > 0.01: chip(c, "Israel: about the size of New Jersey", 1130, na, C_JEW)
    ha = ramp(t, lt(10) + 0.3, lt(10) + 0.6) * (1 - ramp(t, CUT[11] - 0.3, CUT[11]))
    if ha > 0.01: chip(c, "Also: Himyar kingdom, Yemen, 380 to 525 CE", 1130, ha, RED)

def chip(c, s, y, a, col):
    sz = fit(s, 46, 900, 800, 40); tw = font(sz, 800).getlength(s)
    rr(c, 540 - tw / 2 - 28, y - 52, tw + 56, 76, 38); c.set_source_rgba(*NAVYD[:3], 0.92 * a); c.fill_preserve()
    c.set_source_rgba(*col[:3], a); c.set_line_width(3); c.stroke()
    text(c, s, sz, 540, y + 2, 800, WHITE, a)

# ------------------------------------------------------------------ year chip
def draw_year(c, t):
    for t0, t1, K, col in ((T_C0, T_C1, CK, C_CHR), (T_M0, T_M1, MK, C_MUS)):
        a = ramp(t, t0 - 0.3, t0) * (1 - ramp(t, t1 + 0.25, t1 + 0.55))
        if a <= 0.01: continue
        y = int(round(year_at(t, t0, t1, K)))
        s = f"{y}" + (" CE" if y < 1000 else "")
        text(c, "Year", 44, 540, 636, 700, SILVER, a)
        text(c, s, 96, 540, 726, 900, YEL, a)

# ------------------------------------------------------------------ headline
HEAD = [None,
        ["About 15 million.", "How did each spread?"],
        ["“Go and teach", "all nations”"],
        ["380: Rome's state religion.", "Then empires and missions."],
        ["Islam: conquest,", "then trade routes"],
        ["Majority countries", "today"],
        ["2,000 years scattered.", "No empire."],
        ["No missionaries.", "Turn a convert away 3 times"],
        ["Jewish majority countries:", "1"],
        ["Not perfect either:", "Hasmoneans forced the", "Idumeans to convert"],
        ["Rare exceptions.", "Never a world mission."],
        ["Some colonizers."],
        ["Next time someone", "says colonizers:"]]
SRC = ["Pew Research Center, 2025 (2020 data)", "Pew Research Center, 2025 (2020 data)", "Matthew 28:19 (KJV)",
       "Edict of Thessalonica, 380 CE. Encyclopaedia Britannica", "Encyclopaedia Britannica. Map: today's majority, timing approximate",
       "Pew Research Center, 2025 (2020 data)", "Map: some of today's Jewish communities", "Ruth Rabbah 2:16. Talmud, Yevamot 47a",
       "Pew Research Center, 2025. Area: Israel CBS, US Census Bureau", "Josephus, Antiquities 13.257, about 125 BCE",
       "Encyclopaedia Britannica (Himyar)", "Pew Research Center, 2025 (2020 data)", "Pew Research Center, 2025 (2020 data)"]
def draw_hook(c, a):
    if a <= 0.01: return
    text(c, "2.3 billion. 2 billion.", 104, 540, 392, 900, YEL, a)
    text(c, "Jews?", 150, 540, 560, 900, WHITE, a)
def draw_head(c, t):
    i = scene_at(t)
    if i == 0:
        draw_hook(c, 1.0); return
    a = ramp(t, CUT[i] + 0.05, CUT[i] + 0.35)
    if i == NL - 1: a *= 1 - ramp(t, T_FADE - 0.3, T_FADE)
    dy = (1 - eout((t - CUT[i]) / 0.35)) * 24
    hs = HEAD[i]
    if i == 11:
        text(c, hs[0], 132, 540, 470 + dy, 900, YEL, a); return
    if i == 8:
        text(c, hs[0], fit(hs[0], 84, 960, 900), 540, 380 + dy, 900, WHITE, a)
        one = ramp(t, wt(8, "One") - 0.1, wt(8, "One") + 0.25)
        text(c, "1", 170, 540, 560 + dy, 900, YEL, a * one, "c", 0.6 + 0.4 * eob(one)); return
    if i == 9:
        text(c, hs[0], 96, 540, 380 + dy, 900, YEL, a)
        for n, s in enumerate(hs[1:]): text(c, s, 74, 540, 490 + 88 * n + dy, 800, WHITE, a)
        return
    for n, s in enumerate(hs):
        col = YEL if (n == 1 and i in (7, 10)) else WHITE
        sz = fit(s, 88, 960, 900)
        text(c, s, sz, 540, 400 + 110 * n + dy, 900, col, a)
def draw_source(c, t):
    i = scene_at(t); s = SRC[i]
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1])) if i > 0 else 1.0
    if i == NL - 1: a *= 1 - ramp(t, T_FADE - 0.3, T_FADE)
    sz = fit(s, 38, 960, 700, 36); text(c, s, sz, 540, 1536, 700, SILVER, a)

# ------------------------------------------------------------------ the counter panel
def sym(c, kind, x, y, col, a):
    c.save(); c.translate(x, y)
    c.set_source_rgba(*col[:3], 0.22 * a); c.arc(0, 0, 38, 0, 6.283); c.fill()
    c.set_source_rgba(*col[:3], a); c.set_line_width(3); c.arc(0, 0, 38, 0, 6.283); c.stroke()
    c.set_source_rgba(1, 1, 1, a)
    if kind == "c":
        c.rectangle(-4.5, -22, 9, 44); c.rectangle(-15, -11, 30, 8.5); c.fill()
    elif kind == "m":
        c.arc(-2, 0, 20, 0, 6.283); c.fill()
        c.set_source_rgba(*NAVYD[:3], a); c.arc(6, -3, 17, 0, 6.283); c.fill()
        c.set_source_rgba(1, 1, 1, a); c.arc(13, -3, 5, 0, 6.283); c.fill()
    else:
        r = 22; c.set_line_width(4.5); c.set_line_join(cairo.LINE_JOIN_ROUND)
        for rot in (0, math.pi):
            for j in range(3):
                ang = rot - math.pi / 2 + j * 2 * math.pi / 3; (c.move_to if j == 0 else c.line_to)(r * math.cos(ang), r * math.sin(ang))
            c.close_path(); c.stroke()
    c.restore()
def fmt_big(v):
    if v >= 1e9: s = f"{v / 1e9:.1f}B"; return s.replace(".0B", "B")
    if v >= 1e6: return f"{v / 1e6:.0f}M"
    return f"{v:,.0f}"
ROWS_Y = [1290, 1380, 1470]
def panel_mode(t):
    """F = followers, C = majority countries"""
    if CUT[2] <= t < CUT[11]: return "C"
    return "F"
def draw_panel(c, t):
    mode = panel_mode(t)
    # cross-fade at the two switches
    sw = [CUT[2], CUT[11]]; a = 1.0
    for s in sw: a = min(a, 0.25 + 0.75 * clamp(abs(t - s) / 0.3))
    title = "Followers" if mode == "F" else "Majority countries"
    rr(c, 50, 1182, 980, 380, 40); c.set_source_rgba(*NAVYD[:3], 0.78); c.fill()
    text(c, title, 42, 540, 1228, 700, SILVER, a)
    jv_f = None if t < wt(1, "fifteen") - 0.1 and t < CUT[2] else 15.8e6
    if mode == "F":
        u = eout((t - wt(1, "fifteen") + 0.1) / 0.9) if t < CUT[2] else 1.0
        vals = [(2.3e9, 2.3e9), (2.0e9, 2.0e9), (None if jv_f is None else 15e6 * u, 15e6)]
        mx = 2.3e9
    else:
        ct = sum(fill_amount(g, t) for g in GW if g["r"] == "c") / N_C
        mt = sum(fill_amount(g, t) for g in GW if g["r"] == "m") / N_M
        one = ramp(t, wt(8, "One") - 0.1, wt(8, "One") + 0.2)
        vals = [(120 * ct, 120), (53 * mt, 53), (1 * one, 1)]
        mx = 120
    names = [("Christians", "c", C_CHR), ("Muslims", "m", C_MUS), ("Jews", "j", C_JEW)]
    bx0, bw = 440, 400
    for (nm, kd, col), (v, full), y in zip(names, vals, ROWS_Y):
        sym(c, kd, 112, y, col, a)
        text(c, nm, 52, 168, y + 18, 800, WHITE, a, "l")
        rr(c, bx0, y - 15, bw, 30, 15); c.set_source_rgba(1, 1, 1, 0.08 * a); c.fill()
        if v is not None:
            w = max(10, bw * v / mx); rr(c, bx0, y - 15, w, 30, 15); c.set_source_rgba(*col[:3], a); c.fill()
            if kd == "j":      # the sliver that barely moves
                ph = (t % 1.2) / 1.2; c.set_source_rgba(*YEL[:3], a * 0.8 * (1 - ph)); c.set_line_width(3); c.arc(bx0 + 5, y, 18 + 22 * ph, 0, 6.283); c.stroke()
            if mode == "F": s = fmt_big(v if v > 1 else 0) if v >= full * 0.999 else fmt_big(round(v / 1e5) * 1e5)
            else: s = f"{int(round(v))}"
            text(c, s, 64, 1010, y + 22, 900, YEL, a, "r")
        else:
            text(c, "?", 72, 1010, y + 24, 900, YEL, a, "r")

# ------------------------------------------------------------------ subtitles
REPL = [("Two point three billion", "2.3 billion"), ("Two billion", "2 billion"), ("fifteen million", "15 million"),
        ("three eighty,", "380,"), ("a hundred and twenty", "120"), ("Fifty-three", "53"), ("Two thousand years", "2,000 years"),
        ("two thousand years", "2,000 years"), ("three times.", "3 times."), ("One.", "1.")]
SUB_BOTTOM = 1712
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower() == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs()
SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def frame(t, subs=True):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    draw_map(c, t)
    # soft fade behind the headline so text never fights the map
    g = cairo.LinearGradient(0, 250, 0, 760); g.add_color_stop_rgba(0, *NAVYD[:3], 0.0); g.add_color_stop_rgba(0.15, *NAVYD[:3], 0.55); g.add_color_stop_rgba(1, *NAVYD[:3], 0.0)
    c.set_source(g); c.rectangle(0, 250, W, 510); c.fill()
    draw_year(c, t); draw_head(c, t); draw_panel(c, t); draw_source(c, t)
    if subs: draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

if __name__ == "__main__":
    F0 = frame(0.0)
    def blend(tt, img):
        if tt < T_FADE: return img
        u = ease((tt - T_FADE) / (END - T_FADE)); return (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); Image.fromarray(blend(tt, frame(tt))).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; p.stdin.write(blend(tt, frame(tt)).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
