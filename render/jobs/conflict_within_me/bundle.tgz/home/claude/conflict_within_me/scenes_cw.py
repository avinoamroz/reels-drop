"""Bespoke reelkit scenes for conflict_within_me (28 Oct 2026). Warm, illustrated, no photos of people.
family_tree: Dad (Iran, Shiraz) + Mom (USA) tiles joined to Me (Israel); fully on screen at frame 0.
inside_me: line-art bust with the three flags orbiting inside it.
chant: the regime's chant on a dark card, pointing at Mom (US) and Me (IL); "That's my whole family".
travel: world map with travel dots + Shiraz skyline line art (iwan, arcades, dome, minarets, cypresses, 8-point stars).
peace: Middle East map, a dotted flight arc Tehran <-> Tel Aviv with a plane going both ways; history note card.
split: two columns (building vs taking land), footer and a sourced regime note.
rows2: cards (copied from this_life). beach: sun, waves, umbrella, flag towels."""
import math
import cairo
import render as RD
from render import P, T, pill, PP, fade_in, heading, source, block, block_h, shadow_box, icon_of, draw_emoji, series_chip, col, CONTENT_BOTTOM, flag_emoji
from kit import ease, ramp, lerp, St, sa, rr, circ, box, W, H

def _sweep(c, t, t0, x, y, w, a):
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, x - w / 2 * u, y, w * u, 12, 6, P["gold"], a)

def _star8(c, x, y, r, cc, a, fill=False, lw=2.5):
    for rot in (0, math.pi / 4):
        c.save(); c.translate(x, y); c.rotate(rot); c.rectangle(-r * 0.7071, -r * 0.7071, r * 1.4142, r * 1.4142); c.restore()
    sa(c, cc, a)
    if fill: c.fill()
    else: c.set_line_width(lw); c.stroke()

def _title(c, t, S, y=330, size=72, he_size=52):
    """EN block + gold sweep + HE; returns y below"""
    t0 = S["t0"]; a, s = PP(t, t0 + 0.05, S); breath = 1 + 0.01 * math.sin(max(0, t - t0) * 2.2)
    h1 = block_h(S["en"], size, 900, 940, 3)
    block(c, S["en"], size, 540, y + h1 / 2, P["navy"], a, s * breath, hl=P["blue"], maxw=940, max_lines=3)
    y += h1; _sweep(c, t, t0, 540, y + 4, 560, a); y += 36
    if S.get("he"):
        a2, s2 = PP(t, t0 + 0.2, S); hh = block_h(S["he"], he_size, 700, 940, 2)
        block(c, S["he"], he_size, 540, y + hh / 2, P["blue"], a2, s2, w=700, maxw=940, max_lines=2); y += hh
    return y + 30

# ------------------------------------------------------------------ 0: family tree (hook)
def _tile(c, t, S, it, x, y, w, h, k, big=False):
    shadow_box(c, x, y, w, h, 34, P["card"], stroke=P["navy"], sw=5, sh=10)
    if it.get("flag") == "IR":   # Persian 8-point star band, gold line work
        c.save(); rr(c, x + 6, y + 6, w - 12, 150, 28); c.clip()
        for i in range(-1, 9):
            _star8(c, x + 30 + i * 58 + 8 * math.sin(t * 0.6), y + 40, 20, P["gold"], 0.35)
            _star8(c, x + 59 + i * 58 + 8 * math.sin(t * 0.6), y + 110, 20, P["gold"], 0.25)
        c.restore()
    bob = 8 * math.sin(t * 2.2 + k * 1.7)
    fy = y + (120 if big else 105)
    draw_emoji(c, flag_emoji(it["flag"]), x + w / 2, fy + bob, 150 if big else 140, 1.0, 1 + 0.025 * math.sin(t * 2.8 + k))
    z = 54 if big else 46; ey = fy + 125
    he1 = block_h(it["en"], z, 800, w - 40, 2)
    block(c, it["en"], z, x + w / 2, ey + he1 / 2, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=w - 40, max_lines=2)
    ey += he1 + 12
    T(c, it["he"], 44 if big else 40, x + w / 2, ey + 22, P["gold_text"], 1.0, 1.0, 700, maxw=w - 40)
    if it.get("sub"):
        pill(c, f"{it['sub']} | {it['sub_he']}", 32, x + w / 2, ey + 92, P["navy"], P["white"], 1.0, 1.0, outline=P["gold"], w=800)

def sc_family_tree(c, t, S):
    series_chip(c, t, S)
    A = S["tiles"]; old = St.a
    a, s = PP(t, S["t0"], S)
    St.a *= a
    # connectors (flowing dashes give motion from frame 0)
    c.save(); sa(c, P["blue"]); c.set_line_width(8); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_dash([18, 16], -t * 40)
    c.move_to(295, 900); c.line_to(295, 960); c.line_to(785, 960); c.line_to(785, 900); c.stroke()
    c.move_to(540, 960); c.line_to(540, 1030); c.stroke(); c.restore()
    circ(c, 540, 960, 16, P["gold"], 1.0, stroke=P["white"], sw=4)
    _tile(c, t, S, A[0], 70, 410, 450, 490, 0)
    _tile(c, t, S, A[1], 560, 410, 450, 490, 1)
    _tile(c, t, S, A[2], 230, 1030, 620, 420, 2, big=True)
    _sweep(c, t, S["t0"] - 0.1, 540, 1438, 520, 1.0)
    St.a = old

# ------------------------------------------------------------------ 1: inside me
def sc_inside_me(c, t, S):
    y = _title(c, t, S, 330, 80, 56)
    a, s = PP(t, S["t0"] + 0.25, S, s0=0.6, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a
    cx = 540; hy = max(y + 150, 820)
    c.save(); c.translate(cx, hy + 330); c.scale(s, s); c.translate(-cx, -(hy + 330))
    # bust: body then head
    bt, bb = hy + 150, 1440
    c.new_path(); c.move_to(260, bb); c.curve_to(260, bt + 40, 380, bt, cx, bt); c.curve_to(700, bt, 820, bt + 40, 820, bb); c.close_path()
    sa(c, P["white"]); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(8); c.stroke()
    circ(c, cx, hy, 118, P["white"], 1.0, stroke=P["navy"], sw=8)
    # heart glow in the chest
    pulse = 1 + 0.06 * math.sin(t * 4)
    circ(c, cx, (bt + bb) / 2 + 10, 150 * pulse, P["gold2"], 0.30)
    circ(c, cx, (bt + bb) / 2 + 10, 150 * pulse, P["gold"], 0.0, stroke=P["gold"], sw=4)
    ccy = (bt + bb) / 2 + 10
    for k, f in enumerate(("IR", "US", "IL")):
        ang = t * 0.9 + k * 2 * math.pi / 3
        draw_emoji(c, flag_emoji(f), cx + 120 * math.cos(ang), ccy + 75 * math.sin(ang), 104)
    c.restore(); St.a = old

# ------------------------------------------------------------------ 2: chant
def sc_chant(c, t, S):
    y = heading(c, t, S) + 20; tm = S["times"]
    a, s = PP(t, tm.get("chant", S["t0"] + 0.3) - 0.1, S, s0=0.7, bounce=1.3)
    cy0 = y; ch = 330
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(540, cy0 + ch / 2); c.scale(s, s); c.translate(-540, -(cy0 + ch / 2))
        shadow_box(c, 70, cy0, 940, ch, 34, P["navy"], stroke=P["red"], sw=6, sh=10)
        hq = block_h(S["chant"], 66, 900, 860, 2)
        block(c, S["chant"], 66, 540, cy0 + 40 + hq / 2, P["white"], 1.0, 1.0, 900, maxw=860, max_lines=2)
        T(c, S["chant_he"], 50, 540, cy0 + 70 + hq + 20, P["gold2"], 1.0, 1.0, 700, maxw=860)
        c.restore(); St.a = old
    y = cy0 + ch + 60
    xs = (320, 760)
    for k, chp in enumerate(S["chips"]):
        tk = tm.get(f"c{k}", S["t0"] + 1 + k)
        u = ramp(t, tk - 0.1, tk + 0.35)
        if u > 0:   # red dashed arrow from the card
            c.save(); sa(c, P["red"], u); c.set_line_width(6); c.set_dash([14, 12], -t * 30)
            c.move_to(540, cy0 + ch + 6); c.line_to(lerp(540, xs[k], u), lerp(cy0 + ch + 6, y + 40, u)); c.stroke(); c.restore()
        a2, s2 = PP(t, tk, S)
        if a2 > 0.01:
            old = St.a; St.a *= a2
            c.save(); c.translate(xs[k], y + 140); c.scale(s2, s2)
            shadow_box(c, -170, -100, 340, 220, 30, P["card"], stroke=P["blue"], sw=4, sh=8)
            draw_emoji(c, flag_emoji(chp["flag"]), 0, -25 + 5 * math.sin(t * 2.5 + k), 110)
            T(c, f"{chp['en']} | {chp['he']}", 46, 0, 70, P["navy"], 1.0, 1.0, 800, maxw=300)
            c.restore(); St.a = old
    y += 320
    tf = tm.get("foot", S["t0"] + 2.5); a3, s3 = PP(t, tf, S, bounce=2.4)
    pill(c, S["foot"].replace("*", ""), 58, 540, y, P["gold"], P["navy"], a3, s3, outline=P["navy"], w=900)
    T(c, S["foot_he"], 48, 540, y + 92, P["navy"], a3, s3, 700)
    source(c, t, S)

# ------------------------------------------------------------------ maps
def _base_map(S, key, view, box_, fills, tol=0.6, gold_il=True):
    if key in S: return S[key]
    keep = St.a; St.a = 1.0
    G = RD.geo(); mv = RD.MapView(view, box_)
    base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
    x0, y0, x1, y1 = box_
    bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
    for k_, v in G.items():
        rg = mv.rings(v["g"], tol)
        if not rg: continue
        RD._path(bc, rg)
        fc = P["gold"] if (gold_il and k_ in ("IL", "PS")) else col(fills.get(k_), "land")
        sa(bc, fc); bc.fill_preserve(); sa(bc, P["border"]); bc.set_line_width(1.2); bc.stroke()
    if gold_il and "PS" in G:
        rg = mv.rings(G["PS"]["g"], 0.3)
        if rg: RD._path(bc, rg); sa(bc, P["green"]); bc.set_line_width(3); bc.set_dash([8, 5]); bc.stroke(); bc.set_dash([])
    St.a = keep; S[key] = (mv, base); return S[key]

def _panel(c, box_, base, a):
    x0, y0, x1, y1 = box_
    sa(c, P["navy"], 0.12 * a); rr(c, x0 + 3, y0 + 14, x1 - x0, y1 - y0, 30); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip(); c.set_source_surface(base, 0, 0); c.paint_with_alpha(a * St.a); c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"], a); c.set_line_width(6); c.stroke()

CITIES = [(-0.13, 51.5), (2.35, 48.86), (13.4, 52.5), (12.5, 41.9), (2.17, 41.4), (4.9, 52.37), (14.4, 50.1), (-74, 40.7), (-118.2, 34.05),
          (100.5, 13.75), (139.7, 35.7), (-43.2, -22.9), (151.2, -33.9), (55.3, 25.2), (44.8, 41.7), (-3.7, 40.4), (19.0, 47.5), (-79.4, 43.7)]
TLV = (34.78, 32.08); SHZ = (52.53, 29.59); THR = (51.39, 35.69)

def _arc(p0, p1, lift, n=60):
    mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2 - lift
    return [((1 - u) ** 2 * p0[0] + 2 * u * (1 - u) * mx + u * u * p1[0], (1 - u) ** 2 * p0[1] + 2 * u * (1 - u) * my + u * u * p1[1]) for u in (k / n for k in range(n + 1))]

def _skyline(c, t, x0, base_y, w, u, a):
    """Shiraz line art: cypresses, minarets, arcades, central iwan with a pointed arch, dome, 8-point star frieze. u = wipe 0..1"""
    if u <= 0: return
    c.save(); c.rectangle(x0 - 10, base_y - 300, (w + 20) * u, 320); c.clip()
    navy = P["navy"]; S_ = w / 900.0
    X = lambda fx: x0 + fx * S_
    def strk(lw=5): sa(c, navy, a); c.set_line_width(lw); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
    def pointed_arch(cx, bot, hw, h):
        c.move_to(cx - hw, bot); c.line_to(cx - hw, bot - h * 0.55)
        c.curve_to(cx - hw, bot - h * 0.85, cx - hw * 0.2, bot - h * 0.92, cx, bot - h)
        c.curve_to(cx + hw * 0.2, bot - h * 0.92, cx + hw, bot - h * 0.85, cx + hw, bot - h * 0.55); c.line_to(cx + hw, bot)
    # ground
    c.move_to(x0, base_y); c.line_to(x0 + w, base_y); strk(6)
    # cypresses
    for fx, hh in ((30, 190), (75, 140), (870, 190), (825, 140)):
        cx = X(fx); c.move_to(cx, base_y); c.curve_to(cx - 30 * S_, base_y - hh * 0.4, cx - 14 * S_, base_y - hh * 0.8, cx, base_y - hh)
        c.curve_to(cx + 14 * S_, base_y - hh * 0.8, cx + 30 * S_, base_y - hh * 0.4, cx, base_y); sa(c, P["green"], 0.35 * a); c.fill_preserve(); strk(4)
    # minarets
    for fx in (175, 725):
        cx = X(fx); c.rectangle(cx - 16 * S_, base_y - 230, 32 * S_, 230); strk(5)
        c.rectangle(cx - 24 * S_, base_y - 200, 48 * S_, 14); strk(4)
        c.move_to(cx - 16 * S_, base_y - 230); c.curve_to(cx - 16 * S_, base_y - 255, cx, base_y - 262, cx, base_y - 272)
        c.curve_to(cx, base_y - 262, cx + 16 * S_, base_y - 255, cx + 16 * S_, base_y - 230); strk(4)
    # arcades
    for side in (-1, 1):
        for k in range(3):
            cx = X(450 + side * (165 + k * 62)); pointed_arch(cx, base_y, 22 * S_, 100); strk(4)
        xa, xb = X(450 + side * 135), X(450 + side * 300)
        c.move_to(min(xa, xb), base_y - 118); c.line_to(max(xa, xb), base_y - 118); strk(4)
    # dome behind the iwan
    cx = X(450); c.move_to(cx - 120 * S_, base_y - 175)
    c.curve_to(cx - 125 * S_, base_y - 250, cx - 40 * S_, base_y - 270, cx, base_y - 298)
    c.curve_to(cx + 40 * S_, base_y - 270, cx + 125 * S_, base_y - 250, cx + 120 * S_, base_y - 175)
    sa(c, P["blue"], 0.22 * a); c.fill_preserve(); strk(5)
    # iwan block
    c.rectangle(cx - 135 * S_, base_y - 190, 270 * S_, 190); sa(c, P["white"], a); c.fill_preserve(); strk(6)
    pointed_arch(cx, base_y, 70 * S_, 150); sa(c, P["blue"], 0.18 * a); c.fill_preserve(); strk(5)
    pointed_arch(cx, base_y, 52 * S_, 118); strk(3)
    # star frieze
    for k in range(5):
        _star8(c, cx - 112 * S_ + k * 56 * S_, base_y - 172, 9, P["gold"], a, fill=True)
    c.restore()

def sc_travel(c, t, S):
    y = _title(c, t, S, 320, 68, 48); tm = S["times"]
    box_ = (60, y, 1020, y + 320)
    mv, base = _base_map(S, "_m", [-125, -42, 155, 66], box_, {"IR": "blue"}, tol=1.2, gold_il=True)
    a = fade_in(t, S["t0"] + 0.1, S, 0.3); old = St.a; St.a *= a
    _panel(c, box_, base, 1.0)
    c.save(); rr(c, *box_[:2], box_[2] - box_[0], box_[3] - box_[1], 30); c.clip()
    tl = mv.P(*TLV)
    for k, ll in enumerate(CITIES):
        tk = S["t0"] + 0.35 + 0.13 * k; u = ramp(t, tk, tk + 0.4)
        if u <= 0: continue
        p = mv.P(*ll); pts = _arc(tl, p, 0.18 * math.hypot(p[0] - tl[0], p[1] - tl[1]))
        n = max(2, int(len(pts) * u))
        c.save(); c.move_to(*pts[0])
        for q in pts[1:n]: c.line_to(*q)
        sa(c, P["navy"], 0.45); c.set_line_width(2.5); c.set_dash([6, 6]); c.stroke(); c.restore()
        if u > 0.9:
            pr = 1 + 0.25 * math.sin(t * 4 + k)
            circ(c, p[0], p[1], 9 * pr, P["blue"], 1.0, stroke=P["white"], sw=3)
    sp = mv.P(*SHZ); pr = 1 + 0.2 * math.sin(t * 5)
    _star8(c, sp[0], sp[1], 16 * pr, P["gold"], 1.0, fill=True)
    circ(c, tl[0], tl[1], 10, P["gold"], 1.0, stroke=P["navy"], sw=3)
    c.restore()
    T(c, "Shiraz", 30, sp[0] + 70, sp[1] + 6, P["navy"], 1.0, 1.0, 800, maxw=200)
    # chip
    a2, s2 = PP(t, tm.get("chip", S["t0"] + 2), S, bounce=2.4)
    pill(c, S["chip"].replace("*", ""), 42, 510, box_[3] + 44, P["navy"], P["white"], a2, s2, outline=P["gold"], w=800)
    draw_emoji(c, "☕", 720, box_[3] + 44, 56, a2, s2)
    T(c, S["chip_he"], 36, 540, box_[3] + 104, P["navy"], a2, s2, 700)
    # skyline
    u = ramp(t, S["t0"] + 0.5, S["t0"] + 2.2)
    _skyline(c, t, 110, 1462, 860, u, 1.0)
    St.a = old
    a3 = ramp(t, S["t0"] + 1.6, S["t0"] + 2.0)
    T(c, f"{S['city']} | {S['city_he']}", 34, 540, 1530, P["gold_text"], a3, 1.0, 800, maxw=900)

def sc_peace(c, t, S):
    y = _title(c, t, S, 320, 68, 48); tm = S["times"]
    box_ = (60, y, 1020, y + 430)
    mv, base = _base_map(S, "_m", [25, 23, 66, 42], box_, {"IR": "blue"}, tol=0.5)
    a = fade_in(t, S["t0"] + 0.05, S, 0.3); old = St.a; St.a *= a
    _panel(c, box_, base, 1.0)
    pi, pt = mv.P(*THR), mv.P(*TLV)
    pts = _arc(pt, pi, 150)
    tf = tm.get("fly", S["t0"] + 1.0); u = ramp(t, tf - 0.4, tf + 0.4)
    if u > 0:
        n = max(2, int(len(pts) * u)); c.save(); c.move_to(*pts[0])
        for q in pts[1:n]: c.line_to(*q)
        sa(c, P["gold_text"]); c.set_line_width(6); c.set_dash([14, 12], -t * 30); c.stroke(); c.restore()
    if u >= 1:
        ph = ((t - tf - 0.4) / 2.4) % 2; f = ph if ph < 1 else 2 - ph; f = ease(f)
        i = min(len(pts) - 2, int(f * (len(pts) - 1))); p, q = pts[i], pts[i + 1]
        ang = math.atan2(q[1] - p[1], q[0] - p[0]) if ph < 1 else math.atan2(p[1] - q[1], p[0] - q[0])
        draw_emoji(c, "✈️", p[0], p[1], 64, 1.0, 1.0, ang + math.pi / 4)
        mid = pts[len(pts) // 2]; draw_emoji(c, "🕊️", mid[0], mid[1] - 60 + 6 * math.sin(t * 3), 70)
    for (p, en, he, cc) in ((pi, "Iran", "איראן", "blue"), (pt, "Israel", "ישראל", "gold")):
        circ(c, p[0], p[1], 12, P[cc], 1.0, stroke=P["white"], sw=4)
    pill(c, "Iran | איראן", 38, pi[0] - 10, pi[1] + 90, P["white"], P["navy"], 1.0, 1.0, outline=P["blue"], w=800)
    pill(c, "Israel | ישראל", 38, pt[0] + 40, pt[1] + 90, P["white"], P["navy"], 1.0, 1.0, outline=P["gold"], w=800)
    St.a = old
    # history note
    ta = S["t0"] + 1.2; a2, s2 = PP(t, ta, S)
    if a2 > 0.01:
        ny = box_[3] + 30; old = St.a; St.a *= a2
        hn = block_h(S["note"], 40, 800, 860, 2); hh = block_h(S["note_he"], 34, 700, 860, 2)
        shadow_box(c, 70, ny, 940, hn + hh + 60, 28, P["card"], stroke=P["gold"], sw=4, sh=6)
        block(c, S["note"], 40, 540, ny + 25 + hn / 2, P["navy"], 1.0, 1.0, 800, hl=P["gold_text"], maxw=860, max_lines=2)
        block(c, S["note_he"], 34, 540, ny + 35 + hn + hh / 2, P["blue"], 1.0, 1.0, 700, maxw=860, max_lines=2)
        St.a = old
    source(c, t, S)

# ------------------------------------------------------------------ split
def sc_split(c, t, S):
    tm = S["times"]; t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S)
    pill(c, S["top"], 50, 540, 310, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
    T(c, S["top_he"], 42, 540, 382, P["navy"], a, s, 700)
    for k, (key, x) in enumerate((("left", 70), ("right", 555))):
        it = S[key]; tk = tm.get(key, t0 + 0.4 + 2 * k)
        a2, s2 = PP(t, tk, S, s0=0.6, bounce=1.5)
        if a2 <= 0.01: continue
        old = St.a; St.a *= a2; cw_, y0 = 455, 440; ch = 610
        c.save(); c.translate(x + cw_ / 2, y0 + ch / 2); c.scale(s2, s2); c.translate(-(x + cw_ / 2), -(y0 + ch / 2))
        cc = P[it["color"]]
        shadow_box(c, x, y0, cw_, ch, 32, P["card"], stroke=cc, sw=6, sh=8)
        for j, em in enumerate(it["icons"]):
            draw_emoji(c, em, x + cw_ / 2 + (j - 1) * 130, y0 + 95 + 6 * math.sin(t * 2.4 + j + k), 96)
        he1 = block_h(it["en"], 52, 800, cw_ - 50, 3)
        block(c, it["en"], 52, x + cw_ / 2, y0 + 195 + he1 / 2, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=cw_ - 50, max_lines=3)
        yy = y0 + 195 + he1 + 14; hh = block_h(it["he"], 40, 700, cw_ - 50, 2)
        block(c, it["he"], 40, x + cw_ / 2, yy + hh / 2, P["gold_text"], 1.0, 1.0, 700, maxw=cw_ - 50, max_lines=2)
        vy = y0 + ch - 105
        pill(c, it["verdict"], 40, x + cw_ / 2, vy, cc, P["white"], 1.0, 1.0, w=800)
        T(c, it["verdict_he"], 34, x + cw_ / 2, vy + 62, cc, 1.0, 1.0, 700, maxw=cw_ - 40)
        draw_emoji(c, "✅" if k == 0 else "❌", x + cw_ - 30, y0 + 20, 64)
        c.restore(); St.a = old
    tf = tm.get("foot", t0 + 4); a3, s3 = PP(t, tf, S, bounce=2.4)
    pill(c, S["foot"].replace("*", ""), 54, 540, 1110, P["red"], P["white"], a3, s3, outline=P["navy"], w=900)
    T(c, S["foot_he"], 42, 540, 1182, P["navy"], a3, s3, 700)
    tn = tm.get("note", t0 + 3); a4, s4 = PP(t, tn, S)
    if a4 > 0.01:
        old = St.a; St.a *= a4; ny = 1232
        hn = block_h(S["note"], 38, 800, 860, 2); hh = block_h(S["note_he"], 33, 700, 860, 2)
        shadow_box(c, 70, ny, 940, hn + hh + 55, 26, P["card"], stroke=P["grey"], sw=3, sh=6)
        block(c, S["note"], 38, 540, ny + 22 + hn / 2, P["navy"], 1.0, 1.0, 800, hl=P["red"], maxw=860, max_lines=2)
        block(c, S["note_he"], 33, 540, ny + 32 + hn + hh / 2, P["grey"], 1.0, 1.0, 700, maxw=860, max_lines=2)
        St.a = old
    source(c, t, S)

# ------------------------------------------------------------------ rows2 (from this_life/scenes_tl.py)
def sc_rows2(c, t, S):
    y = heading(c, t, S) + 10; items = S["items"]; n = len(items); foot = S.get("footer")
    room = CONTENT_BOTTOM - y - (190 if foot else 10)
    z_en, z_he = S.get("size", 54), S.get("size_he", 42)
    def hs(z1, z2): return [30 + block_h(it.get("en"), z1, 800, 720, 2) + (10 + block_h(it.get("he"), z2, 700, 720, 2) if it.get("he") else 0) + 30 for it in items]
    H_ = hs(z_en, z_he)
    while sum(H_) + 26 * (n - 1) > room and z_en > 36: z_en -= 2; z_he -= 2; H_ = hs(z_en, z_he)
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2); yy = y
    for k, it in enumerate(items):
        bh = H_[k]; tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        if t < tk - 0.07: yy += bh + 26; continue
        a = fade_in(t, tk - 0.07, S, 0.2); u = ease((t - tk + 0.07) / 0.35); dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, 70, yy, 940, bh, 36, P["card"], stroke=col(it.get("color"), "silver"), sw=3, sh=6)
        em = icon_of(it)
        if em: draw_emoji(c, em, 145, yy + bh / 2 + 5 * math.sin(t * 2.5 + k), 76)
        he_ = block_h(it.get("en"), z_en, 800, 720, 2); cy = yy + 30 + he_ / 2
        block(c, it.get("en"), z_en, 585, cy, P["navy"], 1.0, 1.0, 800, hl=col(it.get("hl"), "blue"), maxw=720, max_lines=2)
        if it.get("he"):
            hh = block_h(it["he"], z_he, 700, 720, 2); block(c, it["he"], z_he, 585, yy + 30 + he_ + 10 + hh / 2, P["gold_text"], 1.0, 1.0, 700, maxw=720, max_lines=2)
        c.restore(); St.a = old; yy += bh + 26
    source(c, t, S)

# ------------------------------------------------------------------ beach
def sc_beach(c, t, S):
    y = _title(c, t, S, 330, 72, 50); tm = S["times"]
    x0, y0, x1, y1 = 70, max(y, 700), 1010, 1450
    a = fade_in(t, S["t0"] + 0.1, S, 0.35); old = St.a; St.a *= a
    sa(c, P["navy"], 0.12); rr(c, x0 + 3, y0 + 14, x1 - x0, y1 - y0, 34); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 34); c.clip()
    g = cairo.LinearGradient(0, y0, 0, y1); g.add_color_stop_rgb(0, 0.80, 0.90, 0.98); g.add_color_stop_rgb(1, 0.98, 0.93, 0.82)
    c.rectangle(x0, y0, x1 - x0, y1 - y0); c.set_source(g); c.fill()
    hz = y0 + (y1 - y0) * 0.45; sun_u = ramp(t, S["t0"], S["t0"] + 1.5)
    circ(c, 780, hz - 40 - 70 * sun_u, 80, P["gold2"], 1.0); circ(c, 780, hz - 40 - 70 * sun_u, 110, P["gold2"], 0.3)
    sea_b = y0 + (y1 - y0) * 0.68
    c.rectangle(x0, hz, x1 - x0, sea_b - hz); sa(c, P["blue"], 0.85); c.fill()
    for k in range(4):   # waves
        yy = hz + 25 + k * 34; c.move_to(x0, yy)
        for xx in range(x0, x1 + 10, 10): c.line_to(xx, yy + 6 * math.sin(xx / 38 + t * 2.2 + k))
        sa(c, P["white"], 0.55); c.set_line_width(3); c.stroke()
    c.move_to(x0, sea_b)
    for xx in range(x0, x1 + 10, 10): c.line_to(xx, sea_b + 8 * math.sin(xx / 50 + t * 1.6))
    c.line_to(x1, y1); c.line_to(x0, y1); c.close_path(); sa(c, (0.95, 0.86, 0.66, 1)); c.fill()
    # umbrella
    ux, uy = 330, sea_b - 40
    c.move_to(ux, uy); c.line_to(ux + 40, y1 - 60); sa(c, P["navy"]); c.set_line_width(7); c.stroke()
    for k in range(6):
        a0, a1 = math.pi + k * math.pi / 6, math.pi + (k + 1) * math.pi / 6
        c.move_to(ux, uy); c.arc(ux, uy, 190, a0, a1); c.close_path(); sa(c, P["navy"] if k % 2 == 0 else P["white"]); c.fill()
    c.arc(ux, uy, 190, math.pi, 2 * math.pi); sa(c, P["gold"]); c.set_line_width(4); c.stroke()
    # towels with flags, popping on "beach"
    tb = tm.get("beach", S["t0"] + 1.0)
    for k, (f, tx) in enumerate((("IR", 300), ("US", 540), ("IL", 780))):
        a2, s2 = PP(t, tb + 0.15 * k, S)
        if a2 <= 0.01: continue
        ty = y1 - 95; o2 = St.a; St.a *= a2
        c.save(); c.translate(tx, ty); c.scale(s2, s2); c.rotate(-0.06 + 0.06 * k)
        box(c, -95, -45, 190, 90, 14, P["white"], 1.0, stroke=P["gold"], sw=4)
        for j in range(3): box(c, -95, -45 + 18 + j * 24, 190, 8, 3, P["blue"], 0.35)
        draw_emoji(c, flag_emoji(f), 0, 0, 78)
        c.restore(); St.a = o2
    # beach ball
    bx = 600 + 120 * math.sin(t * 1.3); by = sea_b + 40 - abs(60 * math.sin(t * 3.0))
    draw_emoji(c, "🏐", bx, by, 64)
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 34); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    St.a = old
