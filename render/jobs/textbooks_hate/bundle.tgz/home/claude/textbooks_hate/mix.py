"""local step: loopable documentary piano bed (safety_v4/audio_v4.py doc_music) re-timed to a whole number of bars in T_END,
overflow folded onto the start so the end flows into frame 0; the "flip" lands on the reveal (line 18); soft hits on 18 and 20.
Method: empires_israel/mix.py."""
import sys, os, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/textbooks_hate"
W = json.load(open(f"{D}/work/words.json"))["words"]
LS = lambda li: min(w["t0"] for w in W if w["li"] == li); LE = lambda li: max(w["t1"] for w in W if w["li"] == li)
dur = round(LE(18) + 0.6, 2); SR = AU.SR; TURN = LS(10) - 0.3
bars = round(dur / (4 * 60 / 92)); bpm = 4 * 60 * bars / dur; bar = 4 * 60 / bpm
raw = AU.doc_music(dur + bar, bpm=bpm, flip_at=TURN, end_ring=0.01)
n = int(round(dur * SR)); xf = int(0.6 * SR)
bed = raw[:, :n].copy(); tail = raw[:, n:n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(TURN + 0.25, AU.soft_hit(), -5.0), (LS(16) - 0.05, AU.soft_hit(), -9.0), (LS(3) + 0.3, AU.soft_hit(), -10.0), (LS(1) - 0.05, AU.soft_hit(), -11.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, dur, ev, mw, music_db=-19.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=dur, bpm=bpm, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", dur, bpm, J.get("final_I"), J.get("final_TP"))
