"""geo_prep.py: geo/geo.json for textbooks_hate. Natural Earth 1:50m (public domain).
Region box Morocco to Iran; whole land of Israel (ISR + PSX + Golan), PSX rings for the Green Line."""
import json
from shapely.geometry import shape, mapping, box
from shapely.ops import unary_union
NE = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
ne = {f["properties"]["ADM0_A3"]: shape(f["geometry"]).buffer(0) for f in NE["features"]}
DIS = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_breakaway_disputed_areas.geojson"))
golan = [shape(f["geometry"]).buffer(0) for f in DIS["features"] if "Golan" in json.dumps(f["properties"])]
reg = box(-20, 2, 68, 48)
def ser(g, tol): return mapping(g.simplify(tol, preserve_topology=True))
land = {k: ser(g.intersection(reg), 0.03) for k, g in ne.items() if g.intersects(reg) and k not in ("ISR", "PSX")}
isr = unary_union([ne["ISR"], ne["PSX"]] + golan)
out = dict(land=land, israel=ser(isr, 0.004), psx=ser(ne["PSX"], 0.004))
json.dump(out, open("geo/geo.json", "w")); print(len(land), sorted(land)[:80])
