"""textbooks_hate: "What do kids learn about Jews?" (@noamroz__, English, 2 Nov 2026).
Government curricula, not people: a reviewed textbook page (Jordan, History Grade 12, 2025, via IMPACT-se), a scorecard of
8 school systems x 4 questions (sorted best first, revealed from the bottom up), a "Not perfect either" card (Bar-Tal, Adwan,
Wexler 2013), and a region map where the reforming curricula light up. Circular: the lead-in sits where the hook sits and
the last 0.45 s cross-fade into frame 0. Brand: brandbook night palette, Heebo.
usage: python3 reel.py [--snaps 0,3.1,...] | python3 reel.py --out work/silent.mp4"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/textbooks_hate"; FD = "/home/claude/vid/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ brand (brandbook v1)
NIGHT, NAVY, NAVY2, SKY, GOLD, SAND, GREEN, RED, AMBER, INK, MUTE, LINE = (
    "#0B1426", "#163261", "#1E3F78", "#45A4DD", "#FFCD50", "#C9A85C", "#3FBF7F", "#E5484D", "#F5A524", "#F4F6FA", "#9AA7BE", "#24324D")
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def rgba(h, a=1.0): return hx(h) + (int(max(0, min(1, a)) * 255),)

# ------------------------------------------------------------------ timing
WORDS = json.load(open(f"{D}/work/words.json"))["words"]; T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WT(li, word, n=1, end=False):
    c = 0
    for w in LW[li]:
        if re.sub(r"\W", "", w["w"]).lower().startswith(word.lower()):
            c += 1
            if c == n: return w["t1" if end else "t0"]
    raise KeyError((li, word))
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def back(u):
    u = clamp(u); c = 1.7; return 1 + (c + 1) * (u - 1) ** 3 + c * (u - 1) ** 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def win(t, t0, t1, a=0.3, b=0.3): return seg(t, t0, t0 + a) * (1 - seg(t, t1, t1 + b))
def lerp(a, b, u): return a + (b - a) * u

T_BOOK = S(1) - 0.15; T_MAP1 = S(4) - 0.15; T_TAB = S(5) - 0.15; T_FAIR = S(15) - 0.15; T_PAY = S(16) - 0.15; T_PAY2 = S(17) - 0.1
T_LEAD = S(18) - 0.12

# ------------------------------------------------------------------ text
_fc = {}
def F(sz, w=800):
    k = (int(round(sz)), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FD}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def fit(s, sz, w=900, maxw=940):
    while F(sz, w).getlength(s) > maxw and sz > 40: sz -= 2
    return sz
def text(base, xy, s, sz, w=800, col=INK, a=1.0, anchor="mm", halo=False, scale=1.0):
    """text with true alpha (drawn on a small layer); optional dark halo for map labels"""
    if a <= 0.004 or not s: return
    f = F(sz * scale, w); d0 = ImageDraw.Draw(base)
    x0, y0, x1, y1 = [int(v) for v in d0.textbbox(xy, s, font=f, anchor=anchor)]
    pad = 18 if halo else 3; x0 -= pad; y0 -= pad; x1 += pad; y1 += pad
    L = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    if halo:
        d.text((xy[0] - x0, xy[1] - y0), s, font=f, fill=(4, 8, 18, 255), anchor=anchor, stroke_width=7, stroke_fill=(4, 8, 18, 255))
        L = L.filter(ImageFilter.GaussianBlur(3)); d = ImageDraw.Draw(L)
    d.text((xy[0] - x0, xy[1] - y0), s, font=f, fill=hx(col) + (255,), anchor=anchor)
    if a < 0.999: L.putalpha(L.getchannel("A").point(lambda v: int(v * a)))
    base.alpha_composite(L, (x0, y0))
def rich(base, y, parts, sz, w=900, a=1.0, cx=540):
    f = F(sz, w); ws = [f.getlength(p) for p, _ in parts]; x = cx - sum(ws) / 2
    for (p, c), w_ in zip(parts, ws): text(base, (x, y), p, sz, w, c, a, anchor="ls"); x += w_
def rrect(base, box, r, fill=None, outline=None, width=0):
    L = Image.new("RGBA", base.size, (0, 0, 0, 0)); ImageDraw.Draw(L).rounded_rectangle(box, r, fill=fill, outline=outline, width=width)
    base.alpha_composite(L)

# ------------------------------------------------------------------ background: night with a soft navy glow
def make_bg():
    y = np.linspace(0, 1, H)[:, None]; x = np.linspace(-1, 1, W)[None, :]
    g = np.exp(-((x * 0.9) ** 2 + ((y - 0.42) * 1.6) ** 2) * 1.6)[..., None]
    a, b = np.array(hx(NIGHT), float), np.array(hx(NAVY), float)
    return Image.fromarray((a * (1 - 0.55 * g) + b * 0.55 * g).astype(np.uint8), "RGB").convert("RGBA")
BG = make_bg()

# ------------------------------------------------------------------ the textbook page (clean mock-up: quote text only)
PX0, PY0, PW, PH = 100, 360, 880, 1060
def make_page():
    S_ = 2; im = Image.new("RGBA", (PW * S_, PH * S_), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, PW * S_ - 1, PH * S_ - 1), 30 * S_, fill=hx(INK) + (255,))
    d.rounded_rectangle((0, 0, PW * S_ - 1, 170 * S_), 30 * S_, fill=hx(NAVY) + (255,)); d.rectangle((0, 120 * S_, PW * S_, 170 * S_), fill=hx(NAVY) + (255,))
    im = im.resize((PW, PH), Image.LANCZOS); d = ImageDraw.Draw(im)
    d.text((52, 72), "HISTORY", font=F(72, 900), fill=hx(INK), anchor="lm")
    d.text((52, 132), "Grade 12  ·  Vol. 1  ·  Jordan, 2025", font=F(40, 700), fill=hx(SKY), anchor="lm")
    fl = Image.open(f"{D}/flags/jo.png").convert("RGBA"); fl = fl.resize((110, round(fl.height * 110 / fl.width)), Image.LANCZOS)
    im.alpha_composite(fl, (PW - 52 - 110, 85 - fl.height // 2))
    d.text((52, 238), "The Balfour Promise, 1917", font=F(52, 800), fill=hx(NAVY), anchor="lm")
    d.text((PW - 52, 238), "p. 120", font=F(40, 700), fill=hx("#5B6B82"), anchor="rm")
    bar = hx("#D5DCEA")
    for i, wfrac in enumerate([1.0, 0.94, 0.97, 0.62]):
        y = 312 + i * 46; d.rounded_rectangle((52, y, 52 + (PW - 104) * wfrac, y + 18), 9, fill=bar)
    for i, wfrac in enumerate([0.98, 1.0, 0.9, 0.96, 0.7]):
        y = 770 + i * 46; d.rounded_rectangle((52, y, 52 + (PW - 104) * wfrac, y + 18), 9, fill=bar)
    return im
PAGE = make_page()
QUOTE = ["“...the Jewish role in", "destroying the German", "economy...”"]
QY = [540, 626, 712]; QSZ = 72
def page(base, t, x, y, sc, a, hl):
    if a <= 0.004: return
    L = PAGE.copy(); d = ImageDraw.Draw(L)
    # gold highlighter sweep behind the quote, line by line
    f = F(QSZ, 900)
    for i, (s, qy) in enumerate(zip(QUOTE, QY)):
        u = clamp(hl * 3 - i)
        if u > 0:
            w_ = f.getlength(s); d.rounded_rectangle((44, qy - 46, 44 + 16 + w_ * eout(u), qy + 40), 12, fill=hx(GOLD) + (255,))
    for s, qy in zip(QUOTE, QY): d.text((52, qy), s, font=f, fill=hx(NAVY), anchor="lm")
    d.text((52, PH - 70), "Translated by IMPACT-se, an Israel-based", font=F(36, 400), fill=hx("#5B6B82"), anchor="lm")
    d.text((52, PH - 28), "watchdog. Review of Jordan, May 2026", font=F(36, 400), fill=hx("#5B6B82"), anchor="lm")
    if sc != 1.0: L = L.resize((int(PW * sc), int(PH * sc)), Image.LANCZOS)
    # shadow
    sh = Image.new("RGBA", (L.width + 80, L.height + 80), (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle((40, 52, L.width + 40, L.height + 52), 34, fill=(0, 0, 0, 150))
    sh = sh.filter(ImageFilter.GaussianBlur(18))
    if a < 0.999:
        sh.putalpha(sh.getchannel("A").point(lambda v: int(v * a))); L.putalpha(L.getchannel("A").point(lambda v: int(v * a)))
    base.alpha_composite(sh, (int(x - 40), int(y - 40))); base.alpha_composite(L, (int(x), int(y)))

def stamp(base, t, t0, a):
    k = clamp((t - t0) / 0.28)
    if k <= 0 or a <= 0: return
    s = 1.5 - 0.5 * back(k); al = clamp(k * 2.5) * a
    f = F(86, 900); tw = f.getlength("CONSPIRACY MYTH"); bw, bh = int(tw + 70), 150
    L = Image.new("RGBA", (bw + 40, bh + 40), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    d.rounded_rectangle((20, 20, 20 + bw, 20 + bh), 22, fill=(255, 255, 255, 235), outline=hx(RED) + (255,), width=9)
    d.text((20 + bw / 2, 20 + bh / 2 + 4), "CONSPIRACY MYTH", font=f, fill=hx(RED), anchor="mm")
    L = L.rotate(7, resample=Image.BICUBIC, expand=True); L = L.resize((int(L.width * s), int(L.height * s)), Image.LANCZOS)
    L.putalpha(L.getchannel("A").point(lambda v: int(v * al)))
    base.alpha_composite(L, (int(540 - L.width / 2), int(1190 - L.height / 2)))

# ------------------------------------------------------------------ the scorecard
#   values: G good (green), P partly (amber), B bad (red), N no data (grey); trend U better, S same
ROWS = [  # sorted best first (score: G=1, P=0.5 over the first 3 columns, +1 for better)
    dict(k="UAE", name=["UAE"], flag="ae", v=[("None", "G"), ("Rare", "P"), ("Yes", "G"), "U"], iso="ARE"),
    dict(k="Morocco", name=["Morocco"], flag="ma", v=[("None", "G"), ("No data", "N"), ("Yes", "G"), "U"], iso="MAR"),
    dict(k="Egypt", name=["Egypt"], flag="eg", v=[("Some", "P"), ("No", "B"), ("Yes", "G"), "U"], iso="EGY"),
    dict(k="Saudi", name=["Saudi", "Arabia"], flag="sa", v=[("Some", "P"), ("No", "B"), ("Some", "P"), "U"], iso="SAU"),
    dict(k="Jordan", name=["Jordan"], flag="jo", v=[("Yes", "B"), ("No", "B"), ("Some", "P"), "S"], iso="JOR"),
    dict(k="Qatar", name=["Qatar"], flag="qa", v=[("Yes", "B"), ("No", "B"), ("No", "B"), "S"], iso="QAT"),
    dict(k="PA", name=["Palestinian", "Authority"], flag="ps", v=[("Yes", "B"), ("No", "B"), ("No", "B"), "S"], iso="PSX"),
    dict(k="Iran", name=["Iran", "not Arab"], flag="ir", v=[("Yes", "B"), ("No", "B"), ("No", "B"), "S"], iso="IRN"),
]
FLAGS = {r["k"]: Image.open(f"{D}/flags/{r['flag']}.png").convert("RGBA") for r in ROWS}
def flag_img(k, w):
    im = FLAGS[k]; return im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
FL80 = {k: flag_img(k, 80) for k in FLAGS}; FL96 = {k: flag_img(k, 96) for k in FLAGS}
# reveal order and times (bottom up): line, time of the name
REV = {"Iran": (6, WT(6, "Iran")), "PA": (7, WT(7, "Palestinian")), "Qatar": (8, WT(8, "Qatar")), "Jordan": (9, WT(9, "Jordan")),
       "Saudi": (11, WT(11, "Saudi")), "Egypt": (12, WT(12, "Egypt")), "Morocco": (13, WT(13, "Morocco")), "UAE": (14, WT(14, "Emirates"))}
CELLT = {"Iran": [WT(6, "Antisemitism"), WT(6, "Israel"), WT(6, "Israel") + 0.2, WT(6, "change")]}
for k, (li, t0) in REV.items():
    if k not in CELLT: CELLT[k] = [t0 + 0.35 + 0.16 * j for j in range(4)]
NEXT = {}
_ord = sorted(REV, key=lambda k: REV[k][1])
for i, k in enumerate(_ord): NEXT[k] = REV[_ord[i + 1]][1] - 0.1 if i + 1 < len(_ord) else E(14) + 0.2
TY = 215; LGY = [292, 350, 408, 466]; HDY = 540; RY0 = 585; RH = 104
CXS = [520, 663, 806, 949]; CW_ = 136
LEG = ["Antisemitic content found?", "Israel on the map?", "Peace or tolerance taught?", "Getting better?"]
LEGT = [WT(5, "Antisemitic"), WT(5, "Israel"), WT(5, "Peace"), WT(5, "Getting")]
VC = {"G": GREEN, "P": AMBER, "B": RED, "N": "#5B6B82"}

def pill_num(base, x, y, n, a, r=24, col=SKY):
    L = Image.new("RGBA", base.size, (0, 0, 0, 0)); ImageDraw.Draw(L).ellipse((x - r, y - r, x + r, y + r), fill=rgba(col, a)); base.alpha_composite(L)
    text(base, (x, y + 1), str(n), 34 if r < 30 else 40, 900, NIGHT, a)

def cell(base, x, y, v, k, a):
    if k <= 0 or a <= 0: return
    s = max(0.05, back(k)); L = Image.new("RGBA", (180, 110), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    if isinstance(v, str):  # trend
        col = GREEN if v == "U" else "#5B6B82"
        d.ellipse((90 - 36, 55 - 36, 90 + 36, 55 + 36), fill=hx(col) + (255,))
        if v == "U":
            d.polygon([(90, 30), (113, 56), (99, 56), (99, 80), (81, 80), (81, 56), (67, 56)], fill=(255, 255, 255, 255))
        else:
            d.rounded_rectangle((68, 49, 112, 61), 6, fill=(255, 255, 255, 255))
    else:
        s_, c = v; col = VC[c]
        d.rounded_rectangle((90 - CW_ / 2, 55 - 36, 90 + CW_ / 2, 55 + 36), 20, fill=hx(col) + (255,))
        tc = NIGHT if c in ("P", "G") else INK
        if s_ == "No data":
            d.text((90, 38), "No", font=F(36, 800), fill=hx(INK), anchor="mm"); d.text((90, 73), "data", font=F(36, 800), fill=hx(INK), anchor="mm")
        else: d.text((90, 57), s_, font=F(50, 900), fill=hx(tc), anchor="mm")
    if s != 1: L = L.resize((max(2, int(180 * s)), max(2, int(110 * s))), Image.LANCZOS)
    if a < 0.999: L.putalpha(L.getchannel("A").point(lambda q: int(q * a)))
    base.alpha_composite(L, (int(x - L.width / 2), int(y - L.height / 2)))

# callouts: (key, t0, t1, box, lines [(text, size, weight, colour)], source)
CALL = [
    ("Iran", WT(6, "Iran"), E(6) + 0.25, [("Not an Arab country.", 64, 900, INK), ("Included as a neighbour.", 48, 700, MUTE)], ["ADL 2021; IMPACT-se 2022"]),
    ("PA", WT(7, "study"), E(7) + 0.25, [("On one religious education book:", 40, 700, SKY), ("“cumulative stereotypes and", 50, 800, INK),
                                         ("accusations that can clearly be", 50, 800, INK), ("characterised as anti-Semitic.”", 50, 800, GOLD)],
     ["Georg Eckert Institute, for the EU, 2021"]),
    ("Qatar", WT(8, "Qatar"), E(8) + 0.25, [("Problem content", 64, 900, INK), ("unchanged, 4th year running", 56, 800, GOLD)], ["IMPACT-se review, Feb 2026"]),
    ("Jordan", WT(9, "Jordan"), E(9) + 0.25, [("“Jews and Israel are repeatedly", 50, 800, INK), ("excluded from the curriculum's", 50, 800, INK),
                                             ("tolerance framework.”", 50, 800, GOLD)], ["IMPACT-se, an Israel-based watchdog, May 2026"]),
    ("Saudi", WT(11, "Saudi"), E(11) + 0.2, [("Earlier antisemitic examples:", 54, 800, INK), ("removed", 72, 900, GREEN),
                                            ("Still flagged: “cunning and devious” Zionists", 40, 700, MUTE)], ["IMPACT-se 2023 and July 2026"]),
    ("Egypt", WT(12, "Egypt"), E(12) + 0.2, [("Students learn the 1979", 60, 900, INK), ("peace treaty with Israel", 60, 900, GREEN),
                                            ("Some older high school books not revised yet", 40, 700, MUTE)], ["IMPACT-se 2023 and Dec 2024"]),
    ("Morocco", WT(13, "Morocco"), E(13) + 0.2, [("Jewish history and culture", 60, 900, INK), ("in the curriculum, 2020", 60, 900, GREEN),
                                                ("Jews shown “frequently and warmly”", 40, 700, MUTE)], ["Morocco education ministry, Dec 2020; IMPACT-se 2023"]),
    ("UAE", WT(14, "Emirates"), E(14) + 0.05, [("Abraham Accords from Grade 6", 58, 900, INK), ("Holocaust lessons announced, 2023", 50, 800, GREEN),
                                              ("Most maps still leave Israel off", 40, 700, MUTE)], ["IMPACT-se 2022; AP, Jan 2023"]),
]
TOPBOX = (70, 640, 1010, 1000); BOTBOX = (70, 1040, 1010, 1400)
def callouts(base, t):
    for k, t0, t1, lines, src in CALL:
        a = win(t, t0 + 0.15, t1, 0.25, 0.25)
        if a <= 0: continue
        box = TOPBOX if k in ("Iran", "PA", "Qatar", "Jordan") else BOTBOX
        dy = (1 - eout(clamp((t - t0 - 0.15) / 0.3))) * 30
        x0, y0, x1, y1 = box; y0 += dy; y1 += dy
        rrect(base, (x0, y0, x1, y1), 28, fill=rgba("#0E1C38", 0.96 * a), outline=rgba(SKY if box is TOPBOX else GREEN, a), width=4)
        hs = [sz * 1.22 for _, sz, _, _ in lines]; tot = sum(hs) + 56; y = (y0 + y1) / 2 - tot / 2
        for (s_, sz, w_, c), h_ in zip(lines, hs): text(base, (540, y + h_ / 2), s_, fit(s_, sz, w_, 880), w_, c, a); y += h_
        for j, s_ in enumerate(src): text(base, (540, y + 24 + j * 42), s_, 36, 400, MUTE, a)

def table(base, t):
    a = win(t, T_TAB, T_FAIR - 0.05, 0.35, 0.3)
    if a <= 0: return
    text(base, (540, TY), "8 school systems", 76, 900, INK, a)
    for i, s_ in enumerate(LEG):
        k = clamp((t - LEGT[i] + 0.1) / 0.25); hot = win(t, LEGT[i] - 0.1, LEGT[i] + 1.1, 0.2, 0.3)
        al = a * (0.35 + 0.65 * k)
        f = F(44, 800); w_ = f.getlength(s_); x0 = 230
        pill_num(base, x0 - 50, LGY[i], i + 1, al, 22, GOLD if hot > 0.3 else SKY)
        text(base, (x0, LGY[i]), s_, 44, 800, INK if k > 0.5 else MUTE, al, anchor="lm")
    # header pills above the columns
    for j, x in enumerate(CXS): pill_num(base, x, HDY, j + 1, a, 22)
    d = ImageDraw.Draw(base)
    L = Image.new("RGBA", base.size, (0, 0, 0, 0)); dl = ImageDraw.Draw(L)
    for i in range(8):
        y = RY0 + RH * i
        if i % 2 == 0: dl.rectangle((60, y, 1020, y + RH - 2), fill=(255, 255, 255, int(12 * a)))
    dl.line((60, RY0 - 4, 1020, RY0 - 4), fill=rgba(GOLD, 0.6 * a), width=3)
    base.alpha_composite(L)
    for i, r in enumerate(ROWS):
        k_ = r["k"]; li, t0 = REV[k_]; y = RY0 + RH * i + RH / 2
        k = clamp((t - t0 + 0.15) / 0.35)
        if k <= 0: continue
        act = win(t, t0 - 0.15, NEXT[k_], 0.2, 0.3)
        better = r["v"][3] == "U"; glow = win(t, E(14) + 0.05, T_FAIR, 0.35, 0.2) if better else 0
        if act > 0 or glow > 0:
            c = SKY if act >= glow else GREEN
            rrect(base, (58, y - RH / 2 + 4, 1022, y + RH / 2 - 4), 18, fill=rgba(c, 0.16 * max(act, glow) * a), outline=rgba(c, max(act, glow) * a), width=3)
        dx = (1 - eout(k)) * 120; al = a * clamp(k * 1.5)
        fl = FL80[k_]; Lf = fl.copy()
        if al < 0.999: Lf.putalpha(Lf.getchannel("A").point(lambda q: int(q * al)))
        base.alpha_composite(Lf, (int(78 + dx), int(y - fl.height / 2)))
        nm = r["name"]
        if len(nm) == 1: text(base, (176 + dx, y), nm[0], 46, 800, INK, al, anchor="lm")
        else:
            text(base, (176 + dx, y - 21), nm[0], 40, 800, INK, al, anchor="lm")
            text(base, (176 + dx, y + 22), nm[1], 36 if k_ == "Iran" else 40, 700 if k_ == "Iran" else 800, MUTE if k_ == "Iran" else INK, al, anchor="lm")
        for j, v in enumerate(r["v"]):
            cell(base, CXS[j], y, v, clamp((t - CELLT[k_][j]) / 0.3), a)
    callouts(base, t)
    src = "IMPACT-se is an Israel-based watchdog. All sources in caption."
    text(base, (540, 1468), src, 36, 400, MUTE, a)

# ------------------------------------------------------------------ the map
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    return [np.array(r, float) for p in polys for r in p]
LAND = {k: rings_of(v) for k, v in G["land"].items()}
ISR = rings_of(G["israel"]); PSX = rings_of(G["psx"])
from shapely.geometry import shape, mapping
ISR_ONLY = rings_of(json.loads(json.dumps(mapping(shape(G["israel"]).difference(shape(G["psx"]).buffer(0.002))))))
class Cam:
    def __init__(s, lon, lat, k, cx, cy): s.lon, s.lat, s.k, s.cx, s.cy = lon, lat, k, cx, cy
COS = math.cos(math.radians(27))
CAM = Cam(24.5, 26.5, 14.4, 540, 935)
def ll2xy(c, lon, lat): return c.cx + (lon - c.lon) * c.k * COS, c.cy - (lat - c.lat) * c.k
def path(cx_, c, rings):
    for r in rings:
        xs = c.cx + (r[:, 0] - c.lon) * c.k * COS; ys = c.cy - (r[:, 1] - c.lat) * c.k
        cx_.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): cx_.line_to(x, y)
        cx_.close_path()
def fill(cx_, c, rings, col, a, lw=0.0, scol=None, sa=1.0):
    if a <= 0.004 or not rings: return
    v = [q / 255 for q in hx(col)]; path(cx_, c, rings); cx_.set_source_rgba(*v, a); cx_.fill_preserve()
    if lw: s_ = [q / 255 for q in hx(scol)]; cx_.set_source_rgba(*s_, a * sa); cx_.set_line_width(lw); cx_.stroke()
    else: cx_.new_path()
def mix(c1, c2, u): a, b = hx(c1), hx(c2); return "#%02X%02X%02X" % tuple(int(lerp(a[i], b[i], clamp(u))) for i in range(3))
STUDY = [r["iso"] for r in ROWS]
# map intro pings (line 4) and payoff lights (line 17)
PING_ORDER = ["MAR", "EGY", "PSX", "JOR", "SAU", "QAT", "ARE", "IRN"]
_t4a, _t4b = S(4), E(4)
PING = {iso: _t4a + 0.15 + (_t4b - _t4a - 0.5) * i / 7 for i, iso in enumerate(PING_ORDER)}
REFORM = ["SAU", "EGY", "MAR", "ARE"]
_l17 = [WT(17, "some"), WT(17, "countries"), WT(17, "already"), WT(17, "teaching")]
LIGHT = dict(zip(REFORM, _l17))
LABEL = {"MAR": ("Morocco", -6.8, 31.6), "EGY": ("Egypt", 29.8, 26.2), "SAU": ("Saudi Arabia", 44.6, 23.6), "ARE": ("UAE", 53.6, 20.6)}
INSET = (540, 1300, 128); ICAM = Cam(35.15, 31.45, 62, 540, 1300)

def country_colors(t):
    col = {}
    pay = seg(t, T_PAY, T_PAY + 0.4)
    for iso in STUDY:
        c = "#2C5596"; p = PING.get(iso, 99)
        u = clamp((t - p) / 0.25) * (1 - clamp((t - p - 0.7) / 0.5)) if t < T_TAB else 0
        c = mix(c, SKY, u * 0.9)
        if t >= T_PAY - 0.1:
            c = mix("#2C5596", "#7A2F3B", pay)
            if iso in LIGHT: c = mix(c, GREEN, clamp((t - LIGHT[iso] + 0.05) / 0.3))
        col[iso] = c
    return col

def draw_map(base, t, a):
    if a <= 0.004: return
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cx_ = cairo.Context(surf); cx_.set_line_join(cairo.LINE_JOIN_ROUND)
    col = country_colors(t)
    for k, rs in LAND.items():
        if k in col: continue
        fill(cx_, CAM, rs, "#132546", 1.0, 1.0, "#2B4170")
    for k in STUDY:
        if k in LAND: fill(cx_, CAM, LAND[k], col[k], 1.0, 1.4, "#3A5A92")
    # whole land of Israel: Israel sky, West Bank and Gaza sand, Green Line green
    fill(cx_, CAM, PSX, SAND, 1.0); fill(cx_, CAM, ISR_ONLY, SKY, 1.0)
    path(cx_, CAM, PSX); cx_.set_source_rgba(*[q / 255 for q in hx(GREEN)], 1.0); cx_.set_line_width(1.6); cx_.stroke()
    # PA ping: a ring on the map
    p = PING["PSX"]
    if p < t < p + 1.0 and t < T_TAB:
        x, y = ll2xy(CAM, 35.2, 31.9); u = (t - p) / 1.0
        cx_.arc(x, y, 8 + 50 * eout(u), 0, 2 * math.pi); cx_.set_source_rgba(*[q / 255 for q in hx(SKY)], 1 - u); cx_.set_line_width(4); cx_.stroke()
    # reform pulse rings
    for iso, tl in LIGHT.items():
        u = (t - tl) / 1.2
        if 0 < u < 1:
            x, y = ll2xy(CAM, *LABEL[iso][1:]) if iso != "ARE" else ll2xy(CAM, 54.3, 24.0)
            cx_.arc(x, y, 10 + 90 * eout(u), 0, 2 * math.pi); cx_.set_source_rgba(*[q / 255 for q in hx(GREEN)], 0.9 * (1 - u)); cx_.set_line_width(5); cx_.stroke()
    # inset: the whole land, zoomed, with a leader line
    ix, iy, ir = INSET; sx, sy = ll2xy(CAM, 35.1, 31.4)
    cx_.move_to(sx, sy); cx_.line_to(ix + (sx - ix) * 0.0, iy - ir); cx_.set_source_rgba(1, 1, 1, 0.5); cx_.set_line_width(2); cx_.stroke()
    cx_.arc(sx, sy, 6, 0, 2 * math.pi); cx_.set_source_rgba(1, 1, 1, 0.8); cx_.set_line_width(2); cx_.stroke()
    cx_.save(); cx_.arc(ix, iy, ir, 0, 2 * math.pi); cx_.clip()
    cx_.set_source_rgba(*[q / 255 for q in hx(NIGHT)], 1); cx_.paint()
    for k, rs in LAND.items():
        if k in ("EGY", "JOR", "SAU", "SYR", "LBN"):
            fill(cx_, ICAM, rs, col.get(k, "#132546"), 1.0, 1.5, "#3A5A92")
    fill(cx_, ICAM, PSX, SAND, 1.0); fill(cx_, ICAM, ISR_ONLY, SKY, 1.0)
    path(cx_, ICAM, PSX); cx_.set_source_rgba(*[q / 255 for q in hx(GREEN)], 1.0); cx_.set_line_width(4); cx_.stroke()
    cx_.restore()
    cx_.arc(ix, iy, ir, 0, 2 * math.pi); cx_.set_source_rgba(1, 1, 1, 0.85); cx_.set_line_width(3); cx_.stroke()
    surf.flush()
    arr = np.ndarray((H, W, 4), np.uint8, surf.get_data()).copy()
    rg = arr[:, :, [2, 1, 0, 3]].astype(np.float32); al = rg[:, :, 3:4] / 255.0
    rgb = np.where(al > 0, rg[:, :, :3] / np.maximum(al, 1e-6), 0)
    L = Image.fromarray(np.dstack([rgb, al * 255 * a]).clip(0, 255).astype(np.uint8), "RGBA"); base.alpha_composite(L)
    # labels
    text(base, (ix + ir + 18, iy - 20), "Israel", 40, 800, SKY, a, anchor="lm", halo=True)
    text(base, (ix + ir + 18, iy + 26), "West Bank, Gaza", 36, 700, SAND, a, anchor="lm", halo=True)
    if t >= T_PAY:
        for iso, (nm, lo, la) in LABEL.items():
            k = clamp((t - LIGHT[iso]) / 0.3)
            if k > 0:
                x, y = ll2xy(CAM, lo, la); text(base, (x, y), nm, 40, 800, INK, a * k, halo=True, scale=0.9 + 0.1 * back(k))
    text(base, (540, 1488), "Map: Natural Earth. Green Line in green", 36, 400, MUTE, a)

def flag_row(base, t, a):
    """line 4: the 8 flags pop in a row as their countries ping on the map"""
    order = {"MAR": "Morocco", "EGY": "Egypt", "PSX": "PA", "JOR": "Jordan", "SAU": "Saudi", "QAT": "Qatar", "ARE": "UAE", "IRN": "Iran"}
    for i, (iso, k_) in enumerate(order.items()):
        k = clamp((t - PING[iso] + 0.05) / 0.3)
        if k <= 0: continue
        fl = FL96[k_]; s = max(0.05, back(k)); im = fl.resize((max(2, int(fl.width * s)), max(2, int(fl.height * s))), Image.LANCZOS)
        if a < 0.999: im.putalpha(im.getchannel("A").point(lambda q: int(q * a)))
        x = 540 + (i - 3.5) * 118; base.alpha_composite(im, (int(x - im.width / 2), int(560 - im.height / 2)))

# ------------------------------------------------------------------ fair card
def fair(base, t):
    a = win(t, T_FAIR, T_PAY - 0.05, 0.3, 0.3)
    if a <= 0: return
    tb = WT(15, "Dehumanizing") - 0.15
    text(base, (540, 400), "Not perfect either.", fit("Not perfect either.", 112), 900, AMBER, a)
    a1 = a * (1 - seg(t, tb, tb + 0.3)); a2 = a * seg(t, tb, tb + 0.3)
    k1 = clamp((t - WT(15, "Israeli")) / 0.3)
    text(base, (540, 640), "Israeli and Palestinian", 72, 900, INK, a1 * k1)
    text(base, (540, 740), "textbooks: both tell", 72, 900, INK, a1 * k1)
    text(base, (540, 840), "one-sided national stories", fit("one-sided national stories", 72), 900, GOLD, a1 * clamp((t - WT(15, "both")) / 0.3))
    text(base, (540, 660), "Dehumanizing portrayals:", 72, 900, INK, a2)
    text(base, (540, 770), "rare in both", 96, 900, GREEN, a2 * clamp((t - WT(15, "rare")) / 0.3))
    text(base, (540, 930), "Israeli researchers study", 56, 800, MUTE, a2)
    text(base, (540, 1000), "Israel's own textbooks too.", 56, 800, MUTE, a2)
    text(base, (540, 1420), "“Victims of Our Own Narratives?” 2013", 36, 400, MUTE, a)
    text(base, (540, 1464), "Bar-Tal, Adwan, Wexler. Funded by the US State Department", 36, 400, MUTE, a)
    text(base, (540, 1508), "Israeli critics: e.g. Nurit Peled-Elhanan, 2012", 36, 400, MUTE, a2)

# ------------------------------------------------------------------ subtitles (hook and lead-in are on screen as big type)
SUBS = {
    1: [(3, "Grade 12 history."), (3, "Jordan, 2025.")],
    2: [(4, "Why did Britain back"), (3, "a Jewish homeland?"), (4, "One reason it gives:"), (5, "the Jewish role in destroying"), (3, "the German economy.")],
    3: [(4, "An old conspiracy myth."), (3, "Printed as fact.")],
    4: [(6, "So we checked 8 school systems."), (2, "4 questions.")],
    5: [(2, "Antisemitic content?"), (4, "Israel on the map?"), (4, "Peace taught? Getting better?")],
    6: [(6, "Iran. Antisemitism, no Israel, no change.")],
    7: [(3, "The Palestinian Authority."), (6, "A study for the EU found"), (2, "antisemitic narratives,"), (4, "and maps without Israel.")],
    8: [(5, "Qatar. 4 years, no change.")],
    9: [(3, "Jordan teaches tolerance."), (4, "Just not toward Jews.")],
    10: [(3, "Now the twist.")],
    11: [(4, "Saudi Arabia removed almost"), (3, "all of it,"), (4, "in a few years.")],
    12: [(4, "Egypt now teaches its"), (4, "peace treaty with Israel.")],
    13: [(4, "Morocco added Jewish history"), (3, "in 2020.")],
    14: [(4, "And the Emirates teach"), (3, "the Abraham Accords"), (3, "from grade 6.")],
    15: [(3, "Not perfect either."), (4, "A US-funded study found"), (4, "Israeli and Palestinian books"), (4, "both tell one-sided stories."),
         (3, "Dehumanizing images were"), (3, "rare in both.")],
    16: [(4, "Kids aren't born hating."), (2, "They're taught.")],
    17: [(4, "And some countries are"), (4, "already teaching something new.")],
}
CH = []
for li, chunks in SUBS.items():
    ws = LW[li]; i = 0
    assert sum(n for n, _ in chunks) == len(ws), (li, sum(n for n, _ in chunks), len(ws))
    for n, s_ in chunks: CH.append([ws[i]["t0"] - 0.05, ws[i + n - 1]["t1"] + 0.15, s_]); i += n
CH.sort()
for k in range(len(CH) - 1):
    if CH[k + 1][0] - CH[k][1] < 0.25: CH[k][1] = CH[k + 1][0]
    CH[k][1] = min(CH[k][1], CH[k + 1][0])
SUBF = F(54, 800)
def subtitles(base, t):
    for a0, a1, s_ in CH:
        if a0 <= t < a1:
            al = min(1, (t - a0) / 0.08 + 1e-4, (a1 - t) / 0.08)
            words = s_.split(); lines = [[]]
            for w_ in words:
                tr = " ".join(lines[-1] + [w_])
                if SUBF.getlength(tr) <= 900 or not lines[-1]: lines[-1].append(w_)
                else: lines.append([w_])
            lines = [" ".join(l) for l in lines]; lh = 70; tw = max(SUBF.getlength(l) for l in lines)
            yb = 1650; y0 = yb - lh * len(lines) - 18
            L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
            d.rounded_rectangle((540 - tw / 2 - 26, y0, 540 + tw / 2 + 26, yb), 22, fill=(6, 12, 26, int(215 * al)))
            for i, l in enumerate(lines): d.text((540, y0 + 18 + lh * i + lh / 2 - 4), l, font=SUBF, fill=(255, 255, 255, int(255 * al)), anchor="mm")
            base.alpha_composite(L); return

# ------------------------------------------------------------------ frame
HOOK = [[("What do kids", INK)], [("learn about", INK)], [("Jews?", GOLD)]]
LEAD = [[("So, next time", INK)], [("someone", INK)], [("asks you...", GOLD)]]
HSZ = 150; HY = [520, 690, 860]
def big_lines(base, lines, a, zoom=1.0):
    for ln, y in zip(lines, HY): rich(base, y, ln, int(HSZ * zoom), 900, a)
def page_peek(base, t, a, t_ref):
    """frame 0 / lead-in: the page waits at the bottom, drifting up (motion by 1.5 s)"""
    y = 1150 - 70 * eout(t_ref / 2.0)
    page(base, t, 540 - PW * 0.92 / 2, y, 0.92, a, 0.0)

def frame_raw(t):
    im = BG.copy()
    # hook (frame 0)
    ha = 1 - seg(t, T_BOOK - 0.05, T_BOOK + 0.3)
    if ha > 0:
        big_lines(im, HOOK, ha, 1 + 0.025 * seg(t, 0, T_BOOK))
    # the textbook page
    if t < T_MAP1 + 0.4:
        if t < T_BOOK: page_peek(im, t, 1.0, t)
        else:
            u = eout((t - T_BOOK) / 0.6); y0 = 1150 - 70 * eout(T_BOOK / 2.0)
            out = seg(t, T_MAP1, T_MAP1 + 0.35)
            sc = lerp(0.92, 1.0, u); y = lerp(y0, PY0, u) - 40 * out
            hl = clamp((t - WT(2, "Jewish", 2) + 0.1) / (WT(2, "economy", end=True) - WT(2, "Jewish", 2)))
            page(im, t, 540 - PW * sc / 2, y, sc, 1 - out, hl)
            text(im, (540, 250), "What do kids learn?", 64, 900, MUTE, win(t, T_BOOK + 0.2, T_MAP1, 0.3, 0.3))
            stamp(im, t, WT(3, "conspiracy") - 0.05, 1 - out)
    # map intro (line 4)
    ma = win(t, T_MAP1, T_TAB, 0.35, 0.35)
    if ma > 0:
        draw_map(im, t, ma)
        text(im, (540, 300), "8 school systems", 110, 900, INK, ma)
        text(im, (540, 420), "4 questions", 80, 900, GOLD, ma * clamp((t - WT(4, "Four")) / 0.3))
        flag_row(im, t, ma)
    table(im, t)
    fair(im, t)
    # payoff map
    pa = win(t, T_PAY, T_LEAD, 0.35, 0.35)
    if pa > 0:
        draw_map(im, t, pa)
        a1 = pa * (1 - seg(t, T_PAY2, T_PAY2 + 0.3)); a2 = pa * seg(t, T_PAY2, T_PAY2 + 0.3)
        text(im, (540, 340), "Kids aren't born hating.", fit("Kids aren't born hating.", 100), 900, INK, a1)
        text(im, (540, 480), "They're taught.", 110, 900, GOLD, a1 * clamp((t - WT(16, "They")) / 0.3))
        text(im, (540, 340), "Some are already teaching", fit("Some are already teaching", 90), 900, INK, a2)
        text(im, (540, 470), "something new.", 110, 900, GREEN, a2 * clamp((t - WT(17, "something")) / 0.3))
    # lead-in: same place as the hook, page peeking like frame 0
    la = seg(t, T_LEAD, T_LEAD + 0.35)
    if la > 0:
        page_peek(im, t, la, 0.0)
        big_lines(im, LEAD, la)
    subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS)); return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [c[2] for c in CH] + LEG + QUOTE + [s for c in CALL for s in [l[0] for l in c[3]] + c[4]] + [r for row in ROWS for r in row["name"]]
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam\b|follow", s, re.I) for s in _txt)

if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        ts = [float(x) for x in A.snaps.split(",")] if A.snaps != "auto" else [0, 1.5, S(1) + 1, S(2) + 3, S(3) + 1, S(4) + 1.5, S(5) + 2, S(6) + 1.5, S(7) + 2.5,
                                                                              S(9) + 1, S(11) + 1, S(13) + 1, E(14) + 0.3, S(15) + 2, E(15) - 0.5, S(16) + 1, E(17), T_END - 0.6, T_END - 0.05]
        ims = []
        for x in ts:
            f_ = frame(x); ims.append((x, f_))
        cols = 5; th = (270, 480); rows_ = math.ceil(len(ims) / cols)
        sheet = Image.new("RGB", (cols * th[0], rows_ * (th[1] + 30)), (30, 30, 30)); d = ImageDraw.Draw(sheet)
        for i, (x, f_) in enumerate(ims):
            sheet.paste(f_.resize(th, Image.LANCZOS), ((i % cols) * th[0], (i // cols) * (th[1] + 30) + 30))
            d.text(((i % cols) * th[0] + 8, (i // cols) * (th[1] + 30) + 6), f"{x:.2f}", fill=(255, 255, 255), font=F(22, 700))
        sheet.save(f"{D}/work/snaps/sheet.png"); print("sheet", len(ims), "END", T_END)
        for x in [float(v) for v in (os.environ.get("FULL", "")).split(",") if v]: frame(x).save(f"{D}/work/snaps/f_{x:06.2f}.png")
        sys.exit()
    n = int(round(T_END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-movflags", "+faststart", A.out], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", A.out, T_END)
