#!/bin/bash
# langs side by side, 9:16: the two race renders cropped to their content (y 262..1502) and stacked, 828x950 each (was 540x480 inside a 1080x960 frame),
# a question card over the seam from 37.0 s, cut at 40.8 s (race ends at 40 s, end hold under 1 s), music from the first race with a 0.8 s fade.
set -e
A=/home/claude/vid/final/langs_3000yrs_v2_newtune.mp4; B=/home/claude/vid/final/langs_revival_v6_newtune.mp4; Q=/home/claude/jobA/langs/question.png
ffmpeg -v error -y -i $A -i $B -loop 1 -i $Q -filter_complex \
"[0:v]crop=1080:1240:0:262,scale=828:950,setsar=1[a];[1:v]crop=1080:1240:0:262,scale=828:950,setsar=1[b];\
[a][b]vstack=2[s];[s]pad=1080:1920:126:10:color=#0b1020[p];[2:v]format=rgba,fade=in:st=37.0:d=0.3:alpha=1[q];[p][q]overlay=0:845:enable='gte(t,37.0)'[v]" \
-map "[v]" -map 0:a -t 40.8 -af "afade=out:st=40.0:d=0.8" -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p -r 30 -c:a aac -b:a 192k -ar 48000 -movflags +faststart /home/claude/jobA/langs/langs_side_by_side_v2.mp4
