"""druze_1102 scenes (2 Nov 2026): the arabia_map house scenes (dark stage, label chip, circular loop, bar-cut music,
sc_amap with the whole land of Israel in gold, West Bank and Gaza a slightly different shade, Green Line in green) plus
- brand gold #FFCD50 for numbers and highlights
- sc_dzmap: sc_amap with animated travel arrows. Extra fields: arrows [{a: [lon, lat], b: [lon, lat], bend}] timed by
  marks a0, a1, ... (each arrow draws itself in 0.9 s with an arrow head)."""
exec(compile(open("/home/claude/arabia_map/scenes_am.py").read(), "/home/claude/arabia_map/scenes_am.py", "exec"))
YEL = kit.hx("#FFCD50")
_wtext.__defaults__ = (WHITE, YEL, 1000, 3, 1.0, 1.0, False)

def _arrow(c, p0, p1, bend, u, a):
    (x0, y0), (x1, y1) = p0, p1
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2; dx, dy = x1 - x0, y1 - y0
    cx, cy = mx - dy * bend, my + dx * bend
    n = 40; k = max(2, int(n * u))
    pts = [((1 - t) ** 2 * x0 + 2 * (1 - t) * t * cx + t * t * x1, (1 - t) ** 2 * y0 + 2 * (1 - t) * t * cy + t * t * y1)
           for t in [i / n for i in range(k + 1)]]
    pts = pts[:k + 1]
    c.save(); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for wdt, colr, al in ((16, INK, 0.55), (9, YEL, 1.0)):
        c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; sa(c, colr, al * a); c.set_line_width(wdt); c.stroke()
    if len(pts) >= 2:
        (ax, ay), (bx, by) = pts[-2], pts[-1]; ang = math.atan2(by - ay, bx - ax); L = 34
        c.move_to(bx + 8 * math.cos(ang), by + 8 * math.sin(ang))
        c.line_to(bx - L * math.cos(ang - 0.5), by - L * math.sin(ang - 0.5))
        c.line_to(bx - L * math.cos(ang + 0.5), by - L * math.sin(ang + 0.5)); c.close_path()
        sa(c, YEL, a); c.fill()
    c.restore()

def sc_dzmap(c, t, S):
    sc_amap(c, t, S)
    mv = S["_mv"]
    for i, ar in enumerate(S.get("arrows") or []):
        tk = S["times"].get(f"a{i}", S["t0"] + 0.4 + 0.9 * i)
        if t < tk - 0.05: continue
        u = ease(min(1.0, max(0.0, (t - tk) / 0.9)))
        _arrow(c, mv.P(*ar["a"]), mv.P(*ar["b"]), ar.get("bend", 0.18), max(0.05, u), 1.0)
