"""Bespoke reelkit scene for un_own_people: regime card.
Header (flag + place/year, Hebrew under), a death counter card (counts up on mark 'dead'), an optional grey
'unverified' chip (mark 'unv'), a row of UN body tiles (General Assembly / Security Council / Human Rights Council),
each value popping on mark 'b<k>', an optional note pill (mark 'note') and the source line.
Spec: {"type": "regime", "line", "flag", "en", "he", "value", "prefix", "suffix", "text_value", "label", "label_he",
       "unv": {"en", "he"}, "bodies": [{"en", "he", "value", "value_he", "color"}], "note": {"en", "he"}, "marks", "source"}"""
import math
import render as RD
from render import P, T, pill, PP, fade_in, source, shadow_box, draw_emoji, flag_emoji, block, block_h, col, count, fmt, clean
from kit import ease, ramp, lerp, St, sa, rr, box, font

def sc_regime(c, t, S):
    t0 = S["t0"]; tm = S["times"]
    # header
    a, s = PP(t, t0 + 0.05, S)
    f = font(78, 900); tw = f.getlength(clean(S["en"])); fx = 540 - (tw + 110) / 2
    draw_emoji(c, flag_emoji(S["flag"]), fx + 40, 330, 84, a, s)
    T(c, S["en"], 78, fx + 110 + tw / 2, 332, P["navy"], a, s, 900, maxw=820)
    a2, s2 = PP(t, t0 + 0.18, S); T(c, S.get("he", ""), 54, 540, 420, P["blue"], a2, s2, 700, maxw=900)
    # death card
    td = tm.get("dead", t0 + 0.3)
    a, s = PP(t, t0 + 0.12, S, s0=0.6, bounce=1.4)
    if a > 0.01:
        cy = 640; old = St.a; St.a *= a
        c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
        shadow_box(c, 90, 480, 900, 320, 30, P["card"], stroke=P["navy"], sw=6)
        rr(c, 106, 496, 868, 288, 18); sa(c, P["red"], 0.5); c.set_line_width(2); c.stroke()
        if S.get("text_value"):
            u = ramp(t, td - 0.05, td + 0.3); T(c, S["text_value"], 104, 540, 590, P["red"], u, lerp(1.15, 1, ease(u)), 900, maxw=840)
        else:
            v = count(t, td, 1.3, 0, S["value"]); done = t >= td + 1.3
            lab = f"{S.get('prefix', '')}{fmt(v)}{S.get('suffix', '') if done else ''}"
            pulse = 1 + 0.05 * max(0.0, 1 - abs(t - (td + 1.3)) / 0.25)
            T(c, lab, 170, 540, 590, P["red"], 1.0, pulse, 900, maxw=840)
        T(c, S.get("label", ""), 52, 540, 705, P["navy"], 1.0, 1.0, 800, hl=P["red"], maxw=840)
        if S.get("label_he"): T(c, S["label_he"], 44, 540, 762, P["gold_text"], 1.0, 1.0, 700, maxw=840)
        c.restore(); St.a = old
    y = 850
    if S.get("unv"):
        a, s = PP(t, tm.get("unv", td + 1.0), S, bounce=2.2)
        pill(c, S["unv"]["en"], 40, 540, y + 20, P["grey"], P["white"], a, s, w=800)
        if S["unv"].get("he"): T(c, S["unv"]["he"], 38, 540, y + 88, P["grey"], a, s, 700, maxw=900)
        y += 140
    else: y += 30
    # UN body tiles
    bodies = S.get("bodies", []); n = len(bodies); gap = 24; tw_ = (900 - gap * (n - 1)) / max(1, n); th = 300
    ba = fade_in(t, t0 + 0.25, S, 0.3)
    for k, b in enumerate(bodies):
        x0 = 90 + k * (tw_ + gap); cx = x0 + tw_ / 2
        old = St.a; St.a *= ba
        shadow_box(c, x0, y, tw_, th, 24, P["card"], stroke=P["silver"], sw=3, sh=6)
        box(c, x0, y, tw_, 12, 6, P["gold"])
        hb = block_h(b["en"], 40, 800, tw_ - 30, 2); block(c, b["en"], 40, cx, y + 30 + hb / 2, P["navy"], 1, 1, 800, maxw=tw_ - 30, max_lines=2)
        if b.get("he"): T(c, b["he"], 32, cx, y + 40 + hb + 16, P["gold_text"], 1, 1, 700, maxw=tw_ - 30)
        St.a = old
        tk = tm.get(f"b{k}", t0 + 1.0 + 0.6 * k)
        a, s = PP(t, tk, S, bounce=2.4)
        if a > 0.01:
            old = St.a; St.a *= ba
            vc = col(b.get("color"), "red")
            T(c, b["value"], 74 if len(clean(b["value"])) <= 4 else 50, cx, y + th - 82, vc, a, s, 900, maxw=tw_ - 24)
            if b.get("value_he"): T(c, b["value_he"], 32, cx, y + th - 30, vc, a, s, 700, maxw=tw_ - 24)
            St.a = old
    y += th + 30
    if S.get("note"):
        a, s = PP(t, tm.get("note", t0 + 2.5), S, bounce=2.2)
        pill(c, S["note"]["en"], 38, 540, y + 34, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
        if S["note"].get("he"): T(c, S["note"]["he"], 36, 540, y + 104, P["navy"], a, s, 700, maxw=900)
    source(c, t, S)

def sc_scale(c, t, S):
    """Israel vs the rest of the world: two tall columns counting up (marks 'a', 'b'), labels, source."""
    t0 = S["t0"]; tm = S["times"]
    a, s = PP(t, t0 + 0.05, S)
    hb = block_h(S["title"], 74, 900, 940, 2); block(c, S["title"], 74, 540, 300 + hb / 2 - 37, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=2)
    yy = 300 + hb - 37 + 14
    a, s = PP(t, t0 + 0.2, S); T(c, S.get("title_he", ""), 54, 540, yy + 30, P["blue"], a, s, 700, maxw=940)
    base = 1240; top = 640; vmax = max(b["value"] for b in S["bars"])
    for k, b in enumerate(S["bars"]):
        tk = tm.get("ab"[k], t0 + 0.5 + 1.2 * k); x = 330 if k == 0 else 750; bw = 300
        if t < tk - 0.05: continue
        v = count(t, tk, 1.4, 0, b["value"]); hgt = (base - top) * v / vmax
        cc = col(b.get("color"), "navy")
        sa(c, P["navy"], 0.10); rr(c, x - bw / 2 + 4, base - hgt + 10, bw, hgt, 18); c.fill()
        box(c, x - bw / 2, base - hgt, bw, hgt + 1, 18, cc)
        T(c, fmt(v), 110, x, base - hgt - 70, cc if k == 0 else P["navy"], 1, 1, 900)
        draw_emoji(c, b["icon"], x, base + 62, 64)
        T(c, b["label"], 48, x, base + 132, P["navy"], 1, 1, 800, maxw=400)
        T(c, b["he"], 40, x, base + 186, P["gold_text"], 1, 1, 700, maxw=400)
    sa(c, P["navy"], 0.5); c.rectangle(110, base, 860, 4); c.fill()
    source(c, t, S)

def sc_statement(c, t, S):
    """gold label pill (+ Hebrew), optional icon, a big English statement (*highlight*), Hebrew under it.
    The statement pops on mark 'body' (default t0 + 0.3)."""
    t0 = S["t0"]; tb = S["times"].get("body", t0 + 0.3)
    en, he = S["en"], S.get("he", "")
    h_en = block_h(en, S.get("size", 76), 900, 920, 4); h_he = block_h(he, 54, 700, 920, 3)
    em = S.get("icon"); total = (190 if em else 0) + 150 + h_en + 40 + h_he
    y = max(330, (330 + 1420) / 2 - total / 2)
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 80, 150, a, s); y += 190
    a, s = PP(t, t0 + 0.08, S)
    pill(c, S["label"], 52, 540, y + 36, P["gold"], P["white"], a, s, w=900)
    T(c, S.get("label_he", ""), 44, 540, y + 112, P["navy"], a, s, 700); y += 150
    a, s = PP(t, tb, S, s0=0.7, bounce=1.4); breath = 1 + 0.01 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, S.get("size", 76), 540, y + h_en / 2, P["navy"], a, s * breath, 900, hl=P["blue"], maxw=920, max_lines=4); y += h_en
    u = ease((t - tb - 0.2) / 0.8) if t > tb + 0.2 else 0.0
    if u > 0: box(c, 540 - 300 * u, y + 10, 600 * u, 10, 5, P["gold"], a)
    y += 40
    a, s = PP(t, tb + 0.25, S); block(c, he, 54, 540, y + h_he / 2, P["blue"], a, s, 700, maxw=920, max_lines=3)
    source(c, t, S)
