"""Bespoke reelkit scenes for the startups Part 1 / Part 2 reels (10 Israeli startups each).
sc_impact: one card per startup. Top: 10-step progress bar, field pill, rank badge, name EN/HE, year pill.
Middle: the human impact line EN/HE (on its spoken phrase), a gold stat chip.
Bottom: world map strip (Natural Earth 1:50m, plate carree). Reach is drawn as a choropleth, only from sourced claims:
  map.mode "broad"  all land tinted (a worldwide user/country count is sourced), revealed as a ripple from Israel
  map.mode "light"  faint tint (reach is only "worldwide" / unlisted country count)
  map.mode "none"   no tint
  map.region        region-level sourced claims (e.g. "Europe"), medium blue
  map.core          named sourced countries, full blue, pulsing in one by one with gold arcs from Israel, flags under the map
Israel: the full land between the river and the sea in gold #B8923F with the Green Line in green, drawn with
/home/claude/island_israel/island_common.py, plus a zoomed inset so the Green Line can be seen.
sc_verdict2: closing "In my view" card (20 dots). sc_tease: Part 2 tomorrow card."""
import math, json, sys
import numpy as np, cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, draw_emoji, source, col, flag_emoji, W, H
from kit import ease, ramp, lerp, St, sa, rr, circ, box
sys.path.insert(0, "/home/claude/island_israel")
import island_common as IC

FIELDS = {
    "medicine":    ("MEDICINE", "רפואה", "🩺", "red"),
    "transport":   ("TRANSPORTATION", "תחבורה", "🚌", "blue"),
    "safety":      ("ROAD SAFETY", "בטיחות בדרכים", "🚗", "blue"),
    "agriculture": ("AGRICULTURE", "חקלאות", "🌱", "green"),
    "water":       ("WATER", "מים", "💧", "blue"),
    "tech":        ("TECH", "טכנולוגיה", "💻", "navy"),
    "security":    ("CYBER SECURITY", "אבטחת מידע", "🛡️", "navy"),
    "energy":      ("ENERGY", "אנרגיה", "☀️", "amber"),
}
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
# map strip geometry (plate carree)
MX0, MX1 = 60, 1020; LON0, LON1 = -180.0, 180.0; LATT, LATB = 80.0, -56.0
KPX = (MX1 - MX0) / (LON1 - LON0); MY0 = 1046; MY1 = MY0 + (LATT - LATB) * KPX
def mp(lon, lat): return (MX0 + (lon - LON0) * KPX, MY0 + (LATT - lat) * KPX)
ISR_LL = (35.0, 31.5)
BLUE_CORE = "#1F6FC0"; BLUE_REG = "#5FA3E0"; BLUE_BROAD = "#8DBDE8"; BLUE_LIGHT = "#BCD6EF"

_G = {}
def countries():
    if "c" in _G: return _G["c"]
    from shapely.geometry import shape, box as sbox
    from shapely.ops import unary_union
    d = json.load(open(GEO)); acc = {}
    for f in d["features"]:
        p = f["properties"]; iso = p.get("ISO_A2_EH")
        if not iso or iso == "-99": iso = p.get("ADM0_A3")
        if iso == "AQ": continue
        acc.setdefault(iso, []).append(shape(f["geometry"]))
    clipb = sbox(LON0, LATB, LON1, LATT); out = {}
    for iso, gs in acc.items():
        g = unary_union(gs).intersection(clipb)
        if g.is_empty: continue
        ps = [g] if g.geom_type == "Polygon" else [x for x in getattr(g, "geoms", []) if x.geom_type == "Polygon"]
        rings = []
        for pp in ps:
            pp = pp.simplify(0.25)
            if pp.is_empty or pp.area < 0.02: continue
            rings.append(np.array([mp(x, y) for x, y in pp.exterior.coords]))
        if rings:
            main = max(ps, key=lambda q: q.area); rp = main.representative_point()
            out[iso] = dict(rings=rings, rp=mp(rp.x, rp.y))
    _G["c"] = out; return out

def _path(c, rings):
    for r in rings:
        c.move_to(*r[0])
        for x, y in r[1:]: c.line_to(x, y)
        c.close_path()

def layer(fill_hex, skip=("IL", "PS"), only=None, edge=True):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s); C = countries()
    for k, v in C.items():
        if k in skip or (only is not None and k not in only): continue
        _path(c, v["rings"]); sa(c, RD.col(fill_hex)); c.fill_preserve()
        if edge: sa(c, RD.col("#FFFFFF"), 0.9); c.set_line_width(0.9); c.stroke()
        else: c.new_path()
    return s

def base_layer():
    if "base" not in _G:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
        rr(c, MX0, MY0, MX1 - MX0, MY1 - MY0, 26); sa(c, RD.col("#E4E8EE")); c.fill()
        c.save(); rr(c, MX0, MY0, MX1 - MX0, MY1 - MY0, 26); c.clip()
        sa(c, RD.col("#FFFFFF"), 0.5); c.set_line_width(1)
        for lat in (-30, 0, 30, 60):
            y = mp(0, lat)[1]; c.move_to(MX0, y); c.line_to(MX1, y); c.stroke()
        c.set_source_surface(layer("#FBFBFC"), 0, 0); c.paint(); c.restore()
        _G["base"] = s
    return _G["base"]

def draw_israel(c, sc_px_per_deg, ox, oy, a=1.0, t=0.0):
    """gold land + lakes + Green Line from island_common, camera centred on ISR_LL at (ox, oy)"""
    s = sc_px_per_deg / IC.KY
    cx, cy = IC.ll2km(*ISR_LL)
    cam = IC.Cam(ox, oy, s, 0.0, cx, cy)
    IC.fill_rings(c, IC.R_LAND, cam, IC.GOLDL, a, edge=IC.GOLD_EDGE, ew=max(0.6, s * 0.7))
    IC.fill_rings(c, IC.R_LAKES, cam, IC.WATER, a)
    IC.stroke_lines(c, IC.R_GREEN, cam, IC.GLINE, max(1.0, s * 1.5), a)
    return cam

def world_map(c, t, S, t_map):
    m = S.get("map", {}); C = countries()
    if "_lay" not in S:
        mode = m.get("mode", "broad")
        S["_lay"] = dict(
            broad=layer(BLUE_BROAD if mode == "broad" else BLUE_LIGHT) if mode in ("broad", "light") else None,
            region=layer(BLUE_REG, only=set(m.get("region", []))) if m.get("region") else None)
    L = S["_lay"]; a0 = St.a
    sa(c, P["navy"], 0.10 * a0); rr(c, MX0 + 3, MY0 + 12, MX1 - MX0, MY1 - MY0, 26); c.fill()
    c.set_source_surface(base_layer(), 0, 0); c.paint_with_alpha(a0)
    ix, iy = mp(*ISR_LL)
    c.save(); rr(c, MX0, MY0, MX1 - MX0, MY1 - MY0, 26); c.clip()
    # broad / light reach: ripple out from Israel
    u = ease(ramp(t, t_map, t_map + 1.3))
    for key in ("broad", "region"):
        if L[key] is None or u <= 0: continue
        c.save(); c.new_path(); c.arc(ix, iy, 30 + 1100 * u, 0, 2 * math.pi); c.clip()
        c.set_source_surface(L[key], 0, 0); c.paint_with_alpha(a0 * (0.8 if m.get("mode") == "light" and key == "broad" else 1.0)); c.restore()
    if u > 0 and u < 1:
        c.new_path(); c.arc(ix, iy, 30 + 1100 * u, 0, 2 * math.pi); sa(c, P["gold"], 0.5 * (1 - u) * a0); c.set_line_width(4); c.stroke()
    # core countries pop in one by one, gold arcs from Israel
    core = [k for k in m.get("core", []) if k in C]; tc = S.setdefault("_tcore", [t_map + 0.5 + 0.22 * k for k in range(len(core))])
    for k, iso in enumerate(core):
        v = ramp(t, tc[k], tc[k] + 0.3)
        if v <= 0.01: continue
        pulse = 0.35 * max(0.0, 1 - (t - tc[k]) / 0.7)
        _path(c, C[iso]["rings"]); sa(c, RD.col(BLUE_CORE), (0.9 + 0.1 * pulse) * v * a0); c.fill_preserve()
        sa(c, P["white"], v * a0); c.set_line_width(1.0); c.stroke()
        if iso in ("IL", "PS"): continue
        px, py = C[iso]["rp"]; w = ease(ramp(t, tc[k] - 0.2, tc[k] + 0.4)); d = math.hypot(px - ix, py - iy)
        if d < 8: continue
        qx, qy = (ix + px) / 2, min(iy, py) - 0.28 * d - 10; n = 40; pts = []
        for j in range(int(n * w) + 1):
            s_ = j / n; pts.append(((1 - s_) ** 2 * ix + 2 * (1 - s_) * s_ * qx + s_ * s_ * px, (1 - s_) ** 2 * iy + 2 * (1 - s_) * s_ * qy + s_ * s_ * py))
        if len(pts) > 1:
            c.move_to(*pts[0])
            for q in pts[1:]: c.line_to(*q)
            sa(c, P["gold"], 0.85 * a0); c.set_line_width(2.6); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
        if w >= 1: circ(c, px, py, 5, P["gold"], a0, stroke=P["white"], sw=2)
    c.restore()
    # Israel in gold (full land, Green Line) + pulsing origin ring
    draw_israel(c, KPX, ix, iy, a0)
    ph = (t * 0.8) % 1.0
    c.new_path(); c.arc(ix, iy, 8 + 22 * ph, 0, 2 * math.pi); sa(c, P["gold"], 0.9 * (1 - ph) * a0); c.set_line_width(3); c.stroke()
    # Gaza marker (Watergen) or other point markers
    for mk in m.get("markers", []):
        v = ramp(t, t_map + mk.get("delay", 0.6), t_map + mk.get("delay", 0.6) + 0.3)
        if v > 0.01:
            mx, my = mp(*mk["lonlat"]); circ(c, mx, my, 6, P["red"], v * a0, stroke=P["white"], sw=2)
    rr(c, MX0, MY0, MX1 - MX0, MY1 - MY0, 26); sa(c, P["navy"], a0); c.set_line_width(5); c.stroke()
    # Israel inset (bottom left over the Pacific), so the gold land and Green Line read at a glance
    insx, insy, insr = MX0 + 92, MY1 - 92, 70
    c.save(); c.new_path(); c.arc(insx, insy, insr, 0, 2 * math.pi); sa(c, RD.col("#DCE7F3"), a0); c.fill_preserve(); c.clip()
    draw_israel(c, 28.0, insx, insy, a0)
    for mk in m.get("markers", []):
        cam_s = 28.0
        gx = insx + (mk["lonlat"][0] - ISR_LL[0]) * cam_s * IC.KX / IC.KY; gy = insy - (mk["lonlat"][1] - ISR_LL[1]) * cam_s
        v = ramp(t, t_map + mk.get("delay", 0.6), t_map + mk.get("delay", 0.6) + 0.3); circ(c, gx, gy, 6, P["red"], v * a0, stroke=P["white"], sw=2)
    c.restore()
    c.new_path(); c.arc(insx, insy, insr, 0, 2 * math.pi); sa(c, P["gold"], a0); c.set_line_width(4); c.stroke()
    # reach chip (EN | HE) bottom right inside the map
    if m.get("reach"):
        a, s = PP(t, t_map + 0.3, S)
        pill(c, m["reach"], 34, 650, MY1 - 40, P["white"], P["navy"], a, s, outline=RD.col(BLUE_CORE), w=800, padh=1.45)
        if m.get("reach_he"): T(c, m["reach_he"], 30, 650, MY1 - 92, P["navy"], a, s, 700, maxw=600)
    # flags of the named countries under the map
    fl = [k for k in m.get("flags", m.get("core", [])) if k not in ("IL", "PS")]
    if fl:
        n = len(fl); sz = 50 if n <= 8 else 40; gap = sz + 14; lab = m.get("core_label")
        lw = (RD.font(30, 800).getlength(lab) + 24) if lab else 0
        tot = (n - 1) * gap + sz + lw; x0 = 540 - tot / 2 + lw + sz / 2
        if lab:
            a, s = PP(t, (tc[0] if tc else t_map + 0.5), S); T(c, lab, 30, 540 - tot / 2, MY1 + 46, P["navy"], a, 1.0, 800, maxw=420, anchor="l")
        for k, iso in enumerate(fl):
            tk = tc[core.index(iso)] if iso in core else t_map + 0.5
            a, s = PP(t, tk, S); draw_emoji(c, flag_emoji(iso), x0 + k * gap, MY1 + 44, sz, a, s)

def progress(c, t, S):
    n = S.get("of", 10); k_cur = n - S["rank"]; x0, x1, y = 150, 930, 226; gap = 10; w = (x1 - x0 - gap * (n - 1)) / n
    u = ease(ramp(t, S["t0"] + 0.05, S["t0"] + 0.45))
    for k in range(n):
        x = x0 + k * (w + gap); box(c, x, y - 7, w, 14, 7, P["silver"], 0.55)
        if k < k_cur: box(c, x, y - 7, w, 14, 7, P["navy"], 0.9)
        elif k == k_cur: box(c, x, y - 9, w * u, 18, 9, P["gold"], 1.0)
    T(c, S.get("part_label", ""), 30, 540, y + 40, P["grey"], fade_in(t, S["t0"], S), 1.0, 800, maxw=700)

def sc_impact(c, t, S):
    t0 = S["t0"]; rank = S["rank"]; fe, fh, em, fc = FIELDS[S["field"]]; fcol = col(fc)
    tn = S["times"].get("nm", t0 + 0.4); th = S["times"].get("hp", t0 + 1.0)
    progress(c, t, S)
    # field pill
    a, s = PP(t, t0 + 0.02, S); pill(c, f"{fe}  |  {fh}", 32, 540, 318, fcol, P["white"], a, s, w=800)
    # rank badge (left), bobbing field icon
    u = ease(ramp(t, t0, t0 + 0.35)); bx, by = 168, 470; r = 92 * (0.85 + 0.15 * u)
    sa(c, P["navy"], 0.10 * u); c.new_sub_path(); c.arc(bx + 3, by + 10, r, 0, 2 * math.pi); c.fill()
    circ(c, bx, by, r, P["card"], u, stroke=P["gold"], sw=8)
    T(c, f"#{rank}", 86 if rank < 10 else 74, bx, by + 4, P["navy"], u, 1 + 0.02 * math.sin(max(0, t - t0) * 3), 900, maxw=160)
    a, s = PP(t, t0 + 0.15, S)
    if a > 0.01:
        ix, iy = bx + 74, by - 74 + 5 * math.sin(t * 2.8)
        circ(c, ix, iy, 38 * s, P["white"], a, stroke=fcol, sw=4); draw_emoji(c, em, ix, iy, 46, a, s)
    # name, Hebrew name, year
    cx = 640
    if S.get("view"):
        a2, s2 = PP(t, tn + 0.2, S); pill(c, "In my view  |  לדעתי", 30, bx, by + 126, P["gold"], P["white"], a2, s2, w=800)
    a, s = PP(t, tn - 0.05, S, bounce=2.4)
    T(c, S["name"], 94 if len(S["name"]) <= 10 else 80, cx, 420, P["navy"], a, s, 900, maxw=700)
    a, s = PP(t, tn + 0.12, S); T(c, S["he"], 50, cx, 496, P["blue"], a, s, 700, maxw=700)
    a, s = PP(t, tn + 0.25, S); pill(c, S.get("year_label") or f"Founded {S['year']}", 32, cx, 566, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
    # human impact card
    a, s = PP(t, th - 0.05, S, d=0.4); ytop = 636
    h_en = block_h(S["impact"], 54, 900, 860, 2); h_he = block_h(S["impact_he"], 42, 700, 860, 2); ch = h_en + h_he + 70
    if a > 0.01:
        c.save(); c.translate(540, ytop + ch / 2); c.scale(s, s); c.translate(-540, -(ytop + ch / 2)); old = St.a; St.a *= a
        shadow_box(c, 80, ytop, 920, ch, 30, P["card"], stroke=P["silver"], sw=3); box(c, 80, ytop, 14, ch, 7, P["gold"])
        block(c, S["impact"], 54, 545, ytop + 28 + h_en / 2, P["navy"], 1, 1, 900, hl=P["blue"], maxw=860, max_lines=2)
        block(c, S["impact_he"], 42, 545, ytop + 28 + h_en + 12 + h_he / 2, P["grey"], 1, 1, 700, maxw=860, max_lines=2)
        St.a = old; c.restore()
    # stat chip
    ys = max(ytop + ch + 52, 960)
    a, s = PP(t, th + 0.45, S); pill(c, S["stat"], 38, 540, min(ys, 990), P["white"], P["gold_text"], a, s, outline=P["gold"], w=800, padh=1.45)
    # world map
    t_map = th + 0.25
    a = fade_in(t, t0 + 0.1, S, 0.35); old = St.a; St.a *= a
    world_map(c, t, S, t_map); St.a = old
    src_line(c, t, S)

def src_line(c, t, S):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + S.get("source_delay", 0.6), S)
    z, ls = RD.wrap(s, 30, 700, 940, 2, 0.85); y0 = 1528 if len(ls) == 1 else 1510
    for k, l in enumerate(ls): T(c, l, z, 540, y0 + 38 * k, P["grey"], a, 1.0, 700, src=True)

def sc_tease(c, t, S):
    t0 = S["t0"]; cx = 540
    if S.get("pill"):
        a, s = PP(t, t0 + 0.02, S); pill(c, S["pill"], 46, cx, 520, P["gold"], P["white"], a, s, w=800)
    a, s = PP(t, t0 + 0.15, S); block(c, S["en"], 100, cx, 720, P["navy"], a, s * (1 + 0.012 * math.sin(max(0, t - t0) * 2.2)), 900, hl=P["blue"], maxw=940, max_lines=2)
    a, s = PP(t, t0 + 0.35, S); block(c, S["he"], 60, cx, 880, P["blue"], a, s, 700, maxw=940)
    for k in range(10):
        u = ramp(t, t0 + 0.3 + k * 0.06, t0 + 0.5 + k * 0.06)
        x = 160 + k * 84; y = 1040; circ(c, x, y, 28 * (0.6 + 0.4 * u), P["silver"], 0.3 + 0.7 * u, stroke=P["gold"], sw=3)
        T(c, "?", 30, x, y + 2, P["navy"], u, 1.0, 900, maxw=40)
    a, s = PP(t, t0 + 0.6, S); draw_emoji(c, "🌍", cx, 1250 + 10 * math.sin(t * 2.4), 150, a, s)

def sc_verdict2(c, t, S):
    t0 = S["t0"]; cx = 540
    a, s = PP(t, t0 + 0.02, S); pill(c, "In my view  |  לדעתי", 46, cx, 470, P["gold"], P["white"], a, s, w=800)
    tr = S["times"].get("real", t0 + 0.6)
    a, s = PP(t, tr, S); block(c, S["en"], 104, cx, 700, P["navy"], a, s * (1 + 0.012 * math.sin(max(0, t - t0) * 2.2)), 900, hl=P["blue"], maxw=940, max_lines=3)
    a, s = PP(t, tr + 0.25, S); block(c, S["he"], 60, cx, 900, P["blue"], a, s, 700, maxw=940)
    for k in range(20):
        u = ramp(t, t0 + 0.2 + k * 0.05, t0 + 0.4 + k * 0.05)
        x = 140 + (k % 10) * 89; y = 1080 + (k // 10) * 90
        circ(c, x, y, 30 * (0.6 + 0.4 * u), P["gold"] if k == 19 else P["navy"], 0.25 + 0.75 * u)
        T(c, str(20 - k), 30, x, y + 2, P["white"], u, 1.0, 900, maxw=50)
    emj = ["🩺", "🚌", "🌱", "💧", "💻", "☀️"]
    for k, e in enumerate(emj):
        a, s = PP(t, t0 + 0.9 + 0.12 * k, S); draw_emoji(c, e, 190 + k * 140, 1340 + 8 * math.sin(t * 3 + k), 76, a, s)

def sc_question(c, t, S):
    """comment question end card (no keyword): question EN/HE, ask pill, follow."""
    t0 = S["t0"]; cx = 540; y = 470
    a, s = PP(t, t0 + 0.05, S); draw_emoji(c, "🤔", cx, y - 60 + 8 * math.sin(t * 2.4), 150, a, s)
    hh = block_h(S["en"], 92, 900, 940, 3); block(c, S["en"], 92, cx, y + 90 + hh / 2 - 46, P["navy"], a, s, 900, hl=P["blue"], maxw=940, max_lines=3); y += 90 + hh
    a, s = PP(t, t0 + 0.2, S); block(c, S["he"], 56, cx, y + 20, P["blue"], a, s, 700, maxw=940, max_lines=2); y += 160
    tk = S["times"].get("tell", t0 + 1.0); a, s = PP(t, tk, S)
    pill(c, "Tell me in the comments", 54, cx, y + 40, P["navy"], P["gold2"], a, s, w=900)
    T(c, "כתבו לי בתגובות", 46, cx, y + 140, P["navy"], a, s, 700); y += 260
    a, s = PP(t, tk + 0.4, S)
    T(c, "Follow *@noamroz__*", 56, cx, y + 40, P["navy"], a, s, 900, hl=P["gold_text"]); T(c, "עקבו לעוד", 44, cx, y + 110, P["gold_text"], a, s, 700)
