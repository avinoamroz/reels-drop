"""grab.py <reel_id> <part> <drive_download_json>: parse Cartesia SSE into <reel>/p<part>.wav + _words.json, delete the download.
join: grab.py --join <reel_id>: join parts into vo.wav + vo_words.json with exactly one entry per script word
(Cartesia words are mapped onto script words by character position, so tokenisation differences do not matter).
Pauses inside a part longer than MAXG are squeezed to MAXG; GAP s of silence between parts."""
import json, os, sys, wave, subprocess, re
import numpy as np
D = os.path.dirname(os.path.abspath(__file__)); SR = 44100; MAXG = 0.42; GAP = 0.32
def norm(s): return re.sub(r"[^\w]", "", s.lower())
if sys.argv[1] != "--join":
    rid, k, src = sys.argv[1], sys.argv[2], sys.argv[3]
    out = f"{D}/{rid}/p{k}"
    r = subprocess.run(["python3", "/home/claude/tts_api/sse_parse.py", src, out], capture_output=True, text=True)
    print(r.stdout.strip(), r.stderr.strip()[-300:])
    if r.returncode == 0 and os.path.getsize(out + ".wav") > 20000: os.remove(src)
    sys.exit(r.returncode)
rid = sys.argv[2]; d = f"{D}/{rid}"
parts = json.load(open(f"{d}/tts_parts.json"))
chunks, words, t_out = [], [], 0.0
for k, P in enumerate(parts):
    w = wave.open(f"{d}/p{k}.wav"); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32)
    W = json.load(open(f"{d}/p{k}_words.json"))
    # map script words of this part onto Cartesia word times by character fraction
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f, end=False):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9:
                u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sw = " ".join(P["lines"]).split(); sn = [norm(x) for x in sw]; stot = sum(max(1, len(x)) for x in sn); pos = 0; mine = []
    for x, n_ in zip(sw, sn):
        L = max(1, len(n_)); f0, f1 = pos / stot, (pos + L) / stot; pos += L
        mine.append(dict(word=x, start=t_at(f0 + 1e-6), end=t_at(f1 - 1e-6, True)))
    # squeeze long pauses (by Cartesia word gaps)
    s0 = 0.0 if k == 0 else max(0, W[0]["start"] - 0.1); e_last = min(len(a) / SR, W[-1]["end"] + (0.45 if k == len(parts) - 1 else 0.12))
    cuts = []
    for i in range(len(W) - 1):
        g0, g1 = W[i]["end"], W[i + 1]["start"]
        if g1 - g0 > MAXG: ex = (g1 - g0) - MAXG; m = (g0 + g1) / 2; cuts.append((m - ex / 2, m + ex / 2))
    keep = []; cur = s0
    for c0, c1 in cuts: keep.append((cur, c0)); cur = c1
    keep.append((cur, e_last))
    def mp(t):
        acc = 0.0
        for k0, k1 in keep:
            if t <= k1: return t_out + acc + max(0, t - k0)
            acc += k1 - k0
        return t_out + acc
    for x in mine: words.append(dict(word=x["word"], start=round(mp(x["start"]), 4), end=round(mp(max(x["end"], x["start"] + 0.04)), 4)))
    for k0, k1 in keep:
        seg = a[int(k0 * SR):int(k1 * SR)].copy(); f = min(len(seg), int(0.008 * SR))
        if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        chunks.append(seg); t_out += len(seg) / SR
    if k < len(parts) - 1: chunks.append(np.zeros(int(GAP * SR), np.float32)); t_out += GAP
y = np.concatenate(chunks).clip(-32768, 32767).astype(np.int16)
with wave.open(f"{d}/vo.wav", "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(y.tobytes())
json.dump(words, open(f"{d}/vo_words.json", "w"), ensure_ascii=False, indent=0)
nscript = sum(len(l.split()) for P in parts for l in P["lines"])
print(rid, round(len(y) / SR, 2), "s,", len(words), "words (script", nscript, ")")
