import sys, glob
from PIL import Image
d = sys.argv[1]; fs = sorted(glob.glob(f"{d}/snaps/*.png")); n = len(fs); cols = min(5, n); rows = -(-n // cols)
S = Image.new("RGB", (cols * 360, rows * 640), "black")
for i, f in enumerate(fs): S.paste(Image.open(f).resize((360, 640)), ((i % cols) * 360, (i // cols) * 640))
S.save(f"{d}/sheet.png"); print(f"{d}/sheet.png")
