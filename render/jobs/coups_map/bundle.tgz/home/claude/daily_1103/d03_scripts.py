# -*- coding: utf-8 -*-
"""Narration for the 3 Nov 2026 daily reels (one TTS line per list item). Facts checked 3 Nov 2026:
minorities_kept: Jewish Virtual Library, Jewish Populations in the Arab World (1948 vs 2023); Israel CBS (156,000 Arabs in 1948;
  almost 2.2 million, 21.7%, Sept 2026 release); UN Conciliation Commission for Palestine (about 711,000 Arab refugees, 1951).
coups_map / coups_loop: Powell and Thyne, Global Instances of Coups dataset (version 29 Aug 2026, 1950 to 2026)."""
S = {}
S["minorities_kept"] = [
 "Nineteen forty eight. Two minorities. Who kept theirs?",
 "Iraq. One hundred thirty five thousand Jews. Today? Four.",
 "Egypt. Seventy five thousand. Today, about one hundred.",
 "Yemen, sixty three thousand. Syria, thirty thousand. Today, almost none.",
 "Libya. Thirty eight thousand. Zero.",
 "Algeria. One hundred forty thousand. Fewer than two hundred.",
 "Tunisia, one thousand left. Morocco, about two thousand.",
 "Eight hundred fifty one thousand Jews. Fewer than four thousand remain.",
 "Most of them found a new home in Israel.",
 "Now the other minority. Arabs in Israel, nineteen forty eight. One hundred fifty six thousand.",
 "Today? Almost two point two million. More than one in five Israelis.",
 "Doctors. Judges. Members of the Knesset.",
 "Not perfect either. In nineteen forty eight, about seven hundred thousand Arabs fled or were expelled.",
 "So next time someone says only one side was pushed out, ask them...",
]
S["coups_map"] = [
 "Since nineteen fifty. How many coups?",
 "The fifties. Syria. Egypt. Iran. Egypt again. Syria again. Iraq.",
 "The sixties. Turkey. Syria, twice. Yemen. Iraq. Syria. Iraq again.",
 "Then Syria. Yemen. Iraq. Syria. Libya.",
 "The seventies. Oman. Syria, again. Turkey. Qatar. Yemen. Yemen.",
 "Turkey, nineteen eighty. Yemen, eighty six. Qatar, ninety five.",
 "Egypt, twenty eleven. And twenty thirteen.",
 "Twenty nine coups. And twenty eight more that failed.",
 "Lebanon, Jordan, the UAE? They tried. They failed.",
 "No attempt at all? Only four countries.",
 "Saudi Arabia, Kuwait and Bahrain. Where the crown stays in the family.",
 "And Israel. Where power changes hands one way. The vote.",
 "Not perfect either. In nineteen ninety five, an Israeli extremist murdered Prime Minister Rabin.",
 "So next time someone says Israel isn't a democracy, ask them...",
]
S["coups_loop"] = [
 "Since nineteen fifty. How many coups?",
 "Syria, eight. Yemen, five. Egypt and Iraq, four each.",
 "Twenty nine in all. Israel? Zero.",
 "So when someone says Israel isn't a democracy...",
]
