"""send_c.py [ids] [--dry]: one GitHub render batch for the 5 click-study reels (voice and mix done locally)."""
import sys, os; sys.path.insert(0, "/home/claude/reelkit")
import cloud_render as C
B = "/home/claude/daily_1103"
R = {"minorities_kept": "d03_map_min.py", "coups_map": "d03_map_coups.py coups_map", "coups_loop": "d03_map_coups.py coups_loop"}
jobs = []
for rid, cmd in R.items():
    ents = [f"{B}/{cmd.split()[0]}", f"{B}/d03_ck.py"]
    jobs.append(dict(id=rid, cmd=f"cd {B} && python3 {cmd}", out=f"{B}/{rid}/out/{rid}.mp4", entry=ents,
                     add=[f"{B}/{rid}/timing.json", f"{B}/{rid}/audio.m4a", f"{B}/{rid}/tts.txt"]))
only = [a for a in sys.argv[1:] if not a.startswith("--")]
if only: jobs = [j for j in jobs if j["id"] in only]
_c = C.collect
def coll(e, a):
    keep = []
    for f in _c(e, a):
        if f.startswith(B + "/"):
            rel = f[len(B) + 1:]
            if not (rel.endswith(".py") and "/" not in rel) and not rel.startswith("flags/") and f not in a: continue
        keep.append(f)
    return keep
C.collect = coll
if "--dry" in sys.argv:
    for j in jobs:
        fs = coll(j["entry"], j["add"]); print(j["id"], len(fs), sum(os.path.getsize(x) for x in fs) >> 20, "MB", [x for x in fs if "daily_1103" in x])
else: C.send(jobs)
