import json, os, sys
sys.path.insert(0, "/home/claude/daily_1103")
from d03_scripts import S
VOICE = "cd06f613-0c92-4347-9b94-b34cb4a0239f"
for rid, lines in S.items():
    d = f"/home/claude/daily_1103/{rid}"; os.makedirs(d, exist_ok=True)
    open(f"{d}/tts.txt", "w").write("\n".join(lines) + "\n")
    parts, cur, n = [], [], 0
    for l in lines:
        w = len(l.split())
        if cur and n + w > 75: parts.append(cur); cur, n = [], 0
        cur.append(l); n += w
    parts.append(cur)
    out = []
    for k, ls in enumerate(parts):
        name = f"d03_{rid}_p{k}.txt"
        body = {"model_id": "sonic-3", "transcript": " ".join(ls), "voice": {"mode": "id", "id": VOICE},
                "output_format": {"container": "raw", "encoding": "pcm_s16le", "sample_rate": 44100}, "add_timestamps": True, "language": "en"}
        out.append(dict(lines=ls, name=name, data=dict(body=json.dumps(body, ensure_ascii=False), name=name, tag="reel", endpoint="sse")))
    json.dump(out, open(f"{d}/tts_parts.json", "w"), ensure_ascii=False, indent=1)
    print(rid, [len(" ".join(p).split()) for p in parts])
