# -*- coding: utf-8 -*-
"""coups_map / coups_loop: Since 1950. How many coups? Middle East map + year counter + coup counter.
Data: Powell and Thyne, Global Instances of Coups (version 29 Aug 2026): successful coups (code 2) and failed attempts (code 1), 1950 to 2026.
usage: d03_map_coups.py <rid> [--snaps=..]"""
import sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/daily_1103")
from d03_ck import *
rid = sys.argv[1]; LOOP = rid == "coups_loop"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
F = features()
def wt(L, word, nth=1):
    n = 0
    for w in T.lines[L - 1]["words"]:
        if T.norm(w["w"]) == T.norm(word):
            n += 1
            if n == nth: return w["t0"] - 0.05
    raise KeyError((L, word))
# successful coups, chronological (country, year, (line, word, nth)) for the full reel
EV = [("SYR", 1951, (2, "Syria", 1)), ("EGY", 1952, (2, "Egypt", 1)), ("IRN", 1953, (2, "Iran", 1)), ("EGY", 1954, (2, "Egypt", 2)),
      ("SYR", 1954, (2, "Syria", 2)), ("IRQ", 1958, (2, "Iraq", 1)),
      ("TUR", 1960, (3, "Turkey", 1)), ("SYR", 1961, (3, "Syria", 1)), ("SYR", 1962, (3, "twice", 1)), ("YEM", 1962, (3, "Yemen", 1)),
      ("IRQ", 1963, (3, "Iraq", 1)), ("SYR", 1963, (3, "Syria", 2)), ("IRQ", 1963, (3, "Iraq", 2)),
      ("SYR", 1966, (4, "Syria", 1)), ("YEM", 1967, (4, "Yemen", 1)), ("IRQ", 1968, (4, "Iraq", 1)), ("SYR", 1969, (4, "Syria", 2)), ("LBY", 1969, (4, "Libya", 1)),
      ("OMN", 1970, (5, "Oman", 1)), ("SYR", 1970, (5, "Syria", 1)), ("TUR", 1971, (5, "Turkey", 1)), ("QAT", 1972, (5, "Qatar", 1)),
      ("YEM", 1974, (5, "Yemen", 1)), ("YEM", 1978, (5, "Yemen", 2)),
      ("TUR", 1980, (6, "Turkey", 1)), ("YEM", 1986, (6, "Yemen", 1)), ("QAT", 1995, (6, "Qatar", 1)),
      ("EGY", 2011, (7, "Egypt", 1)), ("EGY", 2013, (7, "thirteen", 1))]
assert len(EV) == 29
FAILED = {"TUR": 3, "IRQ": 8, "SYR": 4, "LBN": 2, "JOR": 2, "YEM": 4, "LBY": 2, "QAT": 1, "ARE": 2}
assert sum(FAILED.values()) == 28
if LOOP:   # whole countries light on their names
    TM = {"SYR": wt(2, "Syria"), "YEM": wt(2, "Yemen"), "EGY": wt(2, "Egypt"), "IRQ": wt(2, "Iraq")}
    rest = ["TUR", "QAT", "IRN", "LBY", "OMN"]; t_r = wt(3, "Twenty")
    times = []
    for i, (k, y, _) in enumerate(EV):
        if k in TM: j = sum(1 for kk, _, _ in EV[:i] if kk == k); times.append(TM[k] + 0.07 * j)
        else: times.append(t_r + 0.12 * rest.index(k) + 0.03 * i)
    T_FAIL = 99; T_TRY = 99; T_NONE = 99; T_KING = 99; T_ISR = wt(3, "Israel?"); T_NP = T.at(4); T_END = T.at(4)
else:
    times = [wt(*e[2]) for e in EV]
    T_FAIL = wt(8, "twenty", 1); T_TRY = T.at(9); T_NONE = T.at(10); T_KING = T.at(11); T_ISR = T.at(12); T_NP = T.at(13); T_END = T.at(14)
YKF = [(0.0, 1950.0)] + [(tt, float(y)) for tt, (k, y, _) in zip(times, EV)] + [(times[-1] + 1.2, 2026.0), (999, 2026.0)]
YKF = sorted(YKF)
def year_at(t): return float(np.interp(t, [a for a, _ in YKF], [b for _, b in YKF]))
MR = (0, 560, W, 1232); P = Proj((8.5, 11.5, 62.0, 42.5), MR, lat0=27)
LAND = hx("#26385C"); SEA = (12, 24, 52); RED2 = hx("#E0605E"); SIL = hx("#8FA3C4")
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
# badge position (lon, lat), anchor (lon, lat) or None
BP = {"SYR": ((39.6, 35.4), None), "EGY": ((29.6, 26.6), None), "IRN": ((55.2, 33.4), None), "IRQ": ((44.2, 32.3), None),
      "TUR": ((34.0, 39.2), None), "YEM": ((47.5, 15.9), None), "LBY": ((17.8, 27.0), None), "OMN": ((57.6, 19.6), None),
      "QAT": ((54.6, 26.2), (51.2, 25.3)), "BHR": ((52.8, 28.6), (50.55, 26.05)), "KWT": ((49.8, 30.4), (47.6, 29.3)),
      "SAU": ((44.7, 23.6), None), "ARE": ((54.0, 23.1), None), "JOR": ((37.4, 30.4), None), "LBN": ((30.4, 34.9), (35.8, 33.9)),
      "ISR": ((30.2, 32.2), (34.8, 31.4))}
NAME = {"SYR": "Syria", "EGY": "Egypt", "IRN": "Iran", "IRQ": "Iraq", "TUR": "Turkey", "YEM": "Yemen", "LBY": "Libya", "OMN": "Oman",
        "QAT": "Qatar", "BHR": "Bahrain", "KWT": "Kuwait", "SAU": "Saudi Arabia", "ARE": "UAE", "JOR": "Jordan", "LBN": "Lebanon", "ISR": "Israel"}
SIDE = {"BHR", "QAT"}; LEFT = {"LBN"}; UP = {"KWT"}
KINGS = ["SAU", "KWT", "BHR"]; TRIED = ["LBN", "JOR", "ARE"]
SUBS = sub_chunks(T, [("nineteen fifty", "1950"), ("Nineteen fifty", "1950"), ("nineteen eighty", "1980"), ("eighty six", "1986"), ("ninety five", "1995"),
                      ("twenty eleven", "2011"), ("twenty thirteen", "2013"), ("Twenty nine", "29"), ("twenty eight", "28"), ("nineteen ninety five", "1995"),
                      ("eight", "8"), ("five", "5"), ("four each", "4 each"), ("Zero", "0"), ("four countries", "4 countries")])
out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    im = stage(); arr = BASE.copy(); cnt = {}
    for tt, (k, y, _) in zip(times, EV):
        if t >= tt: cnt[k] = cnt.get(k, 0) + 1; last = (k, y, tt)
    for k, n in cnt.items():
        compR(arr, M[k], RED2, min(1.0, 0.35 + 0.13 * n))
    if t >= T_TRY:
        for k in TRIED: compR(arr, M[k], SIL, 0.45 * min(1, (t - T_TRY) / 0.4))
    compR(arr, M["ISR"], ISRAEL_GOLD, 1.0); compR(arr, M["PSX"], PAL_GOLD, 1.0)
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    for k, ((lo, la), anc) in BP.items():
        n = cnt.get(k, 0); x, y = P(lo, la)
        if anc:
            ax, ay = P(*anc); ld.line([(x, y), (ax, ay)], fill=WHITE[:3] + (180,), width=3); ld.ellipse([ax - 5, ay - 5, ax + 5, ay + 5], fill=WHITE)
        pop = 0.0
        for tt, (kk, _, _) in zip(times, EV):
            if kk == k and 0 <= t - tt < 0.35: pop = math.sin(math.pi * (t - tt) / 0.35)
        hl = (k in KINGS and T_KING <= t < T_ISR) or (k in TRIED and T_TRY <= t < T_NONE) or (k == "ISR" and t >= T_ISR and t < T_END + 1.0)
        r = 27 * (1 + 0.35 * pop + 0.04 * math.sin(t * 4 + x / 90)) * (1.12 + 0.06 * math.sin(t * 6) if hl else 1)
        fill = RED[:3] + (240,) if n else (10, 22, 50, 235)
        oc = YEL if (hl or k == "ISR") else (WHITE if n else SILVER)
        ld.ellipse([x - r, y - r, x + r, y + r], fill=fill, outline=oc[:3] + (255,), width=5 if hl else 3)
        txt(ld, x, y + 1, str(n), int(34 * r / 27), WHITE if n else (YEL if k == "ISR" else SILVER), 900, "mm")
        if k in UP: txt(ld, x, y - r - 22, NAME[k], 36, WHITE, 800, "mm", stroke=4)
        elif k in LEFT: txt(ld, x - r - 8, y, NAME[k], 36, WHITE, 800, "rm", stroke=4)
        elif k in SIDE: txt(ld, x + r + 8, y, NAME[k], 36, WHITE, 800, "lm", stroke=4)
        else: txt(ld, x, y + r + 22, NAME[k], 36 if k not in ("ISR",) else 42, YEL if k == "ISR" else WHITE, 800, "mm", stroke=4)
    im.alpha_composite(lay); d = ImageDraw.Draw(im)
    yh = hook(d, ["Since 1950.", "How many coups?"], t)
    ev = "16 countries. 76 years."
    if T_TRY <= t < T_NONE: ev = "Lebanon, Jordan, UAE: tried and failed"
    elif T_NONE <= t < T_ISR: ev = "No attempt at all: Saudi Arabia, Kuwait, Bahrain"
    elif cnt and t < T_FAIL and t - last[2] < 2.5: ev = f"{last[1]}: {NAME[last[0]]}"
    txt(d, W / 2, yh + 2, ev, fit(ev, 56, 1000, 700, 44), WHITE if ev[0].isdigit() and ev[:2] != "16" else SILVER, 700, "ma")
    YY = 1244; y = year_at(t)
    txt(d, 46, YY, "76 years" if LOOP else str(int(y)), 130 if LOOP else 150, WHITE, 900, "la")
    tot = sum(cnt.values())
    txt(d, 1034, YY + 8, "Coups", 56, SILVER, 700, "ra"); txt(d, 1034, YY + 62, str(tot), 110, YEL, 900, "ra")
    if t >= T_FAIL:
        nf = int(round(28 * ease((t - T_FAIL) / 1.0)))
        txt(d, 760, YY + 8, "Failed", 56, SILVER, 700, "ra"); txt(d, 760, YY + 62, f"+{nf}", 110, SILVER, 900, "ra")
    if T_ISR <= t:
        a = min(1, (t - T_ISR) / 0.3) * (1 - min(1, max(0, (t - T_NP) / 0.3)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([40, 1236, 1040, 1440], 26, fill=(8, 20, 46, int(245 * a)), outline=YEL[:3] + (int(255 * a),), width=4)
            txt(ld, W / 2, 1258, "Israel: 0 coups. 0 attempts.", fit("Israel: 0 coups. 0 attempts.", 76, 940, 900, 50), WHITE, 900, "ma", a)
            txt(ld, W / 2, 1352, "Power changes one way: the vote", fit("Power changes one way: the vote", 60, 940, 900, 44), YEL, 900, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    if T_NP <= t:
        a = min(1, (t - T_NP) / 0.3) * (1 - min(1, max(0, (t - (T_END if not LOOP else DUR - 1.2) - (0.6 if not LOOP else 0)) / 0.4)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([40, 600, 1040, 1000], 28, fill=(8, 20, 46, int(245 * a)), outline=GOLD[:3] + (int(255 * a),), width=4)
            txt(ld, W / 2, 640, "Not perfect either", 76, GOLD, 900, "ma", a)
            for i, l in enumerate(wrap("1995: an Israeli extremist murdered PM Yitzhak Rabin.", 64, 900)):
                txt(ld, W / 2, 760 + i * 80, l, 64, WHITE, 800, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    source(d, "Source: Powell and Thyne, Global Instances of Coups, Aug 2026")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
