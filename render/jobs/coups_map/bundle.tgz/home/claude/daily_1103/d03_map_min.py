# -*- coding: utf-8 -*-
"""minorities_kept: 1948. Two minorities. Who kept theirs? Map of 8 Arab countries (Jewish communities shrink, JVL 1948 vs 2023)
plus Israel (Arab citizens 156,000 in 1948 to almost 2.2 million, CBS 2026). Two counters, answer held to the end.
usage: d03_map_min.py [--snaps=..]"""
import sys, re
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/daily_1103")
from d03_ck import *
rid = "minorities_kept"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
F = features()
def wt(L, word, nth=1):
    n = 0
    for w in T.lines[L - 1]["words"]:
        if T.norm(w["w"]) == T.norm(word):
            n += 1
            if n == nth: return w["t0"] - 0.05
    raise KeyError((L, word))
# code, name, 1948, today, display today, label (lon, lat), drop time
C = [("IRQ", "Iraq", 135000, 4, "4", (44.0, 32.6), wt(2, "Four.")),
     ("EGY", "Egypt", 75000, 100, "100", (29.6, 26.4), wt(3, "about")),
     ("YEM", "Yemen", 63000, 0, "0", (46.5, 15.6), wt(4, "almost")),
     ("SYR", "Syria", 30000, 0, "0", (38.6, 35.3), wt(4, "almost") + 0.15),
     ("LBY", "Libya", 38000, 0, "0", (18.0, 27.0), wt(5, "Zero.")),
     ("DZA", "Algeria", 140000, 200, "<200", (2.2, 25.6), wt(6, "Fewer")),
     ("TUN", "Tunisia", 105000, 1000, "1,000", (9.6, 34.4), wt(7, "one")),
     ("MAR", "Morocco", 265000, 2100, "2,100", (-7.4, 31.0), wt(7, "about"))]
HL = {"IRQ": T.at(2), "EGY": T.at(3), "YEM": T.at(4), "SYR": wt(4, "Syria,"), "LBY": T.at(5), "DZA": T.at(6), "TUN": T.at(7), "MAR": wt(7, "Morocco,")}
T_TOT = T.at(8); T_HOME = T.at(9); T_OTHER = T.at(10); T_GROW = wt(11, "Almost"); T_PEOPLE = T.at(12); T_NP = T.at(13); T_END = T.at(14)
A0, A1 = 156000, 2200000
MR = (0, 572, W, 1052); P = Proj((-13.5, 11.5, 57.5, 38.5), MR, lat0=27)
LAND = hx("#26385C"); SEA = (12, 24, 52); LIT = hx("#45A4DD"); DIM = hx("#2E4672")
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
KR = 62 / math.sqrt(265000)
def fmt(v): return f"{int(round(v)):,}"
SUBS = sub_chunks(T, [("Nineteen forty eight", "1948"), ("nineteen forty eight", "1948"), ("One hundred thirty five thousand", "135,000"),
                      ("Seventy five thousand", "75,000"), ("about one hundred", "about 100"), ("sixty three thousand", "63,000"), ("thirty thousand", "30,000"),
                      ("Thirty eight thousand", "38,000"), ("One hundred forty thousand", "140,000"), ("two hundred", "200"), ("one thousand", "1,000"),
                      ("about two thousand", "about 2,000"), ("Eight hundred fifty one thousand", "851,000"), ("four thousand", "4,000"),
                      ("One hundred fifty six thousand", "156,000"), ("two point two million", "2.2 million"), ("seven hundred thousand", "700,000"),
                      ("Four.", "4."), ("Zero.", "0."), ("one in five", "1 in 5")])
def val(c, t):
    k, n, v0, v1, *_ , td = c
    u = ease((t - td) / 1.0); return v0 + (v1 - v0) * u
out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    im = stage(); arr = BASE.copy()
    for c in C:
        k, v0 = c[0], c[2]; v = val(c, t); compR(arr, M[k], LIT, 0.25 + 0.75 * (v / v0) ** 0.5)
    compR(arr, M["ISR"], ISRAEL_GOLD, 1.0); compR(arr, M["PSX"], PAL_GOLD, 1.0)
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    # arrows home (line 9)
    if T_HOME <= t < T_NP:
        a = min(1, (t - T_HOME) / 0.6) * (1 - min(1, max(0, (t - T_OTHER - 1.5) / 0.6)))
        ix, iy = P(34.9, 31.6)
        for c in C:
            x, y = P(*c[5]); u = ease((t - T_HOME) / 1.2)
            ld.line([(x, y), (x + (ix - x) * u, y + (iy - y) * u)], fill=YEL[:3] + (int(200 * a),), width=4)
    # Israel ring (Arab citizens)
    av = A0 + (A1 - A0) * ease((t - T_GROW) / 2.0) if t >= T_GROW else A0
    ix, iy = P(34.9, 31.6); r = KR * math.sqrt(av)
    ga = 0.55 if t < T_OTHER else 1.0
    ld.ellipse([ix - r, iy - r, ix + r, iy + r], fill=GOLD[:3] + (int(60 * ga),), outline=GOLD[:3] + (int(255 * ga),), width=5)
    # community bubbles
    for c in C:
        k, n, v0, v1, disp, lab, td = c; v = val(c, t); x, y = P(*lab)
        r = max(6, KR * math.sqrt(v)) * (1 + 0.03 * math.sin(t * 3 + x))
        hl = HL[k] <= t < td + 1.4
        ld.ellipse([x - r, y - r, x + r, y + r], fill=SKY[:3] + (150,), outline=(YEL if hl else WHITE)[:3] + (255,), width=6 if hl else 3)
        s = disp if t >= td + 1.0 else fmt(v / 1000) + "k" if v >= 1000 else fmt(v)
        if t < td: s = fmt(v0 / 1000) + "k"
        txt(ld, x, y - r - 30, s, 48, YEL, 900, "mm", stroke=4)
        txt(ld, x, y + r + 26, n, 40, WHITE, 800, "mm", stroke=4)
    im.alpha_composite(lay); d = ImageDraw.Draw(im)
    txt(d, ix - r - 8 if r < 60 else ix, iy + (0 if r < 60 else r + 30), "Israel", 42, GOLD, 900, "rm" if r < 60 else "mm", stroke=4)
    # hook + shape
    yh = hook(d, ["Two minorities.", "Who kept theirs?"], t)
    # counters
    jt = sum(val(c, t) for c in C); YY = 1080
    lab_a = 1.0 if t < T_OTHER else 0.55
    txt(d, 270, YY, "Jews in 8 Arab", 56, SILVER, 700, "ma", lab_a); txt(d, 270, YY + 60, "countries", 56, SILVER, 700, "ma", lab_a)
    js = "under 4,000" if t >= T_TOT else fmt(jt)
    txt(d, 270, YY + 128, js, fit(js, 110, 466, 900, 60), YEL, 900, "ma", lab_a)
    txt(d, 270, YY + 254, "2023" if t >= wt(7, "about") + 1 else "1948", 48, SILVER, 700, "ma", lab_a)
    rb = 1.0 if t >= T_OTHER else 0.8
    txt(d, 810, YY, "Arabs in", 56, SILVER, 700, "ma", rb); txt(d, 810, YY + 60, "Israel", 56, SILVER, 700, "ma", rb)
    as_ = "2.2 million" if t >= T_GROW + 2.0 else fmt(round(av, -3))
    txt(d, 810, YY + 128, as_, fit(as_, 110, 466, 900, 60), GOLD, 900, "ma", rb)
    txt(d, 810, YY + 254, "2026: 21.7% of Israel" if t >= T_GROW + 2.0 else "1948", 48, SILVER, 700, "ma", rb)
    d.line([(540, YY + 10), (540, YY + 270)], fill=GREY[:3] + (160,), width=2)
    if T_OTHER <= t < T_NP:   # highlight the right counter
        a = min(1, (t - T_OTHER) / 0.3); d.rounded_rectangle([572, YY - 14, 1050, YY + 316], 24, outline=GOLD[:3] + (int(255 * a),), width=4)
    if T_TOT <= t < T_OTHER:
        a = min(1, (t - T_TOT) / 0.3); d.rounded_rectangle([30, YY - 14, 510, YY + 316], 24, outline=YEL[:3] + (int(255 * a),), width=4)
    ev = None
    if T_HOME <= t < T_OTHER: ev = "Most came to Israel"
    elif T_PEOPLE <= t < T_NP: ev = "Doctors. Judges. Knesset members."
    sh = ev or "1948 to today. Two counters."
    txt(d, W / 2, yh + 2, sh, fit(sh, 54, 1000, 700, 44), WHITE if ev else SILVER, 700, "ma")
    # not perfect card
    if T_NP <= t:
        a = min(1, (t - T_NP) / 0.3) * (1 - min(1, max(0, (t - T_END - 0.6) / 0.4)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([40, 576, 1040, 1046], 28, fill=(8, 20, 46, int(245 * a)), outline=GOLD[:3] + (int(255 * a),), width=4)
            txt(ld, W / 2, 616, "Not perfect either", 76, GOLD, 900, "ma", a)
            for i, l in enumerate(wrap("1948: about 700,000 Arabs fled or were expelled.", 66, 900)):
                txt(ld, W / 2, 736 + i * 82, l, 66, WHITE, 800, "ma", a)
            txt(ld, W / 2, 976, "UN Conciliation Commission estimate, 1951", 38, SILVER, 700, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    source(d, "Sources: Jewish Virtual Library 2023; Israel CBS 2026; UNCCP 1951")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
