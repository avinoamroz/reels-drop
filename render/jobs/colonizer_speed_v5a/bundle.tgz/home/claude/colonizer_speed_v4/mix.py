"""local step: loopable doc_piano bed + soft hits (replay start, dive to Israel) + jet whoosh under the replay, under work/vo.wav
-> work/mix.m4a (-14 LUFS). Same loop method as empires_israel/mix.py: a whole number of bars, overflow folded onto the start."""
import sys, os, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/colonizer_speed_v4"
WJ = json.load(open(f"{D}/work/words.json")); W = WJ["words"]; dur = WJ["dur"]; SR = AU.SR
LS = lambda li: min(w["t0"] for w in W if w["li"] == li); LE = lambda li: max(w["t1"] for w in W if w["li"] == li)
TURN = LS(4) - 0.2; R0 = LE(3) - 0.05
bars = round(dur / (4 * 60 / 90)); bpm = 4 * 60 * bars / dur; bar = 4 * 60 / bpm
raw = AU.doc_music(dur + bar, bpm=bpm, flip_at=TURN, end_ring=0.01)
n = int(round(dur * SR)); xf = int(0.6 * SR)
bed = raw[:, :n].copy(); tail = raw[:, n:n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(R0, AU.soft_hit(), -5.0), (R0 + 0.1, AU.jet_whoosh(3.0), -9.0), (TURN + 0.2, AU.soft_hit(), -5.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, dur, ev, mw, music_db=-18.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=dur, bpm=bpm, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", dur, J.get("final_I"), J.get("final_TP"))
