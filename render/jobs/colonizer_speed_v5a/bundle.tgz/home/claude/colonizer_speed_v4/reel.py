"""colonizer_speed_v4 (Noam, 1 Nov): five colonial empires on a world map. 1) the land each took, filled at its peak extent,
2) its speed in km² a year (bar race), 3) 'real speed': all five spread across the map by the year they took each piece,
1492 to 1942 in about 3 s, 4) the camera dives to Israel: 1967 (Sinai, Gaza, West Bank, Golan), Sinai handed back, Gaza left
in 2005, ~170 km² a year even counting from 1948, then it stopped. Questions, the petri dish of terror (US State Dept list),
7 October, peace treaties (photo: Begin, Carter, Sadat 1978, public domain), and Noam's closing line. Visual-only 'Follow for
part 2' cue with a chevron, then the last 0.5 s cross-fades into frame 0 (the lead-in completes the hook).
usage: python3 reel.py --snaps 0,1.5,... | python3 reel.py --out work/silent.mp4"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rlib import *
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()

# ------------------------------------------------------------------ timing
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]; T_END = WJ["dur"]; LOOP = 0.5
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word, n=0):
    k = 0
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(word.lower()):
            if k == n: return i
            k += 1
    raise KeyError((li, word))
def SW(li, word, n=0): return S(li, WI(li, word, n))
YELLOW = "#FFD60A"; SKY = "#45A4DD"; NAVY = "#163261"; ILG = "#E2B84B"; LGREY = "#C9CED8"

# ------------------------------------------------------------------ geography
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    return [np.array(r, float) for p in polys for r in p]
EMPS = [  # key, name, flag, colour, peak area (M km2), peak year, speed km2/yr, first year
 ("britain", "Britain", "🇬🇧", "#FF453A", 35.5, 1920, 105000, 1583),
 ("russia", "Russia", "🇷🇺", "#BF5AF2", 22.8, 1895, 57000, 1547),
 ("spain", "Spain", "🇪🇸", "#FF9F0A", 13.7, 1810, 42000, 1492),
 ("france", "France", "🇫🇷", "#0A84FF", 11.5, 1920, 120000, 1830),
 ("japan", "Japan", "🇯🇵", "#5EE6D0", 7.4, 1942, 150000, 1895),
]
EI = {e[0]: e for e in EMPS}
PIECES = sorted([(p["year"], k, rings_of(p["geom"])) for k, ps in G["empires"].items() for p in ps], key=lambda x: x[0])
LOCAL = {k: rings_of(v) for k, v in G["local"].items()}
ISR49, WB, GAZA, GOLAN, SINAI = (rings_of(G[k]) for k in ("isr49", "wb", "gaza", "golan", "sinai"))
def path(c, cam, rings):
    kx = cam.k * cam.cosf; ky = cam.k
    for r in rings:
        xs = 540 + (r[:, 0] - cam.lon) * kx; ys = cam.cy - (r[:, 1] - cam.lat) * ky
        c.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): c.line_to(x, y)
        c.close_path()
def solid(c, cam, rings, col, alpha, lw=0.0, scol="#FFFFFF", salpha=None):
    if alpha <= 0.004 or not rings: return
    v = hx(col) / 255; path(c, cam, rings); c.set_source_rgba(v[0], v[1], v[2], alpha); c.fill_preserve()
    if lw: s_ = hx(scol) / 255; c.set_source_rgba(s_[0], s_[1], s_[2], alpha if salpha is None else salpha); c.set_line_width(lw); c.stroke()
    else: c.new_path()
def glow(c, cam, rings, a, col="#FFFFFF"):
    if a <= 0.004: return
    v = hx(col) / 255; path(c, cam, rings)
    for wdt, al in ((14, 0.12), (8, 0.22), (3, 0.95)):
        c.set_source_rgba(v[0], v[1], v[2], al * a); c.set_line_width(wdt); c.stroke_preserve()
    c.new_path()

# ------------------------------------------------------------------ beats (all from the narration's word times)
T_LAND = S(1); FILL_T = [S(1) + 0.55 + 0.5 * i for i in range(5)]            # Britain..Japan fill one by one
T_SPEED = S(2)
SPEED_AT = {"japan": SW(2, "Japan"), "france": SW(2, "France"), "britain": SW(2, "Britain"), "russia": SW(2, "Russia"), "spain": SW(2, "Spain")}
T_REAL = S(3); R0, R1 = E(3) - 0.05, S(4) - 0.35; Y0, Y1 = 1492, 1942
T_ISR = S(4); T_DIVE1 = SW(4, "In") + 0.2
TK = {"sinai": SW(4, "Sinai"), "gaza": SW(4, "Gaza"), "wb": SW(4, "West"), "golan": SW(4, "Golan")}
T_SIN = S(5); T_BACK = SW(5, "back"); T_GAZ = SW(5, "Gaza"); T_LEFT = SW(5, "Left")
T_170 = S(6); T_170v = SW(6, "about")
T_STOP = S(7); T_WHY1 = SW(7, "Why"); T_WHY2 = SW(7, "Why", 1)
T_ASK = S(8)
T_TERR = S(9); T_PETRI = SW(9, "petri")
T_OCT = S(10); T_LEFT2 = SW(10, "land")
T_PEACE = S(11)
T_END1 = S(12); T_BABY = SW(12, "Its")
T_LEAD = S(13)

# ------------------------------------------------------------------ camera
WORLD = camw(15, 14, 330, 1130)
LEV = camw(34.4, 30.6, 6.6, 1250)
LEVW = camw(39.5, 32.4, 21, 1120)
GAZC = camw(34.6, 31.45, 2.8, 1180)
PEACEC = camw(35.5, 29.5, 13, 1400)
def camera(t):
    if t < T_ISR:
        z = 1 + 0.035 * seg(t, 0, T_ISR); return Cam(WORLD.lon, WORLD.lat, WORLD.k * z, WORLD.cy)
    w1 = Cam(WORLD.lon, WORLD.lat, WORLD.k * 1.035, WORLD.cy)
    if t < T_TERR - 0.2: c = cam_lerp(w1, LEV, seg(t, T_ISR + 0.05, T_DIVE1 + 0.6)); return c
    if t < T_OCT - 0.15: return cam_lerp(LEV, LEVW, seg(t, T_TERR - 0.2, T_TERR + 0.9))
    if t < T_PEACE - 0.15: return cam_lerp(LEVW, GAZC, seg(t, T_OCT - 0.15, T_OCT + 0.9))
    if t < T_LEAD - 0.1: return cam_lerp(GAZC, PEACEC, seg(t, T_PEACE - 0.15, T_PEACE + 1.0))
    return cam_lerp(PEACEC, WORLD, seg(t, T_LEAD - 0.1, T_END - LOOP - 0.1))

# ------------------------------------------------------------------ map layer
def year_at(t):
    if t < R0: return None
    return Y0 + (Y1 - Y0) * min(1, (t - R0) / (R1 - R0))
def emp_alpha(k, t):
    """static fill of an empire: in on its FILL_T, held through the speed beat, out for the replay"""
    i = [e[0] for e in EMPS].index(k)
    a_in = seg(t, FILL_T[i], FILL_T[i] + 0.3) if t >= 0.85 else 0.0
    return a_in * (1 - seg(t, R0 - 0.25, R0))
def hook_flash(k, t):
    i = [e[0] for e in EMPS].index(k); a0 = 0.2 + 0.18 * i
    return 0.85 * seg(t, a0, a0 + 0.16) * (1 - seg(t, a0 + 0.4, a0 + 0.7)) if t < 1.6 else 0.0
def map_layer(canvas, t, cam):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); c.set_line_join(cairo.LINE_JOIN_ROUND)
    va = seg(cam.k, 25, 90)
    if va > 0:
        for k, rs in LOCAL.items(): solid(c, cam, rs, "#20242C", 0.85 * va, 1.3, "#6B7385")
    yr = year_at(t); ra = 1 - seg(t, T_ISR + 0.1, T_ISR + 0.7)
    spk = None
    if T_SPEED <= t < R0:
        for k, ts in sorted(SPEED_AT.items(), key=lambda x: x[1]):
            if t >= ts - 0.05: spk = k
    for y, k, rs in PIECES:
        col = EI[k][3]
        a = max(emp_alpha(k, t), hook_flash(k, t))
        if yr is not None and y <= yr:
            a = max(a, ra * min(1, (yr - y) / 12 + 0.35))
        if a > 0.004:
            hi = (spk == k)
            solid(c, cam, rs, col, 0.88 * a, 0.9, "#FFFFFF", (0.55 + 0.4 * hi) * a)
    # Israel (gold, incl. Golan); West Bank and Gaza in the shade; Green Line in green
    ia = seg(t, T_ISR + 0.2, T_ISR + 0.9) * (1 - seg(t, T_LEAD, T_LEAD + 0.8))
    if ia > 0:
        solid(c, cam, ISR49, ILG, 0.95 * ia, 1.2, "#FFFFFF", 0.7 * ia)
        for key, rs, col in (("golan", GOLAN, ILG), ("wb", WB, ISR_SHADE), ("gaza", GAZA, ISR_SHADE)):
            a = ia * seg(t, TK[key] - 0.05, TK[key] + 0.3)
            solid(c, cam, rs, col, 0.95 * a)
            glow(c, cam, rs, a * (1 - seg(t, TK[key] + 0.6, TK[key] + 1.4)))
        ga = ia * seg(t, TK["wb"], TK["wb"] + 0.3)
        if ga > 0 and cam.k > 40:
            path(c, cam, WB + GAZA); c.set_source_rgba(*GREEN, ga); c.set_line_width(min(5, 1.5 + cam.k / 100)); c.set_dash([10, 6]); c.stroke(); c.set_dash([])
        # Sinai: taken 1967, handed back (completed 1982)
        sa = ia * seg(t, TK["sinai"] - 0.05, TK["sinai"] + 0.3) * (1 - seg(t, T_BACK, T_BACK + 0.8))
        solid(c, cam, SINAI, ILG, 0.9 * sa); glow(c, cam, SINAI, sa * (1 - seg(t, TK["sinai"] + 0.6, TK["sinai"] + 1.4)))
        oa = ia * seg(t, T_BACK + 0.4, T_BACK + 0.9) * (1 - seg(t, T_170 - 0.2, T_170 + 0.3))
        if oa > 0:
            path(c, cam, SINAI); c.set_source_rgba(1, 1, 1, 0.9 * oa); c.set_line_width(3); c.set_dash([12, 8]); c.stroke(); c.set_dash([])
        gl = ia * seg(t, T_LEFT, T_LEFT + 0.3) * (1 - seg(t, T_170 - 0.2, T_170 + 0.3))
        glow(c, cam, GAZA, gl)
    surf.flush()
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data()).copy()
    rgba = a[:, :, [2, 1, 0, 3]].astype(np.float32); al = rgba[:, :, 3:4] / 255.0
    col = np.where(al > 0, rgba[:, :, :3] / np.maximum(al, 1e-6), 0)
    canvas.alpha_composite(Image.fromarray(np.dstack([col, al * 255]).clip(0, 255).astype(np.uint8), "RGBA"))

# terror pulses (petri dish) and the 7 October pulse
HOTS = [("HAMAS", 34.42, 31.42, -1), ("Hezbollah", 35.6, 33.55, 1), ("ISIS", 40.2, 35.0, 1), ("Iran", 47.0, 33.4, -1)]
def pulses(canvas, t, cam):
    a0 = seg(t, T_TERR + 0.6, T_TERR + 1.0) * (1 - seg(t, T_OCT - 0.2, T_OCT + 0.2))
    a1 = seg(t, T_OCT + 0.6, T_OCT + 1.0) * (1 - seg(t, T_PEACE - 0.2, T_PEACE + 0.2))
    if a0 <= 0 and a1 <= 0: return
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    pts = [(n, lo, la, s, a0 * seg(t, T_TERR + 0.6 + 0.25 * i, T_TERR + 0.9 + 0.25 * i)) for i, (n, lo, la, s) in enumerate(HOTS)]
    if a1 > 0: pts = [("", 34.42, 31.42, 0, a1)]
    for n, lo, la, s, a in pts:
        if a <= 0: continue
        x, y = ll2xy(cam, lo, la)
        for ph in (0.0, 0.5):
            u = ((t * 0.9 + ph) % 1.0); r = 18 + 70 * u
            d.ellipse((x - r, y - r, x + r, y + r), outline=(255, 59, 48, int(220 * a * (1 - u))), width=5)
        d.ellipse((x - 16, y - 16, x + 16, y + 16), fill=(255, 59, 48, int(240 * a)))
    canvas.alpha_composite(ov)
    for n, lo, la, s, a in pts:
        if n and a > 0:
            x, y = ll2xy(cam, lo, la); fs = 54; fw = font("db", fs).getlength(n)
            cx = x + s * (fw / 2 + 40); cx = min(max(cx, fw / 2 + 60), W - fw / 2 - 60)
            text(canvas, t, n, y - 6, fs, T_TERR, T_OCT - 0.2, color="#FFFFFF", alpha=a, cx=cx)

# ------------------------------------------------------------------ vignette, emoji flags, photo
_v = np.zeros((H, W), np.float32); yy = np.arange(H)[:, None]
_v += np.clip((900 - yy) / 900, 0, 1) ** 1.3 * 0.82 + np.clip((yy - 1330) / 590, 0, 1) ** 1.2 * 0.85
VIG = Image.fromarray(np.dstack([np.zeros((H, W, 3), np.uint8), (_v.clip(0, 1) * 255).astype(np.uint8)]), "RGBA")
EMO = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf", 109)
_ef = {}
def emoji(e, size):
    if (e, size) not in _ef:
        im = Image.new("RGBA", (160, 128), (0, 0, 0, 0)); ImageDraw.Draw(im).text((0, 0), e, font=EMO, embedded_color=True)
        im = im.crop(im.getbbox()); _ef[(e, size)] = im.resize((int(im.width * size / im.height), size), Image.LANCZOS)
    return _ef[(e, size)]
def put_emoji(canvas, e, x, y, size, a):
    if a <= 0.004: return
    im = emoji(e, size).copy(); im.putalpha(Image.fromarray((np.asarray(im)[:, :, 3] * a).astype(np.uint8)))
    canvas.alpha_composite(im, (int(x), int(y - size / 2)))
PH = Image.open(f"{D}/photos/sinai.jpg").convert("RGB")
def photo_panel(canvas, t, t0, t1, box_=(90, 250, 990, 760)):
    a = seg(t, t0, t0 + 0.4) * (1 - seg(t, t1 - 0.3, t1))
    if a <= 0.004: return
    x0, y0, x1, y1 = box_; bw, bh = x1 - x0, y1 - y0; z = 1.0 + 0.08 * min(1, (t - t0) / max(0.1, t1 - t0))
    iw, ih = PH.size; sc = max(bw / iw, bh / ih) * z; cw, ch = bw / sc, bh / sc; cx, cy = iw * 0.5, ih * 0.40
    crop = PH.crop((int(cx - cw / 2), int(max(0, cy - ch / 2)), int(cx + cw / 2), int(max(0, cy - ch / 2) + ch))).resize((bw, bh), Image.LANCZOS)
    m = Image.new("L", (bw, bh), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, bw - 1, bh - 1), 36, fill=int(255 * a))
    lay = crop.convert("RGBA"); lay.putalpha(m); canvas.alpha_composite(lay, (x0, y0))

# ------------------------------------------------------------------ top cards
def legend_rows(im, t):
    """L1 rows: flag, name, peak area; L2: rows glide into speed order and become bars"""
    if t < FILL_T[0] - 0.1 or t > R0 + 0.1: return
    out = 1 - seg(t, R0 - 0.35, R0 - 0.05)
    text(im, t, "THE LAND THEY TOOK", 300, 88, T_LAND, T_SPEED - 0.1, ain=0.25, alpha=out)
    text(im, t, "KM² TAKEN PER YEAR", 300, 88, T_SPEED, T_REAL - 0.12, ain=0.25, aout=0.12)
    order_area = [e[0] for e in EMPS]; order_speed = [k for k, _ in sorted(SPEED_AT.items(), key=lambda x: -EI[x[0]][6])]
    u = seg(t, T_SPEED - 0.1, T_SPEED + 0.5)
    for i, e in enumerate(EMPS):
        k, name, fl, col, area, py, spd, fy = e
        a = seg(t, FILL_T[i], FILL_T[i] + 0.3) * out
        if a <= 0.004: continue
        y = lerp(410 + 96 * order_area.index(k), 410 + 96 * order_speed.index(k), u)
        put_emoji(im, fl, 92, y, 58, a)
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
        cc = tuple(int(v) for v in hx(col)); d.rounded_rectangle((176, y - 9, 196, y + 11), 6, fill=cc + (int(255 * a),))
        im.alpha_composite(ov)
        text(im, t, name, y, 60, FILL_T[i], 1e9, fk="dsb", cx=210 + font("dsb", 60).getlength(name) / 2, alpha=a)
        # area (L1) -> speed bar (L2)
        aa = a * (1 - u)
        if aa > 0.004:
            s = f"{area:g}M km²"; text(im, t, s, y, 62, FILL_T[i], 1e9, fk="db", color=YELLOW, cx=990 - font("db", 62).getlength(s) / 2, alpha=aa)
        ts = SPEED_AT[k]; bu = seg(t, ts - 0.1, ts + 0.6); ba = a * u
        if ba > 0.004:
            bw = 250 * spd / 150000 * bu
            ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
            d.rounded_rectangle((470, y - 20, 470 + max(6, bw), y + 20), 12, fill=cc + (int(235 * ba),)); im.alpha_composite(ov)
            if bu > 0.05:
                s = f"{int(round(spd * bu, -3)):,}"; text(im, t, s, y, 62, ts, 1e9, fk="db", color=YELLOW, cx=990 - font("db", 62).getlength(f"{spd:,}") / 2, alpha=ba * seg(t, ts, ts + 0.2))
def israel_bars(im, t):
    a = seg(t, T_170, T_170 + 0.35) * (1 - seg(t, T_STOP - 0.25, T_STOP + 0.05))
    if a <= 0.004: return
    text(im, t, "KM² TAKEN PER YEAR", 300, 88, T_170, T_STOP - 0.1, ain=0.25, alpha=1)
    rows = [("🇯🇵", "Japan", 150000, "#5EE6D0", T_170), ("🇬🇧", "Britain", 105000, "#FF453A", T_170 + 0.15), ("🇮🇱", "Israel", 170, ILG, T_170v)]
    for i, (fl, name, v, col, ts) in enumerate(rows):
        y = 430 + 110 * i; ra = a * seg(t, ts, ts + 0.3)
        if ra <= 0.004: continue
        put_emoji(im, fl, 92, y, 58, ra)
        text(im, t, name, y, 60, ts, 1e9, fk="dsb", cx=180 + font("dsb", 60).getlength(name) / 2, alpha=ra)
        bu = seg(t, ts, ts + 0.6); bw = 250 * v / 150000 * bu
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov); cc = tuple(int(x) for x in hx(col))
        d.rounded_rectangle((440, y - 22, 440 + max(6, bw), y + 22), 12, fill=cc + (int(240 * ra),)); im.alpha_composite(ov)
        s = f"~{v:,}" if name == "Israel" else f"{v:,}"
        text(im, t, s, y, 64, ts, 1e9, fk="db", color=YELLOW, cx=990 - font("db", 64).getlength(s) / 2, alpha=ra)
def label_at(im, t, cam, s, lon, lat, t0, t1, size=50, dx=0, color="#FFFFFF"):
    x, y = ll2xy(cam, lon, lat); text(im, t, s, y, size, t0, t1, fk="db", color=color, cx=x + dx, ain=0.25)

# ------------------------------------------------------------------ subtitles (Heebo ExtraBold 54 on a dark rounded box)
SUBF = ImageFont.truetype("/root/.fonts/Heebo-ExtraBold.ttf", 54)
REPL = [("a hundred and fifty thousand square kilometers", "150,000 km²"), ("a hundred and twenty thousand", "120,000"), ("a hundred and five", "105,000"),
        ("fifty seven", "57,000"), ("forty two", "42,000"), ("nineteen sixty seven", "1967"), ("two thousand five", "2005"),
        ("nineteen forty eight", "1948"), ("a hundred and seventy", "170"), ("October seventh", "October 7"), ("HAMAS", "HAMAS"), ("five", "5")]
def toks(li):
    ws = LW[li]; out = []; i = 0
    while i < len(ws):
        hit = None
        for sp, disp in REPL:
            n = len(sp.split())
            seq = " ".join(re.sub(r"[^\w']", "", w["w"]) for w in ws[i:i + n])
            if seq.lower() == sp.lower():
                tail = re.sub(r"[\w']", "", ws[i + n - 1]["w"]); hit = (disp + tail, ws[i]["t0"], ws[i + n - 1]["t1"], n); break
        if hit: out.append(hit[:3]); i += hit[3]
        else: out.append((ws[i]["w"], ws[i]["t0"], ws[i]["t1"])); i += 1
    return out
SUBS = []
for li in sorted(LW):
    cur = []
    tk = toks(li)
    for j, tok in enumerate(tk):
        cur.append(tok)
        if re.search(r"[.,?:!]$", tok[0]) or len(cur) >= 6 or j == len(tk) - 1:
            if len(cur) == 1 and SUBS and SUBS[-1][3] == li and len(SUBS[-1][2].split()) < 4 and not SUBS[-1][2].endswith((".", "?")):
                a, b, s, l_ = SUBS.pop(); SUBS.append((a, cur[-1][2], s + " " + cur[0][0], li))
            else:
                SUBS.append((cur[0][1], cur[-1][2], " ".join(x[0] for x in cur), li))
            cur = []
SUBS = [(a - 0.05, b + 0.25, s.rstrip(",:").replace("...", "..."), li) for a, b, s, li in SUBS]
SUBS = [(a, min(b, SUBS[i + 1][0] - 0.02) if i + 1 < len(SUBS) else b, s, li) for i, (a, b, s, li) in enumerate(SUBS)]
SUB_Y = 1392
def subtitles(canvas, t):
    for a, b, s, li in SUBS:
        if a <= t < b:
            al = min(1, (t - a) / 0.08, (b - t) / 0.08)
            words = s.split(); lines = [[]]
            for w_ in words:
                if SUBF.getlength(" ".join(lines[-1] + [w_])) <= 900 or not lines[-1]: lines[-1].append(w_)
                else: lines.append([w_])
            lines = [" ".join(l) for l in lines]; lh = 70; tw = max(SUBF.getlength(l) for l in lines)
            h = lh * len(lines) + 30; y0 = SUB_Y - h / 2
            lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            d.rounded_rectangle((540 - tw / 2 - 30, y0, 540 + tw / 2 + 30, y0 + h), 26, fill=(10, 16, 30, int(200 * al)))
            for i, l in enumerate(lines): d.text((540, y0 + 15 + lh * i + lh / 2), l, font=SUBF, fill=(255, 255, 255, int(255 * al)), anchor="mm")
            canvas.alpha_composite(lay); return

# ------------------------------------------------------------------ sources (38 px)
SRCF = font("r", 38)
SOURCES = [
 (0, ["Peak areas: Taagepera 1997; Japan: James 2010", "Map: NASA Blue Marble. Borders approx."]),
 (T_SPEED, ["Speed = (peak area minus home country) ÷ years", "GB 1583 to 1920, RU 1547 to 1895, ES 1492 to 1810"]),
 (SPEED_AT["russia"] - 1.2, ["Speed = (peak area minus home country) ÷ years", "FR 1830 to 1920, JP 1895 to 1942. Rounded"]),
 (R0 - 0.3, ["Replay: each piece shown from the year it was", "taken, peak extents on modern borders (approx.)"]),
 (T_ISR + 0.6, ["1967: Sinai ~60,000, West Bank 5,655, Gaza 365,", "Golan ~1,200 km² (CIA World Factbook, Britannica)"]),
 (T_SIN, ["Sinai returned under the 1979 treaty, by 1982.", "Gaza: disengagement completed Sep 2005"]),
 (T_170, ["~13,000 km² net since 1948 (UN 1947 plan ~15,000", "to ~28,000 incl. West Bank, Golan) ÷ 78 years"]),
 (T_STOP, ["1967: the armies of Egypt, Jordan and Syria", "were defeated in six days (Britannica)"]),
 (T_TERR, ["US State Dept: Foreign Terrorist Organizations;", "Iran: State Sponsor of Terrorism"]),
 (T_OCT, ["7 Oct 2023: ~1,200 killed, 251 hostages", "Israeli government figures; UN 2024"]),
 (T_PEACE, ["Photo: Begin, Carter, Sadat 1978, public domain", "Abraham Accords 2020 (UAE, Bahrain, Morocco)"]),
 (T_END1, None)]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        if not lines: continue
        t1 = SOURCES[i + 1][0]; a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.3)) * (1 - seg(t, t1 - 0.2, t1))
        if t >= t0 - 0.01 and a > 0.004:
            lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            for j, l in enumerate(lines): d.text((540, 1488 + j * 44), l, font=SRCF, fill=(205, 210, 220, int(255 * a)), anchor="mm")
            canvas.alpha_composite(lay)

# ------------------------------------------------------------------ follow cue (visual only, chevron in a sky circle)
def follow_cue(canvas, t):
    a = seg(t, T_LEAD + 0.1, T_LEAD + 0.45) * (1 - seg(t, T_END - LOOP - 0.15, T_END - LOOP + 0.05))
    if a <= 0.004: return
    s = "Follow for part 2"; fs = 60; tw = font("dsb", fs).getlength(s); r = 38; gap = 22; tot = 2 * r + gap + tw
    x0 = 540 - tot / 2; y = 1250; sc = 0.94 + 0.06 * seg(t, T_LEAD + 0.1, T_LEAD + 0.45)
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    d.rounded_rectangle((x0 - 26, y - r - 16, x0 + tot + 34, y + r + 16), 60, fill=(10, 16, 30, int(190 * a)), outline=(255, 255, 255, int(70 * a)), width=2)
    cx = x0 + r; bob = 5 * math.sin((t - T_LEAD) * 6)
    d.ellipse((cx - r, y - r, cx + r, y + r), fill=(0x45, 0xA4, 0xDD, int(255 * a)))
    d.line([(cx - 15, y - 6 + bob), (cx, y + 9 + bob), (cx + 15, y - 6 + bob)], fill=(255, 255, 255, int(255 * a)), width=7, joint="curve")
    for px, py in ((cx - 15, y - 6 + bob), (cx, y + 9 + bob), (cx + 15, y - 6 + bob)): d.ellipse((px - 3.5, py - 3.5, px + 3.5, py + 3.5), fill=(255, 255, 255, int(255 * a)))
    canvas.alpha_composite(ov)
    text(canvas, t, s, y, fs, T_LEAD + 0.1, 1e9, fk="dsb", cx=x0 + 2 * r + gap + tw / 2, alpha=a * (1 - seg(t, T_END - LOOP - 0.15, T_END - LOOP + 0.05)), zoom=sc)

# ------------------------------------------------------------------ frame
HOOK = ("5 EMPIRES.", "RANKED BY SPEED.")
HS = min(fit(HOOK[0], "db", 140, 960), fit(HOOK[1], "db", 140, 960)); HY = (330, 330 + HS * 1.12)
ENDL = ("SO NEXT TIME", "SOMEONE SAYS...")
_g = np.linspace(0, 1, H)[:, None, None]; _c0, _c1 = hx("#0B1730"), hx("#14284F")
GRAD = Image.fromarray(np.broadcast_to(_c0 * (1 - _g) + _c1 * _g, (H, W, 3)).astype(np.uint8), "RGB").convert("RGBA")
BMA = BM.convert("RGBA")
def bg(cam):
    kx = cam.k * cam.cosf; a = IW / 360 / kx; c = (cam.lon + 180) * IW / 360 - 540 * a
    e = IH / 180 / cam.k; f = (90 - cam.lat) * IH / 180 - cam.cy * e
    im = GRAD.copy(); im.alpha_composite(BMA.transform((W, H), Image.AFFINE, (a, 0, c, 0, e, f), Image.BILINEAR, fillcolor=(0, 0, 0, 0))); return im
def frame_raw(t):
    cam = camera(t); im = bg(cam); map_layer(im, t, cam); pulses(im, t, cam); im.alpha_composite(VIG)
    # hook (frame 0) and the lead-in in the same place
    text(im, t, HOOK[0], HY[0], HS, 0, T_LAND - 0.1, inst=True, zoom=1 + 0.03 * seg(t, 0, T_LAND), color=YELLOW)
    text(im, t, HOOK[1], HY[1], HS, 0, T_LAND - 0.1, inst=True, zoom=1 + 0.03 * seg(t, 0, T_LAND))
    if t < T_LAND:   # gold underline sweep: motion by 1.5 s
        u = seg(t, 0.15, 1.3); ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov); yl = HY[1] + HS * 0.72
        d.rounded_rectangle((540 - 380 * u, yl, 540 + 380 * u, yl + 12), 6, fill=(255, 214, 10, int(255 * (1 - seg(t, T_LAND - 0.3, T_LAND))))); im.alpha_composite(ov)
    text(im, t, ENDL[0], HY[0], HS, T_LEAD, 1e9, ain=0.35, color=YELLOW)
    text(im, t, ENDL[1], HY[1], HS, T_LEAD + 0.08, 1e9, ain=0.35)
    legend_rows(im, t)
    # real speed
    yr = year_at(t)
    if yr is not None and t < T_ISR:
        a = seg(t, R0 - 0.1, R0 + 0.2) * (1 - seg(t, T_ISR - 0.2, T_ISR + 0.1))
        text(im, t, "AT REAL SPEED", 300, 88, R0 - 0.2, T_ISR - 0.1, ain=0.25, alpha=1)
        text(im, t, str(int(yr)), 520, 220, R0 - 0.1, T_ISR - 0.1, fk="db", color=YELLOW, ain=0.2, alpha=a)
        text(im, t, "450 years in 3 seconds", 690, 60, R0 + 0.1, T_ISR - 0.1, fk="dsb", color=LGREY, ain=0.25, alpha=a)
    if T_REAL - 0.05 <= t < R0:
        text(im, t, "AT REAL SPEED", 300, 88, T_REAL + 0.02, 1e9, ain=0.25)
    # Israel
    text(im, t, "AND ISRAEL?", 330, 130, T_ISR, SW(4, "In") - 0.1, ain=0.3)
    text(im, t, "ISRAEL, 1967", 300, 110, SW(4, "In") - 0.05, T_SIN - 0.1, ain=0.25)
    rich(im, t, [("Took ", WHITE), ("~67,000 km²", YELLOW)], 420, 72, TK["sinai"], T_SIN - 0.1, fk="db", ain=0.25)
    text(im, t, "About 3x its own size", 510, 60, TK["golan"], T_SIN - 0.1, fk="dsb", color=LGREY, ain=0.25)
    cam = camera(t)
    for key, s, lo, la, dx in (("sinai", "Sinai", 33.5, 30.75, 0), ("gaza", "Gaza", 34.35, 31.45, -110), ("wb", "West Bank", 35.3, 32.0, 190), ("golan", "Golan", 35.8, 33.05, 120)):
        label_at(im, t, cam, s, lo, la, TK[key], T_SIN - 0.1, 50, dx)
    text(im, t, "SINAI: GIVEN BACK", 300, 100, T_SIN, T_GAZ - 0.05, ain=0.25)
    text(im, t, "For peace with Egypt. 1982.", 410, 62, T_BACK, T_GAZ - 0.05, fk="dsb", color=YELLOW, ain=0.25)
    text(im, t, "GAZA: LEFT IN 2005", 300, 100, T_GAZ, T_170 - 0.1, ain=0.25)
    text(im, t, "Every soldier, every settler.", 410, 62, T_LEFT, T_170 - 0.1, fk="dsb", color=YELLOW, ain=0.25)
    label_at(im, t, cam, "Returned", 33.5, 30.75, T_BACK + 0.3, T_170 - 0.1, 50)
    israel_bars(im, t)
    text(im, t, "THEN IT STOPPED.", 300, 112, T_STOP, T_ASK - 0.1, ain=0.25)
    text(im, t, "Even with weak neighbors.", 410, 64, SW(7, "even"), T_ASK - 0.1, fk="dsb", color=LGREY, ain=0.25)
    text(im, t, "Why so little?", 560, 104, T_WHY1, T_ASK - 0.1, fk="db", color=YELLOW, ain=0.25)
    text(im, t, "Why stop?", 690, 104, T_WHY2, T_ASK - 0.1, fk="db", color=YELLOW, ain=0.25)
    text(im, t, "Ask that first.", 420, 120, T_ASK, T_TERR - 0.1, ain=0.25)
    text(im, t, "A DANGEROUS PLACE", 300, 100, T_TERR, T_OCT - 0.1, ain=0.25)
    text(im, t, "Israel is holding land here.", 410, 60, T_TERR + 0.2, T_OCT - 0.1, fk="dsb", color=LGREY, ain=0.25)
    rich(im, t, [("A ", WHITE), ("petri dish", "#FF453A"), (" of terror.", WHITE)], 520, 84, T_PETRI, T_OCT - 0.1, fk="db", ain=0.25)
    text(im, t, "7 OCTOBER 2023", 300, 110, T_OCT, T_PEACE - 0.1, ain=0.25)
    rich(im, t, [("HAMAS", "#FF453A"), (" came from Gaza.", WHITE)], 420, 74, SW(10, "Hamas"), T_PEACE - 0.1, fk="db", ain=0.25)
    text(im, t, "~1,200 murdered. 251 taken hostage.", 520, 58, SW(10, "came"), T_PEACE - 0.1, fk="dsb", color=YELLOW, ain=0.25)
    text(im, t, "The land Israel left.", 610, 60, T_LEFT2, T_PEACE - 0.1, fk="dsb", color=LGREY, ain=0.25)
    photo_panel(im, t, T_PEACE, T_END1 + 0.05, (110, 250, 970, 760))
    text(im, t, "Still looking for peace", 840, 80, T_PEACE + 0.15, T_END1 - 0.05, fk="db", ain=0.25)
    text(im, t, "Egypt 1979. Jordan 1994. 2020 Accords.", 940, 56, T_PEACE + 0.5, T_END1 - 0.05, fk="dsb", color=YELLOW, ain=0.25)
    text(im, t, "Not colonizing.", 420, 120, T_END1, T_LEAD - 0.1, ain=0.3)
    rich(im, t, [("More like ", WHITE), ("babysitting.", YELLOW)], 580, 96, T_BABY, T_LEAD - 0.1, fk="db", ain=0.3)
    follow_cue(im, t)
    sources(im, t); subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS)); return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s, _ in SUBS] + [l for _, v in SOURCES if v for l in v] + list(HOOK) + list(ENDL)
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam", s, re.I) for s in _txt)
assert len(HOOK[0].split() + HOOK[1].split()) <= 6
for _, v in SOURCES:
    for l in (v or []): assert SRCF.getlength(l) <= 940, ("source too wide", l)
N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
