"""rlib.py: text, camera and Blue Marble helpers, copied from empires_israel/reel2.py (same house look)."""
import math, numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
D = "/home/claude/colonizer_speed_v4"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
W, H, FPS = 1080, 1920, 30
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
WHITE, GREY, GOLD, RED = "#FFFFFF", "#B9B9BE", "#F2C94C", "#FF3B30"
ISR_SHADE = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
# ------------------------------------------------------------------ text (2x masks, sub-pixel, scale + blur-in), from engine_v3
FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium", r="Inter-Regular").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=1000):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size
_rc = {}
def raster(s, fk, size):
    key = (s, fk, size)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
    ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 600: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur, shadow=True):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 14; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = np.asarray(m, np.float32)
    lays = []
    if shadow:   # soft dark halo so white type reads over the map
        sh = np.asarray(m.filter(ImageFilter.GaussianBlur(7)), np.float32) * 0.85 * alpha
        l0 = Image.new("RGBA", (cw, ch), (0, 0, 0, 0)); l0.putalpha(Image.fromarray(sh.clip(0, 255).astype(np.uint8), "L")); lays.append(l0)
    l1 = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); l1.putalpha(Image.fromarray((a * alpha).clip(0, 255).astype(np.uint8), "L")); lays.append(l1)
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0:
        for lay in lays: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
T_IN, T_OUT = 0.32, 0.22
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.9 + 0.1 * u) * (1 + 0.03 * v), 8 * (1 - u) + 6 * v, 0
def text(canvas, t, s, y, size, t0, t1, fk="db", color=WHITE, inst=False, zoom=1.0, ain=T_IN, aout=T_OUT, cx=540, alpha=1.0):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    size = fit(s, fk, size, 960)
    info = raster(s, fk, size); put(canvas, info, cx, y + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)
def rich(canvas, t, parts, y, size, t0, t1, fk="dsb", ain=T_IN, aout=T_OUT):
    """one centred line of differently coloured pieces: parts = [(text, colour), ...]"""
    f = font(fk, size); ws = [f.getlength(p) for p, _ in parts]; x = 540 - sum(ws) / 2
    for (p, c), w_ in zip(parts, ws):
        text(canvas, t, p, y, size, t0, t1, fk=fk, color=c, ain=ain, aout=aout, cx=x + w_ / 2); x += w_

# ------------------------------------------------------------------ background: NASA Blue Marble, darkened
_bm = Image.open(f"{D}/photos/world.jpg").convert("RGB")
_bm = ImageEnhance.Color(_bm).enhance(0.62); _bm = ImageEnhance.Brightness(_bm).enhance(0.46); _bm = ImageEnhance.Contrast(_bm).enhance(1.12)
BM = _bm; IW, IH = BM.size
class Cam:
    def __init__(s, lon, lat, k, cy=1000): s.lon, s.lat, s.k, s.cy = lon, lat, k, cy
    @property
    def cosf(s): return max(0.6, math.cos(math.radians(min(62, abs(s.lat)))))
def cam_lerp(a, b, u):
    return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.k), math.log(b.k), u)), lerp(a.cy, b.cy, u))
def camw(lon, lat, width_deg, cy=1000):
    c = Cam(lon, lat, 1, cy); return Cam(lon, lat, W / (width_deg * c.cosf), cy)
def background(cam):
    kx = cam.k * cam.cosf; a = IW / 360 / kx; c = (cam.lon + 180) * IW / 360 - 540 * a
    e = IH / 180 / cam.k; f = (90 - cam.lat) * IH / 180 - cam.cy * e
    return BM.transform((W, H), Image.AFFINE, (a, 0, c, 0, e, f), Image.BILINEAR).convert("RGBA")
def ll2xy(cam, lon, lat): return 540 + (lon - cam.lon) * cam.k * cam.cosf, cam.cy - (lat - cam.lat) * cam.k

