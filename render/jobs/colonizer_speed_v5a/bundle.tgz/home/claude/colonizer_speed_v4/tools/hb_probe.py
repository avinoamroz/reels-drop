import json,sys,re
from shapely.geometry import shape
from shapely.ops import transform
import numpy as np
def area(g): return abs(transform(lambda x,y,z=None:(x*111.32*np.cos(np.radians(y)),y*110.57),g).area)
f=sys.argv[1]; pat=re.compile(sys.argv[2],re.I)
d=json.load(open(f)); rows=[]
for ft in d['features']:
    p=ft['properties']; s=f"{p.get('NAME')} | {p.get('SUBJECTO')} | {p.get('PARTOF')}"
    if ft['geometry'] is None: continue
    try: a=area(shape(ft['geometry']).buffer(0))
    except Exception as e: a=-1
    rows.append((a,s))
rows.sort(reverse=True)
tot=0
for a,s in rows:
    if pat.search(s): tot+=a; print(f"{a/1e6:7.2f}M  {s}")
print("TOTAL match", round(tot/1e6,2),"M")
