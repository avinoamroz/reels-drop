"""geo_prep.py -> geo/geo.json for colonizer_speed_v4.
Empire extents at their peak (Britain 1920, Russia 1895, Spain 1810, France 1920, Japan 1942) drawn on MODERN Natural Earth
1:50m borders (public domain), one piece per modern country (or part of one), each with the approximate year it came under
that empire's rule, so the 'real speed' replay can grow each empire over time. Partial countries are clipped with simple
boxes (Japan in China, Spain in the US, Russia's Siberia split by longitude so it spreads east). Areas are printed against
the peak figures used on screen (Taagepera 1997 via Wikipedia; Japan: James 2010)."""
import json, os, numpy as np
from shapely.geometry import shape, mapping, Polygon, box
from shapely.ops import unary_union
D = "/home/claude/colonizer_speed_v4"
def area(g):
    import shapely
    return shapely.transform(g, lambda a: np.c_[a[:, 0] * 111.32 * np.cos(np.radians(a[:, 1])), a[:, 1] * 110.57]).area
NE = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
ne = {f["properties"]["ADM0_A3"]: shape(f["geometry"]).buffer(0) for f in NE["features"]}
DIS = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_breakaway_disputed_areas.geojson"))
golan = unary_union([shape(f["geometry"]).buffer(0) for f in DIS["features"] if "Golan" in json.dumps(f["properties"])])
P = lambda pts: Polygon(pts)
CHN = ne["CHN"]; RUS = ne["RUS"]; USA = ne["USA"]
manchuria = CHN.intersection(P([(115.5, 41), (119, 39.3), (121.5, 38.6), (125, 39.8), (131, 42.5), (135.2, 48.5), (127, 53.8), (120, 53.5), (115.5, 47)]))
eastchina = CHN.intersection(P([(109.5, 40.8), (115.5, 41), (119, 39.3), (121.5, 38.6), (123, 30), (122, 25), (117, 23), (114, 22), (108.5, 21.5), (111, 27), (112.5, 30.5), (110.5, 34.5)]))
sakh = RUS.intersection(box(141, 45.5, 145, 50))
sw_us = USA.intersection(P([(-124.6, 42), (-111, 42), (-104, 38), (-94, 33.5), (-93.8, 29.5), (-97.5, 25.8), (-117.1, 32.5), (-124.6, 40)]))
florida = USA.intersection(box(-87.6, 24.5, -80, 31))
rus_core = RUS.difference(sakh)
def band(g, x0, x1, y0=-90, y1=90): return g.intersection(box(x0, y0, x1, y1))
amur = rus_core.intersection(P([(127, 53.3), (131, 47.5), (135, 48.3), (131, 42.5), (138, 42), (141.5, 49), (141.5, 53.5)]))
rus_rest = rus_core.difference(amur)
SIB = [(band(rus_rest, -180, 50), 1556), (band(rus_rest, 50, 62), 1582), (band(rus_rest, 62, 80), 1600), (band(rus_rest, 80, 100), 1620),
       (band(rus_rest, 100, 120), 1632), (band(rus_rest, 120, 145), 1645), (band(rus_rest, 145, 180), 1700), (amur, 1860)]
kaz_n = band(ne["KAZ"], 40, 90, 48, 60); kaz_s = ne["KAZ"].difference(kaz_n)
poland = ne["POL"].intersection(box(18.5, 49.5, 24.5, 55))
EMP = {
 "spain": [("ESP", 1492), ("DOM", 1496), ("PRI", 1508), ("CUB", 1511), ("PAN", 1513), ("MEX", 1521), ("GTM", 1524), ("HND", 1524), ("SLV", 1525),
           ("NIC", 1524), ("CRI", 1561), ("VEN", 1527), ("PER", 1533), ("ECU", 1534), ("COL", 1538), ("BOL", 1538), ("PRY", 1537), ("CHL", 1541),
           (florida, 1565), ("PHL", 1565), ("ARG", 1580), (sw_us, 1598), ("URY", 1726), ("BLZ", 1600), ("GNQ", 1778)],
 "russia": SIB + [("UKR", 1654), ("EST", 1721), ("LVA", 1721), (kaz_n, 1731), ("BLR", 1795), ("LTU", 1795), ("GEO", 1801), ("FIN", 1809),
           ("MDA", 1812), ("AZE", 1813), (poland, 1815), ("ARM", 1828), (kaz_s, 1847), ("UZB", 1868), ("TJK", 1868), ("KGZ", 1876), ("TKM", 1881)],
 "britain": [("GBR", 1583), ("IRL", 1603), ("JAM", 1655), ("BHS", 1718), ("CAN", 1763), ("BGD", 1757), ("AUS", 1788), ("LKA", 1796), ("MLT", 1800),
           ("IND", 1803), ("ZAF", 1806), ("SLE", 1808), ("GUY", 1814), ("GMB", 1816), ("SGP", 1819), ("NZL", 1840), ("PAK", 1849), ("BLZ", 1862),
           ("LSO", 1868), ("MYS", 1874), ("GHA", 1874), ("FJI", 1874), ("CYP", 1878), ("EGY", 1882), ("BWA", 1885), ("MMR", 1885), ("NGA", 1885),
           ("PNG", 1888), ("BRN", 1888), ("SOL", 1888), ("ZWE", 1890), ("ZMB", 1891), ("MWI", 1891), ("UGA", 1894), ("KEN", 1895), ("SDN", 1899), ("SDS", 1899),
           ("KWT", 1899), ("SWZ", 1903), ("QAT", 1916), ("ARE", 1892), ("BHR", 1892), ("NAM", 1915), ("TZA", 1919), ("IRQ", 1920),
           ("JOR", 1920), ("ISR", 1920), ("PSX", 1920)],
 "france": [("FRA", 1830), ("DZA", 1830), ("SEN", 1854), ("NCL", 1853), ("VNM", 1862), ("KHM", 1863), ("GAB", 1880), ("COG", 1880),
           ("TUN", 1881), ("DJI", 1884), ("LAO", 1893), ("GIN", 1891), ("MLI", 1892), ("CIV", 1893), ("BEN", 1894), ("MDG", 1896), ("BFA", 1896),
           ("TCD", 1900), ("NER", 1900), ("CAF", 1903), ("MRT", 1903), ("MAR", 1912), ("CMR", 1916), ("TGO", 1916), ("SYR", 1920), ("LBN", 1920)],
 "japan": [("JPN", 1895), ("TWN", 1895), (sakh, 1905), ("KOR", 1910), ("PRK", 1910), (manchuria, 1931), (eastchina, 1937), ("VNM", 1940),
           ("LAO", 1941), ("KHM", 1941), ("PHL", 1942), ("MYS", 1942), ("SGP", 1942), ("BRN", 1942), ("IDN", 1942), ("TLS", 1942), ("MMR", 1942)],
}
HOME = {"spain": "ESP", "russia": None, "britain": "GBR", "france": "FRA", "japan": "JPN"}
def ser(g, tol): return mapping(g.simplify(tol, preserve_topology=True))
out_emp = {}
for k, items in EMP.items():
    pieces = []; tot = 0
    for g, y in items:
        if isinstance(g, str): g = ne[g]
        if g.is_empty: continue
        tot += area(g); pieces.append(dict(year=y, geom=ser(g, 0.06)))
    out_emp[k] = pieces; print(f"{k:8s} {tot / 1e6:6.2f} M km2, {len(pieces)} pieces")
world = {k: ser(g, 0.08) for k, g in ne.items() if k != "ATA"}
lev = box(18, 10, 58, 44)
local = {k: ser(g.intersection(lev), 0.004) for k, g in ne.items() if g.intersects(lev) and k not in ("ISR", "PSX")}
cut = Polygon([(32.30, 31.8), (32.33, 30.10), (32.58, 29.93), (33.05, 29.0), (33.75, 27.85), (34.25, 27.60), (35.5, 27.5), (35.5, 31.8)])
sinai = ne["EGY"].intersection(cut)
psx = ne["PSX"]; gaza = [p for p in psx.geoms if p.centroid.x < 34.6][0]; wb = [p for p in psx.geoms if p.centroid.x > 34.6][0]
isr49 = ne["ISR"].difference(golan)
print("ISR49", round(area(isr49)), "WB", round(area(wb)), "Gaza", round(area(gaza)), "Golan", round(area(golan)), "Sinai", round(area(sinai)))
out = dict(world=world, local=local, empires=out_emp, isr49=ser(isr49, 0.002), wb=ser(wb, 0.002), gaza=ser(gaza, 0.001), golan=ser(golan, 0.002),
           sinai=ser(sinai, 0.004), egy=ser(ne["EGY"].intersection(lev), 0.004))
os.makedirs(f"{D}/geo", exist_ok=True); json.dump(out, open(f"{D}/geo/geo.json", "w"))
print("geo.json", os.path.getsize(f"{D}/geo/geo.json") // 1024, "KB")
