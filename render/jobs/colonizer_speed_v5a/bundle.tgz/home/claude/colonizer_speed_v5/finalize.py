"""finalize.py: for v5a/b/c after the cloud render: probe mp4, raw URL status, pill check frame, payload to posting/queue/gh."""
import json, os, subprocess
REPO = "/home/claude/reels-drop"; Q = "/home/claude/posting/queue/gh"; D = "/home/claude/colonizer_speed_v5"
SC = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
for v in "abc":
    rid = f"colonizer_speed_v5{v}"; mp4 = f"{REPO}/{rid}.mp4"
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height", "-of", "json", mp4], capture_output=True, text=True).stdout)
    dur = float(pr["format"]["duration"]); st = [(s["codec_type"], s.get("width"), s.get("height")) for s in pr["streams"]]
    url = f"https://raw.githubusercontent.com/avinoamroz/reels-drop/main/{rid}.mp4"
    code = subprocess.run(["curl", "-s", "-o", "/dev/null", "-I", "-w", "%{http_code}", url], capture_output=True, text=True).stdout
    for t, n in ((0.0, "f0"), (dur - 1.4, "end")):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", mp4, "-frames:v", "1", "-vf", "scale=360:-1", f"{SC}/{rid}_{n}.png"])
    cap = open(f"{D}/caption/caption_{v}.txt").read().strip()
    body = {"media_type": "REELS", "video_url": url, "caption": cap, "share_to_feed": True, "is_ai_generated": True, "trial_params": {"graduation_strategy": "SS_PERFORMANCE"}}
    json.dump({"action": "init", "account": "noam", "tag": f"{rid}-gh", "body": json.dumps(body, ensure_ascii=False)}, open(f"{Q}/{rid}.json", "w"), ensure_ascii=False, indent=1)
    print(rid, f"{dur:.2f}s", st, "url", code, "preview", os.path.getsize(f"{REPO}/render/out/{rid}_540.mp4"))
