"""cloud step: python3 render.py <var>: silent video (reel.py --var) + work/<var>/mix.m4a -> colonizer_speed_v5<var>.mp4"""
import subprocess, os, json, sys
D = "/home/claude/colonizer_speed_v5"; V = sys.argv[1]; WD = f"{D}/work/{V}"; T = json.load(open(f"{WD}/audio.json"))["T_END"]
subprocess.run(["python3", f"{D}/reel.py", "--var", V, "--out", f"{WD}/silent.mp4"], check=True)
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", f"{WD}/silent.mp4", "-i", f"{WD}/mix.m4a", "-map", "0:v", "-map", "1:a",
                "-c", "copy", "-t", f"{T:.2f}", "-movflags", "+faststart", f"{D}/colonizer_speed_v5{V}.mp4"], check=True)
os.remove(f"{WD}/silent.mp4"); print("final", f"{D}/colonizer_speed_v5{V}.mp4")
