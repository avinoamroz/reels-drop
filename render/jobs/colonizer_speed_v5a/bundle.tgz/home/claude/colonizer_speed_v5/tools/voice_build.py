"""voice_build.py <var>: colonizer_speed_v5<var> narration (v4 clips + new hook clip h_<var> + re-voiced line 12 clip end). Based on v4 -> work/vo.wav (48 kHz, house chain) + work/words.json.
Seven Cartesia SSE clips (clips/c1..c7, voice cd06f613, sonic-3). Each script line is cut from its clip by the Cartesia word
timestamps, internal pauses over MAXG are squeezed, and lines are laid out with the reel-time gaps in GAP (room for the map
fills after line 1 and the real-speed replay after line 3). House chain from reelkit/voice.py at TEMPO 1.026, which is the
v3 pace (v1 ran at 1.08, v3 is 5% slower)."""
import json, re, sys, wave, os
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
V4 = "/home/claude/colonizer_speed_v4"; D = "/home/claude/colonizer_speed_v5"; VAR = sys.argv[1]; WD = f"{D}/work/{VAR}"; os.makedirs(WD, exist_ok=True); SR0 = 44100; TEMPO = 1.026; LEAD = 0.12; V.TEMPO = TEMPO; V.LEAD = LEAD
L = [l.strip() for l in open(f"{D}/tts_{VAR}.txt") if l.strip()]
L4 = [l.strip() for l in open(f"{V4}/tts.txt") if l.strip()]
# per line: (clip path, word offset in that clip). Line 0 = new hook clip, line 12 = re-voiced clip; the rest are v4 clips
CL4 = {"c1": [0, 1], "c2": [2], "c3": [3, 4], "c4": [5, 6], "c5": [7, 8, 9], "c6": [10, 11], "c7": [12, 13]}
SRC = {}
for c, lis in CL4.items():
    k = 0
    for li in lis: SRC[li] = (f"{V4}/clips/{c}", k); k += len(L4[li].split())
SRC[0] = (f"{D}/clips/h_{VAR}", 0); SRC[12] = (f"{D}/clips/end", 0)
GAP = {1: 1.45, 3: 3.0, 4: 0.4, 6: 0.42, 9: 0.34, 11: 0.42, 12: 0.34}
GAP[0] = {"a": 0.26, "b": 0.45, "c": 0.75}[VAR]  # a beat after the question / challenge
DEF_GAP = 0.26; MAXG = 0.24; TAIL = 0.95
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
PIECES = {}
for li in range(len(L)):
    cp, k = SRC[li]; a = load(f"{cp}.wav"); W = json.load(open(f"{cp}_words.json"))
    if True:
        sw = L[li].split(); ws = W[k:k + len(sw)]
        if li in (0, 12): assert len(ws) == len(W), (li, len(W))
        assert [norm(w["word"]) for w in ws] == [norm(x) for x in sw], (li, [w["word"] for w in ws])
        s0 = max(0, ws[0]["start"] - 0.05); e0 = min(len(a) / SR0, ws[-1]["end"] + (0.32 if li == len(L) - 1 else 0.10))
        keep = []; cur = s0
        for i in range(len(ws) - 1):
            g0, g1 = ws[i]["end"], ws[i + 1]["start"]
            if g1 - g0 > MAXG: ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
        keep.append((cur, e0))
        def mp(x):
            q = 0.0
            for k0, k1 in keep:
                if x <= k1: return q + max(0, x - k0)
                q += k1 - k0
            return q
        segs = []
        for k0, k1 in keep:
            sg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(sg) // 2, int(0.008 * SR0))
            if f: sg[:f] *= np.linspace(0, 1, f); sg[-f:] *= np.linspace(1, 0, f)
            segs.append(sg)
        PIECES[li] = (np.concatenate(segs), [(x, mp(w["start"]), mp(max(w["end"], w["start"] + 0.04))) for x, w in zip(sw, ws)])
dur = {li: len(p[0]) / SR0 / TEMPO for li, p in PIECES.items()}
starts = {}; t = LEAD
for li in range(len(L)): starts[li] = t; t += dur[li] + GAP.get(li, DEF_GAP)
T_END = round(starts[len(L) - 1] + dur[len(L) - 1] + TAIL, 3)
raw = np.zeros(int(T_END * TEMPO * SR0) + SR0, np.float32); words = []
for li, (y, ws) in PIECES.items():
    i0 = int((starts[li] - LEAD) * TEMPO * SR0); raw[i0:i0 + len(y)] += y
    for w, a_, b_ in ws: words.append(dict(li=li, w=w, t0=round(starts[li] + a_ / TEMPO, 3), t1=round(starts[li] + b_ / TEMPO, 3)))
sf.write(f"{WD}/raw.wav", raw, SR0)
dry = V.chain_dry(f"{WD}/raw.wav"); cl = V.clean_vo(dry, V.SR); y, _ = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y)[:int(T_END * V.SR)]; vo = np.pad(vo, (0, max(0, int(T_END * V.SR) - len(vo)))); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{WD}/vo.wav", vo.astype(np.float32), V.SR); os.remove(f"{WD}/raw.wav")
json.dump(dict(words=words, dur=T_END, starts=starts, tempo=TEMPO), open(f"{WD}/words.json", "w"), indent=0)
print("T_END", T_END)
for li in range(len(L)): print(li, round(starts[li], 2), round(dur[li], 2), L[li])
