"""muslims_freest_v2: transposed table (criteria = rows on the left, country flags = columns), big text, narration.
python3 engine.py [--frames t1,t2,...] [--out path.mp4]
Reads timing.json, flags/*.png, mix.m4a in this folder. 1080x1920, 30 fps."""
import json, os, re, sys, subprocess, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = "/home/claude/muslims_freest_v2/cloud"
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"
NAVY, NAVY2, PANEL, BLUE, GOLD, SILVER, WHITE = "#163260", "#0C1E3E", "#1D3E73", "#2A88D4", "#D2AA53", "#C9D1DC", "#FFFFFF"
GREEN, RED, AMBER, DRED = "#2FB36B", "#E0453A", "#F2B33D", "#A3142A"
_fc = {}
def F(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def hexa(c, a=255):
    c = c.lstrip("#"); return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), int(a))
def ease(x): x = min(1, max(0, x)); return 1 - (1 - x) ** 3
def back(x):
    x = min(1, max(0, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def clamp(x): return min(1, max(0, x))

# ------------------------------------------------------------------ timing
T = json.load(open(f"{D}/timing.json")); LINES = T["lines"]; VO_END = LINES[-1]["t1"]
END = round(VO_END + 0.55, 2)          # end card (held question frame) under 1 s
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]) == norm(word)]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]

# ------------------------------------------------------------------ data (from /home/claude/mena_rights/research.json, re-checked 30 Oct 2026)
CC = {"Israel": "il", "Turkey": "tr", "Lebanon": "lb", "Jordan": "jo", "Egypt": "eg", "Iraq": "iq", "Saudi Arabia": "sa", "Iran": "ir",
      "UAE": "ae", "Qatar": "qa", "Yemen": "ye"}
# rows: elect, run, free (FH 2026), gay sex legal, gay couples, leave religion, women travel without guardian
# V yes, ~ partly, X no, D death penalty in law, Y15 = 10 to 15 years prison
TAB = {
    "Israel":       ["V", "V", "V", "V", "V", "V", "V"],
    "Turkey":       ["V", "~", "X", "V", "X", "V", "V"],
    "Lebanon":      ["~", "~", "~", "~", "X", "V", "V"],
    "Jordan":       ["~", "V", "~", "V", "X", "~", "~"],
    "Egypt":        ["~", "X", "X", "X", "X", "~", "V"],
    "Iraq":         ["V", "~", "X", "Y15", "X", "~", "~"],
    "Saudi Arabia": ["X", "X", "X", "D", "X", "D", "~"],
    "Iran":         ["~", "X", "X", "D", "X", "D", "X"],
    "UAE":          ["~", "X", "X", "X", "X", "D", "V"],
    "Qatar":        ["X", "X", "X", "X", "X", "D", "X"],
    "Yemen":        ["X", "X", "X", "D", "X", "D", "X"],
}
SCORE = {c: sum(v == "V" for v in r) for c, r in TAB.items()}
assert SCORE == {"Israel": 7, "Turkey": 4, "Lebanon": 2, "Jordan": 2, "Egypt": 1, "Iraq": 1, "Saudi Arabia": 0, "Iran": 0, "UAE": 1, "Qatar": 0, "Yemen": 0}
LABELS = [("Vote for", "parliament"), ("Anyone", "can run"), ("Rated", "free"), ("Gay sex", "legal"), ("Gay couples", "recognised"),
          ("Can leave", "religion"), ("Women can", "travel alone")]
NAMES = {"Saudi Arabia": ("Saudi", "Arabia")}

# ------------------------------------------------------------------ layout
X0, LBLW = 60, 340
CX0, CW, NCOL = 400, 130, 4                 # columns 400..920, right 160 px clear
TITLE_Y = 196
FLAG_Y, FLAGW = 262, 118
NAME_Y = 372
RY0, RH, NR = 452, 128, 7                   # rows 452..1348
SC_Y = 1356                                  # score row 1356..1440
SRC_Y = 1458                                 # sources 1458..1536 (bottom 380 px clear from 1540)
def cx(j): return CX0 + CW * j + CW // 2
def ry(i): return RY0 + RH * i

# ------------------------------------------------------------------ assets
def load_flag(code, w):
    im = Image.open(f"{D}/flags/{code}.png").convert("RGBA"); h = round(im.height * w / im.width)
    return im.resize((w, h), Image.LANCZOS)
FLAG = {c: load_flag(k, FLAGW) for c, k in CC.items()}
FLAG_SB = {c: load_flag(k, 112) for c, k in CC.items()}
def qcard(w):
    h = round(w * 0.74); S = 4; im = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w * S - 1, h * S - 1), 14 * S, fill=hexa(GOLD)); im = im.resize((w, h), Image.LANCZOS); d = ImageDraw.Draw(im)
    d.text((w / 2, h / 2 + 2), "?", font=F(int(h * 0.8), 900), fill=hexa(NAVY), anchor="mm"); return im
QCARD = qcard(FLAGW)

_icon = {}
def icon(kind, scale=1.0):
    q = round(scale * 20) / 20; key = (kind, q)
    if key in _icon: return _icon[key]
    S = 4; R = 46; sz = int(150 * q) + 4
    im = Image.new("RGBA", (sz * S, sz * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = sz * S / 2; r = R * q * S
    if kind in ("D", "Y15"):
        bw, bh = 62 * q * S, 32 * q * S
        d.rounded_rectangle((c - bw, c - bh, c + bw, c + bh), 12 * q * S, fill=hexa(DRED), outline=hexa("#FF6B6B"), width=int(3 * q * S))
        im = im.resize((sz, sz), Image.LANCZOS); d = ImageDraw.Draw(im)
        if q > 0.3: d.text((sz / 2, sz / 2 + 1), "DEATH" if kind == "D" else "15 YRS", font=F(max(8, int(34 * q)), 900), fill=hexa(WHITE), anchor="mm")
        _icon[key] = im; return im
    col = {"V": GREEN, "X": RED, "~": AMBER}[kind]
    d.ellipse((c - r, c - r, c + r, c + r), fill=hexa(col))
    lw = int(9 * q * S)
    if kind == "V": d.line([(c - 0.42 * r, c + 0.02 * r), (c - 0.12 * r, c + 0.33 * r), (c + 0.45 * r, c - 0.33 * r)], fill=hexa(WHITE), width=lw, joint="curve")
    elif kind == "X":
        k = 0.34 * r; d.line([(c - k, c - k), (c + k, c + k)], fill=hexa(WHITE), width=lw); d.line([(c - k, c + k), (c + k, c - k)], fill=hexa(WHITE), width=lw)
    else:   # partly: a half-filled circle look, white bar
        d.rounded_rectangle((c - 0.42 * r, c - 0.09 * r, c + 0.42 * r, c + 0.09 * r), 0.09 * r, fill=hexa(WHITE))
    im = im.resize((sz, sz), Image.LANCZOS); _icon[key] = im; return im

def paste_c(base, im, x, y, alpha=1.0):
    if alpha <= 0.01: return
    if alpha < 0.999:
        im = im.copy(); a = im.getchannel("A").point(lambda v: int(v * alpha)); im.putalpha(a)
    pos = (int(round(x - im.width / 2)), int(round(y - im.height / 2)))
    if base.mode == "RGBA": base.alpha_composite(im, pos)
    else: base.paste(im, pos, im)
def lay(base, L): base.paste(L, (0, 0), L)
def DR(base): return ImageDraw.Draw(base, "RGBA")

# ------------------------------------------------------------------ background
def make_bg():
    y = np.linspace(0, 1, H)[:, None]; x = np.linspace(-1, 1, W)[None, :]
    a, b = np.array(hexa(NAVY)[:3], float), np.array(hexa(NAVY2)[:3], float)
    t = np.clip(0.25 + 0.75 * y + 0.12 * x ** 2, 0, 1)[..., None]
    arr = a * (1 - t) + b * t
    return Image.fromarray(arr.astype(np.uint8), "RGB")
BG = make_bg()

def table_skeleton():
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i in range(NR):
        if i % 2 == 0: d.rectangle((X0 - 10, ry(i), 1020, ry(i) + RH - 1), fill=hexa("#FFFFFF", 14))
    d.line((CX0 - 6, FLAG_Y - 10, CX0 - 6, SC_Y + 84), fill=hexa(SILVER, 70), width=2)
    d.line((X0 - 10, SC_Y - 2, 1020, SC_Y - 2), fill=hexa(GOLD, 160), width=3)
    return im
SKEL = table_skeleton()

def draw_labels(base, t, lit):
    d = DR(base)
    for i, (a, b) in enumerate(LABELS):
        k = lit[i]
        if k > 0:
            d.rectangle((X0 - 10, ry(i) + 10, X0 - 4, ry(i) + RH - 10), fill=hexa(GOLD, int(255 * k)))
        col = hexa(WHITE, int(110 + 145 * k)); y = ry(i) + RH / 2
        d.text((X0 + 6, y - 30), a, font=F(56, 800), fill=col, anchor="lm")
        d.text((X0 + 6, y + 30), b, font=F(56, 800), fill=col, anchor="lm")
    d.text((X0 + 6, SC_Y + 42), "Score", font=F(60, 900), fill=hexa(GOLD), anchor="lm")

def draw_sources(base, a=1.0):
    d = DR(base); c = hexa(SILVER, int(230 * a))
    d.text((X0, SRC_Y + 16), "Freedom House 2026, HRW, Pew, IPU, laws.", font=F(34, 700), fill=c, anchor="lm")
    d.text((X0, SRC_Y + 60), "Amber = partly (no point). Sources in caption.", font=F(34, 700), fill=c, anchor="lm")

def draw_title(base, txt, a=1.0, y=TITLE_Y, sz=64, col=GOLD):
    d = DR(base); d.text((X0, y), txt, font=F(sz, 900), fill=hexa(col, int(255 * a)), anchor="lm")

# ------------------------------------------------------------------ groups and schedule
G = {}
G["A"] = dict(cols=["Turkey", "Lebanon", "Jordan", "Egypt"], t_in=lt(4) - 0.45,
              fill={"Turkey": wt(4, "Turkey"), "Lebanon": wt(5, "Lebanon"), "Jordan": wt(5, "Jordan"), "Egypt": wt(6, "Egypt")},
              score={"Turkey": wt(4, "Four"), "Lebanon": wt(5, "Two"), "Jordan": wt(5, "each"), "Egypt": wt(6, "One")})
G["B"] = dict(cols=["Iraq", "Saudi Arabia", "Iran"], t_in=lt(7) - 0.45,
              fill={"Iraq": wt(7, "Iraq"), "Saudi Arabia": wt(8, "Saudi"), "Iran": wt(9, "Iran")},
              score={"Iraq": wt(7, "One"), "Saudi Arabia": wt(8, "Zero"), "Iran": wt(9, "Zero")},
              pulse=[("Iraq", 3, wt(7, "fifteen")), ("Saudi Arabia", 0, wt(8, "appoints")), ("Iran", 5, wt(9, "death"))])
G["C"] = dict(cols=["UAE", "Qatar", "Yemen"], t_in=lt(10) - 0.45,
              fill={"UAE": wt(10, "UAE"), "Qatar": wt(10, "Qatar"), "Yemen": wt(10, "Yemen")},
              score={"UAE": wt(10, "one"), "Qatar": wt(10, "zero"), "Yemen": wt(10, "zero") + 0.12})
T_ISR = wt(12, "Israel")
G["D"] = dict(cols=["Israel", "Turkey", "Lebanon", "Jordan"], t_in=lt(11) - 0.3,
              fill={"Israel": T_ISR + 0.25, "Turkey": -9, "Lebanon": -9, "Jordan": -9},
              score={"Israel": wt(12, "Seven"), "Turkey": -9, "Lebanon": -9, "Jordan": -9}, mystery="Israel", stagger=0.11)
ORDER = ["A", "B", "C", "D"]
SLIDE = 0.4
T_FAIR0, T_FAIR1 = lt(13) - 0.25, lt(15) - 0.3
T_SB = lt(15) - 0.3
T_Q = lt(15 + 1) - 0.2
T_TABLE = lt(1) - 0.25                    # hook -> table skeleton

def group_layer(g, t):
    """RGBA layer with flags, names, cells and scores of group g at time t"""
    Lr = Image.new("RGBA", (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(Lr)
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L); st = g.get("stagger", 0.13)
    for j, c in enumerate(g["cols"]):
        x = cx(j); tf = g["fill"][c]; active = tf - 0.3 <= t <= tf + 2.6 and tf > 0
        if c == "Israel" or (active and c != "Israel"):
            hl = clamp((t - (tf - 0.3)) / 0.25) if c != "Israel" else clamp((t - T_ISR) / 0.3)
            if c != "Israel": hl *= clamp((tf + 2.6 - t) / 0.4)
            if hl > 0:
                col = hexa(GOLD, int(255 * hl)) if c == "Israel" else hexa(BLUE, int(200 * hl))
                fillc = hexa(GOLD, int(34 * hl)) if c == "Israel" else hexa(BLUE, int(40 * hl))
                dr.rounded_rectangle((x - CW / 2 + 4, FLAG_Y - 14, x + CW / 2 - 4, SC_Y + 82), 18, fill=fillc, outline=col, width=4)
        # flag
        if g.get("mystery") == c and t < T_ISR:
            paste_c(L, QCARD, x, FLAG_Y + 44 + 4 * math.sin(t * 6))
            d.text((x, NAME_Y + 16), "?", font=F(40, 900), fill=hexa(GOLD), anchor="mm")
        else:
            fl = FLAG[c]
            if g.get("mystery") == c:
                k = clamp((t - T_ISR) / 0.3); s = max(0.05, abs(math.cos(math.pi * (1 - k) / 2)))
                fl = fl.resize((max(2, int(fl.width * s)), fl.height), Image.LANCZOS) if k < 1 else fl
            paste_c(L, fl, x, FLAG_Y + 44)
            nm = NAMES.get(c)
            ncol = hexa(GOLD) if c == "Israel" else hexa(WHITE)
            if nm:
                d.text((x, NAME_Y + 2), nm[0], font=F(32, 800), fill=ncol, anchor="mm"); d.text((x, NAME_Y + 36), nm[1], font=F(32, 800), fill=ncol, anchor="mm")
            else: d.text((x, NAME_Y + 16), c, font=F(32 if len(c) > 6 else 34, 800), fill=ncol, anchor="mm")
        # cells
        for i, v in enumerate(TAB[c]):
            t0 = tf + st * i; k = (t - t0) / 0.28
            if tf < 0: k = 1
            if k <= 0: continue
            s = back(k)
            for (pc, pi, pt) in g.get("pulse", []):
                if pc == c and pi == i and pt - 0.05 < t < pt + 0.75: s *= 1 + 0.28 * math.sin(math.pi * clamp((t - pt + 0.05) / 0.8))
            paste_c(L, icon(v, max(0.05, s)), x, ry(i) + RH / 2)
        ts = g["score"][c]; k = 1 if ts < 0 else (t - ts) / 0.3
        if k > 0:
            s = back(k); fz = int(58 * max(0.2, s))
            d.text((x, SC_Y + 42), f"{SCORE[c]}/7", font=F(fz, 900), fill=hexa(GOLD if c == "Israel" else WHITE), anchor="mm")
    Lr.alpha_composite(L); return Lr

def table_phase(base, t):
    """skeleton + labels + groups (with slide transitions) + sources"""
    a = clamp((t - T_TABLE) / 0.35)
    if a <= 0: return
    paste_c(base, SKEL, W / 2, H / 2, a)
    lit = [0.0] * NR
    rowt = [wt(2, "vote"), wt(2, "anyone"), wt(2, "rated"), wt(3, "gay"), wt(3, "couples"), wt(3, "leave"), wt(3, "women")]
    for i, rt in enumerate(rowt):
        on = clamp((t - rt + 0.1) / 0.25)
        lit[i] = on * (1.0 if t < G["A"]["t_in"] else 0.55)
        if rt - 0.1 < t < rt + 1.3:    # highlight band while spoken
            k = clamp((t - rt + 0.1) / 0.2) * clamp((rt + 1.3 - t) / 0.3)
            DR(base).rectangle((X0 - 10, ry(i), 1020, ry(i) + RH - 1), fill=hexa(BLUE, int(70 * k)))
    if t >= G["A"]["t_in"]: lit = [max(l, 0.85) for l in lit]
    if t < G["A"]["t_in"]: lit = [max(l, 0.0) for l in lit]
    draw_labels(base, t, lit)
    # header before groups: flag carousel (10 flags + a mystery card)
    if t < G["A"]["t_in"] + SLIDE:
        k_out = clamp((t - G["A"]["t_in"]) / SLIDE)
        car = Image.new("RGBA", (W, H), (0, 0, 0, 0)); seq = [c for c in CC if c != "Israel"] + ["?"]
        step = 150; off = (t * 70) % (step * len(seq))
        for n in range(-1, len(seq) * 2):
            c = seq[n % len(seq)]; x = CX0 + 60 + n * step - off
            if -200 < x < W + 200: paste_c(car, QCARD if c == "?" else FLAG[c], x, FLAG_Y + 44)
        d = ImageDraw.Draw(car); d.text((cx(1.5) if False else (CX0 + 520) / 2 + 200, NAME_Y + 16), "11 countries", font=F(40, 800), fill=hexa(SILVER), anchor="mm")
        mask = Image.new("L", (W, H), 0); ImageDraw.Draw(mask).rectangle((CX0, 0, 1020, H), fill=255)
        car.putalpha(Image.fromarray((np.array(car.getchannel("A"), float) * np.array(mask, float) / 255 * (1 - k_out) * a).astype(np.uint8)))
        lay(base, car)
    # groups
    for n, gk in enumerate(ORDER):
        g = G[gk]; t_in = g["t_in"]; t_out = G[ORDER[n + 1]]["t_in"] if n + 1 < len(ORDER) else 1e9
        if t < t_in or t > t_out + SLIDE: continue
        dx = 0
        if t < t_in + SLIDE: dx = (1 - ease((t - t_in) / SLIDE)) * 700
        if t > t_out: dx = -ease((t - t_out) / SLIDE) * 700
        L = group_layer(g, t)
        if dx:
            L2 = Image.new("RGBA", (W, H), (0, 0, 0, 0)); L2.alpha_composite(L, (int(dx), 0)); L = L2
        al = np.array(L.getchannel("A")); al[:, :CX0 - 4] = 0; L.putalpha(Image.fromarray(al))
        lay(base, L)
    draw_sources(base, a)

def wrap(txt, font, maxw):
    out, cur = [], ""
    for w_ in txt.split():
        tst = (cur + " " + w_).strip()
        if font.getlength(tst) <= maxw: cur = tst
        else: out.append(cur); cur = w_
    out.append(cur); return out

def fair_card(base, t):
    a = clamp((t - T_FAIR0) / 0.3) * clamp((T_FAIR1 + 0.3 - t) / 0.3)
    if a <= 0: return
    ov = base; d = DR(base)
    d.rectangle((0, 0, W, H), fill=hexa(NAVY2, int(200 * a)))
    y0 = 560 - 30 * (1 - ease((t - T_FAIR0) / 0.35))
    d.rounded_rectangle((X0 - 14, y0, 936, y0 + 820), 28, fill=hexa(PANEL, int(250 * a)), outline=hexa(GOLD, int(255 * a)), width=4)
    d.text((X0 + 26, y0 + 70), "To be fair", font=F(72, 900), fill=hexa(GOLD, int(255 * a)), anchor="lm")
    y = y0 + 160
    b1 = clamp((t - wt(13, "flags")) / 0.3) * a
    for ln in wrap("Freedom House flags discrimination against Arab citizens of Israel.", F(54, 800), 800):
        d.text((X0 + 26, y), ln, font=F(54, 800), fill=hexa(WHITE, int(255 * b1)), anchor="lm"); y += 66
    d.text((X0 + 26, y + 6), "Israel: 73/100. Free, not perfect.", font=F(48, 700), fill=hexa(SILVER, int(255 * b1)), anchor="lm"); y += 110
    b2 = clamp((t - wt(14, "Palestinians")) / 0.3) * a
    for ln in wrap("Palestinians in the West Bank and Gaza are not citizens and can't vote for the Knesset.", F(54, 800), 800):
        d.text((X0 + 26, y), ln, font=F(54, 800), fill=hexa(WHITE, int(255 * b2)), anchor="lm"); y += 66

SB_ORDER = sorted(TAB, key=lambda c: (-SCORE[c], list(TAB).index(c)))
def scoreboard(base, t):
    a = clamp((t - T_SB) / 0.3)
    if a <= 0: return
    ov = base; d = DR(base)
    d.rectangle((0, 0, W, H), fill=hexa(NAVY2, int(255 * a)))
    d.text((X0, 200), "Score out of 7", font=F(72, 900), fill=hexa(GOLD, int(255 * a)), anchor="lm")
    y0, rh = 290, 104
    t_hi = wt(15, "only")
    for n, c in enumerate(SB_ORDER):
        k = ease((t - T_SB - 0.07 * n) / 0.35)
        if k <= 0: continue
        y = y0 + rh * n + rh / 2; xo = (1 - k) * 120
        if c == "Israel":
            p = clamp((t - t_hi) / 0.3)
            d.rounded_rectangle((X0 - 14 + xo, y - rh / 2 + 6, 950 + xo, y + rh / 2 - 6), 18, fill=hexa(GOLD, int((40 + 50 * p) * k)), outline=hexa(GOLD, int(255 * k)), width=4)
        paste_c(ov, FLAG_SB[c], X0 + 60 + xo, y, k)
        d.text((X0 + 136 + xo, y), c, font=F(54, 800), fill=hexa(GOLD if c == "Israel" else WHITE, int(255 * k)), anchor="lm")
        for p_ in range(7):   # 7 pips
            px = 560 + p_ * 40 + xo; on = p_ < SCORE[c]
            d.ellipse((px - 14, y - 14, px + 14, y + 14), fill=hexa(GOLD if (on and c == "Israel") else (GREEN if on else "#FFFFFF"), int((255 if on else 40) * k)))
        d.text((930 + xo, y), str(SCORE[c]), font=F(60, 900), fill=hexa(GOLD if c == "Israel" else WHITE, int(255 * k)), anchor="rm")
    d.text((X0, SRC_Y + 16), "Freedom House 2026, HRW, Pew, IPU, laws.", font=F(34, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")
    d.text((X0, SRC_Y + 60), "Score = full yes answers. Sources in caption.", font=F(34, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")

HOOK = [("Where are", WHITE), ("Muslims the ", WHITE, "freest", GOLD), ("in the Middle East?", WHITE)]
def hook_text(base, t, a, y0, sz, question=False):
    d = DR(base); y = y0
    lines = HOOK if not question else [("So, where are", WHITE), ("Muslims the ", WHITE, "freest", GOLD), ("in the Middle East?", WHITE)]
    for ln in lines:
        segs = [(ln[i], ln[i + 1]) for i in range(0, len(ln), 2)]
        wsum = sum(F(sz, 900).getlength(s) for s, _ in segs); x = X0
        for s, c in segs:
            d.text((x, y), s, font=F(sz, 900), fill=hexa(c, int(255 * a)), anchor="ls"); x += F(sz, 900).getlength(s)
        y += int(sz * 1.12)

def hook_phase(base, t):
    if t >= T_TABLE + 0.4: return
    a = 1 - clamp((t - T_TABLE) / 0.35)
    sz = 95 + 3 * ease(t / 2.6)                # slow push-in from frame 0
    hook_text(base, t, a, 520, sz)
    # flag carousel under the hook from frame 0 (motion), Israel hidden as "?"
    seq = [c for c in CC if c != "Israel"] + ["?"]; step = 180; off = (t * 160 + 60) % (step * len(seq))
    for n in range(-1, len(seq) * 2):
        c = seq[n % len(seq)]; x = 40 + n * step - off
        if -200 < x < W + 200: paste_c(base, QCARD if c == "?" else FLAG[c], x, 1040, a)
    d = DR(base)
    d.text((X0, 1210), "7 questions. 11 countries.", font=F(58, 800), fill=hexa(SILVER, int(255 * a * clamp((t - lt(1) + 0.1) / 0.25))), anchor="lm")

def title_phase(base, t):
    a = clamp((t - T_TABLE) / 0.35) * (1 - clamp((t - T_FAIR0) / 0.3))
    if a > 0: draw_title(base, "Where are Muslims freest?", a)

def question_phase(base, t):
    a = clamp((t - T_Q) / 0.3)
    if a <= 0: return
    d = DR(base); d.rectangle((0, 0, W, H), fill=hexa(NAVY2, int(225 * a)))
    hook_text(base, t, a, 800, 97, question=True)

def frame(t):
    base = BG.copy()
    hook_phase(base, t)
    if t >= T_TABLE: table_phase(base, t); title_phase(base, t)
    fair_card(base, t); scoreboard(base, t); question_phase(base, t)
    return base

if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0] == "--frames":
        out = args[2] if len(args) > 2 else f"{D}/qa"
        os.makedirs(out, exist_ok=True)
        for s in args[1].split(","): frame(float(s)).save(f"{out}/f_{float(s):06.2f}.png")
        print("END", END); sys.exit()
    outp = args[args.index("--out") + 1] if "--out" in args else f"{D}/muslims_freest_v2.mp4"
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
