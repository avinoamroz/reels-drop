# engine_v2 (26 Oct 2026): new fluency line and card; --segs (spans from Cartesia word timestamps, no ASR).
"""Shared reel engine for the two IDF reels (/home/claude/idf/corps, /home/claude/idf/ranks).

Each reel has script.py (lines: key, en, he, tts) and render.py (one draw function per key).
  python3 render.py                      music-only preview, timing estimated from word counts
  python3 render.py --vo vo/noam.mp3     split the voice on silence (whisper small as fallback), time the cards to it
  python3 render.py --frames 0.5,3,10    save check/f_<t>.png only, no encode
  --out FILE  --wps 2.7  --gap 0.8  --force-asr

Text is Pillow + RAQM (Hebrew with direction="rtl"). Fonts: Inter + Heebo (copied from /home/claude/gifts/src/fonts).
Music is generated here in numpy and ducked under the voice. Palette: English Express navy.
"""
import os, sys, re, json, math, time, argparse, subprocess, difflib, functools
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS, SR = 1080, 1920, 30, 44100
FD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")

def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
NAVY, G0, G1, SKY, WHITE = hx("#163261"), hx("#0E1E3A"), hx("#2749D3"), hx("#45A4DD"), (255, 255, 255)
MUTED, DIM = (168, 184, 212), (110, 128, 165)

def clamp(x): return max(0.0, min(1.0, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def smooth(x): x = clamp(x); return x * x * (3 - 2 * x)
def lerp(a, b, u): return a + (b - a) * u
def is_he(s): return any("֐" <= c <= "׿" for c in s)

_FC = {}
def F(fam, w, size):
    """fam 'en' (Inter) or 'he' (Heebo). w: 400..900"""
    k = (fam, w, int(size))
    if k not in _FC:
        if fam == "he":
            ww = {400: 400, 500: 400, 600: 700, 700: 700, 800: 800, 900: 900}[w]; p = f"Heebo-{ww}.ttf"
        else:
            p = {400: "Inter-Regular.ttf", 500: "Inter-Medium.ttf", 600: "Inter-SemiBold.ttf", 700: "Inter-Bold.ttf", 800: "Inter-ExtraBold.ttf", 900: "Inter-ExtraBold.ttf"}[w]
        _FC[k] = ImageFont.truetype(os.path.join(FD, p), int(size), layout_engine=ImageFont.Layout.RAQM)
    return _FC[k]

# ------------------------------------------------------------------ sprites
_SC = {}
def text_sprite(s, size, w=700, color=WHITE, fam=None, track=0, strike=None):
    """RGBA sprite of one line of text, tight box. Hebrew (or fam='he') drawn RTL with Heebo."""
    fam = fam or ("he" if is_he(s) else "en")
    k = ("t", s, size, w, color, fam, track, strike)
    if k in _SC: return _SC[k]
    f = F(fam, w, size)
    kw = dict(direction="rtl", language="he") if fam == "he" else dict(language="en")
    if fam == "en" and track:
        feats = None
    bb = f.getbbox(s, **kw)
    asc, desc = f.getmetrics()
    wd = bb[2] - bb[0] + 8; ht = asc + desc + 8
    im = Image.new("RGBA", (max(1, wd), ht), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.text((4 - bb[0], 4), s, font=f, fill=color + (255,), **kw)
    if strike:
        y = int(4 + asc * 0.62); th = max(4, size // 14)
        d.rounded_rectangle([0, y - th // 2, wd, y + th // 2], radius=th // 2, fill=strike + (255,))
    _SC[k] = im
    return im

def wrap(s, size, w, maxw, fam=None):
    fam = fam or ("he" if is_he(s) else "en")
    f = F(fam, w, size); kw = dict(direction="rtl", language="he") if fam == "he" else {}
    words, lines, cur = s.split(), [], ""
    for wd in words:
        c = (cur + " " + wd).strip()
        if f.getlength(c, **kw) <= maxw or not cur: cur = c
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines

def rrect_sprite(w, h, r, fill=(255, 255, 255, 18), outline=(255, 255, 255, 34), ow=2):
    k = ("r", w, h, r, fill, outline, ow)
    if k in _SC: return _SC[k]
    s = 2; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w * s - 1, h * s - 1], radius=r * s, fill=fill, outline=outline, width=ow * s)
    im = im.resize((w, h), Image.LANCZOS); _SC[k] = im
    return im

def pill_sprite(w, h, color):
    k = ("p", w, h, color)
    if k in _SC: return _SC[k]
    s = 2; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w * s - 1, h * s - 1], radius=h * s // 2, fill=color + (255,))
    im = im.resize((w, h), Image.LANCZOS)
    glow = Image.new("RGBA", (w + 160, h + 160), (0, 0, 0, 0)); glow.alpha_composite(im, (80, 80))
    a = glow.getchannel("A").filter(ImageFilter.GaussianBlur(34)).point(lambda v: int(v * 0.55))
    g2 = Image.new("RGBA", glow.size, color + (0,)); g2.putalpha(a); g2.alpha_composite(im, (80, 80))
    _SC[k] = g2
    return g2

def icon_sprite(name, size, fn, color=SKY):
    """fn(draw, S, color) draws on an S x S canvas (S = 4*size) for antialiasing."""
    k = ("i", name, size, color)
    if k in _SC: return _SC[k]
    S = size * 4; im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); fn(ImageDraw.Draw(im), S, color + (255,))
    im = im.resize((size, size), Image.LANCZOS); _SC[k] = im
    return im

def put(fr, spr, x, y, a=1.0, anchor="mm", scale=1.0):
    if a <= 0.003: return
    if abs(scale - 1) > 0.004:
        spr = spr.resize((max(1, int(spr.width * scale)), max(1, int(spr.height * scale))), Image.BILINEAR)
    if a < 0.997:
        spr = spr.copy(); al = np.asarray(spr.getchannel("A"), dtype=np.float32) * a
        spr.putalpha(Image.fromarray(al.astype(np.uint8)))
    w, h = spr.size
    ox = {"l": 0, "m": w / 2, "r": w}[anchor[0]]; oy = {"t": 0, "m": h / 2, "b": h}[anchor[1]]
    X, Y = int(round(x - ox)), int(round(y - oy))
    if X >= W or Y >= H or X + w <= 0 or Y + h <= 0: return
    if X < 0 or Y < 0 or X + w > W or Y + h > H:
        cx0, cy0 = max(0, -X), max(0, -Y); spr = spr.crop((cx0, cy0, min(w, W - X), min(h, H - Y))); X, Y = max(0, X), max(0, Y)
    fr.alpha_composite(spr, (X, Y))

def T(fr, s, x, y, size, w=700, color=WHITE, a=1.0, anchor="mm", fam=None, strike=None):
    spr = text_sprite(s, size, w, color, fam, strike=strike); put(fr, spr, x, y, a, anchor); return spr.width

def enter(lt, t0=0.0, dur=0.38):
    """(alpha, dy) for an element that appears at local time t0"""
    u = ease((lt - t0) / dur); return u, 34 * (1 - u)

# ------------------------------------------------------------------ background
def make_bg():
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    u = np.clip((0.35 * x / W + 0.85 * y / H) / 1.2, 0, 1) ** 1.7
    c0, c1, cn = np.array(G0, np.float32), np.array(G1, np.float32), np.array(NAVY, np.float32)
    mid = np.clip(u * 2, 0, 1)[..., None]; hi = np.clip(u * 2 - 1, 0, 1)[..., None]
    img = c0 * (1 - mid) + cn * mid; img = img * (1 - hi) + c1 * hi * 0.75 + img * hi * 0.25
    vig = 1 - 0.18 * (((x - W / 2) / W) ** 2 + ((y - H * 0.45) / H) ** 2)[..., None]
    img = np.clip(img * vig, 0, 255).astype(np.uint8)
    bg = Image.fromarray(img, "RGB").convert("RGBA")
    g = Image.new("RGBA", (900, 900), (0, 0, 0, 0)); d = ImageDraw.Draw(g)
    d.ellipse([150, 150, 750, 750], fill=G1 + (120,)); g = g.filter(ImageFilter.GaussianBlur(150))
    s = Image.new("RGBA", (700, 700), (0, 0, 0, 0)); d = ImageDraw.Draw(s)
    d.ellipse([170, 170, 530, 530], fill=SKY + (40,)); s = s.filter(ImageFilter.GaussianBlur(120))
    return bg, g, s

# ------------------------------------------------------------------ audio
def load_audio(p):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)

def music(dur, seed=1, bpm=96, key=0, bright=1.0):
    """Light, original bed: soft pad, marimba-like arpeggio, round sub bass, soft kick and shaker."""
    rng = np.random.default_rng(seed); n = int(dur * SR); out = np.zeros(n)
    def note(m): return 440 * 2 ** ((m - 69 + key) / 12)
    def place(sig, st, g=1.0):
        i = int(st * SR); j = min(n, i + len(sig))
        if 0 <= i < n and j > i: out[i:j] += g * sig[:j - i]
    beat = 60 / bpm; bar = 4 * beat
    progs = [[(48, [64, 67, 71, 74]), (45, [64, 67, 72, 76]), (41, [64, 69, 72, 76]), (43, [62, 67, 71, 74])],
             [(41, [65, 69, 72, 76]), (43, [62, 67, 71, 74]), (45, [64, 67, 72, 76]), (40, [64, 67, 71, 74])]]
    prog = progs[seed % 2]
    arp = [0, 1, 2, 3, 2, 1, 2, 3]
    nb = int(dur / bar) + 2
    for b in range(nb):
        root, ch = prog[b % 4]; st = b * bar; inten = min(1.0, 0.55 + st / 25)
        L = bar + 0.4; tt = np.arange(int(L * SR)) / SR; pad = np.zeros_like(tt)
        for m in ch:
            for dt in (-0.07, 0.07): pad += np.sin(2 * np.pi * note(m - 12) * 2 ** (dt / 12) * tt)
        env = np.minimum(1, tt / 0.6) * np.minimum(1, np.maximum(0, (L - tt) / 0.5))
        place(pad * env, st, 0.018)
        tt = np.arange(int(bar * 0.95 * SR)) / SR
        place(np.sin(2 * np.pi * note(root - 12) * tt) * np.minimum(1, tt / 0.02) * np.exp(-tt * 1.4), st, 0.16 * inten)
        place(np.sin(2 * np.pi * note(root - 12) * tt[:int(beat * SR)]) * np.exp(-tt[:int(beat * SR)] * 4), st + 2.5 * beat, 0.08 * inten)
        if b >= 1:
            for q in range(8):
                m = ch[arp[q]] + 12 * (q == 7 and b % 2 == 1); f = note(m)
                tt = np.arange(int(0.6 * SR)) / SR
                s = (np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * 4 * f * tt) * np.exp(-tt * 40)) * np.exp(-tt * 7) * np.minimum(1, tt / 0.003)
                place(s, st + q * beat / 2, (0.05 if q % 2 else 0.065) * inten * bright)
        if b >= 2:
            for q in (0, 2):
                tt = np.arange(int(0.35 * SR)) / SR; fk = 46 + 60 * np.exp(-tt * 28)
                place(np.sin(2 * np.pi * np.cumsum(fk) / SR) * np.exp(-tt * 10), st + q * beat, 0.26 * inten)
            for q in range(8):
                nz = rng.standard_normal(int(0.05 * SR)); nz = np.diff(np.concatenate([[0], nz])) * np.exp(-np.arange(len(nz)) / SR * 70)
                place(nz, st + q * beat / 2 + 0.006 * rng.standard_normal(), (0.012 if q % 2 else 0.007) * inten)
    out = np.tanh(out * 1.2)
    f_ = int(1.8 * SR); out[-f_:] *= np.linspace(1, 0, f_); out[:int(0.05 * SR)] *= np.linspace(0, 1, int(0.05 * SR))
    return out / (np.max(np.abs(out)) + 1e-9) * 0.8

def duck_env(voice, depth_db=-13, att=0.05, rel=0.35):
    hop = int(0.01 * SR); n = len(voice) // hop + 1
    v = np.pad(voice, (0, n * hop - len(voice)))
    rms = np.sqrt(np.mean(v.reshape(n, hop) ** 2, 1) + 1e-12)
    on = (20 * np.log10(rms / (rms.max() + 1e-12)) > -32).astype(float)
    g = np.zeros(n); lo = 10 ** (depth_db / 20); cur = 1.0
    for i in range(n):
        tgt = lo if on[max(0, i - 0):i + 15].any() else 1.0   # look ahead 150 ms
        k = 0.01 / att if tgt < cur else 0.01 / rel
        cur += (tgt - cur) * min(1, k); g[i] = cur
    return np.repeat(g, hop)[:len(voice)]

# ------------------------------------------------------------------ voice splitting
def silences(x, thr_db=-40, min_len=0.25):
    hop = int(0.02 * SR); n = len(x) // hop
    rms = np.sqrt(np.mean(x[:n * hop].reshape(n, hop) ** 2, 1) + 1e-12)
    sil = 20 * np.log10(rms / (np.percentile(rms, 99) + 1e-12)) < thr_db
    runs, i = [], 0
    while i < n:
        if sil[i]:
            j = i
            while j < n and sil[j]: j += 1
            runs.append((i * hop / SR, j * hop / SR)); i = j
        else: i += 1
    first = int(np.argmax(~sil)) * hop / SR; last = (n - int(np.argmax(~sil[::-1]))) * hop / SR
    return [(a, b) for a, b in runs if a > first and b < last and b - a >= min_len], first, last

def split_on_silence(x, nlines):
    runs, first, last = silences(x, min_len=0.25)
    need = nlines - 1
    if len(runs) < need: return None, f"only {len(runs)} pauses for {need} breaks"
    by = sorted(runs, key=lambda r: r[1] - r[0], reverse=True)
    if len(by) > need:
        a, b = by[need - 1][1] - by[need - 1][0], by[need][1] - by[need][0]
        if not (a >= 0.5 and a >= 1.35 * b): return None, f"breaks not clear ({a:.2f}s vs {b:.2f}s)"
    elif by[-1][1] - by[-1][0] < 0.4: return None, "shortest break under 0.4 s"
    cut = sorted(by[:need]); edges = [first] + [v for r in cut for v in r] + [last]
    return [(edges[2 * k], edges[2 * k + 1]) for k in range(nlines)], "silence"

def split_with_asr(x, lines):
    """Chunks from short silences, transcribed with whisper small; a DP assigns chunks to lines by text similarity."""
    runs, first, last = silences(x, min_len=0.2)
    B, a = [], first
    for s, e in runs: B.append((a, s)); a = e
    B.append((a, last))
    M = "/tmp/claude-0/asr/sherpa-onnx-whisper-small/"
    texts = []
    def seg16(a, b):
        i0, i1 = int(max(0, a - 0.05) * SR), min(len(x), int((b + 0.1) * SR)); c = x[i0:i1]
        return np.interp(np.arange(0, len(c) / SR, 1 / 16000), np.arange(len(c)) / SR, c).astype(np.float32)
    if os.path.exists(M + "small-encoder.int8.onnx"):
        import sherpa_onnx
        asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=M + "small-encoder.int8.onnx", decoder=M + "small-decoder.int8.onnx", tokens=M + "small-tokens.txt", language="en", task="transcribe", num_threads=2)
        for a, b in B:
            s = asr.create_stream(); s.accept_waveform(16000, np.concatenate([seg16(a, b), np.zeros(6400, np.float32)])); asr.decode_stream(s); texts.append(s.result.text.strip())
    else:
        from faster_whisper import WhisperModel
        m = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=2)
        for a, b in B:
            segs, _ = m.transcribe(seg16(a, b), language="en", beam_size=1); texts.append(" ".join(s.text for s in segs).strip())
    norm = lambda t: re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", t.lower())).strip()
    ref = [norm(l) for l in lines]; n, m = len(lines), len(B)
    if m < n: sys.exit(f"ASR split: {m} speech chunks for {n} lines")
    sys.setrecursionlimit(10000)
    @functools.lru_cache(None)
    def best(i, k):
        if k == n: return (0.0, ()) if i == m else (-1e9, ())
        if i == m: return (-1e9, ())
        r = (-1e9, ())
        for j in range(i + 1, m + 1 - (n - k - 1)):
            v, p = best(j, k + 1); v += difflib.SequenceMatcher(None, norm(" ".join(texts[i:j])), ref[k]).ratio()
            if v > r[0]: r = (v, ((i, j),) + p)
        return r
    _, part = best(0, 0)
    for k, (i, j) in enumerate(part): print(f"  {k:2d} {B[i][0]:6.2f}-{B[j-1][1]:6.2f} | {' / '.join(texts[i:j])}")
    return [(B[i][0], B[j - 1][1]) for i, j in part]

# ------------------------------------------------------------------ the 7-minute beat
SEVEN_EN = "Want fluency? Talk to yourself in English for seven minutes, on WhatsApp. Then explain the same idea to a friend."
SEVEN_HE = "רוצים שטף? דברו עם עצמכם באנגלית 7 דקות בוואטסאפ, ואז הסבירו את אותו רעיון לחבר."

def _watch(d, S, c):
    w = S // 16; d.ellipse([S * .14, S * .2, S * .86, S * .92], outline=c, width=w)
    d.rounded_rectangle([S * .42, S * .02, S * .58, S * .12], radius=S * .03, fill=c); d.line([(S * .5, S * .12), (S * .5, S * .2)], fill=c, width=w)
    d.line([(S * .5, S * .56), (S * .5, S * .34)], fill=c, width=w); d.line([(S * .5, S * .56), (S * .66, S * .66)], fill=c, width=w)

def seven_card(fr, k, lt, dur, t, R):
    a, dy = enter(lt, 0.0)
    put(fr, icon_sprite("watch7", 190, _watch), W / 2, 440 + dy, a)
    T(fr, "Want fluency?", W / 2, 620 + dy, 62, 700, SKY, a)
    a1, d1 = enter(lt, R.at_phrase("seven", "Talk to") - 0.1)
    T(fr, "Talk to yourself", W / 2, 740 + d1, 90, 800, WHITE, a1)
    T(fr, "in English.", W / 2, 840 + d1, 90, 800, WHITE, a1)
    a2, d2 = enter(lt, R.at_phrase("seven", "seven minutes") - 0.1)
    T(fr, "7 minutes, on WhatsApp.", W / 2, 960 + d2, 60, 700, SKY, a2)
    a3, d3 = enter(lt, R.at_phrase("seven", "Then explain") - 0.1)
    T(fr, "Then explain the same idea", W / 2, 1070 + d3, 48, 600, WHITE, a3)
    T(fr, "to a friend.", W / 2, 1130 + d3, 48, 600, WHITE, a3)
    a4, d4 = enter(lt, 0.4)
    for i, s in enumerate(wrap(SEVEN_HE, 40, 500, 940, "he")): T(fr, s, W / 2, 1250 + i * 52 + d4, 40, 500, (196, 222, 244), a4, fam="he")

# ------------------------------------------------------------------ the reel
def spoken_units(line):
    n = 0.0
    for w in line.split():
        core = re.sub(r"[^\w@]", "", w)
        n += 1 + 0.12 * max(0, len(core) - 6)
        if w.startswith("@"): n += 3
    return n + 0.3 * len(re.findall(r"[.?!,:]", line))

def wait_mem(mb=2500):
    while True:
        avail = int(re.search(r"MemAvailable:\s+(\d+)", open("/proc/meminfo").read()).group(1)) // 1024
        if avail > mb: return avail
        print(f"waiting for memory: {avail} MB available", flush=True); time.sleep(15)

class Reel:
    def __init__(self, here, lines, draw, name, seed=1, bpm=96, key=0, hook_max=1.0):
        self.here, self.L, self.draw, self.name, self.seed, self.bpm, self.mkey = here, lines, draw, name, seed, bpm, key
        self.KEYS = [l["key"] for l in lines]; self.BY = {l["key"]: l for l in lines}; self.hook_max = hook_max
        ap = argparse.ArgumentParser()
        ap.add_argument("--vo"); ap.add_argument("--out"); ap.add_argument("--frames")
        ap.add_argument("--wps", type=float, default=2.8); ap.add_argument("--gap", type=float, default=0.8)
        ap.add_argument("--force-asr", action="store_true")
        ap.add_argument("--segs", help="JSON {segs: [[t0, t1], ...]} one span per line (Cartesia word timestamps); skips the split")
        ap.add_argument("--seven", action="store_true", help="with --vo X_7min.mp3: add the 7-minute card before the last (CTA) line")
        self.A = ap.parse_args()
        if self.A.seven:
            self.L = lines = list(lines[:-1]) + [dict(key="seven", en=SEVEN_EN, he=SEVEN_HE, nosub=True)] + list(lines[-1:])
            self.KEYS = [l["key"] for l in lines]; self.BY = {l["key"]: l for l in lines}
            _draw = draw
            self.draw = lambda fr, k, lt, dur, t, R: seven_card(fr, k, lt, dur, t, R) if k == "seven" else _draw(fr, k, lt, dur, t, R)
        self.bg, self.glow, self.glow2 = make_bg()
        self.timeline()

    def timeline(self):
        A, LEAD, TAIL = self.A, 0.08, 2.3
        self.voice = None
        if A.vo:
            if A.segs:
                x = load_audio(A.vo); spans = [tuple(p) for p in json.load(open(A.segs))["segs"]]; how = "segs (Cartesia word timestamps)"
                assert len(spans) == len(self.KEYS), (len(spans), len(self.KEYS))
            elif A.seven:   # split the ORIGINAL narration as before, then insert the spliced 7-minute line
                info = json.load(open(A.vo + ".json")); L0 = [l for l in self.L if l["key"] != "seven"]
                x0 = load_audio(info["src"]); spans, how = (None, "forced") if A.force_asr else split_on_silence(x0, len(L0))
                if spans is None:
                    print("silence split failed:", how, "-> whisper small alignment"); spans = split_with_asr(x0, [l["en"] for l in L0]); how = "asr"
                sh = info["shift"]; a, b = spans[-1]
                spans = list(spans[:-1]) + [tuple(info["seven"]), (info["cta_start_new"], b + sh)]; how += " + 7min splice"
                x = load_audio(A.vo)
            else:
                x = load_audio(A.vo); spans, how = (None, "forced") if A.force_asr else split_on_silence(x, len(self.KEYS))
                if spans is None:
                    print("silence split failed:", how, "-> whisper small alignment"); spans = split_with_asr(x, [l["en"] for l in self.L]); how = "asr"
            off = 0.15 - spans[0][0]
            self.segs = [dict(key=k, v0=a + off, v1=b + off) for k, (a, b) in zip(self.KEYS, spans)]
            self.TT = self.segs[-1]["v1"] + TAIL
            v = np.zeros(int((self.TT + 0.5) * SR)); src = x[max(0, int(-off * SR)):]; i0 = max(0, int(off * SR))
            L = min(len(src), len(v) - i0); v[i0:i0 + L] = src[:L]; self.voice = v
            print("voice split by", how)
        else:
            t, self.segs = 0.15, []
            for l in self.L:
                d = spoken_units(l["en"]) / A.wps + 0.15
                self.segs.append(dict(key=l["key"], v0=t, v1=t + d)); t += d + A.gap
            self.TT = self.segs[-1]["v1"] + TAIL
        self.SEG = {s["key"]: s for s in self.segs}
        self.B0 = {k: (0.0 if i == 0 else self.SEG[k]["v0"] - LEAD) for i, k in enumerate(self.KEYS)}
        self.B1 = {k: (self.B0[self.KEYS[i + 1]] if i + 1 < len(self.KEYS) else self.TT) for i, k in enumerate(self.KEYS)}
        self.NF = int(math.ceil(self.TT * FPS))

    def beat_at(self, t):
        for k in reversed(self.KEYS):
            if self.B0[k] <= t: return k
        return self.KEYS[0]

    def word_t(self, key, frac):
        """time (beat-local) at a fraction of the spoken line"""
        s = self.SEG[key]; return (s["v0"] - self.B0[key]) + frac * (s["v1"] - s["v0"])

    def at_phrase(self, key, phrase):
        """beat-local time when `phrase` starts, by character position in the line"""
        en = self.BY[key]["en"]; i = en.lower().find(phrase.lower())
        return self.word_t(key, max(0, i) / max(1, len(en))) if i >= 0 else 0.0

    def subtitle(self, fr, key, lt, dur, y=1440):
        l = self.BY[key]
        if l.get("nosub"): return
        a = ease(lt / 0.25) * (1 - clamp((lt - (dur - 0.15)) / 0.15)) if key != self.KEYS[0] else (1 - clamp((lt - (dur - 0.15)) / 0.15))
        en = wrap(l["en"], 43, 600, 940); he = wrap(l["he"], 40, 500, 940, "he")
        yy = y
        for s in en: T(fr, s, W / 2, yy, 43, 600, WHITE, a); yy += 54
        yy += 6
        for s in he: T(fr, s, W / 2, yy, 40, 500, (196, 222, 244), a, fam="he"); yy += 52

    def frame(self, t):
        fr = self.bg.copy()
        gx = W * 0.72 + 120 * math.sin(t * 0.21); gy = H * 0.78 + 90 * math.cos(t * 0.17)
        put(fr, self.glow, gx, gy, 0.9)
        put(fr, self.glow2, W * 0.2 + 80 * math.cos(t * 0.13), H * 0.22 + 60 * math.sin(t * 0.19), 0.8)
        k = self.beat_at(t); b0, b1 = self.B0[k], self.B1[k]; lt, dur = t - b0, b1 - b0
        out = 1 - clamp((lt - (dur - 0.18)) / 0.18) if k != self.KEYS[-1] else 1.0
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        self.draw(layer, k, lt, dur, t, self)
        self.subtitle(layer, k, lt, dur)
        if out < 0.999:
            al = np.asarray(layer.getchannel("A"), dtype=np.float32) * out; layer.putalpha(Image.fromarray(al.astype(np.uint8)))
        fr.alpha_composite(layer)
        # brand line, small, top
        T(fr, "ENGLISH EXPRESS", 80, 150, 24, 700, (200, 214, 236), 0.75, anchor="lm")
        put(fr, pill_sprite(10, 10, SKY), 58, 150, 0.9)
        return fr

    def audio(self):
        m = music(self.TT + 0.5, self.seed, self.bpm, self.mkey)
        if self.voice is None: mix = m * 0.55
        else:
            v = self.voice[:len(m)]; v = np.pad(v, (0, len(m) - len(v)))
            v = v / (np.max(np.abs(v)) + 1e-9) * 0.89
            mix = v + m * 0.30 * duck_env(v)
        mix = np.clip(mix, -0.98, 0.98)
        p = os.path.join(self.here, "work_mix.wav")
        import wave
        w = wave.open(p, "wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        st = np.stack([mix, mix], 1); w.writeframes((st * 32767).astype(np.int16).tobytes()); w.close()
        return p

    def run(self):
        A = self.A
        print(f"{self.name}: {self.TT:.2f}s, {self.NF} frames")
        for s in self.segs: print(f"  {s['key']:8s} {self.B0[s['key']]:6.2f} voice {s['v0']:6.2f}-{s['v1']:6.2f}")
        if A.frames:
            os.makedirs(os.path.join(self.here, "check"), exist_ok=True)
            for v in A.frames.split(","):
                tt = float(v); self.frame(tt).convert("RGB").save(os.path.join(self.here, "check", f"f_{tt:05.2f}.png")); print("frame", tt)
            return
        wait_mem(2500)
        out = A.out or os.path.join(self.here, f"{self.name}_{'vo' if A.vo else 'v1'}.mp4")
        aud = self.audio()
        cmd = ["nice", "-n", "15", "ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-i", aud, "-c:v", "libx264", "-preset", "medium", "-crf", "21", "-maxrate", "1900k", "-bufsize", "3800k", "-pix_fmt", "yuv420p",
               "-threads", "2", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", "-shortest", out]
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE); t0 = time.time()
        for i in range(self.NF):
            p.stdin.write(self.frame(i / FPS).convert("RGB").tobytes())
            if i % 150 == 0: print(f"  frame {i}/{self.NF}  {time.time() - t0:.0f}s", flush=True)
        p.stdin.close(); p.wait()
        print("wrote", out, f"{os.path.getsize(out) / 1e6:.2f} MB")
