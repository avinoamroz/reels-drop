# render_v2: script_v2 + engine_v2, CTA comment IDF.
#!/usr/bin/env python3
"""Reel 2: "IDF ranks in English" for @expressenglishcom (collab @noamroz__).
  python3 render.py                    -> ranks_v1.mp4 (music only, timing from word counts)
  python3 render.py --vo vo/noam.mp3   -> ranks_vo.mp4 (cards timed to Noam's voice; silence split, whisper small fallback)
  python3 render.py --frames 0.5,4     -> check/f_*.png
Ranks come from facts.json. Insignia are simplified original sketches by rank family, not reproductions."""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "common")); sys.path.insert(0, HERE)
from engine_v2 import *
from script_v2 import LINES

RED = (232, 96, 110)
RANKS = json.load(open(os.path.join(HERE, "facts.json"), encoding="utf8"))["ranks"]
IDX = {r["rom"]: i for i, r in enumerate(RANKS)}

# ------------------------------------------------------------------ insignia sketches (original, generic)
def insignia(i):
    """returns a draw fn for rank index i"""
    r = RANKS[i]; g = r["group"]
    def fn(d, S, c):
        w = S // 18
        if g == "enlisted":
            n = [0, 2, 3, 3][i]
            if n == 0:
                d.rounded_rectangle([S * .3, S * .46, S * .7, S * .54], radius=S * .04, fill=c[:3] + (90,)); return
            for k in range(n):
                y = S * (.36 + .16 * k) - (n - 2) * S * .06
                d.line([(S * .22, y + S * .14), (S * .5, y), (S * .78, y + S * .14)], fill=c, width=int(S * .07), joint="curve")
            if i == 3:  # small leaf above the stripes
                d.ellipse([S * .44, S * .1, S * .56, S * .26], fill=c)
        elif g == "nco":
            n = i - 3   # 1..5
            d.line([(S * .5, S * .1), (S * .82, S * .22), (S * .78, S * .6), (S * .5, S * .9), (S * .22, S * .6), (S * .18, S * .22), (S * .5, S * .1)], fill=c, width=w, joint="curve")
            pts = {1: [(.5, .48)], 2: [(.4, .48), (.6, .48)], 3: [(.36, .44), (.5, .44), (.64, .44)], 4: [(.4, .36), (.6, .36), (.4, .56), (.6, .56)],
                   5: [(.36, .36), (.5, .36), (.64, .36), (.43, .56), (.57, .56)]}[n]
            for x, y in pts: d.ellipse([S * x - S * .045, S * y - S * .045, S * x + S * .045, S * y + S * .045], fill=c)
        elif g == "junior":
            n = i - 8
            for k in range(n):
                y = S * (.5 + (k - (n - 1) / 2) * .17); d.rounded_rectangle([S * .24, y - S * .045, S * .76, y + S * .045], radius=S * .045, fill=c)
        elif g == "senior":
            n = i - 11
            for k in range(n):
                x = S * (.5 + (k - (n - 1) / 2) * .24)
                d.polygon([(x, S * .26), (x + S * .1, S * .5), (x, S * .74), (x - S * .1, S * .5)], fill=c)
        else:  # general: crossed blade and branch, with 1..3 marks
            n = i - 14
            d.line([(S * .2, S * .84), (S * .8, S * .3)], fill=c, width=int(S * .06))
            d.line([(S * .8, S * .84), (S * .2, S * .3)], fill=c, width=int(S * .045))
            for k in range(3): d.ellipse([S * (.3 + .1 * k) - S * .04, S * (.4 + .09 * k) - S * .07, S * (.3 + .1 * k) + S * .04, S * (.4 + .09 * k) + S * .02], fill=c)
            for k in range(n):
                x = S * (.5 + (k - (n - 1) / 2) * .17); d.ellipse([x - S * .05, S * .08, x + S * .05, S * .18], fill=c)
    return fn

GROUPS = {"enl": ("ENLISTED", "חוגרים", ["Turai", "Rav Turai", "Samal", "Samal Rishon"]),
          "nco1": ("NCOs · WARRANT OFFICERS", "נגדים", ["Rav Samal", "Rav Samal Rishon"]),
          "nco2": ("NCOs · WARRANT OFFICERS", "נגדים", ["Rav Samal Mitkadem", "Rav Samal Bakhir", "Rav Nagad"]),
          "jr": ("JUNIOR OFFICERS", "קצינים זוטרים", ["Segen Mishne", "Segen", "Seren"]),
          "sr": ("SENIOR OFFICERS", "קצינים בכירים", ["Rav Seren", "Sgan Aluf", "Aluf Mishne"]),
          "gen": ("GENERALS", "אלופים", ["Tat Aluf", "Aluf", "Rav Aluf"])}

def rank_card(fr, y, i, a, dy, lit):
    r = RANKS[i]
    put(fr, rrect_sprite(960, 200, 34, fill=(255, 255, 255, 20 if lit else 12)), W / 2, y + dy, a)
    put(fr, rrect_sprite(140, 140, 30, fill=SKY + (30,), outline=SKY + (90,)), 132, y + dy, a)
    put(fr, icon_sprite(f"ins{i}", 104, insignia(i), WHITE if r["group"] in ("enlisted", "nco") else SKY), 132, y + dy, a)
    size = 50
    while F("en", 800, size).getlength(r["en"]) > 560: size -= 1
    T(fr, r["en"], 232, y + dy - 44, size, 800, WHITE, a, "lm")
    T(fr, r["rom"], 232, y + dy + 14, 34, 600, SKY, a, "lm")
    T(fr, r["meaning"], 232, y + dy + 60, 25, 500, MUTED, a, "lm")
    T(fr, r["he"], 1000, y + dy - 30, 44, 800, (220, 232, 248), a, "rm", fam="he")
    T(fr, r["abbr"], 1000, y + dy + 30, 32, 500, MUTED, a, "rm", fam="he")

def ladder(fr, cur, a):
    """18 dots across the top, one per rank, lit up to the current one"""
    x0, x1, y = 90, 990, 236
    for i in range(len(RANKS)):
        x = x0 + (x1 - x0) * i / (len(RANKS) - 1)
        on = i <= cur
        put(fr, pill_sprite(16 if i == cur else 10, 16 if i == cur else 10, SKY if on else (70, 90, 130)), x, y, a * (1 if on else 0.8))

def word_card(fr, word, y, a, dy, size=170, color=WHITE, strike=None):
    put(fr, text_sprite(word, size, 800, color, strike=strike), W / 2, y + dy, a)

def draw(fr, k, lt, dur, t, R):
    A = lambda t0=0.0, d=0.38: enter(lt, t0, d)
    if k == "hook":
        if lt < R.hook_max:   # hook on screen from frame 0, at most 1 s
            T(fr, "Your IDF rank,", W / 2, 640, 96, 800, WHITE)
            T(fr, "in English?", W / 2, 760, 96, 800, SKY)
            T(fr, "סמ\"ר  =  ?", W / 2, 940, 80, 800, (220, 232, 248), fam="he")
        else:
            a, dy = A(R.hook_max, 0.3)
            T(fr, "Your IDF rank,", W / 2, 640, 96, 800, WHITE)
            T(fr, "in English?", W / 2, 760, 96, 800, SKY)
            put(fr, rrect_sprite(760, 140, 70, fill=SKY + (30,), outline=SKY + (120,)), W / 2, 960 + dy, a)
            T(fr, "סמ\"ר", 300, 960 + dy, 64, 800, WHITE, a, fam="he")
            T(fr, "=", 395, 960 + dy, 52, 700, WHITE, a)
            T(fr, "Staff Sergeant", 445, 960 + dy, 50, 800, SKY, a, "lm")
            T(fr, "From Turai to Rav Aluf", W / 2, 1110 + dy, 40, 600, MUTED, a)
    elif k in GROUPS:
        title, he, names = GROUPS[k]; n = len(names); gap = 222
        y0 = 820 - (n - 1) * gap / 2 + (0 if n == 4 else 20)
        ah = ease(lt / 0.3) if k in ("enl", "jr") else 1.0
        T(fr, title, 60, 310, 30, 800, SKY, ah, "lm"); T(fr, he, 1020, 310, 32, 700, (196, 222, 244), ah, "rm", fam="he")
        cur = IDX[names[0]] - 1
        for j, nm in enumerate(names):
            t0 = max(0, R.at_phrase(k, nm if j == 0 or nm not in ("Segen", "Aluf") else (", " + nm + ",")) - 0.12)
            if k == "enl" and nm == "Turai": t0 = 0.0
            if k == "enl" and nm == "Samal": t0 = R.at_phrase(k, ". Samal,")
            if k == "nco1" and nm == "Rav Samal": t0 = 0.0
            if k == "gen" and nm == "Aluf": t0 = R.at_phrase(k, ". Aluf,")
            if k == "jr" and nm == "Segen": t0 = R.at_phrase(k, ". Segen,")
            a, dy = A(t0, 0.34)
            if lt >= t0: cur = IDX[nm]
            rank_card(fr, y0 + j * gap, IDX[nm], max(a, 0.2 * ease(lt / 0.3)), dy * a, lt >= t0)
        ladder(fr, cur, 1.0)
    elif k == "col":
        a, dy = A(0)
        T(fr, "PRONUNCIATION TRAPS", W / 2, 420, 32, 800, SKY, a)
        word_card(fr, "Colonel", 640, a, dy)
        a2, d2 = A(R.at_phrase(k, "kernel") - 0.1)
        T(fr, "=  \"kernel\"", W / 2, 840 + d2, 110, 800, SKY, a2)
        T(fr, "/ˈkɝːnəl/   KER-nul", W / 2, 980 + d2, 46, 500, WHITE, a2)
        T(fr, "No L sound. Spelled with L, said with R.", W / 2, 1090 + d2, 34, 500, MUTED, a2)
    elif k == "lt":
        a, dy = A(0)
        word_card(fr, "Lieutenant", 520, a, dy, 140)
        for x, top, say, ipa, ph in [(300, "US", "loo-TEN-ant", "/luːˈtɛnənt/", "loo-TEN"), (780, "UK", "lef-TEN-ant", "/lɛfˈtɛnənt/", "lef-TEN")]:
            aa, dd = A(R.at_phrase(k, ph) - 0.1)
            put(fr, rrect_sprite(440, 400, 44), x, 880 + dd, aa)
            T(fr, top, x, 740 + dd, 36, 800, SKY, aa)
            T(fr, say, x, 860 + dd, 56, 800, WHITE, aa)
            T(fr, ipa, x, 950 + dd, 38, 500, MUTED, aa)
            T(fr, "American English" if top == "US" else "British English", x, 1020 + dd, 28, 500, MUTED, aa)
    elif k == "sgt":
        a, dy = A(0)
        word_card(fr, "Sergeant", 480, a, dy, 140)
        T(fr, "=  \"SAR-jent\"", W / 2, 640 + dy, 76, 800, SKY, a)
        T(fr, "/ˈsɑːrdʒənt/", W / 2, 730 + dy, 40, 500, WHITE, a)
        a2, d2 = A(R.at_phrase(k, "Corporal") - 0.1)
        put(fr, rrect_sprite(940, 330, 46, fill=SKY + (26,), outline=SKY + (100,)), W / 2, 1040 + d2, a2)
        T(fr, "corporal", 330, 990 + d2, 76, 800, WHITE, a2)
        T(fr, "/ˈkɔːrpərəl/  the rank", 330, 1070 + d2, 30, 500, SKY, a2)
        a3, d3 = A(R.at_phrase(k, "not corporate") - 0.1)
        T(fr, "corporate", 760, 990 + d3, 72, 800, (150, 164, 196), a3, strike=RED)
        T(fr, "about companies", 760, 1070 + d3, 30, 500, MUTED, a3)
    elif k == "end":
        a, dy = A(0)
        T(fr, "Now you can", W / 2, 560 + dy, 96, 800, WHITE, a)
        T(fr, "talk about", W / 2, 670 + dy, 96, 800, WHITE, a)
        T(fr, "your service.", W / 2, 780 + dy, 96, 800, SKY, a)
        a2, d2 = A(0.7)
        put(fr, rrect_sprite(940, 150, 40), W / 2, 980 + d2, a2)
        T(fr, "\"I served as a Staff Sergeant", W / 2, 950 + d2, 38, 600, WHITE, a2)
        T(fr, "in the Intelligence Corps.\"", W / 2, 1006 + d2, 38, 600, WHITE, a2)
    elif k == "kw":
        a, dy = A(0)
        T(fr, "COMMENT", W / 2, 520 + dy, 44, 700, WHITE, a)
        sc = 1 + 0.035 * math.sin(max(0, lt - 0.5) * 3.2)
        put(fr, pill_sprite(560, 230, SKY), W / 2, 720 + dy, a, scale=sc)
        T(fr, "IDF", W / 2, 718 + dy, 150, 800, WHITE, a)
        a2, d2 = A(0.4)
        T(fr, "Get the IDF cheat sheet", W / 2, 920 + d2, 42, 600, WHITE, a2)
        T(fr, "דף הדרגות והחילות באנגלית", W / 2, 985 + d2, 38, 500, (196, 222, 244), a2, fam="he")
        a3, d3 = A(0.8)
        T(fr, "@expressenglishcom", W / 2, 1150 + d3, 46, 700, WHITE, a3)
        T(fr, "with @noamroz__", W / 2, 1212 + d3, 38, 500, MUTED, a3)

if __name__ == "__main__":
    Reel(HERE, LINES, draw, "ranks", seed=2, bpm=100, key=2).run()
