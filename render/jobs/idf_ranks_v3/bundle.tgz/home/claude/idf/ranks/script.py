"""Reel 2, "IDF ranks in English". One dict per spoken line: en (narration + caption), he (subtitle), tts (ElevenLabs text,
with respellings so an English voice says the Hebrew rank names right). python3 script.py writes narration.txt and tts.txt"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))

LINES = [
 dict(key="hook", en="Your IDF rank, in English?", he="הדרגה שלכם בצה\"ל, באנגלית?",
      tts="Your I-D-F rank, in English?"),
 dict(key="enl", en="Turai, private. Rav Turai, corporal. Samal, sergeant. Samal Rishon, staff sergeant.",
      he="טוראי: Private. רב\"ט: Corporal. סמל: Sergeant. סמ\"ר: Staff Sergeant.",
      tts="Too-rye, private. Rahv too-rye, corporal. Sah-mahl, sergeant. Sah-mahl ree-shone, staff sergeant."),
 dict(key="nco1", en="Rav Samal, sergeant first class. Rav Samal Rishon, master sergeant.",
      he="רס\"ל: Sergeant First Class. רס\"ר: Master Sergeant.",
      tts="Rahv sah-mahl, sergeant first class. Rahv sah-mahl ree-shone, master sergeant."),
 dict(key="nco2", en="Rav Samal Mitkadem, sergeant major. Rav Samal Bakhir, warrant officer. Rav Nagad, chief warrant officer.",
      he="רס\"ם: Sergeant Major. רס\"ב: Warrant Officer. רנ\"ג: Chief Warrant Officer.",
      tts="Rahv sah-mahl meet-kah-dem, sergeant major. Rahv sah-mahl bah-kheer, warrant officer. Rahv nah-gahd, chief warrant officer."),
 dict(key="jr", en="Segen Mishne, second lieutenant. Segen, lieutenant. Seren, captain.",
      he="סג\"ם: Second Lieutenant. סגן: Lieutenant. סרן: Captain.",
      tts="Seh-ghen meesh-neh, second lieutenant. Seh-ghen, lieutenant. Seh-ren, captain."),
 dict(key="sr", en="Rav Seren, major. Sgan Aluf, lieutenant colonel. Aluf Mishne, colonel.",
      he="רס\"ן: Major. סא\"ל: Lieutenant Colonel. אל\"ם: Colonel.",
      tts="Rahv seh-ren, major. Sgahn ah-loof, lieutenant colonel. Ah-loof meesh-neh, colonel."),
 dict(key="gen", en="Tat Aluf, brigadier general. Aluf, major general. Rav Aluf, lieutenant general.",
      he="תא\"ל: Brigadier General. אלוף: Major General. רא\"ל: Lieutenant General.",
      tts="Taht ah-loof, brigadier general. Ah-loof, major general. Rahv ah-loof, lieutenant general."),
 dict(key="col", en="Colonel is said kernel.", he="את Colonel הוגים \"קֶרְנֶל\".", tts="Colonel, is said kernel."),
 dict(key="lt", en="Lieutenant: loo-TEN-ant in the US, lef-TEN-ant in Britain.",
      he="Lieutenant: \"לוּ־טֶנֶנְט\" בארה\"ב, \"לֶף־טֶנֶנְט\" בבריטניה.",
      tts="Lieutenant: loo-TEN-uhnt, in the U-S. Lef-TEN-uhnt, in Britain."),
 dict(key="sgt", en="Sergeant: SAR-jent. Corporal, not corporate.", he="Sergeant: \"סַרְגֶ'נְט\". ו־Corporal, לא Corporate.",
      tts="Sergeant: SAR-jent. Corporal. Not corporate."),
 dict(key="end", en="Now you can talk about your service in English.", he="עכשיו אתם יכולים לדבר על השירות שלכם באנגלית."),
 dict(key="kw", en="Comment RANK to get the full table of ranks in English.", he="תגיבו RANK ותקבלו את הטבלה המלאה של הדרגות באנגלית.",
      tts="Comment, RANK, to get the full table of ranks in English."),
]
BREAK = ' <break time="0.8s" /> '

if __name__ == "__main__":
    for l in LINES:
        for k in ("en", "he", "tts"):
            assert "\u2014" not in l.get(k, "") and "\u2013" not in l.get(k, ""), l
    open(os.path.join(HERE, "narration.txt"), "w", encoding="utf8").write("\n".join(l["en"] for l in LINES) + "\n")
    open(os.path.join(HERE, "tts.txt"), "w", encoding="utf8").write(BREAK.join(l.get("tts", l["en"]) for l in LINES) + "\n")
    n = sum(len(l["en"].split()) for l in LINES)
    print("ok", len(LINES), "lines,", n, "words, est", round(n / 2.4 + 0.8 * (len(LINES) - 1) + 2.6, 1), "s")
