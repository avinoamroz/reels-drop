# Voice batching: Make TTS1 (scenario 4998936), 1 Nov 2026

Every TTS1 call is a full Make round trip (and one Drive file to find and fetch). Batch.

## Rule
1. **One TTS1 call per reel.** Put every line of the script in one transcript, keep the sentence breaks
   (each script line ends with . ? or !, Cartesia pauses there). Use `endpoint: "sse"` so word timestamps
   come back and no whisper timing pass is needed.
   `python3 /home/claude/reelkit/cloud_voice.py plan tts.txt <prefix>` prints the exact `data` and writes `<prefix>_parts.json`.
2. **Split only when the file would be too big.** SSE output is about 120 KB per second of speech
   (44.1 kHz PCM in base64). Raw SSE blobs up to 7.4 MB (about 60 s) have come through the Drive download
   tool fine. `plan` splits at line boundaries only above `--max-sec` (default 55 s, about 140 words).
   Never split per line (the old `beer_per_km/tts_lines.py` way): it multiplies calls and breaks the intonation.
3. **Fetch without searching.** TTS1 returns `file_id` and `size` in its output when available; otherwise one
   `search_files` with `title = '<name>' and parentId = '1A04ai2ai6iUq5fkz2mH5t4meqCH8U1k9'`.
   Then `download_file_content` and `python3 /home/claude/tts_api/sse_parse.py <saved file> <out_prefix>`
   (it accepts the raw blob or the JSON wrapper via `daily_1101/grab_raw.py`).
4. **Long reel, or the Drive tool chokes: the GitHub path (no size limit).**
   - Make IG3 (scenario 4985693) with `{"drive_file_id": "<file_id>"}` makes that one file viewable by link
     (the TTS folder itself is shared with the expressenglish.co.il domain only).
   - `python3 /home/claude/reelkit/cloud_voice.py pull <name>.txt <file_id>` appends to `voice/drive.txt` in
     reels-drop; fetch.yml downloads it on GitHub, parses the SSE and commits `voice/<name>.wav` +
     `voice/<name>_words.json`. Tested 1 Nov: about 3 min round trip.
   - A file that is not link-viewable comes back as `voice/<name>.err`.
5. Do not change the Make scenario. Never read data store 94072 and never print the Cartesia key.
