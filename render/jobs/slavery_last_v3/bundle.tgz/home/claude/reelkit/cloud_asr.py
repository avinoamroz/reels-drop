#!/usr/bin/env python3
"""Read the cloud ASR of a GitHub render and score it against the script.

render.yml transcribes every good render on the GitHub machine (faster-whisper small.en, word timestamps)
and commits render/done/<id>.asr.json + <id>.asr.txt with the mp4. No local whisper, no ASR lock queue.

  python3 cloud_asr.py <id> [--script tts.txt] [--timeout 1800] [--min 0.8] [--json out.json]

Waits (git pull every 20 s) for render/done/<id>.json, prints the transcript, and with --script prints a
per-line match score (share of the line's words found, in order, in the transcript, after normalising case,
punctuation and numbers) plus the time span where each line is heard. Lines under --min are flagged MISS.
Exit code 0 = all lines at or above --min (or no script given), 2 = some lines below, 3 = no transcript.
Also prints any clip transcripts (render/done/<id>.asr_<lang>.txt) from --asr-lang/--asr-clips jobs.
Importable: from cloud_asr import fetch, score.
"""
import argparse, difflib, json, os, re, subprocess, sys, time

REPO = "/home/claude/reels-drop"
DONE = os.path.join(REPO, "render/done")
try:
    from num2words import num2words
except Exception:
    num2words = None


def pull():
    subprocess.run(["git", "-C", REPO, "pull", "-q", "--rebase", "--autostash"], capture_output=True)


def fetch(i, timeout=1800, wait=True):
    """-> (asr dict or None, done dict or None). Waits for the render result commit."""
    t0 = time.time()
    while True:
        d = os.path.join(DONE, i + ".json")
        if os.path.exists(d):
            a = os.path.join(DONE, i + ".asr.json")
            return (json.load(open(a)) if os.path.exists(a) else None), json.load(open(d))
        if not wait or time.time() - t0 > timeout:
            return None, None
        pull(); time.sleep(20)


def _num(tok):
    if num2words and re.fullmatch(r"\d+(\.\d+)?", tok):
        try:
            return num2words(float(tok) if "." in tok else int(tok)).replace("-", " ").replace(",", "").split()
        except Exception:
            pass
    return [tok]


def norm(text):
    t = text.lower().replace("’", "'").replace("%", " percent").replace("&", " and ")
    t = re.sub(r"won't", "will not", t); t = re.sub(r"can't", "can not", t); t = re.sub(r"n't\b", " not", t)
    for c, e in (("'re", " are"), ("'ve", " have"), ("'ll", " will"), ("'m", " am"), ("'d", " would")):
        t = re.sub(c + r"\b", e, t)
    t = re.sub(r"(?<=\d),(?=\d{3})", "", t)           # 1,000 -> 1000
    t = re.sub(r"[^\w\s.']|(?<!\d)\.|\.(?!\d)", " ", t)  # keep decimals and apostrophes
    t = t.replace("'", "").replace("-", " ").replace("_", " ")
    out = []
    for tok in t.split():
        out += _num(tok)
    return out


def score(asr, script_lines):
    """per script line: {'line','score','found','words','start','end'}"""
    hw, ht = [], []
    for s in asr["segments"]:
        ws = s.get("words") or [{"w": s["text"], "s": s["s"], "e": s["e"]}]
        for w in ws:
            for t in norm(w["w"]):
                hw.append(t); ht.append((w["s"], w["e"]))
    sw, owner = [], []
    for k, l in enumerate(script_lines):
        for t in norm(l):
            sw.append(t); owner.append(k)
    hit = [None] * len(sw)
    sm = difflib.SequenceMatcher(None, sw, hw, autojunk=False)
    for a, b, n in sm.get_matching_blocks():
        for x in range(n):
            hit[a + x] = b + x
    res = []
    for k, l in enumerate(script_lines):
        idx = [x for x in range(len(sw)) if owner[x] == k]
        found = [hit[x] for x in idx if hit[x] is not None]
        res.append({"line": l, "words": len(idx), "found": len(found),
                    "score": round(len(found) / len(idx), 2) if idx else 1.0,
                    "start": ht[min(found)][0] if found else None, "end": ht[max(found)][1] if found else None})
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("id"); ap.add_argument("--script"); ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--min", type=float, default=0.8); ap.add_argument("--json"); ap.add_argument("--no-wait", action="store_true")
    a = ap.parse_args()
    asr, done = fetch(a.id, a.timeout, not a.no_wait)
    if done is None:
        print(f"no result yet for {a.id}; see https://github.com/avinoamroz/reels-drop/actions"); sys.exit(3)
    if asr is None:
        err = os.path.join(DONE, a.id + ".asr.err")
        why = open(err).read()[-1500:] if os.path.exists(err) else ("render failed" if not done.get("ok") else "ASR step skipped or failed")
        print(f"no cloud transcript for {a.id}: {why}\nrun https://github.com/avinoamroz/reels-drop/actions/runs/{done.get('run')}"); sys.exit(3)
    print(f"# {a.id}: {asr['duration']} s, model {asr['model']}, lang {asr['lang']}  ({DONE}/{a.id}.asr.json)")
    for s in asr["segments"]:
        print(f"[{s['s']:6.2f} {s['e']:6.2f}] {s['text']}")
    for f in sorted(os.listdir(DONE)):
        if f.startswith(a.id + ".asr_") and f.endswith(".txt"):
            print(f"\n# clips: {DONE}/{f}\n" + open(os.path.join(DONE, f)).read().rstrip())
    rc = 0
    if a.script:
        lines = [l.strip() for l in open(a.script, encoding="utf-8") if l.strip()]
        res = score(asr, lines)
        print(f"\n# script match ({a.script}), flag under {a.min}")
        for k, r in enumerate(res, 1):
            flag = "ok  " if r["score"] >= a.min else "MISS"
            span = f"{r['start']:6.2f} {r['end']:6.2f}" if r["start"] is not None else "   not heard  "
            print(f"{flag} {k:2d} {r['score']:.2f} [{span}] {r['line']}")
        tot = sum(r["found"] for r in res) / max(1, sum(r["words"] for r in res))
        print(f"overall {tot:.2f}")
        if any(r["score"] < a.min for r in res):
            rc = 2
        if a.json:
            json.dump({"id": a.id, "overall": round(tot, 3), "lines": res}, open(a.json, "w"), indent=1, ensure_ascii=False)
    sys.exit(rc)


if __name__ == "__main__":
    main()
