#!/usr/bin/env python3
"""Fetch photos the container cannot reach (Wikimedia Commons, LOC, GPO, US gov) through GitHub.

  python3 cloud_photos.py NAME URL [NAME URL ...] [--timeout 900] [--force]
  python3 cloud_photos.py --file list.txt          (lines "name url")

Appends "name url" to photos/list.txt in /home/claude/reels-drop, pushes, and the photos.yml workflow
downloads each url, resizes to max 1920 px (JPEG q88) and commits photos/<name>.jpg plus photos/<name>.json
(license, author and a ready credit_line from the Commons API when the url is Commons). Then this pulls and
prints the local paths and credits. Names: letters, digits, _ and - only. A name already fetched with the same
url is reused at once; a new url for an existing name needs --force.
Importable: from cloud_photos import fetch; fetch([("tlv_1930", url)]) -> [{"name","path","ok","credit_line",...}]
Commons urls can be a File: page, an upload.wikimedia.org link, or a Wikipedia #/media/File: link.
"""
import argparse, json, os, re, subprocess, sys, time

REPO = "/home/claude/reels-drop"
LIST = os.path.join(REPO, "photos/list.txt")
SIGN = "\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_01D8gF2iekadnzKcdJnCPGVX"


def git(*a, check=True):
    return subprocess.run(["git", "-C", REPO, *a], check=check, capture_output=True, text=True)


def _meta(name):
    p = os.path.join(REPO, "photos", name + ".json")
    try:
        return json.load(open(p))
    except Exception:
        return None


def _ready(name, url):
    m = _meta(name)
    return m if m and m.get("url") == url and (m.get("ok") is False or os.path.exists(os.path.join(REPO, "photos", name + ".jpg"))) else None


def fetch(pairs, timeout=900, force=False):
    for n, u in pairs:
        if not re.fullmatch(r"[A-Za-z0-9_-]+", n):
            sys.exit(f"bad name {n!r}: use letters, digits, _ and -")
    git("pull", "-q", "--rebase", "--autostash", check=False)
    os.makedirs(os.path.dirname(LIST), exist_ok=True)
    cur = [l.rstrip("\n") for l in open(LIST, encoding="utf-8")] if os.path.exists(LIST) else []
    have = {l.split()[0]: l.split(None, 1)[1].strip() for l in cur if len(l.split()) >= 2 and not l.startswith("#")}
    todo = [(n, u) for n, u in pairs if not _ready(n, u)]
    for n, u in todo:
        if n in have and have[n] != u and not force:
            sys.exit(f"{n} is already listed with another url ({have[n]}); pick a new name or pass --force")
    if todo:
        keep = [l for l in cur if not (len(l.split()) >= 2 and l.split()[0] in {n for n, _ in todo})]
        open(LIST, "w", encoding="utf-8").write("\n".join(keep + [f"{n} {u}" for n, u in todo]) + "\n")
        git("add", LIST)
        git("-c", "user.name=Noam Roz", "-c", "user.email=noam@expressenglish.co.il", "commit", "-q", "-m",
            "Photos: " + " ".join(n for n, _ in todo) + SIGN)
        for i in range(6):
            if git("push", "-q", check=False).returncode == 0:
                break
            git("pull", "-q", "--rebase", "--autostash", check=False); time.sleep(5)
        else:
            sys.exit("push failed")
        print("pushed; GitHub photos.yml is downloading:", " ".join(n for n, _ in todo), flush=True)
    t0, left = time.time(), dict(todo)
    while left and time.time() - t0 < timeout:
        time.sleep(15)
        git("pull", "-q", "--rebase", "--autostash", check=False)
        for n in list(left):
            if _ready(n, left[n]):
                left.pop(n)
    out = []
    for n, u in pairs:
        m = _meta(n) if n not in left else None
        if not m:
            out.append({"name": n, "url": u, "ok": False, "error": "timed out, see https://github.com/avinoamroz/reels-drop/actions/workflows/photos.yml"}); continue
        m = dict(m); m["path"] = os.path.join(REPO, "photos", n + ".jpg") if m.get("ok") else None
        out.append(m)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pairs", nargs="*"); ap.add_argument("--file"); ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--force", action="store_true"); ap.add_argument("--json")
    a = ap.parse_args()
    toks = a.pairs + (open(a.file).read().split() if a.file else [])
    if not toks or len(toks) % 2:
        sys.exit(__doc__)
    res = fetch(list(zip(toks[::2], toks[1::2])), a.timeout, a.force)
    for r in res:
        if r.get("ok"):
            print(f"OK   {r['name']}: {r['path']} {r.get('size')}\n     credit: {r.get('credit_line') or r.get('source')}  license: {r.get('license')}  {r.get('page') or r.get('url')}")
        else:
            print(f"FAIL {r['name']}: {r.get('error')}")
    if a.json:
        json.dump(res, open(a.json, "w"), indent=1, ensure_ascii=False)
    sys.exit(0 if all(r.get("ok") for r in res) else 2)


if __name__ == "__main__":
    main()
