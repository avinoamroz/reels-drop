#!/usr/bin/env bash
# cleanup.sh: free disk on the shared box. SAFE to run while other agents work.
#   bash /home/claude/reelkit/cleanup.sh            (do it)
#   bash /home/claude/reelkit/cleanup.sh --dry-run  (only list what would go)
# Deletes ONLY:
#   1. /tmp/claude-0/asr/*.wav older than 2 h (top level only; the whisper models stay)
#   2. reels-drop render/out/*_540.mp4 previews older than 24 h (git rm, the full <id>.mp4 stays)
#   3. work/ and tts/ folders inside /home/claude build dirs whose newest file is older than 24 h,
#      only when that build's final mp4 is already in reels-drop (or render/out)
#   4. reels-drop render/jobs/<id> folders older than 6 h (by mtime; git log is useless in a shallow clone)
# 2 and 4 go out as ONE "[skip ci]" commit, pushed only when no other agent has unpushed local commits.
# Never touches anything modified in the last 2 h. NEVER runs git prune, git gc or reflog expire.
set -u
DRY=0; [ "${1:-}" = "--dry-run" ] && DRY=1
REPO=/home/claude/reels-drop
avail() { df --output=avail -B1 /home/claude | tail -1; }
A0=$(avail); FREED=0
gone() { # path: add its size, delete it
  local s; s=$(du -sb "$1" 2>/dev/null | cut -f1); FREED=$(( FREED + ${s:-0} ))
  echo "  rm $1 ($(( ${s:-0} >> 20 )) MB)"
  [ $DRY = 1 ] || rm -rf -- "$1"
}

echo "1. ASR temp wavs older than 2 h"
find /tmp/claude-0/asr -maxdepth 1 -type f -name '*.wav' -mmin +120 2>/dev/null | while read -r f; do gone "$f"; done
# (the while loop runs in a subshell, so recount below from df)

echo "3. work/ and tts/ in finished builds, idle 24 h"
python3 - "$DRY" <<'EOF'
import os, sys, glob, shutil, time
dry = sys.argv[1] == "1"; H = "/home/claude"; R = H + "/reels-drop"; now = time.time()
def newest(d):
    m = os.path.getmtime(d)
    for root, ds, fs in os.walk(d):
        for x in fs + ds:
            try: m = max(m, os.lstat(os.path.join(root, x)).st_mtime)
            except OSError: pass
    return m
def size(d):
    t = 0
    for root, ds, fs in os.walk(d):
        for f in fs:
            try: t += os.lstat(os.path.join(root, f)).st_size
            except OSError: pass
    return t
# which mp4s a job id produced, from job.json "out" (jobs still in the repo)
outs = {}
for j in glob.glob(R + "/render/jobs/*/job.json"):
    try:
        import json; o = json.load(open(j)); outs.setdefault(os.path.dirname(o["out"]), set()).add(o["id"])
    except Exception: pass
def has_mp4(name):
    return bool(glob.glob(f"{R}/{glob.escape(name)}.mp4") or glob.glob(f"{R}/{glob.escape(name)}_*.mp4")
                or glob.glob(f"{R}/render/out/{glob.escape(name)}*_540.mp4"))
tot = 0
for top in sorted(os.listdir(H)):
    B = os.path.join(H, top)
    if top in ("reels-drop", "reelkit") or top.startswith(".") or not os.path.isdir(B) or os.path.islink(B):
        continue
    for root, ds, fs in os.walk(B):
        if root.count(os.sep) - B.count(os.sep) >= 4:
            ds[:] = []; continue
        for d in list(ds):
            if d not in ("work", "tts"):
                continue
            ds.remove(d)  # never descend into it (work/work etc.)
            p = os.path.join(root, d)
            if os.path.islink(p) or now - newest(p) < 24 * 3600:
                continue
            parent = os.path.basename(root)
            names = {top, parent, f"{top}_{parent}"} - {"out", "build"}
            ids = set().union(*[outs.get(x, set()) for x in outs if x.startswith(B + "/")]) if outs else set()
            if not any(has_mp4(n) for n in names | ids):
                continue
            s = size(p); tot += s
            print(f"  rm {p} ({s >> 20} MB)")
            if not dry: shutil.rmtree(p, ignore_errors=True)
print(f"  build folders: {tot >> 20} MB")
EOF

echo "2+4. old previews and render job folders (one [skip ci] commit)"
cd "$REPO" || exit 1
if [ -e .git/index.lock ]; then
  echo "  git busy (index.lock), skipping repo cleanup this time"
else
  RM=()
  while read -r f; do RM+=("$f"); done < <(git ls-files 'render/out/*_540.mp4' | while read -r f; do
      [ -f "$f" ] && [ -n "$(find "$f" -mmin +1440)" ] && echo "$f"; done)
  for d in render/jobs/*/; do
    d=${d%/}; [ -d "$d" ] || continue
    [ -n "$(git ls-files "$d" | head -1)" ] || continue          # untracked: maybe being sent right now
    [ -n "$(find "$d" -mmin -360 | head -1)" ] && continue         # anything touched in the last 6 h
    RM+=("$d")
  done
  echo "  ${#RM[@]} paths"
  if [ ${#RM[@]} -gt 0 ]; then
    S=$(du -sbc "${RM[@]}" 2>/dev/null | tail -1 | cut -f1); echo "  $(( ${S:-0} >> 20 )) MB in previews and job bundles"
    if [ $DRY = 0 ]; then
      git pull -q --rebase --autostash
      if [ -n "$(git log --oneline @{u}..HEAD 2>/dev/null)" ]; then
        echo "  another agent has unpushed commits; not committing now (rerun later)"
      else
        git rm -r -q --ignore-unmatch -- "${RM[@]}"
        git -c user.name="Noam Roz" -c user.email="noam@expressenglish.co.il" commit -q -m "Cleanup: render jobs older than 6 h, previews older than 24 h [skip ci]

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01D8gF2iekadnzKcdJnCPGVX" -- "${RM[@]}"
        for i in 1 2 3 4 5 6; do git pull -q --rebase --autostash && git push -q && break; sleep $(( (RANDOM % 6) + 4 )); done
        [ -n "$(git log --oneline @{u}..HEAD 2>/dev/null)" ] && echo "  WARNING: cleanup commit not pushed yet; run: git -C $REPO pull --rebase --autostash && git -C $REPO push"
      fi
    fi
  fi
fi

A1=$(avail)
echo "free before $(( A0 >> 20 )) MB, after $(( A1 >> 20 )) MB, freed $(( (A1 - A0) >> 20 )) MB"
