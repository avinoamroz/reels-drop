#!/usr/bin/env python3
"""ovl6.py cfg.json [--preview t1,t2,...]: Launch Map fix batch 6 (1 Nov). Wraps /home/claude/fix5/ovl.py (same inserts,
frame-identical outside the inserts, audio copied) and adds, for map inserts:
  labels  [{lon,lat,en,at,until,sz,kind}]  text-only place labels (kind "country": caps navy, no dot; "sea": italic blue)
  arrows  [... , "en": label at the arrow's middle, "w": width]   labelled movement arrows
  compass true                                                    small N arrow in the panel's top-right corner
  rings   [{lon,lat,at,until,color}]                              pulsing find-spot rings (no label)
cfg "src_url": if cfg "src" is missing (cloud machine), it is downloaded first."""
import json, math, os, sys, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ovl5 as O
import cairo
from kit import St, ramp
import render as RD, kit

_orig_draw = O.MapInsert.draw
NAVY, WHITE, SKY = O.NAVY, O.WHITE, O.SKY

def _M(s, t):
    d = s.d; x0, y0, x1, y1 = d["rect"]; u = ramp(t, d["t0"], d["t1"]); z = O.lerp(1.0, d.get("zoom", 1.06), u)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    use2 = s.base2 is not None and t >= d.get("view_to_at", 1e9)
    base, pr = (s.base2, s.pr2) if use2 else (s.base, s.pr); sc_ = z / s.ov
    def M(lon, lat):
        px, py = pr.P(lon, lat); return cx + (px - base.get_width() / 2) * sc_, cy + (py - base.get_height() / 2) * sc_
    return M

def _vis(t, it, t0, a):
    ta = it.get("at", t0 + 0.2); u = ramp(t, ta, ta + 0.3) * a
    if it.get("until") and t > it["until"]: u *= 1 - ramp(t, it["until"], it["until"] + 0.3)
    return u

def draw(s, c, t, a):
    d = s.d
    M = _M(s, t); x0, y0, x1, y1 = d["rect"]
    # pin labels stay inside the panel: flip left/right, else above/below
    for p in d.get("pins", []):
        if not p.get("en"): continue
        if "_side0" not in p: p["_side0"] = p.get("side", "r")
        px, py = M(p["lon"], p["lat"]); sz = p.get("sz", 40); w = kit.font(sz, 800).getlength(p["en"]) + sz * 1.1
        side = p["_side0"]
        if side == "r" and px + 30 + w > x1 - 8: side = "l"
        if side == "l" and px - 30 - w < x0 + 8: side = "r" if px + 30 + w <= x1 - 8 else ("d" if py < (y0 + y1) / 2 else "u")
        if side in ("u", "d") and (px - w / 2 < x0 + 8 or px + w / 2 > x1 - 8):
            p["_shift"] = True
        p["side"] = side
    credit = d.pop("credit", None); d["_credit"] = credit or d.get("_credit")
    _orig_draw(s, c, t, a)
    if d.get("_credit"):
        RD.T(c, d["_credit"], 36, x1 - 24, y1 - 34, NAVY, a * 0.85, 1, 700, anchor="r", maxw=420)
    c.save(); O.rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    for r in d.get("rings", []):
        u = _vis(t, r, d["t0"], a)
        if u <= 0.01: continue
        px, py = M(r["lon"], r["lat"]); colr = kit.hx(r.get("color", "#D63A4A"))
        for k in range(2):
            ph = ((t - r.get("at", d["t0"])) * 0.8 + k * 0.5) % 1.0
            c.arc(px, py, 18 + 46 * ph, 0, 2 * math.pi); c.set_source_rgba(colr[0], colr[1], colr[2], u * (1 - ph)); c.set_line_width(5); c.stroke()
    for lb in d.get("labels", []):
        u = _vis(t, lb, d["t0"], a)
        if u <= 0.01: continue
        px, py = M(lb["lon"], lb["lat"]); kind = lb.get("kind", "country"); sz = lb.get("sz", 40)
        if kind == "sea":
            RD.T(c, lb["en"], sz, px, py, kit.hx("#2A6FB0"), u, 1, 700, maxw=600)
        else:
            f = kit.font(sz, 900); tw = f.getlength(lb["en"])
            O.sa(c, WHITE, 0.72 * u); O.rr(c, px - tw / 2 - 12, py - sz * 0.62, tw + 24, sz * 1.25, 12); c.fill()
            RD.T(c, lb["en"], sz, px, py, NAVY, u, 1, 900, maxw=700)
    c.restore()
    for ar in d.get("arrows", []):
        if not ar.get("en"): continue
        ta = ar.get("at", d["t0"] + 0.3); u = ramp(t, ta + 0.5, ta + 0.8) * a
        if ar.get("until") and t > ar["until"]: u *= 1 - ramp(t, ar["until"], ar["until"] + 0.3)
        if u <= 0.01: continue
        (ax, ay), (bx, by) = M(*ar["a"]), M(*ar["b"])
        mx, my = (ax + bx) / 2, (ay + by) / 2; nx, ny = -(by - ay), bx - ax; L = math.hypot(nx, ny) or 1
        bend = ar.get("bend", 0.18); qx, qy = mx + nx * bend, my + ny * bend
        lx, ly = 0.25 * ax + 0.5 * qx + 0.25 * bx, 0.25 * ay + 0.5 * qy + 0.25 * by
        dx, dy = ar.get("lab_off", [0, 0])
        colr = kit.hx(ar.get("color", "#D63A4A"))
        O.pill_at(c, ar["en"], ar.get("sz", 38), lx + dx, ly + dy, u, bg=colr, fg=WHITE, outline=WHITE)
    if d.get("compass"):
        cx, cy = x1 - 52, y0 + 58; u = a
        c.set_source_rgba(1, 1, 1, 0.9 * u); c.arc(cx, cy + 6, 36, 0, 2 * math.pi); c.fill()
        c.set_source_rgba(*NAVY[:3], u); c.move_to(cx, cy - 26); c.line_to(cx + 12, cy + 2); c.line_to(cx - 12, cy + 2); c.close_path(); c.fill()
        RD.T(c, "N", 36, cx, cy + 22, NAVY, u, 1, 900, maxw=60)
O.MapInsert.draw = draw
_orig_frame = O.draw_frame
def draw_frame(c, src_surf, t, inserts):
    for d in inserts:   # shiftf: move a band of the original frame by dy, feathered at its leading edge
        if d["kind"] != "shiftf" or not (d["t0"] <= t <= d["t1"]): continue
        e = d.get("ease", 0.35); u = O.ease(ramp(t, d["t0"], d["t0"] + e)) * (1 - O.ease(ramp(t, d["t1"] - e, d["t1"])))
        if u <= 0.001: continue
        y0, y1 = d["band"]; dy = d["dy"] * u; fe = d.get("feather", 160)
        S2 = cairo.ImageSurface(cairo.FORMAT_ARGB32, O.W, O.H); c2 = cairo.Context(S2)
        c2.set_source_surface(src_surf, 0, 0); c2.paint()
        g = cairo.LinearGradient(0, y0 + dy, 0, y0 + dy + fe); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0, 0, 0, 1)
        c2.save(); c2.rectangle(0, y0 + dy, O.W, y1 - y0); c2.clip(); c2.set_source_surface(src_surf, 0, dy); c2.mask(g); c2.restore()
        c2.save(); c2.rectangle(0, y0 + dy + fe, O.W, y1 - y0 - fe); c2.clip(); c2.set_source_surface(src_surf, 0, dy); c2.paint(); c2.restore()
        S2.flush(); src_surf = S2
    _orig_frame(c, src_surf, t, inserts)
    for d in inserts:   # patch: cover a rect with pixels of the same frame from a clean area (dx shift)
        if d["kind"] != "patch" or not (d["t0"] <= t <= d["t1"]): continue
        x0, y0, x1, y1 = d["rect"]; c.save(); c.rectangle(x0, y0, x1 - x0, y1 - y0); c.clip()
        c.set_source_surface(src_surf, -d["dx"], 0); c.paint(); c.restore()
O.draw_frame = draw_frame

if __name__ == "__main__":
    a = sys.argv[1:]; cfg = json.load(open(a[0]))
    if not os.path.exists(cfg["src"]) and cfg.get("src_url"):
        os.makedirs(os.path.dirname(cfg["src"]), exist_ok=True); urllib.request.urlretrieve(cfg["src_url"], cfg["src"])
    os.makedirs(os.path.dirname(cfg["out"]), exist_ok=True)
    if len(a) > 2 and a[1] == "--preview": O.main(a[0], [float(x) for x in a[2].split(",")])
    else: O.main(a[0])
