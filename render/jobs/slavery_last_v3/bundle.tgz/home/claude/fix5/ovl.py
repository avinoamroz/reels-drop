#!/usr/bin/env python3
"""ovl.py cfg.json: Launch Map fix batch 5 (1 Nov). Composites animated map panels and real-photo panels onto an
existing reel (the version Noam watched), so everything else stays frame-identical. Audio is copied untouched.
Map: Natural Earth 1:50m (public domain). The whole land of Israel is gold (incl. Golan); Judea/Samaria and Gaza a
slightly different gold (#B8923F) with the Green Line in green (46,204,113). Scale bars in kilometers. Labels 36 px+.
Insert kinds:
  map    {t0,t1,rect,view:[lon0,lat0,lon1,lat1], view_to, hl:[{iso|circle:[lon,lat,km], color, at}], pins:[{lon,lat,en,at,side}],
          arrows:[{a:[lon,lat], b:[lon,lat], at, color}], chip, chip_at, credit}
  photo  {t0,t1,rect,src,credit,zoom:[1.0,1.08],caption}
  photos {t0,t1,rect,items:[{src,credit,at}]}  (cross-fading slideshow, each photo from its 'at')
  shift  {t0,t1,band:[y0,y1],dy}  (moves a band of the original frame, eased in/out over 'ease' s)
  cover  {t0,t1,rect,color}       (plain fill; only on flat backgrounds)
Every insert fades/scales in over 0.3 s and out over 0.25 s unless fade=false."""
import json, math, os, subprocess, sys
import numpy as np, cairo
sys.path.insert(0, "/home/claude/reelkit")
import render as RD, kit
from kit import St, sa, rr, ease, ramp, lerp
from PIL import Image, ImageOps, ImageDraw
W, H, FPS = 1080, 1920, 30
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
GOLD_IL = kit.hx("#C9A44C"); GOLD_PS = kit.hx("#B8923F"); GREEN = (46 / 255, 204 / 255, 113 / 255, 1)
SEA = kit.hx("#CFE2F1"); LAND = kit.hx("#F4F1EA"); BORDER = kit.hx("#B5BDC8"); NAVY = kit.hx("#163261"); SKY = kit.hx("#45A4DD")
RED = kit.hx("#D63A4A"); WHITE = kit.hx("#FFFFFF"); YEL = kit.hx("#F5C518")
_G = {}
def geo():
    if not _G:
        from shapely.geometry import shape
        for f in json.load(open(GEO))["features"]:
            p = f["properties"]; iso = p.get("ISO_A2") if p.get("ISO_A2") not in (None, "-99") else p.get("ADM0_A3")
            _G[iso] = shape(f["geometry"])
        _G["FR"] = _G.get("FR") or _G.get("FRA"); _G["NO"] = _G.get("NO") or _G.get("NOR")
    return _G

class Proj:
    """equirectangular with cos(lat) correction; view fitted (cover) into a w x h panel"""
    def __init__(s, view, w, h, fit='cover'):
        lon0, lat0, lon1, lat1 = view; s.cos = math.cos(math.radians((lat0 + lat1) / 2))
        s.cx, s.cy = (lon0 + lon1) / 2, (lat0 + lat1) / 2
        s.k = (max if fit == 'cover' else min)(w / ((lon1 - lon0) * s.cos), h / (lat1 - lat0)); s.w, s.h = w, h
    def P(s, lon, lat): return (s.w / 2 + (lon - s.cx) * s.cos * s.k, s.h / 2 - (lat - s.cy) * s.k)
    def km_px(s): return s.k / 111.32   # px per km (north-south)

def _rings(g, pr, tol):
    from shapely.geometry import box as sbox
    lon0 = pr.cx - pr.w / 2 / (pr.cos * pr.k) - 2; lon1 = pr.cx + pr.w / 2 / (pr.cos * pr.k) + 2
    lat0 = pr.cy - pr.h / 2 / pr.k - 2; lat1 = pr.cy + pr.h / 2 / pr.k + 2
    vb = sbox(lon0, lat0, lon1, lat1)
    if not g.intersects(vb): return []
    g = g.intersection(vb).simplify(tol / pr.k)
    ps = [g] if g.geom_type == "Polygon" else [p for p in getattr(g, "geoms", []) if p.geom_type == "Polygon"]
    return [[pr.P(x, y) for x, y in p.exterior.coords] for p in ps if not p.is_empty]
def _path(c, rings):
    for r in rings:
        c.move_to(*r[0])
        for x, y in r[1:]: c.line_to(x, y)
        c.close_path()

def base_map(view, w, h, hl_static=(), fit='cover'):
    """sea, land, borders, the whole land of Israel in gold with the Green Line"""
    G = geo(); pr = Proj(view, w, h, fit); s = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(w), int(h)); c = cairo.Context(s)
    c.set_source_rgb(*SEA[:3]); c.paint()
    tol = 0.5
    for k, g in G.items():
        if k in ("IL", "PS"): continue
        rg = _rings(g, pr, tol)
        if not rg: continue
        _path(c, rg); c.set_source_rgb(*LAND[:3]); c.fill_preserve(); c.set_source_rgb(*BORDER[:3]); c.set_line_width(1.6); c.stroke()
    for k, colr in (("IL", GOLD_IL), ("PS", GOLD_PS)):
        rg = _rings(G[k], pr, 0.25)
        if rg: _path(c, rg); c.set_source_rgb(*colr[:3]); c.fill()
    rg = _rings(G["PS"], pr, 0.2)
    if rg: _path(c, rg); c.set_source_rgba(*GREEN); c.set_line_width(max(2.5, min(5, pr.k / 60))); c.stroke()
    return s, pr

def _nice_km(px_per_km, target_px=170):
    v = target_px / px_per_km
    for n in (5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000):
        if n >= v * 0.6: return n
    return 5000

def pill_at(c, txt, sz, x, y, a, bg=WHITE, fg=NAVY, outline=NAVY, anchor="c"):
    f = kit.font(sz, 800); tw = f.getlength(txt); pw = tw + sz * 1.1; ph = sz * 1.45
    if anchor == "l": x = x + pw / 2
    elif anchor == "r": x = x - pw / 2
    old = St.a; St.a = a
    sa(c, NAVY, 0.18); rr(c, x - pw / 2, y - ph / 2 + 6, pw, ph, ph / 2); c.fill()
    kit.box(c, x - pw / 2, y - ph / 2, pw, ph, ph / 2, bg, 1, stroke=outline, sw=4)
    St.a = old
    RD.T(c, txt, sz, x, y + 2, fg, a, 1, 800, maxw=1000)
    return pw

class MapInsert:
    def __init__(s, d):
        s.d = d; x0, y0, x1, y1 = d["rect"]; s.w, s.h = x1 - x0, y1 - y0; s.ov = 1.12   # render oversize for the slow zoom
        s.base, s.pr = base_map(d["view"], s.w * s.ov, s.h * s.ov, fit=d.get("fit", "cover"))
        s.base2 = None
        if d.get("view_to"): s.base2, s.pr2 = base_map(d["view_to"], s.w * s.ov, s.h * s.ov)
        G = geo(); s.hl = []
        for h_ in d.get("hl", []):
            if "iso" in h_:
                g = G[h_["iso"]]
                if h_.get("part"):
                    ps = list(getattr(g, "geoms", [g]))
                    ps = [p for p in ps if (p.centroid.x < 34.6) == (h_["part"] == "gaza")]
                    from shapely.geometry import MultiPolygon
                    g = MultiPolygon(ps) if len(ps) > 1 else ps[0]
                s.hl.append(("poly", h_, g))
            else: s.hl.append(("circle", h_, None))
    def draw(s, c, t, a):
        d = s.d; x0, y0, x1, y1 = d["rect"]; t0, t1 = d["t0"], d["t1"]
        u = ramp(t, t0, t1); z = lerp(1.0, d.get("zoom", 1.06), u)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        St.a = 1.0
        sa(c, NAVY, 0.16 * a); rr(c, x0 + 3, y0 + 14, s.w, s.h, 30); c.fill()
        c.save(); rr(c, x0, y0, s.w, s.h, 30); c.clip()
        use2 = s.base2 is not None and t >= d.get("view_to_at", 1e9)
        base, pr = (s.base2, s.pr2) if use2 else (s.base, s.pr)
        sc_ = z / s.ov
        def M(lon, lat):
            px, py = pr.P(lon, lat); return cx + (px - base.get_width() / 2) * sc_, cy + (py - base.get_height() / 2) * sc_
        c.save(); c.translate(cx, cy); c.scale(sc_, sc_); c.translate(-base.get_width() / 2, -base.get_height() / 2)
        c.set_source_surface(base, 0, 0); c.paint_with_alpha(a)
        if use2 and t < d["view_to_at"] + 0.35:   # cross-fade from the first view
            c.set_source_surface(s.base, 0, 0); c.paint_with_alpha(a * (1 - ramp(t, d["view_to_at"], d["view_to_at"] + 0.35)))
        c.restore()
        # highlights
        for kind, h_, g in s.hl:
            ta = h_.get("at", t0 + 0.2); ua = ramp(t, ta, ta + 0.35) * a
            if h_.get("until") and t > h_["until"]: ua *= 1 - ramp(t, h_["until"], h_["until"] + 0.3)
            if ua <= 0.01: continue
            colr = kit.hx(h_.get("color", "#D63A4A"))
            if kind == "poly":
                rg = [[M(*pr_inv) for pr_inv in ring] for ring in _lonlat_rings(g, pr)]
                _path(c, rg); c.set_source_rgba(colr[0], colr[1], colr[2], 0.55 * ua); c.fill_preserve()
                c.set_source_rgba(colr[0], colr[1], colr[2], ua); c.set_line_width(3); c.stroke()
            else:
                lon, lat, km = h_["circle"]; px, py = M(lon, lat); r = km * pr.km_px() * sc_
                pulse = 1 + 0.06 * math.sin((t - ta) * 5)
                c.arc(px, py, r * pulse, 0, 2 * math.pi); c.set_source_rgba(colr[0], colr[1], colr[2], 0.38 * ua); c.fill_preserve()
                c.set_source_rgba(colr[0], colr[1], colr[2], 0.95 * ua); c.set_line_width(4); c.stroke()
        # lines (rivers, ranges), drawn progressively
        for ln in d.get("lines", []):
            ta = ln.get("at", t0 + 0.3); ua = ramp(t, ta, ta + ln.get("dur", 0.9))
            if ua <= 0.01: continue
            pts = [M(*p) for p in ln["pts"]]; segs = [math.hypot(b[0]-a[0], b[1]-a[1]) for a, b in zip(pts, pts[1:])]; L_ = sum(segs) * ua
            colr = kit.hx(ln.get("color", "#2A88D4")); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
            for wdt, cc in ((ln.get("w", 9) + 6, (1, 1, 1, 0.85 * a)), (ln.get("w", 9), (colr[0], colr[1], colr[2], a))):
                c.set_source_rgba(*cc); c.set_line_width(wdt); c.move_to(*pts[0]); acc = 0
                for (p0, p1), sg in zip(zip(pts, pts[1:]), segs):
                    if acc + sg <= L_: c.line_to(*p1); acc += sg
                    else:
                        f = (L_ - acc) / sg if sg else 0; c.line_to(p0[0] + (p1[0]-p0[0]) * f, p0[1] + (p1[1]-p0[1]) * f); break
                c.stroke()
        # arrows
        for ar in d.get("arrows", []):
            ta = ar.get("at", t0 + 0.3); ua = ramp(t, ta, ta + 0.7)
            if ua <= 0.01: continue
            (ax, ay), (bx, by) = M(*ar["a"]), M(*ar["b"])
            mx, my = (ax + bx) / 2, (ay + by) / 2; nx, ny = -(by - ay), bx - ax; L = math.hypot(nx, ny) or 1
            bend = ar.get("bend", 0.18); qx, qy = mx + nx / L * L * bend, my + ny / L * L * bend
            pts = [((1 - v) ** 2 * ax + 2 * (1 - v) * v * qx + v * v * bx, (1 - v) ** 2 * ay + 2 * (1 - v) * v * qy + v * v * by) for v in np.linspace(0, ua, 40)]
            colr = kit.hx(ar.get("color", "#D63A4A"))
            c.set_source_rgba(*WHITE[:3], 0.9 * a); c.set_line_width(11); c.set_line_cap(cairo.LINE_CAP_ROUND)
            c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.stroke()
            c.set_source_rgba(colr[0], colr[1], colr[2], a); c.set_line_width(6)
            c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.stroke()
            if ua > 0.97:
                (px, py), (qx2, qy2) = pts[-1], pts[-4]; ang = math.atan2(py - qy2, px - qx2)
                c.move_to(px + 20 * math.cos(ang), py + 20 * math.sin(ang))
                c.line_to(px + 20 * math.cos(ang + 2.5), py + 20 * math.sin(ang + 2.5)); c.line_to(px + 20 * math.cos(ang - 2.5), py + 20 * math.sin(ang - 2.5))
                c.close_path(); c.fill()
        # scale bar (km)
        kmpx = pr.km_px() * sc_; n = _nice_km(kmpx); L = n * kmpx
        bx0, by0 = (x1 - L - 210, y1 - 40) if d.get('scale') == 'r' else (x0 + 34, y1 - 40)
        c.set_source_rgba(*NAVY[:3], 0.85 * a); c.set_line_width(6); c.move_to(bx0, by0); c.line_to(bx0 + L, by0); c.stroke()
        for xx in (bx0, bx0 + L): c.move_to(xx, by0 - 12); c.line_to(xx, by0 + 6); c.stroke()
        RD.T(c, f"{n:,} km", 36, bx0 + L + 14, by0 - 4, NAVY, a, 1, 800, anchor="l", maxw=300)
        c.restore()
        rr(c, x0, y0, s.w, s.h, 30); c.set_source_rgba(*NAVY[:3], a); c.set_line_width(6); c.stroke()
        # pins + labels (unclipped)
        for p in d.get("pins", []):
            ta = p.get("at", t0 + 0.3); up = ramp(t, ta, ta + 0.3) * a
            if p.get("until") and t > p["until"]: up *= 1 - ramp(t, p["until"], p["until"] + 0.3)
            if up <= 0.01: continue
            px, py = M(p["lon"], p["lat"]); colr = kit.hx(p.get("color", "#D63A4A"))
            bob = kit.pop(t, ta, 0.4, 0.3, 2.0)[1]
            r = 15 * bob
            c.arc(px, py, r + 5, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, up); c.fill()
            c.arc(px, py, r, 0, 2 * math.pi); c.set_source_rgba(colr[0], colr[1], colr[2], up); c.fill()
            if p.get("en"):
                side = p.get("side", "r"); sz = p.get("sz", 40); off = 30
                lx = {"r": px + off, "l": px - off, "u": px, "d": px}[side]; ly = {"u": py - 50, "d": py + 52}.get(side, py)
                anc = {"r": "l", "l": "r"}.get(side, "c")
                pill_at(c, p["en"], sz, lx, ly, up, anchor=anc, outline=colr)
        if d.get("chip"):
            ua = ramp(t, d.get("chip_at", t0), d.get("chip_at", t0) + 0.3) * a
            pill_at(c, d["chip"], 40, x0 + 30, y0 + 44, ua, bg=NAVY, fg=WHITE, outline=NAVY, anchor="l")
        if d.get("credit"):
            RD.T(c, d["credit"], 36, x1 - 24, y0 + 40, NAVY, a * 0.9, 1, 700, anchor="r", maxw=600)

def _lonlat_rings(g, pr):
    from shapely.geometry import box as sbox
    gg = g.simplify(0.02)
    ps = [gg] if gg.geom_type == "Polygon" else list(getattr(gg, "geoms", []))
    return [list(p.exterior.coords) for p in ps if p.geom_type == "Polygon"]

_IMG = {}
CROP = {}
def photo_surf(src, w, h):
    k = (src, int(w), int(h))
    if k not in _IMG:
        im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
        if CROP.get(src): a, b, c_, d_ = CROP[src]; im = im.crop((int(a * im.width), int(b * im.height), int(c_ * im.width), int(d_ * im.height)))
        im = ImageOps.fit(im, (int(w), int(h)), Image.LANCZOS)
        _IMG[k] = kit.pil2cairo(im.convert("RGBA"))
    return _IMG[k]

def draw_photo(c, d, it, t, a, t_start):
    x0, y0, x1, y1 = d["rect"]; w, h = x1 - x0, y1 - y0; ov = 1.10
    s = photo_surf(it["src"], w * ov, h * ov)
    u = ramp(t, t_start, t_start + max(2.5, d["t1"] - t_start)); z0, z1 = it.get("zoom", d.get("zoom", [1.0, 1.08]))
    z = lerp(z0, z1, u) / ov; dx, dy = it.get("pan", [0, 0])
    St.a = 1.0
    c.save(); rr(c, x0, y0, w, h, 30); c.clip()
    c.translate((x0 + x1) / 2 + dx * u, (y0 + y1) / 2 + dy * u); c.scale(z, z); c.translate(-s.get_width() / 2, -s.get_height() / 2)
    c.set_source_surface(s, 0, 0); c.paint_with_alpha(a); c.restore()
    c.save(); rr(c, x0, y0, w, h, 30); c.clip()
    g = cairo.LinearGradient(0, y1 - 150, 0, y1); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0, 0, 0, 0.62 * a)
    c.rectangle(x0, y1 - 150, w, 150); c.set_source(g); c.fill()
    if it.get("caption"):
        g = cairo.LinearGradient(0, y0, 0, y0 + 150); g.add_color_stop_rgba(0, 0, 0, 0, 0.55 * a); g.add_color_stop_rgba(1, 0, 0, 0, 0)
        c.rectangle(x0, y0, w, 150); c.set_source(g); c.fill()
    c.restore()
    if it.get("caption"): RD.T(c, it["caption"], it.get("cap_sz", 52), (x0 + x1) / 2, y0 + 56, WHITE, a, 1, 900, maxw=w - 60)
    if it.get("credit"): RD.T(c, it["credit"], 36, (x0 + x1) / 2, y1 - 36, WHITE, a, 1, 700, maxw=w - 40)
    return s

def draw_frame(c, src_surf, t, inserts):
    # shifts first (they move the original picture)
    shifted = False
    for d in inserts:
        if d["kind"] != "shift" or not (d["t0"] - 0.01 <= t <= d["t1"] + 0.01): continue
        e = d.get("ease", 0.35); u = ramp(t, d["t0"], d["t0"] + e) * (1 - ramp(t, d["t1"] - e, d["t1"])) if d.get("ease_out", True) else ramp(t, d["t0"], d["t0"] + e)
        if d.get("hold_start"): u = 1.0 if t < d["t1"] - e else 1 - ramp(t, d["t1"] - e, d["t1"])
        y0, y1 = d["band"]; dy = d["dy"] * u
        if not shifted:
            c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_surface(src_surf, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER); shifted = True
        # fill the band's old place with the background just outside it, then paint the band moved
        if dy < 0: c.save(); c.rectangle(0, y1 + dy, W, -dy); c.clip(); c.set_source_surface(src_surf, 0, dy); c.paint(); c.restore()
        elif dy > 0: c.save(); c.rectangle(0, y0, W, dy); c.clip(); c.set_source_surface(src_surf, 0, dy); c.paint(); c.restore()
        c.save(); c.rectangle(0, y0 + dy, W, y1 - y0); c.clip(); c.set_source_surface(src_surf, 0, dy); c.paint(); c.restore()
    if not shifted:
        c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_surface(src_surf, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
    for d in inserts:
        if d["kind"] == "shift" or not (d["t0"] <= t <= d["t1"]): continue
        a = 1.0
        if d.get("fade", True): a = ramp(t, d["t0"], d["t0"] + d.get("fin", 0.3)) * (1 - ramp(t, d["t1"] - d.get("fout", 0.25), d["t1"]))
        if a <= 0.01: continue
        x0, y0, x1, y1 = d.get("rect", (0, 0, 0, 0)); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        sc = lerp(0.94, 1.0, ease(min(1, (t - d["t0"]) / 0.3))) if d.get("fade", True) else 1.0
        c.save(); c.translate(cx, cy); c.scale(sc, sc); c.translate(-cx, -cy)
        if d["kind"] == "map": d["_o"].draw(c, t, a)
        elif d["kind"] == "photo": draw_photo(c, d, d, t, a, d["t0"])
        elif d["kind"] == "photos":
            its = d["items"]; k = max(i for i, it in enumerate(its) if it.get("at", d["t0"]) <= t or i == 0)
            draw_photo(c, d, its[k], t, a, its[k].get("at", d["t0"]))
            if k + 1 <= len(its) - 1: pass
            if k > 0 and t < its[k]["at"] + 0.35:   # cross-fade from the previous photo
                draw_photo(c, d, its[k - 1], t, a * (1 - ramp(t, its[k]["at"], its[k]["at"] + 0.35)), its[k - 1].get("at", d["t0"]))
            if d.get("frame", True):
                rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.set_source_rgba(1, 1, 1, a); c.set_line_width(6); c.stroke()
        elif d["kind"] == "cover":
            colr = kit.hx(d["color"]); c.rectangle(x0, y0, x1 - x0, y1 - y0); c.set_source_rgba(colr[0], colr[1], colr[2], a); c.fill()
        elif d["kind"] == "draw":   # custom drawing hook from a python module
            d["_fn"](c, t, a, d)
        c.restore()

def main(cfgp, preview=None):
    cfg = json.load(open(cfgp)); ins = cfg["inserts"]
    for d in ins:
        for it in [d] + d.get("items", []):
            if it.get("crop"): CROP[it["src"]] = it["crop"]
    for d in ins:
        if d["kind"] == "map": d["_o"] = MapInsert(d)
        if d["kind"] == "draw":
            import importlib.util
            sp = importlib.util.spec_from_file_location("ovl_draw", d["module"]); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
            d["_fn"] = getattr(m, d["fn"])
    src = cfg["src"]
    if preview is not None:
        times = preview; ims = []
        for t in times:
            raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", src, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "bgra", "-"], capture_output=True).stdout
            ss = cairo.ImageSurface.create_for_data(bytearray(raw), cairo.FORMAT_ARGB32, W, H)
            out = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(out); draw_frame(c, ss, t, ins)
            im = Image.frombuffer("RGBA", (W, H), bytes(out.get_data()), "raw", "BGRA", 0, 1).convert("RGB").resize((360, 640))
            ImageDraw.Draw(im).text((6, 6), f"{t:.2f}", fill=(255, 0, 0)); ims.append(im)
        cols = min(6, len(ims)); rows = (len(ims) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * 365, rows * 645), "white")
        for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * 365, (i // cols) * 645))
        sheet.save(cfg.get("preview_png", cfgp.replace(".json", "_pv.png"))); print("preview", len(ims)); return
    dec = subprocess.Popen(["ffmpeg", "-v", "error", "-i", src, "-f", "rawvideo", "-pix_fmt", "bgra", "-"], stdout=subprocess.PIPE)
    out = cfg["out"]; tmp = out + ".v.mp4"
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", tmp], stdin=subprocess.PIPE)
    fs = W * H * 4; k = 0; dst = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(dst)
    while True:
        raw = dec.stdout.read(fs)
        if len(raw) < fs: break
        t = k / FPS
        if any(d["t0"] - 0.05 <= t <= d["t1"] + 0.05 for d in ins):
            ss = cairo.ImageSurface.create_for_data(bytearray(raw), cairo.FORMAT_ARGB32, W, H)
            draw_frame(c, ss, t, ins); dst.flush(); enc.stdin.write(bytes(dst.get_data()))
        else: enc.stdin.write(raw)
        k += 1
    enc.stdin.close(); enc.wait(); dec.wait()
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-i", src, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "copy", "-movflags", "+faststart", out], check=True)
    os.remove(tmp); print("wrote", out, k, "frames")

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) > 1 and a[1] == "--preview": main(a[0], [float(x) for x in a[2].split(",")])
    else: main(a[0])
