"""Bespoke reelkit scenes for this_life (28 Oct 2026).
two_roads: a road that forks. The long left road builds (homes, hospitals, families, startups, schools pop along it);
the short gold right road is a dashed shortcut that stops at a cloud labelled "Paradise" in quotes. No violent imagery.
  {"type": "two_roads", "en", "he", "size", "labels": true|false, "marks": {"build": phrase, "bypass": phrase}}
rows2: heading + cards with wrapped English (up to 2 lines) and Hebrew under; marks i0.., footer at mark "footer"."""
import math
import cairo
import render as RD
from render import P, T, pill, PP, fade_in, heading, source, block, block_h, shadow_box, icon_of, draw_emoji, series_chip, col, CONTENT_BOTTOM
from kit import ease, ramp, lerp, St, sa, rr, circ, box

def _bez(p0, p1, p2, p3, n=80):
    out = []
    for k in range(n + 1):
        u = k / n; a = (1 - u) ** 3; b = 3 * u * (1 - u) ** 2; c_ = 3 * u * u * (1 - u); d = u ** 3
        out.append((a * p0[0] + b * p1[0] + c_ * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c_ * p2[1] + d * p3[1]))
    return out
def _part(pts, u):
    n = max(1, int(round((len(pts) - 1) * max(0.0, min(1.0, u))))); return pts[:n + 1]
def _stroke(c, pts, wdt, cc, a=1.0, dash=None):
    if len(pts) < 2: return
    c.save(); c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    sa(c, cc, a); c.set_line_width(wdt); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    if dash: c.set_dash(dash)
    c.stroke(); c.restore()
def _cloud(c, x, y, s, a):
    old = St.a; St.a *= a
    sa(c, P["navy"], 0.10); c.save(); c.translate(0, 10)
    for dx, dy, r in ((-70, 10, 50), (-20, -20, 66), (45, -5, 56), (85, 20, 40), (0, 25, 55)): c.arc(x + dx * s, y + dy * s, r * s, 0, 2 * math.pi); c.new_sub_path()
    c.fill(); c.restore()
    sa(c, P["white"])
    for dx, dy, r in ((-70, 10, 50), (-20, -20, 66), (45, -5, 56), (85, 20, 40), (0, 25, 55)): c.arc(x + dx * s, y + dy * s, r * s, 0, 2 * math.pi); c.new_sub_path()
    c.fill_preserve(); sa(c, P["gold"]); c.set_line_width(4); c.stroke()
    St.a = old

BUILD = [("🏠", 0.12, 1), ("🏥", 0.30, -1), ("👨‍👩‍👧", 0.48, 1), ("🚀", 0.66, -1), ("🎓", 0.84, 1)]

def sc_two_roads(c, t, S):
    t0 = S["t0"]; hook = S.get("hook")
    if hook: series_chip(c, t, S)
    y = 470 if hook else 340
    a, s = PP(t, t0 + 0.05, S); breath = 1 + 0.012 * math.sin(max(0, t - t0) * 2.2)
    h1 = block_h(S["en"], S.get("size", 96), 900, 940, 2)
    block(c, S["en"], S.get("size", 96), 540, y + h1 / 2 - 48, P["navy"], a, s * breath, hl=P["blue"], maxw=940, max_lines=2)
    yy = y + h1 - 48
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 300 * u, yy + 4, 600 * u, 12, 6, P["gold"], a)
    a2, s2 = PP(t, t0 + 0.2, S); hh = block_h(S.get("he"), 58, 700, 940, 2)
    block(c, S.get("he"), 58, 540, yy + 40 + hh / 2, P["blue"], a2, s2, w=700, maxw=940, max_lines=2)
    top = yy + 40 + hh + 60; bot = 1440
    # geometry in the box (80..1000, top..bot)
    X = lambda fx: 80 + 920 * fx; Y = lambda fy: top + (bot - top) * fy
    start, fork = (X(0.5), Y(1.0)), (X(0.5), Y(0.80))
    left = _bez(fork, (X(0.47), Y(0.55)), (X(0.05), Y(0.55)), (X(0.22), Y(0.06)))
    right = _bez(fork, (X(0.56), Y(0.68)), (X(0.74), Y(0.66)), (X(0.78), Y(0.50)), 40)
    trunk = [start, fork]
    tb = S["times"].get("build", t0 + 0.2); tp = S["times"].get("bypass", t0 + 0.6)
    if hook: tb, tp = -2.5, -1.5
    ul = ramp(t, tb, tb + 1.3); ur = ramp(t, tp, tp + 0.7)
    _stroke(c, trunk, 96, P["navy"], 1.0); _stroke(c, trunk, 6, P["white"], 0.9, [26, 22])
    lp = _part(left, ul); _stroke(c, lp, 96, P["navy"]); _stroke(c, lp, 6, P["white"], 0.9, [26, 22])
    rp = _part(right, ur); _stroke(c, rp, 66, P["gold"], 0.95); _stroke(c, rp, 5, P["white"], 0.9, [16, 16])
    # the shortcut ends in a gap, then a cloud
    ca = ramp(t, tp + 0.5, tp + 0.9)
    if ca > 0:
        ex, ey = right[-1]
        for k in range(3): circ(c, ex + 18 + k * 22, ey - 30 - k * 34, 7, P["gold"], ca)
        _cloud(c, X(0.86), Y(0.22), 0.95, ca)
        T(c, "“Paradise”", 46, X(0.86), Y(0.22) + 6, P["gold_text"], ca, 1.0, 800, maxw=300)
    # building icons along the long road
    for k, (em, f, side) in enumerate(BUILD):
        tk = tb + 0.25 + 0.22 * k
        if ul < f - 0.02 and not hook: continue
        a3, s3 = (1.0, 1.0) if (hook and tk <= RD.HOOK_GRACE) else RD.kit.pop(t, tk, 0.45, 0.15, 2.0)
        i = int(f * (len(left) - 1)); px, py = left[i]; qx, qy = left[min(len(left) - 1, i + 1)] if i < len(left) - 1 else left[i - 1]
        dx, dy = qx - px, qy - py; L = math.hypot(dx, dy) or 1; nx, ny = -dy / L, dx / L
        cx, cy = px + nx * 105 * side, py + ny * 105 * side
        if a3 > 0.01:
            circ(c, cx, cy, 52 * s3, P["white"], a3); c.save(); sa(c, P["blue"], a3); c.set_line_width(4); c.arc(cx, cy, 52 * s3, 0, 2 * math.pi); c.stroke(); c.restore()
            bob = 6 * math.sin(t * 2.4 + k * 1.3)
            draw_emoji(c, em, cx, cy + bob, 62, a3, s3 * (1 + 0.04 * math.sin(t * 3 + k)))
    if S.get("labels"):
        la, ls = PP(t, tb + 0.1, S); lx, ly = left[-1]
        pill(c, S.get("left", "Build"), 54, lx + 250, ly + 10, P["navy"], P["white"], la, ls, outline=P["gold"], w=900)
        if S.get("left_he"): T(c, S["left_he"], 44, lx + 250, ly + 86, P["navy"], la, ls, 700, maxw=420)
        ra, rs = PP(t, tp + 0.3, S); rx, ry = right[-1]
        pill(c, S.get("right", "Bypass"), 54, rx + 40, ry + 120, P["gold"], P["navy"], ra, rs, outline=P["navy"], w=900)
        if S.get("right_he"): T(c, S["right_he"], 44, rx + 40, ry + 196, P["gold_text"], ra, rs, 700, maxw=420)
    source(c, t, S)

def sc_rows2(c, t, S):
    y = heading(c, t, S) + 10; items = S["items"]; n = len(items); foot = S.get("footer")
    room = CONTENT_BOTTOM - y - (190 if foot else 10)
    z_en, z_he = S.get("size", 54), S.get("size_he", 42)
    def hs(z1, z2): return [30 + block_h(it.get("en"), z1, 800, 720, 2) + (10 + block_h(it.get("he"), z2, 700, 720, 2) if it.get("he") else 0) + 30 for it in items]
    H_ = hs(z_en, z_he)
    while sum(H_) + 26 * (n - 1) > room and z_en > 36: z_en -= 2; z_he -= 2; H_ = hs(z_en, z_he)
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2); yy = y
    for k, it in enumerate(items):
        bh = H_[k]; tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        if t < tk - 0.07: yy += bh + 26; continue
        a = fade_in(t, tk - 0.07, S, 0.2); u = ease((t - tk + 0.07) / 0.35); dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, 70, yy, 940, bh, 36, P["card"], stroke=col(it.get("color"), "silver"), sw=3, sh=6)
        em = icon_of(it)
        if em: draw_emoji(c, em, 145, yy + bh / 2, 76)
        he_ = block_h(it.get("en"), z_en, 800, 720, 2); cy = yy + 30 + he_ / 2
        block(c, it.get("en"), z_en, 585, cy, P["navy"], 1.0, 1.0, 800, hl=col(it.get("hl"), "blue"), maxw=720, max_lines=2)
        if it.get("he"):
            hh = block_h(it["he"], z_he, 700, 720, 2); block(c, it["he"], z_he, 585, yy + 30 + he_ + 10 + hh / 2, P["gold_text"], 1.0, 1.0, 700, maxw=720, max_lines=2)
        c.restore(); St.a = old; yy += bh + 26
    if foot:
        tf = S["times"].get("footer", S["t0"] + span + 0.6)
        a, s = PP(t, tf, S, bounce=2.4); fy = yy + 60
        pill(c, foot.get("en", ""), 56, 540, fy, col(foot.get("color"), "navy"), P["white"], a, s, outline=P["gold"], w=900)
        if foot.get("he"): T(c, foot["he"], 46, 540, fy + 92, col(foot.get("he_color"), "navy"), a, s, w=700)
    source(c, t, S)
