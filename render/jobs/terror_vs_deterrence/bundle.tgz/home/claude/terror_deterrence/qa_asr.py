import sys, json, subprocess, numpy as np
sys.path.insert(0, "/home/claude/reelkit")
import vo_restore as R
from collections import Counter
media, tj, tts = sys.argv[1:4]
T = json.load(open(tj)); lines = [l.strip() for l in open(tts) if l.strip()]
R.asr()
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", media, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
tot = hit = 0; out = []
for i, (a, b) in enumerate(T["lines"]):
    ref = R.toks(lines[i]); h = R.transcribe(x, a - 0.15, b + 0.35)
    m = sum((Counter(R.toks(h)) & Counter(ref)).values()); tot += len(ref); hit += m
    out.append(dict(line=i + 1, recall=round(m / max(1, len(ref)), 3), heard=h))
    print(i + 1, round(m / max(1, len(ref)), 3), "|", h)
print("OVERALL", round(hit / tot, 3))
json.dump(dict(overall=round(hit / tot, 3), lines=out), open("asr_final.json", "w"), indent=1)
