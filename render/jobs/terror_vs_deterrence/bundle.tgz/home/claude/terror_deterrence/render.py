"""terror_vs_deterrence frame renderer (pycairo), frames streamed into ffmpeg.
usage: render.py timing.json out_silent.mp4 [--still t1,t2,... out.png [--big]]"""
import sys, json, math, subprocess, re
import numpy as np, cairo
from PIL import Image

W, H, FPS = 1080, 1920, 30
NAVY = (0x16 / 255, 0x32 / 255, 0x61 / 255); SKY = (0x45 / 255, 0xA4 / 255, 0xDD / 255)
YEL = (1.0, 0.84, 0.18); WHITE = (1, 1, 1); SOFT = (0.80, 0.86, 0.95); RED = (1.0, 0.36, 0.36)
GOLD = (0.90, 0.76, 0.31); GOLD2 = (0.72, 0.57, 0.25); GREEN = (46 / 255, 204 / 255, 113 / 255)
BROWN = (0.55, 0.35, 0.18); LAND = (0.20, 0.30, 0.48); SEA = (0.07, 0.15, 0.30)
FONT = "Heebo"

T = json.load(open(sys.argv[1]))
WORDS = T["words"]; LINES = T["lines"]; DUR = T["dur"]


def wt(line, word, k=0):
    ws = [w for w in WORDS if w["line"] == line and re.sub(r"[^a-z0-9]", "", w["w"].lower()) == word.lower()]
    if not ws: raise KeyError((line, word))
    return ws[min(k, len(ws) - 1)]["t0"]
def ls(n): return LINES[n - 1][0]
def le(n): return LINES[n - 1][1]
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ease(x): x = clamp(x); return x * x * (3 - 2 * x)
def back(x):
    x = clamp(x); c = 1.7
    return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def ap(t, t0, r=0.35): return ease((t - t0) / r)

# ---------------------------------------------------------------- phases
P_HOOK = 0.0
P_DEF = ls(2) - 0.15
T_DEF2 = wt(2, "deterrence") - 0.1
P_T1 = ls(3) - 0.15
T_T1B = ls(4) - 0.1
P_T2 = ls(5) - 0.15
T_T2B = ls(6) - 0.1
P_T3 = ls(7) - 0.15
T_OCT = ls(8) - 0.1
T_T3B = ls(9) - 0.1
P_SPINE = ls(10) - 0.15
T_DETERS = wt(10, "it") - 0.1
P_MAP = ls(11) - 0.15
P_SITE = ls(12) - 0.15
P_BAL = ls(13) - 0.15
T_JUDGE = wt(13, "judge") - 0.1
P_LOOP = ls(14) - 0.15
T_LOOP2 = wt(14, "and") - 0.1
PH = [P_HOOK, P_DEF, P_T1, P_T2, P_T3, P_SPINE, P_MAP, P_SITE, P_BAL, P_LOOP, DUR + 1]


def phase(t):
    for i in range(len(PH) - 1):
        if PH[i] <= t < PH[i + 1]: return i, PH[i], PH[i + 1]
    return len(PH) - 2, PH[-2], PH[-1]

# ---------------------------------------------------------------- drawing helpers
def rrect(c, x, y, w, h, r):
    c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()

def setf(c, size, weight=cairo.FONT_WEIGHT_BOLD):
    c.select_font_face(FONT, cairo.FONT_SLANT_NORMAL, weight); c.set_font_size(size)

def twidth(c, s, size, weight=cairo.FONT_WEIGHT_BOLD):
    setf(c, size, weight); return c.text_extents(s)[4]

def text(c, s, size, x, y, color=WHITE, a=1.0, anchor="c", weight=cairo.FONT_WEIGHT_BOLD, parts=None):
    setf(c, size, weight)
    parts = parts or [(s, color)]
    widths = [c.text_extents(p)[4] for p, _ in parts]; tw = sum(widths)
    asc = c.font_extents()[0] * 0.72
    x0 = x - tw / 2 if anchor == "c" else (x if anchor == "l" else x - tw)
    for (p, col), w in zip(parts, widths):
        c.move_to(x0, y + asc / 2); c.set_source_rgba(*col, a); c.show_text(p); x0 += w
    return tw

def fit(c, s, size, maxw, lo=64):
    while twidth(c, s.replace("*", ""), size) > maxw and size > lo: size -= 2
    return size

def wrap(c, s, size, maxw):
    words = s.split(); lines = [""]
    for w in words:
        trial = (lines[-1] + " " + w).strip()
        if twidth(c, trial.replace("*", ""), size) <= maxw or not lines[-1]: lines[-1] = trial
        else: lines.append(w)
    out = []; on = False
    for l in lines:
        s2 = ("*" if on else "") + l
        if s2.count("*") % 2: s2 += "*"
        on = (on + l.count("*")) % 2 == 1
        out.append(s2)
    return out

def rich(c, s, size, x, y, a=1.0, base=WHITE, hl=YEL, anchor="c"):
    parts = []; on = False
    for seg in s.split("*"):
        if seg: parts.append((seg, hl if on else base))
        on = not on
    return text(c, None, size, x, y, a=a, parts=parts, anchor=anchor)

def para(c, s, size, x, y, a=1.0, lh=1.16, maxw=940, base=WHITE, hl=YEL):
    lines = wrap(c, s, size, maxw)
    y0 = y - (len(lines) - 1) * size * lh / 2
    for i, l in enumerate(lines): rich(c, l, size, x, y0 + i * size * lh, a=a, base=base, hl=hl)
    return len(lines)

def small(c, s, x, y, a=1.0, col=SOFT, maxw=940):
    setf(c, 36, cairo.FONT_WEIGHT_NORMAL)
    lines = wrap(c, s, 36, maxw)
    for i, l in enumerate(lines):
        text(c, l.replace("*", ""), 36, x, y + i * 44, col, a=0.95 * a, weight=cairo.FONT_WEIGHT_NORMAL)

def pill(c, s, size, x, y, fill, tcol=WHITE, a=1.0, padx=34, h=None):
    w = twidth(c, s, size) + 2 * padx; h = h or size * 1.5
    rrect(c, x - w / 2, y - h / 2, w, h, h / 2); c.set_source_rgba(*fill, a); c.fill()
    text(c, s, size, x, y, tcol, a=a)
    return w

def bg(c, t, split=0.0):
    g = cairo.LinearGradient(0, 0, 0, H)
    g.add_color_stop_rgb(0, 0.055, 0.118, 0.227); g.add_color_stop_rgb(0.5, *NAVY); g.add_color_stop_rgb(1, 0.06, 0.13, 0.26)
    c.set_source(g); c.paint()
    sx = 540 + 160 * math.sin(t * 0.35)
    r = cairo.RadialGradient(sx, 900, 0, sx, 900, 700)
    r.add_color_stop_rgba(0, 0.27, 0.64, 0.87, 0.13); r.add_color_stop_rgba(1, 0.27, 0.64, 0.87, 0)
    c.set_source(r); c.paint()
    if split > 0:
        # red glow on the top half, sky glow on the bottom half
        for cy, col in ((560, RED), (1260, SKY)):
            r = cairo.RadialGradient(540, cy, 0, 540, cy, 620)
            r.add_color_stop_rgba(0, *col, 0.16 * split); r.add_color_stop_rgba(1, *col, 0)
            c.set_source(r); c.paint()

# panels: top = TERROR (red), bottom = DETERRENCE (sky)
PX, PW, PH_ = 50, 980, 540
PY = {"top": 400, "bot": 985}

def panel(c, which, a, label=True):
    y = PY[which]; col = RED if which == "top" else SKY
    rrect(c, PX, y, PW, PH_, 36); c.set_source_rgba(0.03, 0.07, 0.16, 0.55 * a); c.fill_preserve()
    c.set_source_rgba(*col, 0.9 * a); c.set_line_width(5); c.stroke()
    if label:
        s = "TERROR" if which == "top" else "DETERRENCE"
        w = twidth(c, s, 46) + 52
        rrect(c, PX + 34, y - 34, w, 68, 34); c.set_source_rgba(*col, a); c.fill()
        text(c, s, 46, PX + 34 + w / 2, y, WHITE, a=a)
    return y

def header(c, s, a, y=300):
    pill(c, s, 56, 540, y, (1, 1, 1), NAVY, a=a)

# ---------------------------------------------------------------- figures
def stroke(c, col, a, lw):
    c.set_source_rgba(*col, a); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()

def person(c, x, y, s=1.0, col=WHITE, a=1.0, armL=(-140, 20), armR=(-40, 20), lean=0.0, legs=0.0, face=None):
    """stick figure, y = feet. arm angles in degrees from straight down (0 = down, 90 = sideways out)."""
    lw = 10 * s; hip = (x + lean * 20 * s, y - 70 * s); neck = (x + lean * 34 * s, y - 145 * s)
    head = (neck[0] + lean * 6 * s, neck[1] - 30 * s)
    c.move_to(x - (22 + legs) * s, y); c.line_to(*hip); c.line_to(x + (22 + legs) * s, y)
    c.move_to(*hip); c.line_to(*neck); stroke(c, col, a, lw)
    for side, (ang, bend) in ((-1, armL), (1, armR)):
        rad = math.radians(ang); L = 58 * s
        ex = neck[0] + side * math.sin(rad) * L; ey = neck[1] + 12 * s + math.cos(rad) * L
        c.move_to(neck[0], neck[1] + 12 * s); c.line_to(ex, ey); stroke(c, col, a, lw)
    c.arc(head[0], head[1], 25 * s, 0, 2 * math.pi); c.set_source_rgba(*col, a); c.fill()
    if face:
        c.set_source_rgba(*NAVY, a)
        for dx in (-8, 8): c.arc(head[0] + dx * s, head[1] - 4 * s, 3.4 * s, 0, 2 * math.pi); c.fill()
        c.set_line_width(3.2 * s)
        if face == "smile": c.arc(head[0], head[1] + 2 * s, 10 * s, 0.2 * math.pi, 0.8 * math.pi)
        elif face == "frown": c.arc(head[0], head[1] + 17 * s, 9 * s, 1.2 * math.pi, 1.8 * math.pi)
        else: c.move_to(head[0] - 8 * s, head[1] + 9 * s); c.line_to(head[0] + 8 * s, head[1] + 9 * s)
        c.stroke()
    return head

def hand_pos(x, y, s, side, ang, lean=0.0):
    neck = (x + lean * 34 * s, y - 145 * s); rad = math.radians(ang); L = 58 * s
    return neck[0] + side * math.sin(rad) * L, neck[1] + 12 * s + math.cos(rad) * L

def cup(c, x, y, s=1.0, rot=0.0, a=1.0):
    c.save(); c.translate(x, y); c.rotate(rot)
    c.move_to(-18 * s, -22 * s); c.line_to(18 * s, -22 * s); c.line_to(13 * s, 22 * s); c.line_to(-13 * s, 22 * s); c.close_path()
    c.set_source_rgba(1, 1, 1, a); c.fill()
    c.rectangle(-17 * s, -14 * s, 34 * s, 12 * s); c.set_source_rgba(*BROWN, a); c.fill()
    c.arc(22 * s, 0, 9 * s, -math.pi / 2, math.pi / 2); c.set_source_rgba(1, 1, 1, a); c.set_line_width(4 * s); c.stroke()
    c.restore()

def bubble(c, s, x, y, a, size=46, col=WHITE, tcol=NAVY, tail=(-1, 1)):
    w = twidth(c, s, size) + 50; h = size * 1.6
    rrect(c, x - w / 2, y - h / 2, w, h, 26); c.set_source_rgba(*col, a); c.fill()
    c.move_to(x - 70, y + h / 2 - 2); c.line_to(x - 120, y + h / 2 + 36); c.line_to(x - 20, y + h / 2 - 2)
    c.close_path(); c.fill()
    text(c, s, size, x, y, tcol, a=a)

def star(c, x, y, r, a, col=YEL, n=8):
    c.new_path()
    for k in range(2 * n):
        rr = r if k % 2 == 0 else r * 0.45; ang = k * math.pi / n
        c.line_to(x + rr * math.cos(ang), y + rr * math.sin(ang))
    c.close_path(); c.set_source_rgba(*col, a); c.fill()

def rocket(c, x, y, ang, s=1.0, a=1.0, col=RED):
    c.save(); c.translate(x, y); c.rotate(ang)
    c.move_to(26 * s, 0); c.line_to(6 * s, -8 * s); c.line_to(-22 * s, -8 * s); c.line_to(-22 * s, 8 * s); c.line_to(6 * s, 8 * s); c.close_path()
    c.set_source_rgba(*col, a); c.fill()
    c.move_to(-22 * s, 0); c.line_to(-40 * s, -5 * s); c.line_to(-40 * s, 5 * s); c.close_path(); c.set_source_rgba(1, 0.75, 0.3, 0.8 * a); c.fill()
    c.restore()

def building(c, x, y, w, h, a, col=SOFT, win=True):
    c.rectangle(x - w / 2, y - h, w, h); c.set_source_rgba(*col, 0.85 * a); c.fill()
    if win:
        c.set_source_rgba(*NAVY, 0.8 * a)
        for yy in np.arange(y - h + 14, y - 22, 30):
            for xx in np.arange(x - w / 2 + 12, x + w / 2 - 18, 26): c.rectangle(xx, yy, 13, 16); c.fill()

def shield(c, x, y, s, a, col=SKY):
    c.move_to(x, y - 60 * s); c.curve_to(x + 30 * s, y - 45 * s, x + 50 * s, y - 45 * s, x + 55 * s, y - 45 * s)
    c.curve_to(x + 55 * s, y + 10 * s, x + 35 * s, y + 45 * s, x, y + 65 * s)
    c.curve_to(x - 35 * s, y + 45 * s, x - 55 * s, y + 10 * s, x - 55 * s, y - 45 * s)
    c.curve_to(x - 50 * s, y - 45 * s, x - 30 * s, y - 45 * s, x, y - 60 * s); c.close_path()
    c.set_source_rgba(*col, a); c.fill()
    c.move_to(x - 22 * s, y + 2 * s); c.line_to(x - 4 * s, y + 20 * s); c.line_to(x + 26 * s, y - 16 * s); stroke(c, WHITE, a, 9 * s)

def crosshair(c, x, y, r, a, col=RED):
    c.arc(x, y, r, 0, 2 * math.pi); stroke(c, col, a, 7)
    c.arc(x, y, r * 0.45, 0, 2 * math.pi); stroke(c, col, a, 5)
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        c.move_to(x + dx * r * 0.6, y + dy * r * 0.6); c.line_to(x + dx * r * 1.25, y + dy * r * 1.25)
    stroke(c, col, a, 6)

def phone(c, x, y, s, a, crossed=0.0):
    rrect(c, x - 26 * s, y - 46 * s, 52 * s, 92 * s, 10 * s); c.set_source_rgba(1, 1, 1, a); c.fill()
    rrect(c, x - 20 * s, y - 36 * s, 40 * s, 66 * s, 4 * s); c.set_source_rgba(*SKY, a); c.fill()
    if crossed > 0:
        k = ease(crossed); r = 70 * s
        c.arc(x, y, r, 0, 2 * math.pi * k); stroke(c, RED, a, 10 * s)
        if k > 0.5:
            q = ease((k - 0.5) * 2); d = r * 0.7
            c.move_to(x - d, y - d); c.line_to(x - d + 2 * d * q, y - d + 2 * d * q); stroke(c, RED, a, 10 * s)

def siren(c, x, y, s, a, t):
    c.move_to(x - 30 * s, y + 20 * s); c.line_to(x - 30 * s, y - 10 * s); c.arc(x, y - 10 * s, 30 * s, math.pi, 2 * math.pi); c.line_to(x + 30 * s, y + 20 * s); c.close_path()
    c.set_source_rgba(1, 0.75, 0.2, a); c.fill(); c.rectangle(x - 42 * s, y + 20 * s, 84 * s, 14 * s); c.set_source_rgba(1, 1, 1, a); c.fill()
    p = 0.5 + 0.5 * math.sin(t * 9)
    for side in (-1, 1):
        for k in (1, 2):
            c.arc(x, y - 10 * s, (40 + 18 * k) * s, (-0.5 + side * 0.25) * math.pi - 0.3, (-0.5 + side * 0.25) * math.pi + 0.3)
            stroke(c, YEL, a * (0.4 + 0.6 * p), 5 * s)

# ---------------------------------------------------------------- scenes
def sc_hook(c, t, a=1.0):
    pill(c, "3 TESTS", 54, 540, 380, YEL, NAVY, a=a)
    sz = fit(c, "TERROR", 190, 960, 120); text(c, "TERROR", sz, 540, 640, RED, a=a)
    text(c, "or", 96, 540, 820, WHITE, a=a)
    sz = fit(c, "DETERRENCE?", 170, 980, 100); text(c, "DETERRENCE?", sz, 540, 1000, SKY, a=a)
    # motion: underline sweep + breathing test dots
    k = ease(t / 1.2) if t < 3 else 1.0
    c.rectangle(540 - 420 * k, 1100, 840 * k, 10); c.set_source_rgba(*YEL, a); c.fill()
    for i in range(3):
        p = 1 + 0.12 * math.sin(t * 4 - i * 1.1)
        cx = 540 + (i - 1) * 190; cy = 1290
        c.arc(cx, cy, 62 * p, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, 0.12 * a); c.fill()
        c.arc(cx, cy, 62 * p, 0, 2 * math.pi); stroke(c, SKY if i % 2 else RED, a, 6)
        text(c, str(i + 1), 76, cx, cy, WHITE, a=a)
    for i, s in enumerate(["work", "home", "countries"]):
        text(c, s, 44, 540 + (i - 1) * 190, 1400, SOFT, a=a)

def sc_def(c, t, a):
    y = panel(c, "top", a)
    for i, dx in enumerate((-150, 0, 150)):
        person(c, 540 + dx, y + 310, 1.15, WHITE, a, face="frown")
    p = ap(t, P_DEF + 0.3, 0.6); cx = 540 + 150 * math.sin(t * 2.2) * (1 - 0.3 * p)
    crosshair(c, cx, y + 170, 60, a * p)
    para(c, "Aims at *civilians*, to spread *fear*", 66, 540, y + 410, a=a)
    small(c, "UN SC Res. 1566 (2004); 22 USC 2656f", 540, y + 500, a=a)
    b = ap(t, T_DEF2); y2 = panel(c, "bot", a * b)
    if b > 0:
        person(c, 760, y2 + 290, 1.1, RED, a * b, armL=(-40, 0), armR=(-120, 0), face="line")
        rocket(c, 680, y2 + 140, math.pi, 1.3, a * b)
        shield(c, 420, y2 + 170, 1.25 + 0.04 * math.sin(t * 5), a * b)
        para(c, "Aims at *attackers*, to stop the next attack", 66, 540, y2 + 385, a=a * b, hl=SKY)
        small(c, "Deterrence: Encyclopaedia Britannica", 540, y2 + 500, a=a * b)

def sc_t1(c, t, a):
    header(c, "TEST 1: WORK", a)
    y = panel(c, "top", a)
    t0 = P_T1 + 0.6; k = clamp((t - t0) / 0.9)
    hit = k > 0.25
    person(c, 330, y + 330, 1.3, RED, a, armL=(-150, 0), armR=(-(30 if not hit else 110), 0), lean=0.15, face="smile")
    vx = 640 + (25 * ease((k - 0.3) / 0.7)) + (4 * math.sin(t * 30) if k > 0.4 else 0)
    vs = 1.2 - 0.25 * ease((k - 0.4) / 0.6)
    person(c, vx, y + 330, vs, WHITE, a, armL=(-20, 0), armR=(-(80 if not hit else 30), 0), face="frown" if hit else "line")
    if not hit:
        hx, hy = hand_pos(640, y + 330, 1.0, 1, 80); cup(c, hx + 10, hy - 20, 1.2, 0, a)
    else:
        q = ease((k - 0.25) / 0.75); hx, hy = hand_pos(640, y + 330, 1.0, 1, 80)
        cx = hx + 230 * q; cy = hy - 20 - 160 * math.sin(q * math.pi) + 60 * q
        cup(c, cx, cy, 1.2, q * 5, a)
        for d in range(5):
            dq = clamp(q * 1.2 - d * 0.06)
            c.arc(cx - 30 - d * 26 * dq, cy + 10 + d * 14 * dq + 40 * dq * dq, 7 - d, 0, 2 * math.pi); c.set_source_rgba(*BROWN, a); c.fill()
        star(c, 480, y + 190, 30 * ease(clamp((k - 0.25) / 0.15)) * (1 - clamp((k - 0.6) / 0.3)), a, WHITE)
    para(c, "The point is *fear*", 70, 540, y + 455, a=a, hl=RED)
    b = ap(t, T_T1B); y2 = panel(c, "bot", a * b)
    if b > 0:
        person(c, 300, y2 + 330, 1.3, SKY, a * b, armL=(-20, 0), armR=(-110, 0), face="line")
        # lunch box on a table, a clear line on the floor
        c.rectangle(600, y2 + 250, 260, 16); c.set_source_rgba(*SOFT, a * b); c.fill()
        c.rectangle(615, y2 + 266, 12, 64); c.rectangle(833, y2 + 266, 12, 64); c.fill()
        rrect(c, 680, y2 + 195, 110, 55, 10); c.set_source_rgba(*YEL, a * b); c.fill()
        lq = ease(clamp((t - T_T1B - 0.4) / 0.8))
        c.set_dash([24, 16]); c.move_to(520, y2 + 345 - 230 * 0); c.line_to(520, y2 + 345 - 260 * lq); stroke(c, SKY, a * b, 8); c.set_dash([])
        bubble(c, "Touch it: HR hears.", 560, y2 + 105, a * b * ap(t, T_T1B + 0.2), size=48)
        para(c, "A *clear line*, set in advance", 70, 540, y2 + 455, a=a * b, hl=SKY)

def sc_t2(c, t, a):
    header(c, "TEST 2: HOME", a)
    y = panel(c, "top", a)
    k = clamp((t - P_T2 - 0.5) / 0.6); sw = 0.5 + 0.5 * math.sin((t - P_T2) * 6)
    hit = sw > 0.6 and t > P_T2 + 0.5
    person(c, 400, y + 330, 1.25, RED, a, armL=(-150, 0), armR=(-(60 + 60 * sw), 0), lean=0.1 * sw, face="smile")
    person(c, 660 + (8 if hit else 0), y + 330, 0.85, WHITE, a, armL=(-150, 0), armR=(-150, 0), face="frown")
    if hit: star(c, 560, y + 200, 34, a, WHITE)
    para(c, "Hits to *scare*", 70, 540, y + 455, a=a, hl=RED)
    b = ap(t, T_T2B); y2 = panel(c, "bot", a * b)
    if b > 0:
        person(c, 330, y2 + 330, 1.3, SKY, a * b, armL=(-20, 0), armR=(-115, 0), face="line")
        person(c, 560, y2 + 330, 0.85, WHITE, a * b, face="line")
        phone(c, 780, y2 + 190, 1.2, a * b, crossed=clamp((t - T_T2B - 0.6) / 0.8))
        para(c, "*Hit again*: no phone tonight", 70, 540, y2 + 455, a=a * b, hl=SKY)

def sc_t3(c, t, a):
    header(c, "TEST 3: COUNTRIES", a)
    y = panel(c, "top", a)
    # rockets arcing from the left towards a skyline on the right
    for i, (bx, bh) in enumerate(((700, 150), (790, 210), (880, 120), (960, 170))):
        building(c, bx, y + 330, 70, bh, a)
    for k in range(6):
        ph = ((t - P_T3) * 0.7 + k / 6) % 1.0
        x0, x1 = 600, 680 + (k % 4) * 90; x1 = 660 + (k % 4) * 95; xx = x0 + (x1 - x0) * ph; yy = y + 120 + 160 * ph - 120 * math.sin(ph * math.pi)
        ang = math.atan2(160 - 120 * math.pi * math.cos(ph * math.pi), (x1 - x0) + 1e-3)
        rocket(c, xx, yy, ang, 1.0, a * (1 - clamp((ph - 0.9) / 0.1)))
    if t < T_OCT:
        q = ease((t - P_T3 - 0.8) / 2.2); n = int(round(12000 * q / 10) * 10)
        text(c, f"~{n:,}", 130, 330, y + 140, YEL, a=a)
        text(c, "rockets at Israel", 50, 330, y + 230, WHITE, a=a)
        para(c, "Oct to Dec *2023*", 60, 540, y + 420, a=a, hl=YEL)
        small(c, "Israeli govt figures via NYT, 27 Dec 2023", 540, y + 495, a=a)
    else:
        q = ap(t, T_OCT)
        text(c, "~1,200", 130, 330, y + 140, YEL, a=a * q)
        text(c, "killed on Oct 7", 50, 330, y + 230, WHITE, a=a * q)
        para(c, "Mostly *civilians*", 70, 540, y + 420, a=a * q, hl=RED)
        small(c, "Israeli government count, 2023", 540, y + 495, a=a * q)
    b = ap(t, T_T3B); y2 = panel(c, "bot", a * b)
    if b > 0:
        tt = t - T_T3B
        # dome + interceptor, siren, launcher with an X
        c.arc(250, y2 + 300, 120, math.pi, 2 * math.pi); c.set_source_rgba(*SKY, 0.25 * a * b); c.fill()
        c.arc(250, y2 + 300, 120, math.pi, 2 * math.pi); stroke(c, SKY, a * b, 6)
        for k in range(2):
            ph = (tt * 0.8 + k * 0.5) % 1.0
            iy = y2 + 290 - 220 * ph; ix = 250 + 60 * ph * (1 if k else -1)
            rocket(c, ix, iy, -math.pi / 2 + (0.25 if k else -0.25) * ph, 0.8, a * b * (1 - ph), SKY)
            if ph > 0.85: star(c, ix, iy - 20, 30, a * b, WHITE)
        siren(c, 540, y2 + 230, 1.2, a * b, t)
        c.rectangle(760, y2 + 250, 150, 40); c.set_source_rgba(*SOFT, a * b); c.fill()
        c.move_to(790, y2 + 250); c.line_to(860, y2 + 180); stroke(c, SOFT, a * b, 14)
        xq = ease(clamp((tt - 1.6) / 0.5))
        if xq > 0:
            d = 70 * xq; c.move_to(835 - d, y2 + 235 - d); c.line_to(835 + d, y2 + 235 + d); c.move_to(835 + d, y2 + 235 - d); c.line_to(835 - d, y2 + 235 + d); stroke(c, SKY, a * b, 14)
        for lab, x, at in (("Iron Dome", 250, 0.0), ("Warnings", 540, 0.6), ("Launchers", 835, 1.3)):
            text(c, lab, 46, x, y2 + 360, WHITE, a=a * b * ap(tt, at))
        para(c, "Stops the *attackers*", 70, 540, y2 + 455, a=a * b, hl=SKY)

def sc_spine(c, t, a):
    tt = t - P_SPINE
    p = 1 + 0.03 * math.sin(t * 3)
    shield(c, 540, 600, 2.6 * p, a * 0.9)
    para(c, "Israel doesn't do *terror*.", 104, 540, 1010, a=a, hl=RED, maxw=980)
    q = back(clamp((t - T_DETERS) / 0.45))
    if q > 0:
        c.save(); c.translate(540, 1270); c.scale(q, q); text(c, "It DETERS.", 150, 0, 0, SKY, a=a); c.restore()

# ---- map
GEO = json.load(open("/home/claude/empires_israel/geo/geo.json"))
NE = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
LON0, LON1, LAT0, LAT1 = 31.0, 61.0, 12.0, 37.0
KX = math.cos(math.radians(26)); MAPX, MAPY, MAPW = 50, 330, 980
SC = MAPW / ((LON1 - LON0) * KX)
def pr(lon, lat): return (MAPX + (lon - LON0) * KX * SC, MAPY + (LAT1 - lat) * SC)
def polys(g): return [g["coordinates"]] if g["type"] == "Polygon" else g["coordinates"]
MAPH = (LAT1 - LAT0) * SC

def build_map():
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    c.rectangle(MAPX, MAPY, MAPW, MAPH); c.clip()
    rrect(c, MAPX, MAPY, MAPW, MAPH, 30); c.set_source_rgb(*SEA); c.fill()
    for f in NE["features"]:
        iso = f["properties"].get("ISO_A2_EH") or f["properties"].get("ISO_A2")
        if iso in ("IL", "PS"): continue
        for poly in polys(f["geometry"]):
            c.new_path()
            for p in poly[0]: c.line_to(*pr(*p))
            c.close_path(); c.set_source_rgb(*LAND); c.fill_preserve(); c.set_source_rgba(0.55, 0.65, 0.8, 0.6); c.set_line_width(1.5); c.stroke()
    for key, col in (("israel", GOLD), ("psx", GOLD2), ("gaza", GOLD2)):
        for poly in polys(GEO[key]):
            c.new_path()
            for p in poly[0]: c.line_to(*pr(*p))
            c.close_path(); c.set_source_rgb(*col); c.fill()
    for key in ("psx", "gaza"):
        for poly in polys(GEO[key]):
            c.new_path()
            for p in poly[0]: c.line_to(*pr(*p))
            c.close_path(); c.set_source_rgb(*GREEN); c.set_line_width(2.2); c.stroke()
    return surf
MAP = build_map()

GROUPS = [  # name, lon, lat, label dx, dy, cue word, source year
    ("HAMAS", 34.40, 31.40, -10, 120, "hamas"),
    ("Hezbollah", 35.6, 33.6, 40, -110, "hezbollah"),
    ("Houthis", 44.2, 15.4, 0, 100, "houthis"),
    ("IRGC Quds Force", 53.0, 32.5, 0, 110, "quds"),
]

def sc_map(c, t, a):
    text(c, "Terror around Israel", 84, 540, 260, WHITE, a=a)
    c.save(); c.set_source_surface(MAP, 0, 0); c.paint_with_alpha(a); c.restore()
    rrect(c, MAPX, MAPY, MAPW, MAPH, 30); stroke(c, SOFT, 0.5 * a, 3)
    ix, iy = pr(35.0, 31.3)
    for name, lon, lat, dx, dy, cue in GROUPS:
        tc = wt(11, cue) - 0.15; q = ap(t, tc, 0.3)
        if q <= 0: continue
        x, y = pr(lon, lat); pulse = 0.5 + 0.5 * math.sin((t - tc) * 5)
        c.arc(x, y, 18 + 14 * pulse, 0, 2 * math.pi); c.set_source_rgba(*RED, 0.35 * a * q); c.fill()
        c.arc(x, y, 14, 0, 2 * math.pi); c.set_source_rgba(*RED, a * q); c.fill()
        lx, ly = x + dx, y + dy
        if name == "HAMAS": lx, ly = x - 60, y + 190
        if name == "Hezbollah": lx, ly = x + 200, y + 20
        c.move_to(x, y); c.line_to(lx, ly); stroke(c, RED, a * q, 4)
        w = twidth(c, name, 52) + 40
        lx = min(max(lx, MAPX + w / 2 + 10), MAPX + MAPW - w / 2 - 10)
        rrect(c, lx - w / 2, ly - 38, w, 76, 38); c.set_source_rgba(*RED, a * q); c.fill()
        text(c, name, 52, lx, ly, WHITE, a=a * q)
    # legend + source
    ly = MAPY + MAPH + 50
    c.rectangle(110, ly - 18, 50, 36); c.set_source_rgba(*GOLD, a); c.fill()
    c.rectangle(160, ly - 18, 30, 36); c.set_source_rgba(*GOLD2, a); c.fill()
    text(c, "Israel, West Bank, Gaza", 40, 215, ly, SOFT, a=a, anchor="l", weight=cairo.FONT_WEIGHT_NORMAL)
    c.move_to(690, ly); c.line_to(740, ly); stroke(c, GREEN, a, 6)
    text(c, "Green Line", 40, 760, ly, SOFT, a=a, anchor="l", weight=cairo.FONT_WEIGHT_NORMAL)
    small(c, "US State Dept Foreign Terrorist Organizations list: HAMAS, Hezbollah (1997), IRGC (2019), Ansarallah (2025)", 540, ly + 70, a=a)

def sc_site(c, t, a):
    tt = t - P_SITE
    para(c, "Israel does *DETERRENCE*", 92, 540, 300, a=a, hl=SKY)
    gy = 1180
    # crane
    c.move_to(300, gy); c.line_to(300, 560); c.line_to(760, 560); stroke(c, YEL, a, 12)
    c.move_to(300, 600); c.line_to(360, 560); stroke(c, YEL, a, 6)
    hx = 520 + 120 * math.sin(tt * 1.2)
    c.move_to(hx, 560); c.line_to(hx, 660); stroke(c, SOFT, a, 4); c.rectangle(hx - 40, 660, 80, 30); c.set_source_rgba(*SOFT, a); c.fill()
    # building rising floor by floor
    floors = 3 + int(clamp(tt / 3.5) * 5)
    for f in range(floors):
        c.rectangle(400, gy - (f + 1) * 62, 380, 56); c.set_source_rgba(1, 1, 1, 0.88 * a); c.fill()
        c.set_source_rgba(*NAVY, a)
        for k in range(5): c.rectangle(422 + k * 72, gy - (f + 1) * 62 + 14, 40, 28); c.fill()
    c.move_to(80, gy); c.line_to(1000, gy); stroke(c, SOFT, a, 6)
    # fence
    for x in range(110, 1000, 44):
        c.move_to(x, gy); c.line_to(x, gy - 120); stroke(c, SKY, a, 7)
    for yy in (gy - 100, gy - 40):
        c.move_to(100, yy); c.line_to(990, yy); stroke(c, SKY, a, 6)
    # rockets from the right stopped at the fence
    for k in range(2):
        ph = (tt * 0.6 + k * 0.5) % 1.0; xx = 1060 - 140 * ph * 0 - 900 * min(ph, 0.1) * 0 - (1060 - 1000) * ph * 0
        xx = 1100 - 160 * ph; yy = 760 + 160 * k + 260 * ph
        if ph < 0.75: rocket(c, xx, yy, math.pi * 0.85, 0.9, a)
        else: star(c, 960, yy, 34, a * (1 - (ph - 0.75) * 4), WHITE)
    para(c, "the *fence* around the building site", 70, 540, 1310, a=a, hl=SKY)
    text(c, "so it can keep building", 56, 540, 1430, SOFT, a=a * ap(t, wt(12, "so") - 0.1))

def sc_bal(c, t, a):
    para(c, "Deterrence can be *misused* too", 88, 540, 420, a=a, hl=YEL, maxw=960)
    # balance scale
    tilt = 0.12 * math.sin(t * 1.8); cx, cy = 540, 640
    c.move_to(cx, cy); c.line_to(cx, cy + 220); stroke(c, WHITE, a, 10)
    c.move_to(cx - 120, cy + 230); c.line_to(cx + 120, cy + 230); stroke(c, WHITE, a, 10)
    dx = 260 * math.cos(tilt); dy = 260 * math.sin(tilt)
    c.move_to(cx - dx, cy - dy); c.line_to(cx + dx, cy + dy); stroke(c, WHITE, a, 9)
    for s, col in ((-1, SKY), (1, RED)):
        px, py = cx + s * dx, cy + s * dy
        c.move_to(px, py); c.line_to(px - 60, py + 90); c.move_to(px, py); c.line_to(px + 60, py + 90); stroke(c, SOFT, a, 3)
        c.arc(px, py + 90, 70, 0, math.pi); c.set_source_rgba(*col, a); c.fill()
    q = ap(t, T_JUDGE)
    text(c, "Judge every strike:", 76, 540, 1050, WHITE, a=a * q)
    q2 = ap(t, wt(13, "attackers") - 0.1); q3 = ap(t, wt(13, "fear") - 0.1)
    pill(c, "at attackers?", 64, 540, 1190, SKY, WHITE, a=a * q2)
    pill(c, "at fear?", 64, 540, 1330, RED, WHITE, a=a * q3)

def sc_loop(c, t, a):
    y = panel(c, "top", a, label=False)
    for dx in (-150, 0, 150): person(c, 540 + dx, y + 330, 1.1, WHITE, a, face="line")
    crosshair(c, 540 + 150 * math.sin(t * 2), y + 180, 55, a)
    para(c, "Who's aiming at *civilians*?", 72, 540, y + 455, a=a, hl=RED)
    b = ap(t, T_LOOP2); y2 = panel(c, "bot", a * b, label=False)
    if b > 0:
        person(c, 720, y2 + 330, 1.15, RED, a * b, armL=(-40, 0), armR=(-120, 0), face="line")
        shield(c, 400, y2 + 200, 1.3, a * b)
        para(c, "Who's aiming at *attackers*?", 72, 540, y2 + 455, a=a * b, hl=SKY)

SCN = [sc_hook, sc_def, sc_t1, sc_t2, sc_t3, sc_spine, sc_map, sc_site, sc_bal, sc_loop]
SPLIT = {0, 1, 2, 3, 4, 9}

# ---------------------------------------------------------------- subtitles
SUBS = T["subs"]
def draw_subs(c, t):
    for a, b, s in SUBS:
        if a <= t < b:
            size = 54; lines = [s]
            if twidth(c, s, size) > 920:
                w = s.split(); best = None
                for i in range(1, len(w)):
                    l1, l2 = " ".join(w[:i]), " ".join(w[i:]); m = max(twidth(c, l1, size), twidth(c, l2, size))
                    if best is None or m < best[0]: best = (m, [l1, l2])
                lines = best[1]
            bw = max(twidth(c, l, size) for l in lines) + 56; bh = 74 * len(lines) + 20
            y0 = 1660 - bh / 2
            rrect(c, 540 - bw / 2, y0, bw, bh, 22); c.set_source_rgba(0.03, 0.07, 0.15, 0.88); c.fill()
            for i, l in enumerate(lines): text(c, l, size, 540, y0 + 10 + 37 + 74 * i, WHITE)
            return

def frame(t):
    surf = cairo.ImageSurface(cairo.FORMAT_RGB24, W, H); c = cairo.Context(surf)
    i, a0, b0 = phase(t)
    bg(c, t, 1.0 if i in SPLIT else 0.0)
    ain = 1.0 if i == 0 else ease((t - a0) / 0.3)
    SCN[i](c, t, ain)
    draw_subs(c, t)
    return surf

def to_rgb(surf):
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data())
    return a[:, :, [2, 1, 0]]

if __name__ == "__main__":
    if "--still" in sys.argv:
        i = sys.argv.index("--still"); ts = [float(x) for x in sys.argv[i + 1].split(",")]; out = sys.argv[i + 2]
        big = "--big" in sys.argv
        sz = (1080, 1920) if big else (360, 640)
        ims = [Image.fromarray(to_rgb(frame(t)).copy()).resize(sz) for t in ts]
        cols = 1 if big else min(6, len(ims))
        sheet = Image.new("RGB", (sz[0] * cols, sz[1] * math.ceil(len(ims) / cols)))
        for k, im in enumerate(ims): sheet.paste(im, (sz[0] * (k % cols), sz[1] * (k // cols)))
        sheet.save(out); print(out); sys.exit()
    out = sys.argv[2]; n = int(round(DUR * FPS))
    p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                          "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    f0 = to_rgb(frame(0)).astype(np.float32); XF = 0.45
    for f in range(n):
        t = f / FPS; im = to_rgb(frame(t))
        if t > DUR - XF:
            k = ease((t - (DUR - XF)) / XF); im = (im.astype(np.float32) * (1 - k) + f0 * k).astype(np.uint8)
        p.stdin.write(np.ascontiguousarray(im).tobytes())
    p.stdin.close(); p.wait(); print(out, n, "frames")
