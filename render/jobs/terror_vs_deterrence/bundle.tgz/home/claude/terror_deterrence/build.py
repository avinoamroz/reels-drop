import subprocess
D = "/home/claude/terror_deterrence"
subprocess.run(["python3", f"{D}/render.py", f"{D}/work/timing.json", f"{D}/work/silent.mp4"], check=True)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{D}/work/silent.mp4", "-i", f"{D}/work/mix.wav", "-map", "0:v", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", f"{D}/work/final.mp4"], check=True)
