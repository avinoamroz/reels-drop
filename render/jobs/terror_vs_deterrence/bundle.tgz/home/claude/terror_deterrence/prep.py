"""voice chain + timing. usage: prep.py RAW.wav WORDS.json tts.txt OUTDIR
House chain: rubberband pitch 0.9715 (formants kept), bass g=2 f=135, clean_vo, atempo ATEMPO, 0.3 s lead.
Word times map t' = LEAD + t / ATEMPO (pitch, bass and clean_vo keep the timeline)."""
import sys, json, re, os, subprocess, shutil
raw, wj, tts, out = sys.argv[1:5]
ATEMPO = float(os.environ.get("ATEMPO", 1.1)); LEAD = 0.3; TAIL = float(os.environ.get("TAIL", 2.0))
os.makedirs(out, exist_ok=True)
d1 = f"{out}/c_in"; d2 = f"{out}/c_out"; os.makedirs(d1, exist_ok=True); os.makedirs(d2, exist_ok=True)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", "48000", "-ac", "1", f"{d1}/vo.wav"], check=True)
subprocess.run(["python3", "/home/claude/reelkit/clean_vo.py", d1, d2], check=True)
# soft-ending restore + soft word lift (Cartesia drops line-final words; clean_vo ducks them further)
import numpy as np, soundfile as sf
_d, _sr = sf.read(f"{d1}/vo.wav"); _c, _ = sf.read(f"{d2}/vo.wav"); hop = int(0.02 * _sr)
def _rms(x): return np.sqrt(np.convolve(x ** 2, np.ones(hop) / hop, "same")) + 1e-9
m = (20 * np.log10(_rms(_d) / _rms(_c)) > 4) & (_rms(_d) > 10 ** (-50 / 20))
m = np.convolve(m.astype(float), np.ones(int(0.015 * _sr)) / int(0.015 * _sr), "same").clip(0, 1)
x = _c * (1 - m) + _d * m
_W = json.load(open(wj)); lv = []
for w in _W:
    i, j = int(w["start"] * _sr), int(w["end"] * _sr); lv.append(20 * np.log10(np.sqrt((x[i:j] ** 2).mean()) + 1e-9))
med = float(np.median(lv)); gain = np.ones(len(x))
for w, l in zip(_W, lv):
    if l < med - 7:
        g = 10 ** (min(12, med - 3 - l) / 20); i, j = int((w["start"] - 0.03) * _sr), int((w["end"] + 0.05) * _sr)
        r = int(0.02 * _sr); seg = np.full(j - i, g); seg[:r] = np.linspace(1, g, r); seg[-r:] = np.linspace(g, 1, r)
        gain[i:j] = np.maximum(gain[i:j], seg); print("lift", w["word"], round(l - med, 1), "dB")
x = x * gain; x = x / max(1, np.abs(x).max() / 0.98); sf.write(f"{d2}/vo_fix.wav", x, _sr)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{d2}/vo_fix.wav", "-af", f"atempo={ATEMPO}",
                "-ar", "48000", f"{out}/vo_t.wav"], check=True)
GAPS = {}   # extra pause after line k (s)

W = json.load(open(wj)); lines = [l.strip() for l in open(tts) if l.strip()]
norm = lambda s: re.sub(r"[^a-z0-9']", "", s.lower())
# assign words to lines in order
import numpy as np, soundfile as sf
words = []; li = 0; lw = [l.split() for l in lines]; pos = 0
for w in W:
    while li < len(lw) and pos >= len(lw[li]): li += 1; pos = 0
    words.append(dict(w=w["word"], t0=w["start"] / ATEMPO, t1=w["end"] / ATEMPO, line=li + 1))
    if norm(w["word"]) != norm(lw[li][pos]): print("warn", w["word"], "vs", lw[li][pos])
    pos += 1
# insert pauses at mid-gap between lines
x, sr = sf.read(f"{out}/vo_t.wav"); pieces = [np.zeros(int(LEAD * sr))]; prev = 0; shift = {}
acc = LEAD
for k in range(1, len(lines) + 1):
    shift[k] = acc
    if k in GAPS and k < len(lines):
        e = max(w["t1"] for w in words if w["line"] == k); b = min(w["t0"] for w in words if w["line"] == k + 1)
        cut = int((e + b) / 2 * sr); pieces += [x[prev:cut], np.zeros(int(GAPS[k] * sr))]; prev = cut; acc += GAPS[k]
pieces.append(x[prev:]); sf.write(f"{out}/vo.wav", np.concatenate(pieces), sr)
for w in words: w["t0"] += shift[w["line"]]; w["t1"] += shift[w["line"]]
L = []
for k in range(1, len(lines) + 1):
    ws = [w for w in words if w["line"] == k]; L.append([ws[0]["t0"], ws[-1]["t1"]])
dur_vo = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f"{out}/vo.wav"],
                              capture_output=True, text=True).stdout)
dur = L[-1][1] + TAIL
# subtitles: chunks of max 6 words, split at punctuation, display numbers
REPL = [("twelve thousand", "12,000"), ("twelve hundred", "1,200"), ("October seventh", "October 7"), (r"\bHamas\b", "HAMAS"), ("Three tests", "3 tests")]
subs = []
for k, line in enumerate(lines, 1):
    ws = [w for w in words if w["line"] == k]; groups = [[]]
    for w in ws:
        groups[-1].append(w)
        if re.search(r"[.?!:]$", w["w"]): groups.append([])
    groups = [g for g in groups if g]
    def split(g):
        if len(g) <= 6: return [g]
        cut = None
        for i2 in range(len(g) - 1, 0, -1):
            if g[i2 - 1]["w"].endswith(",") and 2 <= i2 <= len(g) - 2: cut = i2; break
        if cut is None:
            for i2 in range(len(g) - 2, 1, -1):
                if g[i2]["w"].lower() in ("to", "and", "from", "with", "compared"): cut = i2; break
        if cut is None: cut = (len(g) + 1) // 2
        return split(g[:cut]) + split(g[cut:])
    out_g = [p for g in groups for p in split(g)]
    for g in out_g: subs.append([g[0]["t0"], g[-1]["t1"], " ".join(x["w"] for x in g), k])
for s in subs:
    t = s[2]
    for a, b in REPL: t = re.sub(a, b, t, flags=re.I)
    s[2] = t.rstrip(",:")
for i in range(len(subs) - 1):                       # hold each chunk until the next (max 0.6 s gap)
    subs[i][1] = min(subs[i + 1][0], subs[i][1] + 0.6)
subs[-1][1] = min(dur, subs[-1][1] + 0.6)
json.dump(dict(words=words, lines=L, dur=dur, subs=[s[:3] for s in subs], vo_dur=dur_vo), open(f"{out}/timing.json", "w"), indent=1)
print("dur", round(dur, 2), "vo", round(dur_vo, 2))
for k, (a, b) in enumerate(L, 1): print(k, round(a, 2), round(b, 2), lines[k - 1][:50])
for s in subs: print(round(s[0], 2), round(s[1], 2), s[2])
