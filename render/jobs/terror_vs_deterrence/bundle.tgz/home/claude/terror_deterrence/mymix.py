"""mix voice + bed + whooshes -> -16 LUFS. usage: mymix.py timing.json vo.wav out.wav"""
import sys, json
sys.path.insert(0, "/home/claude/reelkit")
import mix as M, numpy as np
T = json.load(open(sys.argv[1])); vo = M.load(sys.argv[2]); dur = T["dur"]
music = M.bed("cinematic", dur)
fo = int(0.45 * M.SR); music[:, -fo:] *= np.linspace(1, 0.35, fo)
ph = [T["lines"][k - 1][0] - 0.15 for k in (2, 3, 5, 7, 10, 11, 12, 13, 14)]
ev = [(t, "whoosh", 0) for t in ph]
print(M.mix(vo, dur, music, ev, sys.argv[3], lufs=-16.0))
