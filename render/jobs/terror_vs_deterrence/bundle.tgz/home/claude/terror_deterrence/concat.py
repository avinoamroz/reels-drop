"""join the 3 TTS parts (0.35 s gap), shift word times. usage: concat.py out.wav out_words.json"""
import sys, json, numpy as np, soundfile as sf
R = "/home/claude/terror_deterrence/vo/"
xs = []; W = []; off = 0.0; sr0 = None
for p in range(3):
    x, sr = sf.read(f"{R}td_vo_p{p}.wav"); sr0 = sr0 or sr
    if x.ndim > 1: x = x.mean(1)
    for w in json.load(open(f"{R}td_vo_p{p}_words.json")):
        W.append(dict(word=w["word"], start=w["start"] + off, end=w["end"] + off))
    gap = np.zeros(int(0.35 * sr)); xs += [x, gap]; off += len(x) / sr + 0.35
sf.write(sys.argv[1], np.concatenate(xs[:-1]), sr0); json.dump(W, open(sys.argv[2], "w"), indent=0)
print("sr", sr0, "dur", round(off - 0.35, 2), "words", len(W))
