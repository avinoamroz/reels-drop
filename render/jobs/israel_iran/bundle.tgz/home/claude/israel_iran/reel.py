"""israel_iran: "2 Iranians hugged me. Here's why." (@noamroz__, English, 1 Nov 2026), Noam's Vienna 2016 story, the 2,500-year bond,
the regime vs the people, and what Iranians themselves demand. Engine core (Apple keynote stage, Inter, cubic fades, Ken Burns photo panels,
36 px credits, cairo stick figures and bubbles) copied from israel_feels_home/reel.py. New: hug scene, plane, seats, Israel and Iran map
(Natural Earth 1:50m, public domain) with the Shiraz to Tel Aviv arc and km counter, Persian line (DejaVu Sans Bold, RTL), checklist cards.
Loop: lead-in "Like the day…" over the hug, last 0.45 s cross-fades into frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py (silent video to work/silent.mp4)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/israel_iran"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing from the narration (work/words.json)
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):     # index of the first word in line li that starts with `word`
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(re.sub(r"\W", "", word).lower()): return i
    raise KeyError((li, word))
NL = max(LW) + 1
T_END = round(E(NL - 1) + 0.5, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = "#060608"; GLOW_COL = "#E8C77E"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
ISR_GOLD = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

# stage: one wide soft glow
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# text rasters at 2x, composited with sub-pixel placement, scale and blur (from engine_v3)
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 500: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
def capof(fk, size): return raster("H", fk, size)[3]
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0):
    """y_cap_mid: vertical middle of the capitals"""
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, 540, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)

# ------------------------------------------------------------------ photos (Ken Burns in a rounded panel)
PH = {  # key: (file, focus x, focus y, credit at 36 px)
}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
def photo(canvas, t, k, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35):
    a = seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout)) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC)
    sc = 0.97 + 0.03 * seg(t, t0, t0 + ain)
    m = rmask(w, h, 34); lay = crop.convert("RGBA"); lay.putalpha(m.point(lambda v: int(v * a)))
    if sc < 0.999:
        nw, nh = int(w * sc), int(h * sc); lay = lay.resize((nw, nh), Image.BICUBIC); x0 += (w - nw) // 2; y0 += (h - nh) // 2
    canvas.alpha_composite(lay, (int(x0), int(y0)))
def credit(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.45)

# ------------------------------------------------------------------ counters
def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def num_text(canvas, t, s, y, size, t0, t1, color=GOLD, ain=0.4):
    text(canvas, t, s, y, size, t0, t1, fk="db", color=color, tab=True, ain=ain)

# ------------------------------------------------------------------ flat layers: subtitles, sources
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)

# ================================================================== israel_feels_home
T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45
GLOW_COL = "#F0C27A"; GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
ORANGE = "#F28C28"; NAVY = "#0E1E3A"
PH.update({})
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def WX(li, word, n=1):     # index of the n-th word in line li that equals `word` (punctuation ignored)
    k = re.sub(r"\W", "", word).lower(); c = 0
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower() == k:
            c += 1
            if c == n: return i
    raise KeyError((li, word))
def SW(li, word, n=1): return S(li, WX(li, word, n))
def photo_b(canvas, t, k, t0, t1, box, ain=0.45, aout=0.35, alpha=1.0):
    x0, y0, x1, y1 = [int(round(v)) for v in box]; photo(canvas, t, k, t0, t1, (x0, y0, x1, y1), alpha=alpha, ain=ain, aout=aout)
def credit_at(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#9A9AA0", ain=0.3, inst=(t0 <= 0))
def textx(canvas, t, s, cx, y_cap_mid, size, t0, t1, fk="db", color=WHITE, ain=T_IN, aout=T_OUT, alpha=1.0):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size); put(canvas, info, cx, y_cap_mid + info[3] / 2 + dy, sc, hx(color), a * alpha, bl)
HEF = "/root/.fonts/Heebo-ExtraBold.ttf"
def hebrew(canvas, t, s, y, size, t0, t1, color=GREY):
    a, sc, bl, dy = envl(t, t0, t1)
    if a <= 0.004: return
    f = ImageFont.truetype(HEF, size); lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((540, y + dy), s, font=f, fill=tuple(int(c) for c in hx(color)) + (int(255 * a),), anchor="mm", direction="rtl", language="he")
    canvas.alpha_composite(lay)

# ------------------------------------------------------------------ cairo layer (figures, bubbles, props)
class Layer:
    def __init__(s): s.surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); s.c = cairo.Context(s.surf); s.used = False
    def done(s, canvas):
        if not s.used: return
        s.surf.flush(); a = np.ndarray((H, W, 4), np.uint8, s.surf.get_data()).astype(np.float32)
        al = a[:, :, 3:4]; rgb = np.where(al > 0, a[:, :, 2::-1] * 255.0 / np.maximum(al, 1), 0)
        canvas.alpha_composite(Image.fromarray(np.concatenate([rgb, al], 2).clip(0, 255).astype(np.uint8), "RGBA"))
def rgb(hc): v = hx(hc) / 255.0; return float(v[0]), float(v[1]), float(v[2])
def group(L_, a, fn):
    if a <= 0.004: return
    L_.used = True; c = L_.c; c.push_group(); fn(c); c.pop_group_to_source(); c.paint_with_alpha(min(1, a))
def stroke_pts(c, pts, lw, col):
    c.set_source_rgb(*rgb(col)); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()
def figure(c, x, yf, h, col, walk=0.0, arm_l=0.0, arm_r=0.0, lean=0.0, skirt=False, bag=False, sweat=0.0, smile=1.0, talk=0.0, bun=False):
    """stick figure standing on (x, yf), height h. arm_*: 0 down, 0.5 sideways, 1 up. walk: phase in radians (0 = still)."""
    lw = h * 0.062; r = h * 0.125; sw = math.sin(walk) if walk else 0.0
    hx_ = x + lean * h * 0.18; hy = yf - h + r; neck = (hx_ - lean * h * 0.02, hy + r + lw * 0.3)
    hip = (x, yf - h * 0.42); sh = (neck[0] * 0.85 + hip[0] * 0.15, neck[1] + (hip[1] - neck[1]) * 0.18)
    st = h * 0.14
    stroke_pts(c, [hip, (x - st * 0.75 + sw * st * 0.9, yf)], lw, col); stroke_pts(c, [hip, (x + st * 0.75 - sw * st * 0.9, yf)], lw, col)
    if skirt:
        c.set_source_rgb(*rgb(col)); c.move_to(hip[0] - h * 0.04, hip[1] - h * 0.12); c.line_to(hip[0] + h * 0.04, hip[1] - h * 0.12)
        c.line_to(hip[0] + h * 0.17, hip[1] + h * 0.14); c.line_to(hip[0] - h * 0.17, hip[1] + h * 0.14); c.close_path(); c.fill()
    stroke_pts(c, [neck, hip], lw, col)
    al = h * 0.36
    def arm(side, u):
        th = 0.18 + u * math.pi * 0.82                      # angle from straight down, outward
        hand = (sh[0] + side * math.sin(th) * al, sh[1] + math.cos(th) * al)
        stroke_pts(c, [sh, hand], lw, col); return hand
    hl = arm(-1, arm_l + (0.08 * -sw if walk else 0)); hr = arm(1, arm_r + (0.08 * sw if walk else 0))
    if bag:
        bw, bh = h * 0.22, h * 0.17; bx, by = hr[0] + h * 0.01, hr[1] + h * 0.03
        c.set_source_rgb(*rgb("#D9D9DE")); c.new_path(); rr(c, bx - bw / 2, by, bw, bh, h * 0.025); c.fill()
        stroke_pts(c, [(bx - bw * 0.2, by), (bx - bw * 0.2, by - h * 0.03), (bx + bw * 0.2, by - h * 0.03), (bx + bw * 0.2, by)], lw * 0.45, "#D9D9DE")
    c.set_source_rgb(*rgb(col)); c.arc(hx_, hy, r, 0, 2 * math.pi); c.fill()
    if bun: c.arc(hx_ - r * 0.15, hy - r * 1.02, r * 0.42, 0, 2 * math.pi); c.fill()
    c.set_source_rgb(*rgb(NAVY)); er = r * 0.12
    for ex in (-0.36, 0.36): c.arc(hx_ + ex * r, hy - r * 0.12, er, 0, 2 * math.pi); c.fill()
    c.set_line_width(r * 0.11); c.set_line_cap(cairo.LINE_CAP_ROUND)
    if talk > 0.02:
        c.save(); c.translate(hx_, hy + r * 0.42); c.scale(1, max(0.2, talk)); c.arc(0, 0, r * 0.2, 0, 2 * math.pi); c.restore(); c.fill()
    elif smile >= 0: c.arc(hx_, hy + r * 0.12, r * 0.4, math.pi * (0.2 - 0.08 * (1 - smile)), math.pi * (0.8 + 0.08 * (1 - smile))); c.stroke()
    else: c.arc(hx_, hy + r * 0.62, r * 0.3, math.pi * 1.2, math.pi * 1.8); c.stroke()
    if sweat > 0.02:
        c.set_source_rgba(0.78, 0.9, 1.0, min(1, sweat)); sx, sy = hx_ + r * 1.15, hy - r * 0.3
        c.move_to(sx, sy - r * 0.45); c.curve_to(sx + r * 0.32, sy, sx + r * 0.28, sy + r * 0.32, sx, sy + r * 0.32)
        c.curve_to(sx - r * 0.28, sy + r * 0.32, sx - r * 0.32, sy, sx, sy - r * 0.45); c.fill()
    return (hx_, hy, r)
def rr(c, x, y, w, h, r):
    c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
BUBF = "sb"
def bubble_shape(c, cx, cy, w, h, tip):
    c.set_source_rgb(*rgb("#F5F5F7")); rr(c, cx - w / 2, cy - h / 2, w, h, h * 0.42); c.fill()
    bx = min(max(tip[0], cx - w / 2 + 50), cx + w / 2 - 50)
    c.move_to(bx - 26, cy + h / 2 - 2); c.line_to(bx + 26, cy + h / 2 - 2); c.line_to(tip[0], tip[1]); c.close_path(); c.fill()
def bubble(canvas, L_, t, s, cx, cy, tip, t0, t1, size=60):
    a, sc, bl, dy = envl(t, t0, t1, 0.35, 0.25)
    if a <= 0.004: return
    tw = font(BUBF, size).getlength(s); w = tw + 90; h = size * 1.9; cy = cy + dy * 0.5
    pop = 0.85 + 0.15 * seg(t, t0, t0 + 0.25)
    def fn(c):
        c.translate(tip[0], tip[1]); c.scale(pop, pop); c.translate(-tip[0], -tip[1]); bubble_shape(c, cx, cy, w, h, tip)
    group(L_, a, fn); L_.done(canvas); L_.__init__()
    textx(canvas, t, s, tip[0] + (cx - tip[0]) * pop, tip[1] + (cy - tip[1]) * pop, size * pop, t0, t1, fk=BUBF, color=NAVY, ain=0.35, aout=0.25)
def house(c, cx, base, w, h, u, col=GOLD, lw=9):
    pts = [(cx - w / 2, base), (cx - w / 2, base - h * 0.62), (cx, base - h), (cx + w / 2, base - h * 0.62), (cx + w / 2, base)]
    segl = [math.dist(pts[i], pts[i + 1]) for i in range(4)]; tot = sum(segl); c.set_source_rgb(*rgb(col)); c.set_line_width(lw)
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.move_to(*pts[0]); left = tot * u
    for i in range(4):
        if left <= 0: break
        f = min(1, left / segl[i]); p0, p1 = pts[i], pts[i + 1]; c.line_to(p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f); left -= segl[i]
    c.stroke()

# ================================================================== israel_iran scenes
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
ORANGE = "#F28C28"; NAVY = "#0E1E3A"; RED = "#E5484D"
PH.update({
 "cyrus": ("cyrus.jpg", 0.52, 0.30, "Cyrus Cylinder. Photo: M. Nemat Zadeh, CC0"),
 "elal": ("elal.jpg", 0.42, 0.55, "El Al 707, 1978. Photo: Steve Fitzgerald, GFDL 1.2"),
 "berlin": ("berlin.jpg", 0.45, 0.62, "Berlin, Oct 2022. Photo: A. Sarabadani, CC BY-SA 4.0"),
})
def WX(li, word, n=1):
    k = re.sub(r"\W", "", word).lower(); c = 0
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower() == k:
            c += 1
            if c == n: return i
    raise KeyError((li, word))
def SW(li, word, n=1): return S(li, WX(li, word, n))
def photo_b(canvas, t, k, t0, t1, box, ain=0.45, aout=0.35, alpha=1.0):
    x0, y0, x1, y1 = [int(round(v)) for v in box]; photo(canvas, t, k, t0, t1, (x0, y0, x1, y1), alpha=alpha, ain=ain, aout=aout)
def credit_at(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#9A9AA0", ain=0.3)
def textx(canvas, t, s, cx, y_cap_mid, size, t0, t1, fk="db", color=WHITE, ain=T_IN, aout=T_OUT, alpha=1.0, inst=False):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size); put(canvas, info, cx, y_cap_mid + info[3] / 2 + dy, sc, hx(color), a * alpha, bl)
def textl(canvas, t, s, x0, y, size, t0, t1, fk="dsb", color=WHITE, ain=0.4):
    textx(canvas, t, s, x0 + font(fk, size).getlength(s) / 2, y, size, t0, t1, fk=fk, color=color, ain=ain)
FAF = f"{D}/fonts/DejaVuSans-Bold.ttf"
def persian(canvas, t, s, y, size, t0, t1, color=WHITE):
    a, sc, bl, dy = envl(t, t0, t1)
    if a <= 0.004: return
    f = ImageFont.truetype(FAF, size); lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((540, y + dy), s, font=f, fill=tuple(int(c) for c in hx(color)) + (int(255 * a),), anchor="mm", direction="rtl", language="fa")
    canvas.alpha_composite(lay)

# ------------------------------------------------------------------ drawn props
def heart(c, x, y, s, col=RED):
    c.save(); c.translate(x, y); c.scale(s, s); c.set_source_rgb(*rgb(col))
    c.move_to(0, 30); c.curve_to(-60, -10, -40, -60, 0, -30); c.curve_to(40, -60, 60, -10, 0, 30); c.close_path(); c.fill(); c.restore()
def hug(c, t, u, yf=1480, h=420, heart_a=0.0):
    """two Iranians (sky, acting) hug me (orange, receiving). u: 0 apart, 1 hugging"""
    d = lerp(255, 118, u); sway = 0.04 * math.sin(t * 2.2) * u
    figure(c, 540, yf, h, ORANGE, arm_l=0.12 + 0.5 * u, arm_r=0.12 + 0.5 * u, smile=1)
    figure(c, 540 - d, yf, h * 0.98, SKY, lean=0.55 * u + sway, arm_r=0.12 + 0.55 * u, arm_l=0.1, smile=1)
    figure(c, 540 + d, yf, h * 0.98, SKY, lean=-0.55 * u + sway, arm_l=0.12 + 0.55 * u, arm_r=0.1, smile=1)
    if heart_a > 0.01:
        c.push_group(); heart(c, 540, yf - h - 110, 1.15 + 0.06 * math.sin(t * 5)); c.pop_group_to_source(); c.paint_with_alpha(min(1, heart_a))
def plane(c, x, y, s=1.0, col=WHITE):
    c.save(); c.translate(x, y); c.scale(s, s); c.set_source_rgb(*rgb(col))
    c.save(); c.scale(1, 0.22); c.arc(0, 0, 95, 0, 2 * math.pi); c.restore(); c.fill()
    c.move_to(-10, -4); c.line_to(-55, -72); c.line_to(-28, -72); c.line_to(32, -4); c.close_path(); c.fill()
    c.move_to(-10, 4); c.line_to(-55, 72); c.line_to(-28, 72); c.line_to(32, 4); c.close_path(); c.fill()
    c.move_to(-70, -4); c.line_to(-98, -36); c.line_to(-84, -36); c.line_to(-58, -4); c.close_path(); c.fill()
    c.move_to(-70, 4); c.line_to(-98, 36); c.line_to(-84, 36); c.line_to(-58, 4); c.close_path(); c.fill()
    c.restore()
def seat(c, x, top=1300, w=200, h=230):
    c.set_source_rgb(*rgb("#2E2E36")); rr(c, x - w / 2, top, w, h, 30); c.fill()
    c.set_source_rgb(*rgb("#3C3C46")); rr(c, x - w / 2 + 14, top + 14, w - 28, 40, 16); c.fill()
def check(c, x, y, r, col=SKY):
    c.set_source_rgb(*rgb(col)); c.arc(x, y, r, 0, 2 * math.pi); c.fill()
    c.set_source_rgb(*rgb(NAVY)); c.set_line_width(r * 0.22); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(x - r * 0.42, y + r * 0.02); c.line_to(x - r * 0.1, y + r * 0.34); c.line_to(x + r * 0.45, y - r * 0.32); c.stroke()

# ------------------------------------------------------------------ map: Israel and Iran, Shiraz to Tel Aviv
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
MBOX = (60, 250, 1020, 1010); MV = (31.5, 24.5, 57.5, 39.5)
_MAP = {}
def mproj():
    lon0, lat0, lon1, lat1 = MV; w, h = MBOX[2] - MBOX[0], MBOX[3] - MBOX[1]; cs = math.cos(math.radians((lat0 + lat1) / 2))
    k = min(w / ((lon1 - lon0) * cs), h / (lat1 - lat0)); cx, cy = (lon0 + lon1) / 2, (lat0 + lat1) / 2
    return lambda lon, lat: (MBOX[0] + w / 2 + (lon - cx) * cs * k, MBOX[1] + h / 2 - (lat - cy) * k)
MP = mproj()
def map_img():
    if "im" in _MAP: return _MAP["im"]
    from shapely.geometry import shape, box as sbox
    G = {}
    for f in json.load(open(GEO))["features"]:
        p = f["properties"]; iso = p.get("ISO_A2") if p.get("ISO_A2") not in (None, "-99") else p.get("ADM0_A3"); G[iso] = shape(f["geometry"])
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    x0, y0, x1, y1 = MBOX; rr(c, x0, y0, x1 - x0, y1 - y0, 34); c.clip()
    c.set_source_rgb(*rgb("#0B1622")); c.paint()
    vb = sbox(MV[0] - 4, MV[1] - 4, MV[2] + 4, MV[3] + 4)
    def path(g, tol=0.03):
        g = g.intersection(vb).simplify(tol)
        for p in ([g] if g.geom_type == "Polygon" else [q for q in getattr(g, "geoms", []) if q.geom_type == "Polygon"]):
            pts = [MP(x, y) for x, y in p.exterior.coords]; c.move_to(*pts[0])
            for q in pts[1:]: c.line_to(*q)
            c.close_path()
    for k, g in G.items():
        if k in ("IL", "PS", "IR") or not g.intersects(vb): continue
        path(g); c.set_source_rgb(*rgb("#24262E")); c.fill_preserve(); c.set_source_rgb(*rgb("#3B3E48")); c.set_line_width(1.6); c.stroke()
    path(G["IR"]); c.set_source_rgb(*rgb("#1F4E74")); c.fill_preserve(); c.set_source_rgb(*rgb(SKY)); c.set_line_width(2.5); c.stroke()
    path(G["IL"], 0.01); c.set_source_rgb(*rgb("#C9A44C")); c.fill()
    path(G["PS"], 0.01); c.set_source_rgb(*rgb(ISR_GOLD)); c.fill_preserve(); c.set_source_rgb(*GREEN); c.set_line_width(2.5); c.stroke()
    s.flush(); a = np.ndarray((H, W, 4), np.uint8, s.get_data()).astype(np.float32)
    al = a[:, :, 3:4]; rgbv = np.where(al > 0, a[:, :, 2::-1] * 255.0 / np.maximum(al, 1), 0)
    _MAP["im"] = Image.fromarray(np.concatenate([rgbv, al], 2).clip(0, 255).astype(np.uint8), "RGBA"); return _MAP["im"]
TLV, SHZ = (34.78, 32.08), (52.54, 29.61)
def map_scene(canvas, t, t0, t1, Lr):
    a = seg(t, t0, t0 + 0.45) * (1 - seg(t, t1, t1 + 0.35))
    if a <= 0.004: return
    m = map_img(); sc = 0.97 + 0.03 * seg(t, t0, t0 + 0.45)
    lay = m.copy(); lay.putalpha(lay.getchannel("A").point(lambda v: int(v * a)))
    if sc < 0.999:
        lay = lay.resize((int(W * sc), int(H * sc)), Image.BICUBIC); canvas.alpha_composite(lay, (int(W * (1 - sc) / 2), int(H * (1 - sc) / 2)))
    else: canvas.alpha_composite(lay)
    p0, p1 = MP(*SHZ), MP(*TLV); ua = seg(t, t0 + 0.5, t0 + 1.7)
    def fn(c):
        mx, my = (p0[0] + p1[0]) / 2, min(p0[1], p1[1]) - 170
        c.set_source_rgb(*rgb(GOLD)); c.set_line_width(6); c.set_dash([3, 16]); c.set_line_cap(cairo.LINE_CAP_ROUND)
        n = 60; pts = [((1 - s_) ** 2 * p0[0] + 2 * (1 - s_) * s_ * mx + s_ ** 2 * p1[0], (1 - s_) ** 2 * p0[1] + 2 * (1 - s_) * s_ * my + s_ ** 2 * p1[1]) for s_ in [i / n for i in range(n + 1)]]
        k = max(1, int(n * ua))
        if ua > 0.01:
            c.move_to(*pts[0])
            for q in pts[1:k + 1]: c.line_to(*q)
            c.stroke()
        c.set_dash([])
        for p in (p0, p1):
            c.set_source_rgb(*rgb(WHITE)); c.arc(p[0], p[1], 13, 0, 2 * math.pi); c.fill()
            c.set_source_rgb(*rgb(GOLD)); c.arc(p[0], p[1], 8, 0, 2 * math.pi); c.fill()
    group(Lr, a, fn); Lr.done(canvas); Lr.__init__()
    textx(canvas, t, "Shiraz", p0[0] - 10, p0[1] + 58, 52, t0 + 0.3, t1, fk="dsb")
    textx(canvas, t, "Tel Aviv", p1[0] + 125, p1[1] + 48, 46, t0 + 0.3, t1, fk="dsb")
    textx(canvas, t, "IRAN", MP(54.0, 33.0)[0], MP(54.0, 33.0)[1], 64, t0 + 0.2, t1, fk="db", color="#BFE3FA")
    textx(canvas, t, "ISRAEL", p1[0] + 130, p1[1] - 52, 44, t0 + 0.2, t1, fk="db", color=GOLD)
    km = int(round(roll(t, t0 + 0.5, 1.2, 0, 1700) / 10) * 10)
    num_text(canvas, t, f"{km:,} km", (p0[1] + p1[1]) / 2 - 215, 76, t0 + 0.5, t1)

# ------------------------------------------------------------------ timing
B0 = S(1) - 0.15; C0 = S(2) - 0.15; D0 = S(3) - 0.15; E0_ = S(4) - 0.15; F0 = S(5) - 0.15; G0 = S(6) - 0.15
H0 = S(7) - 0.15; I0 = S(8) + 0.35; J0 = S(10) - 0.15; K1 = S(11) - 0.15; K2 = S(13) - 0.15; L0 = S(15) - 0.15
END_T = S(16) - 0.12; HOOK_END = B0
BOX = (60, 250, 1020, 760); CRED_Y = 792
HOOK_A, HOOK_B, HOOK_C = "2 Iranians", "hugged me.", "Here's why."
HS = min(fit(HOOK_A, "db", 150), fit(HOOK_B, "db", 150)); HY1, HY2 = 400, 400 + HS * 1.18
END_A = "Like the day…"
def glow_at(t):
    g = 0.09 + 0.04 * seg(t, 0, 1.2)
    g -= 0.06 * seg(t, H0, H0 + 0.5) * (1 - seg(t, I0 - 0.3, I0 + 0.3))
    g += 0.06 * seg(t, L0, L0 + 1.0)
    return max(0.02, g)

def frame_raw(t):
    im = stage(glow_at(t)); Lr = Layer()
    # ---- A. hook (line 0) and M. lead-in (line 16): same place, same hug
    zoom = 1 + 0.03 * seg(t, 0, HOOK_END)
    text(im, t, HOOK_A, HY1, HS, 0, HOOK_END, inst=True, zoom=zoom)
    text(im, t, HOOK_B, HY2, HS, 0, HOOK_END, inst=True, zoom=zoom, color=GOLD)
    text(im, t, HOOK_C, HY2 + 150, 72, 0, HOOK_END, fk="dsb", color=GREY, inst=True)
    if t < HOOK_END + 0.4:
        a = 1 - seg(t, HOOK_END, HOOK_END + 0.35); u = 0.55 + 0.45 * seg(t, 0.0, 1.0)
        group(Lr, a, lambda c: hug(c, t, u, heart_a=seg(t, 0.5, 0.9)))
    if t > END_T - 0.1:
        text(im, t, END_A, HY1 + HS * 0.6, HS, END_T, T_END + 1, ain=0.5)
        a = seg(t, END_T, END_T + 0.4); u = lerp(0.3, 0.55, seg(t, END_T, T_END - LOOP))
        group(Lr, a, lambda c: hug(c, t, u, heart_a=seg(t, T_END - LOOP - 0.3, T_END - LOOP)))
    # ---- B/C. lines 1 to 3a: Vienna 2016, two seats, the hug
    if B0 - 0.1 < t < SW(3, "My") + 0.4:
        t1 = SW(3, "My") - 0.15; hg = SW(2, "hugged") - 0.15
        a = seg(t, B0, B0 + 0.35) * (1 - seg(t, t1, t1 + 0.3))
        text(im, t, "Vienna, 2016", 400, 120, B0 + 0.05, C0, color=WHITE)
        text(im, t, "Debate competition", 530, 66, B0 + 0.3, C0, fk="dm", color=GREY)
        text(im, t, "Vienna, 2016", 400, 72, C0, D0, fk="dsb", color=GREY, ain=0.3)
        text(im, t, "I was shocked.", 470, fit("I was shocked.", "db", 130), D0 + 0.05, t1, color=GOLD)
        pu = seg(t, B0, B0 + 2.4); iw = SW(1, "two") - 0.1
        su = 1 - seg(t, hg, hg + 0.5)
        def fn(c):
            if pu < 1:
                c.set_source_rgba(1, 1, 1, 0.35); c.set_line_width(5); c.set_dash([2, 18]); c.set_line_cap(cairo.LINE_CAP_ROUND)
                px = lerp(-120, 1200, pu); py = 760 - 120 * math.sin(pu * math.pi * 0.9)
                c.move_to(-120, 760); c.curve_to(200, 700, px - 300, py + 30, px - 110, py); c.stroke(); c.set_dash([])
                plane(c, px, py, 0.9, WHITE)
            u = seg(t, hg, hg + 0.6)
            if u <= 0:
                figure(c, 540, 1480, 340, ORANGE, smile=1, sweat=0)
                for k, x in enumerate((300, 780)):
                    v = seg(t, iw + 0.15 * k, iw + 0.15 * k + 0.35)
                    if v > 0:
                        c.push_group(); figure(c, x, 1480, 340, SKY, smile=1, talk=(0.5 + 0.5 * math.sin(t * 18)) if (k == 1 and SW(2, "said") - 0.1 < t < hg) else 0)
                        c.pop_group_to_source(); c.paint_with_alpha(v)
                c.push_group()
                for x in (300, 540, 780): seat(c, x)
                c.pop_group_to_source(); c.paint_with_alpha(su)
            else:
                hug(c, t, 0.45 + 0.55 * u, yf=1480, h=380, heart_a=seg(t, hg + 0.4, hg + 0.8) * (1 - seg(t, D0, D0 + 0.4)))
                if t > D0: figure(c, 540, 1480, 380, ORANGE, arm_l=0.6, arm_r=0.6, sweat=seg(t, D0, D0 + 0.3), smile=0.2)
                c.push_group()
                for x in (300, 540, 780): seat(c, x)
                c.pop_group_to_source(); c.paint_with_alpha(su)
        group(Lr, a, fn); Lr.done(im); Lr = Layer()
        tipL, tipR = (560, 1100), (760, 1110)
        bubble(im, Lr, t, "I'm from Israel.", 470, 960, tipL, SW(2, "I'm") - 0.1, SW(2, "said") - 0.1, size=60)
        bubble(im, Lr, t, "Wow, I love Israel!", 600, 960, tipR, SW(2, "said") - 0.05, hg + 0.3, size=60)
        text(im, t, "2 Iranian guys", 800, 84, iw, C0, fk="db", color=SKY)
    # ---- D. line 3b: my father's family, Shiraz to Israel
    if SW(3, "My") - 0.3 < t < E0_ + 0.5:
        t0 = SW(3, "My") - 0.15; t1 = E0_; map_scene(im, t, t0, t1, Lr); Lr = Layer()
        s = "My father's family: Shiraz"; text(im, t, s, 1100, fit(s, "dsb", 76), t0 + 0.1, t1, fk="dsb")
        s = "I thought Iranians hate us."; text(im, t, s, 1210, fit(s, "dm", 66), SW(3, "thought") - 0.15, t1, fk="dm", color=GREY)
    # ---- E. line 4: the government vs the citizens
    if E0_ - 0.1 < t < F0 + 0.5:
        t1 = F0; g = SW(4, "government") - 0.2; ci = SW(4, "citizens") - 0.2
        text(im, t, "The government", 470, fit("The government", "db", 120), E0_ + 0.05, t1, color=RED)
        text(im, t, "hates us.", 620, 96, SW(4, "hates") - 0.15, t1, fk="dsb")
        s = "and tries to kill us."; text(im, t, s, 730, 64, SW(4, "tries") - 0.15, t1, fk="dm", color=GREY)
        text(im, t, "The citizens", 1030, 120, ci, t1, color=SKY)
        text(im, t, "love us.", 1180, 110, SW(4, "love") - 0.15, t1, color=GOLD)
        a = seg(t, E0_, E0_ + 0.3) * (1 - seg(t, t1, t1 + 0.3))
        def fn(c):
            c.set_source_rgba(1, 1, 1, 0.18); c.set_line_width(3); c.move_to(240, 880); c.line_to(840, 880); c.stroke()
            hv = seg(t, SW(4, "love") - 0.1, SW(4, "love") + 0.3)
            if hv > 0: c.push_group(); heart(c, 540, 1360, 0.9 + 0.25 * hv + 0.04 * math.sin(t * 5)); c.pop_group_to_source(); c.paint_with_alpha(hv)
        group(Lr, a, fn); Lr.done(im); Lr = Layer()
    # ---- F. line 5: 2,500 years, Cyrus
    if F0 - 0.1 < t < G0 + 0.5:
        t1 = G0; photo_b(im, t, "cyrus", F0, t1, BOX); credit_at(im, t, "cyrus", F0 + 0.1, t1, CRED_Y)
        v = int(round(roll(t, F0 + 0.15, 1.1, 0, 2500)))
        num_text(im, t, f"{v:,} years", 930, 140, F0 + 0.1, t1)
        text(im, t, "Cyrus let the Jews", 1090, 80, SW(5, "Cyrus") - 0.15, t1, fk="dsb")
        text(im, t, "rebuild the Temple.", 1190, 80, SW(5, "rebuild") - 0.15, t1, fk="dsb", color=GOLD)
    # ---- G. line 6: until 1979, friends
    if G0 - 0.1 < t < H0 + 0.5:
        t1 = H0; photo_b(im, t, "elal", G0, t1, BOX); credit_at(im, t, "elal", G0 + 0.1, t1, CRED_Y)
        text(im, t, "Until 1979", 930, 130, G0 + 0.05, t1)
        text(im, t, "we were friends.", 1080, fit("we were friends.", "db", 110), SW(6, "we") - 0.15, t1, color=GOLD)
        text(im, t, "El Al flew to Tehran", 1210, 66, SW(6, "El") - 0.15, t1, fk="dm", color=GREY)
    # ---- H. line 7: the regime
    if H0 - 0.1 < t < I0 + 0.5:
        t1 = I0; fu = SW(7, "funded") - 0.15
        text(im, t, "Then the regime", 440, fit("Then the regime", "db", 110), H0 + 0.05, t1)
        text(im, t, "cut ties.", 600, 150, SW(7, "cut") - 0.15, t1, color=RED)
        v = int(round(roll(t, fu, 0.9, 0, 700)))
        num_text(im, t, f"${v}M", 900, 190, fu, t1)
        text(im, t, "a year to Hezbollah", 1060, 76, fu + 0.15, t1, fk="dsb")
        text(im, t, "plus HAMAS and other groups", 1170, 60, fu + 0.45, t1, fk="dm", color=GREY)
    # ---- I. lines 8 and 9: the people, Woman Life Freedom
    if I0 - 0.1 < t < J0 + 0.5:
        t1 = J0; fa = E(8) + 0.05; en = S(9) - 0.15
        photo_b(im, t, "berlin", I0, t1, BOX); credit_at(im, t, "berlin", I0 + 0.1, t1, CRED_Y)
        text(im, t, "The people?", 900, 100, I0 + 0.05, fa, color=SKY)
        persian(im, t, "زن، زندگی، آزادی", 920, 104, fa, t1)
        text(im, t, "Zan, Zendegi, Azadi", 1030, 56, fa + 0.2, t1, fk="dm", color=GREY)
        text(im, t, "Woman, Life, Freedom", 1150, fit("Woman, Life, Freedom", "db", 100), en, t1, color=GOLD)
    # ---- J/K. lines 10 to 14: what needs to happen
    if J0 - 0.1 < t < L0 + 0.5:
        t1 = L0; up = seg(t, K1 - 0.1, K1 + 0.45)
        a = seg(t, J0, J0 + 0.4) * (1 - seg(t, t1, t1 + 0.3))
        y1 = lerp(820, 330, up); y2 = lerp(990, 330, up); sz = lerp(140, 76, up)
        if up < 0.999:
            text(im, t, "What needs", y1, sz, J0 + 0.05, t1, alpha=1 - up)
            text(im, t, "to happen?", y2, sz, J0 + 0.2, t1, color=GOLD, alpha=1 - up)
        if up > 0.001: text(im, t, "What needs to happen?", 330, 76, K1, t1, color=GOLD, alpha=up, ain=0.01)
        rows1 = [("Free elections", SW(11, "Free") - 0.1), ("Political prisoners free", S(12) - 0.1),
                 ("Women free to choose", SW(12, "Women") - 0.1), ("Open internet", SW(12, "Open") - 0.1)]
        rows2 = [("Peaceful strikes", S(13) - 0.1), ("Forces won't turn on people", SW(13, "Security") - 0.1),
                 ("A united opposition", SW(14, "united") - 0.15), ("The world backs the people", SW(14, "world") - 0.1)]
        YS = [560, 780, 1000, 1220]
        for rows, r0, r1 in ((rows1, K1, K2), (rows2, K2, t1)):
            for (s, ta), y in zip(rows, YS):
                ta = max(ta, r0 + 0.05); ra = seg(t, ta, ta + 0.35) * (1 - seg(t, r1, r1 + 0.3))
                if ra <= 0: continue
                sz = fit(s, "dsb", 72, maxw=800)
                def fn(c, y=y, ra=ra, ta=ta):
                    c.set_source_rgba(1, 1, 1, 0.06); rr(c, 70, y - 82, 940, 164, 40); c.fill()
                    check(c, 150, y, 38 * (0.8 + 0.2 * seg(t, ta, ta + 0.25)))
                group(Lr, ra, fn); Lr.done(im); Lr = Layer()
                textl(im, t, s, 215, y, sz, ta, r1)
        text(im, t, "No unelected council vetting candidates", 1400, 50, SW(11, "unelected") - 0.15, K2, fk="dm", color=GREY)
        text(im, t, "Nonviolent campaigns win 53% of the time.", 1400, 50, SW(14, "world") + 0.1, t1, fk="dsb", color=GOLD)
        text(im, t, "Violent ones: 26%.", 1470, 50, SW(14, "world") + 0.4, t1, fk="dm", color=GREY)
    # ---- L. line 15: safe, free, healthy lives, and maybe we hug again
    if L0 - 0.1 < t < END_T + 0.4:
        t1 = END_T; mb = SW(15, "maybe") - 0.15
        WD = (("Safe.", "safe"), ("Free.", "free"), ("Healthy.", "healthy")); full = " ".join(w for w, _ in WD); fs = fit(full, "db", 110, maxw=940)
        x = 540 - font("db", fs).getlength(full) / 2
        for k, (s, w_) in enumerate(WD):
            textx(im, t, s, x + font("db", fs).getlength(s) / 2, 620, fs, SW(15, w_) - 0.15, mb, fk="db", color=[WHITE, WHITE, GOLD][k])
            x += font("db", fs).getlength(s + " ")
        text(im, t, "Iranians can live", 470, 76, L0 + 0.05, mb, fk="dsb", color=SKY)
        text(im, t, "And maybe", 470, 110, mb, t1, color=WHITE)
        text(im, t, "we hug again.", 620, 120, SW(15, "hug") - 0.15, t1, color=GOLD)
        a = seg(t, L0, L0 + 0.4) * (1 - seg(t, END_T, END_T + 0.3)); u = lerp(0.0, 0.3, seg(t, mb, END_T))
        group(Lr, a, lambda c: hug(c, t, u))
    Lr.done(im)
    sources(im, t); subtitles(im, t)
    return im

# ------------------------------------------------------------------ subtitles (hero text carries lines 0, 9, 10, 16)
SKIP = {0, 9, 10, 16}
REPL = []
def chunks(li):
    ws = [w["w"] for w in LW[li]]; out = []; cur = []
    for i, w in enumerate(ws):
        cur.append(i)
        if (w[-1] in ".,?!:" and len(cur) >= 3) or len(cur) >= 6: out.append(cur); cur = []
    if cur:
        if out and len(cur) <= 2 and len(out[-1]) + len(cur) <= 7: out[-1] += cur
        else: out.append(cur)
    return out
SUBS = []
for li in range(NL):
    if li in SKIP: continue
    cs = chunks(li)
    for k, ids in enumerate(cs):
        s = " ".join(LW[li][i]["w"] for i in ids).rstrip(":")
        a = S(li, ids[0]) - 0.04; b = E(li, ids[-1]) + 0.35
        if k + 1 < len(cs): b = min(b, S(li, cs[k + 1][0]) - 0.06)
        elif li + 1 < NL: b = min(b, S(li + 1) - 0.06)
        SUBS.append((a, b, s)); assert len(s.split()) <= 7, s
SUB_Y = 1610; SRC_Y = 1760
def subtitles(canvas, t):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12)
            lines = wrap(s, SUBF, 900); lay_h = 68 * len(lines) + 30
            ww = max(SUBF.getlength(l) for l in lines) + 56
            box = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(box).rounded_rectangle(
                (540 - ww / 2, SUB_Y - lay_h / 2, 540 + ww / 2, SUB_Y + lay_h / 2), 22, fill=(8, 8, 12, int(170 * al)))
            canvas.alpha_composite(box); flat(canvas, lines, SUBF, SUB_Y, 68, "#FFFFFF", 0.96 * al)
SOURCES = [(0, []), (B0, ["Noam's own story, Vienna, 2016"]), (SW(3, "My") - 0.15, ["Shiraz to Tel Aviv: about 1,700 km,", "straight line"]),
           (E0_, []), (F0, ["Book of Ezra 1; Cyrus decree,", "about 538 BCE"]),
           (G0, ["Iran recognised Israel de facto, 6 Mar 1950.", "El Al flew Tel Aviv to Tehran (JTA, 2015)"]),
           (H0, ["Ties cut Feb 1979. US State Dept: N. Sales,", "Nov 2018; Terrorism Report 2020"]),
           (I0, ["Mahsa Amini, 22, died in morality police", "custody, 16 Sep 2022 (UN fact-finding, 2024)"]),
           (J0, []), (K1, ["Freedom House 2026: Iran 10/100, Not Free.", "Guardian Council disqualifies candidates"]),
           (K2, ["Chenoweth and Stephan, Why Civil", "Resistance Works, 2011 (1900 to 2006)"]), (L0, [])]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if lines and t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, SRC_Y, 50, "#9A9AA0", a)

F0IMG = None
def frame(t):
    global F0IMG
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0IMG is None: F0IMG = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0IMG, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + [v[3] for v in PH.values()] + [HOOK_A, HOOK_B, HOOK_C, END_A] + L
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam\b|follow", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
for v in PH.values(): assert font("r", 36).getlength(v[3]) <= 980, v[3]
assert len((HOOK_A + " " + HOOK_B + " " + HOOK_C).split()) <= 6

N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
