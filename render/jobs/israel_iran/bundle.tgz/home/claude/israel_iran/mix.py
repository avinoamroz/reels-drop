"""local step: warm Middle Eastern bed (shabbat_record/shabbat_audio.py: D freygish, oud-ish pluck, hand drum, reed) re-timed so a whole
number of bars (about 100 BPM) fills T_END, cut from bar 4 on so the groove is full at frame 0 and the last bar resolves into bar 4 on the loop;
strings swell under the hopeful ending (lines 10 to 16); soft hits on the turn (line 4) and on "What needs to happen?" (line 10). Method: together_works/mix.py."""
import sys, os, json, types, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/israel_iran"
src = open("/home/claude/shabbat_record/shabbat_audio.py").read().replace("bpm = 104;", "bpm = BPM;")
SA = types.ModuleType("sa"); SA.__dict__["__file__"] = "/home/claude/shabbat_record/shabbat_audio.py"
W = json.load(open(f"{D}/work/words.json"))["words"]
LS = lambda li: min(w["t0"] for w in W if w["li"] == li)
LE = lambda li: max(w["t1"] for w in W if w["li"] == li)
T_END = round(LE(16) + 0.55, 2); BARS = round(T_END * 100 / 240); BPM = 4 * 60 * BARS / T_END; bar = 4 * 60 / BPM
SA.__dict__["BPM"] = BPM; exec(compile(src, "shabbat_audio_ii", "exec"), SA.__dict__)
SR = SA.SR; assert SR == AU.SR
pre = 4 * bar; s0 = LS(10) - 0.3 + pre; s1 = LS(16) - 0.2 + pre
raw = SA.music(T_END + pre + bar, swell=(s0, s1), end_fade=0.01)
i0 = int(round(pre * SR)); n = int(round(T_END * SR)); xf = int(0.6 * SR)
bed = raw[:, i0:i0 + n].copy(); tail = raw[:, i0 + n:i0 + n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
head = raw[:, i0 - int(0.02 * SR):i0]          # no click at the loop point: tiny pre-roll blend
# fix 1 Nov: duck the bed 9 dB under "I'm from Israel" (line 2; ASR heard "him from Israel" under the music), 0.15 s ramps
w2 = [w for w in W if w["li"] == 2]; k = [i for i, w in enumerate(w2) if w["w"] == "I'm"][0]
d0, d1 = w2[k]["t0"] - 0.25, w2[k + 2]["t1"] + 0.15; tq = np.arange(bed.shape[1]) / SR
u = np.clip(np.minimum((tq - (d0 - 0.15)) / 0.15, ((d1 + 0.15) - tq) / 0.15), 0, 1); bed = bed * (1 - u * (1 - 10 ** (-9 / 20)))[None, :]
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(LS(4) - 0.05, AU.soft_hit(), -10.0), (LS(10) - 0.05, AU.soft_hit(), -11.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, T_END, ev, mw, music_db=-18.0, sfx_db=-14.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=T_END, bpm=BPM, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", T_END, BPM, J.get("final_I"), J.get("final_TP"))
