"""israel_iran voice: Cartesia SSE parts (clips/p*.wav + _words.json) -> work/vo.wav (48 kHz, house chain) + work/words.json. From israel_feels_home/tools/voice_build.py.
Persian "Zan, Zendegi, Azadi" is on screen only (Cartesia: unsupported language fa): a 1.35 s pause after line 8 carries it."""
import json, re, sys, wave
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
D = "/home/claude/israel_iran"; SR0 = 44100; TEMPO = 1.15; V.TEMPO = TEMPO; LEAD = 0.12; V.LEAD = LEAD
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
parts = json.load(open(f"{D}/work/tts_parts.json"))[:4]
GAP = {0: 0.40, 1: 0.22, 2: 0.32, 3: 0.25, 4: 0.45, 5: 0.30, 6: 0.25, 7: 0.30, 8: 0.95, 9: 0.42, 10: 0.28, 11: 0.25, 12: 0.25, 13: 0.30, 14: 0.35, 15: 0.30}
MAXG = 0.21
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
def env_db(x, h=441):
    n = len(x) // h; return 10 * np.log10((x[:n * h].reshape(n, h) ** 2).mean(1) + 1e-12)
def map_words(script_words, W):
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sn = [norm(x) for x in script_words]; stot = sum(max(1, len(x)) for x in sn); pos = 0; out = []
    for x, n_ in zip(script_words, sn):
        Ln = max(1, len(n_)); f0, f1 = pos / stot, (pos + Ln) / stot; pos += Ln
        out.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
    return out
SPOKEN = {1: "In twenty sixteen, in Vienna, two Iranian guys sat next to me.", 5: "Our bond is two and a half thousand years old. Cyrus let the Jews rebuild the Temple.", 6: "Until nineteen seventy-nine, we were friends. El Al flew to Tehran."}
PAUSE = {2: [(7.63, 0.10)]}                      # raw p0 time (end of the "d" in "heard"), pause in s
FIXL = {1, 2, 3, 4}                                    # lines re-cut at the real pause (no internal pause trim, as before)
LINES = {}
for k, P in enumerate(parts):
    a = load(f"{D}/clips/p{k}.wav"); W = json.load(open(f"{D}/clips/p{k}_words.json"))
    # fix 1 Nov (0:07 glitch): map the SPOKEN transcript (numbers spelled as Cartesia said them) onto Cartesia's words first, so
    # line cuts land in the real pauses; the old char mapping of "2016," drifted 0.5 s and cut line 1 inside "next" (doubled "next").
    sw = []; owner = []
    for li in P["lines"]:
        for x in SPOKEN.get(li, L[li]).split(): sw.append(x); owner.append(li)
    mw = map_words(sw, W)
    sw0 = [x for li in P["lines"] for x in L[li].split()]; own0 = [li for li in P["lines"] for x in L[li].split()]
    mw0 = map_words(sw0, W)                       # the old mapping: every other line keeps its exact cut and pacing
    for li in P["lines"]:
        if li in FIXL:
            Wl = [dict(word=m[0], start=m[1], end=m[2]) for m, o in zip(mw, owner) if o == li]
            LINES[li] = (a, map_words(L[li].split(), Wl))
        else: LINES[li] = (a, [m for m, o in zip(mw0, own0) if o == li])
NATIVE = {}
chunks = []; words = []; t = 0.0
for li in range(len(L)):
    a, ws = LINES[li]
    if li in NATIVE: s0, e0 = 0.0, len(a) / SR0
    else: s0 = max(0, ws[0][1] - 0.06); e0 = min(len(a) / SR0, ws[-1][2] + (0.35 if li == len(L) - 1 else 0.10))
    keep = []; cur = s0
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][2], ws[i + 1][1]
        if g1 - g0 > (9.0 if li in FIXL else MAXG):
            ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
    keep.append((cur, e0))
    pz = {}                                   # fix 1 Nov: a short breath after "heard" so "heard I'm" no longer reads as "heard him"
    for xs, dur in PAUSE.get(li, []):
        for i_, (k0, k1) in enumerate(keep):
            if k0 < xs < k1: keep[i_:i_ + 1] = [(k0, xs), (xs, k1)]; pz[xs] = dur; break
    def mp(x):
        acc = 0.0
        for k0, k1 in keep:
            if x <= k1: return t + acc + max(0, x - k0)
            acc += k1 - k0 + pz.get(k1, 0.0)
        return t + acc
    for w_, a_, b_ in ws: words.append(dict(li=li, w=w_, p0=mp(a_), p1=mp(max(b_, a_ + 0.04))))
    for k0, k1 in keep:
        seg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(seg) // 2, int(0.008 * SR0))
        if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        chunks.append(seg); t += len(seg) / SR0
        if k1 in pz: chunks.append(np.zeros(int(pz[k1] * SR0), np.float32)); t += pz[k1]
    if li in GAP: chunks.append(np.zeros(int(GAP[li] * SR0), np.float32)); t += GAP[li]
raw = np.concatenate(chunks); sf.write(f"{D}/work/raw.wav", raw, SR0)
dry = V.chain_dry(f"{D}/work/raw.wav"); cl = V.clean_vo(dry, V.SR); y, sp = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{D}/work/vo.wav", vo.astype(np.float32), V.SR)
for w in words: w["t0"] = round(LEAD + w.pop("p0") / TEMPO, 3); w["t1"] = round(LEAD + w.pop("p1") / TEMPO, 3)
json.dump(dict(words=words, dur=round(len(vo) / V.SR, 3)), open(f"{D}/work/words.json", "w"), indent=0, ensure_ascii=False)
import os; os.remove(f"{D}/work/raw.wav")
print("vo", round(len(vo) / V.SR, 2), "s")
for li in range(len(L)):
    ws = [w for w in words if w["li"] == li]; print(li, ws[0]["t0"], ws[-1]["t1"], L[li])
