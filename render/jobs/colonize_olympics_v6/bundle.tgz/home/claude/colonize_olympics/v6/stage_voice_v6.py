"""Colonization Olympics v6 voice: v5 narration lines 1 to 13 (rebuilt from out_v4/vo.wav exactly as v5 was cut:
voice.select dropping the King David line and the old comments line), a silent gap for the 50-names slide,
then the two new Cartesia lines (same clone, house chain: pitch 0.9715 formant preserved, bass, clean_vo,
soft-ending restore, atempo 1.1), level matched to lines 1 to 13. Timing for new lines from Cartesia word stamps."""
import os, sys, json
sys.path.insert(0, "/home/claude/reelkit"); os.nice(5)
import numpy as np, soundfile as sf
import voice as V
from clean_vo import clean as clean_vo
SR = V.SR
B = "/home/claude/colonize_olympics/build"; OUT = f"{B}/out_v6"; os.makedirs(OUT, exist_ok=True)
GAP_SLIDE = float(os.environ.get("GAP_SLIDE", "3.75"))   # line 13 end -> line 14 start (names slide lives in here)
GAP_14_15 = 0.55

v4, _ = sf.read(f"{B}/out_v4/vo.wav"); t4 = json.load(open(f"{B}/out_v4/timing.json"))
keep = [0, 1, 2, 3] + list(range(5, 14))            # v4 lines minus King David (4) and the comments line (14)
vo, tim = V.select(v4, t4, keep, gap_max=0.6, gap_new=0.38)
t5 = json.load(open(f"{B}/out_v5/timing.json"))
dev = max(abs(a["t0"] - b["t0"]) + abs(a["t1"] - b["t1"]) for a, b in zip(tim["lines"], t5["lines"][:13]))
print("rebuild vs v5 timing max deviation (s):", round(dev, 4)); assert dev < 0.02

def act_rms(x):
    n = int(0.05 * SR); m = len(x) // n; e = np.sqrt((x[:m * n].reshape(m, n) ** 2).mean(1)); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
ref = act_rms(vo[int(tim["lines"][8]["t0"] * SR):])   # level of the later v5 lines (medcards part)

# new lines through the house chain
raw = "/home/claude/colonize_olympics/v6/co_v6_end.wav"; W = json.load(open("/home/claude/colonize_olympics/v6/co_v6_end_words.json"))
dry = V.chain_dry(raw); cl = clean_vo(dry, SR); y, spans = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
y = V.tempo(y)                                        # reel-speed, word time = cartesia / TEMPO
split = (4.09 + 4.61) / 2 / V.TEMPO                   # between "world." and "Not"
segA = y[:int(split * SR)]; segB = y[int(split * SR):]
g = ref / act_rms(y); segA = segA * g; segB = segB * g
fa = int(0.01 * SR); segB[:fa] *= np.linspace(0, 1, fa); segA[-fa:] *= np.linspace(1, 0, fa)
tail = int(0.35 * SR); segB = np.concatenate([segB, np.zeros(tail)])

L13_end = tim["lines"][-1]["t1"]
w14 = [w for w in W if w["start"] < 4.3]; w15 = [w for w in W if w["start"] >= 4.3]
st14 = L13_end + GAP_SLIDE                            # reel time of "So"
offA = st14 - w14[0]["start"] / V.TEMPO
st15 = offA + w14[-1]["end"] / V.TEMPO + GAP_14_15
offB = st15 - (w15[0]["start"] / V.TEMPO - split)
n = int((offB + len(segB) / SR) * SR) + 1; out = np.zeros(n); out[:len(vo)] = vo
ka = int(round(offA * SR)); out[ka:ka + len(segA)] += segA
kb = int(round(offB * SR)); out[kb:kb + len(segB)] += segB

lines = tim["lines"]; words = tim["words"]
texts = [l.strip() for l in open("/home/claude/colonize_olympics/script_lines_v6.txt", encoding="utf-8") if l.strip()]
for li, (ws, off, base) in ((13, (w14, offA, 0.0)), (14, (w15, offB, split))):
    ww = [dict(w=w["word"], line=li, t0=round(off + w["start"] / V.TEMPO - base, 3), t1=round(off + w["end"] / V.TEMPO - base, 3), matched=True, src_line=li) for w in ws]
    words += ww; lines.append(dict(i=li, text=texts[li], t0=ww[0]["t0"], t1=ww[-1]["t1"], recall=1.0, missing=[], src_line=li))
for L in lines: L["src_line"] = L["i"]
for w in words: w["src_line"] = w["line"]
tim = dict(lines=lines, words=words, dur=round(len(out) / SR, 3), selected=list(range(15)))
V.write(OUT, out, tim, dict(base="out_v4/vo.wav via voice.select (as v5)", new=raw, gain_db=round(20 * np.log10(g), 2),
                            restored_spans=len(spans), chain="house chain + atempo 1.1, timing from Cartesia word stamps"))
for L in lines[-4:]: print(L["i"], L["t0"], L["t1"], L["text"])
print("dur", tim["dur"], "gain", round(20 * np.log10(g), 2), "dB")
