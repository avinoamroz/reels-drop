"""apartheid_world v2 (31 Oct): cards_grid with big text, cards sized to their content and centred (Noam: [0:15] fix text)."""
import math
import render as RD
from render import P, T, PP, block, block_h, shadow_box, col, icon_of, draw_emoji, heading, source, CONTENT_BOTTOM
from kit import St

def sc_cards_grid(c, t, S):
    y = heading(c, t, S) + 30; cards = S["cards"]; ts = S["times"]["cards"]; n = len(cards)
    cols = S.get("cols", 2 if n <= 4 else 3); rows = -(-n // cols)
    gap = 28; cw = (940 - gap * (cols - 1)) / cols
    vsz = 120 if cols == 2 else 92; lsz = 64 if cols == 2 else 52; isz = 150 if cols == 2 else 120
    lab_h = max(block_h(cd.get("label", ""), lsz, 800, cw - 40, 3) for cd in cards)
    ch = 40 + isz + 20 + (vsz * 1.1 if any(cd.get("value") for cd in cards) else 0) + 10 + lab_h + 44
    avail = CONTENT_BOTTOM - y - 10; top = y + max(0, (avail - (rows * ch + (rows - 1) * gap)) / 2) * 0.6
    for k, cd in enumerate(cards):
        r_, q = divmod(k, cols); in_row = min(cols, n - r_ * cols)
        x0 = 70 + (940 - (in_row * cw + (in_row - 1) * gap)) / 2 + q * (cw + gap); y0 = top + r_ * (ch + gap)
        a, s = PP(t, ts[k], S, s0=0.5, bounce=1.6)
        if a <= 0.01: continue
        cx, cy = x0 + cw / 2, y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
        shadow_box(c, x0, y0, cw, ch, 30, P["card"], stroke=col(cd.get("color"), "navy"), sw=5)
        yy = y0 + 40
        if icon_of(cd): draw_emoji(c, icon_of(cd), cx, yy + isz / 2, isz, rot=0.04 * math.sin(t * 2 + k))
        yy += isz + 20
        if cd.get("value"): T(c, cd["value"], vsz, cx, yy + vsz * 0.5, col(cd.get("value_color"), "blue"), 1, 1, 900, maxw=cw - 30); yy += vsz * 1.1 + 10
        block(c, cd.get("label", ""), lsz, cx, yy + lab_h / 2, P["navy"], 1, 1, 800, maxw=cw - 40, max_lines=3)
        c.restore(); St.a = old
    source(c, t, S)
