"""Bespoke reelkit scenes for the "inner scar" self-talk reel (@noamroz__).
Loaded through the spec field "scene_module". Each sc_<name>(c, t, S) is scene type <name>; S["times"][mark] per "marks".
A line-art figure (navy outline, translucent skin) carries a chest scar: hidden inside, shown outside, healed in gold."""
import math
import cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, draw_emoji
from kit import ease, ramp, lerp, St, sa, rr, line as kline, circ, box, mix, hx

def M(S, k, d=None): return S["times"].get(k, d if d is not None else S["t0"] + 0.3)
def xfade(t, a0, a1, d=0.25):
    if a1 is None: return ramp(t, a0, a0 + d)
    return ramp(t, a0, a0 + d) * (1 - ramp(t, a1, a1 + d))
SCAR = hx("#C0504A")      # red with a little gold in it
SOFT = hx("#8FA0B8")

# ------------------------------------------------------------------ heading with timed phases
def phases(c, t, S, ph, y=300, sz=70, hsz=46):
    """ph = [(t_start, en, he), ...]; each phase cross-fades into the next"""
    for k, (pa, en, he) in enumerate(ph):
        pb = ph[k + 1][0] if k + 1 < len(ph) else None
        if k == 0:
            a, sc = PP(t, S["t0"] + 0.05, S); a *= 1 - (ramp(t, pb, pb + 0.2) if pb else 0)
        else:
            a, sc = PP(t, pa, S, s0=0.7, bounce=1.2); a *= 1 - (ramp(t, pb, pb + 0.2) if pb else 0)
        if a <= 0.01: continue
        breathe = 1 + 0.012 * math.sin(t * 2.2)
        h = block_h(en, sz, 900, 940, 3)
        block(c, en, sz, 540, y + h / 2, P["navy"], a, sc * breathe, hl=P["blue"], maxw=940, max_lines=3)
        if he:
            hh = block_h(he, hsz, 700, 940, 2)
            block(c, he, hsz, 540, y + h + 18 + hh / 2, P["blue"], a, sc, w=700, maxw=940, max_lines=2)

# ------------------------------------------------------------------ the figure
def _spline(c, pts):
    n = len(pts); c.move_to(*pts[0])
    for i in range(n):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[(i + 1) % n], pts[(i + 2) % n]
        c.curve_to(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, *p2)
    c.close_path()
LEFT = [(-24, -496), (-66, -476), (-98, -448), (-110, -392), (-116, -326), (-120, -262), (-108, -236), (-92, -258),
        (-90, -330), (-76, -398), (-66, -350), (-58, -290), (-70, -228), (-64, -150), (-52, -80), (-46, -24), (-58, -4),
        (-16, -4), (-20, -26), (-22, -96), (-14, -190)]
def body_pts(bow=0.0, tall=0.0):
    out = []
    for x, y in LEFT:
        if y < -380: x *= 1 - 0.07 * bow; y += 18 * bow * (1 if y < -440 else 0.6)
        y *= 1 + 0.025 * tall
        out.append((x, y))
    right = [(-x, y) for x, y in reversed(out)]
    return out + [(0, -196 * (1 + 0.025 * tall))] + right
def figure(c, x, y, s, a=1.0, bow=0.0, tall=0.0, colr=None, skin=0.55, scar=0.0, scar_mode="in", heal=0.0, seam=0.0, lw=6.5):
    """feet at (x, y); s = px per unit (figure is ~620 units tall). scar = draw progress 0..1"""
    if a <= 0.01: return
    colr = colr or P["navy"]; old = St.a; St.a *= a
    c.save(); c.translate(x, y); c.scale(s, s)
    pts = body_pts(bow, tall)
    # ground shadow
    c.save(); c.scale(1, 0.18); c.new_sub_path(); c.arc(0, 0, 120, 0, 2 * math.pi); sa(c, P["navy"], 0.10); c.fill(); c.restore()
    _spline(c, pts); sa(c, P["white"], skin); c.fill()
    hx_, hy = 4 * bow, -556 * (1 + 0.025 * tall) + 40 * bow
    # scar under the skin
    sc_t = 1 - heal
    if scar > 0 and scar_mode == "in" and sc_t > 0.01: _scar(c, scar, SCAR, 6.0, sc_t)
    if scar_mode == "in" and (scar > 0 or heal > 0):
        _spline(c, pts); sa(c, mix(P["white"], P["bg0"], 0.4), 0.42); c.fill()           # the translucent layer over it
    if heal > 0.01:
        g = cairo.RadialGradient(0, -395, 0, 0, -395, 150); gc = P["gold2"]
        g.add_color_stop_rgba(0, gc[0], gc[1], gc[2], 0.75 * heal * St.a * (0.85 + 0.15 * math.sin(RD.kit.CUR["t"] * 3)))
        g.add_color_stop_rgba(1, gc[0], gc[1], gc[2], 0); c.set_source(g); c.arc(0, -395, 150, 0, 2 * math.pi); c.fill()
    if seam > 0.01: _scar(c, 1.0, P["gold"], 4.0, seam, stitches=False)
    # outline
    _spline(c, pts); sa(c, colr); c.set_line_width(lw / s); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
    # neck + head
    c.save(); c.translate(hx_, hy); c.scale(1, 1 - 0.06 * bow); c.new_sub_path(); c.arc(0, 0, 52, 0, 2 * math.pi)
    sa(c, P["white"], skin); c.fill_preserve(); sa(c, colr); c.set_line_width(lw / s); c.stroke(); c.restore()
    if scar > 0 and scar_mode == "out":
        _scar(c, scar, P["red"], 7.5, 1.0, glow=True, big=1.35)
    c.restore(); St.a = old
SCAR_PTS = [(-40, -430), (-26, -418), (-14, -404), (-2, -398), (10, -386), (22, -372), (38, -360)]
def _scar(c, u, colr, w, a=1.0, stitches=True, glow=False, big=1.0):
    pts = [(x * big, -395 + (y + 395) * big) for x, y in SCAR_PTS]; n = len(pts) - 1; m = u * n
    path = [pts[0]]
    for i in range(n):
        if m >= i + 1: path.append(pts[i + 1])
        elif m > i: f = m - i; path.append((lerp(pts[i][0], pts[i + 1][0], f), lerp(pts[i][1], pts[i + 1][1], f))); break
    if len(path) < 2: return
    c.set_line_cap(cairo.LINE_CAP_ROUND)
    if glow: kline(c, path, colr, w * 3.2, 0.18 * a)
    kline(c, path, colr, w, a)
    if stitches:
        for i in range(1, n):
            if m < i: break
            (x0, y0), (x1, y1) = pts[i - 1], pts[i + 1]; ang = math.atan2(y1 - y0, x1 - x0) + math.pi / 2; L = 10 * big
            px, py = pts[i]; kline(c, [(px - L * math.cos(ang), py - L * math.sin(ang)), (px + L * math.cos(ang), py + L * math.sin(ang))], colr, w * 0.55, a)

# ------------------------------------------------------------------ bubbles, eyes, people, aura
def bubble(c, x, y, en, he=None, kind="inner", a=1.0, sc=1.0, tail=(0, 1), w=None, label=None, strike=0.0, sz=48):
    """kind: inner (dashed navy, translucent), outer (solid, red edge), kind (gold)"""
    if a <= 0.01 or sc <= 0.01: return
    f = RD.font(sz, 800); tw = f.getlength(en.replace("*", "")); bw = w or max(300, tw + 90); bh = sz * 1.9 + (sz * 0.9 if he else 0)
    old = St.a; St.a *= a; c.save(); c.translate(x, y); c.scale(sc, sc)
    edge = {"inner": P["navy"], "outer": P["red"], "kind": P["gold"]}[kind]
    fill = {"inner": P["white"], "outer": P["white"], "kind": hx("#FFF8EA")}[kind]
    tx_, ty_ = tail
    sa(c, P["navy"], 0.10); rr(c, -bw / 2 + 3, -bh / 2 + 10, bw, bh, 34); c.fill()
    # tail
    bx = bw * 0.18 * (1 if tx_ >= 0 else -1); by = bh / 2 if ty_ > 0 else -bh / 2
    if kind == "inner":   # thought dots toward the head
        for k, r in enumerate((14, 9)):
            circ(c, bx + tx_ * (40 + 34 * k), by + ty_ * (28 + 30 * k), r, fill, 0.92, stroke=edge, sw=4)
    else:
        c.move_to(bx - 22, by - ty_ * 2); c.line_to(bx + tx_ * 60, by + ty_ * 52); c.line_to(bx + 22, by - ty_ * 2); c.close_path()
        sa(c, fill); c.fill_preserve(); sa(c, edge); c.set_line_width(5); c.stroke()
    rr(c, -bw / 2, -bh / 2, bw, bh, 34); sa(c, fill, 0.9 if kind == "inner" else 1.0); c.fill_preserve(); sa(c, edge)
    c.set_line_width(5)
    if kind == "inner": c.set_dash([16, 11])
    c.stroke(); c.set_dash([])
    if kind != "inner":   # cover the tail joint
        c.move_to(bx - 19, by - ty_ * 4); c.line_to(bx + 19, by - ty_ * 4); sa(c, fill); c.set_line_width(8); c.stroke()
    ty0 = -bh / 2 + sz * 0.95
    T(c, en, sz, 0, ty0 + (0 if he else 0), P["navy"] if kind != "kind" else P["gold_text"], 1, 1, 800, maxw=bw - 40)
    if he: T(c, he, int(sz * 0.72), 0, ty0 + sz * 0.98, P["blue"] if kind != "kind" else P["gold_text"], 1, 1, 700, maxw=bw - 40)
    if strike > 0:
        L = (tw + 40) * strike; kline(c, [(-tw / 2 - 20, ty0 + 4), (-tw / 2 - 20 + L, ty0 - 4)], P["red"], 9, 1)
    c.restore()
    if label:
        pill(c, label, 32, x, y - bh / 2 * sc - 30, P["navy"], P["white"], a, sc, outline=P["gold"], w=800)
    St.a = old
def eye(c, x, y, s, tx, ty, a=1.0, t=0.0, seed=0):
    if a <= 0.01: return
    bl = 1.0 - 0.9 * max(0.0, 1 - abs(((t * 0.6 + seed * 0.37) % 3.0) - 1.5) / 0.08) if True else 1
    old = St.a; St.a *= a; c.save(); c.translate(x, y); c.scale(s, s * max(0.12, bl))
    c.move_to(-40, 0); c.curve_to(-18, -28, 18, -28, 40, 0); c.curve_to(18, 28, -18, 28, -40, 0); c.close_path()
    sa(c, P["white"]); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(4 / s * 1.0); c.stroke()
    d = math.hypot(tx - x, ty - y) or 1; ox, oy = 12 * (tx - x) / d, 9 * (ty - y) / d
    circ(c, ox, oy, 13, P["navy"]); circ(c, ox + 4, oy - 4, 4, P["white"])
    c.restore(); St.a = old
def bust(c, x, y, s, colr, a=1.0, tx=None, ty=None):
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(x, y); c.scale(s, s)
    c.new_sub_path(); c.arc(0, 40, 46, math.pi, 2 * math.pi); c.close_path(); sa(c, colr, 0.85); c.fill()
    circ(c, 0, -14, 24, colr, 0.85)
    if tx is not None:
        d = math.hypot(tx - x, ty - y) or 1; ox, oy = 5 * (tx - x) / d, 4 * (ty - y) / d
        for ex in (-8, 8): circ(c, ex + ox, -16 + oy, 4.2, P["white"])
    c.restore(); St.a = old
def aura(c, x, y, rx, ry, a=1.0, t=0.0):
    if a <= 0.01: return
    gc = P["gold2"]; c.save(); c.translate(x, y); c.scale(rx / 300, ry / 300)
    g = cairo.RadialGradient(0, 0, 120, 0, 0, 300)
    g.add_color_stop_rgba(0, gc[0], gc[1], gc[2], 0.0); g.add_color_stop_rgba(0.75, gc[0], gc[1], gc[2], 0.28 * a * St.a)
    g.add_color_stop_rgba(1, gc[0], gc[1], gc[2], 0); c.set_source(g); c.arc(0, 0, 300, 0, 2 * math.pi); c.fill()
    for k in range(2):
        r = 268 + 10 * math.sin(t * 2 + k * 1.7) + k * 16
        c.new_sub_path(); c.arc(0, 0, r, 0, 2 * math.pi); sa(c, P["gold"], (0.55 - 0.25 * k) * a); c.set_line_width(4 * 300 / rx); c.stroke()
    c.restore()
def spark(c, x, y, u, colr=None):
    if u <= 0 or u >= 1: return
    colr = colr or P["gold"]
    for k in range(7):
        ang = k * 2 * math.pi / 7; r0, r1 = 10 + 40 * u, 24 + 60 * u
        kline(c, [(x + r0 * math.cos(ang), y + r0 * math.sin(ang)), (x + r1 * math.cos(ang), y + r1 * math.sin(ang))], colr, 5, 1 - u)
def chest(x, y, s, big=1.0): return x, y - 395 * s

# ================================================================== 1. hook: a scar nobody sees (lines 1-2)
def sc_hook(c, t, S):
    tm = S["times"]
    phases(c, t, S, [(S["t0"], "When you talk badly to yourself, it's a *scar nobody sees.*", "כשאתם מדברים לעצמכם לא יפה, זו צלקת שאף אחד לא רואה."),
                     (M(S, "ashamed"), "Maybe you're ashamed of it. But you can still *stand tall.*", "אולי אתם מתביישים בה. אבל אפשר לעמוד זקוף, כי אף אחד לא רואה.")])
    fx, fy, fs = 540, 1530, 1.33
    scar = 0.3 + 0.7 * ease(t / 1.2)
    tall = ramp(t, M(S, "tall"), M(S, "tall") + 0.6)
    breathe = 0.012 * math.sin(t * 1.8)
    figure(c, fx, fy, fs * (1 + breathe), scar=scar, tall=tall)
    # the inner voice
    bubble(c, 815, 830, "So stupid.", "כזה טיפש.", "inner", 1.0, 1.0 + 0.02 * math.sin(t * 2.5), tail=(-1, 1), label="Me, to me")
    # nobody sees it: soft "hidden" tag at the chest
    cx, cy = chest(fx, fy, fs); a = ramp(t, 0.5, 0.9)
    kline(c, [(cx + 70, cy), (cx + 170, cy - 30)], P["grey"], 3, a)
    T(c, "inside", 34, cx + 230, cy - 38, P["grey"], a, 1, 700)
    # stand tall: gold rule along the figure
    if tall > 0.01:
        x0 = fx - 230; ya, yb = fy, fy - 640 * fs * tall
        kline(c, [(x0, ya), (x0, yb)], P["gold"], 6, 0.9); kline(c, [(x0, yb), (x0 - 18, yb + 26)], P["gold"], 6, 0.9); kline(c, [(x0, yb), (x0 + 18, yb + 26)], P["gold"], 6, 0.9)
        a2, s2 = PP(t, M(S, "nobody"), S, bounce=2.2)
        pill(c, "nobody sees it", 36, fx, fy - 80, P["navy"], P["white"], a2, s2, outline=P["gold"], w=800)

# ================================================================== 2. someone else says it (lines 3-4)
def sc_outside(c, t, S):
    tm = S["times"]
    phases(c, t, S, [(S["t0"], "Now someone else says *the same words.*", "עכשיו מישהו אחר אומר לכם את אותן מילים. באותו טון."),
                     (M(S, "sudden"), "Suddenly, you *can't look them in the eye.*", "ופתאום קשה להסתכל לו בעיניים. קשה לדבר. האגו נפגע.")])
    mx_, my, ms = 730, 1530, 1.18
    ox, oy, os_ = 270, 1530, 0.98
    ts = M(S, "sudden"); bow = ramp(t, M(S, "look"), M(S, "look") + 0.8)
    out = ramp(t, ts, ts + 0.5)
    a0 = fade_in(t, S["t0"] + 0.1, S, 0.4)
    figure(c, ox, oy, os_, a0, colr=P["blue"], skin=0.4)
    if out >= 0.01:
        figure(c, mx_, my, ms, scar=0.0, bow=bow)                     # skin only
        old = St.a; St.a *= out; c.save(); c.translate(mx_, my); c.scale(ms, ms); _scar(c, 1.0, P["red"], 7.5, 1.0, glow=True, big=1.35); c.restore(); St.a = old
    else:
        figure(c, mx_, my, ms, scar=1.0, bow=bow)
    # the same words, twice
    a1, s1 = PP(t, S["t0"] + 0.15, S)
    bubble(c, 880, 680 + 20 * bow, "So stupid.", None, "inner", a1, s1, tail=(-1, 1), label="Me, to me", sz=44)
    a2, s2 = PP(t, M(S, "same"), S)
    bubble(c, 300, 820, "So stupid.", "כזה טיפש.", "outer", a2, s2, tail=(1, 1), sz=48)
    a3, s3 = PP(t, M(S, "same2"), S, bounce=2.4)
    pill(c, "same words", 34, 560, 690, P["gold"], P["white"], a3, s3, w=800)
    # everyone looks
    cx, cy = chest(mx_, my, ms)
    E = [(560, 960), (980, 870), (1000, 1110), (590, 1220), (965, 1330), (120, 1040), (450, 1090), (1010, 640)]
    for k, (ex, ey) in enumerate(E):
        tk = ts + 0.1 + 0.09 * k; a, sc = PP(t, tk, S, s0=0.3)
        if a > 0.01: eye(c, ex, ey + 6 * math.sin(t * 2 + k), 0.75 * sc, cx, cy, a, t, k)
    B = [(110, 1440, 0.9), (470, 1470, 0.8), (980, 1470, 0.95), (880, 1500, 0.7)]
    for k, (bx, by, bs) in enumerate(B):
        a = fade_in(t, ts + 0.3 + 0.1 * k, S, 0.3); bust(c, bx, by, bs, SOFT, a, cx, cy)
    if out > 0.01:
        a4, s4 = PP(t, ts + 0.35, S, bounce=2.2)
        pill(c, "now it shows", 34, mx_ + 0, cy + 150, P["red"], P["white"], a4, s4, w=800)

# ================================================================== 3. split: inside vs outside (line 5)
def sc_split(c, t, S):
    phases(c, t, S, [(S["t0"], "The words *didn't change.*", "המילים לא השתנו."),
                     (M(S, "changed"), "What changed: now *other people can see the scar.*", "מה שהשתנה: עכשיו אחרים רואים את הצלקת.")])
    y0, y1 = 600, 1550
    for k in range(2):
        a, sc = PP(t, S["t0"] + 0.1 + 0.25 * k, S, s0=0.8, bounce=1.2)
        if a <= 0.01: continue
        x0 = 55 if k == 0 else 555; w = 470; xc = x0 + w / 2
        old = St.a; St.a *= a
        shadow_box(c, x0, y0, w, y1 - y0, 30, P["card"], 0.55, stroke=P["navy"] if k == 0 else P["red"], sw=4)
        T(c, "INSIDE" if k == 0 else "OUTSIDE", 40, xc, y0 + 52, P["navy"] if k == 0 else P["red"], 1, 1, 900)
        T(c, "בפנים" if k == 0 else "בחוץ", 34, xc, y0 + 100, P["grey"], 1, 1, 700)
        fy = y1 - 40; fs = 0.92
        if k == 0:
            figure(c, xc, fy, fs, scar=1.0)
        else:
            bow = ramp(t, M(S, "see"), M(S, "see") + 0.6) * 0.8 + 0.2
            figure(c, xc, fy, fs, scar=1.0, scar_mode="out", bow=bow)
            cx, cy = chest(xc, fy, fs)
            for j, (ex, ey) in enumerate([(x0 + 60, y0 + 330), (x0 + w - 60, y0 + 360), (x0 + 50, y0 + 610), (x0 + w - 50, y0 + 640)]):
                aa = fade_in(t, M(S, "see") + 0.08 * j, S, 0.25); eye(c, ex, ey, 0.55, cx, cy, aa, t, j)
        bubble(c, xc, y0 + 205, "So stupid.", None, "inner" if k == 0 else "outer", 1, 1, tail=(0.3, 1), w=330, sz=44)
        St.a = old
    a, sc = PP(t, S["t0"] + 0.7, S, bounce=2.4)
    if a > 0.01:
        circ(c, 540, 805, 34, P["gold"], a); T(c, "=", 52, 540, 801, P["white"], a, sc, 900)

# ================================================================== 4. me, to me + would I say this to a friend? (lines 6-8)
def sc_me_to_me(c, t, S):
    tl, tf, tx_, tk = M(S, "listen"), M(S, "catch"), M(S, "cross"), M(S, "kindb")
    phases(c, t, S, [(S["t0"], "We say those words to *ourselves first.*", "ואת המילים האלה אנחנו אומרים קודם כל לעצמנו."),
                     (tl, "So start inside. Listen to *how you talk to yourself.*", "אז מתחילים מבפנים. תקשיבו איך אתם מדברים לעצמכם."),
                     (tf, "Catch the line. Would I say this *to a friend?*", "תתפסו את המשפט ותשאלו: הייתי אומר את זה לחבר?")])
    fx, fy, fs = 330, 1530, 1.2
    figure(c, fx, fy, fs, scar=1.0, bow=0.15 * (1 - ramp(t, tk, tk + 0.6)))
    hxy = (fx, fy - 556 * fs)
    # harsh inner bubble
    a, sc = PP(t, S["t0"] + 0.25, S)
    st = ramp(t, tx_, tx_ + 0.35); gone = ramp(t, tk - 0.05, tk + 0.3)
    bubble(c, 750, 840 - 40 * gone, "I'm so stupid.", "אני כזה טיפש.", "inner", a * (1 - 0.65 * gone), sc * (1 - 0.15 * gone), tail=(-1, 1),
           label="Me, to me", strike=st, sz=50)
    # listen: sound arcs toward the head
    al = xfade(t, tl, tf, 0.25)
    if al > 0.01:
        for k in range(3):
            ph = (t * 1.2 + k / 3) % 1.0; r = 30 + 60 * ph
            c.new_sub_path(); c.arc(hxy[0] + 70, hxy[1], r, -0.7, 0.7); sa(c, P["blue"], al * (1 - ph)); c.set_line_width(5); c.stroke()
    # catch: gold brackets around the line
    ac = xfade(t, tf, tk, 0.2)
    if ac > 0.01:
        x0, x1, ya, yb = 520, 980, 760, 920
        for sx, xx in ((1, x0), (-1, x1)):
            kline(c, [(xx + 26 * sx, ya), (xx, ya), (xx, yb), (xx + 26 * sx, yb)], P["gold"], 7, ac)
    # the friend
    af, sf = PP(t, M(S, "friend"), S)
    if af > 0.01:
        figure(c, 850, 1530, 0.72, af, colr=P["blue"], skin=0.45)
        a2, s2 = PP(t, M(S, "friend") + 0.15, S, bounce=2.6)
        circ(c, 950, 1165, 40, P["blue"], a2); T(c, "?", 56, 950, 1165, P["white"], a2, s2, 900)
    # kinder line replaces it
    a3, s3 = PP(t, tk, S, s0=0.6, bounce=1.5)
    bubble(c, 720, 1040, "I made a mistake. I'll fix it.", "טעיתי. אני אתקן.", "kind", a3, s3, tail=(-1, -1), sz=44)

# ================================================================== 5. softer, kinder + words bounce off (lines 9-10)
def sc_soft(c, t, S):
    ts, tkd, tb, tw = M(S, "softer"), M(S, "kinder"), M(S, "because"), M(S, "words")
    phases(c, t, S, [(S["t0"], "Then change it, gradually. *Softer. Kinder.*", "ואז משנים, בהדרגה. ברכות. בטוב לב."),
                     (tb, "When the voice inside is kind, the words outside have *less to hold on to.*", "כשהקול בפנים טוב, למילים מבחוץ יש פחות במה להיאחז.")],
           sz=64)
    fx, fy, fs = 540, 1530, 1.2
    heal = ramp(t, ts - 0.1, tkd + 0.6)
    au = ramp(t, tb, tb + 0.8)
    aura(c, fx, fy - 330 * fs, 300, 470, au, t)
    figure(c, fx, fy, fs, scar=1.0, heal=heal, seam=0.35 * heal, bow=0.1 * (1 - heal))
    a1, s1 = PP(t, S["t0"] + 0.1, S); a1 *= 1 - ramp(t, tb, tb + 0.3)
    bubble(c, 820, 860, "I'll fix it.", "אני אתקן.", "kind", a1, s1, tail=(-1, 1), sz=44)
    for k, (wd, at) in enumerate(((("Soft", ts)), ("Kind", tkd))):
        a, sc = PP(t, at, S, bounce=2.4); a *= 1 - ramp(t, tb, tb + 0.3)
        pill(c, ["softer", "kinder"][k], 38, 220 if k == 0 else 860, 1180, P["gold"], P["white"], a, sc, w=800)
    # outside words fly in and bounce off the aura
    W_ = [("So stupid.", -1, 980), ("Not enough.", 1, 1120), ("Failure.", -1, 1290), ("Too much.", 1, 960)]
    for k, (wd, side, yy) in enumerate(W_):
        t0 = tw + 0.35 * k
        if t < t0: continue
        u = (t - t0) / 1.6
        if u >= 1: continue
        hw = RD.font(36, 700).getlength(wd) / 2 + 30; edge = 540 + side * (480 - hw)   # pill stays inside x 60..1020
        xh = 540 + side * min(480 - hw, 300 + hw - 30); y0_ = yy - 250
        if u < 0.4: f = ease(u / 0.4) ** 0.8; x = lerp(edge, xh, f); y = lerp(y0_, yy, f); a = ramp(u, 0, 0.12)
        else: v = 1 - (1 - (u - 0.4) / 0.6) ** 2; x = lerp(xh, edge, v); y = lerp(yy, yy + 180, v); a = 1 - (u - 0.4) / 0.6
        pill(c, wd, 36, x, y, P["white"], P["grey"], a, 1, outline=P["silver"], w=700)
        spark(c, xh - side * (hw - 10), yy, (u - 0.38) / 0.3)

# ================================================================== 6. stand tall again (line 11)
def sc_tall(c, t, S):
    phases(c, t, S, [(S["t0"], "The people who stand tallest aren't the ones *nobody criticizes.*", "מי שעומד הכי זקוף הוא לא מי שאף אחד לא מבקר."),
                     (M(S, "theyre"), "They're the ones who *stopped beating themselves up* first.", "אלה מי שהפסיקו להלקות את עצמם קודם.")],
           y=350, sz=64)
    fx, fy, fs = 540, 1530, 1.2
    tall = ramp(t, S["t0"], S["t0"] + 0.8)
    aura(c, fx, fy - 330 * fs, 290, 460, 0.6 * ramp(t, M(S, "theyre"), M(S, "theyre") + 0.8), t)
    figure(c, fx, fy, fs * (1 + 0.01 * math.sin(t * 1.6)), tall=tall, seam=0.45)
    x0 = fx - 250; ya, yb = fy, fy - 650 * fs * ease(tall)
    kline(c, [(x0, ya), (x0, yb)], P["gold"], 6, 0.9)
    if tall > 0.9:
        kline(c, [(x0, yb), (x0 - 18, yb + 26)], P["gold"], 6, 0.9); kline(c, [(x0, yb), (x0 + 18, yb + 26)], P["gold"], 6, 0.9)

# ================================================================== 7. CTA: tell me in the comments (line 12; replaces the built-in cta)
def sc_cta(c, t, S):
    t0 = S["t0"]; tk = S["times"]["keyword"]
    a, sc = PP(t, t0 + 0.05, S)
    h = block_h(S["en"], 70, 900, 940, 3); block(c, S["en"], 70, 540, 330 + h / 2, P["navy"], a, sc * (1 + 0.01 * math.sin(t * 2)), hl=P["blue"], maxw=940, max_lines=3)
    y = 330 + h + 20
    a, sc = PP(t, t0 + 0.2, S); hh = block_h(S["he"], 54, 700, 940, 2); block(c, S["he"], 54, 540, y + hh / 2, P["blue"], a, sc, w=700, maxw=940); y += hh + 50
    # comment card with the kind line typed in
    a, sc = PP(t, tk - 0.05, S, bounce=1.6)
    if a > 0.01:
        cy = y + 110; old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(sc, sc)
        shadow_box(c, -440, -100, 880, 200, 40, P["card"], stroke=P["gold"], sw=5)
        circ(c, -360, 0, 46, P["blue"]); circ(c, -360, -12, 16, P["white"]); c.new_sub_path(); c.arc(-360, 34, 28, math.pi, 2 * math.pi); sa(c, P["white"]); c.fill()
        T(c, "Tell me in the *comments*", 58, 50, -2, P["navy"], 1, 1, 900, hl=P["gold_text"], maxw=650)
        c.restore(); St.a = old
        y = cy + 130
        draw_emoji(c, "👇", 540, y + 70 + 12 * math.sin(t * 6), 120, a, sc); y += 170
        T(c, S["he2"], 56, 540, y, P["blue"], a, sc, 700); y += 110
    tf = tk + 0.5; a, sc = PP(t, tf, S)
    T(c, S.get("follow", "Follow *@noamroz__*"), 54, 540, min(y, 1420) + 10, P["navy"], a, sc, 800, hl=P["gold_text"])
    figure(c, 900, 1545, 0.42, fade_in(t, t0 + 0.3, S, 0.4), seam=0.45) if y < 1300 else None
