"""fetch_sse.py NAME FILE_ID OUT_MP4: runs on a GitHub render machine. Downloads a TTS1 sse file from Drive (several URL forms),
parses it, writes OUT_MP4 (black 1080x1920 video + ALAC audio of the voice) and prints the word timings as compact JSON."""
import sys, json, base64, wave, subprocess, urllib.request
name, fid, out = sys.argv[1:4]
URLS = [f"https://drive.usercontent.google.com/download?id={fid}&export=download&confirm=t",
        f"https://drive.google.com/uc?export=download&id={fid}&confirm=t",
        f"https://drive.google.com/uc?export=download&id={fid}"]
raw = None
for u in URLS:
    try:
        req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"})
        b = urllib.request.urlopen(req, timeout=120).read()
        if b[:600].lower().find(b"<html") >= 0 or b[:600].lower().find(b"<!doctype") >= 0:
            print("HTML from", u, b[:400].decode("utf-8", "replace").replace("\n", " ")[:400]); continue
        raw = b.decode("utf-8", "replace"); print("OK", u, len(b)); break
    except Exception as e:
        print("ERR", u, e)
if raw is None: sys.exit(3)
if raw.lstrip().startswith("{"):
    try: raw = base64.b64decode(json.loads(raw)["content"]).decode("utf-8", "replace")
    except Exception: pass
pcm = bytearray(); words = []
for line in raw.splitlines():
    if not line.startswith("data:"): continue
    try: ev = json.loads(line[5:].strip())
    except Exception: continue
    if ev.get("type") == "chunk" and ev.get("data"): pcm += base64.b64decode(ev["data"])
    wt = ev.get("word_timestamps")
    if wt:
        for w, s, e in zip(wt["words"], wt["start"], wt["end"]): words.append([w, round(s, 3), round(e, 3)])
wav = "/tmp/v.wav"
with wave.open(wav, "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100); w.writeframes(bytes(pcm))
d = len(pcm) / 88200
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"color=black:s=1080x1920:r=30:d={d:.3f}", "-i", wav,
                "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "alac", "-shortest", out], check=True)
print("WORDS" + json.dumps(words, separators=(",", ":")))
print(round(d, 2), "s", len(words), "words")
