"""empires_israel: "The greatest empires in history. And Israel?" (@noamroz__, English, 1 Nov 2026).
Apple keynote look from series_more/safe_p2_v3 (near-black stage, one soft glow, Inter only, cubic fades with blur-in, rolling
hero numbers), plus: a vector world map (cairo) with a moving camera and each empire's peak extent in gold, Ken Burns photo
panels (Wikimedia Commons, credited at 36 px), and the reveal zoom from the British Empire down to Israel.
Circular: the hook is said once at frame 0; the last line "So next time someone calls Israel an empire, show them..." sits
where the hook sits, and the last 0.45 s cross-fade into the exact frame 0.
usage: python3 reel.py [--snaps 0,3.1,...] (snaps to work/snaps) | python3 reel.py (silent video to work/silent.mp4)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/empires_israel"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing from the narration (work/words.json)
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):     # index of the first word in line li that starts with `word`
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(word.lower()): return i
    raise KeyError((li, word))
NL = max(LW) + 1
T_END = round(E(NL - 1) + 0.5, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = "#060608"; GLOW_COL = "#E8C77E"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
ISR_GOLD = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

# stage: one wide soft glow
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# text rasters at 2x, composited with sub-pixel placement, scale and blur (from engine_v3)
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 500: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
def capof(fk, size): return raster("H", fk, size)[3]
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0):
    """y_cap_mid: vertical middle of the capitals"""
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, 540, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)

# ------------------------------------------------------------------ geography
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    out = []
    for p in polys:
        for r in p: out.append(np.array(r, float))
    return out
def bounds(rs):
    a = np.concatenate(rs); return a[:, 0].min(), a[:, 1].min(), a[:, 0].max(), a[:, 1].max()
WORLD = {k: rings_of(v) for k, v in G["world"].items()}; WB = {k: bounds(v) for k, v in WORLD.items() if v}
LOCAL = {k: rings_of(v) for k, v in G["local"].items()}; LB = {k: bounds(v) for k, v in LOCAL.items() if v}
EMP = {k: rings_of(v) for k, v in G["empires"].items()}
EMP["umayyad"] = [r for r in EMP["umayyad"] if r[:, 0].mean() > -11]
ISR = rings_of(G["israel"]); PSX = rings_of(G["psx"]); SINAI = rings_of(G["sinai"]); GAZA = rings_of(G["gaza"])
for k in ("ISR", "PSX"): WORLD.pop(k, None); WB.pop(k, None)

class Cam:
    def __init__(s, lon, lat, k, cy): s.lon, s.lat, s.k, s.cy = lon, lat, k, cy
    @property
    def cosf(s): return math.cos(math.radians(min(55, max(0, abs(s.lat))))) * 0.15 + 0.80
def cam_lerp(a, b, u):
    return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.k), math.log(b.k), u)), lerp(a.cy, b.cy, u))
def path(c, cam, rings):
    kx = cam.k * cam.cosf; ky = cam.k
    for r in rings:
        xs = 540 + (r[:, 0] - cam.lon) * kx; ys = cam.cy - (r[:, 1] - cam.lat) * ky
        c.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): c.line_to(x, y)
        c.close_path()
def visible(cam, b, y0, y1):
    kx = cam.k * cam.cosf
    x0 = 540 + (b[0] - cam.lon) * kx; x1 = 540 + (b[2] - cam.lon) * kx
    yt = cam.cy - (b[3] - cam.lat) * cam.k; yb = cam.cy - (b[1] - cam.lat) * cam.k
    return x1 > -20 and x0 < W + 20 and yb > y0 - 20 and yt < y1 + 20 and (x1 - x0) + (yb - yt) > 0.6
def rgb(h): v = hx(h) / 255; return float(v[0]), float(v[1]), float(v[2])
def draw_map(canvas, cam, y0, y1, alpha, layers, fade=150):
    """layers: list of (rings, fill hex, fill alpha, stroke hex or None) drawn over the land"""
    if alpha <= 0.004: return
    hgt = int(y1 - y0); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, hgt); c = cairo.Context(surf)
    c.translate(0, -y0); c.set_line_join(cairo.LINE_JOIN_ROUND)
    hw = 540 / (cam.k * cam.cosf); hh = (y1 - y0) / 2 / cam.k
    local = cam.k > 25 and cam.lon - hw > 24 and cam.lon + hw < 46 and cam.lat - hh > 22 and cam.lat + hh < 40
    for k, rs in WORLD.items():
        if local and k in LOCAL: continue
        if k not in WB or not visible(cam, WB[k], y0, y1): continue
        path(c, cam, rs)
    if local:
        for k, rs in LOCAL.items():
            if k in LB and visible(cam, LB[k], y0, y1): path(c, cam, rs)
    c.set_source_rgb(*rgb("#24252C")); c.fill_preserve(); c.set_source_rgb(*rgb("#3A3B44")); c.set_line_width(1.0); c.stroke()
    for rs, fill, fa, stroke in layers:
        if fa <= 0.004 or not rs: continue
        path(c, cam, rs); c.set_source_rgba(*rgb(fill), fa); c.fill_preserve()
        if stroke: c.set_source_rgba(*rgb(stroke), min(1, fa * 1.2)); c.set_line_width(1.6); c.stroke()
        else: c.new_path()
    surf.flush()
    a = np.ndarray((hgt, W, 4), np.uint8, surf.get_data()).copy()
    rgba = a[:, :, [2, 1, 0, 3]].astype(np.float32)
    al = rgba[:, :, 3:4] / 255.0; col = np.where(al > 0, rgba[:, :, :3] / np.maximum(al, 1e-6), 0)   # un-premultiply
    m = np.ones(hgt, np.float32)
    f = min(fade, hgt // 3); r = np.arange(f) / f; m[:f] = ease_arr(r); m[-f:] = ease_arr(r[::-1])
    al = al * m[:, None, None] * alpha
    lay = Image.fromarray(np.dstack([col, al * 255]).clip(0, 255).astype(np.uint8), "RGBA")
    canvas.alpha_composite(lay, (0, int(y0)))
def ease_arr(u): return np.where(u < 0.5, 4 * u ** 3, 1 - (-2 * u + 2) ** 3 / 2)
def ll2xy(cam, lon, lat): return 540 + (lon - cam.lon) * cam.k * cam.cosf, cam.cy - (lat - cam.lat) * cam.k

# ------------------------------------------------------------------ photos (Ken Burns in a rounded panel)
PH = {  # key: (file, focus x, focus y, credit at 36 px)
 "alex": ("alex.jpg", 0.30, 0.45, "Alexander Mosaic. Photo: Magrippa, CC BY-SA 3.0"),
 "rome": ("rome.jpg", 0.50, 0.52, "Colosseum. Photo: David Iliff, CC BY-SA 2.5"),
 "umayyad": ("umayyad.jpg", 0.52, 0.42, "Umayyad Mosque. Photo: B. Gagnon, CC BY-SA 3.0"),
 "mongol": ("mongol.jpg", 0.50, 0.40, "Genghis Khan, Yuan era album. Public domain"),
 "napo": ("napo.jpg", 0.50, 0.17, "Jacques-Louis David, 1812. Public domain"),
 "us": ("us.jpg", 0.50, 0.40, "John Gast, American Progress, 1872. Public domain"),
 "russia": ("russia.jpg", 0.30, 0.24, "Nicholas II by Ernst Lipgart. Public domain"),
 "brit": ("brit.jpg", 0.50, 0.42, "Walter Crane, Empire map, 1886. Public domain"),
 "sinai": ("sinai.jpg", 0.50, 0.36, "Begin, Carter, Sadat, 1978. Public domain"),
}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
def photo(canvas, t, k, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35):
    a = seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout)) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC)
    sc = 0.97 + 0.03 * seg(t, t0, t0 + ain)
    m = rmask(w, h, 34); lay = crop.convert("RGBA"); lay.putalpha(m.point(lambda v: int(v * a)))
    if sc < 0.999:
        nw, nh = int(w * sc), int(h * sc); lay = lay.resize((nw, nh), Image.BICUBIC); x0 += (w - nw) // 2; y0 += (h - nh) // 2
    canvas.alpha_composite(lay, (int(x0), int(y0)))
def credit(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.45)

# ------------------------------------------------------------------ the beats
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def num_idx(li, w): return WI(li, w)
BEATS = [  # key, line, name, year label, value, decimals, first number word, map layers, camera (lon, lat, width deg), source lines
 dict(k="alex", li=1, name="Alexander the Great", year="Macedonia, 323 BCE", v=5.2, dec=1, nw="Five", emp=["alex"], cam=(47, 33, 64),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: historical-basemaps"]),
 dict(k="rome", li=2, name="Roman Empire", year="117 CE", v=5.0, dec=0, nw="Five", emp=["rome"], cam=(15, 39, 58),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: historical-basemaps"]),
 dict(k="umayyad", li=3, name="Umayyad Caliphate", year="720 CE", v=11.1, dec=1, nw="Eleven", emp=["umayyad"], cam=(22, 30, 112),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: historical-basemaps, Iberia added"]),
 dict(k="mongol", li=4, name="Mongol Empire", year="1270", v=24.0, dec=0, nw="Twenty", emp=["mongol"], cam=(80, 42, 132),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: historical-basemaps"]),
 dict(k="napo", li=5, name="Napoleon's France", year="1813, with client states", v=2.1, dec=1, nw="Two", emp=["napo"], cam=(9, 46, 44),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: modern borders"]),
 dict(k="us", li=6, name="United States", year="1783 to 1867", v=9.2, v0=2.3, dec=1, nw="two", nw2="nine", emp=["us1783", "us1867"],
      cam=(-110, 47, 128), src=["Sum of US acquisitions to 1867, Wikipedia", "Map approx.: historical-basemaps"]),
 dict(k="russia", li=7, name="Russian Empire", year="1895", v=22.8, dec=1, nw="Twenty", emp=["russia"], cam=(92, 56, 196),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: historical-basemaps"]),
 dict(k="brit", li=8, name="British Empire", year="1920. The largest ever", v=35.5, dec=1, nw="Thirty", emp=["brit"], cam=(12, 12, 352),
      src=["Peak land area: Taagepera, via Wikipedia", "Map approx.: modern borders"]),
]
MAP_Y0, MAP_Y1 = 905, 1335; MAP_CY = (MAP_Y0 + MAP_Y1) / 2
PH_BOX = (60, 250, 1020, 690); CRED_Y = 718; NAME_Y = 790; YEAR_Y = 868; NUM_Y = 1415; UNIT_Y = 1512
for b in BEATS: b["t0"] = S(b["li"]) - 0.22
for i, b in enumerate(BEATS):
    b["t1"] = (BEATS[i + 1]["t0"] if i + 1 < len(BEATS) else S(9) - 0.3)
    lon, lat, wd = b["cam"]; c = Cam(lon, lat, 1, MAP_CY); b["camo"] = Cam(lon, lat, 1060 / (wd * c.cosf), MAP_CY)
    b["tn"] = S(b["li"], num_idx(b["li"], b["nw"])) - 0.05
    b["tn2"] = S(b["li"], num_idx(b["li"], b["nw2"])) - 0.05 if "nw2" in b else None
HOOK_CAM = Cam(15, 18, 1060 / (352 * 0.9), 1080); HOOK_MAP = (640, 1520)
REV_T = S(9) - 0.3                              # "And Israel?"
ISR_CAM = Cam(35.1, 31.5, 1060 / (7.4 * 0.93), 1000); REV_MAP = (560, 1330)
SIN_T = S(11) - 0.2; SIN_CAM = Cam(34.0, 30.4, 1060 / (10.8 * 0.93), 1035); SIN_MAP = (740, 1335)
GAZ_T = S(12) - 0.2; GAZ_CAM = Cam(34.55, 31.42, 1060 / (2.3 * 0.93), 980); GAZ_MAP = (600, 1335)
END_T = S(13) - 0.2

def camera(t):
    """(cam, y0, y1) of the map at time t"""
    b0 = BEATS[0]
    if t < b0["t0"]:
        z = 1 + 0.035 * seg(t, 0, b0["t0"]); c = Cam(HOOK_CAM.lon, HOOK_CAM.lat, HOOK_CAM.k * z, HOOK_CAM.cy); return c, *HOOK_MAP
    if t < REV_T:
        prev = HOOK_CAM; prect = HOOK_MAP
        for b in BEATS:
            if t < b["t1"] or b is BEATS[-1]:
                u = seg(t, b["t0"], b["t0"] + 0.85); c = cam_lerp(prev, b["camo"], u)
                return c, lerp(prect[0], MAP_Y0, u), lerp(prect[1], MAP_Y1, u)
            prev = b["camo"]; prect = (MAP_Y0, MAP_Y1)
    if t < SIN_T:
        u = seg(t, REV_T + 0.25, S(10) + 0.35); c = cam_lerp(BEATS[-1]["camo"], ISR_CAM, u)
        return c, lerp(MAP_Y0, REV_MAP[0], seg(t, REV_T, REV_T + 0.6)), lerp(MAP_Y1, REV_MAP[1], seg(t, REV_T, REV_T + 0.6))
    if t < GAZ_T:
        u = seg(t, SIN_T, SIN_T + 1.0); c = cam_lerp(ISR_CAM, SIN_CAM, u); return c, lerp(REV_MAP[0], SIN_MAP[0], u), lerp(REV_MAP[1], SIN_MAP[1], u)
    if t < END_T:
        u = seg(t, GAZ_T, GAZ_T + 1.1); c = cam_lerp(SIN_CAM, GAZ_CAM, u); return c, lerp(SIN_MAP[0], GAZ_MAP[0], u), lerp(SIN_MAP[1], GAZ_MAP[1], u)
    u = seg(t, END_T, T_END - LOOP - 0.1); c = cam_lerp(GAZ_CAM, HOOK_CAM, u)
    return c, lerp(GAZ_MAP[0], HOOK_MAP[0], u), lerp(GAZ_MAP[1], HOOK_MAP[1], u)

def map_layers(t):
    lay = []
    # hook shimmer: every empire flashes once while the hook is read (motion by 1.5 s)
    if t < BEATS[0]["t0"] + 0.4:
        order = ["alex", "rome", "umayyad", "mongol", "napo", "us1867", "russia", "brit"]
        for i, k in enumerate(order):
            a0 = 0.25 + 0.2 * i; al = 0.5 * seg(t, a0, a0 + 0.25) * (1 - seg(t, a0 + 0.55, a0 + 0.95))
            lay.append((EMP[k], GOLD, al, None))
    for i, b in enumerate(BEATS):
        t_off = b["t1"] if b is not BEATS[-1] else REV_T
        fa = seg(t, b["t0"] + 0.35, b["t0"] + 0.95) * (1 - seg(t, t_off - 0.05, t_off + 0.35))
        if b is BEATS[-1]: fa = seg(t, b["t0"] + 0.35, b["t0"] + 0.95) * (1 - seg(t, REV_T + 0.1, REV_T + 1.0))
        if b["k"] == "us":
            f2 = seg(t, b["tn2"], b["tn2"] + 0.7)
            lay.append((EMP["us1867"], GOLD, 0.85 * fa * f2, "#F6E3B4")); lay.append((EMP["us1783"], GOLD, 0.85 * fa * (1 - f2), "#F6E3B4"))
        else:
            for k in b["emp"]: lay.append((EMP[k], GOLD, 0.85 * fa, "#F6E3B4"))
    sa = seg(t, S(11, WI(11, "Sinai")) - 0.1, S(11, WI(11, "Sinai")) + 0.5) * (1 - seg(t, GAZ_T, GAZ_T + 0.6))
    lay.append((SINAI, SKY, 0.75 * sa, "#9ED3F2"))
    lay.append((ISR, ISR_GOLD, seg(t, REV_T, REV_T + 0.5), None))
    ga = seg(t, GAZ_T + 0.3, GAZ_T + 0.9) * (1 - seg(t, END_T, END_T + 0.6)); pul = 0.15 * math.sin(max(0, t - GAZ_T) * 4.5) if ga > 0 else 0
    lay.append((GAZA, SKY, (0.82 + pul) * ga, "#BFE3F7"))
    return lay

def green_line(canvas, cam, y0, y1, alpha):
    """West Bank and Gaza outlines (Green Line) in green, dashed, over the gold land"""
    if alpha <= 0.01 or cam.k < 14: return
    hgt = int(y1 - y0); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, hgt); c = cairo.Context(surf); c.translate(0, -y0)
    path(c, cam, PSX); c.set_source_rgba(*GREEN, alpha); c.set_line_width(min(4.5, 1 + cam.k / 60)); c.set_dash([10, 6]); c.stroke(); surf.flush()
    a = np.ndarray((hgt, W, 4), np.uint8, surf.get_data()).copy()[:, :, [2, 1, 0, 3]]
    canvas.alpha_composite(Image.fromarray(a, "RGBA"), (0, int(y0)))

# ------------------------------------------------------------------ counters
def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def num_text(canvas, t, s, y, size, t0, t1, color=GOLD, ain=0.4):
    text(canvas, t, s, y, size, t0, t1, fk="db", color=color, tab=True, ain=ain)

# ------------------------------------------------------------------ flat layers: subtitles, sources
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)
# subtitles: (line, first word index, text). Lines 0, 9 and 13 show their own words as hero text; "Every soldier. Every settler." too
CH = [(1, 0, "Alexander the Great, 323 BC."), (1, WI(1, "Five"), "5.2 million square kilometers."),
      (2, 0, "Rome, 117 AD. 5 million."), (3, 0, "The Umayyad Caliphate, 720."), (3, WI(3, "Eleven"), "11 million."),
      (4, 0, "The Mongols, 1270."), (4, WI(4, "Twenty"), "24 million."), (5, 0, "Napoleon, 1813."), (5, WI(5, "Two"), "2.1 million."),
      (6, 0, "The United States."), (6, WI(6, "From"), "From 2.3 million,"), (6, WI(6, "to"), "to over 9 million by 1867."),
      (7, 0, "Russia, 1895."), (7, WI(7, "Twenty"), "22.8 million."), (8, 0, "And Britain, 1920."), (8, WI(8, "Thirty"), "35.5 million."),
      (8, WI(8, "The"), "The largest empire ever."), (10, 0, "22,000 square kilometers."), (10, WI(10, "Overseas"), "Overseas colonies? Zero."),
      (11, 0, "In 1982, it gave Sinai"), (11, WI(11, "back"), "back to Egypt, for peace."), (11, WI(11, "Almost"), "Almost three times its own size."),
      (12, 0, "In 2005, it left Gaza.")]
SUBS = []
for i, (li, wi, s) in enumerate(CH):
    a = S(li, wi) - 0.04; nxt = CH[i + 1] if i + 1 < len(CH) else None
    endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
    b = E(li, endw) + 0.4
    if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.06)
    SUBS.append((a, b, s)); assert len(s.split()) <= 7, s
def subtitles(canvas, t):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12); flat(canvas, wrap(s, SUBF, 900), SUBF, 1608, 68, "#FFFFFF", 0.94 * al)
SRC0 = ["Peak land areas: Taagepera, via Wikipedia,", "List of largest empires"]
SOURCES = [(0, SRC0)] + [(b["t0"], b["src"]) for b in BEATS] + [
    (REV_T, ["Israel 22,072 km², incl. Golan and E. Jerusalem:", "CBS. Map: Natural Earth, Green Line in green"]),
    (SIN_T, ["Sinai about 60,000 km², Wikipedia. Returned", "under the 1979 peace treaty, completed 1982"]),
    (GAZ_T, ["Gaza disengagement, completed 12 Sep 2005:", "21 settlements, about 8,500 settlers. Wikipedia"]),
    (END_T, SRC0)]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, 1772, 50, "#8E8E93", a)

# ------------------------------------------------------------------ frame
HOOK_A, HOOK_B = "The greatest", "empires in history."
HS = fit(HOOK_B, "db", 140); HCAP = capof("db", HS); HY1, HY2 = 400 - HS * 0.6, 400 + HS * 0.6
END_A, END_B = "So next time someone", "calls Israel an empire..."
ES = min(fit(END_A, "db", 120), fit(END_B, "db", 120))
def glow_at(t):
    g = 0.06 + 0.06 * seg(t, REV_T, REV_T + 1.2) * (1 - seg(t, END_T, END_T + 1.5)); return g
def frame_raw(t):
    im = stage(glow_at(t))
    cam, y0, y1 = camera(t)
    ma = 0.75 + 0.25 * seg(t, BEATS[0]["t0"], BEATS[0]["t0"] + 0.6) * (1 - seg(t, END_T, END_T + 1.5))
    draw_map(im, cam, y0, y1, ma, map_layers(t))
    green_line(im, cam, y0, y1, seg(t, REV_T + 0.8, S(10)) * ma)
    b0t = BEATS[0]["t0"]
    # hook (frame 0, fully on screen) and the lead-in at the same place and size
    text(im, t, HOOK_A, HY1, HS, 0, b0t, inst=True, zoom=1 + 0.03 * seg(t, 0, b0t))
    text(im, t, HOOK_B, HY2, HS, 0, b0t, inst=True, zoom=1 + 0.03 * seg(t, 0, b0t))
    text(im, t, END_A, HY1, ES, END_T, T_END, ain=0.55); text(im, t, END_B, HY2, ES, END_T + 0.12, T_END, ain=0.55)
    # empires
    for i, b in enumerate(BEATS):
        t0, t1 = b["t0"], b["t1"]; last = b is BEATS[-1]
        photo(im, t, b["k"], t0, t1 if not last else REV_T, PH_BOX, ain=0.45 if i == 0 else 0.3, aout=0.3)
        credit(im, t, b["k"], t0, t1 if not last else REV_T, CRED_Y)
        ns = fit(b["name"], "db", 92); text(im, t, b["name"], NAME_Y, ns, t0 + 0.05, t1 - 0.1)
        text(im, t, b["year"], YEAR_Y, fit(b["year"], "dm", 56), t0 + 0.15, t1 - 0.1, fk="dm", color=GREY)
    # one counter across the empire beats: rolls from the last value to the new one on the spoken number
    if b0t <= t < REV_T + 0.5:
        cur = None
        for i, b in enumerate(BEATS):
            if t >= b["t0"] - 0.01: cur = (i, b)
        i, b = cur; prev = BEATS[i - 1]["v"] if i else 0.0
        if b["k"] == "us":
            v = roll(t, b["tn"], 0.5, prev, b["v0"]); v = roll(t, b["tn2"], 0.8, v, b["v"]) if t >= b["tn2"] else v
        else: v = roll(t, b["tn"], 0.7, prev, b["v"], log=prev > 0)
        dec = b["dec"] if t >= b["tn"] + 0.7 or b["k"] == "us" else 1
        s = f"{v:.{dec}f}"
        a_out = REV_T
        dim = 1.0 if i == 0 else 0.3 + 0.7 * seg(t, b["tn"] - 0.15, b["tn"] + 0.15) if t >= b["t0"] + 0.25 else 1.0 - 0.7 * seg(t, b["t0"], b["t0"] + 0.25)
        if i and t >= b["t0"] + 0.25: dim = 0.3 + 0.7 * seg(t, b["tn"] - 0.15, b["tn"] + 0.15)
        text(im, t, s, NUM_Y, 150, BEATS[0]["tn"] - 0.1, a_out, fk="db", color=GOLD, tab=True, alpha=dim)
        text(im, t, "million km²", UNIT_Y, 56, BEATS[0]["tn"], a_out, fk="dm", color=WHITE)
    # reveal
    rv = S(10)
    text(im, t, "And Israel?", 400, fit("And Israel?", "db", 150), REV_T, S(10, WI(10, "Overseas")) - 0.15, ain=0.7)
    pulse_t = REV_T + 0.4
    if pulse_t < t < rv + 0.3:   # a white ring closing onto Israel while the camera dives
        px, py = ll2xy(cam, 35.1, 31.4); u = (t - pulse_t) / (rv + 0.3 - pulse_t); rr = 160 * (1 - ease(u)) + 18
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(ov).ellipse((px - rr, py - rr, px + rr, py + rr), outline=(255, 255, 255, int(200 * (1 - u))), width=5)
        im.alpha_composite(ov)
    if rv - 0.2 <= t < GAZ_T + 0.4:
        sq = S(11, WI(11, "Almost")) - 0.05
        v = roll(t, rv - 0.1, 1.1, 35_500_000, 22_072, log=True)
        if t >= sq: v = roll(t, sq, 0.9, 22_072, 60_000)
        s = f"{int(round(v)):,}"
        text(im, t, s, NUM_Y, fit("35,500,000", "db", 150), rv - 0.2, GAZ_T, fk="db", color=GOLD, tab=True, ain=0.3)
        text(im, t, "km², Israel", UNIT_Y + 14, 56, rv - 0.1, sq - 0.1, fk="dm")
        text(im, t, "km² of Sinai: almost 3 times Israel", UNIT_Y + 14, fit("km² of Sinai: almost 3 times Israel", "dm", 56), sq + 0.05, GAZ_T, fk="dm")
    to = S(10, WI(10, "Overseas")) - 0.05
    text(im, t, "Overseas colonies", 330, 92, to, SIN_T, fk="dsb")
    text(im, t, "0", 520, 190, S(10, WI(10, "Zero")) - 0.05, SIN_T, fk="db", color=GOLD, tab=True, ain=0.35)
    # Sinai: photo, then the line
    photo(im, t, "sinai", SIN_T, GAZ_T, (60, 250, 1020, 600), aout=0.3); credit(im, t, "sinai", SIN_T, GAZ_T, 628)
    text(im, t, "1982: Sinai back to Egypt", 690, fit("1982: Sinai back to Egypt", "db", 80), SIN_T + 0.15, GAZ_T - 0.05)
    if SIN_T + 0.8 < t < GAZ_T + 0.3:   # map labels
        a = seg(t, SIN_T + 0.8, SIN_T + 1.3) * (1 - seg(t, GAZ_T - 0.1, GAZ_T + 0.3)); c2, _, _ = camera(t)
        x, y = ll2xy(c2, 33.85, 29.35); put(im, raster("Sinai", "dsb", 64), x, y + 22, 1, hx(WHITE), a, 0)
    # Gaza
    if GAZ_T + 0.9 < t < END_T + 0.3:
        a = seg(t, GAZ_T + 0.9, GAZ_T + 1.4) * (1 - seg(t, END_T - 0.1, END_T + 0.3)); c2, _, _ = camera(t)
        x, y = ll2xy(c2, 33.95, 31.42); put(im, raster("Gaza", "dsb", 60), x, y + 22, 1, hx(WHITE), a, 0)
    text(im, t, "2005", 330, 190, GAZ_T + 0.05, END_T, fk="db", color=GOLD, tab=True)
    text(im, t, "Israel left Gaza", 510, 84, GAZ_T + 0.2, END_T, fk="dsb")
    text(im, t, "Every soldier.", 1410, 84, S(12, WI(12, "Every")) - 0.05, END_T, fk="dsb")
    text(im, t, "Every settler.", 1515, 84, S(12, len(LW[12]) - 2) - 0.05, END_T, fk="dsb", color=GOLD)
    sources(im, t); subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + [b["name"] for b in BEATS] + [b["year"] for b in BEATS] + \
       [v[3] for v in PH.values()] + [HOOK_A, HOOK_B, END_A, END_B] + L
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
for v in PH.values(): assert font("r", 36).getlength(v[3]) <= 980, v[3]

N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
