"""geo_prep.py: one small geo/geo.json for the engine.
world: Natural Earth 1:50m country polygons (public domain), simplified 0.08 deg (world views) and a 0.006 deg set for the
Levant zoom. empires: historical-basemaps (A. Ourednik, GPL-3.0) polygons where they hold up, modern borders where they
do not (see empires_raw.json). Israel: ISR + PSX (West Bank, Gaza) + Golan as one gold land, PSX rings for the Green Line.
Sinai: Egypt east of the Suez Canal and Gulf of Suez."""
import json, numpy as np
from shapely.geometry import shape, mapping, Polygon, box
from shapely.ops import unary_union, transform
def area(g): return transform(lambda x, y, z=None: (x * 111.32 * np.cos(np.radians(y)), y * 110.57), g).area
NE = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
ne = {f["properties"]["ADM0_A3"]: shape(f["geometry"]).buffer(0) for f in NE["features"]}
DIS = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_breakaway_disputed_areas.geojson"))
golan = [shape(f["geometry"]).buffer(0) for f in DIS["features"] if "Golan" in json.dumps(f["properties"])]
print("golan pieces", len(golan), [round(area(g)) for g in golan])
isr = unary_union([ne["ISR"], ne["PSX"]] + golan)
print("ISR", round(area(ne["ISR"])), "PSX", round(area(ne["PSX"])), "whole land", round(area(isr)))
cut = Polygon([(32.30, 31.8), (32.33, 30.10), (32.58, 29.93), (33.05, 29.0), (33.75, 27.85), (34.25, 27.60), (35.5, 27.5), (35.5, 31.8)])
sinai = ne["EGY"].intersection(cut)
print("Sinai", round(area(sinai)), "ratio", round(area(sinai) / 22072, 2))
def ser(g, tol): 
    g = g.simplify(tol, preserve_topology=True); return mapping(g)
lev = box(24, 22, 46, 40)
world = {}
for k, g in ne.items():
    if k in ("ATA",): continue
    world[k] = ser(g, 0.08)
local = {k: ser(g.intersection(lev), 0.004) for k, g in ne.items() if g.intersects(lev) and k not in ("ISR", "PSX")}
E = json.load(open("geo/empires_raw.json"))
out = dict(world=world, local=local, empires=E, israel=ser(isr, 0.003), psx=ser(ne["PSX"], 0.003), sinai=ser(sinai, 0.004),
           gaza=ser([p for p in ne["PSX"].geoms if p.centroid.x < 34.6][0] if ne["PSX"].geom_type == "MultiPolygon" else ne["PSX"], 0.002))
json.dump(out, open("geo/geo.json", "w"))
import os; print("geo.json", os.path.getsize("geo/geo.json") // 1024, "KB")
