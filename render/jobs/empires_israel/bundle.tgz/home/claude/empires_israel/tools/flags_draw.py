"""flags_draw.py: the simple geometric flags drawn from their public-domain specifications (same designs as the
Wikimedia Commons PD SVGs: Flag of France, Flag of Russia (1858 to 1896, black-yellow-white), Flag of the United Kingdom
(3:5), Flag of Israel, Flag of the United States (1896 to 1908, 45 stars), plus a plain white Umayyad banner) ->
flags/*.png at 1800 px wide. Commons downloads for these small files would only bloat the tool results."""
import math
from PIL import Image, ImageDraw
D = "/home/claude/empires_israel/flags"
def star(d, cx, cy, r, fill, pts=5, inner=0.382, rot=-90):
    p = []
    for i in range(pts * 2):
        a = math.radians(rot + i * 180 / pts); rr = r if i % 2 == 0 else r * inner; p.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    d.polygon(p, fill=fill)
W = 1800
# France 2:3
im = Image.new("RGB", (W, 1200), "white"); d = ImageDraw.Draw(im); d.rectangle((0, 0, 600, 1200), fill="#002395"); d.rectangle((1200, 0, 1800, 1200), fill="#ED2939"); im.save(f"{D}/fr.png")
# Russian Empire black-yellow-white 2:3
im = Image.new("RGB", (W, 1200), "white"); d = ImageDraw.Draw(im); d.rectangle((0, 0, W, 400), fill="#000000"); d.rectangle((0, 400, W, 800), fill="#FFD200"); im.save(f"{D}/ru.png")
# Umayyad: plain white banner with a faint weave so it reads as cloth
im = Image.new("RGB", (W, 1200), "#F4F1E8"); d = ImageDraw.Draw(im)
for y in range(0, 1200, 6): d.line((0, y, W, y), fill="#E9E4D6", width=1)
im.save(f"{D}/umayyad.png")
# Israel 8:11
H = int(W * 8 / 11); im = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(im); u = H / 160; blue = "#0038B8"
d.rectangle((0, 15 * u, W, 40 * u), fill=blue); d.rectangle((0, 120 * u, W, 145 * u), fill=blue)
cx, cy = W / 2, H / 2; R = 27.5 * u; t = 5.5 * u
for rot in (-90, 90):
    outer = [(cx + R * math.cos(math.radians(rot + k * 120)), cy + R * math.sin(math.radians(rot + k * 120))) for k in range(3)]
    inner = [(cx + (R - t * 2) * math.cos(math.radians(rot + k * 120)), cy + (R - t * 2) * math.sin(math.radians(rot + k * 120))) for k in range(3)]
    d.polygon(outer, fill=blue)
for rot in (-90, 90):
    inner = [(cx + (R - t * 2) * math.cos(math.radians(rot + k * 120)), cy + (R - t * 2) * math.sin(math.radians(rot + k * 120))) for k in range(3)]
    d.polygon(inner, fill="white")
im.save(f"{D}/il.png")
# United Kingdom 3:5
H = int(W * 3 / 5); im = Image.new("RGB", (W, H), "#012169"); d = ImageDraw.Draw(im); s = H / 30
for (a, b) in (((0, 0), (W, H)), ((0, H), (W, 0))): d.line((a, b), fill="white", width=int(6 * s))
for sgn in (1, -1):   # counterchanged red saltire, offset
    off = s * 1.0
    d.line(((0, 0 + sgn * off * 0), (W / 2, H / 2)), fill="#C8102E", width=int(2 * s))
d.line((0, 0, W, H), fill="#C8102E", width=int(2 * s)); d.line((0, H, W, 0), fill="#C8102E", width=int(2 * s))
d.rectangle((W / 2 - 5 * s, 0, W / 2 + 5 * s, H), fill="white"); d.rectangle((0, H / 2 - 5 * s, W, H / 2 + 5 * s), fill="white")
d.rectangle((W / 2 - 3 * s, 0, W / 2 + 3 * s, H), fill="#C8102E"); d.rectangle((0, H / 2 - 3 * s, W, H / 2 + 3 * s), fill="#C8102E")
im.save(f"{D}/uk.png")
# United States 1896 to 1908, 45 stars (rows 8,7,8,7,8,7), 10:19 (the source's US peak year is 1900)
H = int(W * 10 / 19); im = Image.new("RGB", (W, H), "white"); d = ImageDraw.Draw(im); sh = H / 13
for i in range(0, 13, 2): d.rectangle((0, i * sh, W, (i + 1) * sh), fill="#B22234")
cw, ch = W * 0.4, sh * 7; d.rectangle((0, 0, cw, ch), fill="#3C3B6E")
rows = [8, 7, 8, 7, 8, 7]
for r, n in enumerate(rows):
    y = ch * (r + 0.5) / 6
    for k in range(n): star(d, cw * (k + 0.5) / n, y, sh * 0.33, "white")
im.save(f"{D}/us.png")
print("ok")
