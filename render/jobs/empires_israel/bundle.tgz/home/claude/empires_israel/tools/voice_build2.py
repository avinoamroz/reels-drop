"""voice_build2.py: v2 narration (countdown format) -> work/vo.wav (48 kHz, house chain) + work/words.json + work/grid.json.
Lines come from Cartesia SSE clips: q0/q1/q2 are new (1 Nov, countdown lines), p0/p4/p5/p6 are reused from v1 (hook, "And
Israel?", Sinai, Gaza, lead-in). Lines 0 to 8 start on bar lines of the music (hook bar 0, #8..#2 one bar each, #1 two bars),
line 9 ("And Israel?") starts bar 10, lines 10 to 13 flow with short gaps, and the bar length is solved so the whole reel is a
whole number of bars (so the beat loops). Internal pauses over 0.28 s are squeezed. House chain from reelkit/voice.py."""
import json, re, sys, wave
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
D = "/home/claude/empires_israel"; SR0 = 44100; TEMPO = 1.08; LEAD = 0.10; V.TEMPO = TEMPO; V.LEAD = LEAD
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
OLD = [l.strip() for l in open(f"{D}/work/tts_v1.txt") if l.strip()]
CLIPS = {"q0": L[1:5], "q1": L[5:9], "q2": ["Zero point zero one six percent of the world. Colonies? Zero."], "p0": OLD[0:2], "p4": OLD[8:10], "p5": OLD[10:12], "p6": OLD[12:14]}
SRC = {0: ("p0", 0), 1: ("q0", 0), 2: ("q0", 1), 3: ("q0", 2), 4: ("q0", 3), 5: ("q1", 0), 6: ("q1", 1), 7: ("q1", 2), 8: ("q1", 3),
       9: ("p4", 1), 10: ("q2", 0, None, [0, 1, 2, 3, 4, 5, 9, 10]), 11: ("p5", 1, 12), 12: ("p6", 0), 13: ("p6", 1)}
BAR_OF = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 10}
POST_GAP = {9: 0.85, 10: 0.42, 11: 0.42, 12: 0.5}     # reel-time gap after the line (9: room for the dive)
MAXG = 0.28
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
def map_words(script_words, W):
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sn = [norm(x) for x in script_words]; stot = sum(max(1, len(x)) for x in sn); pos = 0; out = []
    for x, n_ in zip(script_words, sn):
        Ln = max(1, len(n_)); f0, f1 = pos / stot, (pos + Ln) / stot; pos += Ln; out.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
    return out
CW = {}
for c, lines in CLIPS.items():
    a = load(f"{D}/clips/{c}.wav"); W = json.load(open(f"{D}/clips/{c}_words.json"))
    sw, own = [], []
    for i, l in enumerate(lines):
        for x in l.split(): sw.append(x); own.append(i)
    mw = map_words(sw, W); CW[c] = (a, [[m for m, o in zip(mw, own) if o == i] for i in range(len(lines))])
PIECES = {}
for li in range(len(L)):
    s = SRC[li]; a, per = CW[s[0]]; ws = per[s[1]]
    if len(s) > 2 and s[2]: ws = ws[:s[2]]
    sel = list(s[3]) if len(s) > 3 else list(range(len(ws)))
    if len(s) > 3: ws = [ws[i] for i in s[3]]
    assert [norm(w[0]) for w in ws] == [norm(x) for x in L[li].split()], (li, [w[0] for w in ws])
    s0 = max(0, ws[0][1] - 0.05); e0 = min(len(a) / SR0, ws[-1][2] + (0.30 if li == len(L) - 1 else 0.09))
    keep = []; cur = s0
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][2], ws[i + 1][1]
        if sel[i + 1] - sel[i] > 1:      # words removed between them: cut their audio out completely, leave a short pause
            keep.append((cur, g0 + 0.06)); cur = g1 - 0.04; continue
        if g1 - g0 > MAXG: ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
    keep.append((cur, e0))
    segs = []; wt = []; acc = 0.0
    def mp(x):
        q = 0.0
        for k0, k1 in keep:
            if x <= k1: return q + max(0, x - k0)
            q += k1 - k0
        return q
    for k0, k1 in keep:
        sg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(sg) // 2, int(0.008 * SR0))
        if f: sg[:f] *= np.linspace(0, 1, f); sg[-f:] *= np.linspace(1, 0, f)
        segs.append(sg)
    y = np.concatenate(segs); PIECES[li] = (y, [(w, mp(b0), mp(max(b1, b0 + 0.04))) for w, b0, b1 in ws])
dur = {li: len(p[0]) / SR0 / TEMPO for li, p in PIECES.items()}          # reel-time length of each line
post = sum(dur[li] + POST_GAP.get(li, 0) for li in range(9, len(L))) + 0.45
N = 16; bar = post / (N - 10)
assert 2.6 <= bar <= 3.3, bar
for li in range(1, 8): assert dur[li] < bar - 0.25, (li, dur[li], bar)
assert dur[8] < 2 * bar - 0.3 and dur[0] < bar - 0.3
starts = {}
for li in range(10): starts[li] = BAR_OF[li] * bar + (0.12 if li == 0 else 0.10)
t = starts[9]
for li in range(9, len(L)): starts[li] = t; t += dur[li] + POST_GAP.get(li, 0)
T_END = round(N * bar, 3)
raw = np.zeros(int((T_END - LEAD) * TEMPO * SR0) + SR0, np.float32); words = []
for li, (y, ws) in PIECES.items():
    i0 = int(max(0, starts[li] - LEAD) * TEMPO * SR0); raw[i0:i0 + len(y)] += y
    for w, a_, b_ in ws: words.append(dict(li=li, w=w, t0=round(starts[li] + a_ / TEMPO, 3), t1=round(starts[li] + b_ / TEMPO, 3)))
sf.write(f"{D}/work/raw.wav", raw, SR0)
dry = V.chain_dry(f"{D}/work/raw.wav"); cl = V.clean_vo(dry, V.SR); y, _ = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y)[:int(T_END * V.SR)]; vo = np.pad(vo, (0, max(0, int(T_END * V.SR) - len(vo)))); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{D}/work/vo.wav", vo.astype(np.float32), V.SR)
import os; os.remove(f"{D}/work/raw.wav")
json.dump(dict(words=words, dur=T_END), open(f"{D}/work/words.json", "w"), indent=0)
json.dump(dict(bar=bar, bars=N, T_END=T_END, bpm=240 / bar, starts=starts), open(f"{D}/work/grid.json", "w"), indent=1)
print("bar", round(bar, 3), "bpm", round(240 / bar, 2), "bars", N, "T_END", T_END, "reveal", round(starts[9], 2), f"{starts[9] / T_END:.0%}")
for li in range(len(L)): print(li, round(starts[li], 2), round(dur[li], 2), L[li])
