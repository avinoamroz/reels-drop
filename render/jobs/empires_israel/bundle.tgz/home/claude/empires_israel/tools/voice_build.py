"""voice_build.py: Cartesia SSE parts (clips/p*.wav + _words.json) -> work/vo.wav (48 kHz, house chain) + work/words.json
Each script word gets reel-time t0/t1 and its line index li. Lines are cut out of the parts by word times, internal pauses
over 0.30 s are squeezed to 0.30 s, then lines are joined with the GAP table. House chain from reelkit/voice.py
(rubberband pitch 0.9715 formant preserved, bass, clean_vo, soft-ending restore), atempo TEMPO, LEAD s lead."""
import json, re, sys, wave, subprocess
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
D = "/home/claude/empires_israel"; SR0 = 44100; TEMPO = 1.08; V.TEMPO = TEMPO; LEAD = 0.12; V.LEAD = LEAD
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
parts = json.load(open(f"{D}/work/tts_parts.json"))
over = json.load(open(f"{D}/work/retakes.json")) if len(sys.argv) > 1 else {}
GAP = {0: 0.42, 1: 0.36, 2: 0.36, 3: 0.36, 4: 0.36, 5: 0.36, 6: 0.36, 7: 0.40, 8: 0.75, 9: 0.85, 10: 0.40, 11: 0.45, 12: 0.55}
MAXG = 0.30
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768; return a
def map_words(script_words, W):
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sn = [norm(x) for x in script_words]; stot = sum(max(1, len(x)) for x in sn); pos = 0; out = []
    for x, n_ in zip(script_words, sn):
        Ln = max(1, len(n_)); f0, f1 = pos / stot, (pos + Ln) / stot; pos += Ln
        out.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
    return out
# per line: (audio, [(word, t0, t1)] relative to the line audio)
LINES = {}
for k, P in enumerate(parts):
    a = load(f"{D}/clips/p{k}.wav"); W = json.load(open(f"{D}/clips/p{k}_words.json"))
    sw = []; owner = []
    for li in P["lines"]:
        for x in L[li].split(): sw.append(x); owner.append(li)
    mw = map_words(sw, W)
    for li in P["lines"]:
        ws = [m for m, o in zip(mw, owner) if o == li]
        LINES[li] = (a, ws)
for li, src in over.items():   # retakes: {line: "clips/r?.wav"}
    a = load(f"{D}/{src}"); W = json.load(open(f"{D}/{src[:-4]}_words.json")); LINES[int(li)] = (a, map_words(L[int(li)].split(), W))
chunks = []; words = []; t = 0.0
for li in range(len(L)):
    a, ws = LINES[li]
    s0 = max(0, ws[0][1] - 0.06); e0 = min(len(a) / SR0, ws[-1][2] + (0.35 if li == len(L) - 1 else 0.10))
    keep = []; cur = s0
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][2], ws[i + 1][1]
        if g1 - g0 > MAXG: ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
    keep.append((cur, e0))
    def mp(x):
        acc = 0.0
        for k0, k1 in keep:
            if x <= k1: return t + acc + max(0, x - k0)
            acc += k1 - k0
        return t + acc
    for w_, a_, b_ in ws: words.append(dict(li=li, w=w_, p0=mp(a_), p1=mp(max(b_, a_ + 0.04))))
    for k0, k1 in keep:
        seg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(seg) // 2, int(0.008 * SR0))
        if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        chunks.append(seg); t += len(seg) / SR0
    if li in GAP: chunks.append(np.zeros(int(GAP[li] * SR0), np.float32)); t += GAP[li]
raw = np.concatenate(chunks); sf.write(f"{D}/work/raw.wav", raw, SR0)
dry = V.chain_dry(f"{D}/work/raw.wav"); cl = V.clean_vo(dry, V.SR); y, sp = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{D}/work/vo.wav", vo.astype(np.float32), V.SR)
for w in words: w["t0"] = round(LEAD + w.pop("p0") / TEMPO, 3); w["t1"] = round(LEAD + w.pop("p1") / TEMPO, 3)
json.dump(dict(words=words, dur=round(len(vo) / V.SR, 3)), open(f"{D}/work/words.json", "w"), indent=0)
import os; os.remove(f"{D}/work/raw.wav")
print("vo", round(len(vo) / V.SR, 2), "s"); 
for li in range(len(L)):
    ws = [w for w in words if w["li"] == li]; print(li, ws[0]["t0"], ws[-1]["t1"], L[li])
