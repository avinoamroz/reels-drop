"""empires_israel v2: countdown format after the reference Short "Largest Empires of All Time" (@histographyYT), per the
coordinator's 1 Nov notes. Full-frame dark satellite world (NASA Blue Marble, public domain, darkened), each empire's peak
extent FILLED WITH ITS FLAG, "#8 ... #1" titles in big white caps with "x% of the World" under them, quick bar-locked beats
(one bar of the beat each, #1 two bars), bold caps subtitles with one key word in red. Then the twist: the camera dives to
Israel (flag fill, 0.016% of the world, colonies 0), Sinai filled and handed back, Gaza filled and left in 2005.
Circular: hook said once at frame 0; the lead-in sits where the hook sits; the last 0.45 s cross-fade into frame 0.
usage: python3 reel2.py [--snaps 0,3.2,...|last] | python3 reel2.py --out work/silent.mp4"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
D = "/home/claude/empires_israel"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]; GR = json.load(open(f"{D}/work/grid.json"))
BAR = GR["bar"]; T_END = GR["T_END"]; LOOP = 0.45
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(word.lower()): return i
    raise KeyError((li, word))
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
WHITE, GREY, GOLD, RED = "#FFFFFF", "#B9B9BE", "#F2C94C", "#FF3B30"
ISR_SHADE = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)

# ------------------------------------------------------------------ text (2x masks, sub-pixel, scale + blur-in), from engine_v3
FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium", r="Inter-Regular").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=1000):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size
_rc = {}
def raster(s, fk, size):
    key = (s, fk, size)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
    ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 600: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur, shadow=True):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 14; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = np.asarray(m, np.float32)
    lays = []
    if shadow:   # soft dark halo so white type reads over the map
        sh = np.asarray(m.filter(ImageFilter.GaussianBlur(7)), np.float32) * 0.85 * alpha
        l0 = Image.new("RGBA", (cw, ch), (0, 0, 0, 0)); l0.putalpha(Image.fromarray(sh.clip(0, 255).astype(np.uint8), "L")); lays.append(l0)
    l1 = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); l1.putalpha(Image.fromarray((a * alpha).clip(0, 255).astype(np.uint8), "L")); lays.append(l1)
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0:
        for lay in lays: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
T_IN, T_OUT = 0.32, 0.22
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.9 + 0.1 * u) * (1 + 0.03 * v), 8 * (1 - u) + 6 * v, 0
def text(canvas, t, s, y, size, t0, t1, fk="db", color=WHITE, inst=False, zoom=1.0, ain=T_IN, aout=T_OUT, cx=540, alpha=1.0):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size); put(canvas, info, cx, y + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)
def rich(canvas, t, parts, y, size, t0, t1, fk="dsb", ain=T_IN, aout=T_OUT):
    """one centred line of differently coloured pieces: parts = [(text, colour), ...]"""
    f = font(fk, size); ws = [f.getlength(p) for p, _ in parts]; x = 540 - sum(ws) / 2
    for (p, c), w_ in zip(parts, ws):
        text(canvas, t, p, y, size, t0, t1, fk=fk, color=c, ain=ain, aout=aout, cx=x + w_ / 2); x += w_

# ------------------------------------------------------------------ background: NASA Blue Marble, darkened
_bm = Image.open(f"{D}/photos/world.jpg").convert("RGB")
_bm = ImageEnhance.Color(_bm).enhance(0.62); _bm = ImageEnhance.Brightness(_bm).enhance(0.46); _bm = ImageEnhance.Contrast(_bm).enhance(1.12)
BM = _bm; IW, IH = BM.size
class Cam:
    def __init__(s, lon, lat, k, cy=1000): s.lon, s.lat, s.k, s.cy = lon, lat, k, cy
    @property
    def cosf(s): return max(0.6, math.cos(math.radians(min(62, abs(s.lat)))))
def cam_lerp(a, b, u):
    return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.k), math.log(b.k), u)), lerp(a.cy, b.cy, u))
def camw(lon, lat, width_deg, cy=1000):
    c = Cam(lon, lat, 1, cy); return Cam(lon, lat, W / (width_deg * c.cosf), cy)
def background(cam):
    kx = cam.k * cam.cosf; a = IW / 360 / kx; c = (cam.lon + 180) * IW / 360 - 540 * a
    e = IH / 180 / cam.k; f = (90 - cam.lat) * IH / 180 - cam.cy * e
    return BM.transform((W, H), Image.AFFINE, (a, 0, c, 0, e, f), Image.BILINEAR).convert("RGBA")
def ll2xy(cam, lon, lat): return 540 + (lon - cam.lon) * cam.k * cam.cosf, cam.cy - (lat - cam.lat) * cam.k

# ------------------------------------------------------------------ geography (geo/geo.json from tools/geo_prep.py)
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    return [np.array(r, float) for p in polys for r in p]
def bounds(rs): a = np.concatenate(rs); return a[:, 0].min(), a[:, 1].min(), a[:, 0].max(), a[:, 1].max()
def polys_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    out = []
    for p in polys:
        rs = [np.array(r, float) for r in p]; o = rs[0]; out.append((rs, (o[:, 0].min(), o[:, 1].min(), o[:, 0].max(), o[:, 1].max())))
    return out
LOCAL = {k: rings_of(v) for k, v in G["local"].items()}; LB = {k: bounds(v) for k, v in LOCAL.items() if v}
EMP = {k: rings_of(v) for k, v in G["empires"].items()}
EMP["umayyad"] = [r for r in EMP["umayyad"] if r[:, 0].mean() > -11]
EP = {k: polys_of(v) for k, v in G["empires"].items()}
EP["umayyad"] = [p for p in EP["umayyad"] if p[1][2] > -11]
ISR = rings_of(G["israel"]); PSX = rings_of(G["psx"]); SINAI = rings_of(G["sinai"]); GAZA = rings_of(G["gaza"])
from shapely.geometry import shape
_isr_only = shape(G["israel"]).difference(shape(G["psx"]).buffer(0.002))
_isr_gj = json.loads(json.dumps(__import__("shapely.geometry", fromlist=["mapping"]).mapping(_isr_only)))
ISR_ONLY = rings_of(_isr_gj)
for k, gj in (("sinai", G["sinai"]), ("gaza", G["gaza"]), ("isr", _isr_gj)): EP[k] = polys_of(gj)
EP["isr"] = [max(EP["isr"], key=lambda p: (p[1][2] - p[1][0]) * (p[1][3] - p[1][1]))]   # one flag over the whole land
EB = {k: bounds(v) for k, v in EMP.items()}
for k, b in (("sinai", SINAI), ("gaza", GAZA), ("isr", ISR_ONLY)): EB[k] = bounds(b)

def path(c, cam, rings):
    kx = cam.k * cam.cosf; ky = cam.k
    for r in rings:
        xs = 540 + (r[:, 0] - cam.lon) * kx; ys = cam.cy - (r[:, 1] - cam.lat) * ky
        c.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): c.line_to(x, y)
        c.close_path()
# flags as cairo surfaces
def surf_of(path_png):
    im = Image.open(path_png).convert("RGBA"); a = np.asarray(im).copy(); bgra = a[:, :, [2, 1, 0, 3]].copy()
    s = cairo.ImageSurface.create_for_data(memoryview(bgra), cairo.FORMAT_ARGB32, im.width, im.height); return s, bgra
FLAGS = {}
for k, f in dict(fr="fr.png", rome="rome_tex.png", mk="mk_tex.png", us="us.png", umayyad="umayyad.png", ru="ru.png", mongol="mongol_tex.png",
                 uk="uk.png", il="il.png").items():
    FLAGS[k] = surf_of(f"{D}/flags/{f}")
def flag_fill(c, cam, rings, flag, bb, alpha, stroke=True, scale=1.0, polys=None):
    """each polygon gets the flag stretched over its own outer box (like the reference), clipped even-odd; white outline + glow"""
    if alpha <= 0.004 or not rings: return
    s, _ = FLAGS[flag]; fw, fh = s.get_width(), s.get_height()
    for rs, pb in (polys or [(rings, bb)]):
        x0, y0 = ll2xy(cam, pb[0], pb[3]); x1, y1 = ll2xy(cam, pb[2], pb[1])
        if x1 < -50 or x0 > W + 50 or y1 < -50 or y0 > H + 50 or (x1 - x0) * (y1 - y0) < 4: continue
        bw, bh = max(2, x1 - x0), max(2, y1 - y0)
        c.save(); c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD); path(c, cam, rs); c.clip()
        c.translate(x0, y0); c.scale(bw / fw, bh / fh); c.set_source_surface(s, 0, 0)
        c.get_source().set_filter(cairo.FILTER_GOOD); c.paint_with_alpha(alpha); c.restore()
    if stroke:
        path(c, cam, rings)
        for wdt, al in ((9, 0.10), (5, 0.18), (2.2, 0.95)):
            c.set_source_rgba(1, 1, 1, al * alpha); c.set_line_width(wdt); c.stroke_preserve()
        c.new_path()
def solid(c, cam, rings, col, alpha, lw=0.0, scol=None):
    if alpha <= 0.004 or not rings: return
    v = hx(col) / 255; path(c, cam, rings); c.set_source_rgba(v[0], v[1], v[2], alpha); c.fill_preserve()
    if lw: s_ = hx(scol) / 255; c.set_source_rgba(s_[0], s_[1], s_[2], alpha); c.set_line_width(lw); c.stroke()
    else: c.new_path()

# ------------------------------------------------------------------ the countdown
BEATS = [  # rank, key, title, share of world land (Taagepera via Wikipedia), peak year, flag, camera (lon, lat, width deg), border note
 (8, "napo", "NAPOLEON'S FRANCE", "1.56", "1813, with client states", "fr", (9, 46, 38), "modern borders"),
 (7, "rome", "ROMAN EMPIRE", "3.71", "117 CE", "rome", (16, 38, 54), "historical-basemaps"),
 (6, "alex", "ALEXANDER'S EMPIRE", "3.86", "Macedonia, 323 BCE", "mk", (48, 33, 60), "historical-basemaps"),
 (5, "us1867", "UNITED STATES", "7.05", "1900", "us", (-118, 48, 118), "historical-basemaps"),
 (4, "umayyad", "UMAYYAD CALIPHATE", "8.24", "720 CE", "umayyad", (24, 30, 110), "historical-basemaps, Iberia added"),
 (3, "russia", "RUSSIAN EMPIRE", "16.92", "1895", "ru", (95, 57, 185), "historical-basemaps"),
 (2, "mongol", "MONGOL EMPIRE", "17.81", "1270", "mongol", (82, 42, 128), "historical-basemaps"),
 (1, "brit", "BRITISH EMPIRE", "26.35", "1920", "uk", (5, 14, 352), "modern borders"),
]
B = []
for i, (rank, key, title, pct, year, flag, cam, note) in enumerate(BEATS):
    li = i + 1; t0 = (li) * BAR; t1 = (li + 1) * BAR if rank != 1 else 10 * BAR
    B.append(dict(rank=rank, key=key, title=f"#{rank} {title}", pct=pct, year=year, flag=flag, cam=camw(*cam), t0=t0, t1=t1, note=note, li=li))
HOOK_CAM = camw(32, 30, 215, 1030)
REV_T = 10 * BAR; ISR_CAM = camw(35.0, 31.55, 5.0, 1010)
SIN_T = S(11) - 0.15; SIN_CAM = camw(33.9, 30.35, 9.2, 1020)
GAZ_T = S(12) - 0.15; GAZ_CAM = camw(34.62, 31.45, 2.4, 1000)
END_T = S(13) - 0.15
def camera(t):
    if t < B[0]["t0"]:
        z = 1 + 0.04 * seg(t, 0, B[0]["t0"]); return Cam(HOOK_CAM.lon + 4 * seg(t, 0, B[0]["t0"]), HOOK_CAM.lat, HOOK_CAM.k * z, HOOK_CAM.cy)
    if t < REV_T:
        prev = HOOK_CAM
        for b in B:
            if t < b["t1"]:
                u = seg(t, b["t0"] - 0.05, b["t0"] + 0.55); c = cam_lerp(prev, b["cam"], u)
                d = (t - b["t0"]) / (b["t1"] - b["t0"]); c.k *= 1 + 0.035 * d; return c   # slow push-in while the beat holds
            prev = b["cam"]
    last = B[-1]["cam"]; last = Cam(last.lon, last.lat, last.k * 1.035, last.cy)
    if t < SIN_T: return cam_lerp(last, ISR_CAM, seg(t, REV_T + 0.15, REV_T + 2.0))
    if t < GAZ_T: return cam_lerp(ISR_CAM, SIN_CAM, seg(t, SIN_T, SIN_T + 0.8))
    if t < END_T: return cam_lerp(SIN_CAM, GAZ_CAM, seg(t, GAZ_T, GAZ_T + 0.9))
    return cam_lerp(GAZ_CAM, HOOK_CAM, seg(t, END_T, T_END - LOOP - 0.15))

def map_layer(canvas, t, cam):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); c.set_line_join(cairo.LINE_JOIN_ROUND)
    # deep zoom: vector land over the (soft) photo, so coasts stay crisp
    hw = 540 / (cam.k * cam.cosf); hh = 960 / cam.k
    inside = cam.lon - hw > 24.5 and cam.lon + hw < 45.5 and cam.lat - hh > 22.5 and cam.lat + hh < 39.5
    va = seg(cam.k, 60, 130) if inside else 0.0
    if va > 0:
        for k, rs in LOCAL.items():
            if k in LB: solid(c, cam, rs, "#1D1E1A", 0.82 * va, 1.2, "#5A5B52")
    # hook shimmer: each empire flashes once in its flag (motion by 1.5 s)
    if t < B[0]["t0"] + 0.3:
        for i, b in enumerate(B):
            a0 = 0.25 + 0.19 * i; al = 0.8 * seg(t, a0, a0 + 0.18) * (1 - seg(t, a0 + 0.42, a0 + 0.75))
            flag_fill(c, cam, EMP[b["key"]], b["flag"], EB[b["key"]], al, stroke=al > 0.05, polys=EP[b["key"]])
    for b in B:
        t_off = b["t1"] if b["rank"] != 1 else REV_T + 0.5
        fa = seg(t, b["t0"] + 0.05, b["t0"] + 0.4) * (1 - seg(t, t_off - 0.08, t_off + 0.25))
        if b["rank"] == 1: fa = seg(t, b["t0"] + 0.05, b["t0"] + 0.4) * (1 - seg(t, REV_T + 0.2, REV_T + 1.3))
        flag_fill(c, cam, EMP[b["key"]], b["flag"], EB[b["key"]], 0.92 * fa, polys=EP[b["key"]])
    # Israel: flag over Israel (incl. Golan); West Bank and Gaza in a slightly different shade; Green Line green
    ia = seg(t, REV_T + 0.3, REV_T + 1.2) * (1 - seg(t, END_T + 1.0, END_T + 2.2))
    if ia > 0:
        solid(c, cam, PSX, ISR_SHADE, 0.9 * ia)
        flag_fill(c, cam, ISR_ONLY, "il", EB["isr"], ia, stroke=True, polys=EP["isr"])
        if cam.k > 20:
            path(c, cam, PSX); c.set_source_rgba(*GREEN, ia); c.set_line_width(min(5, 1.5 + cam.k / 120)); c.set_dash([10, 6]); c.stroke(); c.set_dash([])
    # Sinai: filled with the flag (held 1967 to 1982), then handed back on "back to Egypt"
    tb = S(11, WI(11, "back")) - 0.05
    sa = seg(t, SIN_T + 0.5, SIN_T + 0.9) * (1 - seg(t, tb, tb + 0.7))
    flag_fill(c, cam, SINAI, "il", EB["sinai"], sa, polys=EP["sinai"])
    if SIN_T < t < GAZ_T:   # after the hand-back: the outline of what was returned
        oa = seg(t, tb + 0.3, tb + 0.8) * (1 - seg(t, GAZ_T - 0.3, GAZ_T)); path(c, cam, SINAI); c.set_source_rgba(1, 1, 1, 0.9 * oa)
        c.set_line_width(3); c.set_dash([12, 8]); c.stroke(); c.set_dash([])
    # Gaza: filled, then left on "left Gaza"
    tg = S(12, WI(12, "left")) - 0.05
    ga = seg(t, GAZ_T + 0.5, GAZ_T + 0.9) * (1 - seg(t, tg, tg + 0.6))
    flag_fill(c, cam, GAZA, "il", EB["gaza"], ga, polys=EP["gaza"])
    surf.flush()
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data()).copy()
    rgba = a[:, :, [2, 1, 0, 3]].astype(np.float32); al = rgba[:, :, 3:4] / 255.0
    col = np.where(al > 0, rgba[:, :, :3] / np.maximum(al, 1e-6), 0)
    canvas.alpha_composite(Image.fromarray(np.dstack([col, al * 255]).clip(0, 255).astype(np.uint8), "RGBA"))

# vignette: darker top and bottom for the titles, subtitles and sources
_v = np.zeros((H, W), np.float32); yy = np.arange(H)[:, None]
_v += np.clip((620 - yy) / 620, 0, 1) ** 1.4 * 0.75 + np.clip((yy - 1360) / 560, 0, 1) ** 1.3 * 0.8
VIG = Image.fromarray(np.dstack([np.zeros((H, W, 3), np.uint8), (_v.clip(0, 1) * 255).astype(np.uint8)]), "RGBA")

# ------------------------------------------------------------------ subtitles: bold caps, white, one key word red
SUBF = font("db", 60)
CH = [  # (line, first word index, text, key word)
 (1, 0, "NUMBER EIGHT.", "EIGHT."), (1, WI(1, "Napoleon"), "NAPOLEON'S FRANCE.", "NAPOLEON'S"), (2, 0, "SEVEN. ROME.", "ROME."),
 (3, 0, "SIX. ALEXANDER THE GREAT.", "ALEXANDER"), (4, 0, "FIVE. THE UNITED STATES.", "UNITED"), (5, 0, "FOUR. THE UMAYYAD CALIPHATE.", "UMAYYAD"),
 (6, 0, "THREE. THE RUSSIAN EMPIRE.", "RUSSIAN"), (7, 0, "TWO. THE MONGOLS.", "MONGOLS."), (8, 0, "AND NUMBER ONE.", "ONE."),
 (8, WI(8, "The"), "THE BRITISH EMPIRE.", "BRITISH"), (8, WI(8, "More"), "MORE THAN A QUARTER OF THE WORLD.", "QUARTER"),
 (10, 0, "0.016 PERCENT.", "0.016"), (10, WI(10, "Colonies"), "COLONIES? ZERO.", "ZERO."),
 (11, 0, "IN 1982, IT GAVE SINAI", "SINAI"), (11, WI(11, "back"), "BACK TO EGYPT, FOR PEACE.", "PEACE."),
 (12, 0, "IN 2005, IT LEFT GAZA.", "GAZA."), (12, WI(12, "Every"), "EVERY SOLDIER. EVERY SETTLER.", "SETTLER."),
]
SUBS = []
for i, (li, wi, s, key) in enumerate(CH):
    a = S(li, wi) - 0.04; nxt = CH[i + 1] if i + 1 < len(CH) else None
    endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
    b = E(li, endw) + 0.35
    if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.05)
    SUBS.append((a, b, s, key)); assert len(s.split()) <= 7, s
def sub_lines(s):
    out = [[]]
    for w_ in s.split():
        trial = " ".join(out[-1] + [w_])
        if SUBF.getlength(trial) <= 960 or not out[-1]: out[-1].append(w_)
        else: out.append([w_])
    return out
def subtitles(canvas, t):
    for a, b, s, key in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.08 + 1e-4, (b - t) / 0.1); pop = 1 + 0.06 * (1 - seg(t, a, a + 0.12))
            lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); lines = sub_lines(s); lh = 74
            y0 = 1560 - lh * (len(lines) - 1) / 2; sp = SUBF.getlength(" ")
            for i, ws in enumerate(lines):
                tw = sum(SUBF.getlength(w_) for w_ in ws) + sp * (len(ws) - 1); x = 540 - tw / 2
                for w_ in ws:
                    col = hx(RED if w_ == key else WHITE)
                    d.text((x, y0 + i * lh), w_, font=SUBF, fill=tuple(int(c) for c in col) + (int(255 * al),), anchor="lm",
                           stroke_width=5, stroke_fill=(0, 0, 0, int(230 * al)))
                    x += SUBF.getlength(w_) + sp
            if pop > 1.001:
                lay = lay.resize((int(W * pop), int(H * pop)), Image.BICUBIC).crop((int((W * pop - W) / 2), int((1560 * pop - 1560)), int((W * pop - W) / 2) + W, int((1560 * pop - 1560)) + H))
            canvas.alpha_composite(lay)

# ------------------------------------------------------------------ sources (36 to 40 px grey)
SRCF = font("r", 38)
SRC0 = ["Share of world land: Taagepera, via Wikipedia", "Map: NASA Blue Marble, public domain"]
SOURCES = [(0, SRC0)] + [(b["t0"], ["Share of world land: Taagepera, via Wikipedia", f"Borders approx.: {b['note']}"]) for b in B] + [
    (REV_T + 1.2, ["Israel 22,072 km², incl. Golan, E. Jerusalem (CBS)", "Same world base as the list. Green Line in green"]),
    (SIN_T, ["Sinai about 60,000 km², Wikipedia. Returned", "under the 1979 peace treaty, completed 1982"]),
    (GAZ_T, ["Gaza disengagement, completed 12 Sep 2005:", "21 settlements, about 8,500 settlers. Wikipedia"]),
    (END_T, SRC0)]
def sources(canvas, t):
    lay = None
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.3)) * (1 - seg(t, t1 - 0.2, t1))
        if t >= t0 - 0.01 and a > 0.004:
            lay = lay or Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            for j, l in enumerate(lines): d.text((540, 1752 + j * 48), l, font=SRCF, fill=(170, 170, 176, int(255 * a)), anchor="mm")
    if lay: canvas.alpha_composite(lay)

# ------------------------------------------------------------------ frame
HOOK = ("THE GREATEST", "EMPIRES IN HISTORY.")
HS = min(fit(HOOK[0], "db", 120), fit(HOOK[1], "db", 120)); HY = (330, 330 + HS * 1.08)
ENDL = ("SO NEXT TIME SOMEONE", "CALLS ISRAEL AN EMPIRE...")
ES = min(fit(ENDL[0], "db", 120), fit(ENDL[1], "db", 120))
TITLE_Y, PCT_Y, YEAR_Y = 300, 410, 482
def frame_raw(t):
    cam = camera(t); im = background(cam); map_layer(im, t, cam); im.alpha_composite(VIG)
    b0 = B[0]["t0"]
    text(im, t, HOOK[0], HY[0], HS, 0, b0 - 0.05, inst=True, zoom=1 + 0.025 * seg(t, 0, b0))
    text(im, t, HOOK[1], HY[1], HS, 0, b0 - 0.05, inst=True, zoom=1 + 0.025 * seg(t, 0, b0))
    text(im, t, ENDL[0], HY[0], ES, END_T, T_END, ain=0.4); text(im, t, ENDL[1], HY[1], ES, END_T + 0.1, T_END, ain=0.4)
    for b in B:
        t0, t1 = b["t0"], (b["t1"] if b["rank"] != 1 else REV_T)
        text(im, t, b["title"], TITLE_Y, fit(b["title"], "db", 104), t0, t1 - 0.12, ain=0.22)
        rich(im, t, [(f"{b['pct']}%", GOLD), (" of the World", WHITE)], PCT_Y, 64, t0 + 0.08, t1 - 0.12, ain=0.22)
        text(im, t, f"Peak: {b['year']}", YEAR_Y, fit(f"Peak: {b['year']}", "dm", 42), t0 + 0.14, t1 - 0.12, fk="dm", color=GREY, ain=0.22)
    # the twist
    text(im, t, "AND ISRAEL?", TITLE_Y + 40, 132, REV_T, S(10) - 0.15, ain=0.35)
    text(im, t, "ISRAEL", TITLE_Y, 112, S(10) - 0.1, SIN_T - 0.1, ain=0.25)
    rich(im, t, [("0.016%", GOLD), (" of the World", WHITE)], PCT_Y, 64, S(10) - 0.05, SIN_T - 0.1, ain=0.25)
    tc = S(10, WI(10, "Colonies")) - 0.05
    rich(im, t, [("Colonies: ", WHITE), ("0", GOLD)], YEAR_Y + 18, 72, tc, SIN_T - 0.1, fk="db", ain=0.25)
    tb = S(11, WI(11, "back")) - 0.05
    text(im, t, "1982: SINAI", TITLE_Y, 112, SIN_T + 0.05, GAZ_T - 0.1, ain=0.25)
    rich(im, t, [("About ", WHITE), ("3x", GOLD), (" the size of Israel", WHITE)], PCT_Y, 60, SIN_T + 0.2, GAZ_T - 0.1, ain=0.25)
    text(im, t, "Handed back to Egypt, for peace", YEAR_Y + 14, fit("Handed back to Egypt, for peace", "dm", 50), tb + 0.1, GAZ_T - 0.1, fk="dm", ain=0.25)
    tg = S(12, WI(12, "left")) - 0.05
    text(im, t, "2005: GAZA", TITLE_Y, 112, GAZ_T + 0.05, END_T - 0.1, ain=0.25)
    rich(im, t, [("Israel left. ", WHITE), ("Every", GOLD), (" soldier and settler", WHITE)], PCT_Y, fit("Israel left. Every soldier and settler", "dsb", 60), tg + 0.05, END_T - 0.1, ain=0.25)
    if REV_T + 0.3 < t < S(10) + 0.4:      # white ring closing onto Israel during the dive
        u = (t - REV_T - 0.3) / (S(10) + 0.4 - REV_T - 0.3); px, py = ll2xy(cam, 35.1, 31.4); rr = 220 * (1 - ease(u)) + 26
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(ov).ellipse((px - rr, py - rr, px + rr, py + rr), outline=(255, 255, 255, int(230 * (1 - u))), width=6)
        im.alpha_composite(ov)
    sources(im, t); subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS)); return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s, _ in SUBS] + [l for _, v in SOURCES for l in v] + [b["title"] for b in B] + list(HOOK) + list(ENDL)
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 1000, ("source too wide", l)
N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
