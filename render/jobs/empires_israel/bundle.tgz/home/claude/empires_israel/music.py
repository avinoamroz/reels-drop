"""music.py: an original dark phonk-style beat for empires_israel (all synthesized here, no samples), exactly the reel's
16 bars (work/grid.json), so the loop lands on a downbeat; + mix with work/vo.wav -> work/mix.m4a (-14 LUFS, <= -1.5 dBTP).
D minor, 4-bar progression Dm, Dm, Bb, A. 808 kick (1, 1.75 and 3.5), clap on 3 (half-time), 16th hats with 32nd rolls,
the phonk cowbell riff (two detuned square partials, short decay), 808 bass with glides and saturation, dark pad.
Bar 10 ("And Israel?") is a breakdown: drums and cowbell out, a sub drop and the pad only, a reversed swell into bar 11.
The tails of the last bar are folded onto the start (wrap-around), so the last sample flows into the first."""
import sys, os, json, numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/empires_israel"; SR = AU.SR
G = json.load(open(f"{D}/work/grid.json")); BAR = G["bar"]; NB = G["bars"]; T = G["T_END"]; BEAT = BAR / 4; S16 = BEAT / 4
N = int(round(T * SR)); EXT = int(4 * SR)
L = np.zeros(N + EXT); R = np.zeros(N + EXT)
rng = np.random.default_rng(7)
def lp(x, f, o=2): return sosfilt(butter(o, f, "lp", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "hp", fs=SR, output="sos"), x)
def bp(x, a, b, o=2): return sosfilt(butter(o, [a, b], "bp", fs=SR, output="sos"), x)
def add(sig, t, g=1.0, pan=0.0):
    i = int(round(t * SR)); j = min(len(L), i + len(sig))
    if j <= i: return
    L[i:j] += sig[:j - i] * g * (1 - max(0, pan)); R[i:j] += sig[:j - i] * g * (1 + min(0, pan))
def tt(d): return np.arange(int(d * SR)) / SR
def mtof(m): return 440 * 2 ** ((m - 69) / 12)
def kick():
    t = tt(0.55); f = 48 + 110 * np.exp(-t * 28); x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 6.5)
    return np.tanh(2.2 * x) * 0.9
def clap():
    t = tt(0.32); nz = rng.standard_normal(len(t)); e = np.exp(-t * 18)
    for d in (0.0, 0.011, 0.022): e = e + 0.6 * np.exp(-np.maximum(0, t - d) * 90) * (t >= d)
    return bp(nz, 900, 5200) * e * 0.5
def hat(o=False):
    t = tt(0.22 if o else 0.05); return hp(rng.standard_normal(len(t)), 7000) * np.exp(-t * (14 if o else 80)) * 0.22
def bell(m, d=0.16):
    t = tt(d); f = mtof(m); sq = lambda fr: np.sign(np.sin(2 * np.pi * fr * t))
    x = (sq(f) + 0.75 * sq(f * 1.4823)) * np.exp(-t * 16) ; return bp(x, 380, 4200) * 0.16
def sub808(m0, m1, d, glide=0.08):
    t = tt(d); f0, f1 = mtof(m0), mtof(m1); u = np.clip(t / glide, 0, 1); f = f0 + (f1 - f0) * u if m0 != m1 else np.full(len(t), f0)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR); env = np.minimum(1, t / 0.005) * np.exp(-t * 0.9) * np.minimum(1, (d - t) / 0.04)
    return np.tanh(1.8 * x) * env * 0.55
def pad(notes, d):
    t = tt(d); x = np.zeros(len(t))
    for m in notes:
        for det in (-0.08, 0.0, 0.08):
            f = mtof(m + det); x += 2 * ((f * t) % 1.0) - 1
    env = np.minimum(1, t / 0.6) * np.minimum(1, (d - t) / 0.5); return lp(x, 900) * env * 0.05
PROG = [(38, [62, 65, 69]), (38, [62, 65, 69]), (34, [58, 62, 65]), (33, [57, 61, 64])]
RIFF = [74, 77, 81, 79, 77, 76, 74, 72, 74, 77, 81, 82, 81, 79, 77, 76]     # cowbell 16ths, D minor
BREAK = 10
for b in range(NB + 1):                       # one extra bar: its head folds onto bar 0
    t0 = b * BAR; root, chord = PROG[b % 4]; brk = (b == BREAK)
    add(pad(chord, BAR + 0.5), t0, 1.0 if not brk else 1.4, pan=0.0)
    if brk:
        add(sub808(root - 12, root - 12, BAR * 0.9), t0, 1.1)
        sw = hp(rng.standard_normal(int(BAR * SR)), 3000) * np.linspace(0, 1, int(BAR * SR)) ** 3 * 0.25; add(sw, t0)
        continue
    for k, frac in enumerate((0.0, 0.4375, 0.875)):
        add(kick(), t0 + frac * BAR, 1.0)
    add(sub808(root, root, BAR * 0.43), t0, 1.0); add(sub808(root, root + (3 if b % 2 else -2), BAR * 0.5), t0 + 0.5 * BAR, 1.0)
    add(clap(), t0 + 0.5 * BAR, 1.0)
    for s in range(16):
        add(hat(o=(s % 8 == 6)), t0 + s * S16, 0.9 if s % 2 == 0 else 0.6, pan=0.15)
    if b % 2 == 1:                            # 32nd roll at the bar end
        for r in range(6): add(hat(), t0 + 0.875 * BAR + r * S16 / 2, 0.5 + 0.08 * r, pan=0.15)
    shift = -2 if root == 34 else (-5 if root == 33 else 0)
    for s, m in enumerate(RIFF):
        if s in (7, 15) and b % 4 == 3: continue
        add(bell(m + shift), t0 + s * S16, 0.95, pan=-0.2 if s % 2 else 0.2)
# fold the overflow (past the last bar) onto the start
st = np.vstack([L, R]); bed = st[:, :N].copy(); ov = st[:, N:N + EXT]; bed[:, :ov.shape[1]] += ov
bed = bed / (np.abs(bed).max() + 1e-9)
print("seam step", float(np.abs(bed[:, 0] - bed[:, -1]).max()))
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR
ev = [(BREAK * BAR + 0.02, AU.soft_hit(), -3.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, T, ev, mw, music_db=-15.0, sfx_db=-12.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=T, bpm=G["bpm"], bars=NB, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1)
print("audio", T, J.get("final_I"), J.get("final_TP"))
