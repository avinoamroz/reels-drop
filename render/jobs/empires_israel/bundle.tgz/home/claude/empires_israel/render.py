"""cloud step: silent video (reel.py) + work/mix.m4a -> empires_israel.mp4"""
import subprocess, os, json
D = "/home/claude/empires_israel"; T = json.load(open(f"{D}/work/audio.json"))["T_END"]
subprocess.run(["nice", "-n", "10", "python3", f"{D}/reel2.py", "--out", f"{D}/work/silent.mp4"], check=True)
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", f"{D}/work/silent.mp4", "-i", f"{D}/work/mix.m4a", "-map", "0:v", "-map", "1:a",
                "-c", "copy", "-t", f"{T:.2f}", "-movflags", "+faststart", f"{D}/empires_israel.mp4"], check=True)
os.remove(f"{D}/work/silent.mp4"); print("final", f"{D}/empires_israel.mp4")
