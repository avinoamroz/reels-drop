"""water_2000 scenes (1 Nov 2026): 2,700 years of moving water on ONE map of the land of Israel.
Loads the water_compare_rmk1 module (house map colours, _wbase, d01 stage/photo/loop helpers), then adds sc_era:
- the same full map in every scene (whole land of Israel incl. Golan in gold, West Bank and Gaza a slightly different gold,
  Green Line green, Sea of Galilee and Dead Sea in water blue), so the cuts feel like one continuous map
- a big yellow year label that counts from the previous scene's year (the "3,000 years" look), or the hook text in scene 0
- water lines that draw themselves (sky blue core, white dashes running along), earlier eras stay on the map, dimmer
- pins with label pills, an optional rounded photo inset over the sea with its credit, an optional big counter
- loop: the last scene rewinds the year to 700 BCE; d01's last 0.5 s cross-fade lands on frame 0."""
exec(compile(open("/home/claude/water_compare_rmk1/scenes_wc.py").read(), "/home/claude/water_compare_rmk1/scenes_wc.py", "exec"))

BOX = (0, 470, 1080, 1500)
VIEW = [32.57, 29.45, 37.43, 33.40]
LAKEC = (0.13, 0.42, 0.68)
_W2 = {}

def _base2(view=None):
    view = tuple(view or VIEW)
    if view in _W2: return _W2[view]
    mv, s = _wbase(list(view), BOX); bc = cairo.Context(s)
    R = _region()
    for nm in ("Sea of Galilee", "Dead Sea"):
        lk = R["lakes"].get(nm)
        if lk is None: continue
        for p in ([lk] if lk.geom_type == "Polygon" else list(lk.geoms)):
            pts = [mv.P(x, y) for x, y in p.exterior.coords]; _ring_path(bc, pts)
        sa(bc, LAKEC); bc.fill()
    jr = R["rivers"].get("Jordan")
    if jr is not None:
        for ln in _lines(jr):
            pts = [mv.P(x, y) for x, y in ln.coords]; bc.move_to(*pts[0]); [bc.line_to(*q) for q in pts[1:]]
            sa(bc, LAKEC, 0.9); bc.set_line_width(3); bc.stroke()
    _W2[view] = (mv, s)
    return mv, s

def _yfmt(y, approx):
    y = int(round(y))
    if y < 0: return ("c. " if approx else "") + f"{-y:,} BCE"
    return ("c. " if approx else "") + (f"{y} CE" if y < 1000 else f"{y}")

def _poly(pts, u):
    """first fraction u of a polyline (by length)"""
    if u >= 1.0: return pts
    L = [math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1)]
    tot = sum(L) * max(0.0, u); out = [pts[0]]
    for i, l in enumerate(L):
        if tot <= l:
            f = 0 if l == 0 else tot / l; out.append((pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f)); break
        out.append(pts[i + 1]); tot -= l
    return out

def _line(c, t, mv, fl, tin, a=1.0, dur=1.3):
    if t < tin - 0.02: return
    g = ease(min(1.0, (t - tin) / dur)); pts = [mv.P(x, y) for x, y in fl["pts"]]
    if fl.get("rev"): pts = pts[::-1]
    p = _poly(pts, g)
    if len(p) < 2: return
    core = YEL if fl.get("yel") else SKY; w = fl.get("w", 12)
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    def path():
        c.move_to(*p[0]); [c.line_to(*q) for q in p[1:]]
    path(); sa(c, (0.02, 0.06, 0.14), 0.6 * a); c.set_line_width(w + 9); c.stroke()
    path(); sa(c, core, 0.97 * a); c.set_line_width(w); c.stroke()
    path(); c.set_dash([4, 22], -(t * 80) % 26); sa(c, WHITE, 0.95 * a); c.set_line_width(max(4, w * 0.5)); c.stroke(); c.set_dash([])
    if g < 1.0:   # bright water head
        circ(c, p[-1][0], p[-1][1], w * 1.1, WHITE, a); circ(c, p[-1][0], p[-1][1], w * 1.9, core, 0.35 * a)
    elif a > 0.8:
        r = w * 0.9 + 4 * math.sin(t * 5); circ(c, p[-1][0], p[-1][1], r, core, a); circ(c, p[-1][0], p[-1][1], r * 0.45, WHITE, a)

def _pin(c, t, mv, pn, tin, a=1.0, z=1.0):
    if t < tin - 0.02: return None
    u = ease(min(1.0, (t - tin) / 0.35)); x, y = mv.P(pn["at"][0], pn["at"][1])
    colr = YEL if pn.get("yel") else SKY
    if a > 0.8:
        ph = (t * 0.9 + pn["at"][0]) % 1.0; circ(c, x, y, 16 + 50 * ph, colr, 0.5 * (1 - ph) * a)
    circ(c, x, y, 17 * u, WHITE, a); circ(c, x, y, 11 * u, colr, a)
    return x, y

def sc_era(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); tm = S["times"]
    _stage_bg(c, t, S); mv, base = _base2(S.get("view")); x0, y0, x1, y1 = BOX
    c.save(); c.rectangle(x0, y0, x1 - x0, y1 - y0); c.clip()
    uz = 0.0 if hook else _ease3((t - t0) / max(1.0, (S["t1"] or t0 + 4) - t0)); zm = 1.0 + 0.045 * uz
    zx, zy = S.get("zc", (540, 985)); c.translate(zx, zy); c.scale(zm, zm); c.translate(-zx, -zy)
    c.set_source_surface(base, 0, 0); c.paint_with_alpha(St.a)
    if S.get("wb"):   # Oslo II beat: the West Bank and its Green Line pulse
        G = geo(); rg = mv.rings(G["PS"]["g"], 0.3) if "PS" in G else []
        if rg:
            pu = 0.5 + 0.5 * math.sin(t * 4.2); ua = ramp(t, tm.get("wb", t0 + 0.3), tm.get("wb", t0 + 0.3) + 0.4)
            _path(c, rg); sa(c, GREEN, 0.18 * ua * (0.6 + 0.4 * pu)); c.fill_preserve(); sa(c, GREEN, ua); c.set_line_width(6 + 3 * pu); c.stroke()
    for fl in S.get("old", []): _line(c, t, mv, fl, -99, a=0.5)
    for k, fl in enumerate(S.get("flows", [])):
        _line(c, t, mv, fl, 0.0 if hook else tm.get(f"f{k}", t0 + 0.3), dur=fl.get("dur", 1.3))
    for pn in S.get("old_pins", []):
        x, y = mv.P(*pn["at"]); circ(c, x, y, 10, WHITE, 0.6); circ(c, x, y, 6, SKY, 0.7)
    shown = []
    for k, pn in enumerate(S.get("pins", [])):
        tk = 0.0 if hook else tm.get(f"p{k}", t0 + 0.25 + 0.25 * k); r = _pin(c, t, mv, pn, tk)
        if r: shown.append((k, pn, tk, (zx + (r[0] - zx) * zm, zy + (r[1] - zy) * zm)))
    c.restore()
    for ya, yb, up in ((y0, y0 + 80, True), (y1 - 110, y1, False)):
        g = cairo.LinearGradient(0, ya, 0, yb)
        g.add_color_stop_rgba(0, 0.03, 0.06, 0.14, 1.0 if up else 0.0); g.add_color_stop_rgba(1, 0.03, 0.06, 0.14, 0.0 if up else 1.0)
        c.rectangle(0, ya, W, yb - ya); c.set_source(g); c.fill()
    # pin labels (screen space)
    for k, pn, tk, (x, y) in shown:
        if not pn.get("en"): continue
        a2, s2 = (1.0, 1.0) if hook else PP(t, tk + 0.12, S)
        f_ = kit.font(pn.get("sz", 48), 900); hw = f_.getlength(RD.clean(pn["en"]).replace("*", "")) / 2 + pn.get("sz", 48) * 0.6
        lx, ly = pn.get("lab") or (x + 240 + hw * 0.3, y - 60); lx = min(max(lx, 70 + hw), 1010 - hw)
        sa(c, WHITE, 0.8 * a2); c.set_line_width(3); c.move_to(x, y); c.line_to(lx, ly); c.stroke()
        pill(c, pn["en"], pn.get("sz", 48), lx, ly, INK, WHITE, a2, s2, outline=YEL if pn.get("yel") else SKY, w=900, padh=1.35)
    # photo inset over the sea
    if S.get("photo"):
        tp = 0.0 if hook else tm.get("ph", t0 + 0.2)
        a3, s3 = (1.0, 1.0) if hook else PP(t, tp, S, s0=0.7, bounce=1.0)
        if a3 > 0.01:
            px, py, pw, ph = S.get("pbox", (34, 700, 450, 340)); fx, fy = S.get("focus", (0.5, 0.5))
            u = _ease3((t - t0) / max(1.0, (S["t1"] or t0 + 4) - t0)); zz = 1.0 + 0.07 * u
            c.save(); cx, cy = px + pw / 2, py + ph / 2; c.translate(cx, cy); c.scale(s3, s3); c.translate(-cx, -cy)
            sa(c, (0, 0, 0), 0.4 * a3); rr(c, px + 5, py + 14, pw, ph, 30); c.fill()
            c.save(); rr(c, px, py, pw, ph, 30); c.clip()
            img = _cover(S["photo"], pw, ph, fx, fy); c.translate(px + pw * fx, py + ph * fy); c.scale(zz, zz); c.translate(-(px + pw * fx), -(py + ph * fy))
            c.set_source_surface(img, px, py); c.paint_with_alpha(a3); c.restore()
            sa(c, WHITE, 0.85 * a3); c.set_line_width(4); rr(c, px, py, pw, ph, 30); c.stroke(); c.restore()
    # big counter (payoff)
    if S.get("big"):
        tb = tm.get("big", t0 + 0.3); ub = ramp(t, tb - 0.2, tb + 0.3)
        sa(c, INK, 0.62 * ub); c.rectangle(0, 560, W, 760); c.fill()
        b = S["big"]; v = b["num"] * ease(min(1.0, max(0.0, (t - tb) / 1.3)))
        a4, s4 = PP(t, tb, S, s0=0.6, bounce=1.4)
        _wtext(c, f"{b.get('prefix', '')}{v:,.0f}{b.get('suffix', '')}", 280, 860, color=YEL, a=a4, sc=s4, max_lines=1)
        _wtext(c, b["label"], 72, 1080, a=a4, sc=s4, max_lines=2)
    # year counter or hook
    if hook:
        br = 1.0 + 0.012 * math.sin(t * 2.2)
        _wtext(c, S["hook_text"], S.get("size", 124), 400, a=1.0, sc=br, max_lines=2)
    elif S.get("year") is not None:
        ty = tm.get("yr", t0); y_ = S["year"]; yp = S.get("prev_year", y_)
        u = ease(min(1.0, max(0.0, (t - ty) / S.get("ydur", 0.9))))
        yv = yp + (y_ - yp) * u
        lab = S.get("ylabel") if (S.get("ylabel") and u >= 1.0) else _yfmt(yv, bool(S.get("approx")) and yv < 1000)
        _wtext(c, lab, 140, 330, color=YEL, a=1.0, max_lines=1)
    if S.get("en") and not hook:
        a1, s1 = PP(t, t0 + 0.15, S); _wtext(c, S["en"], S.get("en_size", 70), 455, a=a1, sc=s1, max_lines=1, maxw=1020)
    if S.get("note"):
        tn = tm.get("note", t0 + 0.6); a5, s5 = PP(t, tn, S)
        nx, ny = S.get("note_at", (540, 1250))
        pill(c, S["note"], S.get("note_size", 54), nx, ny, INK, WHITE, a5, s5, outline=YEL, w=900, padh=1.4)
    la = 1.0 if hook else RD.fade_in(t, t0 + 0.4, S)
    if S.get("credit"): _label(c, S["credit"], 1360, la)
    if S.get("source"): _label(c, S["source"], 1418, la)
