#!/usr/bin/env python3
"""endings_1101/cut.py JOB_DIR OUT.mp4: cloud step. Removes time spans from a published reel (video and audio together,
40 ms audio cross-fade at each seam). meta.json: {"id","src_url","cuts":[[a,b],...]}. Render only."""
import json, os, subprocess, sys, urllib.request
J, out = sys.argv[1], sys.argv[2]
m = json.load(open(os.path.join(J, "meta.json")))
src = "/tmp/src_" + m["id"] + ".mp4"
if not os.path.exists(src): urllib.request.urlretrieve(m["src_url"], src)
d = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src]).decode())
keep, cur = [], 0.0
for a, b in sorted(m["cuts"]): keep.append((cur, a)); cur = b
keep.append((cur, d))
fc, X = [], 0.04
for i, (a, b) in enumerate(keep):
    fc.append(f"[0:v]trim={a}:{b},setpts=PTS-STARTPTS[v{i}]")
    fc.append(f"[0:a]atrim={a}:{min(d, b + (X if i < len(keep) - 1 else 0))},asetpts=PTS-STARTPTS[a{i}]")
fc.append("".join(f"[v{i}]" for i in range(len(keep))) + f"concat=n={len(keep)}:v=1:a=0[v]")
prev = "a0"
for i in range(1, len(keep)):
    fc.append(f"[{prev}][a{i}]acrossfade=d={X}:c1=tri:c2=tri[x{i}]"); prev = f"x{i}"
os.makedirs(os.path.dirname(out), exist_ok=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex", ";".join(fc), "-map", "[v]", "-map", f"[{prev}]",
                "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "192k",
                "-ar", "48000", "-movflags", "+faststart", out], check=True)
print("cut", out, keep)
