"""peace_treaties: Israel's peace deals, what Israel gave back. Map plus counter (Egypt 1979, Jordan 1994) then a scorecard.
Map: whole land of Israel (gold, West Bank and Gaza darker gold, Green Line green), Sinai lit gold as held in 1967, then it
"returns" to Egypt with a sweep and a km2 counter. Jordan: the Arava border is drawn, 380 km2 counter, a water pipe with an
m3 counter. Scorecard, a "Not perfect" card, then the West Bank and Gaza. Circular: the last line "So next time they say
Israel never gives back land..." lands on the frame 0 hook.
python3 engine.py [--frames t1,t2,...] [--out path.mp4]"""
import os, sys, math, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

D = os.path.dirname(os.path.abspath(__file__)); ARGS = sys.argv[1:]
TM = Timing(D, tail=1.3); wt, lt, CUT, END = TM.wt, TM.lt, TM.CUT, TM.END
NL = TM.n
EGC, EGL = hx("#1C3566"), hx("#2A4A85")   # neighbour fill, neighbour stroke

# ------------------------------------------------------------------ geometry
GIL = json.load(open(f"{D}/geo_il.json")); GPT = json.load(open(f"{D}/geo_pt.json"))
MX0, MY0, MW, MH = 40, 600, 1000, 940
VA = (33.75, 30.45, 140.0)      # Sinai view
VB = (35.85, 31.35, 175.0)      # Jordan view
VC = (35.05, 31.75, 300.0)      # West Bank and Gaza
T_RET0 = wt(4, "back") - 0.1
T_RET1 = wt(6, "1982", end=True)
T_TABA = wt(7, "Taba") - 0.05
T_CAMB = CUT[9]; T_CAMC = CUT[16]; T_LOOP = CUT[17]
def cam(t):
    def mixv(a, b, u): return tuple(lerp(x, y, u) for x, y in zip(a, b))
    v = VA
    v = mixv(v, VB, ease((t - T_CAMB) / 1.1))
    v = mixv(v, VC, ease((t - T_CAMC) / 1.0))
    v = mixv(v, VA, ease((t - (T_LOOP + 0.2)) / 1.4))
    return v
def proj(v):
    lo0, la0, mk = v; cf = math.cos(math.radians(la0))
    cx, cy = MX0 + MW / 2, MY0 + MH / 2
    return lambda lo, la: (cx + (lo - lo0) * cf * mk, cy - (la - la0) * mk)

def sinai_held(t):
    """1 = Sinai drawn as held by Israel (gold), 0 = returned to Egypt. Returns (west->east sweep fraction returned, taba held)"""
    r = ease((t - T_RET0) / max(0.5, T_RET1 - T_RET0))
    r *= 1 - ease((t - (T_LOOP + 0.3)) / 1.4)          # loop: back to the frame 0 look
    taba = 1 - ramp(t, T_TABA + 0.3, T_TABA + 0.9)
    taba = max(taba, ease((t - (T_LOOP + 0.3)) / 1.4))
    return r, taba

def draw_map(c, t, a=1.0):
    if a <= 0.01: return
    P = proj(cam(t))
    c.save(); rr(c, MX0, MY0, MW, MH, 40); c.clip()
    c.set_source_rgba(*hx("#0E2348")[:3], a); c.paint_with_alpha(a)
    # neighbours
    for nm in ("Saudi Arabia", "Iraq", "Syria", "Lebanon", "Jordan", "Egypt"):
        poly(c, GPT[nm], P)
        col = EGC
        if nm == "Jordan":
            uj = ramp(t, CUT[9] + 0.2, CUT[9] + 0.8) * (1 - ramp(t, CUT[12] - 0.2, CUT[12] + 0.3))
            col = mixc(EGC, hx("#24508F"), uj)
        c.set_source_rgba(*col[:3], a); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.28 * a); c.set_line_width(1.6); c.stroke()
    # Sinai: held (gold) vs returned (Egypt colour), swept west to east
    r, taba = sinai_held(t)
    lo0, la0, mk = cam(t)
    xs = [P(lo, la)[0] for rg in GPT["Sinai"] for lo, la in rg]; sx0, sx1 = min(xs), max(xs)
    bx = sx0 + (sx1 - sx0 + 4) * r
    poly(c, GPT["Sinai"], P); c.set_source_rgba(*EGC[:3], a); c.fill()
    pul = 0.86 + 0.10 * math.sin(t * 3.0)
    c.save(); c.rectangle(bx, 0, W, H); c.clip(); poly(c, GPT["Sinai"], P); c.clip()
    c.set_source_rgba(*GOLD[:3], a * pul); c.paint()
    c.set_source_rgba(1, 1, 1, 0.10 * a); c.set_line_width(3)
    for k in range(-40, 40):
        c.move_to(k * 26, 0); c.line_to(k * 26 + 1300, 1300 * 1.2)
    c.stroke()
    c.restore()
    if taba > 0.01:                                  # the Taba sliver, returned last
        tx, ty = P(34.89, 29.50); c.arc(tx, ty, max(5, 0.05 * mk), 0, 6.283); c.set_source_rgba(*GOLD[:3], a * taba); c.fill()
    if 0.002 < r < 0.998:
        g = cairo.LinearGradient(bx - 60, 0, bx + 6, 0); g.add_color_stop_rgba(0, *SKY[:3], 0); g.add_color_stop_rgba(1, *WHITE[:3], 0.55 * a)
        c.save(); poly(c, GPT["Sinai"], P); c.clip(); c.rectangle(bx - 60, 0, 66, H); c.set_source(g); c.fill(); c.restore()
    poly(c, GPT["Sinai"], P); c.set_source_rgba(*GOLD[:3], (0.55 + 0.35 * (1 - r)) * a); c.set_line_width(3); c.stroke()
    # Israel
    poly(c, GIL["isr"], P); c.set_source_rgba(*GOLD_IL[:3], a); c.fill_preserve(); c.set_source_rgba(*NIGHT[:3], 0.8 * a); c.set_line_width(2.5); c.stroke()
    wb = ramp(t, CUT[16] + 0.4, CUT[16] + 0.9) * (1 - ramp(t, T_LOOP, T_LOOP + 0.6))
    poly(c, GIL["pal"], P); c.set_source_rgba(*mixc(GOLD_PA, hx("#D9B867"), wb * (0.5 + 0.5 * math.sin(t * 4)))[:3], a); c.fill()
    poly(c, GIL["lakes"], P); c.set_source_rgba(*hx("#0E2348")[:3], a); c.fill()
    c.set_source_rgba(*GREEN[:3], a); c.set_line_width(3.0 if mk < 250 else 4.0)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    # Jordan: Arava border drawn south to north, the returned strip glows
    ub = ramp(t, CUT[10] - 0.1, CUT[10] + 1.4) * (1 - ramp(t, CUT[12] - 0.2, CUT[12] + 0.3))
    if ub > 0.01:
        pts = BORDER
        n = max(2, int(len(pts) * ub))
        c.set_line_width(14); c.set_source_rgba(*SKY[:3], 0.45 * a * (0.7 + 0.3 * math.sin(t * 4)))
        for i, (lo, la) in enumerate(pts[:n]):
            x, y = P(lo + 0.06, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
        c.set_line_width(5); c.set_source_rgba(*GOLD[:3], a); c.set_dash([16, 10])
        for i, (lo, la) in enumerate(pts[:n]):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke(); c.set_dash([])
    draw_pipe(c, t, P, a)
    draw_pins(c, t, P, a)
    # country labels
    def lab(s, lo, la, al, size=44, col=WHITE):
        if al <= 0.01: return
        x, y = P(lo, la)
        if MX0 + 40 < x < MX0 + MW - 40 and MY0 + 40 < y < MY0 + MH - 40: text(c, s, size, x, y, 800, col, al * a)
    m_a = 1 - ramp(t, T_CAMC, T_CAMC + 0.5) * (1 - ramp(t, T_LOOP + 0.3, T_LOOP + 1.0))
    lab("EGYPT", 31.2, 29.2, m_a * (1 - ramp(t, T_CAMB, T_CAMB + 0.6)) + ramp(t, T_LOOP + 0.6, T_LOOP + 1.2))
    lab("SINAI", 33.75, 29.55, m_a, 50, NIGHT if r < 0.5 else GOLD)
    lab("JORDAN", 36.9, 30.9, m_a * ramp(t, CUT[1], CUT[1] + 0.5))
    lab("ISRAEL", 34.80, 30.65, ramp(t, T_CAMC + 0.5, T_CAMC + 0.9) * (1 - ramp(t, T_LOOP, T_LOOP + 0.4)), 46, NIGHT)
    wl = ramp(t, T_CAMC + 0.6, T_CAMC + 1.0) * (1 - ramp(t, T_LOOP, T_LOOP + 0.4))
    lab("West Bank", 35.62, 32.05, wl, 46, WHITE)
    lab("Gaza", 34.05, 31.62, wl, 46, WHITE)
    c.restore()
    rr(c, MX0, MY0, MW, MH, 40); c.set_source_rgba(*SKY[:3], 0.35 * a); c.set_line_width(2); c.stroke()
    text(c, "Green Line", 36, MX0 + MW - 28, MY0 + 56, 700, GREEN, a, "r")

def _border():
    """eastern edge of Israel's polygon from Eilat to the Dead Sea (the Arava border with Jordan)"""
    ring = GIL["isr"][0]
    pts = [(lo, la) for lo, la in ring if 29.48 <= la <= 31.05 and lo >= 34.93]
    pts.sort(key=lambda p: p[1])
    return pts
BORDER = _border()

def draw_pipe(c, t, P, a):
    u = ramp(t, CUT[11] - 0.1, CUT[11] + 0.5) * (1 - ramp(t, CUT[12] - 0.2, CUT[12] + 0.3))
    if u <= 0.01: return
    x0, y0 = P(35.20, 32.62); x1, y1 = P(36.35, 32.25)
    grow = ease((t - CUT[11]) / 0.9)
    xe, ye = lerp(x0, x1, grow), lerp(y0, y1, grow)
    c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.set_line_width(30); c.set_source_rgba(*hx("#0B1426")[:3], 0.85 * a * u); c.move_to(x0, y0); c.line_to(xe, ye); c.stroke()
    c.set_line_width(20); c.set_source_rgba(*SKY[:3], a * u); c.move_to(x0, y0); c.line_to(xe, ye); c.stroke()
    # flowing water dashes
    c.set_line_width(8); c.set_source_rgba(1, 1, 1, 0.9 * a * u); c.set_dash([18, 26], -(t * 120) % 44)
    c.move_to(x0, y0); c.line_to(xe, ye); c.stroke(); c.set_dash([])
    c.set_line_cap(cairo.LINE_CAP_BUTT)
    if grow > 0.95:
        for k in range(3):
            ph = (t * 1.3 + k / 3) % 1.0
            c.arc(x1 + 4, y1 + 24 + 60 * ph, 9 * (1 - 0.4 * ph), 0, 6.283); c.set_source_rgba(*SKY[:3], a * u * (1 - ph)); c.fill()

PINS = [  # lon, lat, label, label2, line, word
    (33.20, 28.88, "Sinai oil fields", "1/4 of Israel's oil", 5, "oil"),
    (34.18, 31.24, "Yamit", "torn down, Apr 1982", 6, "town"),
    (34.89, 29.50, "Taba", "returned 1989", 7, "Taba"),
]
def draw_pins(c, t, P, a):
    for k, (lo, la, l1, l2, li, wd) in enumerate(PINS):
        t0 = wt(li, wd) - 0.1; t1 = CUT[8] if k < 2 else CUT[8]
        u = ramp(t, t0, t0 + 0.3) * (1 - ramp(t, t1 - 0.2, t1 + 0.2))
        if u <= 0.01: continue
        x, y = P(lo, la); pop = eob(clamp((t - t0) / 0.4))
        col = RED if k == 1 else GOLD
        dt = t - t0
        if 0 < dt < 0.9:
            c.set_source_rgba(*col[:3], u * a * (1 - dt / 0.9)); c.set_line_width(4); c.arc(x, y, 10 + 70 * dt, 0, 6.283); c.stroke()
        pin(c, x, y, col, u * a, 1.3 * pop)
        # callout card
        f1, f2 = 50, 42
        w_ = max(font(f1, 900).getlength(l1), font(f2, 800).getlength(l2)) + 44
        side = -1 if k == 0 else 1
        if k == 1: bx, by = x - w_ / 2, y - 250
        elif k == 0: bx, by = x - w_ - 40, y - 230
        else: bx, by = x + 40, y - 70
        bx = max(MX0 + 20, min(MX0 + MW - 20 - w_, bx))
        rr(c, bx, by, w_, 130, 22); c.set_source_rgba(*NIGHT[:3], 0.9 * u * a); c.fill()
        rr(c, bx, by, w_, 130, 22); c.set_source_rgba(*col[:3], 0.8 * u * a); c.set_line_width(2.5); c.stroke()
        text(c, l1, f1, bx + 22, by + 58, 900, col, u * a, "l")
        text(c, l2, f2, bx + 22, by + 110, 800, WHITE, u * a, "l")

# ------------------------------------------------------------------ photos
def _ph(name):
    p = f"{D}/{name}.jpg"
    return p if os.path.exists(p) else None
PH = {}
def photo(name, w, h):
    k = (name, w, h)
    if k not in PH:
        p = _ph(name); PH[k] = None
        if p:
            im = Image.open(p).convert("RGB"); sc = max(w / im.width, h / im.height) * 1.08
            PH[k] = (pil2cairo(im.resize((int(im.width * sc) + 1, int(im.height * sc) + 1), Image.LANCZOS).convert("RGBA")), im.width * sc, im.height * sc)
    return PH[k]
CREDIT = json.load(open(f"{D}/credits.json")) if os.path.exists(f"{D}/credits.json") else {}
FULL = (60, 610, 960, 700); THUMB = (70, 618, 330, 240)
def draw_photo(c, t, name, t0, t1, shrink_at=None, caption=None, grey=False):
    if not _ph(name): return
    a = ramp(t, t0, t0 + 0.35) * (1 - ramp(t, t1 - 0.3, t1))
    if a <= 0.01: return
    u = ease((t - shrink_at) / 0.6) if shrink_at else 0.0
    x, y, w, h = [lerp(p, q, u) for p, q in zip(FULL, THUMB)]
    ph = photo(name, FULL[2], FULL[3])
    if ph is None: return
    surf, pw, phh = ph
    z = 1.0 + 0.07 * clamp((t - t0) / 6.0)
    c.save(); rr(c, x, y, w, h, 30 - 12 * u); c.clip()
    s = w / FULL[2] * z
    c.translate(x + w / 2, y + h / 2); c.scale(s, s); c.translate(-pw / 2, -phh / 2)
    c.set_source_surface(surf, 0, 0); c.paint_with_alpha(a)
    c.restore()
    if grey:
        c.save(); rr(c, x, y, w, h, 30); c.clip(); c.set_source_rgba(0.04, 0.07, 0.14, 0.45 * a); c.paint(); c.restore()
    rr(c, x, y, w, h, 30 - 12 * u); c.set_source_rgba(1, 1, 1, 0.5 * a); c.set_line_width(2); c.stroke()
    if u < 0.5:
        b = a * (1 - 2 * u)
        g = cairo.LinearGradient(0, y + h - 190, 0, y + h); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0.03, 0.06, 0.13, 0.85 * b)
        c.save(); rr(c, x, y, w, h, 30); c.clip(); c.rectangle(x, y + h - 190, w, 190); c.set_source(g); c.fill(); c.restore()
        if caption: text(c, caption, fit(caption, 58, w - 60, 900), x + w / 2, y + h - 60, 900, WHITE, b)
        cr = CREDIT.get(name, "")
        if cr: text(c, cr, fit(cr, 36, 940, 700, 36), 540, y + h + 50, 700, MUTE, b)

# ------------------------------------------------------------------ top band
def fmtn(v): return f"{v:,.0f}"
def draw_top(c, t):
    i = TM.scene(t)
    if i == 0 or t >= END - 0.9:
        a = 1.0 if i == 0 else ramp(t, END - 1.3, END - 1.0)
        draw_hook(c, t, a); return
    if i == 17:
        b = ramp(t, CUT[17], CUT[17] + 0.3) * (1 - ramp(t, END - 1.55, END - 1.3))
        text(c, "So next time they say", 76, 540, 400, 900, WHITE, b)
        text(c, "Israel never gives back land...", fit("Israel never gives back land...", 76, 980, 900), 540, 500, 900, GOLD, b)
        draw_hook(c, t, ramp(t, END - 1.3, END - 1.0)); return
    a = ramp(t, CUT[i], CUT[i] + 0.3)
    def big(s, col=GOLD, sub=None, subcol=WHITE, size=170):
        text(c, s, fit(s, size, 980, 900), 540, 440, 900, col, a)
        if sub: text(c, sub, fit(sub, 60, 980, 800), 540, 540, 800, subcol, a)
    if i == 1: big("1967", sub="Six Day War: Israel holds Sinai")
    elif i == 2:
        t0 = wt(2, "Sixty") - 0.05; v = 61000 * eout((t - t0) / 1.6) if t > t0 else 0
        big(f"{fmtn(v)} km²", sub="Sinai: about 2.8 times Israel")
    elif i == 3: big("1977", sub="Egypt's President Sadat in Jerusalem")
    elif i in (4, 5, 6, 7):
        if t < T_RET0: big("1979", sub="Peace treaty with Egypt")
        else:
            r, _ = sinai_held(t); v = 61000 * r
            if t > T_TABA + 0.6: v = 61000
            big(f"{fmtn(v)} km²", sub="Returned to Egypt", subcol=GREENB)
    elif i == 8: big("1981", RED, sub="Sadat is assassinated")
    elif i == 9: big("1994", sub="Peace with Jordan")
    elif i == 10:
        t0 = wt(10, "three") - 0.05; v = 380 * eout((t - t0) / 1.4) if t > t0 else 0
        big(f"{fmtn(v)} km²", sub="Arava land returned to Jordan", subcol=GREENB)
    elif i == 11:
        t0 = wt(11, "fifty") - 0.05; v = 50 * eout((t - t0) / 1.4) if t > t0 else 0
        big(f"{v:.0f} million m³", SKY, sub="of water to Jordan, every year", size=150)
    elif 12 <= i <= 14: big("The scorecard", WHITE, size=130)
    elif i == 15: big("Not perfect", WHITE, size=140)
    elif i == 16: big("Still unresolved", WHITE, sub="West Bank and Gaza", size=130)

def draw_hook(c, t, a):
    if a <= 0.01: return
    text(c, "Israel returned", 124, 540, 400, 900, WHITE, a)
    parts(c, [("almost ", WHITE), ("3x", GOLD), (" its size.", WHITE)], 124, 530, a, 900)
    u = eout(t / 1.2) if t < 2 else 1.0
    w_ = font(124, 900).getlength("almost 3x its size.")
    c.set_source_rgba(*GOLD[:3], 0.9 * a); rr(c, 540 - w_ / 2, 562, w_ * u, 10, 5); c.fill()

def draw_compare(c, t):
    """line 2: Israel vs Sinai bars inside the map, bottom left"""
    a = ramp(t, wt(2, "Sixty") + 0.3, wt(2, "Sixty") + 0.7) * (1 - ramp(t, CUT[3] - 0.2, CUT[3] + 0.1))
    if a <= 0.01: return
    x, y, w = 80, 1270, 520
    rr(c, x - 20, y - 70, w + 60, 250, 26); c.set_source_rgba(*NIGHT[:3], 0.88 * a); c.fill()
    u = eout((t - (wt(2, "Sixty") + 0.4)) / 1.2)
    text(c, "Israel 22,072", 46, x, y, 800, WHITE, a, "l")
    rr(c, x, y + 14, w * 22072 / 61000 * u + 1, 30, 10); c.set_source_rgba(*WHITE[:3], a); c.fill()
    text(c, "Sinai 61,000", 46, x, y + 100, 800, GOLD, a, "l")
    rr(c, x, y + 114, w * u + 1, 30, 10); c.set_source_rgba(*GOLD[:3], a); c.fill()

# ------------------------------------------------------------------ scorecard + fair card
ROWS = [  # title, value, sub, line, word
    ("1967 land given back", "~90%", "Sinai alone: almost 90% of it", 12, "Sinai"),
    ("Peace with Egypt", "47 yrs", "Since 26 Mar 1979", 13, "Egypt"),
    ("Peace with Jordan", "32 yrs", "Since 26 Oct 1994", 13, "Jordan"),
    ("Abraham Accords, 2020", "+4", "UAE, Bahrain, Morocco, Sudan", 14, "Abraham"),
]
CX, CY, CW, CH = 50, 610, 980, 920
def draw_card(c, t):
    a = ramp(t, CUT[12], CUT[12] + 0.35) * (1 - ramp(t, CUT[16] - 0.1, CUT[16] + 0.3))
    if a <= 0.01: return
    rr(c, CX, CY, CW, CH, 36); c.set_source_rgba(*NIGHT[:3], 0.95 * a); c.fill()
    rr(c, CX, CY, CW, CH, 36); c.set_source_rgba(*SKY[:3], 0.4 * a); c.set_line_width(2); c.stroke()
    fa = 1 - ramp(t, CUT[15] - 0.1, CUT[15] + 0.25)
    if fa > 0.01:
        for k, (ti, val, sub, li, wd) in enumerate(ROWS):
            t0 = wt(li, wd) - 0.1; u = eout((t - t0) / 0.4)
            if t < t0: continue
            y = CY + 40 + 215 * k; dx = (1 - u) * 50; aa = a * fa * u
            rr(c, CX + 24 + dx, y, CW - 48, 190, 24); c.set_source_rgba(1, 1, 1, 0.06 * aa); c.fill()
            c.rectangle(CX + 24 + dx, y + 20, 8, 150); c.set_source_rgba(*(GREENB if k < 3 else SKY)[:3], aa); c.fill()
            text(c, ti, fit(ti, 58, 600, 800, 52), CX + 60 + dx, y + 82, 800, WHITE, aa, "l")
            text(c, sub, fit(sub, 40, 560, 700), CX + 60 + dx, y + 142, 700, MUTE, aa, "l")
            sc = eob(clamp((t - t0) / 0.45))
            text(c, val, 96, CX + CW - 60 + dx, y + 132, 900, GOLD, aa, "r", sc=max(0.01, sc))
    b = ramp(t, CUT[15], CUT[15] + 0.35)
    if b > 0.01:
        aa = a * b
        text(c, "Cold peace", 84, 540, CY + 150, 900, SKY, aa)
        t0 = wt(15, "five") - 0.1; v = 5 * eout((t - t0) / 0.8) if t > t0 else 0
        s1 = ramp(t, t0, t0 + 0.2)
        text(c, f"{v:.0f}%", 300, 540, CY + 500, 900, GOLD, aa * s1)
        text(c, "in Egypt and in Jordan", 62, 540, CY + 620, 800, WHITE, aa * s1)
        text(c, "back normalization with Israel", fit("back normalization with Israel", 62, 900, 800), 540, CY + 700, 800, WHITE, aa * s1)
        text(c, "Arab Barometer, Jan 2025", 38, 540, CY + 820, 700, MUTE, aa * s1)

SRC = {1: "Six Day War, June 1967", 2: "Sinai: Britannica. Israel: CBS, 22,072 km²",
       5: "JTA, 26 Nov 1979: Sinai fields, a quarter of Israel's use", 6: "Yamit evacuated, April 1982. Sinai handover 25 Apr 1982",
       7: "Taba: arbitration 29 Sep 1988, handed over 15 Mar 1989", 10: "Moscow Times, 1995. Two farms leased back; Jordan ended it in 2019",
       11: "Treaty Annex II, 1994. Extra 2021 deal expired 2025 (Kan, 2026)", 12: "Jewish Virtual Library",
       16: "Taken from Jordan and Egypt in 1967"}
def draw_source(c, t):
    i = TM.scene(t); s = SRC.get(i)
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1]))
    y = 1500 if i not in (12,) else 1490
    sz = fit(s, 38, 920, 700, 36)
    w_ = font(sz, 700).getlength(s) + 36
    rr(c, 540 - w_ / 2, y - 40, w_, 56, 16); c.set_source_rgba(*NIGHT[:3], 0.75 * a); c.fill()
    text(c, s, sz, 540, y, 700, MUTE, a)

REPL = [("Sixty-one thousand square kilometres", "61,000 km²"), ("three hundred and eighty square kilometres", "380 km²"),
        ("fifty million cubic metres", "50 million m³"), ("ninety percent", "90%"), ("forty-seven", "47"),
        ("thirty-two", "32"), ("five percent", "5%")]
SUBS = build_subs(TM, REPL)
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    draw_map(c, t, 1.0)
    draw_compare(c, t)
    draw_photo(c, t, "pt_sadat_knesset", CUT[3], CUT[4] + 0.2, caption="Sadat in the Knesset, Nov 1977")
    draw_photo(c, t, "pt_egypt_sign", CUT[4], CUT[8] + 0.1, shrink_at=T_RET0, caption="Begin, Carter, Sadat, 26 Mar 1979")
    draw_photo(c, t, "pt_begin_carter_sadat", CUT[8], CUT[9] + 0.2, caption="Anwar Sadat, 1918 to 1981", grey=True)
    draw_photo(c, t, "pt_jordan_gpo", CUT[9], CUT[12], shrink_at=CUT[10], caption="Rabin and King Hussein")
    draw_card(c, t)
    draw_top(c, t); draw_source(c, t)
    draw_subs(c, t, SUBS)
    return to_np(s)

if __name__ == "__main__":
    run(D, TM, frame, ARGS)

def SFX():
    ev = [(CUT[i] - 0.1, "whoosh", -3) for i in (3, 9, 12, 15)]
    ev += [(wt(li, wd) - 0.05, "pop", -2) for _, _, _, _, li, wd in PINS]
    ev += [(wt(li, wd) - 0.05, "pop", -2) for _, _, _, li, wd in ROWS]
    ev += [(T_TABA + 0.6, "ding", -2), (wt(10, "three") + 1.4, "ding", -3), (wt(15, "five") + 0.2, "ding", -2)]
    return ev
