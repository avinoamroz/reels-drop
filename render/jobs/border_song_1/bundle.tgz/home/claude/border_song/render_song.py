#!/usr/bin/env python3
"""border_song renderer: map of the whole land of Israel + Gaza/Egypt border, animated shut Rafah gate,
fact cards with sources, karaoke lyrics in sync with the voice. 1080x1920, 30 fps.
usage: render_song.py border_song_N [--still t1,t2,...]   (stills -> work/<id>/still_<t>.png)"""
import sys, os, json, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon, MultiPolygon, LineString, MultiLineString, box as sbox
from shapely.ops import unary_union

HERE = os.path.dirname(os.path.abspath(__file__))
W, H, FPS = 1080, 1920, 30
FONTS = {w: f"/home/claude/vid/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
def hx(s, a=1.0): s = s.lstrip("#"); return (int(s[0:2], 16) / 255, int(s[2:4], 16) / 255, int(s[4:6], 16) / 255, a)
NIGHT, NAVY, SKY, GOLD, RED = hx("#0B1426"), hx("#163261"), hx("#45A4DD"), hx("#FFCD50"), hx("#E5484D")
SAND, SAND_WB, GREEN, WHITE, MIST = hx("#C9A85C"), hx("#D9C285"), hx("#3FBF7F"), hx("#FFFFFF"), hx("#CBD3E3")
LANDN, EDGE = hx("#1A3A70"), hx("#2E5596")

# ------------------------------------------------------------------ geometry (world-atlas countries-10m = Natural Earth)
def _topo(path):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
NEAR = sbox(30.0, 27.0, 40.5, 35.8)
RAW = {k: v.intersection(NEAR) for k, v in _topo("/home/claude/goals_scorecard/geodata/countries-10m.json").items() if v.intersects(NEAR)}
_pal = list(RAW["Palestine"].geoms) if isinstance(RAW["Palestine"], MultiPolygon) else [RAW["Palestine"]]
GAZA = unary_union([p for p in _pal if p.centroid.x < 34.6])
WB = unary_union([p for p in _pal if p.centroid.x >= 34.6])
ISR = RAW["Israel"]
GL = RAW["Palestine"].boundary.intersection(ISR.buffer(0.004))
EGB = GAZA.boundary.intersection(RAW["Egypt"].buffer(0.006))
PHIL = EGB.buffer(0.022).intersection(GAZA)            # Gaza side strip (Philadelphi corridor, schematic)
OTHERS = {k: v for k, v in RAW.items() if k not in ("Israel", "Palestine")}
LV = {}
def lv(tol):
    if tol not in LV:
        LV[tol] = dict(isr=ISR.simplify(tol), wb=WB.simplify(tol), gaza=GAZA.simplify(tol / 2), gl=GL.simplify(tol),
                       oth={k: v.simplify(tol) for k, v in OTHERS.items()}, egb=EGB.simplify(tol / 3), phil=PHIL.simplify(tol / 3))
    return LV[tol]
def polys(g):
    if g.is_empty: return []
    return [g] if isinstance(g, Polygon) else [p for p in getattr(g, "geoms", []) if isinstance(p, Polygon)]
def lines(g):
    if g.is_empty: return []
    if isinstance(g, LineString): return [list(g.coords)]
    out = []
    for x in getattr(g, "geoms", []):
        if isinstance(x, LineString): out.append(list(x.coords))
        elif isinstance(x, MultiLineString): out += [list(y.coords) for y in x.geoms]
    return out

_egl = LineString(sorted([pt for ln in lines(EGB) for pt in ln], key=lambda q: -q[1]))
EG0, EG1 = _egl.coords[0], _egl.coords[-1]                  # coast end (NW), Kerem Shalom end (SE)
_rp = _egl.interpolate(0.62, normalized=True); RAFAH = (_rp.x, _rp.y)
class Cam:
    def __init__(s, lon, lat, span, cy=980):
        s.lon, s.lat, s.span = lon, lat, span; s.k = H / span; s.cos = math.cos(math.radians(lat)); s.cy = cy
    def P(s, lon, lat): return (W / 2 + (lon - s.lon) * s.cos * s.k, s.cy - (lat - s.lat) * s.k)
CAMS = {"wide": (35.05, 31.25, 4.9), "mid": (34.42, 31.33, 1.15), "close": (34.25, 31.26, 0.36)}
def cam_mix(a, b, u):
    return (a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, math.exp(math.log(a[2]) + (math.log(b[2]) - math.log(a[2])) * u))

def path(c, cam, g):
    for p in polys(g):
        xy = [cam.P(x, y) for x, y in p.exterior.coords]
        c.move_to(*xy[0])
        for q in xy[1:]: c.line_to(*q)
        c.close_path()
def stroke_lines(c, cam, g):
    for ln in lines(g):
        xy = [cam.P(x, y) for x, y in ln]; c.move_to(*xy[0])
        for q in xy[1:]: c.line_to(*q)

# ------------------------------------------------------------------ text (PIL -> cairo, cached)
_f, _ts = {}, {}
def font(sz, w): k = (int(sz), w); _f.setdefault(k, ImageFont.truetype(FONTS[w], int(sz))); return _f[k]
DASH = ("‒", "–", "—", "―")
def tsurf(s, sz, w=900, col=WHITE, shadow=True):
    k = (s, int(sz), w, col, shadow)
    if k in _ts: return _ts[k]
    assert not any(d in s for d in DASH), s
    f = font(sz, w); asc, desc = f.getmetrics(); pad = 18 if shadow else 4
    tw = f.getlength(s)
    im = Image.new("RGBA", (int(tw + 2 * pad + 2), int(asc + desc + 2 * pad)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if shadow:
        sh = Image.new("RGBA", im.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).text((pad, pad + 4), s, font=f, fill=(4, 10, 24, 200))
        from PIL import ImageFilter
        im = Image.alpha_composite(im, sh.filter(ImageFilter.GaussianBlur(7))); d = ImageDraw.Draw(im)
    d.text((pad, pad), s, font=f, fill=tuple(int(v * 255) for v in col))
    a = np.asarray(im).astype(np.float32); al = a[:, :, 3:4] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, :3] = (a[:, :, 2::-1] * al).astype(np.uint8); bgra[:, :, 3] = a[:, :, 3]
    h, w_ = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w_)
    buf = np.zeros((h, st), np.uint8); buf[:, :w_ * 4] = bgra.reshape(h, w_ * 4)
    surf = cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w_, h, st)
    _ts[k] = (surf, tw, pad, asc)
    return _ts[k]
def text(c, s, sz, x, y, w=900, col=WHITE, a=1.0, sc=1.0, anchor="c", shadow=True):
    """y = vertical centre of the cap height"""
    if a <= 0.01: return 0
    surf, tw, pad, asc = tsurf(s, sz, w, col, shadow)
    c.save(); c.translate(x, y); c.scale(sc, sc)
    ox = {"c": -tw / 2, "l": 0, "r": -tw}[anchor]
    c.set_source_surface(surf, ox - pad, -pad - asc * 0.62); c.paint_with_alpha(a); c.restore()
    return tw
def twidth(s, sz, w=900): return font(sz, w).getlength(s)
def wrap(s, sz, w, maxw):
    out, cur = [], ""
    for wd in s.split():
        t = (cur + " " + wd).strip()
        if cur and twidth(t, sz, w) > maxw: out.append(cur); cur = wd
        else: cur = t
    return out + ([cur] if cur else [])

def rrect(c, x, y, w, h, r):
    c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def src(c, rgba, a=1.0): c.set_source_rgba(rgba[0], rgba[1], rgba[2], rgba[3] * a)
def ease(u): u = min(1, max(0, u)); return u * u * (3 - 2 * u)
def eout(u): u = min(1, max(0, u)); return 1 - (1 - u) ** 3

# ------------------------------------------------------------------ fact cards (every fact sourced, source + year on screen)
def card_for(txt, key, song):
    t = txt.lower()
    if key.startswith("h") or key.startswith("o"): return None
    if "may 2024" in t:
        return dict(big="MAY 2024", label="Israel holds the Gaza side of Rafah", src="Reuters, 2024 and Feb 2026", col=SKY)
    if "president" in t or "sinai" in t:
        return dict(big="2023", label="Egypt's president: no moving Gazans into Sinai", src="Reuters, 18 Oct 2023")
    if "flooded" in t or "buffer" in t:
        lab = "Egypt flooded the smuggling tunnels with seawater" if "buffer" not in t else "Egypt flooded tunnels, cleared a buffer zone"
        return dict(big="2015", label=lab, src="Al Jazeera; Human Rights Watch, 2015")
    if "how many days" in t:
        return dict(big="? / 365", label="days open in 2015", src="Gaza crossings data via Times of Israel, 2016")
    if ("2015" in t and "21" in t) or t.strip("!. ") == "21":
        return dict(big="21 / 365", label="days open in 2015", src="Gaza crossings data via Times of Israel, 2016", count=21)
    if "2007" in t:
        return dict(big="2007", label="Since HAMAS took over: closed most days", src="NPR, 2023; UN OCHA crossings data")
    if t.strip("!. ") == "egypt" or "who kept it shut" in t:
        return dict(big="EGYPT", label="kept Rafah shut most days, 2007 to 2024", src="NPR, 2023; UN OCHA crossings data", col=RED)
    if "rafah crossing" in t or "the gate?" in t:
        return dict(big="RAFAH", label="The only Gaza crossing Israel didn't run, until 2024", src="NPR, 2023")
    if "12 km" in t or "how long" in t:
        return dict(big="12 km", label="Gaza's border with Egypt", src="NPR, 2023 (7.5 miles); Natural Earth")
    if "most days" in t:
        return dict(big="2007", label="Since HAMAS took over: closed most days", src="NPR, 2023; UN OCHA crossings data")
    if "south" in t or "further down" in t:
        return dict(big="12 km", label="Gaza's border with Egypt", src="NPR, 2023 (7.5 miles); Natural Earth")
    if "count with me" in t:
        return dict(big="2 borders", label="Gaza touches Israel, and Egypt", src="Map: Natural Earth", col=WHITE)
    if "prison" in t:
        return dict(big="PRISON?", label="Look at the whole map", src=None, col=WHITE)
    if "two gates" in t or "two borders" in t:
        return dict(big="2 gates", label="Israel's crossings, and Egypt's Rafah", src="Map: Natural Earth", col=WHITE)
    return "keep"

def cam_for(it):
    t = " ".join(w["w"] for w in it["dwords"]).lower(); k = it["key"]
    if k.startswith("h") or k.startswith("o"): return "mid"
    if "prison" in t or "two gates" in t or "two borders" in t or "count with me" in t: return "wide"
    if "south" in t or "map" in t: return "mid"
    return "close"

# ------------------------------------------------------------------ gate
def draw_gate(c, x, y, s, closed, lockpop, shake, flash, alpha=1.0):
    c.save(); c.translate(x + shake, y); c.scale(s, s)
    if flash > 0:
        r = 140 + 170 * (1 - flash)
        c.arc(0, -20, r, 0, 2 * math.pi); src(c, RED, 0.55 * flash); c.set_line_width(14); c.stroke()
    # shadow plate
    rrect(c, -165, -150, 330, 250, 26); src(c, NIGHT, 0.55 * alpha); c.fill()
    # doors (each hinged on its post, perspective squeeze while opening)
    for side in (-1, 1):
        sq = 0.18 + 0.82 * closed
        c.save(); c.translate(side * 132, 0); c.scale(-side * sq, 1)
        rrect(c, 0, -112, 128, 196, 8); src(c, NAVY, 0.92 * alpha); c.fill_preserve(); src(c, WHITE, alpha); c.set_line_width(6); c.stroke()
        for bx in (24, 50, 76, 102):
            c.move_to(bx, -106); c.line_to(bx, 78)
        c.move_to(4, -40); c.line_to(124, -40); c.move_to(4, 30); c.line_to(124, 30)
        src(c, WHITE, 0.85 * alpha); c.set_line_width(7); c.stroke(); c.restore()
    for side in (-1, 1):                                   # posts
        rrect(c, side * 150 - 18, -140, 36, 240, 10); src(c, WHITE, alpha); c.fill()
    rrect(c, -168, -150, 336, 30, 12); src(c, WHITE, alpha); c.fill()
    # padlock
    c.save(); c.translate(0, 0); k = 1 + 0.22 * lockpop; c.scale(k, k)
    c.arc(0, -36, 24, math.pi, 2 * math.pi); c.set_line_width(12); src(c, RED, alpha); c.stroke()
    c.move_to(-24, -36); c.line_to(-24, -22); c.move_to(24, -36); c.line_to(24, -22); c.stroke()
    rrect(c, -40, -26, 80, 64, 12); src(c, RED, alpha); c.fill()
    c.arc(0, 0, 8, 0, 2 * math.pi); src(c, NIGHT, alpha); c.fill(); c.rectangle(-3.5, 2, 7, 18); c.fill()
    c.restore(); c.restore()

# ------------------------------------------------------------------ main
def main():
    sid = sys.argv[1]; wd = os.path.join(HERE, "work", sid)
    tl = json.load(open(os.path.join(wd, "timeline.json")))
    items, beat, D = tl["items"], tl["beat"], tl["dur"]
    hook_lines = wrap(tl["hook_screen"], 112, 900, 900)
    # per-item card + camera
    cur = None
    for it in items:
        txt = " ".join(w["w"] for w in it["dwords"])
        cd = card_for(txt, it["key"], tl)
        if cd == "keep": cd = cur
        if it["key"][0] in "ho": cd = None
        it["card"] = cd; cur = cd if cd else cur
        if it["key"][0] in "ho": cur = None
        it["cam"] = cam_for(it)
        it["end"] = it["t"] + it["beats"] * beat
    for j, it in enumerate(items):
        it["card_t0"] = it["t"] if (j == 0 or items[j - 1].get("card") != it["card"]) else items[j - 1]["card_t0"]
    fair_t = min([it["t"] for it in items if it["key"] == "f1"] or [1e9])
    fair_end = min([it["t"] for it in items if it["t"] > fair_t and it["key"][0] == "h"] or [D])
    km_items = [(it["t"], it["end"]) for it in items if "12 km" in " ".join(w["w"] for w in it["dwords"]) or (it.get("card") or {}).get("big") == "12 km"]
    slams = tl["slams"]
    hooks = [(it["t"], it["end"]) for it in items if it["key"][0] in "h"]

    def item_at(t):
        for j, it in enumerate(items):
            nxt = items[j + 1]["t"] if j + 1 < len(items) else D + 1
            if it["t"] - 0.12 <= t < nxt - 0.12: return j, it
        return 0, items[0]

    def frame(t):
        surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
        j, it = item_at(t)
        # camera
        prev = items[j - 1]["cam"] if j > 0 else items[-1]["cam"]
        u = ease((t - (it["t"] - 0.15)) / 0.9)
        cm = cam_mix(CAMS[prev], CAMS[it["cam"]], u)
        bp = (t - tl["lead"]) / beat; ph = bp - math.floor(bp)
        pulse = math.exp(-ph * 5) if bp >= 0 else 0
        cam = Cam(cm[0], cm[1], cm[2] / (1 + 0.006 * pulse), cy=1040)
        tol = max(0.0004, cm[2] / 1500); L = lv(round(tol, 4))
        # sea
        g = cairo.RadialGradient(W / 2, 900, 100, W / 2, 900, 1300); g.add_color_stop_rgba(0, 0.075, 0.13, 0.24, 1); g.add_color_stop_rgba(1, *NIGHT[:3], 1)
        c.set_source(g); c.paint()
        # neighbours
        c.set_line_join(cairo.LINE_JOIN_ROUND)
        for k, gm in L["oth"].items():
            path(c, cam, gm); src(c, LANDN); c.fill_preserve(); src(c, EDGE); c.set_line_width(2.5); c.stroke()
        path(c, cam, L["isr"]); src(c, SKY); c.fill()
        path(c, cam, L["wb"]); src(c, SAND_WB); c.fill()
        path(c, cam, L["gaza"]); src(c, SAND); c.fill()
        stroke_lines(c, cam, L["gl"]); src(c, GREEN); c.set_line_width(6); c.stroke()
        # Philadelphi strip (Israel on the Gaza side since May 2024)
        fa = ease((t - fair_t) / 0.5) * (1 - ease((t - fair_end + 0.4) / 0.4))
        if fa > 0.01:
            path(c, cam, L["phil"]); src(c, SKY, 0.95 * fa); c.fill_preserve(); src(c, WHITE, fa); c.set_line_width(3); c.stroke()
            lx, ly = cam.P(EG1[0] + 0.012, EG1[1] + 0.006)
            if cm[2] < 0.6:
                lw_ = twidth("Israel since May 2024", 40, 800) + 44
                lx = min(W - 60 - lw_, lx); ly = min(1240, ly)
                rrect(c, lx - 10, ly - 30, lw_, 60, 30); src(c, SKY, fa); c.fill_preserve(); src(c, WHITE, fa); c.set_line_width(3); c.stroke()
                text(c, "Israel since May 2024", 40, lx - 10 + lw_ / 2, ly, 800, NIGHT, fa, shadow=False)
        # the Gaza / Egypt border: red, glowing
        for lw, a in ((26, 0.25), (14, 0.5), (8, 1.0)):
            stroke_lines(c, cam, L["egb"]); src(c, RED, a); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
        # 12 km dimension line
        for a0, a1 in km_items:
            ka = ease((t - a0) / 0.4) * (1 - ease((t - a1 + 0.1) / 0.35))
            if ka > 0.01:
                p0, p1 = cam.P(*EG0), cam.P(*EG1)
                dx, dy = p1[0] - p0[0], p1[1] - p0[1]; n = math.hypot(dx, dy); ox, oy = -dy / n * 200, dx / n * 200
                grow = eout((t - a0) / 0.6)
                q0 = (p0[0] + ox, p0[1] + oy); q1 = (q0[0] + dx * grow, q0[1] + dy * grow)
                c.move_to(*q0); c.line_to(*q1); src(c, GOLD, ka); c.set_line_width(8); c.stroke()
                for q in (q0, q1):
                    c.move_to(q[0] - oy / 4, q[1] + ox / 4); c.line_to(q[0] + oy / 4, q[1] - ox / 4); c.stroke()
                mx, my = q0[0] + dx * 0.5 * grow + ox * 0.45, q0[1] + dy * 0.5 * grow + oy * 0.45
                mx = min(W - 140, max(140, mx)); my = min(1230, max(820, my))
                rrect(c, mx - 120, my - 50, 240, 100, 50); src(c, GOLD, ka); c.fill()
                text(c, "12 km", 72, mx, my, 900, NIGHT, ka, shadow=False)
        # map labels
        lab = [("ISRAEL", 34.92, 31.0, 64, WHITE), ("EGYPT", 33.85, 30.75, 64, MIST), ("GAZA", 34.43, 31.47, 56, NIGHT),
               ("SINAI", 33.95, 30.25, 48, MIST), ("WEST BANK", 35.25, 31.95, 44, NIGHT), ("JORDAN", 36.2, 31.0, 52, MIST),
               ("MEDITERRANEAN", 34.1, 32.3, 40, MIST)]
        for s, lo, la, sz, col in lab:
            x, y = cam.P(lo, la)
            if s == "GAZA" and cm[2] < 0.5: x, y = cam.P(34.33, 31.36)
            if s == "GAZA" and cm[2] > 0.9: continue
            if s in ("WEST BANK", "JORDAN", "SINAI", "MEDITERRANEAN") and cm[2] < 0.8: continue
            if 80 < x < W - 80 and 760 < y < 1240 or (s in ("ISRAEL", "EGYPT", "GAZA") and 80 < x < W - 80 and 740 < y < 1260):
                text(c, s, sz, x, y, 900, col, 0.92, shadow=col != NIGHT)
        # gate
        gx, gy = cam.P(*RAFAH)
        gs = 0.5 + 0.3 * min(1, max(0, (2.0 - cm[2]) / 1.7))
        gx = min(W - 190 * gs, max(190 * gs, gx)); gy = min(1150, max(1000, gy))
        closed, shake, flash = 1.0, 0.0, 0.0
        for st_ in slams:
            d = t - st_
            if -0.25 < d < 0:
                closed = 0.35 + 0.65 * (1 - ease(-d / 0.25)) if st_ > 0 else closed
            if 0 <= d < 0.6:
                shake += 16 * math.sin(d * 70) * math.exp(-d / 0.12); flash = max(flash, 1 - d / 0.45)
        if t < 0.1: closed = 0.55 + 0.45 * ease(t / 0.1)
        inhook = any(a <= t < b for a, b in hooks)
        lockpop = pulse if inhook else 0.25 * pulse
        draw_gate(c, gx, gy, gs, closed, lockpop, shake, max(0, flash))
        text(c, "RAFAH", 46, gx, gy - 182 * gs - 30, 900, GOLD, 1.0)
        # top: chip
        chip = tl["chip"]; cw = twidth(chip, 40, 800) + 60
        rrect(c, W / 2 - cw / 2, 268, cw, 64, 32); src(c, SKY, 0.95); c.fill()
        text(c, chip, 40, W / 2, 300, 800, NIGHT, 1.0, shadow=False)
        # top: hook text or fact card
        cd = it.get("card")
        if cd is None:
            hy = 420; n = len(hook_lines)
            rrect(c, 60, 352, W - 120, 70 + 128 * n, 36); src(c, NIGHT, 0.78); c.fill()
            for k, ln in enumerate(hook_lines):
                col = WHITE if k == 0 else GOLD
                text(c, ln, 112, W / 2, hy + 128 * k + 20, 900, col, 1.0, sc=1 + 0.015 * pulse)
        else:
            u = eout((t - it["card_t0"] + 0.12) / 0.35)
            labl = wrap(cd["label"], 60, 800, 880)
            hh = 200 + 70 * len(labl) + (90 if cd.get("src") else 0)
            c.save(); c.translate(0, -30 * (1 - u))
            rrect(c, 60, 352, W - 120, hh, 36); src(c, NIGHT, 0.82 * u); c.fill()
            big = cd["big"]
            if cd.get("count"):
                n = int(round(cd["count"] * eout((t - it["t"]) / 0.9)))
                big = f"{n} / 365"
            text(c, big, 150, W / 2, 470, 900, cd.get("col", GOLD), u)
            for k, ln in enumerate(labl):
                text(c, ln, 60, W / 2, 590 + 70 * k, 800, WHITE, u)
            if cd.get("src"):
                text(c, cd["src"], 38, W / 2, 590 + 70 * len(labl) + 30, 400, MIST, u, shadow=False)
            c.restore()
        # karaoke panel
        words = it["dwords"]; sz = 82
        lns = []
        while True:
            lns, cur_, wcur = [], [], 0
            for wi, w in enumerate(words):
                ww = twidth(w["w"], sz)
                if cur_ and wcur + 28 + ww > 920: lns.append(cur_); cur_, wcur = [], 0
                cur_.append(wi); wcur += (28 if wcur else 0) + ww
            lns.append(cur_)
            if len(lns) <= 2 or sz <= 64: break
            sz -= 6
        py0, ph_ = 1300, 250
        rrect(c, 50, py0, W - 100, ph_, 40); src(c, NIGHT, 0.86); c.fill_preserve(); src(c, SKY, 0.9); c.set_line_width(4); c.stroke()
        if inhook or it["key"][0] in "o":
            lw_ = twidth("SING ALONG", 38, 800) + 50
            rrect(c, W / 2 - lw_ / 2, py0 - 26, lw_, 52, 26); src(c, GOLD); c.fill()
            text(c, "SING ALONG", 38, W / 2, py0, 800, NIGHT, shadow=False)
        lh = sz * 1.18; y0 = py0 + ph_ / 2 - (len(lns) - 1) * lh / 2 + 4
        for li, ln in enumerate(lns):
            tw = sum(twidth(words[wi]["w"], sz) for wi in ln) + 28 * (len(ln) - 1)
            x = W / 2 - tw / 2
            for wi in ln:
                w = words[wi]; ww = twidth(w["w"], sz)
                if t >= w["e"]: col, a, sc = WHITE, 1.0, 1.0
                elif t >= w["s"] - 0.03:
                    col, a = GOLD, 1.0; sc = 1 + 0.08 * math.exp(-max(0, t - w["s"]) / 0.13)
                else: col, a, sc = WHITE, 0.42, 1.0
                text(c, w["w"], sz, x + ww / 2, y0 + li * lh - (8 * (sc - 1) / 0.08 if sc > 1 else 0), 900, col, a, sc=sc)
                x += ww + 28
        return surf

    if len(sys.argv) > 3 and sys.argv[2] == "--still":
        for ts in sys.argv[3].split(","):
            frame(float(ts)).write_to_png(os.path.join(wd, f"still_{float(ts):05.1f}.png"))
        return
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(wd, f"{sid}.mp4")
    nf = int(round(D * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
                          "-i", "pipe:0", "-i", os.path.join(wd, "mix.wav"), "-map", "0:v", "-map", "1:a",
                          "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                          "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", out], stdin=subprocess.PIPE)
    for i in range(nf):
        p.stdin.write(bytes(frame(i / FPS).get_data()))
        if i % 300 == 0: print(f"{sid} frame {i}/{nf}", flush=True)
    p.stdin.close(); p.wait()
    print("wrote", out)


if __name__ == "__main__":
    main()
