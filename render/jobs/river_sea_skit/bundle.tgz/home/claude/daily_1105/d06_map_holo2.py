# -*- coding: utf-8 -*-
"""holocaust_israel_v2: evidence chain. Each beat is "built BEFORE the Holocaust" (green check + icon), then the Holocaust as what it
did (urgency), 1947, 1948, the reveal, the balance card and the loop lead-in. Same engine as d05_map_holo.py: globe opener (first 2.4 s
come from map_open.py), year counter, Jews-in-the-land counter, map with pins.
usage: python3 d06_map_holo2.py [--snaps=t,t,...] [--endimg=PNG]"""
import sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, "/home/claude/daily_1105")
import d05_ck
from d05_ck import *
rid = "holocaust_israel_v2"; T = Timing(rid); DUR = round(T.dur + 0.9, 2); OFF = 2.4
F = features()
EMO = {}
def emoji(ch, px):
    k = (ch, px)
    if k not in EMO:
        f = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf", 109)
        im = Image.new("RGBA", (136, 128), (0, 0, 0, 0)); ImageDraw.Draw(im).text((0, 0), ch, font=f, embedded_color=True)
        im = im.crop(im.getbbox()); s = px / max(im.size); EMO[k] = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    return EMO[k]
def at(m): return T.at(m)
# ------------------------------------------------------------------ beats (card start time, year, title, icon, kind, pin, source)
BL = "built"
BEATS = [
 dict(t=at("3"), yr=-1000, title="3,000 years of Jewish roots here", ic="\U0001F4DC", k=BL, pin=None, src="Source: Britannica, AJC (King David, about 1000 BCE)", ytxt="1000 BCE"),
 dict(t=at("4:Eighteen eighty"), yr=1882, title="First wave of Jewish immigrants", ic="\U0001F6A2", k=BL, pin=None, src="Source: Jewish Virtual Library (First Aliyah 1882 to 1903)"),
 dict(t=at("4:Eighteen ninety"), yr=1897, title="First Zionist Congress, Basel", ic="\U0001F3DB", k=BL, pin=None, src="Source: Jewish Virtual Library (First Zionist Congress, 29 Aug 1897)"),
 dict(t=at("5:Nineteen oh"), yr=1909, title="Tel Aviv founded", ic="\U0001F3D8", k=BL, pin="TLV", src="Source: Tel Aviv-Yafo Municipality (11 April 1909)"),
 dict(t=at("5:Nineteen seventeen"), yr=1917, title="Balfour Declaration backs a Jewish home", ic="✉️", k=BL, pin=None, src="Source: Balfour Declaration, 2 Nov 1917 (Yale Avalon Project)"),
 dict(t=at("6:Nineteen twenty"), yr=1920, title="", ic="", k=BL, pin=None, src="Source: Jewish Virtual Library (Haganah, Histadrut, Assembly, 1920)",
      rows=[(at("6:A defense"), "\U0001F6E1", "Defense force", None), (at("6:a workers"), "\U0001F528", "Workers' union", "HFA"), (at("6:an elected"), "\U0001F5F3", "Elected assembly", None)]),
 dict(t=at("7:Nineteen twenty"), yr=1922, title="League of Nations backs the Jewish link", ic="⚖️", k=BL, pin=None, src="Source: Mandate for Palestine, 24 July 1922 (preamble)"),
 dict(t=at("8:Nineteen twenty five"), yr=1925, title="Hebrew University opens", ic="\U0001F393", k=BL, pin="JLM", src="Source: Hebrew University of Jerusalem (opened 1 April 1925)"),
 dict(t=at("8:Nineteen twenty nine"), yr=1929, title="Jewish Agency formed", ic="\U0001F3E2", k=BL, pin=None, src="Source: Jewish Virtual Library (Jewish Agency, August 1929)"),
 dict(t=at("9"), yr=1939, title="449,000 Jews, with their own schools", ic="\U0001F3EB", k=BL, pin=None, src="Source: Jewish Virtual Library (population table, 1939)"),
 dict(t=at("10"), yr=1941, title="6 million Jews murdered", ic="\U0001F56F", k="holo", pin=None, src="Source: US Holocaust Memorial Museum", y2=1945),
 dict(t=at("11"), yr=1945, title="250,000+ survivors still in camps", ic="⛺", k="after", pin=None, src="Source: US Holocaust Memorial Museum (Jewish displaced persons)"),
 dict(t=at("12:Nineteen forty seven"), yr=1947, title="UN votes to divide the land", ic="\U0001F310", k="after", pin=None, src="Source: UN General Assembly Resolution 181, 29 Nov 1947 (33 to 13)"),
 dict(t=at("12:Nineteen forty eight"), yr=1948, title="Israel declares independence", ic="\U0001F1EE\U0001F1F1", k="after", pin=None, src="Source: Israel State Archives (14 May 1948)"),
]
for b in BEATS: b.setdefault("ky", b["t"])
nB = len(BEATS)
for i, b in enumerate(BEATS): b["end"] = BEATS[i + 1]["t"] if i + 1 < nB else at("13")
T_REV = at("13"); T_BAL = at("14"); T_LEAD = at("15"); T_END = T_LEAD
N_BUILT = sum(len(b["rows"]) if b.get("rows") else 1 for b in BEATS if b["k"] == BL)
# year keyframes
YK = [(b["ky"], b["yr"]) for b in BEATS] + [(T_BAL, 1948)]
Y_RAMP = {0: None, 1: None}
def year_at(t):
    if t < YK[0][0]: return -1000
    for i in range(len(YK) - 1):
        a, ya = YK[i]; b, yb = YK[i + 1]
        if a <= t < b:
            if i == 0: ramp = (b - a) * 0.95          # 1000 BCE ticks up to 1882 across the 3,000 years line
            elif BEATS[i]["k"] == "holo": return ya + (BEATS[i]["y2"] - ya) * ease((t - a) / max(0.5, at("10$") - a))
            else: ramp = min(0.55, b - a)
            u = (t - (b - ramp)) / ramp
            return ya + (yb - ya) * ease(u) if u > 0 else ya
    return YK[-1][1]
def ylabel(y):
    y = int(round(y))
    if y <= 0: return f"{abs(y) if y else 1} BCE"
    return str(y)
# population (Jews in the land): step anchors, JVL table (British Mandate censuses, Israel CBS, Rabinovich and Reinharz 2008)
def BY(y, k=None): return next(b for b in BEATS if b["yr"] == y and (k is None or b["k"] == k))
LS = [(BY(1882)["t"], 24000), (BY(1922)["t"], 83794), (BY(1939)["t"], 449000), (BY(1947)["t"], 630000)]
ANCH = [24000, 83794, 449000, 630000]
def land_val(t):
    if t < LS[0][0]: return None
    v = LS[0][1]; prev = LS[0][1]
    for i, (ts, val) in enumerate(LS):
        if t >= ts:
            u = min(1.0, (t - ts) / 0.8); prev = LS[i - 1][1] if i else val; v = prev + (val - prev) * ease(u)
    return v
def pop_str(v):
    near = [x for x in ANCH if abs(v - x) < 60]
    return f"{near[0]:,}" if near else f"{int(round(v / 100.0) * 100):,}"
T_H0, T_H1 = BY(1941)["t"], BY(1947)["t"]
def hol_val(t): return 6000000 * ease((t - T_H0) / max(1.0, at("10$") - T_H0 + 0.2))
PIN = {"TLV": dict(lo=34.78, la=32.08, lab="1909 Tel Aviv", side="l"),
       "HFA": dict(lo=34.99, la=32.79, lab="1920 Haifa", side="l"),
       "JLM": dict(lo=35.23, la=31.78, lab="1925 Jerusalem", side="r")}
PT = {b["pin"]: b["t"] for b in BEATS if b["pin"]}
for b in BEATS:
    for (rt, _i, _x, rp) in b.get("rows", []):
        if rp: PT[rp] = rt
EV = []   # (time, kind, pin) of every card or row
for b in BEATS:
    if b.get("rows"): EV += [(rt, b["k"], rp) for (rt, _i, _x, rp) in b["rows"]]
    else: EV.append((b["t"], b["k"], b["pin"]))
BUILT_T = sorted(e[0] for e in EV if e[1] == BL)
# ------------------------------------------------------------------ map
MR = (0, 570, W, 960); P = Proj((33.3, 29.3, 37.0, 33.6), MR, lat0=31.5)
LAND = hx("#26385C"); SEA = (12, 24, 52)
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
compR(base, M["ISR"], ISRAEL_GOLD, 1.0); compR(base, M["PSX"], PAL_GOLD, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
SUBS = sub_chunks(T, [("Eighteen eighty two", "1882"), ("Eighteen ninety seven", "1897"), ("Nineteen oh nine", "1909"), ("Nineteen seventeen", "1917"),
                      ("Nineteen twenty two", "1922"), ("Nineteen twenty five", "1925"), ("Nineteen twenty nine", "1929"), ("Nineteen twenty", "1920"),
                      ("Nineteen thirty nine", "1939"), ("Nineteen forty one", "1941"), ("nineteen forty five", "1945"), ("Nineteen forty seven", "1947"),
                      ("nineteen forty seven", "1947"), ("Nineteen forty eight", "1948"), ("Four hundred forty nine thousand", "449,000"),
                      ("Two hundred fifty thousand", "250,000"), ("Three thousand", "3,000"), ("Six million", "6 million"), ("two states", "2 states")])
endimg = next((a[9:] for a in sys.argv[1:] if a.startswith("--endimg=")), None)
out = Out(rid, DUR, snaps_arg(), off=OFF, endimg=endimg)
GREEN_D = (47, 191, 113, 255)
def check_badge(ld, cx, cy, r, a, sc=1.0):
    r = r * sc
    ld.ellipse([cx - r, cy - r, cx + r, cy + r], fill=GREEN[:3] + (int(255 * a),), outline=(255, 255, 255, int(255 * a)), width=5)
    ld.line([(cx - r * .45, cy + r * .02), (cx - r * .1, cy + r * .38), (cx + r * .5, cy - r * .36)], fill=(255, 255, 255, int(255 * a)), width=max(6, int(r * .26)), joint="curve")
def rrp(ld, box, rad, fill, outline, w, a):
    ld.rounded_rectangle(box, rad, fill=fill[:3] + (int(fill[3] * a),), outline=outline[:3] + (int(255 * a),), width=w)
def beat_at(t):
    cur = None
    for b in BEATS:
        if b["t"] <= t: cur = b
    return cur
def n_built(t): return sum(1 for x in BUILT_T if x <= t)
def ease_back(u): u = max(0, min(1, u)); return 1 + 2.4 * (u - 1) ** 3 + 1.4 * (u - 1) ** 2
for f, t in out.frames():
    im = stage(); arr = BASE.copy()
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    # pins
    for k, p in PIN.items():
        if k not in PT or t < PT[k]: continue
        x, y = P(p["lo"], p["la"]); u = (t - PT[k]) / 0.45; pop = math.sin(math.pi * min(1, u)) if u < 1 else 0
        r = 14 * (1 + 0.8 * pop)
        ld.ellipse([x - r - 8, y - r - 8, x + r + 8, y + r + 8], fill=WHITE[:3] + (70,)); ld.ellipse([x - r, y - r, x + r, y + r], fill=YEL, outline=(8, 18, 40, 255), width=4)
        if p["side"] == "l": txt(ld, x - 28, y - 6, p["lab"], 40, WHITE, 800, "rm", stroke=4)
        else: txt(ld, x + 30, y + 4, p["lab"], 40, WHITE, 800, "lm", stroke=4)
    # pulse ring at each beat (at its pin, else the middle of the land)
    for (et, ek, pk) in EV:
        u = (t - et) / 0.9
        if 0 <= u <= 1 and ek != "holo":
            lo, la = (PIN[pk]["lo"], PIN[pk]["la"]) if pk else (35.0, 31.5)
            x, y = P(lo, la); rr_ = 20 + 110 * ease(u); colr = GREEN if ek == BL else SKY
            ld.ellipse([x - rr_, y - rr_, x + rr_, y + rr_], outline=colr[:3] + (int(230 * (1 - u)),), width=6)
    im.alpha_composite(lay); d = ImageDraw.Draw(im)
    yh = hook(d, ["Did the Holocaust", "create Israel?"], t, sz=112)
    # ---- chain row
    nb = n_built(t)
    if t < BEATS[0]["t"]:
        txt(d, W / 2, yh + 6, "Let's check what existed first.", 56, WHITE, 800, "ma")
        sc_pre = True
    else:
        if t < T_H0 or t >= T_REV: lab, lc = "Before 1941", WHITE
        else: lab, lc = "Before 1941", WHITE
        if t >= T_H0: lab = "Built before 1941"
        txt(d, 46, yh + 6, lab, 52 if t < T_H0 else 46, lc, 800, "la")
        x0 = 590 if t < T_H0 else 560; step = (1034 - x0) / N_BUILT
        for i in range(N_BUILT):
            cx = x0 + step * (i + 0.5); cy = yh + 36
            if i < nb:
                bt = BUILT_T[i]; u = (t - bt) / 0.3; sc = ease_back(u) if u < 1 else 1.0
                check_badge(d, cx, cy, 20, 1.0, sc)
            else: d.ellipse([cx - 17, cy - 17, cx + 17, cy + 17], outline=(120, 140, 175, 255), width=4)
    # ---- beat card
    cb = beat_at(t)
    cb0 = cb
    if cb is None and t >= OFF and t < BEATS[0]["t"]:
        u = ease((t - OFF) / 0.3); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        rrp(ld, [40, 975, 1040, 1245], 30, (8, 20, 46, 240), SKY, 5, u)
        ic = emoji("\U0001F50E", 150); lay.alpha_composite(ic, (int(165 - ic.width / 2), int(1110 - ic.height / 2)))
        txt(ld, 290, 987, "Before 1941", 92, YEL, 900, "la", u); txt(ld, 290, 1087, "What already existed?", 64, WHITE, 800, "la", u)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    if cb is not None and t < T_REV:
        u = ease((t - cb["t"]) / 0.28); a = u; dy = int((1 - u) * 40)
        col = {BL: GREEN, "holo": RED, "after": SKY}[cb["k"]]
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        y0 = 975 + dy
        rrp(ld, [40, y0, 1040, y0 + 270], 30, (8, 20, 46, 240), col, 5, a)
        ys = cb.get("ytxt") or str(cb["yr"])
        if cb.get("rows"):
            txt(ld, 70, y0 + 135, ys, 88, YEL, 900, "lm", a)
            for i, (rt, ric, rtx, _rp) in enumerate(cb["rows"]):
                ra = ease((t - rt) / 0.25)
                if ra <= 0: continue
                ry = y0 + 14 + 84 * i + 42 + int((1 - ra) * 14)
                e_ = emoji(ric, 64); lay.alpha_composite(e_, (int(372 - e_.width / 2), int(ry - e_.height / 2)))
                txt(ld, 420, ry, rtx, 64, WHITE, 800, "lm", ra * a)
                check_badge(ld, 1000, ry, 27, ra * a, ease_back((t - rt - 0.05) / 0.3) if t - rt > 0.05 else 0.0)
            im.alpha_composite(lay); d = ImageDraw.Draw(im); cb = None
        if cb is not None: ic = emoji(cb["ic"], 150); lay.alpha_composite(ic, (int(165 - ic.width / 2), int(y0 + 135 - ic.height / 2)))
        if cb is not None and cb["k"] == "holo": ys = "1941 to 1945"
        tx = 290; maxw = 1010 - tx
        if cb is not None:
            txt(ld, tx, y0 + 12, ys, 92, YEL if cb["k"] != "holo" else RED, 900, "la", a)
            lines = wrap(cb["title"], 64, maxw, 800)[:2]
            for i, l in enumerate(lines): txt(ld, tx, y0 + 112 + 72 * i, l, 64, WHITE, 800, "la", a)
            if cb["k"] == BL: check_badge(ld, 76, y0 + 6, 34, a, ease_back((t - cb["t"] - 0.12) / 0.3) if t - cb["t"] > 0.12 else 0.0)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    # ---- counters
    YY = 1262; yr = year_at(t)
    txt(d, 46, YY, "Year", 40, SILVER, 700, "la"); txt(d, 46, YY + 40, ylabel(yr), 112, YEL if T_REV <= t < T_BAL else WHITE, 900, "la")
    if T_H0 <= t < T_H1:
        txt(d, 1034, YY, "Jews murdered", 40, RED, 700, "ra"); txt(d, 1034, YY + 40, f"{int(round(hol_val(t) / 10000.0) * 10000):,}" if hol_val(t) < 5999000 else "6,000,000", 112, RED, 900, "ra")
    else:
        txt(d, 1034, YY, "Jews in the land", 40, SILVER, 700, "ra")
        v = land_val(t); ps = "?" if v is None else pop_str(v)
        txt(d, 1034, YY + 40, ps, 112, GREEN if (v or 0) >= 449000 else WHITE, 900, "ra")
    # ---- reveal + balance panels
    if T_REV <= t < T_BAL + 0.01:
        a = min(1, (t - T_REV) / 0.3) * (1 - min(1, max(0, (t - T_BAL + 0.0) / 0.01)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            rrp(ld, [40, 580, 1040, 1245], 30, (8, 20, 46, 248), GOLD, 4, a)
            txt(ld, W / 2, 605, "So, no.", 150, YEL, 900, "ma", a)
            for i, l in enumerate(["The Holocaust did not", "create Israel."]): txt(ld, W / 2, 775 + 98 * i, l, 92, WHITE, 800, "ma", a)
            if t >= at("13:It proved"):
                a2 = min(1, (t - at("13:It proved")) / 0.3)
                for i, l in enumerate(["It proved why", "Israel was needed."]): txt(ld, W / 2, 1015 + 98 * i, l, 92, YEL, 900, "ma", a * a2)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    if T_BAL <= t < T_END + 0.4:
        a = min(1, (t - T_BAL) / 0.3) * (1 - min(1, max(0, (t - T_END) / 0.4)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            rrp(ld, [40, 580, 1040, 1245], 30, (8, 20, 46, 248), GOLD, 4, a)
            txt(ld, W / 2, 600, "Not perfect either", 86, GOLD, 900, "ma", a)
            txt(ld, W / 2, 740, "1947: Jews were about a third", 70, WHITE, 800, "ma", a)
            txt(ld, W / 2, 850, "630,000 of 1,970,000 people.", 70, WHITE, 800, "ma", a)
            txt(ld, W / 2, 990, "The UN proposed two states.", 70, YEL, 800, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    # ---- source label
    sc_ = "Sources: JVL (British Mandate censuses), UN Res. 181"
    if t < T_REV and cb0 is not None: sc_ = cb0["src"]
    elif t < T_BAL: sc_ = "Sources: see caption"
    elif t < T_LEAD: sc_ = "Source: Jewish Virtual Library (32% in 1947), UN Res. 181"
    else: sc_ = "Sources in the caption"
    source(d, sc_)
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
