"""finalize.py id ...: after the cloud render, for each reel: check reels-drop/<id>.mp4 (duration, audio), raw URL 200,
write /home/claude/posting/queue/gh/<id>.json, make a 4-frame QA strip, and report the preview path/size."""
import json, os, subprocess, sys
sys.path.insert(0, "/home/claude/daily_1105")
R = []
REPO = "/home/claude/reels-drop"; Q = "/home/claude/posting/queue/gh"; SC = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/qa"
os.makedirs(SC, exist_ok=True)
byid = {r["id"]: r for r in R}
ACC = {"holocaust_israel": "noam", "best_english_mena": "express"}
for _i in ACC: byid[_i] = dict(id=_i, caption=open(f"/home/claude/daily_1105/captions/{_i}.txt").read())
for rid in sys.argv[1:]:
    r = byid[rid]; mp4 = f"{REPO}/{rid}.mp4"; prev = f"{REPO}/render/out/{rid}_540.mp4"
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height", "-of", "json", mp4], capture_output=True, text=True).stdout)
    dur = float(pr["format"]["duration"]); kinds = [s["codec_type"] for s in pr["streams"]]
    url = f"https://raw.githubusercontent.com/avinoamroz/reels-drop/main/{rid}.mp4"
    code = subprocess.run(["curl", "-s", "-o", "/dev/null", "-I", "-w", "%{http_code}", url], capture_output=True, text=True).stdout
    vol = subprocess.run(["ffmpeg", "-hide_banner", "-i", mp4, "-af", "volumedetect", "-f", "null", "-"], capture_output=True, text=True).stderr
    mean = [l for l in vol.splitlines() if "mean_volume" in l]
    body = {"media_type": "REELS", "video_url": url, "caption": r["caption"], "share_to_feed": True, "is_ai_generated": True,
            "trial_params": {"graduation_strategy": "SS_PERFORMANCE"}}
    json.dump({"action": "init", "account": ACC[rid], "tag": f"{rid}-gh", "body": json.dumps(body, ensure_ascii=False)}, open(f"{Q}/{rid}.json", "w"), ensure_ascii=False, indent=1)
    ts = [0.0, 1.0, 3.0, dur * 0.8, dur - 0.1]
    for k, t in enumerate(ts):
        subprocess.run(["nice", "-n", "10", "ffmpeg", "-y", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", mp4, "-frames:v", "1", "-vf", "scale=270:-1", f"{SC}/{rid}_{k}.png"])
    subprocess.run(["nice", "-n", "10", "ffmpeg", "-y", "-loglevel", "error"] + sum([["-i", f"{SC}/{rid}_{k}.png"] for k in range(5)], []) + ["-filter_complex", "hstack=5", f"{SC}/{rid}_strip.png"])
    for k in range(5): os.remove(f"{SC}/{rid}_{k}.png")
    ps = os.path.getsize(prev) if os.path.exists(prev) else -1
    print(f"{rid}: {dur:.1f}s streams={kinds} {mean[0].split(':')[-1].strip() if mean else 'NO AUDIO'} url={code} preview={ps/1e6:.2f}MB")
