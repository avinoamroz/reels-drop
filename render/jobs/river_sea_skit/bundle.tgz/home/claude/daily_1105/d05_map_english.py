# -*- coding: utf-8 -*-
"""happiest_mena: Who's happiest in the Middle East? Map + world-rank countdown, World Happiness Report 2026.
Frames before OFF (2.4 s) come from the map_open.py opener (globe_spin_whip, zooming into this exact map view).
usage: d05_map_happy.py [--snaps=..]"""
import sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/daily_1105")
from d05_ck import *
rid = "best_english_mena"; T = Timing(rid); DUR = round(T.dur + 0.9, 2); OFF = 2.4
F = features()
def wt(L, word, nth=1):
    n = 0
    for w in T.lines[L - 1]["words"]:
        if T.norm(w["w"]) == T.norm(word):
            n += 1
            if n == nth: return w["t0"] - 0.05
    raise KeyError((L, word))
# EF English Proficiency Index 2025 (rank of 123, score 0 to 800)
D = {"YEM": (116, 402), "SAU": (115, 404), "IRQ": (113, 406), "OMN": (112, 407), "JOR": (105, 426), "KWT": (93, 455), "SYR": (91, 456),
     "EGY": (89, 459), "PSX": (87, 463), "QAT": (81, 469), "LBN": (78, 477), "ARE": (72, 487), "TUR": (71, 488), "IRN": (68, 492), "ISR": (46, 524)}
NODATA = ["BHR"]
REV = {"YEM": wt(3, "Yemen"), "SAU": wt(3, "Saudi"), "IRQ": wt(4, "Iraq"), "OMN": wt(4, "Oman"), "JOR": T.at(5), "KWT": wt(6, "Kuwait"), "SYR": wt(6, "Syria"),
       "EGY": wt(7, "Egypt"), "PSX": wt(7, "Palestinians"), "QAT": wt(8, "Qatar"), "LBN": wt(8, "Lebanon"), "ARE": wt(9, "Emirates"), "TUR": wt(9, "Turkey"),
       "IRN": wt(10, "Iran"), "ISR": T.at(12)}
ORDER = sorted(REV, key=lambda k: REV[k])
KF = [(OFF, 123.0)] + [(REV[k], float(D[k][0])) for k in ORDER]
def rank_at(t): return float(np.interp(t, [a for a, _ in KF], [b for _, b in KF]))
T_ISR = REV["ISR"]; T_AHEAD = T.at(13); T_NP = T.at(14); T_END = T.at(15)
MR = (0, 540, W, 1250); P = Proj((9.0, 11.5, 61.0, 42.5), MR, lat0=27)
LAND = hx("#26385C"); SEA = (12, 24, 52); NOD = hx("#4A5570")
C_LO, C_MID, C_HI = np.array(hx("#E0605E")[:3], float), np.array(hx("#F2B544")[:3], float), np.array(hx("#2FBF9A")[:3], float)
def ramp(s):
    u = (s - 395) / (530 - 395); u = max(0, min(1, u))
    c = C_LO + (C_MID - C_LO) * (u / 0.5) if u < 0.5 else C_MID + (C_HI - C_MID) * ((u - 0.5) / 0.5)
    return tuple(int(x) for x in c) + (255,)
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
for k in NODATA: compR(base, M[k], NOD, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
BP = {"SYR": ((39.6, 35.6), None, "b"), "EGY": ((29.6, 26.6), None, "b"), "IRN": ((55.2, 33.4), None, "b"), "IRQ": ((44.2, 32.3), None, "b"),
      "TUR": ((34.0, 39.2), None, "b"), "YEM": ((47.5, 15.9), None, "b"), "OMN": ((57.6, 19.6), None, "b"),
      "QAT": ((54.6, 26.2), (51.2, 25.3), "r"), "KWT": ((49.8, 30.6), (47.6, 29.3), "u"),
      "SAU": ((44.7, 23.6), None, "b"), "ARE": ((54.0, 23.1), None, "b"), "JOR": ((38.2, 30.6), None, "b"), "LBN": ((31.4, 35.0), (35.8, 33.9), "l"),
      "PSX": ((31.0, 32.3), (35.25, 31.95), "l"), "ISR": ((34.85, 30.55), None, "l")}
NAME = {"SYR": "Syria", "EGY": "Egypt", "IRN": "Iran", "IRQ": "Iraq", "TUR": "Turkey", "YEM": "Yemen", "OMN": "Oman",
        "QAT": "Qatar", "KWT": "Kuwait", "SAU": "Saudi Arabia", "ARE": "UAE", "JOR": "Jordan", "LBN": "Lebanon",
        "PSX": "Palestinians", "ISR": "Israel"}
def ordn(n): return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"
SUBS = sub_chunks(T, [("One hundred twenty three", "123"), ("one sixteen", "116"), ("one fifteen", "115"), ("one thirteen", "113"), ("one twelve", "112"),
                      ("One oh five", "105"), ("ninety three", "93"), ("ninety one", "91"), ("eighty nine", "89"), ("eighty seven", "87"),
                      ("eighty one", "81"), ("seventy eight", "78"), ("seventy two", "72"), ("seventy one", "71"), ("Sixty eight", "68"),
                      ("forty six", "46"), ("Forty six", "46")])
endimg = next((a[9:] for a in sys.argv[1:] if a.startswith("--endimg=")), None)
import d05_ck; d05_ck.HEB_OK = True
out = Out(rid, DUR, snaps_arg(), off=OFF, endimg=endimg)
R = 33
for f, t in out.frames():
    im = stage(); arr = BASE.copy()
    for k in ORDER:
        if t >= REV[k]: compR(arr, M[k], ramp(D[k][1]), min(1.0, (t - REV[k]) / 0.35))
    compR(arr, M["ISR"], ISRAEL_GOLD, 1.0 if t < T_ISR else 1.0); compR(arr, M["PSX"], PAL_GOLD, 1.0 if t < REV["PSX"] else 0.55)
    if t >= T_ISR:   # Israel glows in its score colour under the gold
        g = 0.5 + 0.5 * math.sin((t - T_ISR) * 5); compR(arr, M["ISR"], ramp(D["ISR"][1]), 0.35 * g)
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    last = None
    for k in ORDER:
        if t >= REV[k]: last = k
    for k, ((lo, la), anc, side) in BP.items():
        x, y = P(lo, la); shown = k in REV and t >= REV[k]
        if anc:
            ax, ay = P(*anc); ld.line([(x, y), (ax, ay)], fill=WHITE[:3] + (170,), width=3); ld.ellipse([ax - 5, ay - 5, ax + 5, ay + 5], fill=WHITE)
        pop = math.sin(math.pi * min(1, (t - REV[k]) / 0.4)) if k in REV and 0 <= t - REV[k] < 0.4 else 0.0
        isr = k == "ISR"; big = isr and t >= T_ISR
        r = R * (1 + 0.4 * pop) * (1.35 + 0.05 * math.sin(t * 6) if big else 1)
        if k in NODATA: fill, oc, s = (60, 68, 90, 235), SILVER, "?"
        elif shown: fill, oc, s = ramp(D[k][1])[:3] + (250,), (WHITE if not big else YEL), str(D[k][0])
        else: fill, oc, s = (10, 22, 50, 235), (YEL if isr else SILVER), "?"
        ld.ellipse([x - r, y - r, x + r, y + r], fill=fill, outline=oc[:3] + (255,), width=6 if big else 3)
        tc = (8, 18, 40, 255) if shown else (YEL if isr else SILVER)
        txt(ld, x, y + 1, s, int((32 if len(s) == 3 else 42) * r / R), tc, 900, "mm")
        lab = NAME[k]; ls = 42 if isr else 38; lc = YEL if isr else WHITE
        if side == "u": txt(ld, x, y - r - 22, lab, ls, lc, 800, "mm", stroke=4)
        elif side == "l": txt(ld, x - r - 10, y, lab, ls, lc, 800, "rm", stroke=4)
        elif side == "r": txt(ld, x + r + 10, y, lab, ls, lc, 800, "lm", stroke=4)
        else: txt(ld, x, y + r + 22, lab, ls, lc, 800, "mm", stroke=4)
    im.alpha_composite(lay); d = ImageDraw.Draw(im)
    yh = hook(d, ["Who speaks the best English", "in the Middle East?"], t, sz=100)
    ev = "15 countries. 123 ranked."
    if last and t < T_ISR + 3:
        ev = f"{NAME[last]}: {ordn(D[last][0])} of 123" if last != "ISR" else "Israel: 46th of 123"
        if last in ("IRN", "TUR", "ARE") and t >= REV["ARE"]: ev = "UAE 72nd, Turkey 71st, Iran 68th"
    if T_AHEAD <= t: ev = "Ahead of Egypt, Jordan, Lebanon, Syria"
    if T_NP <= t: ev = "15 countries. 123 ranked."
    txt(d, W / 2, yh + 14, ev, fit(ev, 60, 1000, 800, 44), YEL if last == "ISR" and t < T_NP else WHITE, 800, "ma")
    txt(d, 1040, 1200, "No data: Bahrain", 38, SILVER, 700, "ra")
    YY = 1268; rk = int(round(rank_at(t)))
    txt(d, 46, YY, "World rank", 50, SILVER, 700, "la"); txt(d, 46, YY + 54, f"#{rk}", 130, YEL if t >= T_ISR else WHITE, 900, "la")
    if last:
        sc = D[last][1]
        txt(d, 1034, YY, "EF score of 800", 50, SILVER, 700, "ra"); txt(d, 1034, YY + 54, f"{sc}", 130, ramp(sc), 900, "ra")
    if T_NP <= t:
        a = min(1, (t - T_NP) / 0.3) * (1 - min(1, max(0, (t - T_END - 0.4) / 0.4)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([40, 640, 1040, 1060], 28, fill=(8, 20, 46, int(245 * a)), outline=GOLD[:3] + (int(255 * a),), width=4)
            txt(ld, W / 2, 680, "Not perfect either", 78, GOLD, 900, "ma", a)
            txt(ld, W / 2, 800, "Israel: 524. Moderate.", 72, WHITE, 800, "ma", a)
            txt(ld, W / 2, 900, "Netherlands: 624. Number 1.", 72, WHITE, 800, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    source(d, "Source: EF English Proficiency Index 2025 (123 countries)")
    he = "מי מדבר אנגלית הכי טוב במזרח התיכון?"
    txt(d, W / 2, 1650, he, 56, SKY_L, 800, "ma", 0.95 if t >= 0 else 0)
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
