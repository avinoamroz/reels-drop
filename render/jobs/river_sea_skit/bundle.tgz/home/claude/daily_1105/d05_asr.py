import sys, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit"); import asr
for rid in sys.argv[1:]:
    D = f"/home/claude/daily_1105/{rid}"; x, sr = sf.read(f"{D}/vo.wav")
    lines = [l for l in open(f"{D}/tts.txt").read().splitlines() if l.strip()]
    r = asr.align_voice(x, sr, lines, log=lambda *a: None)
    print(rid, "windows:", " | ".join(r["windows"]) if isinstance(r["windows"][0], str) else r["windows"])
    for L in r["lines"]:
        if L["missing"]: print("  MISS", L["text"], "->", L["missing"])
