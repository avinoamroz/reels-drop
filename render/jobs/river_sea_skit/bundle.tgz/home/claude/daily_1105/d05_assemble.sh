#!/bin/bash
# usage: d05_assemble.sh <rid> <style> <cam> <hook> <hook-y> <hook-s>
set -e
rid=$1; D=/home/claude/daily_1105/$rid
cd /home/claude/map_tear_opener
nice python3 map_open.py --style "$2" --reel $D/out/silent.mp4 --cam "$3" --hook "$4" --hook-y $5 --hook-s $6 --out $D/out/op_full.mp4
DUR=$(python3 -c "import json;print(round(json.load(open('$D/timing.json'))['dur']+0.9,2))")
ffmpeg -nostdin -v error -y -i $D/out/op_full.mp4 -i $D/audio.m4a -filter_complex "[0:a]volume=0.8[s];[1:a][s]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.89[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -ar 48000 -t $DUR -movflags +faststart $D/out/$rid.mp4
rm -f $D/out/silent.mp4 $D/out/op_full.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 $D/out/$rid.mp4
