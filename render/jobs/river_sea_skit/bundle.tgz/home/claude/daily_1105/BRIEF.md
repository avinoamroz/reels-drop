DAILY PRODUCTION for Noam Roz's @noamroz__ Instagram. Today is Thu 5 Nov 2026 (Israel UTC+2). Coordinator: run this as one subagent task and report back to the coordinator, not to Noam. Never use em or en dashes anywhere. FIRST read /home/claude/video-guidelines.md (the house video rules) and follow it.

UPDATED RULES FROM NOAM (30 to 31 Oct), these override older notes below:
- NO "To be fair" lines (31 Oct 21:30) and NEVER "In my view", "In my opinion" or similar ("of course it's in my view"). Applies to every reel: narration, screen text and captions. State sourced facts plainly.
- REAL PHOTOS AND MINI B-ROLL in most reels (31 Oct: "keep on doing it in most videos"): free licences only (Wikimedia Commons PD / CC BY / CC BY-SA, US gov, GPO, Library of Congress, Flickr CC), never Getty, news agencies or Rubinger; fetch via Make scenario 5000550 (download URL to Drive), Commons thumbnails at standard widths like 1920px; full-bleed or a big rounded panel, slow Ken Burns, dark gradient behind text, at least 3 s each, 36 px credit label plus credits in the caption. Reference pipeline: /home/claude/photos_v2 (scenes_photo.py).
- FOREIGN WORDS (firm): never let the English voice read Hebrew, Russian, Spanish or any other language. Voice each foreign word or phrase as its own Cartesia clip with the same voice id and "language" set to that language (he, ru, es...), text in native script (Hebrew WITHOUT niqqud), spliced into the English line. Whisper-check it in that language: python3 /home/claude/launch_plan/voice_transcribe.py --lang he FILE.
- CIRCULAR DONE RIGHT: never ask the hook question at both the start and the end. The question is said ONCE at frame 0. The last line is a lead-in that completes with the hook on loop, e.g. end "So... next time someone asks you?" then loop to "Where can Jews walk safely?". The last frame matches frame 0 and the music loops on a downbeat.
- Avoid the word "Islam" in narration (the Cartesia voice says "eye-slam"); rephrase.
- APPLE KEYNOTE LOOK ("how would Steve Jobs design it"): dark stage, one font family, one huge number or idea per screen, lots of empty space, one accent colour, slow eased motion; no boxes, chips or badges clutter; nothing overlapping. Reference: /home/claude/series_more/safe_p2_v3 (engine_v3.py, cfg_v3.py).
- ENGLISH ONLY, BIG TEXT. No Hebrew lines under the English. Captions English only too.
- FULL SCREEN: use the whole 1080x1920 frame, big text spread across the width and centred. Keep top ~220 px and bottom ~330 px free of key text.
- Kilometers, never miles. Related topics go in separate videos.
- Narration stress must be right: short sentences, numbers written out as words, one line at a time, whisper-check every line and rephrase anything misheard.
- NO RE-HOOKS of weak reels. Variants must change the TOPIC angle (a new question on the same winning subject), not just the first line.
- Don't build anything about "Building a country / year by year", and don't touch: love_colonizing*, tony_*, peace_no_years, compare_nj, arab_vote, beer_per_km*, meat_per_km, israel_drinks*, geneva_uniforms*, babysitters*, colonize_babysit, trade_race, promenade_steps*, muslims_freest*, lib_mena_rights*, safe_p2*, x_*, dead_sea_drop*, hummus_war*, jerusalem_captured*, jerusalem_1000bce*, named_after*, christians_map*, apartheid_world*, series_country*, russian_alone, israel_size*, water_compare*, unrwa_unhcr*, minority_vs_majority*, work_hours*, animals_arrival*, israeli_direct*, gaza_2005*, un_voice_white*, colonizer_speed*, hebrew_revival*, jews_survive*, lib_startups_pc*, lib_vid_jews_world*, not_math*, shell_lottery*, tech_exits*, lib_build_destroy*.

RULES (Noam, 29 Oct):
- Every reel goes to status "check". Never "approved".
- Build 6 reels. Quality over quantity.
- Upload a 540p preview of each to the Launch Map asset store (Artifact publish, url = the Launch Map, asset:true, file_paths) and set preview "/_blob/<asset id>" plus previewAsset, so Noam can play them inside the page.
- Write all Launch Map cards (https://claude.ai/code/artifact/Fkdcnuz1oiYUa3hGP5FvLZ) in ONE ArtifactData batch at the end (load ArtifactData via ToolSearch), flat fields, never nested under "data".

STEP 1, REFRESH WINNERS FIRST: Use Make Graph scenario 4983357 (read only, mcp__Make__s4983357_99_ig_graph_call_for_reels_method_path_body_ret) with {method:"get", path:"17841400746045382/media?fields=id,permalink,caption,timestamp&limit=30", tag:<unique>}; results on hook 2850117 (hook-incomings_list pg limit 10 sortBy created desc, hook-incomings_get matching your tag; large outputs get saved to files, load in python). Then insights "?ids=<ids>&fields=insights.metric(views,reach,shares,saved)". Trial reels are NOT in /media, so also read the Launch Map's live cards and their views field. Known winners as of 31 Oct: s3000_p2 (who ruled this land) 2,230 views / 31 shares; slave word reel 2,044 / 18; walk safely 2,031 / 28; shabbat_p3 1,968 / 59 shares; persecution 1,854 / 28; guinness_il_hook2 1,842; israel_syria 1,734; lib_vid_pets_race_v2 1,485; maps_p2 1,442. Older big ones: came_home 5,421 / 90 shares, aliyah map 4,466, pop race 3,510.

STEP 2, what to build:
- About 4 VARIANTS of winners (new angle on the same winning subject) that don't already have recent variants (check /home/claude/posting/queue/gh and the Launch Map parent fields and addedAt; skip parents with a variant in the last 2 days). Candidates: slavery word reel, persecution, safety_v5, israel_syria, came_home, un_imbalance, silly_maps / maps_p2, true_size.
- About 2 NEW ideas from /home/claude/strategy/reel_ideas.json (NR ideas not built yet) and /home/claude/insights/top_reels_lessons_2026-10-25.md. Data/map ideas in the winners' family (one big question answered with data on a map, with real photos) are good.

STEP 3, retention rules (/home/claude/insights/retention_2026-10-29.csv): motion from frame 0, a counter, photo or new item every ~3 s, reveal at 65 to 80%, no "Part X", end card under 1 s, last line is a lead-in that flows into the hook, 45 to 60 s (about 130 to 155 words).

STEP 4, production:
- Copy the latest pipeline (/home/claude/daily_1101: reels_def4.py, build.py, grab.py, grab_raw.py, grab_all.py, send_cloud.py, finalize.py, docs.py, scenes_daily.py) to /home/claude/daily_1105 and rename the d01_ prefix and daily_1101 paths to d05_/daily_1105. Add photo beats using /home/claude/photos_v2/scenes_photo.py. build.py refuses Hebrew in scenes or captions and the word "mile".
- TTS via Make 4998936 (Cartesia, voice cd06f613-0c92-4347-9b94-b34cb4a0239f, sonic-3, endpoint sse; set "language" per clip). Find the files on Drive by title (search parentId = '1A04ai2ai6iUq5fkz2mH5t4meqCH8U1k9' and createdTime > today), download each, then run grab_all.py or grab_raw.py <id> <part> <blob> per part, and grab.py --join <id>.
- Whisper-check each vo.wav (asr.align_voice from /home/claude/reelkit/asr.py). Grep the final scripts, specs and captions for "in my view", "my opinion", "to be fair", "לדעתי" and remove any hit.
- Run make_reel_sse.py spec.json vo out --preview per reel locally and LOOK at out/preview.png. Delete the out/ folders before sending.
- Render all in ONE cloud batch with /home/claude/reelkit/cloud_render.py (via send_cloud.py), then cloud_render.py wait.
- FACT-CHECK every number with WebSearch before voicing it. Real sources only; sources on screen as a footer (at least 36 px).

House rules: hook at frame 0, motion by 1.5 s; no "In my view", no "To be fair"; no keyword CTA; narration plus music; Israel maps: the land between the river and the sea in gold #B8923F, the Green Line in green. HAMAS in caps on screen.

Each reel needs: a payload at /home/claude/posting/queue/gh/<id>.json (REELS, share_to_feed true, is_ai_generated true, SS_PERFORMANCE; finalize.py does this); a captions/<id> doc; the mp4 in /home/claude/reels-drop. Commit as git -c user.name="Noam Roz" -c user.email="noam@expressenglish.co.il", message ending with "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>" and "Claude-Session: https://claude.ai/code/session_01D8gF2iekadnzKcdJnCPGVX". Pull --rebase --autostash first. QA on a contact sheet that you look at: hook visible, full screen used, centred, nothing overlapping, last frame equals frame 0, the question is not repeated at the end, no opinion or fair lines, foreign words native, no dashes, audio present.

Disk is tight (about 1 GB free): delete your intermediates as you go; you may git rm render/jobs/<id> folders older than 1 day in reels-drop in a commit with "[skip ci]". Stop and report if under 700 MB. Don't grep -r across /home/claude (times out). Never read Make data store 94072, never print keys, never pkill by pattern. Don't schedule posts.

At the end, schedule the next run with mcp__claude-code-remote__send_later at 2026-11-06T07:40:00Z, initiation "human_schedule", name "Daily reel production", using this same brief with dates moved forward one day and the UPDATED RULES section kept (written as instructions to the coordinator session that receives it).

Report: one line per reel (id, parent or idea, sources, raw URL, 540p local path), the count, and anything broken.
BANGER LANE (Noam, 2 Nov 19:57: "Let's work on bangers so we have at least one of them every day"):
- Every daily production run builds at least ONE banger first, before anything else: a direct sequel or sibling of a proven winner (3,000 years population race 128k, Muslims freedom scorecard 84.9k, MENA rights scorecard 88.7k, UN counts 25.6k, ridiculous maps 11.7k), same engine and format, a NEW question, honest predViews 15,000+.
- Mark it on the card with banger: true and put it first in the report. The posting machine gives bangers the 21:00 Israel slot (or the best free slot) every day, replacing the weakest approved card that day if needed.
- Keep a running list of banger ideas used and next in /home/claude/insights/bangers.md (append, never repeat a question).

CLICK DRIVERS (3 Nov) (data study of 106 reels, full doc /home/claude/insights/click_drivers_2026-11-03.md). Apply to every reel; QA them on the 0 / 1 / 3 s contact sheet:
1. FRAME 0 = THE SCOREBOARD: frame 0 shows the map, bars, flag row or counter the reel will change, filling at least half the frame, full brightness. No emoji or icon as the main frame 0 visual, no fade from black, no title card, no series badge. (Winners all open on the data; flops on an icon plus a sentence: fair_elections_v3 56% skip, build_destroy 78%, x_could 90%.)
2. MOVES BY 1 S, FIRST CHANGE BY 3 S: a counter ticks or a bar moves by 1.0 s; first overtake / first answer / first number by 3.0 s.
3. QUESTION IN, ANSWER LAST: hook is a who / where / how question whose answer is the final state. Never put the payoff number in the hook (meat_per_km "80 g" hook: stayers watched 41%). Reveal at 75 to 90% of the runtime, then the loop line.
4. PROMISE THE SHAPE IN 2 S: a small line like "7 questions. 11 countries." or "2,600 years in 40 seconds", or a running year counter.
5. ONE PROCESS TO THE END: the same scoreboard keeps changing up to the reveal. No switch to a stack of argument cards mid-reel. Breakouts (18k+) held non-skippers 72 to 93% of the reel; 4k to 12k reels only 52 to 59%.
6. LENGTH 40 TO 62 S, never over 65 s (lib_gdp_map 69.6 s and build_destroy 71.9 s both lost the middle).
7. READ AT ARM'S LENGTH: hook at least 100 px, labels and values at least 56 px, English only on screen, dark navy stage. (pop_race_v6_en, same race and hook as the 90.5k original but bigger English-only text: 215k views, skip 49.5% down to 37.4%.)
8. REMAKE WINNERS AS-IS: a re-cut of a proven winner keeps its exact hook and question and changes only legibility, length and pace. Never reword a winning hook (reworded 3,000 years hooks got 3.6k and 3.1k). Predict such re-cuts from the winner's family, not the re-hook anchor.
9. NO "PART 2" BUILDS: sequels got 2 to 13% of the parent (s3000_p2 2.5k vs 90.5k; mena_rights_p2 2.7k vs 104k). Build a sibling with a NEW question, standalone title.
10. 3 HOUR GATE: read reels_skip_rate and ig_reels_avg_watch_time (Graph API, they work for graduated reels). Pass = skip 48% or lower AND avg watch / length 0.40 or higher. Skip over 55% = frame 0 failed: rebuild frame 0 only.
11. EXPRESS FRAME 0: open on a map, a race or an identity question with big English. No Hebrew-first abstract line, no "Day N" badge as the first thing seen (90 days series: 71 to 85% skip, 156 to 288 views). Move "Day N" to 1.5 s or the caption.
12. Post hour showed no effect; keep the current windows.
Idea backlog on this pattern (sourced, fact-check before voicing): Who lived in Jerusalem? 1844 to 2022 race; Who recognised Israel first? map 1 to 169; When could women vote here? map + year counter (Turkey 1930 first, Israel 1948); Who lives longest in the Middle East? World Bank race; Where did Europe's Jews go? 9.5M (1933) to 3.5M (1950), USHMM; Express: Which English words came from Hebrew? route map. Details and sources in the doc.

OPENERS (Noam 4 Nov, on all 9 colonize_op_* tests: "great hook, use it in other videos"): every new @noamroz__ reel with a map gets a 2.0 to 2.5 s motion opener from /home/claude/map_tear_opener/map_open.py (styles globe_spin_fast, globe_spin_reverse, globe_spin_whip, globe_spin_night, globe_unpeel, map_crumple, map_fold, map_puzzle, map_tear_v2). Rotate styles so the same one is not used two reels in a row. After the spin or map move, ZOOM IN to the reel's region (Israel or the countries discussed) and the narration starts on the zoom. The hook text is on screen from frame 0 (--hook). Hand over to the reel by 2.5 s.

HARD RULE (Noam 4 Nov 10:46): do NOT create any reel with an honest predViews under 5,000, on either account. If an idea cannot reach 5,000, do not build it. Fewer, stronger reels.
- HARD WORDS NEED A PICTURE (Noam 6 Nov): every non-basic English word on screen (flogging, amputation...) gets an icon or image that shows its meaning, especially in tables and scorecards; prefer simple words.
