# -*- coding: utf-8 -*-
"""Narration for the 5 Nov 2026 daily reels (one TTS line per list item). Facts checked 5 Nov 2026:
best_english_mena: EF English Proficiency Index 2025 (published Nov 2025, 123 countries and regions). Rank / score:
  Israel 46 / 524, UAE 72 / 487, Turkey 71 / 488, Iran 68 / 492, Lebanon 78 / 477, Qatar 81 / 469, Palestine 87 / 463, Egypt 89 / 459,
  Syria 91 / 456, Kuwait 93 / 455, Jordan 105 / 426 (ef.com: 105 / 425), Oman 112 / 407, Iraq 113 / 406 (ef.com: 113 / 406),
  Saudi Arabia 115 / 404, Yemen 116 / 402; Bahrain not listed; Netherlands 1 / 624 (ef.com/epi). Israel 46 / 524 and UAE 72 / 487 and
  Saudi 115 confirmed on ef.com fact sheets and region pages; full table via Wikipedia 'EF English Proficiency Index'.
holocaust_israel: Jewish population of Palestine / Israel (Jewish Virtual Library table, sources British Mandate censuses, Israel CBS,
  Rabinovich and Reinharz 2008): 1882 24,000; 1914 94,000; 1922 83,794 (British census); 1931 174,610 (British census); 1939 449,000;
  1947 630,000 of 1,970,000 (32 percent). Tel Aviv founded 1909; Technion cornerstone 1912; Hebrew University opened 1 April 1925;
  First Zionist Congress, Basel, 1897; mass murder of Europe's Jews begins 1941 (Einsatzgruppen, Chelmno); UN General Assembly
  Resolution 181 (partition), 29 November 1947."""
S = {}
S["best_english_mena"] = [
 "Who speaks the best English in the Middle East?",
 "One hundred twenty three countries ranked. Let's count down.",
 "Yemen, one sixteen. Saudi Arabia, one fifteen.",
 "Iraq, one thirteen. Oman, one twelve.",
 "Jordan. One oh five.",
 "Kuwait, ninety three. Syria, ninety one.",
 "Egypt, eighty nine. The Palestinians, eighty seven.",
 "Qatar, eighty one. Lebanon, seventy eight.",
 "The Emirates, seventy two. Turkey, seventy one.",
 "Iran. Sixty eight. Can anyone here beat that?",
 "One country can.",
 "Israel. Number forty six in the world.",
 "The best English in the region. Ahead of Egypt, Jordan, Lebanon and Syria.",
 "Not perfect either. Forty six is only moderate. The Netherlands is number one.",
 "So next time a friend asks you...",
]
S["holocaust_israel"] = [
 "Did the Holocaust create Israel?",
 "Let's count the Jews in this land, year by year.",
 "Eighteen eighty two. Twenty four thousand.",
 "Nineteen oh nine, Tel Aviv. Nineteen twelve, the Technion. Nineteen fourteen, ninety four thousand.",
 "Nineteen twenty two. Eighty four thousand, after the First World War.",
 "Nineteen twenty five. The Hebrew University opens.",
 "Nineteen thirty one. A hundred seventy five thousand.",
 "Nineteen thirty nine. Four hundred forty nine thousand.",
 "The mass murder of Europe's Jews began in nineteen forty one.",
 "Nineteen forty seven. Six hundred thirty thousand. The UN votes to divide the land.",
 "So, no. The Holocaust did not create Israel.",
 "Zionism began in eighteen ninety seven. The vote came fifty years later.",
 "Not perfect either. In nineteen forty seven, Jews were about a third of the people here. The UN proposed two states.",
 "So next time someone asks you...",
]
