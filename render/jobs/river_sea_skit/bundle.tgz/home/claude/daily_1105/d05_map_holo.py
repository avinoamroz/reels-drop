# -*- coding: utf-8 -*-
"""holocaust_israel: Did the Holocaust create Israel? Map of the land + year counter + Jewish population counter 1882 to 1947.
Frames before OFF (2.4 s) come from the map_open.py opener, zooming into this exact map view."""
import sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/daily_1105")
import d05_ck
from d05_ck import *
rid = "holocaust_israel"; T = Timing(rid); DUR = round(T.dur + 0.9, 2); OFF = 2.4
F = features()
def wt(L, word, nth=1):
    n = 0
    for w in T.lines[L - 1]["words"]:
        if T.norm(w["w"]) == T.norm(word):
            n += 1
            if n == nth: return w["t0"] - 0.05
    raise KeyError((L, word))
# year keyframes (time, year) from the narration; population anchors (time, Jews) = the moment the figure is spoken
YK = [(OFF, 1840), (T.at(3), 1882), (wt(4, "Tel"), 1909), (wt(4, "Technion"), 1912), (wt(4, "ninety"), 1914), (T.at(5), 1922), (T.at(6), 1925),
      (T.at(7), 1931), (T.at(8), 1939), (T.at(9), 1941), (wt(10, "Six"), 1947), (T.at(12), 1897), (T.at(12) + 3.2, 1897), (T.at(12) + 4.2, 1947)]
PK = [(T.at(3), 24000), (wt(3, "Twenty"), 24000), (wt(4, "ninety"), 94000), (T.at(5), 83794), (T.at(7), 174610), (wt(8, "Four"), 449000),
      (wt(10, "Six"), 630000)]
TP0 = PK[0][0]
def year_at(t):
    if t >= YK[-3][0]: return float(np.interp(t, [YK[-3][0], YK[-2][0], YK[-1][0]], [1897, 1897, 1947]))
    return float(np.interp(t, [a for a, _ in YK[:11]], [b for _, b in YK[:11]]))
def pop_at(t):
    if t < TP0: return None
    ts = [PK[0][0], PK[1][0]]
    pts = [(PK[0][0], 24000), (PK[1][0] + 0.2, 24000)]
    for tt, v in PK[2:]: pts.append((tt - 0.9, pts[-1][1])); pts.append((tt, v))
    return float(np.interp(t, [a for a, _ in pts], [b for _, b in pts]))
PIN = {"TLV": dict(lo=34.78, la=32.08, t=wt(4, "Tel"), lab="1909 Tel Aviv", side="l"),
       "HFA": dict(lo=34.99, la=32.79, t=wt(4, "Technion"), lab="1912 Technion", side="l"),
       "JLM": dict(lo=35.23, la=31.78, t=T.at(6), lab="1925 Hebrew University", side="r")}
T_Y41 = T.at(9); T_VOTE = wt(10, "UN"); T_NO = T.at(11); T_97 = T.at(12); T_NP = T.at(13); T_END = T.at(14)
MR = (0, 540, W, 1250); P = Proj((33.3, 29.3, 37.0, 33.6), MR, lat0=31.5)
LAND = hx("#26385C"); SEA = (12, 24, 52)
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
compR(base, M["ISR"], ISRAEL_GOLD, 1.0); compR(base, M["PSX"], PAL_GOLD, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
SUBS = sub_chunks(T, [("Eighteen eighty two", "1882"), ("Twenty four thousand", "24,000"), ("Nineteen oh nine", "1909"), ("Nineteen twelve", "1912"),
                      ("Nineteen fourteen", "1914"), ("ninety four thousand", "94,000"), ("Nineteen twenty two", "1922"), ("Eighty four thousand", "84,000"),
                      ("Nineteen twenty five", "1925"), ("Nineteen thirty one", "1931"), ("a hundred seventy five thousand", "175,000"),
                      ("A hundred seventy five thousand", "175,000"), ("Nineteen thirty nine", "1939"), ("Four hundred forty nine thousand", "449,000"),
                      ("nineteen forty one", "1941"), ("Nineteen forty seven", "1947"), ("nineteen forty seven", "1947"), ("Six hundred thirty thousand", "630,000"),
                      ("eighteen ninety seven", "1897"), ("fifty years", "50 years")])
endimg = next((a[9:] for a in sys.argv[1:] if a.startswith("--endimg=")), None)
out = Out(rid, DUR, snaps_arg(), off=OFF, endimg=endimg)
for f, t in out.frames():
    im = stage(); arr = BASE.copy()
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
    for k, p in PIN.items():
        if t < p["t"]: continue
        x, y = P(p["lo"], p["la"]); u = (t - p["t"]) / 0.45; pop = math.sin(math.pi * min(1, u)) if u < 1 else 0
        r = 15 * (1 + 0.8 * pop)
        ld.ellipse([x - r - 8, y - r - 8, x + r + 8, y + r + 8], fill=WHITE[:3] + (70,)); ld.ellipse([x - r, y - r, x + r, y + r], fill=YEL, outline=(8, 18, 40, 255), width=4)
        if p["side"] == "l":
            ax = x - 30
            txt(ld, ax, y - 8 if k != "HFA" else y - 8, p["lab"], 44, WHITE, 800, "rm", stroke=4)
        else: txt(ld, x + 34, y + 4, p["lab"], 40, WHITE, 800, "lm", stroke=4)
    im.alpha_composite(lay); d = ImageDraw.Draw(im)
    yh = hook(d, ["Did the Holocaust", "create Israel?"], t, sz=112)
    yr = year_at(t); ys = int(round(yr))
    ev = "Jews in this land, year by year."
    if t >= T.at(3): ev = "1882: 24,000 Jews"
    if t >= PIN["TLV"]["t"]: ev = "1909: Tel Aviv founded"
    if t >= PIN["HFA"]["t"]: ev = "1912: the Technion, Haifa"
    if t >= wt(4, "ninety"): ev = "1914: 94,000 Jews"
    if t >= T.at(5): ev = "1922: 83,794 (British census)"
    if t >= T.at(6): ev = "1925: Hebrew University opens"
    if t >= T.at(7): ev = "1931: 174,610 (British census)"
    if t >= T.at(8): ev = "1939: 449,000 Jews"
    if t >= T_Y41: ev = "1941: the mass murder begins"
    if t >= wt(10, "Nineteen"): ev = "1947: the UN votes to divide the land"
    if t >= T_NO: ev = "Answer: No."
    if t >= T_97: ev = "1897 to 1947: fifty years"
    if t >= T_NP: ev = "Jews in this land, year by year."
    txt(d, W / 2, yh + 14, ev, fit(ev, 60, 1000, 800, 44), YEL if (T_NO <= t < T_NP) else WHITE, 800, "ma")
    YY = 1268
    txt(d, 46, YY, "Year", 50, SILVER, 700, "la"); txt(d, 46, YY + 54, f"{ys}", 130, YEL if (T_NO <= t < T_NP) else WHITE, 900, "la")
    pv = pop_at(t)
    txt(d, 1034, YY, "Jews in the land", 50, SILVER, 700, "ra")
    anch = [24000, 94000, 83794, 174610, 449000, 630000]
    if pv is None: ps = "?"
    else:
        near = [x for x in anch if abs(pv - x) < 60]
        ps = f"{near[0]:,}" if near else f"{int(round(pv / 100.0) * 100):,}"
    txt(d, 1034, YY + 54, ps, 130, GREEN if (pv or 0) >= 449000 else WHITE, 900, "ra")
    if T_NP <= t:
        a = min(1, (t - T_NP) / 0.3) * (1 - min(1, max(0, (t - T_END - 0.4) / 0.4)))
        if a > 0:
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
            ld.rounded_rectangle([40, 640, 1040, 1100], 28, fill=(8, 20, 46, int(245 * a)), outline=GOLD[:3] + (int(255 * a),), width=4)
            txt(ld, W / 2, 680, "Not perfect either", 78, GOLD, 900, "ma", a)
            txt(ld, W / 2, 800, "1947: 630,000 Jews.", 72, WHITE, 800, "ma", a)
            txt(ld, W / 2, 900, "1,970,000 people in all.", 72, WHITE, 800, "ma", a)
            txt(ld, W / 2, 1000, "About a third.", 72, YEL, 800, "ma", a)
            im.alpha_composite(lay); d = ImageDraw.Draw(im)
    source(d, "Sources: British Mandate censuses, Jewish Virtual Library, UN Res. 181")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
