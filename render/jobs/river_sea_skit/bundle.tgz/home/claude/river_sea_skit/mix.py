import sys, json, re, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/rehook"); import rk
D = "/home/claude/river_sea_skit"; SR = 48000
TJ = json.load(open(f"{D}/timing.json")); LN = TJ["lines"]; T = round(TJ["dur"] + 0.8, 2); n = int(T * SR)
def load(p):
    y = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ar", str(SR), "-ac", "2", "-f", "f32le", "-"], capture_output=True).stdout, np.float32)
    return y.reshape(-1, 2).T.astype(np.float64)
def lufs(x):
    o = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", "ebur128", "-f", "null", "-"],
                       input=x.T.astype(np.float32).tobytes(), capture_output=True).stderr.decode()
    return float(o[o.rfind("I:"):].split()[1])
vo, sr = sf.read(f"{D}/vo_final.wav"); assert sr == SR
if vo.ndim > 1: vo = vo.mean(1)
vo = np.pad(vo, (0, max(0, n - len(vo))))[:n]
def WF(i, w, nth=0):
    k = 0
    for x in LN[i]["words"]:
        if re.sub(r"[^\w]", "", x["w"].lower()) == w:
            if k == nth: return x["t0"]
            k += 1
# crowd doubling on chant lines
rng = np.random.default_rng(7)
crowdL = np.zeros(n); crowdR = np.zeros(n)
spans = [(LN[i]["t0"] - 0.05, LN[i]["t1"] + 0.1) for i in (0, 2, 4, 6)] + [(LN[10]["t0"] - 0.05, WF(10, "give") - 0.1)]
for a, b in spans:
    i0, i1 = int(a * SR), int(b * SR); seg = vo[i0:i1]
    for k, (r, dl, g, pan) in enumerate(((0.965, 0.035, -9, 0.2), (0.985, 0.06, -10, 0.8), (1.02, 0.045, -10, 0.35), (1.04, 0.08, -11, 0.65), (0.95, 0.1, -12, 0.5))):
        m = int(len(seg) / r); y = np.interp(np.arange(m) * r, np.arange(len(seg)), seg) * 10 ** (g / 20)
        j = i0 + int(dl * SR); j1 = min(n, j + m); y = y[:j1 - j]
        crowdL[j:j1] += y * (1 - pan); crowdR[j:j1] += y * pan
ir = rng.standard_normal(int(0.5 * SR)) * np.exp(-np.arange(int(0.5 * SR)) / SR * 9); ir /= np.abs(ir).sum() / 6
from scipy.signal import fftconvolve
crowd = np.stack([crowdL, crowdR]); crowd = crowd + 0.5 * np.stack([fftconvolve(crowdL, ir)[:n], fftconvolve(crowdR, ir)[:n]])
raw = load("/home/claude/rehook4/beds/potential_bed.wav")
while raw.shape[1] < n + SR: raw = np.concatenate([raw, raw], 1)
bed = raw[:, :n].copy(); xf = int(0.6 * SR); tail = raw[:, n:n + xf]
bed[:, :xf] = bed[:, :xf] * np.minimum(1, np.arange(xf) / xf)[None] + tail * (1 - np.arange(xf) / xf)[None]
bed *= 10 ** ((-16 - lufs(bed)) / 20)
m = np.zeros(n)
for l in LN: m[int((l["t0"] - 0.08) * SR):int((l["t1"] + 0.12) * SR)] = 1
k = int(0.12 * SR); m = np.convolve(m, np.ones(k) / k, "same"); bed *= (10 ** (-9 * m / 20))[None]
sfx = np.zeros(n)
def put(t, y, db):
    i = int(t * SR); j = min(n, i + len(y))
    if i < n: sfx[i:j] += y[:j - i] * 10 ** (db / 20)
tt = np.arange(int(0.35 * SR)) / SR
thud = (np.sin(2 * np.pi * 70 * tt) * np.exp(-tt * 18) + 0.4 * np.random.default_rng(1).standard_normal(len(tt)) * np.exp(-tt * 60)); thud /= np.abs(thud).max()
glass = load("/home/claude/reelkit/sfx/glass_001.wav").mean(0); pluck = load("/home/claude/reelkit/sfx/pluck_001.wav").mean(0)
glass /= np.abs(glass).max(); pluck /= np.abs(pluck).max()
for i, w, nth in ((0, "france", 0), (2, "america", 0), (4, "uruguay", 1), (6, "mexico", 0), (10, "give", 0)): put(WF(i, w, nth) - 0.05, thud, -12)
for i in (1, 3, 5, 7): put(WF(i, "give") - 0.05, pluck, -18)
put(WF(8, "silly") - 0.05, pluck, -16); put(LN[11]["t0"] - 0.1, glass, -13); put(WF(12, "judah") - 0.05, glass, -17); put(LN[13]["t0"] - 0.05, thud, -16)
x = np.stack([vo, vo]) + crowd + bed + np.stack([sfx, sfx])
J = rk.finish_audio(x, f"{D}/audio.m4a")
print("audio", T, J.get("final_I"), J.get("final_TP"))
