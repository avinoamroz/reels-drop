# -*- coding: utf-8 -*-
"""river_sea_skit (@noamroz__, 8 Nov 2026). Satire: the chant "From the river to the sea" applied to France, the US,
Uruguay and Mexico (full-screen maps, animated rivers, protest signs), then turned on Israel. Loops into frame 0.
usage: python3 reel.py [--snaps=0,1.4,...]"""
import sys, math, json, re
import numpy as np
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, "/home/claude/river_sea_skit")
import d05_ck as ck
from d05_ck import *
ck.HERE = "/home/claude"
ck.SUB_Y = 1690
RID = "river_sea_skit"
D = "/home/claude/river_sea_skit"
T = Timing(RID); DUR = round(T.dur + 0.8, 2)
Ls = T.lines
def S(i): return Ls[i]["t0"] - 0.1 if i > 0 else 0.0
def E(i): return Ls[i]["t1"]
def WF(i, word, nth=0):
    n = 0
    for w in Ls[i]["words"]:
        if re.sub(r"[^\w]", "", w["w"].lower()) == word.lower():
            if n == nth: return w["t0"] - 0.06
            n += 1
    raise KeyError((i, word))
def win(t, a, b, fi=0.25, fo=0.25): return max(0.0, min(ease((t - a) / fi), 1 - ease((t - (b - fo)) / fo)))
def T_(d, x, y, s, sz, col, w=900, anchor="mm", a=1.0, stroke=0, maxw=980):
    if a <= 0.01: return
    ck.txt(d, x, y, s, ck.fit(s, sz, maxw, w, 36), col, w, anchor, max(0, min(1, a)), stroke)
SEA = (9, 22, 52); LAND = (30, 50, 96); LAND_E = (52, 78, 132); TARGET = (40, 112, 196); FREE = (69, 164, 221)
RIVER = (120, 230, 255); ORANGE = hx("#FF9F43")

# ------------------------------------------------------------------ flags
EMO = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf", 109)
_fl = {}
def flag_img(cc, w):
    k = (cc, int(w))
    if k in _fl: return _fl[k]
    s = "".join(chr(0x1F1E6 + ord(c) - 65) for c in cc.upper())
    im = Image.new("RGBA", (160, 140), (0, 0, 0, 0)); ImageDraw.Draw(im).text((10, 5), s, font=EMO, embedded_color=True)
    im = im.crop(im.getbbox()); h = int(round(w * im.height / im.width)); im = im.resize((int(w), h), Image.LANCZOS)
    _fl[k] = im; return im
def put(im, src, cx, cy, a=1.0):
    if a <= 0.01: return
    if a < 1: src = src.copy(); src.putalpha(src.getchannel("A").point(lambda v: int(v * a)))
    im.alpha_composite(src, (int(cx - src.width / 2), int(cy - src.height / 2)))
def flag(im, cc, cx, cy, w, a=1.0): put(im, flag_img(cc, w), cx, cy, a)

# ------------------------------------------------------------------ icons (drawn, 100-unit box)
_ic = {}
def icon(name, sz, col=WHITE):
    k = (name, sz, col)
    if k in _ic: return _ic[k]
    Q = 4; n = sz * Q; im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im); u = n / 100.0
    P = lambda *xy: [v * u for v in xy]; L = lambda w: max(1, int(w * u))
    c = col[:3] + (255,); nb = (14, 30, 66, 255); y_ = YEL[:3] + (255,)
    if name == "helmet":      # Gaul: winged helmet
        d.chord(P(22, 30, 78, 86), 180, 360, fill=c); d.rectangle(P(20, 56, 80, 64), fill=c)
        d.polygon(P(22, 46, 2, 18, 8, 40, 0, 34, 10, 52), fill=y_); d.polygon(P(78, 46, 98, 18, 92, 40, 100, 34, 90, 52), fill=y_)
        d.ellipse(P(44, 22, 56, 34), fill=c)
    elif name == "sword":     # invaders
        d.polygon(P(46, 6, 54, 6, 56, 66, 44, 66), fill=c); d.polygon(P(46, 6, 50, 0, 54, 6), fill=c)
        d.rounded_rectangle(P(28, 64, 72, 72), L(3), fill=c); d.rectangle(P(46, 72, 54, 90), fill=c); d.ellipse(P(43, 88, 57, 100), fill=c)
    elif name == "crown":
        d.polygon(P(10, 78, 10, 30, 30, 52, 50, 18, 70, 52, 90, 30, 90, 78), fill=c)
        d.rounded_rectangle(P(10, 82, 90, 94), L(3), fill=c)
    elif name == "tipi":
        d.polygon(P(50, 14, 90, 92, 10, 92), fill=c); d.polygon(P(50, 52, 62, 92, 38, 92), fill=nb)
        d.line(P(50, 18, 36, 2), fill=c, width=L(4)); d.line(P(50, 18, 64, 2), fill=c, width=L(4)); d.line(P(50, 18, 50, 0), fill=c, width=L(4))
        d.line(P(26, 60, 74, 60), fill=y_, width=L(4))
    elif name == "bow":
        d.arc(P(14, 6, 74, 94), 270, 90, fill=c, width=L(7)); d.line(P(44, 8, 44, 92), fill=c, width=L(2))
        d.line(P(10, 50, 92, 50), fill=y_, width=L(5)); d.polygon(P(92, 50, 78, 42, 78, 58), fill=y_)
        d.polygon(P(10, 50, 2, 42, 6, 50, 2, 58), fill=y_)
    elif name == "pyramid":   # Maya step pyramid
        for i, (x0, x1) in enumerate(((6, 94), (16, 84), (26, 74), (36, 64))):
            y1 = 94 - i * 18; d.rectangle(P(x0, y1 - 16, x1, y1), fill=c)
        d.rectangle(P(42, 4, 58, 22), fill=c); d.rectangle(P(46, 10, 54, 22), fill=nb)
        d.polygon(P(44, 94, 56, 94, 54, 26, 46, 26), fill=y_)
    elif name == "megaphone":
        d.polygon(P(14, 38, 60, 14, 60, 86, 14, 62), fill=c); d.rounded_rectangle(P(4, 36, 18, 64), L(4), fill=c)
        d.rectangle(P(22, 60, 34, 90), fill=c)
        for r in (12, 24): d.arc(P(66 - r + 6, 50 - r - 6, 66 + r + 6, 50 + r + 6), -40, 40, fill=y_, width=L(5))
    elif name == "ship":
        d.polygon(P(8, 62, 92, 62, 78, 86, 20, 86), fill=c); d.line(P(50, 10, 50, 62), fill=c, width=L(5))
        d.polygon(P(54, 14, 54, 56, 84, 56), fill=c); d.polygon(P(46, 22, 46, 56, 22, 56), fill=c)
    elif name == "home":
        d.polygon(P(8, 48, 50, 10, 92, 48), fill=c); d.rectangle(P(20, 46, 80, 92), fill=c)
        hx_, hy_ = 50, 66; r_ = RED[:3] + (255,)
        d.ellipse(P(hx_ - 15, hy_ - 14, hx_, hy_ + 1), fill=r_); d.ellipse(P(hx_, hy_ - 14, hx_ + 15, hy_ + 1), fill=r_)
        d.polygon(P(hx_ - 15, hy_ - 4, hx_ + 15, hy_ - 4, hx_, hy_ + 16), fill=r_)
    elif name == "nope":      # red cross-out ring
        d.ellipse(P(4, 4, 96, 96), outline=RED[:3] + (255,), width=L(9)); d.line(P(18, 82, 82, 18), fill=RED[:3] + (255,), width=L(9))
    im = im.resize((sz, sz), Image.LANCZOS); _ic[k] = im; return im
def put_icon(im, name, cx, cy, sz, col=WHITE, a=1.0): put(im, icon(name, int(sz), col), cx, cy, a)

# ------------------------------------------------------------------ rivers
RIV = {}
for f in json.load(open(f"{D}/geo/rivers.geojson"))["features"]:
    n = f["properties"].get("name"); g = f["geometry"]
    if n in ("Rhine", "Mississippi", "Uruguay", "Usumacinta", "Jordan"):
        RIV.setdefault(n, []).extend(g["coordinates"] if g["type"] == "MultiLineString" else [g["coordinates"]])
RIV["Rhine"].append([[7.59, 47.56], [7.57, 47.85], [7.58, 48.03], [7.68, 48.30], [7.80, 48.58], [7.98, 48.80], [8.23, 48.97]])
# reveal order: scalar along the flow (source -> mouth)
FLOW = {"Rhine": lambda lo, la: la, "Mississippi": lambda lo, la: -la, "Uruguay": lambda lo, la: -la,
        "Usumacinta": lambda lo, la: la, "Jordan": lambda lo, la: -la}

# ------------------------------------------------------------------ map scenes
MAP_RECT = (40, 560, 1040, 1500)
class MapScene:
    def __init__(self, box, target, river, free_side=None, israel=False, extra_hi=()):
        self.P = Proj(box, MAP_RECT); self.river = river; self.israel = israel
        F = features(); arr = np.zeros((H, W, 3), np.float32) + np.array(SEA, np.float32)
        L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ld = ImageDraw.Draw(L)
        for k, f in F.items():
            m = mask(f["polys"], self.P)
            if m is None: continue
            comp(arr, m, LAND)
        if israel:
            israel_layer(self.P, arr)
        else:
            mt = mask(F[target]["polys"], self.P); comp(arr, mt, TARGET)
            if free_side is not None:   # US: land between the river and the Pacific
                pts = sorted([p for seg in RIV[river] for p in seg], key=lambda p: -p[1])
                poly = [[(-140, pts[0][1] + 8)] + [tuple(p) for p in pts] + [(pts[-1][0], 20), (-140, 20)]]
                mz = mask([poly], self.P)
                x0, y0, A = mt; z = np.zeros((H, W), np.float32); z[y0:y0 + A.shape[0], x0:x0 + A.shape[1]] = A
                x1, y1, B = mz; z2 = np.zeros((H, W), np.float32); z2[y1:y1 + B.shape[0], x1:x1 + B.shape[1]] = B
                comp(arr, (0, 0, z * z2), FREE)
        self.base = Image.fromarray(arr.clip(0, 255).astype(np.uint8), "RGB").convert("RGBA")
        d = ImageDraw.Draw(self.base)
        for k, f in F.items(): outline(d, f["polys"], self.P, LAND_E + (255,), 2)
        if israel: israel_lines(d, self.P)
        # river polylines in screen space with flow value per point
        fl = FLOW[river]; self.segs = []
        for seg in RIV[river]:
            self.segs.append([(self.P(lo, la), fl(lo, la)) for lo, la in seg])
        vals = [v for s in self.segs for _, v in s]; self.v0, self.v1 = min(vals), max(vals)
    def frame(self, t, t0, z0=1.0, z1=1.06, dur=6.0, dim=0.0, prog=1.0):
        z = z0 + (z1 - z0) * ease((t - t0) / dur)
        im = self.base
        if z != 1.0:
            w2, h2 = int(W * z), int(H * z); cx, cy = 540, (MAP_RECT[1] + MAP_RECT[3]) / 2
            big = im.resize((w2, h2), Image.BILINEAR); ox, oy = int(cx * z - cx), int(cy * z - cy)
            im = big.crop((ox, oy, ox + W, oy + H))
        else: im = im.copy()
        def zp(p): return (540 + (p[0] - 540) * z, (MAP_RECT[1] + MAP_RECT[3]) / 2 + (p[1] - (MAP_RECT[1] + MAP_RECT[3]) / 2) * z)
        L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ld = ImageDraw.Draw(L)
        thr = self.v0 + (self.v1 - self.v0) * prog
        for seg in self.segs:
            pts = []
            for k, (p, v) in enumerate(seg):
                if v <= thr: pts.append(zp(p))
                elif k > 0 and seg[k - 1][1] <= thr:
                    pv, vv = seg[k - 1]; u = (thr - vv) / max(1e-9, v - vv)
                    pts.append(zp((pv[0] + (p[0] - pv[0]) * u, pv[1] + (p[1] - pv[1]) * u)))
            if len(pts) > 1:
                ld.line(pts, fill=RIVER + (70,), width=26, joint="curve"); ld.line(pts, fill=RIVER + (255,), width=10, joint="curve")
        im.alpha_composite(L)
        if dim > 0: im.alpha_composite(Image.new("RGBA", (W, H), (6, 14, 34, int(255 * dim))))
        return im, zp

_bands = None
def bands(im):
    global _bands
    if _bands is None:
        a = np.zeros((H, W, 4), np.uint8); a[..., :3] = (6, 14, 34)
        y = np.arange(H)
        top = np.clip(1 - (y - 470) / 160, 0, 1) * 0.86; bot = np.clip((y - 1480) / 140, 0, 1) * 0.8
        a[..., 3] = (np.maximum(top, bot) * 255).astype(np.uint8)[:, None]
        _bands = Image.fromarray(a, "RGBA")
    im.alpha_composite(_bands)

def lay(): return Image.new("RGBA", (W, H), (0, 0, 0, 0))
def box(im, x0, y0, x1, y1, a, fill=(10, 24, 58), alpha=0.92, line=SKY, r=36):
    L = lay(); ld = ImageDraw.Draw(L)
    ld.rounded_rectangle([x0, y0, x1, y1], r, fill=fill + (int(255 * alpha * a),), outline=line[:3] + (int(230 * a),), width=5)
    im.alpha_composite(L)

# ------------------------------------------------------------------ the four chants
BEATS = [
    dict(i=0, box=(-5.2, 41.3, 9.6, 51.6), tgt="FRA", river="Rhine", r1="FROM THE RHINE", r2="TO THE ATLANTIC,",
         who="FRANCE", cc="FR", sea=("ATLANTIC", (-4.6, 46.2)), rlab=("RHINE", (8.3, 50.4)),
         give="GAULS!", gicon="helmet", gsub="Here before the Franks", gsrc="Britannica: Franks, Clovis I (486 CE)"),
    dict(i=2, box=(-125, 24.5, -66, 49.5), tgt="USA", river="Mississippi", r1="FROM THE MISSISSIPPI", r2="TO THE PACIFIC,",
         who="AMERICA", cc="US", sea=("PACIFIC", (-121.5, 29.5)), rlab=("MISSISSIPPI", (-84.5, 37.5)), free=True,
         give="LAKOTA & COMANCHE!", gicon="tipi", gsub="Great Plains nations, before the US", gsrc="Britannica: Lakota; Comanche; Plains Indian"),
    dict(i=4, box=(-59.2, -35.4, -52.6, -29.8), tgt="URY", river="Uruguay", r1="FROM THE URUGUAY", r2="TO THE ATLANTIC,",
         who="URUGUAY", cc="UY", sea=("ATLANTIC", (-52.6, -32.2)), rlab=("URUGUAY RIVER", (-56.4, -30.2)),
         give="CHARRÚA!", gicon="bow", gsub="Uruguay's first people", gsrc="Britannica: Charrúa; Uruguay River"),
    dict(i=6, box=(-112, 14.6, -86.2, 31.0), tgt="MEX", river="Usumacinta", r1="FROM THE USUMACINTA", r2="TO THE GULF,",
         who="MEXICO", cc="MX", sea=("GULF OF MEXICO", (-92.5, 24.8)), rlab=("USUMACINTA", (-90.6, 19.4)),
         give="MAYA!", gicon="pyramid", gsub="Maya cities lined this river", gsrc="Britannica: Maya; Usumacinta River"),
]
print("building maps", file=sys.stderr)
for b in BEATS: b["M"] = MapScene(b["box"], b["tgt"], b["river"], free_side=b.get("free"))
ISR = MapScene((33.9, 29.45, 36.0, 33.35), None, "Jordan", israel=True)

def chant_scene(im, t, b):
    """t inside [S(i), S(i+2)): chant (line i) then give-back (line i+1)"""
    i = b["i"]; t0 = S(i); tg = S(i + 1)
    prog = ease((t - t0 - 0.15) / 1.3) if i == 0 else ease((t - t0 - 0.1) / 1.2)
    dim = 0.62 * ease((t - tg) / 0.35)
    m, zp = b["M"].frame(t, t0, 1.0, 1.07, (S(i + 2) if i + 2 < len(Ls) else DUR) - t0, dim, prog)
    im.alpha_composite(m); d = ImageDraw.Draw(im)
    a_chant = 1 - ease((t - tg) / 0.3)
    if a_chant > 0.01:
        # labels on the map
        sl, sp = b["sea"]; p = zp(b["M"].P(*sp)); hw = tw(sl, 56, 900) / 2 + 10; T_(d, max(40 + hw, min(1040 - hw, p[0])), p[1], sl, 56, SKY_L, 900, "mm", a_chant, 4, 1000)
        rl, rp = b["rlab"]; p = zp(b["M"].P(*rp)); hw = tw(rl, 54, 900) / 2 + 10; T_(d, max(40 + hw, min(1040 - hw, p[0])), p[1], rl, 54, WHITE, 900, "mm", a_chant * prog, 4, 1000)
        bands(im); d = ImageDraw.Draw(im)
        put_icon(im, "megaphone", 120, 250 + 0, 110, WHITE, a_chant); d = ImageDraw.Draw(im)
        T_(d, W / 2, 372, b["r1"], 116, WHITE, 900, "mm", a_chant, maxw=1000)
        T_(d, W / 2, 496, b["r2"], 116, YEL, 900, "mm", a_chant, maxw=1000)
        # the sign: WHO WILL BE FREE!
        ts = WF(i, b["who"].lower(), 1 if b["who"] == "URUGUAY" else 0)
        u = ease((t - ts) / 0.22)
        if u > 0.01:
            pop = 1 + 0.10 * math.sin(min(1, (t - ts) / 0.35) * math.pi)
            y0 = 1420; hh = 250 * pop
            box(im, 70, y0 - hh / 2, 1010, y0 + hh / 2, u * a_chant, fill=(120, 24, 34), alpha=0.95, line=WHITE)
            flag(im, b["cc"], 170, y0, 130 * pop, u * a_chant); d = ImageDraw.Draw(im)
            T_(d, 600, y0 - 52 * pop, b["who"], 104 * pop, YEL, 900, "mm", u * a_chant, maxw=740)
            T_(d, 600, y0 + 58 * pop, "WILL BE FREE!", 92 * pop, WHITE, 900, "mm", u * a_chant, maxw=740)
    a_g = ease((t - tg) / 0.3)
    if a_g > 0.01:
        d = ImageDraw.Draw(im)
        if i == 0 and t < WF(1, "give"):
            # France is named after its invaders, the Franks
            T_(d, W / 2, 380, "FRANCE", 150, WHITE, 900, "mm", a_g)
            T_(d, W / 2, 520, "is named after", 84, SKY_L, 900, "mm", a_g)
            put_icon(im, "sword", 300, 860, 330, WHITE, a_g); put_icon(im, "crown", 760, 860, 300, YEL, a_g); d = ImageDraw.Draw(im)
            T_(d, W / 2, 1150, "the FRANKS", 130, YEL, 900, "mm", a_g)
            T_(d, W / 2, 1290, "Germanic invaders", 80, WHITE, 900, "mm", a_g)
            T_(d, W / 2, 1520, "Britannica: Franks; Clovis I took Gaul, 486 CE", 38, SILVER, 700, "mm", a_g, maxw=1000)
        else:
            tk = WF(i + 1, "give"); v = a_g * ease((t - tk) / 0.3)
            T_(d, W / 2, 360, "Give it back", 112, WHITE, 900, "mm", v)
            T_(d, W / 2, 480, "to the", 84, SKY_L, 900, "mm", v)
            put_icon(im, b["gicon"], W / 2, 830, 420, WHITE, v); d = ImageDraw.Draw(im)
            T_(d, W / 2, 1160, b["give"], 140, YEL, 900, "mm", v, maxw=1000)
            T_(d, W / 2, 1290, b["gsub"], 70, WHITE, 900, "mm", v, maxw=1000)
            T_(d, W / 2, 1520, b["gsrc"], 38, SILVER, 700, "mm", v, maxw=1000)

def silly_scene(im, t):
    t0 = S(8); a = ease((t - t0) / 0.3)
    im.alpha_composite(BG)
    d = ImageDraw.Draw(im)
    T_(d, W / 2, 330, "Wow.", 130, WHITE, 900, "mm", a)
    T_(d, W / 2, 460, "How does that sound?", 88, SKY_L, 900, "mm", ease((t - WF(8, "how")) / 0.3))
    for k, (cc, nm) in enumerate((("FR", "FRANCE"), ("US", "AMERICA"), ("UY", "URUGUAY"), ("MX", "MEXICO"))):
        cx = 290 + (k % 2) * 500; cy = 720 + (k // 2) * 340; u = ease((t - t0 - 0.15 * k) / 0.3)
        box(im, cx - 230, cy - 150, cx + 230, cy + 150, u, fill=(14, 30, 70), alpha=0.9, line=SKY)
        flag(im, cc, cx, cy - 40, 190, u); d = ImageDraw.Draw(im)
        T_(d, cx, cy + 95, nm + " FREE!", 52, WHITE, 900, "mm", u, maxw=420)
    v = ease((t - WF(8, "silly")) / 0.25)
    if v > 0.01:
        pop = 1 + 0.08 * math.sin(min(1, (t - WF(8, "silly")) / 0.35) * math.pi)
        T_(d, W / 2, 1300, "Silly, right?", 140 * pop, YEL, 900, "mm", v)

def israel_scene(im, t):
    t9, t10, t11, t12, t13, t14 = S(9), S(10), S(11), S(12), S(13), S(14)
    prog = ease((t - t10 - 0.1) / 1.4) if t >= t10 else 0.0
    dim = 0.0
    if t >= t13: dim = 0.6 * ease((t - t13) / 0.3)
    m, zp = ISR.frame(t, t9, 1.0, 1.08, t14 - t9, dim, prog)
    im.alpha_composite(m); d = ImageDraw.Draw(im)
    if t < t13 and not (t11 <= t < t12):
        p = zp(ISR.P(34.15, 32.0)); T_(d, p[0], p[1], "MEDITERRANEAN", 54, SKY_L, 900, "mm", 1 if t >= t10 else 0.0, 4, 420)
        p = zp(ISR.P(34.15, 31.55)); T_(d, p[0], p[1], "SEA", 54, SKY_L, 900, "mm", 1 if t >= t10 else 0.0, 4, 420)
        p = zp(ISR.P(35.85, 32.35)); T_(d, min(980, p[0] + 40), p[1], "JORDAN", 50, WHITE, 900, "mm", prog, 4, 300)
        p = zp(ISR.P(35.85, 32.1)); T_(d, min(980, p[0] + 40), p[1], "RIVER", 50, WHITE, 900, "mm", prog, 4, 300)
    bands(im); d = ImageDraw.Draw(im)
    if t < t10:
        a = ease((t - t9) / 0.3)
        T_(d, W / 2, 372, "Now say it", 116, WHITE, 900, "mm", a)
        T_(d, W / 2, 496, "about Israel.", 116, YEL, 900, "mm", a)
        flag(im, "IL", W / 2, 1250, 230, ease((t - WF(9, "israel")) / 0.3))
    elif t < t11:
        put_icon(im, "megaphone", 120, 250, 110, WHITE, 1); d = ImageDraw.Draw(im)
        T_(d, W / 2, 372, "FROM THE RIVER", 116, WHITE, 900, "mm", 1)
        T_(d, W / 2, 496, "TO THE SEA...", 116, YEL, 900, "mm", 1)
        tg = WF(10, "give"); u = ease((t - tg) / 0.25)
        if u > 0.01:
            pop = 1 + 0.1 * math.sin(min(1, (t - tg) / 0.35) * math.pi)
            box(im, 70, 1420 - 125 * pop, 1010, 1420 + 125 * pop, u, fill=(120, 24, 34), alpha=0.95, line=WHITE); d = ImageDraw.Draw(im)
            T_(d, W / 2, 1420 - 50 * pop, "Give it back", 90 * pop, WHITE, 900, "mm", u)
            T_(d, W / 2, 1420 + 58 * pop, "to WHO?", 104 * pop, YEL, 900, "mm", u)
    elif t < t12:
        stele(im, t, t11, t12)
    elif t < t13:
        a = ease((t - t12) / 0.3)
        T_(d, W / 2, 372, "The word JEW", 112, WHITE, 900, "mm", a)
        T_(d, W / 2, 496, "comes from JUDAH", 112, YEL, 900, "mm", ease((t - WF(12, "comes")) / 0.3))
        rh = ease((t - WF(12, "right")) / 0.3)
        c = zp(ISR.P(35.12, 31.62)); r = 120 + 10 * math.sin(t * 6)
        L = lay(); ld = ImageDraw.Draw(L)
        ld.ellipse([c[0] - r, c[1] - r, c[0] + r, c[1] + r], outline=YEL[:3] + (int(255 * max(rh, 0.0)),), width=10)
        im.alpha_composite(L); d = ImageDraw.Draw(im)
        T_(d, c[0] - 250 if c[0] > 600 else c[0] + 250, c[1] - 10, "JUDAH", 84, YEL, 900, "mm", rh, 5, 380)
        T_(d, W / 2, 1520, "Hebrew Yehudi, from Yehudah. Britannica: Jew; Judah", 38, SILVER, 700, "mm", a, maxw=1000)
    elif t < t14:
        a = ease((t - t13) / 0.3); b = ease((t - WF(13, "judea", 1)) / 0.3)
        put_icon(im, "ship", W / 2, 420, 250, WHITE, a); put_icon(im, "nope", W / 2, 420, 300, WHITE, a); d = ImageDraw.Draw(im)
        T_(d, W / 2, 660, "Jews didn't colonize", 96, WHITE, 900, "mm", a)
        T_(d, W / 2, 770, "Judea.", 96, WHITE, 900, "mm", a)
        put_icon(im, "home", W / 2, 1040, 250, WHITE, b); d = ImageDraw.Draw(im)
        T_(d, W / 2, 1270, "Judea is where", 100, YEL, 900, "mm", b)
        T_(d, W / 2, 1385, "Jews come from.", 100, YEL, 900, "mm", b)

STELE = Image.open("/home/claude/reels-drop/photos/pf_mern1.jpg").convert("RGBA")
def stele(im, t, t0, t1):
    a = ease((t - t0) / 0.3)
    im.alpha_composite(Image.new("RGBA", (W, H), (6, 14, 34, int(245 * a))))
    z = 1.0 + 0.06 * ease((t - t0) / (t1 - t0)); h = int(1000 * z); w = int(h * STELE.width / STELE.height)
    ph = STELE.resize((w, h), Image.LANCZOS)
    cw, ch = 560, 1000
    m = Image.new("L", (cw, ch), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, cw - 1, ch - 1], 36, fill=255)
    crop = ph.crop(((w - cw) // 2, (h - ch) // 2, (w - cw) // 2 + cw, (h - ch) // 2 + ch))
    crop.putalpha(Image.fromarray((np.asarray(m, np.float32) * a).astype(np.uint8)))
    im.alpha_composite(crop, (50, 330)); d = ImageDraw.Draw(im)
    T_(d, 815, 520, "ISRAEL", 112, YEL, 900, "mm", a, maxw=420)
    T_(d, 815, 640, "carved in", 70, WHITE, 900, "mm", a, maxw=420)
    T_(d, 815, 725, "stone", 70, WHITE, 900, "mm", a, maxw=420)
    b = ease((t - WF(11, "over")) / 0.3)
    T_(d, 815, 900, "3,200", 110, YEL, 900, "mm", b, maxw=420)
    T_(d, 815, 1000, "years ago", 70, WHITE, 900, "mm", b, maxw=420)
    T_(d, 815, 1130, "c. 1208 BCE", 64, SKY_L, 900, "mm", b, maxw=420)
    T_(d, W / 2, 1420, "Merneptah Stele, Egypt. Egyptian Museum, Cairo", 40, SILVER, 700, "mm", a, maxw=1000)
    T_(d, W / 2, 1480, "Photo: Webscribe, CC BY-SA 3.0, Wikimedia Commons", 36, SILVER, 700, "mm", a, maxw=1000)

BG = stage()
def chant_end(im, t):
    """line 14 (how silly) and line 15 (lead-in) then crossfade (Out) into frame 0"""
    t14, t15 = S(14), S(15)
    im.alpha_composite(BG); d = ImageDraw.Draw(im)
    if t < t15:
        a = ease((t - t14) / 0.3)
        put_icon(im, "megaphone", W / 2, 640, 380, WHITE, a); d = ImageDraw.Draw(im)
        T_(d, W / 2, 1000, "How silly", 140, WHITE, 900, "mm", a)
        T_(d, W / 2, 1140, "does that chant", 110, WHITE, 900, "mm", a)
        T_(d, W / 2, 1260, "sound now?", 110, YEL, 900, "mm", a)
    else:
        a = ease((t - t15) / 0.3)
        T_(d, W / 2, 400, "Fine.", 130, WHITE, 900, "mm", a)
        T_(d, W / 2, 540, "Let's free everyone.", 100, YEL, 900, "mm", ease((t - WF(15, "lets")) / 0.3))
        for k, cc in enumerate(("FR", "US", "UY", "MX", "GB", "ES", "AU", "CA")):
            cx = 180 + (k % 4) * 240; cy = 800 + (k // 4) * 220; u = ease((t - WF(15, "lets") - 0.06 * k) / 0.25)
            flag(im, cc, cx, cy, 190, u)
        d = ImageDraw.Draw(im)
        v = ease((t - WF(15, "ready")) / 0.25)
        T_(d, W / 2, 1330, "Ready?", 150, WHITE, 900, "mm", v)

_REP = [("three thousand", "3,000"), ("Charrua", "Charrúa")]
SUBS = sub_chunks(T, _REP)
if __name__ == "__main__":
    out = Out(RID, DUR, snaps_arg())
    for f, t in out.frames():
        im = Image.new("RGBA", (W, H), (6, 14, 34, 255))
        if t < S(8):
            for k, b in enumerate(BEATS):
                if t < (BEATS[k + 1]["i"] and S(BEATS[k + 1]["i"]) if k + 1 < len(BEATS) else S(8)):
                    chant_scene(im, t, b); break
        elif t < S(9): silly_scene(im, t)
        elif t < S(14): israel_scene(im, t)
        else: chant_end(im, t)
        draw_sub(im, SUBS, t)
        out.put(f, t, im)
    out.close()
