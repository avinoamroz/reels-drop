"""join2.py: raw Cartesia p0 -> vo.wav + vo_words.json with custom comic gaps between lines (no squeeze)."""
import json, wave, re, numpy as np
D = "/home/claude/river_sea_skit"; SR = 44100
def norm(s): return re.sub(r"[^\w]", "", s.lower())
w = wave.open(f"{D}/p0.wav"); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32)
W = json.load(open(f"{D}/p0_words.json"))
lines = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
def t_at(f):
    for f0, f1, s, e in spans:
        if f <= f1 + 1e-9:
            u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
    return spans[-1][3]
sw = " ".join(lines).split(); sn = [norm(x) for x in sw]; stot = sum(max(1, len(x)) for x in sn); pos = 0; mine = []
for x, n_ in zip(sw, sn):
    L = max(1, len(n_)); f0, f1 = pos / stot, (pos + L) / stot; pos += L
    mine.append(dict(word=x, start=t_at(f0 + 1e-6), end=t_at(f1 - 1e-6)))
# gap AFTER each line (s): chant -> give back short beat, give back -> next chant longer
GAPS = [0.55, 0.85, 0.55, 0.85, 0.55, 0.8, 0.55, 1.0, 0.75, 0.7, 0.8, 0.6, 0.7, 0.9, 0.7, 0.5]
MAXIN = 0.45   # pauses inside a line squeezed to this
out, words, t_out, i = [], [], 0.0, 0
for li, l in enumerate(lines):
    n = len(l.split()); ws = mine[i:i + n]; i += n
    s0 = max(0, ws[0]["start"] - 0.06); e0 = min(len(a) / SR, ws[-1]["end"] + 0.14)
    # inner pauses
    cuts = []
    for k in range(n - 1):
        g0, g1 = ws[k]["end"], ws[k + 1]["start"]
        if g1 - g0 > MAXIN: ex = g1 - g0 - MAXIN; m = (g0 + g1) / 2; cuts.append((m - ex / 2, m + ex / 2))
    keep = []; cur = s0
    for c0, c1 in cuts: keep.append((cur, c0)); cur = c1
    keep.append((cur, e0))
    def mp(t, base=t_out):
        acc = 0.0
        for k0, k1 in keep:
            if t <= k1: return base + acc + max(0, t - k0)
            acc += k1 - k0
        return base + acc
    for x in ws: words.append(dict(word=x["word"], start=round(mp(x["start"]), 4), end=round(mp(max(x["end"], x["start"] + 0.04)), 4)))
    for k0, k1 in keep:
        seg = a[int(k0 * SR):int(k1 * SR)].copy(); f = min(len(seg), int(0.01 * SR))
        seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f); out.append(seg); t_out += len(seg) / SR
    g = GAPS[li]; out.append(np.zeros(int(g * SR), np.float32)); t_out += g
y = np.concatenate(out).clip(-32768, 32767).astype(np.int16)
with wave.open(f"{D}/vo.wav", "wb") as o: o.setnchannels(1); o.setsampwidth(2); o.setframerate(SR); o.writeframes(y.tobytes())
json.dump(words, open(f"{D}/vo_words.json", "w"), indent=0)
print("vo", round(len(y) / SR, 2), len(words))
