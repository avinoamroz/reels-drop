"""Bespoke reelkit scene for the 30 Oct re-hooks: pm_timeline.
A year counter that is already rolling at frame 0, three podium slots (#3 is a pulsing '?' until its mark),
and a 2-column grid of later entries that pop on their marks (one every ~1.5 to 3 s), dimmed once #3 is revealed.
Spec: {"type": "pm_timeline", "line": 1, "title", "title_he", "slots": [3 x {flag, en, he, year, name}],
       "later": [{flag, en, he, year, color}], "after_en", "after_he", "marks": {s0, s1, s2, after, l0..}, "source"}"""
import math
import render as RD
from render import P, T, PP, fade_in, heading, source, shadow_box, draw_emoji, icon_of, col, pill, CONTENT_BOTTOM
from kit import ease, ramp, lerp, St, sa, rr

def _year(t, S):
    """counter: rolls 1900 -> first slot year during the hook, then counts to each new entry's year; rewinds at the reveal"""
    tm = S["times"]; sl = S["slots"]; lt = S["later"]
    keys = [(tm["s0"], sl[0]["year"]), (tm["s1"], sl[1]["year"])]
    keys += [(tm[f"l{k}"], it["year"]) for k, it in enumerate(lt) if f"l{k}" in tm]
    keys += [(tm["s2"], sl[2]["year"])]
    keys.sort()
    if t < keys[0][0]:
        u = ease(t / max(0.3, keys[0][0])); return int(round(lerp(1900, keys[0][1], u)))
    prev = keys[0][1]
    for k in range(1, len(keys)):
        tk, yk = keys[k]
        if t < tk: return prev
        d = 0.9 if k == len(keys) - 1 else 0.55
        if t < tk + d: return int(round(lerp(prev, yk, ease((t - tk) / d))))
        prev = yk
    return prev

def sc_pm_timeline(c, t, S):
    tm = S["times"]; y = heading(c, t, S)
    rev = tm["s2"]; revd = t >= rev - 0.05
    # year counter (moving from frame 0)
    yr = _year(t, S); cy = y + 62
    shadow_box(c, 330, cy - 58, 420, 116, 58, P["navy"], sw=0, sh=6)
    rr(c, 330, cy - 58, 420, 116, 58); sa(c, P["gold"]); c.set_line_width(5); c.stroke()
    T(c, str(yr), 96, 540, cy + 4, P["gold2"], 1, 1.0 + (0.08 * (1 - ease((t - rev) / 0.5)) if 0 <= t - rev < 0.5 else 0), 900)
    # three slots
    y0 = cy + 82; ch = 270; cw = 300; gap = 30; x0s = [60 + k * (cw + gap) for k in range(3)]
    for k, sl in enumerate(S["slots"]):
        x0 = x0s[k]; cx = x0 + cw / 2; tk = tm[f"s{k}"]; shown = t >= tk - 0.07
        gold = k == 2 and revd
        shadow_box(c, x0, y0, cw, ch, 28, P["card"], stroke=P["gold"] if gold else col(None, "silver"), sw=8 if gold else 3, sh=6)
        T(c, f"#{k + 1}", 44, cx, y0 + 40, P["gold_text"], 1, 1, 900)
        if not shown:
            pulse = 1 + 0.07 * math.sin(t * 5.2 + k)
            T(c, "?", 150, cx, y0 + 155, P["silver"] if k < 2 else P["blue"], 1, pulse, 900)
            continue
        a, s = PP(t, tk, S, s0=0.4, bounce=2.2 if k == 2 else 1.6)
        old = St.a; St.a *= a; c.save(); c.translate(cx, y0 + ch / 2); c.scale(s, s); c.translate(-cx, -(y0 + ch / 2))
        draw_emoji(c, icon_of(sl), cx, y0 + 108, 80)
        T(c, sl["en"], 46, cx, y0 + 172, P["navy"], 1, 1, 900, maxw=cw - 24)
        T(c, sl["he"], 38, cx, y0 + 212, P["gold_text"], 1, 1, 700, maxw=cw - 24)
        T(c, f"{sl['year']} · {sl['name']}", 30, cx, y0 + 248, P["blue"], 1, 1, 800, maxw=cw - 24)
        c.restore(); St.a = old
    # later entries
    ya = y0 + ch + 40
    if "after" in tm and t >= tm["after"] - 0.1:
        a, s = PP(t, tm["after"], S)
        T(c, S.get("after_en", ""), 42, 300, ya, P["navy"], a, s, 900, hl=P["red"], maxw=500)
        T(c, S.get("after_he", ""), 38, 800, ya, P["gold_text"], a, s, 700, maxw=420)
    lt = S["later"]; rows = -(-len(lt) // 2); top = ya + 34; rh = min(84, (CONTENT_BOTTOM - top) / max(1, rows)); bw = 465; bh = rh - 12
    dim = 0.45 if revd else 1.0
    for k, it in enumerate(lt):
        tk = tm.get(f"l{k}")
        if tk is None or t < tk - 0.07: continue
        r_, q = divmod(k, 2); x0 = 60 + q * (bw + 30); yy = top + r_ * rh + rh / 2
        a = fade_in(t, tk - 0.07, S, 0.18) * dim; u = ease((t - tk + 0.07) / 0.3)
        old = St.a; St.a *= a; c.save(); c.translate(0, 40 * (1 - u))
        shadow_box(c, x0, yy - bh / 2, bw, bh, bh / 2, P["card"], stroke=col(it.get("color"), "silver"), sw=3, sh=4)
        draw_emoji(c, icon_of(it), x0 + 40, yy, 42)
        lab = it["en"] if it.get("color") else f"{it['en']} {it['year']}"
        T(c, lab, 34, x0 + 74, yy + 2, col(it.get("color"), "navy"), 1, 1, 800, anchor="l", maxw=225)
        T(c, it["he"], 30, x0 + bw - 22, yy + 2, P["gold_text"], 1, 1, 700, anchor="r", maxw=180)
        c.restore(); St.a = old
    source(c, t, S)
