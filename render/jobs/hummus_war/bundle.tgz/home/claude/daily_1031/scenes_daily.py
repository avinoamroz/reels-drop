"""Daily scenes, 31 Oct 2026: ENGLISH ONLY, BIG TEXT, FULL SCREEN, CIRCULAR (Noam, 30 to 31 Oct).
Loaded by reelkit as the spec's scene_module, so the sc_* functions here replace the built-in ones of the same name.
- Layout: content uses the whole width (x 20..1060), headings 100 px, numbers 250 px. Key text stays between y 250 and
  y 1580 (top ~220 px and bottom ~330 px kept free for the IG UI). Sources sit under the content at y 1428 (34 px),
  subtitles at y 1530 (54 px).
- No Hebrew is drawn: any *_he / he field is ignored (build.py also strips them).
- Circular: the last 0.5 s cross-fade into the exact frame 0 (the last frame equals frame 0), and the music bed is cut on
  whole bars from bar 2 of the bed (past its fade-in) and time-fitted to the reel, so the loop lands on a downbeat.
Scene types: title, big_number, cards_grid, map_highlight, city_map, rows."""
import math, re
import numpy as np
import cairo
import render as RD
import kit
from render import P, T, pill, PP, fade_in, MapView, geo, _path, col, block, block_h, shadow_box, icon_of, draw_emoji, box, count, fmt, clean
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, FPS

TOP = 250; CB = 1400; X0, X1 = 20, 1060
RD.SUB_Y = 1530; RD.SOURCE_Y = 1428; RD.CONTENT_BOTTOM = CB
_subs = getattr(RD, "_subs_orig", RD.sub_surfs); RD._subs_orig = _subs
RD.sub_surfs = lambda pieces, sz=54, maxw=1000: _subs(pieces, sz, maxw)

def heading(c, t, S, y=TOP):
    en = S.get("title") or S.get("heading")
    if not en: return y - 30
    a, s = PP(t, S["t0"] + 0.05, S); h1 = block_h(en, 100, 900, 1010, 2)
    block(c, en, 100, 540, y + h1 / 2, P["navy"], a, s, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=2)
    return y + h1 + 30
RD.heading = heading

# ------------------------------------------------------------------ circular: last 0.5 s fade into frame 0
_draw = getattr(RD.Reel, "_draw_orig", RD.Reel.draw); RD.Reel._draw_orig = _draw
def _draw_loop(self, c, t):
    L = float(self.spec.get("loop_fade", 0.5))
    if t < self.T_END - L - 1e-6: return _draw(self, c, t)
    if not hasattr(self, "_f0"):
        s0 = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); _draw(self, cairo.Context(s0), 0.0); s0.flush(); self._f0 = s0
    _draw(self, c, t)
    u = min(1.0, max(0.0, (t - (self.T_END - L)) / max(1e-3, L - 1.0 / FPS)))
    c.set_source_surface(self._f0, 0, 0); c.paint_with_alpha(ease(u))
RD.Reel.draw = _draw_loop

# ------------------------------------------------------------------ circular: music bed cut on whole bars
try:
    import mix as MX
    BPM = {"journey": 100, "doc_piano": 86, "warm": 96, "bounce": 118, "skip": 104}
    _bed = getattr(MX, "_bed_orig", MX.bed); MX._bed_orig = _bed
    def bed_loop(name, dur, end_at=None):
        if name not in BPM: return _bed(name, dur, end_at)
        bar = 240.0 / BPM[name]; nb = max(4, int(round(dur / bar))); L = nb * bar; off = 2 * bar
        raw = _bed(name, off + L + 4.0, off + L + 4.0)          # long render, no ending inside the cut
        seg = raw[:, int(round(off * MX.SR)):int(round((off + L) * MX.SR))]
        n = int(dur * MX.SR); x = np.linspace(0, seg.shape[1] - 1, n)   # time-fit (under 3 %) so the cut ends on a downbeat
        out = np.vstack([np.interp(x, np.arange(seg.shape[1]), ch) for ch in seg])
        f = int(0.012 * MX.SR); out[:, :f] *= np.linspace(0, 1, f); out[:, -f:] *= np.linspace(1, 0, f)
        return out / (np.abs(out).max() + 1e-12)
    MX.bed = bed_loop
except Exception as e:   # preview without mix still works
    print("bed_loop not installed:", e)

# ------------------------------------------------------------------ scenes
def sc_title(c, t, S):
    en = S.get("en"); em = icon_of(S); size = S.get("size", 118)
    h_en = block_h(en, size, 900, 1010, 3); total = (270 if em else 0) + h_en + 40
    y = max(300, (TOP + CB) / 2 - total / 2); t0 = S["t0"]
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 120 + 10 * math.sin(t * 2.6), 230, a, s * (1 + 0.03 * math.sin(t * 3.1))); y += 270
    a, s = PP(t, t0 + 0.08, S); breath = 1 + 0.012 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, size, 540, y + h_en / 2, P["navy"], a, s * breath, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=3); y += h_en
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 380 * u, y + 10, 760 * u, 14, 7, P["gold"], a)
    RD.source(c, t, S)

def sc_big_number(c, t, S):
    y = heading(c, t, S); steps = S["steps"]; ts = S["times"]["steps"]
    cy = max(y + 340, 820); x0, x1, y0, y1 = X0 + 10, X1 - 10, cy - 320, cy + 320
    a, s = PP(t, S["t0"] + 0.1, S, s0=0.6, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
    shadow_box(c, x0, y0, x1 - x0, y1 - y0, 34, P["card"], stroke=P["navy"], sw=7)
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]; dec = st.get("decimals", 0)
    hk = S.get("hook") and ts[0] <= RD.HOOK_GRACE
    if k == 0: v = st["value"] if hk else count(t, ts[0], st.get("dur", 1.2), st.get("from", 0), st["value"])
    else:
        pv = steps[k - 1]["value"]; big = max(abs(pv), abs(st["value"])) / max(1e-9, min(abs(pv), abs(st["value"]))) > 20
        v = count(t, ts[k], st.get("dur", 1.3), pv, st["value"], log=big)
    if t < ts[0] - 0.05 and not hk: v = st.get("from", 0)
    num = f"{v:.{dec}f}" if S.get("year") else fmt(v, dec)
    lab = clean(f"{st.get('prefix', '')}{num}{st.get('suffix', '')}")
    T(c, lab, S.get("size", 250), 540, cy - 80, col(st.get("color"), "blue"), 1.0, 1.0, 900, maxw=960)
    pa = ramp(t, ts[k] - 0.05, ts[k] + 0.25) if k else 1.0
    hl_ = block_h(st.get("label", ""), 76, 800, 940, 2)
    block(c, st.get("label", ""), 76, 540, cy + 130 + hl_ / 2 - 38, P["navy"], pa, 1.0, 800, hl=P["gold_text"], maxw=940, max_lines=2)
    c.restore(); St.a = old
    if S.get("note"):
        a2, s2 = PP(t, S["times"].get("note", S["t0"] + 1.5), S, bounce=2.4)
        pill(c, S["note"], 58, 540, min(y1 + 105, CB - 30), col(S.get("note_color"), "navy"), P["white"], a2, s2, outline=P["gold"])
    RD.source(c, t, S)

def sc_cards_grid(c, t, S):
    y = heading(c, t, S) + 10; cards = S["cards"]; ts = S["times"]["cards"]; n = len(cards)
    cols = S.get("cols", 2 if n <= 4 else 3); rows = -(-n // cols)
    gap = 24; WW = X1 - X0 - 20; cw = (WW - gap * (cols - 1)) / cols; avail = CB - y - 10
    ch = min(cw * 1.5, (avail - gap * (rows - 1)) / rows)
    for k, cd in enumerate(cards):
        r_, q = divmod(k, cols); in_row = min(cols, n - r_ * cols)
        x0 = X0 + 10 + (WW - (in_row * cw + (in_row - 1) * gap)) / 2 + q * (cw + gap); y0 = y + r_ * (ch + gap)
        a, s = PP(t, ts[k], S, s0=0.5, bounce=1.6)
        if a <= 0.01: continue
        cx, cy = x0 + cw / 2, y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
        shadow_box(c, x0, y0, cw, ch, 28, P["card"], stroke=col(cd.get("color"), "navy"), sw=5)
        parts = []; isz = min(cw, ch) * 0.34
        if icon_of(cd): parts.append(("i", isz + 10))
        if cd.get("value"): parts.append(("v", 120))
        hl_ = block_h(cd.get("label"), 58, 800, cw - 36, 3); parts.append(("l", hl_))
        yy = cy - sum(p[1] for p in parts) / 2
        for kind, hgt in parts:
            if kind == "i": draw_emoji(c, icon_of(cd), cx, yy + hgt / 2, isz, rot=0.04 * math.sin(t * 2 + k))
            if kind == "v": T(c, cd["value"], min(110, cw * 0.26), cx, yy + hgt / 2, col(cd.get("value_color") or cd.get("color"), "blue"), 1, 1, 900, maxw=cw - 30)
            if kind == "l": block(c, cd.get("label"), 58, cx, yy + hgt / 2, P["navy"], 1, 1, 800, maxw=cw - 36, max_lines=3)
            yy += hgt
        c.restore(); St.a = old
    RD.source(c, t, S)

def sc_rows(c, t, S):
    y = heading(c, t, S); items = S["items"]; n = len(items)
    rh = min(300, (CB - y - 20) / max(1, n)); bh = rh - 26
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2)
    for k, it in enumerate(items):
        tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        if t < tk - 0.07 and not hk: continue
        a = 1.0 if hk else fade_in(t, tk - 0.07, S, 0.2); u = 1.0 if hk else ease((t - tk + 0.07) / 0.35)
        yy = y + rh * k + rh / 2; dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, X0 + 10, yy - bh / 2, X1 - X0 - 20, bh, min(44, bh / 2.6), P["card"], stroke=col(it.get("color"), "silver"), sw=4, sh=6)
        em = icon_of(it); xt = 540
        if em: draw_emoji(c, em, 120, yy, min(100, bh * 0.5)); xt = 590
        block(c, it.get("en", ""), min(74, bh * 0.36), xt, yy, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=840 if em else 980, max_lines=2)
        c.restore(); St.a = old
    RD.source(c, t, S)

ISRAEL_VIEW = [33.9, 29.35, 36.1, 33.45]
def _base(S, view, box_, G):
    keep = St.a; St.a = 1.0
    mv = MapView(view, box_); base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
    bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
    for k, v in G.items():
        rg = mv.rings(v["g"], 0.6)
        if not rg: continue
        _path(bc, rg); sa(bc, P["gold"] if k in ("IL", "PS") else P["land"]); bc.fill_preserve()
        sa(bc, P["border"]); bc.set_line_width(1.6); bc.stroke()
    if "PS" in G:   # the Green Line in green (house rule)
        rg = mv.rings(G["PS"]["g"], 0.3)
        if rg: _path(bc, rg); sa(bc, P["green"]); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
    St.a = keep; return mv, base

def sc_city_map(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB)
    if "_mv" not in S: S["_mv"], S["_base"] = _base(S, S.get("view", ISRAEL_VIEW), box_, geo())
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"])))
    z = lerp(1.0, S.get("zoom", 1.08), ease(u)); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    shown = []
    for k, p in enumerate(S.get("points", [])):
        tk = S["times"].get(f"p{k}", S["t0"] + 0.4 + 0.8 * k); hk = S.get("hook") and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); cc = col(p.get("color"), "navy")
        pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 22 + 80 * (1 - pr), P["white"], 0.5 * pr * uu)
        circ(c, px, py, 24 * uu, P["white"], uu); circ(c, px, py, 16 * uu, cc, uu)
        shown.append((k, p, tk, px, py))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    for k, p, tk, px, py in shown:
        px = cx + (px - cx) * z; py = cy + (py - cy) * z
        dx = 1 if p.get("side", "r") == "r" else -1
        lx = p.get("lx") or (px + dx * 240); ly = py + p.get("dy", 0)
        hw = max(kit.font(80, 900).getlength(clean(p.get("value") or "").replace("*", "")) * 0.5 + 60,
                 kit.font(56, 800).getlength(clean(p.get("en") or "").replace("*", "")) * 0.5 + 50)
        lx = min(max(lx, X0 + 10 + hw), X1 - 10 - hw) if hw < 500 else 540
        a2, s2 = PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        c.save(); sa(c, P["navy"], 0.8 * a2); c.set_line_width(5); c.move_to(px, py); c.line_to(lx - dx * 150, ly); c.stroke(); c.restore()
        ny = ly
        if p.get("value"): pill(c, p["value"], 80, lx, ly - 50, P["navy"] if p.get("color") in (None, "gold") else col(p.get("color")), P["white"], a2, s2, outline=P["gold"], w=900, padh=1.3); ny = ly + 50
        if p.get("en"): pill(c, p["en"], 56, lx, ny + 14, P["white"], P["navy"], a2, s2, outline=col(p.get("color"), "navy"), w=800, padh=1.3)
    St.a = old
    RD.source(c, t, S)

def sc_map_highlight(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB); G = geo()
    if "_mv" not in S:
        view = S.get("view") or RD.auto_view([h["iso"] for h in S["highlights"]] + ["IL"], box_, 0.12)
        S["_mv"], S["_base"] = _base(S, view, box_, G)
        S["_hl"] = [(S["_mv"].rings(G[h["iso"]]["g"], 0.4), h) for h in S["highlights"] if h["iso"] in G]
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"]))); z = lerp(1.0, S.get("zoom", 1.08), ease(u))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    ts = S["times"]["highlights"]; labels = []
    for k, (rg, h) in enumerate(S["_hl"]):
        hk = S.get("hook") and ts[k] <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, ts[k] - 0.05, ts[k] + 0.3)
        if uu <= 0.01: continue
        _path(c, rg); sa(c, col(h.get("color"), "red"), 0.88 * uu); c.fill_preserve(); sa(c, P["white"], uu); c.set_line_width(2.4 / z); c.stroke()
        labels.append((k, h, uu))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    if "_lab" not in S:
        placed = []; S["_lab"] = {}
        for k, (rg, h) in enumerate(S["_hl"]):
            lon, lat = h.get("at_lonlat") or (lambda p: (p.x, p.y))(RD._main_poly(G[h["iso"]]["g"]).representative_point())
            px, py = mv.P(lon, lat); px = min(max(px, 300), 780); py = min(max(py + h.get("dy", 0), y0 + 70), y1 - 90)
            for dy in (0, 130, -130, 260, -260):
                if not any(abs(q[1] - (py + dy)) < 115 and abs(q[0] - px) < 420 for q in placed): py += dy; break
            placed.append((px, py)); S["_lab"][k] = (px, py)
    for k, h, uu in labels:
        if h.get("label") is False: continue
        px, py = S["_lab"][k]; px = cx + (px - cx) * z; py = cy + (py - cy) * z
        a2, s2 = PP(t, ts[k] + 0.1, S)
        pill(c, h.get("en") or G[h["iso"]]["name"], 54, px, py, P["white"], P["navy"], a2, s2, outline=col(h.get("color"), "red"), w=800, padh=1.35)
    St.a = old
    RD.source(c, t, S)
