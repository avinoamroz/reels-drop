"""she_walks_alone scenes (2 Nov 2026). Base: daily_1101 house scenes (circular loop fade, bar-cut music, _wtext, _label).
One scene type, sc_walk: a night street with a flat skyline of the city (landmark silhouettes, no religious buildings),
and on top a checklist (chips) that fills live, or a card (notperfect, reveal, end), or the hook text.
Drawn ON TOP of every scene by the Reel.draw wrapper (so it never blinks in cross-fades and the loop is seamless):
the pavement, street lamps and the same woman walking (walk cycle and scroll speeds are fitted to T_END, so the last
frame equals frame 0), then the source label of the current scene, then the subtitles."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))
import random
GOLD = kit.hx("#FFCD50"); NAVY = kit.hx("#163261"); NIGHT = kit.hx("#0B1426"); SKY = kit.hx("#45A4DD")
GREEN = kit.hx("#34C77B"); RED = kit.hx("#F0525A"); AMBER = kit.hx("#FFB224"); WHITE = (1.0, 1.0, 1.0)
GY = 1392                      # ground line
WH = 340                       # woman height
_wtext.__defaults__ = (WHITE, GOLD, 1000, 3, 1.0, 1.0, False)
RD.SUB_Y = 1530
_G = {"T": None}

def _fit(T, period, want):
    """speed so that the pattern repeats exactly over T (seamless loop)"""
    n = max(1, round(T * want / period)); return n * period / T

# ------------------------------------------------------------------ skylines (pre-rendered strips)
TW = 2160; _SK = {}
BLD = kit.hx("#0C1838"); BLD2 = kit.hx("#122452"); RIM = kit.hx("#2A4C8F")
def _win(c, x, y0, w, h, rnd, cols=None, a=0.55):
    cols = cols or max(1, int(w // 26)); rows = int(h // 34)
    cw = w / cols
    for i in range(cols):
        for j in range(rows):
            if rnd.random() < 0.42:
                sa(c, GOLD, a * rnd.uniform(0.35, 1.0)); c.rectangle(x + i * cw + cw * 0.28, y0 + 20 + j * 34, cw * 0.44, 14); c.fill()
def _bld(c, x, w, h, rnd, col=BLD, win=True, roof=None):
    sa(c, col); c.rectangle(x, GY - h, w, h + 2); c.fill()
    if roof == "pitch":
        c.move_to(x - 4, GY - h); c.line_to(x + w / 2, GY - h - w * 0.35); c.line_to(x + w + 4, GY - h); c.close_path(); sa(c, col); c.fill()
    if roof == "cren":
        for k in range(int(w // 22)):
            if k % 2 == 0: c.rectangle(x + k * 22, GY - h - 14, 14, 16); sa(c, col); c.fill()
    if win and h > 60: _win(c, x + 6, GY - h, w - 12, h - 40, rnd)
def _palm(c, x, h, col=BLD):
    sa(c, col); c.set_line_width(12); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.move_to(x, GY); c.curve_to(x + 10, GY - h * 0.5, x - 6, GY - h * 0.8, x + 8, GY - h); c.stroke()
    tx, ty = x + 8, GY - h; c.set_line_width(9)
    for ang in (-2.6, -2.0, -1.2, -0.5, 0.2, 0.8):
        ex, ey = tx + 95 * math.cos(ang), ty + 95 * math.sin(ang) * 0.6 + 30
        c.move_to(tx, ty); c.curve_to(tx + 40 * math.cos(ang), ty - 30, ex - 10, ey - 30, ex, ey); c.stroke()
def _mount(c, pts, col, snow=False):
    c.move_to(0, GY); [c.line_to(x, y) for x, y in pts]; c.line_to(TW, GY); c.close_path(); sa(c, col); c.fill()
    if snow:
        for (x0, y0), (x1, y1), (x2, y2) in zip(pts, pts[1:], pts[2:]):
            if y1 < y0 and y1 < y2 and y1 < GY - 330:
                c.move_to(x1, y1); c.line_to(x1 - (x1 - x0) * 0.25, y1 + (y0 - y1) * 0.25); c.line_to(x1 + (x2 - x1) * 0.25, y1 + (y2 - y1) * 0.25)
                c.close_path(); sa(c, (0.85, 0.9, 1.0), 0.75); c.fill()
def _filler(c, rnd, x0, x1, hmin=90, hmax=260, col=BLD, roof=None):
    x = x0
    while x < x1:
        w = rnd.randint(70, 150); _bld(c, x, w, rnd.randint(hmin, hmax), rnd, col=col, roof=roof); x += w + rnd.randint(4, 30)

def _city(c, key):
    rnd = random.Random(hash(key) % 1000)
    if key == "london":
        _filler(c, rnd, 0, TW, 120, 300, BLD2)
        # Big Ben (Elizabeth Tower)
        x = 300; sa(c, BLD); c.rectangle(x, GY - 560, 90, 560); c.fill()
        c.rectangle(x - 8, GY - 640, 106, 90); c.fill()
        c.move_to(x - 8, GY - 640); c.line_to(x + 45, GY - 790); c.line_to(x + 98, GY - 640); c.close_path(); c.fill()
        circ(c, x + 45, GY - 595, 34, kit.hx("#F6E7B0"), 0.9); sa(c, BLD); c.set_line_width(4)
        c.move_to(x + 45, GY - 595); c.line_to(x + 45, GY - 618); c.move_to(x + 45, GY - 595); c.line_to(x + 62, GY - 590); c.stroke()
        _filler(c, rnd, 420, 760, 120, 200, BLD, roof="pitch")
        # London Eye
        cx, cy, r = 1000, GY - 330, 250; c.set_line_width(7); sa(c, RIM); c.arc(cx, cy, r, 0, 2 * math.pi); c.stroke()
        c.set_line_width(2.5)
        for k in range(16):
            a = k * math.pi / 8; c.move_to(cx, cy); c.line_to(cx + r * math.cos(a), cy + r * math.sin(a)); c.stroke()
            circ(c, cx + r * math.cos(a), cy + r * math.sin(a), 11, SKY, 0.8)
        sa(c, BLD); c.set_line_width(10); c.move_to(cx, cy); c.line_to(cx - 120, GY); c.move_to(cx, cy); c.line_to(cx + 120, GY); c.stroke()
        # the Shard
        x = 1600; c.move_to(x, GY); c.line_to(x + 95, GY - 760); c.line_to(x + 200, GY); c.close_path(); sa(c, BLD); c.fill()
        sa(c, SKY, 0.35); c.set_line_width(3); c.move_to(x + 95, GY - 760); c.line_to(x + 140, GY); c.stroke()
        # red phone box
        sa(c, kit.hx("#D6333C")); rr(c, 1350, GY - 150, 60, 150, 8); c.fill(); sa(c, GOLD, 0.6); c.rectangle(1362, GY - 120, 36, 60); c.fill()
    elif key == "telaviv":
        _filler(c, rnd, 0, TW, 160, 330, BLD2)
        # Azrieli towers: round, triangle, square
        sa(c, BLD); rr(c, 380, GY - 620, 120, 620, 55); c.fill(); _win(c, 392, GY - 600, 96, 560, rnd)
        c.move_to(560, GY); c.line_to(560, GY - 580); c.line_to(690, GY - 560); c.line_to(690, GY); c.close_path(); c.fill(); _win(c, 572, GY - 550, 106, 520, rnd)
        c.rectangle(750, GY - 540, 120, 540); c.fill(); _win(c, 762, GY - 520, 96, 480, rnd)
        # white Bauhaus blocks with rounded balconies
        for x, w, h in ((1000, 260, 230), (1320, 220, 190), (1640, 280, 250)):
            sa(c, kit.hx("#1E3260")); rr(c, x, GY - h, w, h + 4, 18); c.fill()
            for j in range(int(h // 56)):
                sa(c, kit.hx("#E9EEF6"), 0.55); rr(c, x - 10, GY - h + 30 + j * 56, w + 20, 14, 7); c.fill()
        for x in (950, 1270, 1590, 1950): _palm(c, x, 260)
    elif key == "baghdad":
        _filler(c, rnd, 0, TW, 90, 220, BLD2)
        # Baghdad Tower (TV tower)
        x = 420; sa(c, BLD); c.move_to(x - 30, GY); c.line_to(x - 12, GY - 600); c.line_to(x + 12, GY - 600); c.line_to(x + 30, GY); c.close_path(); c.fill()
        rr(c, x - 70, GY - 660, 140, 70, 30); c.fill(); c.rectangle(x - 4, GY - 780, 8, 130); c.fill()
        for k in range(5): circ(c, x - 50 + k * 25, GY - 625, 5, GOLD, 0.8)
        # Al-Shaheed Monument: two split turquoise half domes
        cx = 1050; TQ = kit.hx("#2BB3B1"); sa(c, BLD); c.rectangle(cx - 260, GY - 70, 520, 70); c.fill()
        for sgn in (-1, 1):
            c.save(); c.translate(cx + sgn * 22, GY - 70); c.scale(1.0, 1.25)
            c.move_to(0, 0); c.arc(0, 0, 210, math.pi + (0 if sgn < 0 else math.pi / 2), math.pi + (math.pi / 2 if sgn < 0 else math.pi)); c.close_path()
            c.restore(); sa(c, TQ, 0.9); c.fill()
        sa(c, GOLD, 0.9); c.rectangle(cx - 6, GY - 340, 12, 270); c.fill()
        for x in (700, 820, 1380, 1520, 1800, 2000): _palm(c, x, rnd.randint(220, 300))
    elif key == "sanaa":
        _mount(c, [(0, GY - 260), (300, GY - 420), (620, GY - 300), (900, GY - 470), (1300, GY - 320), (1650, GY - 450), (2000, GY - 300), (TW, GY - 360)], kit.hx("#0F1D40"))
        x = 30
        while x < TW:
            w = rnd.randint(110, 170); h = rnd.randint(260, 480)
            sa(c, kit.hx("#2A1F2E") if rnd.random() < 0.5 else BLD); c.rectangle(x, GY - h, w, h + 2); c.fill()
            for k in range(int(w // 22)):
                if k % 2 == 0: c.rectangle(x + k * 22, GY - h - 14, 14, 16); c.fill()
            for j in range(int((h - 60) // 90)):
                yy = GY - h + 50 + j * 90
                sa(c, kit.hx("#F3EBDD"), 0.75); c.rectangle(x + 6, yy - 10, w - 12, 5); c.fill()
                for i in range(2):
                    wx = x + w * (0.3 + 0.4 * i)
                    sa(c, GOLD, 0.65); c.rectangle(wx - 13, yy + 18, 26, 30); c.fill()
                    sa(c, kit.hx("#F3EBDD"), 0.8); c.set_line_width(3); c.arc(wx, yy + 14, 16, math.pi, 2 * math.pi); c.stroke()
                    sa(c, SKY, 0.6); c.arc(wx, yy + 14, 12, math.pi, 2 * math.pi); c.close_path(); c.fill()
            x += w + rnd.randint(8, 40)
    elif key == "riyadh":
        _filler(c, rnd, 0, TW, 80, 200, BLD2)
        # Kingdom Centre: tapering tower with the parabolic opening at the top
        x = 380; c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD)
        c.move_to(x - 110, GY); c.line_to(x - 70, GY - 700); c.line_to(x + 70, GY - 700); c.line_to(x + 110, GY); c.close_path()
        c.move_to(x - 62, GY - 690); c.curve_to(x - 50, GY - 520, x + 50, GY - 520, x + 62, GY - 690); c.close_path()
        sa(c, BLD); c.fill(); c.set_fill_rule(cairo.FILL_RULE_WINDING)
        sa(c, SKY, 0.8); c.set_line_width(4); c.move_to(x - 62, GY - 690); c.curve_to(x - 50, GY - 520, x + 50, GY - 520, x + 62, GY - 690); c.stroke()
        _win(c, x - 90, GY - 480, 180, 460, rnd)
        # Al Faisaliah: pyramid tower with a golden sphere
        x = 1150; c.move_to(x - 120, GY); c.line_to(x - 10, GY - 640); c.line_to(x + 10, GY - 640); c.line_to(x + 120, GY); c.close_path(); sa(c, BLD); c.fill()
        circ(c, x, GY - 470, 46, GOLD, 0.9); sa(c, BLD); c.rectangle(x - 3, GY - 760, 6, 130); c.fill()
        for x in (700, 860, 1500, 1700, 1950): _palm(c, x, rnd.randint(200, 260))
    elif key == "tehran":
        _mount(c, [(0, GY - 380), (260, GY - 560), (520, GY - 420), (840, GY - 640), (1160, GY - 450), (1500, GY - 600), (1820, GY - 430), (TW, GY - 520)], kit.hx("#13234A"), snow=True)
        _filler(c, rnd, 0, TW, 90, 230, BLD2)
        # Milad Tower
        x = 1500; sa(c, BLD); c.move_to(x - 40, GY); c.line_to(x - 14, GY - 560); c.line_to(x + 14, GY - 560); c.line_to(x + 40, GY); c.close_path(); c.fill()
        c.move_to(x - 70, GY - 560); c.line_to(x - 50, GY - 650); c.line_to(x + 50, GY - 650); c.line_to(x + 70, GY - 560); c.close_path(); c.fill()
        c.rectangle(x - 4, GY - 820, 8, 180); c.fill()
        for k in range(6): circ(c, x - 50 + k * 20, GY - 605, 5, GOLD, 0.8)
        # Azadi Tower: wide base with an arch
        x = 600; c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD)
        c.move_to(x - 230, GY); c.curve_to(x - 150, GY - 220, x - 70, GY - 360, x - 40, GY - 430); c.line_to(x + 40, GY - 430)
        c.curve_to(x + 70, GY - 360, x + 150, GY - 220, x + 230, GY); c.close_path()
        c.move_to(x - 120, GY); c.curve_to(x - 100, GY - 190, x - 40, GY - 250, x, GY - 260); c.curve_to(x + 40, GY - 250, x + 100, GY - 190, x + 120, GY); c.close_path()
        sa(c, kit.hx("#1E3466")); c.fill(); c.set_fill_rule(cairo.FILL_RULE_WINDING)
        sa(c, kit.hx("#1E3466")); c.rectangle(x - 55, GY - 470, 110, 44); c.fill()
    else:   # neutral street for the hook and the cards
        _filler(c, rnd, 0, TW, 110, 330, BLD2)
        _filler(c, rnd, 60, TW, 80, 200, BLD)

def _strip(key):
    if key not in _SK:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, TW, H); c = cairo.Context(s); keep = St.a; St.a = 1.0
        _city(c, key); St.a = keep; s.flush(); _SK[key] = s
    return _SK[key]

def _sky(c, t):
    g = cairo.LinearGradient(0, 0, 0, GY); g.add_color_stop_rgb(0, *NIGHT[:3]); g.add_color_stop_rgb(0.7, *NAVY[:3]); g.add_color_stop_rgb(1, 0.15, 0.26, 0.55)
    c.new_path(); c.set_source(g); c.paint_with_alpha(St.a)
    rnd = random.Random(7)
    for k in range(70):
        x, y = rnd.uniform(0, W), rnd.uniform(0, 900); tw = 0.5 + 0.5 * math.sin(t * rnd.uniform(1, 3) + k)
        circ(c, x, y, rnd.uniform(1.2, 2.6), WHITE, (0.25 + 0.45 * tw))
    circ(c, 930, 215, 60, kit.hx("#F6EBC8"), 0.18); circ(c, 930, 215, 44, kit.hx("#F6EBC8"), 0.9)   # full moon

def _skyline(c, t, key):
    s = _strip(key); T = _G["T"] or 60.0; v = _fit(T, TW, 34.0); off = (t * v) % TW
    for k in (0, 1):
        c.set_source_surface(s, -off + k * TW, 0); c.paint_with_alpha(St.a)

# ------------------------------------------------------------------ chips
def _icon(c, x, y, st, u, a):
    r = 40
    if st == "pend" or u <= 0.01:
        sa(c, WHITE, 0.35 * a); c.set_line_width(4); c.arc(x, y, r, 0, 2 * math.pi); c.stroke(); return
    s = kit.pop(0.0, 0.0)[1] if False else 1.0
    colr = {"y": GREEN, "n": RED, "p": AMBER}[st]
    sc_ = 0.4 + 0.6 * kit.eob(min(1.0, u)) if u < 1 else 1.0
    c.save(); c.translate(x, y); c.scale(sc_, sc_)
    circ(c, 0, 0, r, colr, a); sa(c, WHITE, a); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    if st == "y": c.move_to(-17, 1); c.line_to(-5, 14); c.line_to(18, -13); c.stroke()
    elif st == "n": c.move_to(-14, -14); c.line_to(14, 14); c.move_to(14, -14); c.line_to(-14, 14); c.stroke()
    else: c.move_to(-16, 0); c.line_to(16, 0); c.stroke()
    c.restore()

def _chip_times(S, n):
    ts = [S["times"].get(f"c{j}", S["t0"] + 0.6 + 0.5 * j) for j in range(n)]
    order = sorted(range(n), key=lambda j: ts[j])
    for a_, b_ in zip(order, order[1:]):
        if ts[b_] < ts[a_] + 0.22: ts[b_] = ts[a_] + 0.22
    return ts

def _chips(c, t, S, y0, rh=128, gap=14):
    chips = S["chips"]; ts = _chip_times(S, len(chips))
    for j, ch in enumerate(chips):
        ya = y0 + j * (rh + gap); a = RD.fade_in(t, S["t0"] + 0.1 + 0.08 * j, S, 0.3)
        if a <= 0.01: continue
        u = (t - ts[j]) / 0.4 if t >= ts[j] else 0.0
        on = t >= ts[j]
        edge = {"y": GREEN, "n": RED, "p": AMBER}.get(ch["st"], GOLD) if on else (0.35, 0.45, 0.65)
        sa(c, INK, 0.78 * a); rr(c, 40, ya, 1000, rh, 30); c.fill()
        sa(c, edge, 0.9 * a); c.set_line_width(4); rr(c, 40, ya, 1000, rh, 30); c.stroke()
        cy = ya + rh / 2
        if ch["st"] == "pct":
            v = ch.get("pct")
            kit.tx(c, ch["en"], 58, 82, cy, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=640, anchor="l")
            if on:
                if v is None: kit.tx(c, "no data", 56, 1000, cy, w=800, col=RD.c255((0.75, 0.8, 0.9)), a=a * ramp(t, ts[j], ts[j] + 0.3), shadow=False, maxw=300, anchor="r")
                else:
                    vv = v * ease(min(1.0, (t - ts[j]) / 0.9)); kit.tx(c, f"{vv:.0f}%", 84, 1000, cy, w=900, col=RD.c255(GOLD), a=a, shadow=False, maxw=300, anchor="r")
            continue
        _icon(c, 110, cy, ch["st"] if on else "pend", u, a)
        if ch.get("note") and on:
            kit.tx(c, ch["en"], 58, 172, cy - 22, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=840, anchor="l")
            kit.tx(c, ch["note"], 40, 172, cy + 34, w=700, col=RD.c255(AMBER if ch["st"] == "p" else (0.80, 0.86, 0.96)), a=a * ramp(t, ts[j], ts[j] + 0.3), shadow=False, maxw=840, anchor="l")
        else:
            kit.tx(c, ch["en"], 58, 172, cy, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=840, anchor="l")

# ------------------------------------------------------------------ the scene
def sc_walk(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); _sky(c, t); _skyline(c, t, S.get("city", "none"))
    card = S.get("card")
    if hook:
        _wtext(c, S["en"], 150, 600, a=1.0, sc=1.0 + 0.012 * math.sin(t * 2.2), max_lines=2); return
    if card == "end":
        a1, s1 = PP(t, t0 + 0.1, S); _wtext(c, S["en"], 130, 600, a=a1 * (1 - ramp(t, (S["t1"] or t0 + 4) - 0.9, (S["t1"] or t0 + 4) - 0.45)), sc=s1, max_lines=2); return
    if card == "notperfect":
        a1, s1 = PP(t, t0 + 0.05, S); _wtext(c, S["title"], 120, 420, a=a1, sc=s1, max_lines=1)
        kit.tx(c, "Israel", 60, 540, 540, w=800, col=RD.c255(SKY), a=a1, shadow=True, maxw=1000)
        _chips(c, t, S, 640, rh=150); return
    if card == "reveal":
        ta = S["times"].get("r0", t0 + 0.4); tb = S["times"].get("r1", t0 + 1.4)
        for (tk, cap, big, small, y) in ((ta, "SAFEST STREETS", "Riyadh 93%", "feel safe at night", 470), (tb, "MOST FREEDOM", "London, Tel Aviv", "3 of 3 rights", 780)):
            a2, s2 = PP(t, tk, S, s0=0.6, bounce=1.4)
            if a2 <= 0.01: continue
            sa(c, INK, 0.78 * a2); rr(c, 40, y - 120, 1000, 270, 34); c.fill()
            sa(c, GOLD if y < 600 else GREEN, 0.9 * a2); c.set_line_width(4); rr(c, 40, y - 120, 1000, 270, 34); c.stroke()
            kit.tx(c, cap, 52, 540, y - 70, w=900, col=RD.c255(SKY), a=a2, shadow=False, maxw=940)
            _wtext(c, big, 104, y + 20, color=GOLD if y < 600 else WHITE, a=a2, sc=s2, max_lines=1, maxw=940)
            kit.tx(c, small, 48, 540, y + 105, w=700, col=RD.c255((0.85, 0.9, 1.0)), a=a2, shadow=False, maxw=940)
        return
    # a city: name, country, the live checklist
    a1, s1 = PP(t, t0 + 0.05, S)
    _wtext(c, S["name"], 120, 350, a=a1, sc=s1, max_lines=1)
    kit.tx(c, S["sub"], 52, 540, 440, w=800, col=RD.c255(SKY), a=a1, shadow=True, maxw=1000)
    _chips(c, t, S, 492)

# ------------------------------------------------------------------ top layer: street, lamps, the woman, source, subtitles
def _limb(c, pts, w, colr, a):
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; sa(c, colr, a); c.set_line_width(w); c.stroke()

def woman(c, x, gy, h, ph, a=1.0):
    """flat illustration, walking right; ph in radians (one stride = 2 pi)"""
    SKIN = kit.hx("#F1D6C2"); COAT = SKY; COAT2 = kit.hx("#2F86BF"); LEG = kit.hx("#EAF0F8"); LEG2 = kit.hx("#B9C6D8"); HAIR = kit.hx("#3A2620")
    bob = abs(math.sin(ph)) * h * 0.012
    hip = (x, gy - h * 0.50 - bob); sh = (x + h * 0.02, gy - h * 0.80 - bob); hd = (x + h * 0.035, gy - h * 0.905 - bob)
    th, sn = h * 0.255, h * 0.255
    def leg(phase, colr, w):
        s = math.sin(phase); a_th = 0.42 * s; kne = 0.55 * max(0.0, -math.cos(phase)) + 0.08
        kx, ky = hip[0] + th * math.sin(a_th), hip[1] + th * math.cos(a_th)
        a_sn = a_th - kne; fx, fy = kx + sn * math.sin(a_sn), ky + sn * math.cos(a_sn)
        fy = min(fy, gy - 4)
        _limb(c, [hip, (kx, ky), (fx, fy)], w, colr, a)
        _limb(c, [(fx - 4, fy + 2), (fx + h * 0.06, fy + 2)], w * 0.8, kit.hx("#1C2B4A"), a)
    def arm(phase, colr, w):
        s = math.sin(phase); a_u = -0.38 * s; ex, ey = sh[0] + h * 0.15 * math.sin(a_u), sh[1] + h * 0.15 * math.cos(a_u)
        a_f = a_u + 0.35 + 0.2 * max(0, s); hx_, hy_ = ex + h * 0.14 * math.sin(a_f), ey + h * 0.14 * math.cos(a_f)
        _limb(c, [sh, (ex, ey)], w * 1.25, COAT2 if colr is None else colr, a); _limb(c, [(ex, ey), (hx_, hy_)], w, SKIN, a)
    leg(ph + math.pi, LEG2, h * 0.055); arm(ph, COAT2, h * 0.045)
    # shoulder bag strap and bag (back)
    leg(ph, LEG, h * 0.06)
    # coat: A-line from shoulders to just above the knee
    c.move_to(sh[0] - h * 0.07, sh[1] + h * 0.01); c.line_to(sh[0] + h * 0.07, sh[1] + h * 0.01)
    c.line_to(hip[0] + h * 0.11, gy - h * 0.33 - bob); c.curve_to(hip[0] + h * 0.03, gy - h * 0.31 - bob, hip[0] - h * 0.05, gy - h * 0.31 - bob, hip[0] - h * 0.12, gy - h * 0.33 - bob)
    c.close_path(); sa(c, COAT, a); c.fill()
    sa(c, kit.hx("#FFCD50"), a); c.rectangle(hip[0] - h * 0.075, hip[1] - h * 0.02, h * 0.16, h * 0.022); c.fill()   # belt
    # neck, head, hair (bob + ponytail swinging)
    _limb(c, [(sh[0] + h * 0.005, sh[1]), (hd[0] - h * 0.005, hd[1] + h * 0.04)], h * 0.04, SKIN, a)
    sw = math.sin(ph * 2) * 0.12
    c.save(); c.translate(hd[0] - h * 0.04, hd[1] - h * 0.02); c.rotate(0.9 + sw)
    c.move_to(0, 0); c.curve_to(h * 0.02, h * 0.04, h * 0.01, h * 0.11, -h * 0.02, h * 0.14); c.curve_to(-h * 0.03, h * 0.08, -h * 0.03, h * 0.03, 0, 0)
    c.restore(); sa(c, HAIR, a); c.fill()
    circ(c, hd[0], hd[1], h * 0.058, SKIN, a)
    c.move_to(hd[0] - h * 0.06, hd[1] + h * 0.01); c.arc(hd[0], hd[1], h * 0.062, math.pi * 0.95, math.pi * 1.95); c.line_to(hd[0] + h * 0.01, hd[1] - h * 0.02)
    c.curve_to(hd[0] - h * 0.02, hd[1] - h * 0.01, hd[0] - h * 0.035, hd[1] + h * 0.02, hd[0] - h * 0.04, hd[1] + h * 0.045); c.close_path(); sa(c, HAIR, a); c.fill()
    arm(ph + math.pi, COAT, h * 0.05)

def _street(c, t):
    T = _G["T"] or 60.0
    g = cairo.LinearGradient(0, GY, 0, H); g.add_color_stop_rgb(0, 0.10, 0.16, 0.30); g.add_color_stop_rgb(0.25, 0.05, 0.09, 0.18); g.add_color_stop_rgb(1, 0.02, 0.04, 0.09)
    c.rectangle(0, GY, W, H - GY); c.set_source(g); c.fill()
    sa(c, (0.55, 0.65, 0.85), 0.5); c.rectangle(0, GY, W, 3); c.fill()
    v = _fit(T, 540, 150.0); off = (t * v) % 540
    for k in range(-1, 4):
        x = k * 540 - off + 270
        # paving joints
        sa(c, (1, 1, 1), 0.06); c.rectangle(x - 270, GY + 10, 2, 50); c.fill()
        # lamp: pole, arm, warm glow
        sa(c, kit.hx("#0A1226")); c.rectangle(x - 6, GY - 360, 12, 360); c.fill(); c.rectangle(x - 6, GY - 360, 60, 10); c.fill()
        lx, ly = x + 50, GY - 345
        rg = cairo.RadialGradient(lx, ly, 0, lx, ly, 260); rg.add_color_stop_rgba(0, 1, 0.85, 0.5, 0.30); rg.add_color_stop_rgba(1, 1, 0.85, 0.5, 0)
        c.set_source(rg); c.arc(lx, ly, 260, 0, 2 * math.pi); c.fill()
        circ(c, lx, ly, 14, kit.hx("#FFE6A8"), 1.0)
        c.save(); c.translate(lx, GY + 20); c.scale(1.0, 0.18); rg = cairo.RadialGradient(0, 0, 0, 0, 0, 200)
        rg.add_color_stop_rgba(0, 1, 0.85, 0.5, 0.22); rg.add_color_stop_rgba(1, 1, 0.85, 0.5, 0); c.set_source(rg); c.arc(0, 0, 200, 0, 2 * math.pi); c.fill(); c.restore()

def _cur(self, t):
    i = 0
    for k, S in enumerate(self.scenes):
        if t >= S["t0"] - 0.01: i = k
    return i

_subs_draw = RD.draw_subs; RD.draw_subs = lambda c, t, items: None
_draw_prev = RD.Reel.draw
def _draw_top(self, c, t):
    _G["T"] = self.T_END
    _draw_prev(self, c, t)
    keep = St.a; St.a = 1.0
    _street(c, t)
    per = 1.08; n = max(1, round(self.T_END / per)); ph = 2 * math.pi * n * (t / self.T_END)
    c.save(); sa(c, (0, 0, 0), 0.35); c.translate(540, GY + 6); c.scale(1.0, 0.12); c.arc(0, 0, 110, 0, 2 * math.pi); c.fill(); c.restore()
    woman(c, 520, GY, WH, ph)
    i = _cur(self, t); S = self.scenes[i]
    if S.get("source"):
        a = ramp(t, S["t0"] + 0.3, S["t0"] + 0.7) * (1 - ramp(t, (S["t1"] or self.T_END) - 0.25, (S["t1"] or self.T_END)))
        if a > 0.01: _label(c, S["source"], 1415, a)
    _subs_draw(c, t, self.subs)
    St.a = keep
RD.Reel.draw = _draw_top
