REC = {
1948: "Bulgaria, Costa Rica, Czech Republic, Dominican Republic, El Salvador, Guatemala, Honduras, Hungary, Nicaragua, Panama, Paraguay, Poland, Romania, Russia, Slovakia, Uruguay, Venezuela",
1949: "Albania, Argentina, Australia, Bolivia, Brazil, Canada, Chile, Colombia, Cuba, Ecuador, Finland, France, Norway, Peru, South Africa, Switzerland, United States",
1950: "Belgium, Denmark, Haiti, India, Italy, Luxembourg, Netherlands, New Zealand, Sri Lanka, Sweden, Thailand, Turkey, United Kingdom",
1952: "Japan, Mexico", 1953: "Myanmar", 1956: "Austria", 1957: "Laos, Philippines",
1960: "Cambodia, Cameroon, DR Congo, Nepal, Nigeria, Republic of the Congo, Senegal",
1961: "Benin, Burkina Faso, Chad, Cyprus, Cote d'Ivoire, Ethiopia", 1962: "Jamaica, South Korea, Trinidad and Tobago",
1963: "Ireland, Kenya", 1964: "Malawi, Monaco", 1965: "Germany, Maldives, Malta", 1967: "Barbados", 1968: "Eswatini", 1969: "Singapore",
1970: "Fiji", 1972: "Botswana", 1974: "Bahamas", 1975: "Grenada", 1976: "Suriname", 1977: "Portugal, Samoa, Tonga",
1978: "Dominica, Papua New Guinea", 1979: "Egypt, Saint Lucia", 1981: "Saint Vincent and the Grenadines", 1983: "Antigua and Barbuda",
1984: "Belize, Kiribati, Saint Kitts and Nevis, Tuvalu", 1986: "Spain", 1987: "Marshall Islands", 1988: "Micronesia", 1989: "Solomon Islands",
1990: "Greece", 1991: "Mongolia, Ukraine",
1992: "Angola, Armenia, Azerbaijan, Belarus, China, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Moldova, Serbia, Seychelles, Slovenia, Tajikistan, Uzbekistan",
1993: "Eritrea, Mozambique, Sao Tome and Principe, Turkmenistan, Vanuatu, Vietnam, Zimbabwe",
1994: "Andorra, Cabo Verde, Guinea-Bissau, Jordan, Namibia, Nauru, Palau", 1995: "North Macedonia, San Marino",
1997: "Bosnia and Herzegovina, Croatia", 1999: "Mauritania", 2002: "Timor-Leste", 2006: "Montenegro", 2011: "South Sudan",
2020: "Bahrain, Bhutan, Morocco, United Arab Emirates",
}
UNKNOWN = "Burundi, Central African Republic, Equatorial Guinea, Gabon, Gambia, Ghana, Guinea, Guyana, Iceland, Lesotho, Liberia, Madagascar, Mali, Mauritius, Niger, Rwanda, Sierra Leone, Tanzania, Togo, Uganda, Zambia"
NO = "Afghanistan, Algeria, Bangladesh, Brunei, Comoros, Djibouti, Indonesia, Iran, Iraq, Kuwait, Lebanon, Libya, Malaysia, North Korea, Oman, Pakistan, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, Yemen"
def lst(s): return [x.strip() for x in s.split(",")]
