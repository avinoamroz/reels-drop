# -*- coding: utf-8 -*-
"""race.py CFG.py [--snaps=0,1,3]: big-text bar race, year timeline keyed to narration marks."""
import sys, runpy, math
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/click_1103")
from ck import *

C = runpy.run_path(sys.argv[1]); rid = C["ID"]; T = Timing(rid)
DUR = round(T.dur + C.get("TAIL", 0.9), 2)
KF = [(y, (m if isinstance(m, float) else T.at(m))) for y, m in C["KF"]]
ky = [y for y, _ in KF]; kt = [t for _, t in KF]
assert all(b >= a for a, b in zip(kt, kt[1:])), KF
def year_at(t): return float(np.interp(t, kt, ky))
G = C["G"]; names = list(G)
def val(n, y):
    pts = G[n]["pts"]
    if y < pts[0][0] - 1e-9: return None
    return float(np.interp(y, [p[0] for p in pts], [p[1] for p in pts]))
FL = {}
def flag(iso, h):
    if (iso, h) not in FL:
        f = Image.open(f"{HERE}/flags/{iso}.png").convert("RGBA"); w = int(h * f.width / f.height); f = f.resize((w, h), Image.LANCZOS)
        m = Image.new("L", f.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, w - 1, h - 1], 6, fill=255)
        a = np.minimum(np.asarray(f.split()[3]), np.asarray(m)); f.putalpha(Image.fromarray(a)); FL[(iso, h)] = f
    return FL[(iso, h)]
L = C["LAYOUT"]; Y0 = L["y0"]; RH = L["row_h"]; LAB = L["lab"]; BT = L["bar_t"]; VAL = L["val"]; INLINE = L.get("inline", False)
LABW = L.get("lab_w", 0); X0, X1 = 50, 1030
EV = [(T.at(m), s) for m, s in C.get("EVENTS", [])]
SRCS = C.get("SRC_BY_YEAR"); SUBS = sub_chunks(T, C.get("SUBS", []))
REV = [(T.at(a), (T.at(b) if b != "end" else DUR), lines) for a, b, lines in C.get("REVEALS", [])]
pos = {n: None for n in names}; xmax_s = None
out = Out(rid, DUR, snaps_arg())
pre = C.get("GROW", 1.0)
for f, t in out.frames():
    if out.snaps:   # settle smoothing state for stills
        pass
    y = year_at(t); vals = {n: val(n, y) for n in names}
    order = sorted(names, key=lambda n: -(vals[n] if vals[n] is not None else -1e9))
    for i, n in enumerate(order):
        pos[n] = i if (pos[n] is None or out.snaps) else pos[n] + (i - pos[n]) * 0.2
    mx = max(v for v in vals.values() if v is not None); lo = C.get("AXIS_MIN", 0.0)
    xmax_s = mx if (xmax_s is None or out.snaps) else xmax_s + (mx - xmax_s) * 0.15
    g = 0.82 + 0.18 * ease(t / pre)          # frame 0 bars already drawn, still growing at 1 s
    im = stage(); d = ImageDraw.Draw(im)
    yh = hook(d, C["HOOK"], t)
    txt(d, W / 2, yh + 4, C["SHAPE"], fit(C["SHAPE"], 56, 980, 700), SILVER, 700, "ma")
    for n in sorted(names, key=lambda n: -pos[n]):
        v = vals[n]; c = hx(G[n]["col"]); yy = Y0 + pos[n] * RH
        if INLINE:
            lx = X0
            if G[n].get("flag"):
                fl = flag(G[n]["flag"], int(LAB * 0.78)); im.alpha_composite(fl, (int(lx), int(yy + (RH - fl.height) / 2))); lx += fl.width + 14; d = ImageDraw.Draw(im)
            lab = G[n].get("short", n); txt(d, lx, yy + RH / 2, lab, fit(lab, LAB, X0 + LABW - lx - 8, 800, 50), WHITE if not G[n].get("hl") else YEL, 800, "lm")
            bx = X0 + LABW; bwmax = X1 - bx - VAL * 2.3; by = yy + (RH - BT) / 2
        else:
            txt(d, X0, yy + LAB * 0.55, G[n].get("short", n), LAB, c, 800, "lm")
            bx = X0; bwmax = X1 - X0 - VAL * 4.2; by = yy + LAB * 1.15
        if v is None:
            txt(d, bx + 8, by + BT / 2, "no data", int(VAL * 0.85), GREY, 700, "lm"); continue
        Lw = max(8, bwmax * g * (v - lo) / max(1e-9, xmax_s - lo))
        d.rounded_rectangle([bx, by, bx + Lw, by + BT], int(BT / 3), fill=c[:3] + (240,))
        s = C["FMT"](v); txt(d, bx + Lw + 14, by + BT / 2 + 2, s, VAL, YEL if G[n].get("hl") else WHITE, 800, "lm")
    # year + side readout
    YY = L["y_year"]; ys = str(int(round(y)) if C.get("YEAR_ROUND", True) else int(y))
    txt(d, X0 - 4, YY, ys, L.get("year_sz", 150), WHITE, 900, "la")
    if C.get("SIDE"):
        lab, fn = C["SIDE"]; s = fn(vals, y)
        txt(d, X1, YY + 18, lab, 52, SILVER, 700, "ra"); txt(d, X1, YY + 76, s, 76, YEL, 900, "ra")
    # event line or reveal
    ra = 0.0; cur = None
    for a, b, lines in REV:
        if a <= t <= b: ra = min(1, (t - a) / 0.25, (b - t) / 0.25 if b < DUR - 0.01 else 1); cur = lines
    ev = [s for a, s in EV if a <= t]
    EY = L["y_ev"]
    if ev and ra < 1:
        ls = wrap(ev[-1], 58, 980, 800)[:L.get('ev_lines', 2)]
        for i, l in enumerate(ls): txt(d, W / 2, EY + i * 66, l, 58, GOLD, 800, "ma", 1 - ra)
    if cur:
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        RY = L.get("y_rev", EY)
        ld.rounded_rectangle([X0 - 6, RY - 14, X1 + 6, RY + 172], 26, fill=(8, 20, 46, int(245 * ra)), outline=YEL[:3] + (int(255 * ra),), width=4)
        for i, (s, col) in enumerate(zip(cur, (WHITE, YEL))):
            txt(ld, W / 2, RY + 8 + i * 80, s, fit(s, 72, 940, 900, 52), col, 900, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    src = C["SRC"]
    if SRCS:
        k = [s for yr, s in SRCS if yr <= y + 1e-6]; src = (k[-1] if k else SRCS[0][1])
    source(d, src)
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
