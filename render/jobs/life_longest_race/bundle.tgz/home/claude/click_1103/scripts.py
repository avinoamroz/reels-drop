# -*- coding: utf-8 -*-
"""Narration for the 5 click-study reels (3 Nov 2026). One TTS line per list item."""
S = {}
S["jlm_residents_race"] = [
 "Who lived in Jerusalem?",
 "Eighteen forty four. The Prussian consul counts the city.",
 "Seven thousand Jews. Five thousand Muslims. Three thousand Christians.",
 "Thirty years later, another count finds more Muslims.",
 "Then the city grows beyond the Old City walls.",
 "Eighteen ninety six. Twenty eight thousand Jews, out of forty five thousand.",
 "Nineteen twenty two. The first British census.",
 "Nineteen forty four. Ninety seven thousand Jews.",
 "Nineteen sixty seven. The city is reunited, and the borders change.",
 "By twenty twenty, more than nine hundred thousand people.",
 "Every census for over a hundred years shows the same answer.",
 "A Jewish majority. Today, about six in ten.",
 "And about four in ten Jerusalemites are Arab. Almost four hundred thousand people.",
 "In twenty twenty two, the city passed one million.",
 "So next time someone asks you...",
]
S["recognised_first_map"] = [
 "Who recognised Israel first?",
 "May fourteenth, nineteen forty eight. Israel declares independence.",
 "By the end of that year, seventeen countries.",
 "By nineteen fifty, forty seven.",
 "In the sixties, dozens of newly independent African states.",
 "Nineteen seventy nine. Egypt, the first Arab country.",
 "Then the Soviet Union falls. Forty more countries in the nineties, including Jordan.",
 "Twenty twenty. The UAE, Bahrain and Morocco.",
 "Add twenty one more with no date on record.",
 "Today, one hundred sixty nine of the other one hundred ninety two UN members.",
 "Twenty three still say no. Twenty two of them are Muslim majority countries. The other is North Korea.",
 "Recognising is not agreeing. Many of them criticise Israel too.",
 "And the first? Eleven minutes after the declaration, the United States.",
 "Three days later, the first full legal recognition. The Soviet Union.",
 "So next time someone asks you...",
]
S["women_vote_map"] = [
 "When could women vote here?",
 "Nineteen twenty. Jewish women here vote for their community's first assembly.",
 "Nineteen thirty. Turkey, the first country in the region.",
 "Nineteen forty eight. Israel. Women vote in its very first election.",
 "Turkey beat Israel by eighteen years.",
 "Syria, forty nine. Lebanon, fifty two. Egypt, fifty six.",
 "Cyprus, sixty. Iran, sixty three. South Yemen, sixty seven.",
 "Jordan, seventy four. Iraq, eighty.",
 "Then a long wait.",
 "Oman, ninety four, for a hand picked few. Qatar, ninety eight, for the city council.",
 "Bahrain, two thousand two. Kuwait, two thousand five.",
 "The UAE, two thousand six, through a chosen electoral college.",
 "Saudi Arabia, twenty fifteen. City councils only.",
 "From the first to the last, eighty five years. And Saudi Arabia still has no elected parliament.",
 "So if anyone asks you...",
]
S["life_longest_race"] = [
 "Who lives longest in the Middle East?",
 "Sixty years of World Bank data. Eleven countries.",
 "Nineteen sixty one. Israel leads, at seventy two years.",
 "Lebanon is next. Then the Gulf starts climbing.",
 "Nineteen seventy five. Civil war in Lebanon. It drops eight years.",
 "Iraq slides through the eighties.",
 "Two thousand five. The UAE overtakes Israel.",
 "Twenty fifteen. Syria's civil war costs ten years.",
 "Twenty nineteen. Qatar on top.",
 "Then the pandemic hits the Gulf.",
 "Twenty twenty three. The Palestinian territories drop eleven years, the year the war began.",
 "And the top of the table?",
 "Israel. Eighty three point two years.",
 "The UAE is under half a year behind, and Qatar under one.",
 "So when someone asks you...",
]
S["europe_jews_map"] = [
 "Where did Europe's Jews go?",
 "Nineteen thirty three. Nine and a half million Jews live in Europe.",
 "Poland, over three million. The Soviet Union, two and a half million.",
 "Romania. Germany. Hungary. Britain. France.",
 "Families, schools, synagogues, whole towns.",
 "Then come the Nazis, and the war.",
 "By nineteen fifty, the counter reads three and a half million.",
 "Poland, from three million to forty five thousand.",
 "Germany, from over half a million to thirty seven thousand.",
 "Hundreds of thousands of survivors rebuilt their lives far away.",
 "About one hundred thirty six thousand displaced survivors went to Israel. Over eighty thousand to the United States.",
 "The Soviet Union still had about two million Jews.",
 "But most of the missing never went anywhere.",
 "Six million Jews were murdered in the Holocaust.",
 "So if anyone ever asks you...",
]
if __name__ == "__main__":
    import re
    for k, v in S.items():
        txt = " ".join(v); assert not re.search("[‐-―]", txt)
        low = txt.lower()
        for b in ["in my view", "to be fair", "islam", "mile", "opinion"]: assert b not in low, (k, b)
        print(k, len(v), "lines", len(txt.split()), "words")
