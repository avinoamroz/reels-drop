# -*- coding: utf-8 -*-
"""Who recognised Israel first? World map fills by recognition year, counter 0 to 169. usage: map_rec.py [--snaps=..]"""
import sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/click_1103")
from ck import *
from rec_data import REC, UNKNOWN, NO, lst
rid = "recognised_first_map"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
F = features()
IDX = {}
for k, v in F.items(): IDX[v["name"].lower()] = k
import json
for f in json.load(open(GEO))["features"]:
    p = f["properties"]
    for kk in ("NAME_LONG", "ADMIN", "FORMAL_EN", "NAME_SORT", "BRK_NAME", "NAME_ALT"):
        if p.get(kk): IDX.setdefault(p[kk].lower(), p["ADM0_A3"])
ALIAS = {"czech republic": "CZE", "dr congo": "COD", "republic of the congo": "COG", "cote d'ivoire": "CIV", "eswatini": "SWZ", "cabo verde": "CPV",
         "timor-leste": "TLS", "north macedonia": "MKD", "sao tome and principe": "STP", "united states": "USA", "micronesia": "FSM", "bahamas": "BHS",
         "gambia": "GMB", "tanzania": "TZA", "north korea": "PRK", "south korea": "KOR", "brunei": "BRN", "laos": "LAO", "russia": "RUS", "syria": "SYR",
         "iran": "IRN", "vietnam": "VNM", "moldova": "MDA", "guinea-bissau": "GNB", "bosnia and herzegovina": "BIH", "serbia": "SRB", "south sudan": "SDS",
         "marshall islands": "MHL", "solomon islands": "SLB", "saint vincent and the grenadines": "VCT", "saint kitts and nevis": "KNA",
         "antigua and barbuda": "ATG", "saint lucia": "LCA", "central african republic": "CAF", "equatorial guinea": "GNQ", "dominican republic": "DOM",
         "trinidad and tobago": "TTO", "papua new guinea": "PNG", "united kingdom": "GBR", "united arab emirates": "ARE"}
def code(n): return ALIAS.get(n.lower()) or IDX[n.lower()]
# light-up schedule: fractional year per country (1948 starts at 14 May)
SCHED = []
for y in sorted(REC):
    ns = lst(REC[y]); s0 = 0.37 if y == 1948 else 0.05
    for i, n in enumerate(ns): SCHED.append((y + s0 + (0.6 - s0 * 0.5) * i / max(1, len(ns)), code(n), n))
KF = [(1948.36, 0.0), (1948.99, T.at("3:seventeen")), (1950.99, T.at("4:forty")), (1969.99, T.at("5$")), (1979.5, T.at("6:Egypt,")),
      (1989.99, T.at("7:Forty")), (1999.99, T.at("7:including")), (2019.5, T.at("8")), (2020.99, T.at("8:Morocco.")), (2020.99, 99.0)]
ky = [a for a, _ in KF]; kt = [b for _, b in KF]
def year_at(t): return float(np.interp(t, kt, ky))
T_UNK = T.at("9:twenty"); T_NO = T.at("11"); T_US = T.at("13:the United"); T_SU = T.at("14:The Soviet")
UNK = [code(n) for n in lst(UNKNOWN)]; NOC = [code(n) for n in lst(NO)]
# map
MR = (0, 560, W, 1150); P = Proj((-125, -46, 152, 72), MR, lat0=40)
LAND = hx("#26385C"); SEA = (12, 24, 52); LIT = hx("#45A4DD"); LIT2 = hx("#7CC3EE"); NOCOL = hx("#6B5A72")
M = {}
for k, v in F.items():
    if k in ("ATA",): continue
    m = mask(v["polys"], P, ss=2, clip=MR)
    if m is not None: M[k] = m
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
def compR(arr, m, col, a):   # masks are in frame coords; arr is the map rect
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
for k, m in M.items(): compR(base, m, LAND, 1.0)
bimg = Image.fromarray(base.clip(0, 255).astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if k in M: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (60, 82, 122), 1)
LINES = np.asarray(bimg, np.float32)
SUBS = sub_chunks(T, [("May fourteenth, nineteen forty eight", "14 May 1948"), ("nineteen forty eight", "1948"), ("seventeen countries", "17 countries"),
                      ("nineteen fifty", "1950"), ("forty seven", "47"), ("Nineteen seventy nine", "1979"), ("Forty more", "40 more"), ("Twenty twenty", "2020"),
                      ("twenty one", "21"), ("one hundred sixty nine", "169"), ("one hundred ninety two", "192"), ("Twenty three", "23"), ("Twenty two", "22"),
                      ("Eleven minutes", "11 minutes")])
EVENTS = [(0.0, "14 May 1948: independence"), (T.at("3:seventeen"), "End of 1948: 17 countries"),
          (T.at("5"), "1960s: new African states"), (T.at("6:Egypt,"), "1979: Egypt, first Arab country"),
          (T.at("7"), "1990s: the Soviet Union breaks up"), (T.at("7:including"), "1994: Jordan"),
          (T.at("8"), "2020: Abraham Accords"), (T_UNK, "+21: date not on record"),
          (T.at("10"), "169 of the other 192 UN members"), (T_NO, "23 still do not"),
          (T.at("12"), "Recognising is not agreeing")]
REV = [(T_US, T_SU, ["First: the United States", "14 May 1948, 11 minutes later"]), (T_SU, DUR, ["First full legal: Soviet Union", "17 May 1948"])]
def lit_alpha(t, y):
    out = {}
    for yy, k, n in SCHED:
        if y >= yy:
            # time when year passed yy
            tt = float(np.interp(yy, ky[:-1], kt[:-1])); out[k] = min(1.0, (t - tt) / 0.35 + 0.2)
    return out
out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    y = year_at(t); im = stage(); d = ImageDraw.Draw(im)
    arr = LINES.copy(); la = lit_alpha(t, y); n = len(la)
    for k, a in la.items():
        if k in M: compR(arr, M[k], LIT, a)
    ua = 0.0
    if t >= T_UNK:
        for i, k in enumerate(UNK):
            a = min(1.0, (t - T_UNK - 0.05 * i) / 0.3)
            if a > 0: n += 1; compR(arr, M.get(k), LIT2, a)
    if t >= T_NO:
        a = min(1.0, (t - T_NO) / 0.5) * (0.75 + 0.25 * math.sin((t - T_NO) * 4))
        for k in NOC: compR(arr, M.get(k), NOCOL, a)
    for k in ("ISR", "PSX"): compR(arr, M.get(k), ISRAEL_GOLD if k == "ISR" else PAL_GOLD, 1.0)
    if t >= T_US:   # pulse the first two
        for k, t0 in (("USA", T_US), ("RUS", T_SU)):
            if t >= t0: compR(arr, M.get(k), YEL, 0.8 + 0.2 * math.sin((t - t0) * 5))
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P)
    ix, iy = P(35.0, 31.5); r = 9 + 3 * math.sin(t * 3)
    d.ellipse([ix - r, iy - r, ix + r, iy + r], outline=YEL, width=4); txt(d, ix - 16, iy - 22, "Israel", 40, YEL, 800, "rs", stroke=3)
    yh = hook(d, ["Who recognised", "Israel first?"], t)
    txt(d, W / 2, yh + 4, "1948 to today. 192 UN members.", 56, SILVER, 700, "ma")
    ys = "Today" if t >= T.at("10") else str(int(y)); YY = 1166
    txt(d, 46, YY, ys, 150, WHITE, 900, "la")
    txt(d, 1034, YY + 14, "Recognise Israel", 52, SILVER, 700, "ra"); txt(d, 1034, YY + 70, str(n), 110, YEL, 900, "ra")
    ev = [s for a, s in EVENTS if a <= t]; ra = 0; cur = None
    for a, b, ls in REV:
        if a <= t <= b: ra = min(1, (t - a) / 0.25); cur = ls
    if ev and ra < 1:
        for i, l in enumerate(wrap(ev[-1], 56, 990, 800)[:1]): txt(d, W / 2, 1374, l, fit(l, 56, 990, 800, 46), GOLD, 800, "ma", 1 - ra)
    if cur:
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        ld.rounded_rectangle([40, 1160, 1040, 1350], 26, fill=(8, 20, 46, int(245 * ra)), outline=YEL[:3] + (int(255 * ra),), width=4)
        for i, (s, col) in enumerate(zip(cur, (WHITE, YEL))): txt(ld, W / 2, 1180 + i * 84, s, fit(s, 72, 940, 900, 50), col, 900, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    source(d, "Source: Wikipedia, International recognition of Israel, Feb 2026")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
