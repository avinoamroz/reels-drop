import sys, json, subprocess, soundfile as sf, numpy as np
sys.path.insert(0, "/home/claude/reelkit"); import mix
rid, music = sys.argv[1], sys.argv[2]; D = f"/home/claude/click_1103/{rid}"
T = json.load(open(f"{D}/timing.json")); dur = round(T["dur"] + 0.9, 2)
vo, sr = sf.read(f"{D}/vo_final.wav"); assert sr == 48000
if vo.ndim > 1: vo = vo.mean(1)
bed = mix.bed(music, dur)
mix.mix(vo, dur, bed, [], f"{D}/mix.wav", music_db=-16.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{D}/audio.m4a"], check=True)
print(rid, dur)
