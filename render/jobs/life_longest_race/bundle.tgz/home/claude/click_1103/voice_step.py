"""voice_step.py <rid> [tempo]: house voice chain on <rid>/vo.wav -> vo_final.wav (48k) + timing.json (reel-time words per line)"""
import sys, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice
from clean_vo import clean as clean_vo
D = f"/home/claude/click_1103/{sys.argv[1]}"
voice.TEMPO = float(sys.argv[2]) if len(sys.argv) > 2 else 1.1
W = json.load(open(f"{D}/vo_words.json")); lines = voice.read_script(f"{D}/tts.txt")
dry = voice.chain_dry(f"{D}/vo.wav"); cl = clean_vo(dry, voice.SR)
y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); vo = voice.post(y)
k = (len(vo) / voice.SR - voice.LEAD) / (len(dry) / voice.SR); tm = lambda x: round(voice.LEAD + x * k, 3)
out, i = [], 0
for li, l in enumerate(lines):
    n = len(l.split()); ws = W[i:i + n]; i += n
    out.append(dict(i=li, text=l, t0=tm(ws[0]["start"]), t1=tm(ws[-1]["end"]), words=[dict(w=w["word"], t0=tm(w["start"]), t1=tm(w["end"])) for w in ws]))
assert i == len(W)
sf.write(f"{D}/vo_final.wav", vo.astype(np.float32), voice.SR)
json.dump(dict(dur=len(vo) / voice.SR, lines=out), open(f"{D}/timing.json", "w"), indent=0)
print(sys.argv[1], "dur", round(len(vo) / voice.SR, 2))
