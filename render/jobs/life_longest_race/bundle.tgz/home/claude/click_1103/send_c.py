"""send_c.py [ids] [--dry]: one GitHub render batch for the 5 click-study reels (voice and mix done locally)."""
import sys, os; sys.path.insert(0, "/home/claude/reelkit")
import cloud_render as C
B = "/home/claude/click_1103"
R = {"jlm_residents_race": "race.py cfg_jlm.py", "life_longest_race": "race.py cfg_life.py",
     "recognised_first_map": "map_rec.py", "women_vote_map": "map_women.py", "europe_jews_map": "map_eu.py"}
jobs = []
for rid, cmd in R.items():
    ents = [f"{B}/{x}" for x in cmd.split()] + [f"{B}/ck.py"]
    if rid == "recognised_first_map": ents.append(f"{B}/rec_data.py")
    jobs.append(dict(id=rid, cmd=f"cd {B} && python3 {cmd}", out=f"{B}/{rid}/out/{rid}.mp4", entry=ents,
                     add=[f"{B}/{rid}/timing.json", f"{B}/{rid}/audio.m4a", f"{B}/{rid}/tts.txt", f"{B}/flags"]))
only = [a for a in sys.argv[1:] if not a.startswith("--")]
if only: jobs = [j for j in jobs if j["id"] in only]
_c = C.collect
def coll(e, a):
    keep = []
    for f in _c(e, a):
        if f.startswith(B + "/"):
            rel = f[len(B) + 1:]
            if not (rel.endswith(".py") and "/" not in rel) and not rel.startswith("flags/") and f not in a: continue
        keep.append(f)
    return keep
C.collect = coll
if "--dry" in sys.argv:
    for j in jobs:
        fs = coll(j["entry"], j["add"]); print(j["id"], len(fs), sum(os.path.getsize(x) for x in fs) >> 20, "MB", [x for x in fs if "click_1103" in x])
else: C.send(jobs)
