# -*- coding: utf-8 -*-
"""Where did Europe's Jews go? Dot map 1933 to 1950 (USHMM), counter 9.5M to 3.5M. usage: map_eu.py [--snaps=..]"""
import sys
import numpy as np
from PIL import Image, ImageDraw
from matplotlib.path import Path as MPath
sys.path.insert(0, "/home/claude/click_1103")
from ck import *
rid = "europe_jews_map"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
F = features()
# USHMM Holocaust Encyclopedia: 1933 and 1950 figures (countries with both years given)
D = {"Poland": (["POL"], 3000000, 45000, (19.5, 52.0)), "Soviet Union": (["RUS", "UKR", "BLR"], 2525000, 2000000, (33.0, 52.5)),
     "Romania": (["ROU", "MDA"], 756000, 280000, (25.0, 45.9)), "Germany": (["DEU"], 525000, 37000, (10.3, 51.2)),
     "Hungary": (["HUN"], 445000, 190000, (19.3, 47.2)), "Czechoslovakia": (["CZE", "SVK"], 357000, 17000, (17.0, 49.4)),
     "Austria": (["AUT"], 191000, 18000, (14.5, 47.6)), "Britain": (["GBR"], 300000, 450000, (-1.8, 52.8)),
     "France": (["FRA"], 250000, 235000, (2.5, 46.8)), "Greece": (["GRC"], 73000, 7000, (22.0, 39.5)),
     "Yugoslavia": (["SRB", "HRV", "BIH", "SVN", "MNE", "MKD", "KOS"], 68000, 3500, (19.0, 44.0)), "Italy": (["ITA"], 48000, 35000, (12.5, 42.5)),
     "Bulgaria": (["BGR"], 48500, 6500, (25.3, 42.7))}
DOT = 20000
MR = (0, 548, W, 1236); P = Proj((-13.0, 29.0, 57.0, 66.5), MR, lat0=47)
LAND = hx("#26385C"); SEA = (12, 24, 52)
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, v in F.items():
    if k == "ATA": continue
    m = mask(v["polys"], P, 2, MR)
    if m is not None: compR(base, m, LAND, 1.0)
for k in ("ISR",): compR(base, mask(F["ISR"]["polys"], P, 2, MR), ISRAEL_GOLD, 1.0)
compR(base, mask(F["PSX"]["polys"], P, 2, MR), PAL_GOLD, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if k != "ATA": outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (66, 90, 132), 1)
BASE = bimg
# dots inside each country's polygons (Soviet Union: European part, west of 50 E)
rng = np.random.default_rng(7); DOTS = []
for gi, (nm, (codes, v33, v50, lab)) in enumerate(D.items()):
    n33 = int(round(v33 / DOT)); n50 = int(round(v50 / DOT))
    paths = []
    for c in codes:
        for poly in F[c]["polys"]: paths.append(MPath(np.array(poly[0])))
    pts = []; box = np.array([[p.vertices[:, 0].min(), p.vertices[:, 1].min(), p.vertices[:, 0].max(), p.vertices[:, 1].max()] for p in paths])
    lo0, la0, lo1, la1 = box[:, 0].min(), box[:, 1].min(), box[:, 2].max(), box[:, 3].max()
    if nm == "Soviet Union": lo1 = min(lo1, 50.0); la0 = max(la0, 44.5); la1 = min(la1, 60.5)
    nn = max(n33, n50)
    while len(pts) < nn:
        q = np.column_stack([rng.uniform(lo0, lo1, 4000), rng.uniform(la0, la1, 4000)]); ok = np.zeros(len(q), bool)
        for p in paths: ok |= p.contains_points(q)
        pts += [tuple(x) for x in q[ok]]
    extra = pts[n33:nn]; pts = pts[:n33]; order = rng.permutation(n33)
    for j, (lo, la) in enumerate(pts):
        DOTS.append((P(lo, la), nm, int(np.where(order == j)[0][0]) < n50))   # first n50 of the shuffled order survive
    for lo, la in extra: DOTS.append((P(lo, la), nm, "new"))                   # growth (Britain 300,000 to 450,000)
SUBS = sub_chunks(T, [("Nineteen thirty three", "1933"), ("Nine and a half million", "9.5 million"), ("over three million", "over 3 million"),
                      ("two and a half million", "2.5 million"), ("nineteen fifty", "1950"), ("three and a half million", "3.5 million"),
                      ("three million", "3 million"), ("forty five thousand", "45,000"), ("over half a million", "over 500,000"),
                      ("thirty seven thousand", "37,000"), ("one hundred thirty six thousand", "136,000"), ("eighty thousand", "80,000"),
                      ("two million", "2 million"), ("Six million", "6 million")])
TW0 = T.at("6"); TW1 = T.at("7:three")       # the war years: 1939 to 1950 on the clock
KF = [(1933.0, 0.0), (1939.0, TW0), (1945.0, TW0 + (TW1 - TW0) * 0.7), (1950.0, TW1), (1950.0, 99.0)]
ky = [a for a, _ in KF]; kt = [b for _, b in KF]
def year_at(t): return float(np.interp(t, kt, ky))
def loss(y): return ease((y - 1939.0) / 7.0)
NAMED = [("3:Poland,", "Poland", "3,000,000"), ("3:The", "Soviet Union", "2,525,000"), ("4:Romania.", "Romania", "756,000"), ("4:Germany.", "Germany", "525,000"),
         ("4:Hungary.", "Hungary", "445,000"), ("4:Britain.", "Britain", "300,000"), ("4:France.", "France", "250,000"),
         ("8:Poland,", "Poland", "3,000,000 to 45,000"), ("9:Germany,", "Germany", "525,000 to 37,000"), ("12:The", "Soviet Union", "about 2,000,000")]
NAMED = [(T.at(m), nm, s) for m, nm, s in NAMED]
T_ARC = T.at("11:About"); T_US = T.at("11:Over"); T_REV = T.at("14"); T_MISS = T.at("13")
EV = [(0.0, "1933: 9.5 million Jews in Europe"), (T.at("5"), "Families, schools, synagogues, whole towns"), (TW0, "1939 to 1945: the Nazis and the war"),
      (TW1, "1950: 3.5 million"), (T.at("10"), "Survivors rebuild far away"), (T.at("12"), "Soviet Union: about 2 million remain"),
      (T_MISS, "Most of the missing never went anywhere")]
def arc(d, a, b, u, col, w=5, bend=0.25):
    (x0, y0), (x1, y1) = a, b; mx, my = (x0 + x1) / 2, (y0 + y1) / 2; nx, ny = -(y1 - y0) * bend, (x1 - x0) * bend
    pts = []
    for i in range(int(40 * u) + 1):
        s = i / 40; pts.append(((1 - s) ** 2 * x0 + 2 * (1 - s) * s * (mx + nx) + s * s * x1, (1 - s) ** 2 * y0 + 2 * (1 - s) * s * (my + ny) + s * s * y1))
    if len(pts) > 1: d.line(pts, fill=col, width=w, joint="curve")
out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    y = year_at(t); L = loss(y); im = stage(); im.paste(BASE, (0, MR[1])); d = ImageDraw.Draw(im, "RGBA")
    israel_lines(d, P)
    cur = [(a, nm, s) for a, nm, s in NAMED if a <= t < a + (1.6 if a < TW0 else 3.0)]
    hot = {nm for _, nm, _ in cur}
    ghost_a = 0.32 + (0.25 * min(1, (t - T_REV) / 0.6) if t >= T_REV else 0)
    for i, ((x, yy), nm, surv) in enumerate(DOTS):
        tw_ = 0.85 + 0.15 * math.sin(t * 2.2 + i * 1.7)
        if surv == "new":
            if L > 0: r = 4.6; d.ellipse([x - r, yy - r, x + r, yy + r], fill=hx("#F2C14E")[:3] + (int(240 * L * tw_),))
            continue
        if surv or L <= 0:
            r = 4.6 * (1.25 if nm in hot else 1.0); c = YEL if nm in hot else hx("#F2C14E")
            d.ellipse([x - r, yy - r, x + r, yy + r], fill=c[:3] + (int(240 * tw_),))
        else:
            k = (i * 0.618) % 1.0; Lk = min(1.0, max(0.0, (L - k * 0.7) / 0.3))   # each dot turns at its own moment
            if Lk < 1:
                r = 4.6; d.ellipse([x - r, yy - r, x + r, yy + r], fill=hx("#F2C14E")[:3] + (int(240 * (1 - Lk) * tw_),))
            if Lk > 0:
                r = 4.2; d.ellipse([x - r, yy - r, x + r, yy + r], outline=(200, 210, 226, int(255 * ghost_a * Lk)), width=2)
    for a, nm, s in cur:
        lx, ly = P(*D[nm][3]); al = min(1, (t - a) / 0.2)
        txt(d, lx, ly - 26, nm, 44, WHITE, 900, "mm", al, stroke=4); txt(d, lx, ly + 26, s, 44, YEL, 900, "mm", al, stroke=4)
    if t >= T_ARC:
        u = min(1, (t - T_ARC) / 1.2); src = P(14.0, 49.0); arc(d, src, P(34.9, 31.8), u, YEL[:3] + (230,), 6, -0.2)
        if u >= 1: txt(d, P(34.9, 31.8)[0] + 10, P(34.9, 31.8)[1] - 56, "Israel: about 136,000", 40, YEL, 800, "rm", stroke=4)
    if t >= T_US:
        u = min(1, (t - T_US) / 1.0); arc(d, P(2.0, 48.0), P(-13.0, 41.0), u, SKY_L[:3] + (230,), 6, 0.25)
        if u >= 1: txt(d, P(-12.5, 39.4)[0], P(-12.5, 39.4)[1], "USA: 80,000+", 40, SKY_L, 800, "la", stroke=4)
    yh = hook(d, ["Where did", "Europe's Jews go?"], t)
    txt(d, W / 2, yh + 4, "1933 to 1950. One counter.", 56, SILVER, 700, "ma")
    cnt = 9500000 - 6000000 * L
    YY = 1240; txt(d, 46, YY, str(int(y)), 150, WHITE, 900, "la")
    txt(d, 1034, YY + 14, "Jews in Europe", 52, SILVER, 700, "ra"); txt(d, 1034, YY + 62, f"{int(round(cnt, -4)):,}", 84, YEL, 900, "ra")
    ra = min(1, (t - T_REV) / 0.3) if t >= T_REV else 0
    ev = [s for a, s in EV if a <= t]
    if ev and ra < 1: txt(d, W / 2, 1402, ev[-1], fit(ev[-1], 54, 1000, 800, 44), GOLD, 800, "ma", 1 - ra)
    if ra > 0:
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        ld.rounded_rectangle([40, 1232, 1040, 1426], 26, fill=(8, 20, 46, int(245 * ra)), outline=SILVER[:3] + (int(255 * ra),), width=4)
        txt(ld, W / 2, 1252, "6 million murdered", 80, WHITE, 900, "ma", ra); txt(ld, W / 2, 1346, "in the Holocaust", 60, SILVER, 800, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    lg = MR[3] - 40; d.ellipse([44, lg - 9, 62, lg + 9], fill=hx("#F2C14E")); txt(d, 74, lg, "= 20,000 people (13 countries)", 38, SILVER, 700, "lm", stroke=3)
    source(d, "Source: USHMM Holocaust Encyclopedia, 1933 and 1950")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
