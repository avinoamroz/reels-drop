# -*- coding: utf-8 -*-
"""When could women vote here? Middle East map + year counter. usage: map_women.py [--snaps=..]"""
import sys
import numpy as np
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/claude/click_1103")
from ck import *
rid = "women_vote_map"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
F = features()
# code, year, label (lon, lat), anchor (lon, lat) or None, limited?, caption
C = [("TUR", 1930, (37.0, 39.1), None, False, "1930: Turkey (national vote 1934)"),
     ("ISR", 1948, (28.6, 31.7), (34.8, 31.6), False, "1948: Israel, from its first election"),
     ("SYR", 1949, (38.6, 35.2), None, True, "1949: Syria, with limits (lifted 1953)"),
     ("LBN", 1952, (28.6, 33.8), (35.8, 33.9), False, "1952: Lebanon"),
     ("EGY", 1956, (29.8, 26.2), None, False, "1956: Egypt"),
     ("CYP", 1960, (28.6, 35.9), (33.0, 35.1), False, "1960: Cyprus"),
     ("IRN", 1963, (54.5, 32.6), None, False, "1963: Iran"),
     ("YEM", 1967, (47.5, 15.6), None, False, "1967: South Yemen (North: 1970)"),
     ("JOR", 1974, (37.4, 30.6), None, False, "1974: Jordan"),
     ("IRQ", 1980, (43.4, 33.0), None, False, "1980: Iraq"),
     ("OMN", 1994, (57.0, 20.3), None, True, "1994: Oman, a hand picked few (all: 2003)"),
     ("QAT", 1998, (51.4, 22.7), (51.2, 25.2), True, "1998: Qatar, city council (parliament: 2021)"),
     ("BHR", 2002, (48.9, 24.9), (50.55, 26.05), False, "2002: Bahrain"),
     ("KWT", 2005, (47.2, 31.3), (47.6, 29.3), False, "2005: Kuwait"),
     ("ARE", 2006, (55.2, 26.7), (54.3, 24.2), True, "2006: UAE, chosen electoral college"),
     ("SAU", 2015, (44.0, 22.4), None, True, "2015: Saudi Arabia, city councils only")]
KF = [(1910.0, 0.0), (1920.0, T.at("2:Jewish")), (1930.0, T.at("3:Turkey,")), (1948.0, T.at("4:Israel.")), (1948.0, T.at("5$")),
      (1949.0, T.at("6:Syria,")), (1952.0, T.at("6:Lebanon,")), (1956.0, T.at("6:Egypt,")), (1960.0, T.at("7:Cyprus,")), (1963.0, T.at("7:Iran,")),
      (1967.0, T.at("7:South")), (1974.0, T.at("8:Jordan,")), (1980.0, T.at("8:Iraq,")), (1980.5, T.at("9")), (1994.0, T.at("10:Oman,")),
      (1998.0, T.at("10:Qatar,")), (2002.0, T.at("11:Bahrain,")), (2005.0, T.at("11:Kuwait,")), (2006.0, T.at("12:The")), (2015.0, T.at("13:Saudi")), (2015.0, 99.0)]
ky = [a for a, _ in KF]; kt = [b for _, b in KF]
def year_at(t): return float(np.interp(t, kt, ky))
def t_of(yr):
    for (a, ta), (b, tb) in zip(KF, KF[1:]):
        if a <= yr <= b and b > a: return ta + (tb - ta) * (yr - a) / (b - a)
        if yr == a: return ta
    return 99.0
MR = (0, 548, W, 1228); P = Proj((18.5, 11.0, 67.5, 43.2), MR, lat0=27)
LAND = hx("#26385C"); SEA = (12, 24, 52); LIT = hx("#45A4DD"); LIT2 = hx("#9FD3F2")
def compR(arr, m, col, a):
    if m is None or a <= 0: return
    x0, y0, A = m; comp(arr, (x0, y0 - MR[1], A), col, a)
M = {k: mask(v["polys"], P, 2, MR) for k, v in F.items() if k != "ATA"}
base = np.zeros((MR[3] - MR[1], W, 3), np.float32); base[:] = SEA
for k, m in M.items(): compR(base, m, LAND, 1.0)
bimg = Image.fromarray(base.astype(np.uint8)); bd = ImageDraw.Draw(bimg)
for k, v in F.items():
    if M.get(k) is not None: outline(bd, v["polys"], lambda lo, la: (P(lo, la)[0], P(lo, la)[1] - MR[1]), (70, 94, 136), 2)
BASE = np.asarray(bimg, np.float32)
SUBS = sub_chunks(T, [("Nineteen twenty", "1920"), ("Nineteen thirty", "1930"), ("Nineteen forty eight", "1948"), ("eighteen years", "18 years"),
                      ("forty nine", "1949"), ("fifty two", "1952"), ("fifty six", "1956"), ("sixty three", "1963"), ("sixty seven", "1967"), ("sixty", "1960"),
                      ("seventy four", "1974"), ("eighty", "1980"), ("ninety four", "1994"), ("ninety eight", "1998"), ("two thousand two", "2002"),
                      ("two thousand five", "2005"), ("two thousand six", "2006"), ("twenty fifteen", "2015"), ("eighty five years", "85 years")])
T_Y = T.at("2:Jewish"); T_REV = T.at("14"); T_BEAT = T.at("5")
out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    y = year_at(t); im = stage()
    arr = BASE.copy(); n = 0; last = None
    for k, yr, lab, anc, lim, cap in C:
        if y >= yr - 1e-6:
            a = min(1.0, (t - t_of(yr)) / 0.35 + 0.15); n += 1; last = cap
            if k != "ISR": compR(arr, M[k], LIT2 if lim else LIT, a)
    isr_a = 1.0 if y >= 1948 else (0.55 if t >= T_Y else 0.35)
    compR(arr, M["ISR"], ISRAEL_GOLD, isr_a); compR(arr, M["PSX"], PAL_GOLD, isr_a)
    im.paste(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), (0, MR[1])); d = ImageDraw.Draw(im)
    israel_lines(d, P, isr_a)
    for k, yr, lab, anc, lim, cap in C:
        if y >= yr - 1e-6:
            a = min(1.0, (t - t_of(yr)) / 0.3 + 0.2); x, yy = P(*lab)
            if anc:
                ax, ay = P(*anc); d.line([(x, yy), (ax, ay)], fill=WHITE[:3] + (int(200 * a),), width=3); d.ellipse([ax - 5, ay - 5, ax + 5, ay + 5], fill=WHITE)
            txt(d, x, yy, str(yr), 42, YEL, 900, "mm", a, stroke=4)
    if T_Y <= t < T.at("3:Turkey,") + 0.5:   # 1920 Yishuv vote: pulse on the land
        x, yy = P(34.9, 31.7); r = 22 + 6 * math.sin(t * 5); d.ellipse([x - r, yy - r, x + r, yy + r], outline=YEL, width=5)
    yh = hook(d, ["When could women", "vote here?"], t)
    txt(d, W / 2, yh + 4, "16 countries. 1920 to 2015.", 56, SILVER, 700, "ma")
    YY = 1232; txt(d, 46, YY, str(int(y)), 150, WHITE, 900, "la")
    txt(d, 1034, YY + 14, "Women can vote", 52, SILVER, 700, "ra"); txt(d, 1034, YY + 62, f"{n} of 16", 86, YEL, 900, "ra")
    ev = "1920: Jewish community assembly vote" if (T_Y <= t and n == 0) else last
    if t >= T_BEAT and t < T.at("6:Syria,"): ev = "Turkey: 18 years before Israel"
    ra = min(1, (t - T_REV) / 0.25) if t >= T_REV else 0
    if ev and ra < 1: txt(d, W / 2, 1402, ev, fit(ev, 54, 1000, 800, 44), GOLD, 800, "ma", 1 - ra)
    if ra > 0:
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        ld.rounded_rectangle([40, 1232, 1040, 1426], 26, fill=(8, 20, 46, int(245 * ra)), outline=YEL[:3] + (int(255 * ra),), width=4)
        for i, (s, col) in enumerate(zip(["First to last: 85 years", "Saudi Arabia: still no elected parliament"], (WHITE, YEL))):
            txt(ld, W / 2, 1254 + i * 86, s, fit(s, 72 if i == 0 else 56, 940, 900, 44), col, 900, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    lg_y = MR[3] - 46; d.rounded_rectangle([40, lg_y, 76, lg_y + 30], 6, fill=LIT2); txt(d, 88, lg_y + 15, "limited at first", 38, SILVER, 700, "lm", stroke=3)
    source(d, "Sources: IPU; Carnegie 2008; US Library of Congress 2015; UAE NEC")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
