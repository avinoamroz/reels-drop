"""terror_compare: "Jewish suicide bombings: 0". A calm, fair two-column scorecard: Jewish extremist attacks (left, sky) vs
HAMAS and other Palestinian armed groups (right, red). Timeline map of 5 Jewish extremist attacks with a counter, Israel's answer
(checklist), 147 suicide bombings as a dot grid (ITIC 2006), 10 children (HRW 2004), honour vs removal, payments (US State Dept
2026), Pew 2013 bars, the final scorecard, UN OCHA settler attacks, and a loop back to frame 0. Icons and type only.
   python3 engine.py [--frames t1,t2,...] [--out path.mp4]   (DIR: timing.json, geo_il.json, mix.m4a)"""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"


def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u

NAVYD, NAVY, SKY, YEL = hx("#0B1426"), hx("#163261"), hx("#45A4DD"), hx("#FFCD50")
RED, GREEN, GOLD = hx("#E5484D"), hx("#3FBF7F"), hx("#C9A85C")
GL = (46 / 255, 204 / 255, 113 / 255, 1); SILVER = hx("#CBD3E3"); WHITE = (1, 1, 1, 1)
GOLD_IL, GOLD_PA = hx("#E0B252"), hx("#B8923F")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    if a <= 0.01 or not s: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def parts(c, ps, size, y, a=1.0, w=900, sc=1.0, maxw=960, x=540):
    while size > 40 and sum(font(size, w).getlength(s) for s, _ in ps) > maxw: size -= 2
    tot = sum(font(size, w).getlength(s) for s, _ in ps); xx = x - tot / 2
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    for s, col in ps: xx += text(c, s, size, xx, y, w, col, a, "l")
    c.restore()
def fit(s, size, maxw, w=800, mn=36):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def ftext(c, s, size, x, y, maxw, w=800, col=WHITE, a=1.0, align="c", mn=36):
    return text(c, s, fit(s, size, maxw, w, mn), x, y, w, col, a, align)
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def card(c, x, y, w, h, col=WHITE, a=1.0, fa=0.07, stroke=None, r=34):
    rr(c, x, y, w, h, r); c.set_source_rgba(*col[:3], fa * a); c.fill()
    if stroke:
        rr(c, x, y, w, h, r); c.set_source_rgba(*stroke[:3], 0.9 * a); c.set_line_width(4); c.stroke()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def check(c, x, y, s, col, a):          # tick in a circle
    c.set_source_rgba(*col[:3], a); c.arc(x, y, s, 0, 6.283); c.fill()
    c.move_to(x - s * 0.45, y + s * 0.02); c.line_to(x - s * 0.1, y + s * 0.36); c.line_to(x + s * 0.5, y - s * 0.34)
    c.set_source_rgba(*NAVYD[:3], a); c.set_line_width(s * 0.22); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
def icon_build(c, x, y, s, col, a):     # a simple building (women's centre)
    c.set_source_rgba(*col[:3], a); c.move_to(x - s, y - s * 0.3); c.line_to(x, y - s * 1.0); c.line_to(x + s, y - s * 0.3); c.close_path(); c.fill()
    rr(c, x - s * 0.8, y - s * 0.3, s * 1.6, s * 1.1, 4); c.fill()
    c.set_source_rgba(*NAVYD[:3], a)
    for dx in (-0.45, 0, 0.45): rr(c, x + dx * s - s * 0.13, y - s * 0.1, s * 0.26, s * 0.55, 3); c.fill()
def icon_coin(c, x, y, s, col, a):
    c.set_source_rgba(*col[:3], a); c.arc(x, y, s, 0, 6.283); c.fill()
    text(c, "$", int(s * 1.3), x, y + s * 0.45, 900, NAVYD, a)

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 1.2, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1
T_FADE = END - 0.85
def sa(t, i0, i1=None, fi=0.3, fo=0.3):
    """alpha of a block living from scene i0 to scene i1 (inclusive)"""
    i1 = i0 if i1 is None else i1
    return ramp(t, CUT[i0], CUT[i0] + fi) * (1 - ramp(t, CUT[i1 + 1] - fo, CUT[i1 + 1]))

# ------------------------------------------------------------------ header: the two columns
COLX = (290, 790)
def draw_header(c, t):
    i = scene_at(t)
    if i == 0 or i >= 14: return
    a = ramp(t, CUT[1], CUT[1] + 0.4) * (1 - ramp(t, CUT[14] - 0.3, CUT[14]))
    act = 0 if i <= 5 else (1 if i <= 10 else 2)
    if i in (11, 13): act = 3
    for k, (lab, sub, col) in enumerate((("Jewish extremist", "attacks", SKY), ("HAMAS and other", "armed groups", RED))):
        on = act == 2 or act == k
        aa = a * (1.0 if on else 0.35)
        x = COLX[k]
        card(c, x - 235, 262, 470, 128, col, aa, 0.16, col if on and act != 2 else None, 30)
        text(c, lab, fit(lab, 50, 430, 800), x, 318, 800, WHITE, aa)
        text(c, sub, fit(sub, 50, 430, 800), x, 372, 800, col, aa)

# ------------------------------------------------------------------ scene 0: hook (also the loop target)
def draw_hook(c, t, a):
    if a <= 0.01: return
    text(c, "Jewish suicide", 128, 540, 470, 900, WHITE, a)
    text(c, "bombings:", 128, 540, 610, 900, WHITE, a)
    u = eout(t / 1.3) if t < 3 else 1.0
    cx, cy, R = 540, 1000, 250
    glow(c, cx, cy, 420, SKY, 0.22 * a)
    c.set_source_rgba(*SKY[:3], 0.18 * a); c.arc(cx, cy, R, 0, 6.283); c.fill()
    c.set_source_rgba(*SKY[:3], 0.95 * a); c.set_line_width(14); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.arc(cx, cy, R, -math.pi / 2, -math.pi / 2 + 2 * math.pi * max(0.001, u)); c.stroke()
    br = 1 + 0.02 * math.sin(t * 2.4)
    text(c, "0", 400, cx, cy + 142, 900, YEL, a, sc=br)
    s1 = wt(0, "Not") if t < 30 else 0
    b = ramp(t, s1, s1 + 0.3) if t < 30 else 1.0
    text(c, "Not one on record", 72, 540, 1380, 800, WHITE, a * b)
    text(c, "Univ. of Chicago CPOST Suicide Attack Database, 1974 to 2019", fit("Univ. of Chicago CPOST Suicide Attack Database, 1974 to 2019", 38, 960, 700), 540, 1470, 700, SILVER, a * b)

# ------------------------------------------------------------------ scene 1
def draw_real(c, t):
    a = sa(t, 1)
    if a <= 0.01: return
    text(c, "Jewish terror", 130, 540, 760, 900, WHITE, a)
    text(c, "is real.", 130, 540, 900, 900, WHITE, a)
    s = wt(1, "horrible"); b = ramp(t, s - 0.1, s + 0.2)
    text(c, "And horrible.", 130, 540, 1120, 900, RED, b * a, sc=max(0.01, eob(clamp((t - s + 0.1) / 0.4))))

# ------------------------------------------------------------------ scenes 2-3: timeline map
GIL = json.load(open(f"{D}/geo_il.json"))
COSF = math.cos(math.radians(31.5)); MK = 240; MLON, MLAT = 35.0, 31.45; MCX, MCY = 290, 985
def P(lon, lat): return MCX + (lon - MLON) * COSF * MK, MCY - (lat - MLAT) * MK
def poly(c, rings):
    for r in rings:
        for i, (lo, la) in enumerate(r):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.close_path()
def map_bg():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    for iso, rings in GIL["me"].items():
        if iso in ("EG", "JO", "LB", "SY"):
            poly(c, rings); c.set_source_rgba(*hx("#24324D")[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.3); c.set_line_width(1.5); c.stroke()
    poly(c, GIL["isr"]); c.set_source_rgba(*GOLD_IL[:3], 1); c.fill()
    poly(c, GIL["pal"]); c.set_source_rgba(*GOLD_PA[:3], 1); c.fill()
    poly(c, GIL["lakes"]); c.set_source_rgba(*hx("#2A4A85")[:3], 1); c.fill()
    c.set_source_rgba(*GL[:3], 1); c.set_line_width(3)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    s.flush(); return s
MAPBG = map_bg()
# year, place, killed, lon, lat, short line
ATT = [(1990, "Rishon LeZion", 7, 34.79, 31.96, "Gunman, Ami Popper"),
       (1994, "Hebron", 29, 35.11, 31.52, "Baruch Goldstein"),
       (2005, "Shfar'am", 4, 35.17, 32.81, "Bus, Eden Natan-Zada"),
       (2014, "Jerusalem", 1, 35.23, 31.82, "Mohammed Abu Khdeir, 16"),
       (2015, "Duma", 3, 35.37, 32.06, "Arson, Dawabsheh family")]
def att_t(k):
    if k == 1: return wt(2, "1994") - 0.05
    key = {0: "seven", 2: "four", 3: "teenager", 4: "family"}[k]
    return wt(3, key) - 0.1
AT = [att_t(k) for k in range(5)]
def draw_map(c, t):
    a = sa(t, 2, 3, 0.4, 0.35)
    if a <= 0.01: return
    c.save(); c.rectangle(0, 400, W, 1140); c.clip()
    c.set_source_surface(MAPBG, 0, 0); c.paint_with_alpha(a); c.restore()
    order = [1, 0, 2, 3, 4]                     # Hebron first (line 2), then chronological
    n = 0; tot = 0
    for k in range(5):
        u = clamp((t - AT[k]) / 0.4)
        if u <= 0: continue
        yr, pl, kd, lo, la, who = ATT[k]; x, y = P(lo, la)
        dt = t - AT[k]
        if dt < 1.2:
            c.set_source_rgba(*RED[:3], a * (1 - dt / 1.2)); c.set_line_width(4); c.arc(x, y, 18 + 70 * dt, 0, 6.283); c.stroke()
        c.set_source_rgba(*WHITE[:3], a); c.arc(x, y, 15 * eob(u), 0, 6.283); c.fill()
        c.set_source_rgba(*RED[:3], a); c.arc(x, y, 10 * eob(u), 0, 6.283); c.fill()
        tot += kd * eout((t - AT[k]) / 0.8)
    # timeline cards on the right, chronological
    for k in range(5):
        u = clamp((t - AT[k]) / 0.35)
        if u <= 0: continue
        yr, pl, kd, lo, la, who = ATT[k]
        yy = 460 + k * 152 + (1 - eout(u)) * 30
        cur = scene_at(t) == 2 and k == 1 or (scene_at(t) == 3 and max(j for j in range(5) if t >= AT[j]) == k)
        card(c, 560, yy, 470, 138, WHITE, a * u, 0.12 if cur else 0.07, RED if cur else None, 26)
        text(c, str(yr), 52, 590, yy + 60, 900, SKY, a * u, "l")
        ftext(c, pl, 52, 720, yy + 60, 290, 800, WHITE, a * u, "l", 40)
        text(c, f"{kd} killed", 52, 590, yy + 118, 900, YEL, a * u, "l")
        x1, y1 = P(lo, la)
    text(c, "Killed in these 5", 52, 795, 1290, 800, WHITE, a)
    text(c, str(int(round(tot))), 130, 795, 1430, 900, YEL, a)
    text(c, "Shamgar Commission 1994; Israeli court rulings 1991 to 2020", fit("Shamgar Commission 1994; Israeli court rulings 1991 to 2020", 38, 960, 700), 540, 1530, 700, SILVER, a)

# ------------------------------------------------------------------ scenes 4-5: Israel's answer
ANS = [("“A shame on Zionism”", "PM Rabin, Knesset, 1994", wt(4, "shame")),
       ("Kach movement banned", "Israeli cabinet, March 1994", wt(5, "movement")),
       ("Killers jailed, some for life", "Popper, Abu Khdeir and Duma killers", wt(5, "killers")),
       ("Goldstein's shrine bulldozed", "By law, 1999", wt(5, "shrine"))]
def draw_answer(c, t):
    a = sa(t, 4, 5)
    if a <= 0.01: return
    text(c, "Israel's answer", 110, 540, 560, 900, WHITE, a)
    for k, (en, src, t0) in enumerate(ANS):
        u = clamp((t - t0 + 0.1) / 0.35)
        if u <= 0: continue
        y = 660 + k * 200 + (1 - eout(u)) * 26
        card(c, 70, y, 940, 176, SKY, a * u, 0.12, None, 30)
        check(c, 150, y + 88, 42 * eob(u), GREEN, a * u)
        ftext(c, en, 62, 220, y + 84, 760, 800, WHITE, a * u, "l", 48)
        ftext(c, src, 42, 220, y + 140, 760, 700, SILVER, a * u, "l", 36)

# ------------------------------------------------------------------ scenes 6-8: 147 suicide bombings
NDOT, DC, DR = 147, 21, 7
CHILD = [3, 18, 27, 44, 59, 71, 88, 102, 117, 133]     # 10 dots (illustrative positions)
def dot_t(j):
    t0 = wt(7, "hundred") - 0.2; return t0 + 2.2 * (j / NDOT) ** 0.9
def draw_bombings(c, t):
    a = sa(t, 6, 8)
    if a <= 0.01: return
    i = scene_at(t)
    if i == 6:
        b = ramp(t, CUT[6], CUT[6] + 0.3)
        text(c, "Now the", 110, 540, 820, 900, WHITE, a * b)
        text(c, "other column.", 110, 540, 960, 900, RED, a * b)
        return
    text(c, "2000 to 2005", 72, 540, 520, 800, SKY, a)
    n = sum(1 for j in range(NDOT) if t >= dot_t(j))
    text(c, str(n), 230, 540, 760, 900, YEL, a)
    text(c, "suicide bombings", 72, 540, 860, 900, WHITE, a)
    x0, y0, sp = 90, 930, 900 / (DC - 1) * 0.98
    kids = i >= 8; ck = ramp(t, CUT[8], CUT[8] + 0.6)
    for j in range(NDOT):
        u = clamp((t - dot_t(j)) / 0.25)
        if u <= 0: continue
        x = x0 + (j % DC) * sp; y = y0 + (j // DC) * 44
        isk = j in CHILD
        col = YEL if (isk and kids) else RED
        r = 13 * eob(u) * (1 + 0.35 * ck if isk and kids else 1)
        al = a * (0.35 + 0.65 * ck if not isk and kids else 1) if kids else a
        if not isk and kids: al = a * (1 - 0.6 * ck)
        c.set_source_rgba(*col[:3], al); c.arc(x, y, r, 0, 6.283); c.fill()
    k5 = wt(7, "Over") - 0.1
    if not kids:
        b = ramp(t, k5, k5 + 0.3)
        parts(c, [("Over ", WHITE), ("500", YEL), (" killed", WHITE)], 96, 1350, a * b)
    else:
        parts(c, [("At least ", WHITE), ("10", YEL), (" were children", WHITE)], 92, 1350, a * ck)
    src = "Intelligence and Terrorism Information Center, Jan 2006" if not kids else "Human Rights Watch, Nov 2004 (bombers under 18)"
    text(c, src, fit(src, 38, 960, 700), 540, 1450, 700, SILVER, a)
    text(c, "HAMAS, PIJ, Al-Aqsa Brigades, PFLP", 44, 540, 1515, 700, SILVER, a * (1 - ck if kids else 1))

# ------------------------------------------------------------------ scene 9: honour vs removal
def draw_honour(c, t):
    a = sa(t, 9)
    if a <= 0.01: return
    text(c, "Who gets honoured?", 100, 540, 540, 900, WHITE, a)
    # left: removed
    card(c, 60, 620, 470, 620, SKY, a, 0.13, None, 34)
    c.set_source_rgba(*SKY[:3], a); c.set_line_width(10); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.move_to(240, 720); c.line_to(350, 830); c.move_to(350, 720); c.line_to(240, 830); c.stroke()
    text(c, "Goldstein's", 60, 295, 940, 900, WHITE, a)
    text(c, "shrine", 60, 295, 1010, 900, WHITE, a)
    text(c, "Removed", 64, 295, 1110, 900, SKY, a)
    text(c, "By law, 1999", 44, 295, 1180, 700, SILVER, a)
    # right: named
    s = wt(9, "center") - 0.2; b = ramp(t, s, s + 0.35)
    card(c, 550, 620, 470, 620, RED, a * b, 0.13, None, 34)
    icon_build(c, 785, 790, 62, RED, a * b)
    text(c, "Women's centre", 56, 785, 940, 900, WHITE, a * b)
    text(c, "named after", 56, 785, 1006, 800, WHITE, a * b)
    text(c, "Dalal Mughrabi", 56, 785, 1072, 900, RED, a * b)
    text(c, "1978 attack, 38 killed", 44, 785, 1180, 700, SILVER, a * b)
    s2 = wt(9, "UN"); b2 = ramp(t, s2 - 0.1, s2 + 0.25)
    text(c, "The UN pulled out, 2017", 76, 540, 1360, 900, YEL, a * b2, sc=max(0.01, eob(clamp((t - s2 + 0.1) / 0.4))))
    text(c, "UN Secretary-General's office, May 2017", 38, 540, 1450, 700, SILVER, a * b2)

# ------------------------------------------------------------------ scene 10: payments
def draw_pay(c, t):
    a = sa(t, 10)
    if a <= 0.01: return
    text(c, "Payments to", 100, 540, 600, 900, WHITE, a)
    text(c, "attackers' families", 100, 540, 720, 900, WHITE, a)
    for k in range(3):
        u = clamp((t - CUT[10] - 0.15 * k) / 0.4)
        icon_coin(c, 380 + 160 * k, 900 + (1 - eob(u)) * 40, 62, YEL, a * u)
    s = wt(10, "continue"); b = ramp(t, s - 0.4, s)
    text(c, "Still paid", 130, 540, 1180, 900, RED, a * b, sc=max(0.01, eob(clamp((t - s + 0.4) / 0.4))))
    text(c, "US State Department report to Congress, 2026", fit("US State Department report to Congress, 2026", 40, 960, 700), 540, 1300, 700, SILVER, a)
    text(c, "PA “martyr” and prisoner payments, renamed in 2025", fit("PA “martyr” and prisoner payments, renamed in 2025", 40, 960, 700), 540, 1360, 700, SILVER, a)

# ------------------------------------------------------------------ scene 11: Pew
PEW = [("Pakistan", 89), ("Indonesia", 81), ("Nigeria", 78), ("Tunisia", 77)]
def draw_pew(c, t):
    a = sa(t, 11)
    if a <= 0.01: return
    text(c, "Most Muslims", 120, 540, 540, 900, WHITE, a)
    text(c, "reject this", 120, 540, 670, 900, GREEN, a)
    text(c, "Suicide bombing is never justified:", fit("Suicide bombing is never justified:", 56, 960, 800), 540, 790, 800, SILVER, a)
    t0 = wt(11, "Pakistan") - 0.2
    for k, (nm, v) in enumerate(PEW):
        u = eout((t - t0 - 0.25 * k) / 0.8)
        y = 850 + k * 140
        text(c, nm, 56, 80, y + 66, 800, WHITE, a, "l")
        rr(c, 380, y + 20, 520, 64, 32); c.set_source_rgba(1, 1, 1, 0.08 * a); c.fill()
        if u > 0: rr(c, 380, y + 20, 520 * v / 100 * u, 64, 32); c.set_source_rgba(*GREEN[:3], a); c.fill()
        text(c, f"{int(round(v * u))}%", 56, 1010, y + 72, 900, YEL, a * clamp(u * 3), "r")
    text(c, "Muslims polled in 11 countries", 46, 540, 1450, 700, SILVER, a)
    text(c, "Pew Research Center, 2013", 40, 540, 1510, 700, SILVER, a)

# ------------------------------------------------------------------ scene 12: final scorecard
ROWS = [("Suicide bombings", "0", "147"), ("The attacker", "shrine removed", "centre named"), ("The state", "banned, jailed", "pays families")]
def draw_score(c, t):
    a = sa(t, 12)
    if a <= 0.01: return
    for k, (lab, l, r) in enumerate(ROWS):
        u = clamp((t - CUT[12] - 0.25 * k) / 0.35)
        y = 440 + k * 250
        text(c, lab, 50, 540, y + 40, 700, SILVER, a * u)
        card(c, 60, y + 64, 460, 150, SKY, a * u, 0.15, None, 28)
        card(c, 560, y + 64, 460, 150, RED, a * u, 0.15, None, 28)
        big = k == 0
        text(c, l, 110 if big else fit(l, 60, 420, 900), 290, y + 64 + (118 if big else 98), 900, YEL if big else WHITE, a * u)
        text(c, r, 110 if big else fit(r, 60, 420, 900), 790, y + 64 + (118 if big else 98), 900, YEL if big else WHITE, a * u)
    s1 = wt(12, "scale"); s2 = wt(12, "celebration")
    text(c, "Scale.", 124, 540, 1310, 900, YEL, a * ramp(t, s1 - 0.1, s1 + 0.2), sc=max(0.01, eob(clamp((t - s1 + 0.1) / 0.4))))
    text(c, "And celebration.", 110, 540, 1450, 900, YEL, a * ramp(t, s2 - 0.1, s2 + 0.2), sc=max(0.01, eob(clamp((t - s2 + 0.1) / 0.4))))

# ------------------------------------------------------------------ scene 13: OCHA
OCHA = [("2023", 1291), ("2024", 1449), ("2025", 1835)]
def draw_ocha(c, t):
    a = sa(t, 13)
    if a <= 0.01: return
    text(c, "Not perfect", 116, 540, 520, 900, WHITE, a)
    text(c, "Settler attacks, West Bank", fit("Settler attacks, West Bank", 70, 960, 800), 540, 630, 800, GOLD, a)
    t0 = wt(13, "settler") - 0.2
    base, top = 1290, 760
    for k, (yr, v) in enumerate(OCHA):
        u = eout((t - t0 - 0.35 * k) / 0.9)
        x = 230 + k * 310; h = (base - top) * v / 1835 * u
        rr(c, x - 105, base - h, 210, max(1, h), 22); c.set_source_rgba(*(YEL if k == 2 else SKY)[:3], a * (0.5 + 0.5 * clamp(u * 4))); c.fill()
        text(c, f"{int(round(v * u)):,}", 64, x, base - h - 24, 900, YEL if k == 2 else WHITE, a * clamp(u * 3))
        text(c, yr, 60, x, base + 72, 800, WHITE, a)
    text(c, "Rising every year", 64, 540, 1450, 800, WHITE, a * ramp(t, wt(13, "2025"), wt(13, "2025") + 0.3))
    text(c, "UN OCHA data, reported Jul 2026", 40, 540, 1520, 700, SILVER, a)

# ------------------------------------------------------------------ scene 14: lead-in
def draw_lead(c, t):
    a = ramp(t, CUT[14], CUT[14] + 0.3) * (1 - ramp(t, END - 1.25, END - 1.0))
    if a <= 0.01: return
    text(c, "So next time", 116, 540, 760, 900, WHITE, a)
    text(c, "someone says", 116, 540, 900, 900, WHITE, a)
    s = wt(14, "both"); b = ramp(t, s - 0.1, s + 0.25)
    text(c, "both sides", 116, 540, 1080, 900, YEL, a * b)
    text(c, "are the same...", 116, 540, 1220, 900, YEL, a * b)

# ------------------------------------------------------------------ subtitles
REPL = [("Hamas", "HAMAS"), ("a hundred and forty-seven", "147"), ("Twenty-nine", "29"), ("thirty-eight", "38"),
        ("eighty-nine percent", "89%"), ("eighteen hundred", "1,800"), ("five hundred", "500")]
SUB_BOTTOM = 1712
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                cand = " ".join(w["w"] for w in ws[i:i + n])
                core = cand.rstrip(".,:?!")
                if core.lower() == a_.lower(): hit = (n, b_ + cand[len(core):]); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs(); SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1E3F78")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1000, 760, SKY, 0.10); return s
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = scene_at(t)
    if i == 0: draw_hook(c, t, 1 - ramp(t, CUT[1] - 0.25, CUT[1]))
    draw_header(c, t)
    draw_real(c, t); draw_map(c, t); draw_answer(c, t); draw_bombings(c, t); draw_honour(c, t)
    draw_pay(c, t); draw_pew(c, t); draw_score(c, t); draw_ocha(c, t); draw_lead(c, t)
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); img = frame(tt)
            if tt >= T_FADE:
                u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
            Image.fromarray(img).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= T_FADE:
            u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
