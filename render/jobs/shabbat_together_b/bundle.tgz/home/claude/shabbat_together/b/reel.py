"""shabbat_together_b: "A 2,000-year-old dinner party" (@noamroz__, English, 1 Nov 2026). Engine: /home/claude/shabbat_together/tools/eng.py.
Beats: hook over a set Shabbat table, same candles / bread / blessing (antique candlesticks, challah, antique Kiddush cups), the Houses
of Shammai and Hillel arguing about the Kiddush order 2,000 years ago (Mishnah Berakhot 8:1), "we've been arguing at this table ever
since", who's at the table tonight (illustrated, no faces: grandma, a soldier, a newcomer, a friend who isn't Jewish), empires came and
went over a 1657 woodcut of a woman lighting the Sabbath lamp, "the dinner is still on", Ahad Ha'am 1898, the empty gold chair
("always room for one more. Even you."), Shabbat Shalom (native clip), lead-in "So pull up a chair. Because..." at the hook place with a
0.45 s cross-fade into frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py --out work/silent.mp4"""
import sys, os, json, math, argparse
sys.path.insert(0, "/home/claude/shabbat_together/tools")
from eng import *
D = "/home/claude/shabbat_together/b"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
LW = load_words(D); S, E, WX = make_timing(LW)
T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def b0(li): return S(li) - 0.2

CR = {"tbl": "Shabbat table. Photo: Crzrussian, CC BY-SA 3.0",
      "cst": "1862. Photo: Oleg Yunakov, CC BY-SA 4.0",
      "ch0": "Challah. Photo: Rakoon, CC0",
      "gal": "Kiddush cups. Photo: Silar, CC BY-SA 4.0",
      "wood": "Woodcut, Johann Leusden, 1657. Public domain"}
HOOK_A, HOOK_B = "A 2,000-year-old", "dinner party."
HY1, HY2 = 520, 700; HS1 = fit(HOOK_A, "db", 140); HS2 = 160
HOOK_END = S(1) - 0.15; END_T = S(14) - 0.15
LEAD_A, LEAD_B = "So pull up a chair.", "Because..."

def bubble(canvas, t, s, cx, cy, t0, t1, col, tail_dx):
    a = vis(t, t0, t1, 0.35, 0.3)
    if a <= 0.004: return
    f = font("db", 64); w = f.getlength(s) + 70; h = 120; u = seg(t, t0, t0 + 0.35); sc = 0.85 + 0.15 * u
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); c = tuple(int(v) for v in hx(col))
    x0, y0, x1, y1 = cx - w / 2 * sc, cy - h / 2 * sc, cx + w / 2 * sc, cy + h / 2 * sc
    d.rounded_rectangle((x0, y0, x1, y1), 40, fill=c + (int(255 * a),))
    d.polygon([(cx + tail_dx - 22, y1 - 2), (cx + tail_dx + 22, y1 - 2), (cx + tail_dx * 1.6, y1 + 46)], fill=c + (int(255 * a),))
    canvas.alpha_composite(lay)
    text(canvas, t, s, cy, int(64 * sc), t0, t1, fk="db", color="#0B0B10", ain=0.35, cx=cx)

SEATS = [(150, "#B98FD8", "grandma"), (340, "#6E7A3A", "soldier"), (740, "#45A4DD", "newcomer"), (930, "#F08A4B", "friend")]
CHAIR_X = 540
def glow_at(t):
    return 0.08 + 0.10 * seg(t, b0(4), b0(4) + 1.0) * (1 - seg(t, b0(9), b0(9) + 0.6)) + 0.12 * seg(t, b0(12), b0(12) + 1.0) * (1 - seg(t, END_T, END_T + 0.6))

def frame_raw(t):
    im = stage(glow_at(t))
    # ---- hook (frame 0) and lead-in (same place)
    bleed(im, t, "tbl.jpg", 0.5, 0.62, -1, HOOK_END, ain=0.01, aout=0.45, dark=0.80, span=(0, HOOK_END + 0.5), dim=0.6)
    if t < HOOK_END + 0.5: credit(im, t, CR["tbl"], 0, HOOK_END, y=1500, inst=True)
    z = 1 + 0.03 * seg(t, 0, HOOK_END)
    text(im, t, HOOK_A, HY1, HS1, 0, HOOK_END, inst=True, zoom=z)
    text(im, t, HOOK_B, HY2, HS2, 0, HOOK_END, inst=True, zoom=z, color=GOLD)
    bleed(im, t, "tbl.jpg", 0.5, 0.62, END_T, T_END + 1, ain=0.6, dark=0.80, span=(0, HOOK_END + 0.5), dim=0.6)
    if t > END_T: credit(im, t, CR["tbl"], END_T + 0.3, T_END + 1, y=1500)
    text(im, t, LEAD_A, HY1, fit(LEAD_A, "db", 120), END_T + 0.1, T_END + 1, ain=0.55)
    text(im, t, LEAD_B, HY2, 150, S(14, WX(14, "Because")) - 0.15, T_END + 1, ain=0.55, color=GOLD)
    # ---- line 1: same candles, same bread, same blessing
    t0, t1 = b0(1), b0(2); BOX = (60, 250, 1020, 1080)
    beats = [("cst.jpg", 0.5, 0.42, "cst", "Same candles.", S(1, WX(1, "candles")) - 0.55),
             ("ch0.jpg", 0.5, 0.5, "ch0", "Same bread.", S(1, WX(1, "bread")) - 0.5),
             ("gal.jpg", 0.45, 0.4, "gal", "Same blessing.", S(1, WX(1, "blessing")) - 0.55)]
    for i, (f, fx, fy, k, lab, ta) in enumerate(beats):
        tb = beats[i + 1][5] if i < 2 else t1
        ta = t0 if i == 0 else ta
        photo(im, t, f, fx, fy, ta, tb + 0.15, BOX, ain=0.35, aout=0.3); credit(im, t, CR[k], ta + 0.1, tb, y=1112)
        text(im, t, lab, 1235, 120, ta + 0.05, tb, color=GOLD if i == 2 else WHITE)
    text(im, t, "Every Friday night.", 1390, 72, t0 + 0.05, t1, fk="dm", color=GREY)
    # ---- lines 2 and 3: the Houses of Shammai and Hillel
    t0, t1 = b0(2), b0(4)
    a = vis(t, t0, t1, 0.45, 0.35)
    if a > 0.004:
        seats = [(300, "#2E3A59", "rabbi", t0), (780, "#3B2E59", "rabbi2", t0 + 0.15)]
        im.alpha_composite(table_layer(t, seats, y_table=1240, cands=True, alpha=a))
    ta = S(2, WX(2, "arguing")) - 0.25
    text(im, t, "2,000 years ago", 330, 120, t0 + 0.05, b0(3), color=GOLD)
    text(im, t, "two great rabbis argued", 455, fit("two great rabbis argued", "dsb", 78), S(2, 4) - 0.2, b0(3), fk="dsb")
    bubble(im, t, "The day first!", 300, 760, ta, t1, "#E8C77E", 40)
    bubble(im, t, "No! Wine first!", 780, 640, ta + 0.6, t1, "#7CC4EE", -40)
    text(im, t, "House of Shammai", 1450, 56, ta, t1, fk="dsb", cx=300, color=GREY)
    text(im, t, "House of Hillel", 1450, 56, ta + 0.6, t1, fk="dsb", cx=780, color=GREY)
    text(im, t, "So yes.", 330, 92, b0(3), t1, fk="dm")
    text(im, t, "Still arguing. Ever since.", 455, fit("Still arguing. Ever since.", "db", 96), S(3, WX(3, "We've")) - 0.2, t1, color=GOLD)
    # ---- lines 4 to 8, then 12 and 13: who's at the table
    t0, t1 = b0(4), b0(9)
    a = vis(t, t0, t1, 0.5, 0.35) + vis(t, b0(12), END_T, 0.5, 0.35)
    if a > 0.004:
        ats = [S(5) - 0.15, S(6) - 0.15, S(7) - 0.15, S(8) - 0.15]
        if t > b0(10): ats = [b0(12) - 1] * 4
        ci = seg(t, S(12, WX(12, "room")) - 0.3, S(12, WX(12, "room")) + 0.5) * (1 - seg(t, END_T, END_T + 0.3))
        seats = [(x, c, k, at) for (x, c, k), at in zip(SEATS, ats)]
        im.alpha_composite(table_layer(t, seats, y_table=1200, alpha=min(1, a), chair=(CHAIR_X, ci) if ci > 0 else None))
    text(im, t, "Who's at the table", 330, fit("Who's at the table", "db", 110), t0 + 0.05, b0(5))
    text(im, t, "tonight?", 460, 110, t0 + 0.2, b0(5), color=GOLD)
    who = [(5, "Grandma", "60 years of candles"), (6, "A soldier", "home for the weekend"),
           (7, "A newcomer", "landed last week"), (8, "A friend", "not Jewish. Here for the food.")]
    for li, nm, sub in who:
        ta, tb = b0(li), (b0(li + 1) if li < 8 else t1)
        text(im, t, nm, 360, 120, ta + 0.1, tb, color=GOLD)
        text(im, t, sub, 490, fit(sub, "dsb", 76), ta + 0.3, tb, fk="dsb")
    s = "Stayed for the singing."; text(im, t, s, 1440, fit(s, "dm", 70), S(8, WX(8, "Stayed")) - 0.2, t1, fk="dm", color=SKY)
    # ---- line 9: empires came and went (1657 woodcut)
    t0, t1 = b0(9), b0(10)
    photo(im, t, "wood.png", 0.5, 0.55, t0, t1 + 0.1, (190, 250, 890, 1010), r=28); credit(im, t, CR["wood"], t0 + 0.1, t1, y=1045)
    text(im, t, "Empires came and went.", 1140, fit("Empires came and went.", "db", 92), t0 + 0.05, t1)
    for k, (nm, w_) in enumerate((("Rome", "Rome"), ("The Ottomans", "Ottomans"), ("The British", "British"))):
        ta = S(9, WX(9, w_)) - 0.2; y = 1260 + 100 * k
        fade = 1 - 0.55 * seg(t, ta + 0.6, ta + 1.0)
        text(im, t, nm, y, 80, ta, t1, fk="dsb", alpha=fade)
        u = seg(t, ta + 0.4, ta + 0.8)
        if u > 0 and t < t1 + 0.3:
            wd = font("dsb", 80).getlength(nm) * u; lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            ImageDraw.Draw(lay).rectangle((540 - font("dsb", 80).getlength(nm) / 2, y - 3, 540 - font("dsb", 80).getlength(nm) / 2 + wd, y + 4),
                                          fill=tuple(int(c) for c in hx(GOLD)) + (int(230 * vis(t, ta, t1)),))
            im.alpha_composite(lay)
    # ---- line 10: the dinner is still on
    t0, t1 = b0(10), b0(11)
    bleed(im, t, "cst.jpg", 0.5, 0.40, t0, t1, ain=0.45, aout=0.35, dark=0.55, dim=0.45)
    credit(im, t, CR["cst"], t0 + 0.2, t1, y=1500)
    text(im, t, "The dinner", 800, 150, t0 + 0.05, t1)
    text(im, t, "is still on.", 980, 160, S(10, WX(10, "still")) - 0.2, t1, color=GOLD)
    # ---- line 11: Ahad Ha'am
    t0, t1 = b0(11), b0(12); q2 = S(11, 14) - 0.2      # word 14 = second "the Sabbath"
    text(im, t, "“More than the Jews", 640, 92, S(11, WX(11, "More")) - 0.2, t1, fk="dsb", alpha=1 - 0.4 * seg(t, q2, q2 + 0.4))
    text(im, t, "have kept the Sabbath,", 760, 92, S(11, WX(11, "More")) + 0.1, t1, fk="dsb", alpha=1 - 0.4 * seg(t, q2, q2 + 0.4))
    text(im, t, "the Sabbath has kept", 950, 104, q2, t1, color=GOLD)
    text(im, t, "the Jews.”", 1080, 104, q2 + 0.25, t1, color=GOLD)
    text(im, t, "Ahad Ha'am, 1898", 1250, 64, t0 + 0.1, t1, fk="dm", color=GREY)
    # ---- lines 12 and 13: always room for one more, Shabbat Shalom
    t0, t1 = b0(12), END_T
    text(im, t, "Always room", 330, 110, t0 + 0.05, b0(13))
    text(im, t, "for one more.", 460, 110, t0 + 0.2, b0(13))
    text(im, t, "Even you.", 1440, 110, S(12, WX(12, "Even")) - 0.2, b0(13), color=GOLD)
    text(im, t, "Shabbat Shalom.", 400, 140, b0(13), t1, color=GOLD)
    sources(im, t, SOURCES); subtitles(im, t, SUBS)
    return im

CH = [(1, 0, "Every Friday night."), (1, "Same", "Same candles. Same bread."), (1, 7, "Same blessing over the wine."),
      (2, 0, "Two thousand years ago,"), (2, 4, "two great rabbis were already"), (2, "arguing", "arguing about that blessing."),
      (3, 0, "So yes."), (3, "We've", "We've been arguing at this table"), (3, "ever", "ever since."),
      (4, 0, "Now, look who's at the table tonight."), (5, 0, "Grandma,"), (5, "who's", "who's lit these candles for 60 years."),
      (6, 0, "A soldier, home for the weekend,"), (6, "still", "still in uniform."),
      (7, 0, "A newcomer who landed last week,"), (7, "and", "and doesn't know a single song."),
      (8, 0, "And a friend who isn't Jewish."), (8, "Came", "Came for the food."), (8, "Stayed", "Stayed for the singing."),
      (9, 0, "Empires came and went."), (9, "Rome", "Rome. The Ottomans. The British."), (10, 0, "The dinner is still on."),
      (11, 0, "A Jewish writer put it best:"), (11, "More", "more than the Jews"), (11, "have", "have kept the Sabbath,"),
      (11, 14, "the Sabbath has kept the Jews."), (12, 0, "And there's always room for one more."), (12, "Even", "Even you."),
      (13, 0, "Shabbat Shalom, everyone.")]
SUBS = build_subs(CH, LW, S, E, WX)
SOURCES = [(0, []),
           (b0(2), ["Shammai vs Hillel on the Kiddush order:", "Mishnah, Berakhot 8:1"]),
           (b0(4), ["Illustration"]),
           (b0(9), []),
           (b0(11), ["Ahad Ha'am (Asher Ginsberg),", "Shabbat and Zionism, Hashiloah, 1898"]),
           (b0(12), [])]

F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + list(CR.values()) + [HOOK_A, HOOK_B, LEAD_A, LEAD_B] + L
guards(_txt, len((HOOK_A + " " + HOOK_B).split()))
for c in CR.values(): assert CREDF.getlength(c) <= 990, ("credit too wide", c)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
assert LW[11][14]["w"].lower() == "the" and LW[11][15]["w"].lower() == "sabbath", [w["w"] for w in LW[11]]
if __name__ == "__main__": run(frame, T_END, A.out, A.snaps, D)
