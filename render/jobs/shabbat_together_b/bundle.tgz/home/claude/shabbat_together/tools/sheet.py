"""sheet.py <snaps dir> <out>: phone-size contact sheet (each frame 390 px wide)."""
import sys, glob, os
from PIL import Image, ImageDraw
fs = sorted(glob.glob(sys.argv[1] + "/s_*.png")); w = 390; h = int(1920 * w / 1080); cols = 5; rows = (len(fs) + cols - 1) // cols
S = Image.new("RGB", (cols * w, rows * (h + 24)), "white")
for i, f in enumerate(fs):
    im = Image.open(f).convert("RGB").resize((w, h), Image.LANCZOS); x, y = (i % cols) * w, (i // cols) * (h + 24)
    S.paste(im, (x, y)); ImageDraw.Draw(S).text((x + 6, y + h + 5), os.path.basename(f), fill="black")
S.save(sys.argv[2], quality=85)
