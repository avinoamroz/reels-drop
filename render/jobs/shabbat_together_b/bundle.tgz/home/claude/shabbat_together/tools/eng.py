"""eng.py: shared look for shabbat_together a/b. Helpers copied from together_works/reel.py (Apple keynote stage: near-black, one warm
glow, Inter Display, cubic fades with blur-in, rolling numbers, Ken Burns photo panels, flat subtitles), plus full-bleed photos and the
illustrated Shabbat table (round-head figures, no faces) drawn in cairo."""
import sys, os, math, json, subprocess, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
FD = "/home/claude/series_more/safe_p2_v3/fonts"; PHD = "/home/claude/shabbat_together/photos"
W, H, FPS = 1080, 1920, 30
BG = "#060608"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
CANDLE = "#FFB84D"
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx("#F0C27A")[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
GRAD_TOP = np.clip(1 - yy / 1100, 0, 1)[:, :, None] ** 1.4      # darkening for text over full-bleed photos
GRAD_BOT = np.clip((yy - 1150) / 770, 0, 1)[:, :, None] ** 1.2
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 600: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0, cx=540):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, cx, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)
def vis(t, t0, t1, ain=0.45, aout=0.35): return seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout))

# ------------------------------------------------------------------ photos
_ph = {}
def photo_img(f):
    if f not in _ph: _ph[f] = Image.open(f"{PHD}/{f}").convert("RGB")
    return _ph[f]
_mask = {}
def rmask(w, h, r):
    if (w, h, r) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h, r)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h, r)]
def crop_kb(f, fx, fy, w, h, u, z0=1.0, z1=1.08):
    im = photo_img(f); z = z0 + (z1 - z0) * u; ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    return im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BILINEAR)
def photo(canvas, t, f, fx, fy, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35, r=34, z=(1.0, 1.08)):
    a = vis(t, t0, t1, ain, aout) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = [int(round(v)) for v in box]; w, h = x1 - x0, y1 - y0
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0)))
    lay = crop_kb(f, fx, fy, w, h, u, *z).convert("RGBA"); lay.putalpha(rmask(w, h, r).point(lambda v: int(v * a)))
    canvas.alpha_composite(lay, (x0, y0))
def bleed(canvas, t, f, fx, fy, t0, t1, alpha=1.0, ain=0.5, aout=0.5, dark=0.62, z=(1.0, 1.08), span=None, dim=1.0):
    """full-bleed photo with dark gradients top and bottom (text and subtitles stay readable)"""
    a = vis(t, t0, t1, ain, aout) * alpha
    if a <= 0.004: return
    s0, s1 = span or (t0, t1); u = min(1, max(0, (t - s0) / max(1.0, s1 - s0)))
    im = np.asarray(crop_kb(f, fx, fy, W, H, u, *z), np.float32)
    im = im * dim * (1 - dark * GRAD_TOP) * (1 - 0.75 * GRAD_BOT)
    lay = Image.fromarray(np.clip(im, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    if a < 0.999: lay.putalpha(int(255 * a))
    canvas.alpha_composite(lay)

def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)

# ------------------------------------------------------------------ flat layers
SUBF = font("sb", 54); SRCF = font("r", 40); CREDF = font("r", 36)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha, box=False):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    if box:
        mw = max(f.getlength(l) for l in lines); hh = lh * len(lines)
        d.rounded_rectangle((540 - mw / 2 - 28, cy - hh / 2 - 12, 540 + mw / 2 + 28, cy + hh / 2 + 12), 24, fill=(10, 10, 14, int(170 * alpha)))
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)

# ------------------------------------------------------------------ illustrated table (cairo, 1080 wide layer)
def _rgb(h): v = hx(h) / 255; return v[0], v[1], v[2]
def figure(cr, x, base, col, kind, s=1.0, a=1.0):
    """round-head figure seen from the front, sitting behind the table edge at y=base. No faces."""
    cr.save(); cr.translate(x, base); cr.scale(s, s)
    r, g, b = _rgb(col)
    # body
    cr.new_path(); cr.move_to(-62, 0); cr.curve_to(-62, -120, -40, -150, 0, -150); cr.curve_to(40, -150, 62, -120, 62, 0); cr.close_path()
    cr.set_source_rgba(r, g, b, a); cr.fill()
    # head
    skin = (0.96, 0.82, 0.66)
    cr.arc(0, -205, 46, 0, 2 * math.pi); cr.set_source_rgba(*skin, a); cr.fill()
    if kind == "grandma":
        cr.arc(0, -262, 22, 0, 2 * math.pi); cr.set_source_rgba(0.82, 0.82, 0.86, a); cr.fill()                  # bun
        cr.arc(0, -212, 47, math.pi * 1.02, math.pi * 1.98); cr.set_source_rgba(0.82, 0.82, 0.86, a); cr.set_line_width(14); cr.stroke()
        for dx in (-17, 17):
            cr.arc(dx, -205, 12, 0, 2 * math.pi); cr.set_source_rgba(0.25, 0.25, 0.3, a); cr.set_line_width(4); cr.stroke()
        cr.move_to(-5, -205); cr.line_to(5, -205); cr.stroke()
    elif kind == "soldier":
        cr.new_path(); cr.move_to(-50, -228); cr.curve_to(-48, -262, 40, -270, 54, -236); cr.line_to(-50, -224); cr.close_path()
        cr.set_source_rgba(0.42, 0.47, 0.22, a); cr.fill()                                                      # beret
        cr.rectangle(-28, -140, 56, 12); cr.set_source_rgba(0.30, 0.34, 0.16, a); cr.fill()                     # collar
    elif kind == "newcomer":
        cr.arc(0, -214, 47, math.pi * 1.05, math.pi * 1.95); cr.set_source_rgba(0.35, 0.22, 0.12, a); cr.set_line_width(16); cr.stroke()
        cr.rectangle(30, -110, 26, 34); cr.set_source_rgba(1, 1, 1, a); cr.fill()                               # luggage tag
        cr.move_to(43, -110); cr.line_to(43, -126); cr.set_source_rgba(1, 1, 1, a); cr.set_line_width(3); cr.stroke()
    elif kind == "friend":
        cr.arc(0, -214, 48, math.pi * 1.0, math.pi * 2.0); cr.set_source_rgba(0.12, 0.10, 0.10, a); cr.set_line_width(18); cr.stroke()
    elif kind == "host":
        cr.arc(0, -213, 47, math.pi * 1.05, math.pi * 1.95); cr.set_source_rgba(0.15, 0.12, 0.10, a); cr.set_line_width(12); cr.stroke()
    elif kind in ("rabbi", "rabbi2"):
        bc = (0.95, 0.95, 0.95) if kind == "rabbi" else (0.55, 0.55, 0.58)
        cr.save(); cr.translate(0, -172); cr.scale(1, 1.35); cr.arc(0, 0, 40, 0, math.pi); cr.restore()
        cr.set_source_rgba(*bc, a); cr.fill()                                                                      # beard
        cr.save(); cr.translate(0, -246); cr.scale(1, 0.45); cr.arc(0, 0, 30, math.pi, 2 * math.pi); cr.restore()
        cr.set_source_rgba(0.08, 0.08, 0.1, a); cr.fill()                                                         # kippah
    elif kind == "plain":
        pass
    cr.restore()
def candle(cr, x, y, t, a=1.0, lit=1.0, s=1.0):
    cr.save(); cr.translate(x, y); cr.scale(s, s)
    cr.rectangle(-9, -70, 18, 70); cr.set_source_rgba(0.98, 0.97, 0.93, a); cr.fill()
    if lit > 0.01:
        fl = 1 + 0.06 * math.sin(t * 13 + x) + 0.04 * math.sin(t * 7.3 + x * 0.3)
        gr = cairo.RadialGradient(0, -92, 2, 0, -92, 70 * fl)
        gr.add_color_stop_rgba(0, 1, 0.80, 0.40, 0.55 * a * lit); gr.add_color_stop_rgba(1, 1, 0.7, 0.3, 0)
        cr.arc(0, -92, 70 * fl, 0, 2 * math.pi); cr.set_source(gr); cr.fill()
        cr.save(); cr.translate(0, -88); cr.scale(1, 1.7 * fl)
        cr.arc(0, -6, 9, 0, 2 * math.pi); cr.set_source_rgba(1, 0.78, 0.35, a * lit); cr.fill(); cr.restore()
    cr.restore()
def table_layer(t, seats, y_table=1180, cloth="#F2EEE6", cands=True, extra=None, alpha=1.0, chair=None):
    """seats: list of (x, color, kind, appear_t). Figures pop up (scale 0.85 -> 1) when they appear."""
    sf_ = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cr = cairo.Context(sf_)
    if chair is not None:                                   # empty chair, glowing gold: (x, intensity)
        cx_, ci = chair
        gr = cairo.RadialGradient(cx_, y_table - 160, 10, cx_, y_table - 160, 230); gr.add_color_stop_rgba(0, 0.91, 0.78, 0.49, 0.45 * ci)
        gr.add_color_stop_rgba(1, 0.91, 0.78, 0.49, 0); cr.arc(cx_, y_table - 160, 230, 0, 2 * math.pi); cr.set_source(gr); cr.fill()
        cr.set_source_rgba(0.91, 0.78, 0.49, ci); cr.set_line_width(12); cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.move_to(cx_ - 58, y_table); cr.line_to(cx_ - 58, y_table - 250); cr.line_to(cx_ + 58, y_table - 250); cr.line_to(cx_ + 58, y_table); cr.stroke()
        cr.move_to(cx_ - 58, y_table - 175); cr.line_to(cx_ + 58, y_table - 175); cr.stroke()
    for x, col, kind, at in seats:
        u = seg(t, at, at + 0.45)
        if u <= 0: continue
        figure(cr, x, y_table + 6, col, kind, s=0.85 + 0.15 * u, a=u)
    # table: cloth with a soft drape
    cr.rectangle(40, y_table, 1000, 26); cr.set_source_rgba(*_rgb(cloth), 1); cr.fill()
    cr.new_path(); cr.move_to(40, y_table + 26); cr.line_to(1040, y_table + 26); cr.line_to(1010, y_table + 150); cr.line_to(70, y_table + 150); cr.close_path()
    gr = cairo.LinearGradient(0, y_table + 26, 0, y_table + 150); gr.add_color_stop_rgba(0, 0.93, 0.91, 0.86, 1); gr.add_color_stop_rgba(1, 0.70, 0.68, 0.64, 1)
    cr.set_source(gr); cr.fill()
    if cands:
        candle(cr, 470, y_table + 2, t); candle(cr, 610, y_table + 2, t)
        # challah under a cloth (rounded mound) and a cup
        cr.save(); cr.translate(300, y_table + 2); cr.scale(1, 0.45); cr.arc(0, 0, 80, math.pi, 2 * math.pi); cr.restore()
        cr.set_source_rgba(0.27, 0.44, 0.72, 1); cr.fill()
        cr.move_to(770, y_table + 2); cr.line_to(762, y_table - 30); cr.line_to(798, y_table - 30); cr.line_to(790, y_table + 2); cr.close_path()
        cr.set_source_rgba(0.83, 0.71, 0.42, 1); cr.fill()
        cr.rectangle(764, y_table - 70, 32, 42); cr.set_source_rgba(0.83, 0.71, 0.42, 1); cr.fill()
        cr.rectangle(768, y_table - 64, 24, 18); cr.set_source_rgba(0.50, 0.08, 0.16, 1); cr.fill()
    if extra: extra(cr)
    sf_.flush()
    a = np.ndarray((H, W, 4), np.uint8, sf_.get_data())
    rgba = a[:, :, [2, 1, 0, 3]].copy()
    im = Image.fromarray(rgba, "RGBA")
    if alpha < 0.999:
        al = np.asarray(im.getchannel("A"), np.float32) * alpha; im.putalpha(Image.fromarray(al.astype(np.uint8)))
    return im

# ------------------------------------------------------------------ timing helpers
def load_words(D):
    WJ = json.load(open(f"{D}/work/words.json")); LW = {}
    for w in WJ["words"]: LW.setdefault(w["li"], []).append(w)
    return LW
def make_timing(LW):
    def S(li, i=0): return LW[li][i]["t0"]
    def E(li, i=-1): return LW[li][i]["t1"]
    def WX(li, word):
        k = re.sub(r"\W", "", word).lower()
        for i, w in enumerate(LW[li]):
            if re.sub(r"\W", "", w["w"]).lower() == k: return i
        raise KeyError((li, word))
    return S, E, WX
def build_subs(CH, LW, S, E, WX):
    CH = [(li, w if isinstance(w, int) else WX(li, w), s) for li, w, s in CH]; out = []
    for i, (li, wi, s) in enumerate(CH):
        a = S(li, wi) - 0.04; nxt = CH[i + 1] if i + 1 < len(CH) else None
        endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
        b = E(li, endw) + 0.4
        if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.06)
        out.append((a, b, s)); assert len(s.split()) <= 7, s
    return out
SUB_Y = 1600; SRC_Y = 1748
def subtitles(canvas, t, SUBS):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12); flat(canvas, wrap(s, SUBF, 900), SUBF, SUB_Y, 68, "#FFFFFF", 0.96 * al, box=True)
def sources(canvas, t, SOURCES):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if lines and t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, SRC_Y, 50, "#B4B4BA", a)
def credit(canvas, t, s, t0, t1, y=1850, inst=False):
    a = 1.0 if (inst and t < t0 + 0.4) else vis(t, t0, t1, 0.4, 0.3)
    flat(canvas, s if isinstance(s, list) else [s], CREDF, y, 44, "#B4B4BA", a)

_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
def guards(txt, hook_words):
    assert not any(d in s for s in txt for d in _D), "dash"
    bad = [s for s in txt if re.search(r"in my (view|opinion)|to be fair|islam|follow", s, re.I)]
    assert not bad, bad
    assert hook_words <= 6

def run(frame, T_END, out, snaps=None, D=None):
    N = int(round(T_END * FPS))
    if snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); return
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", out, T_END)
