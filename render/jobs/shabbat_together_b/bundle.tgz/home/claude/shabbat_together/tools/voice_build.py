"""voice_build.py a|b: Cartesia SSE parts (<r>/p*.wav + _words.json) + native Hebrew clips -> <r>/work/vo.wav (48 kHz, house chain)
and <r>/work/words.json. Method from together_works/tools/voice_build.py: script words mapped onto Cartesia word times by character
position; long pauses squeezed to MAXG; native clips trimmed by their own energy (not timestamps) and level-matched to the line before."""
import json, re, sys, wave, os
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
R = sys.argv[1]; D = f"/home/claude/shabbat_together/{R}"; C = "/home/claude/shabbat_together/clips"; SR0 = 44100
CFG = {
 "a": dict(tempo=1.06, native={9: "he_kid", 14: "he_ss3"}, ref={9: 8, 14: 13},
           gap={0: 0.70, 1: 0.45, 2: 0.40, 3: 0.60, 4: 0.30, 5: 0.65, 6: 0.70, 7: 0.40, 8: 0.20, 9: 0.65, 10: 0.40, 11: 0.85, 12: 0.35, 13: 0.70, 14: 0.75}),
 "b": dict(tempo=1.07, native={13: "he_ss3"}, ref={13: 12},
           gap={0: 0.65, 1: 0.55, 2: 0.30, 3: 0.75, 4: 0.40, 5: 0.35, 6: 0.35, 7: 0.40, 8: 0.70, 9: 0.40, 10: 0.80, 11: 0.60, 12: 0.60, 13: 0.70}),
}[R]
TEMPO = CFG["tempo"]; V.TEMPO = TEMPO; LEAD = 0.12; V.LEAD = LEAD; MAXG = 0.30
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
parts = json.load(open(f"{D}/tts_parts.json"))
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
def env_db(x, h=441):
    n = len(x) // h; return 10 * np.log10((x[:n * h].reshape(n, h) ** 2).mean(1) + 1e-12)
def map_words(script_words, W):
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sn = [norm(x) for x in script_words]; stot = sum(max(1, len(x)) for x in sn); pos = 0; out = []
    for x, n_ in zip(script_words, sn):
        Ln = max(1, len(n_)); f0, f1 = pos / stot, (pos + Ln) / stot; pos += Ln
        out.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
    return out
LINES = {}
for k, P in enumerate(parts):
    a = load(f"{D}/p{k}.wav"); W = json.load(open(f"{D}/p{k}_words.json"))
    sw = []; owner = []
    for li in P["lines"]:
        for x in L[li].split(): sw.append(x); owner.append(li)
    mw = map_words(sw, W)
    for li in P["lines"]: LINES[li] = (a, [m for m, o in zip(mw, owner) if o == li])
def act(x): r = env_db(x, 882); r = r[r > r.max() - 25]; return np.sqrt(np.mean(10 ** (r / 10)))
NATIVE = {}
for li, nm in CFG["native"].items():
    ar, wr = LINES[CFG["ref"][li]]; ref = ar[int(wr[0][1] * SR0):int(wr[-1][2] * SR0)]
    x = load(f"{C}/{nm}.wav"); Lr = env_db(x); on = np.where(Lr > Lr.max() - 32)[0]
    x = x[max(0, on[0] - 2) * 441:(on[-1] + 4) * 441].copy()
    g = np.clip(act(ref) / act(x), 10 ** (-8 / 20), 10 ** (8 / 20)); x *= g
    f = int(0.012 * SR0); x[:f] *= np.linspace(0, 1, f); x[-f:] *= np.linspace(1, 0, f)
    NATIVE[li] = x; LINES[li] = (x, [(L[li], 0.0, len(x) / SR0)])
    print(nm, round(len(x) / SR0, 2), "s, gain", round(20 * np.log10(g), 1), "dB")
chunks = []; words = []; t = 0.0; GAP = CFG["gap"]
for li in range(len(L)):
    a, ws = LINES[li]
    if li in NATIVE: s0, e0 = 0.0, len(a) / SR0
    else: s0 = max(0, ws[0][1] - 0.06); e0 = min(len(a) / SR0, ws[-1][2] + (0.35 if li == len(L) - 1 else 0.10))
    keep = []; cur = s0
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][2], ws[i + 1][1]
        if g1 - g0 > MAXG:
            ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
    keep.append((cur, e0))
    def mp(x):
        acc = 0.0
        for k0, k1 in keep:
            if x <= k1: return t + acc + max(0, x - k0)
            acc += k1 - k0
        return t + acc
    for w_, a_, b_ in ws: words.append(dict(li=li, w=w_, p0=mp(a_), p1=mp(max(b_, a_ + 0.04))))
    for k0, k1 in keep:
        seg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(seg) // 2, int(0.008 * SR0))
        if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        chunks.append(seg); t += len(seg) / SR0
    if li in GAP: chunks.append(np.zeros(int(GAP[li] * SR0), np.float32)); t += GAP[li]
os.makedirs(f"{D}/work", exist_ok=True)
raw = np.concatenate(chunks); sf.write(f"{D}/work/raw.wav", raw, SR0)
dry = V.chain_dry(f"{D}/work/raw.wav"); cl = V.clean_vo(dry, V.SR); y, sp = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{D}/work/vo.wav", vo.astype(np.float32), V.SR)
for w in words: w["t0"] = round(LEAD + w.pop("p0") / TEMPO, 3); w["t1"] = round(LEAD + w.pop("p1") / TEMPO, 3)
json.dump(dict(words=words, dur=round(len(vo) / V.SR, 3)), open(f"{D}/work/words.json", "w"), indent=0, ensure_ascii=False)
os.remove(f"{D}/work/raw.wav")
print("vo", round(len(vo) / V.SR, 2), "s")
for li in range(len(L)):
    ws = [w for w in words if w["li"] == li]; print(li, ws[0]["t0"], ws[-1]["t1"], L[li])
