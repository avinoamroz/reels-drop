"""mix.py a|b (local step): warm Shabbat bed (shabbat_record/shabbat_audio.py: D freygish, oud-ish pluck, hand drum, reed), re-timed so
exactly BARS bars fill T_END, cut from bar 4 (groove full at frame 0, the last bar resolves into bar 4 on the loop), overflow folded onto the
start; strings swell under the turn; voice from <r>/work/vo.wav -> <r>/work/mix.m4a. Method: together_works/mix.py."""
import sys, os, json, types, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
R = sys.argv[1]; D = f"/home/claude/shabbat_together/{R}"
CFG = {"a": dict(bars=22, swell=(12, 15), hit=12), "b": dict(bars=22, swell=(9, 13), hit=10)}[R]
src = open("/home/claude/shabbat_record/shabbat_audio.py").read().replace("bpm = 104;", "bpm = BPM;")
SA = types.ModuleType("sa"); SA.__dict__["__file__"] = "/home/claude/shabbat_record/shabbat_audio.py"
WJ = json.load(open(f"{D}/work/words.json")); W = WJ["words"]
LS = lambda li: min(w["t0"] for w in W if w["li"] == li)
BARS = CFG["bars"]; T_END = round(WJ["dur"] + 0.45, 2); BPM = 4 * 60 * BARS / T_END; bar = 4 * 60 / BPM
SA.__dict__["BPM"] = BPM; exec(compile(src, "shabbat_audio_st", "exec"), SA.__dict__)
SR = SA.SR; assert SR == AU.SR
pre = 4 * bar; s0 = LS(CFG["swell"][0]) - 0.3 + pre; s1 = LS(CFG["swell"][1]) - 0.6 + pre
raw = SA.music(T_END + pre + bar, swell=(s0, s1), end_fade=0.01)
i0 = int(round(pre * SR)); n = int(round(T_END * SR)); xf = int(0.6 * SR)
bed = raw[:, i0:i0 + n].copy(); tail = raw[:, i0 + n:i0 + n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(LS(CFG["hit"]) - 0.05, AU.soft_hit(), -9.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, T_END, ev, mw, music_db=-18.0, sfx_db=-14.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=T_END, bpm=BPM, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", T_END, BPM, J.get("final_I"), J.get("final_TP"))
