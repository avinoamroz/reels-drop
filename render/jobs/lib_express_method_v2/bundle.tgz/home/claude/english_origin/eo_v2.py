"""english_origin v2 (27 Oct 2026): narrated in Noam's Cartesia voice (v2/v2c.wav + words), the v1 timeline time-warped so each beat
lands on its narration line, new royal-blue background (ocean, panels, end card), fluency CTA end card, music bed looped and ducked
under the voice, v1 SFX moved with the warp. usage: python3 eo_v2.py frames t1 t2 ... | video"""
import sys, os, json, subprocess, wave, numpy as np
D = "/home/claude/english_origin/"; sys.path.insert(0, D); os.chdir(D)
import render as R
from PIL import Image, ImageDraw
NEW1, NEW2, NEWO = (16, 64, 118), (34, 98, 168), (18, 70, 128)
# recolor the baked ocean of the map images and the module colours
for k, m in enumerate(R.MAPS):
    cp = D + f"v2/map{k}_blue.png"
    if not os.path.exists(cp):
        a = np.asarray(m["im"]); out = np.empty_like(a)
        for y0 in range(0, a.shape[0], 200):
            b = a[y0:y0 + 200].astype(np.float32); d = np.abs(b - np.array(R.OCEAN, np.float32)).sum(2)
            w = np.clip(1 - d / 40.0, 0, 1)[..., None]; out[y0:y0 + 200] = (b * (1 - w) + np.array(NEWO, np.float32) * w).clip(0, 255).astype(np.uint8)
        Image.fromarray(out).save(cp); del out, a
    m["im"] = Image.open(cp).convert("RGB")
R.OCEAN = NEWO; R.NAVY1, R.NAVY2 = NEW1, NEW2
# timeline warp: visual beat starts -> narration line starts
V = [0, 3.4, 7.6, 10.6, 14.4, 17.6, 22.0, 27.0, 29.2, 30.6, 33.6, 49.3, 54.6, 58.8]
L = [l.strip() for l in open(D + "v2/v2c_lines.txt")]; W = json.load(open(D + "v2/v2c_words.json")); i = 0; ST = []; EN = []
for l in L:
    n = len(l.split()); ST.append(W[i]["start"]); EN.append(W[i + n - 1]["end"]); i += n
assert len(L) == len(V) == 14
RT = [0.0] + [s - 0.2 for s in ST[1:]]; T_REAL = EN[-1] + 3.0
VB, RB = V + [63.0], RT + [T_REAL]
def warp(t): return float(np.interp(t, RB, VB))
def unwarp(v): return float(np.interp(v, VB, RB))
def endcard(t):
    g = np.linspace(0, 1, R.H)[:, None, None]
    img = Image.fromarray((np.array(NEW1) * (1 - g) + np.array(NEW2) * g).repeat(R.W, 1).astype(np.uint8), "RGB")
    lt = t - RB[13]; al, sc = R.pop(lt, 0.0, 0.35)
    lg = R.LOGO.resize((220, 220), Image.LANCZOS); R.put(img, lg, R.W / 2, 470, al, sc)
    R.txt(img, "Want fluency?", 900, 96, R.GOLD, R.W / 2, 700, al, sc)
    a2 = R.fade(lt, 0.4, 99, 0.3, 0.1)
    R.txt(img, "Talk to yourself in English", 800, 58, R.WHITE, R.W / 2, 840, a2)
    R.txt(img, "for 7 minutes, on WhatsApp.", 800, 58, R.WHITE, R.W / 2, 912, a2)
    a3 = R.fade(lt, 2.6, 99, 0.3, 0.1)
    R.txt(img, "Then explain the same idea", 800, 58, R.WHITE, R.W / 2, 1020, a3)
    R.txt(img, "to a friend.", 900, 58, R.GOLD, R.W / 2, 1092, a3)
    R.txt(img, "דברו עם עצמכם באנגלית 7 דקות בוואטסאפ,", 700, 44, R.SKY, R.W / 2, 1190, a3)
    R.txt(img, "ואז הסבירו את אותו הרעיון לחבר.", 700, 44, R.SKY, R.W / 2, 1250, a3)
    a4 = R.fade(lt, 4.0, 99, 0.3, 0.1); d = ImageDraw.Draw(img, "RGBA")
    d.rounded_rectangle([170, 1340, 910, 1440], radius=50, fill=R.SKY + (int(255 * a4),))
    R.txt(img, "Follow @noamroz__", 900, 48, R.WHITE, R.W / 2, 1390, a4, shadow=False)
    R.txt(img, "@expressenglishcom", 800, 40, R.WHITE, R.W / 2, 1490, a4)
    return img
def frame_real(t):
    v = warp(t)
    if v >= 58.8: return endcard(t)
    im = R.frame(max(v, 0.25) if v < 1.0 else v)
    if v < 3.4:   # hook push-in so it moves by 1.5 s
        z = 1 + 0.045 * min(1.0, t / 3.0); w, h = int(R.W / z), int(R.H / z)
        im = im.crop(((R.W - w) // 2, (R.H - h) // 2, (R.W - w) // 2 + w, (R.H - h) // 2 + h)).resize((R.W, R.H), Image.LANCZOS)
    return im
def build_audio(path):
    SR = 48000; n = int(SR * T_REAL)
    vo = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", D + "v2/v2c.wav", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout, np.float32).astype(np.float64)
    v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]
    mus = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-stream_loop", "3", "-i", D + "music_eo.wav", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout, np.float32).astype(np.float64)[:n]
    m = np.zeros(n); m[:len(mus)] = mus
    env = np.convolve(np.abs(v), np.ones(int(0.25 * SR)) / int(0.25 * SR), "same"); act = np.clip(env / (0.3 * env.max() + 1e-9), 0, 1)
    gain = 0.30 - 0.20 * act; fo = int(2.0 * SR); m[-fo:] *= np.linspace(1, 0, fo)
    # SFX from v1, moved with the warp (render the v1 sfx track at 44.1 kHz once, then move each event)
    R.SFX.sort(key=lambda x: x[1]); sfx = np.zeros(n)
    import importlib; R2 = R
    SR1 = 44100; tmp = D + "v2/_sfx.wav"; save = (R.SFX[:], R.T_END)
    for k, st in save[0]:
        R.SFX[:] = [(k, 0.3)]; R.T_END = 1.6; R.build_audio(tmp)
        w = wave.open(tmp); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).reshape(-1, 2)[:, 0] / 32767.0; w.close()
        w2 = wave.open(D + "music_eo.wav"); mu = np.frombuffer(w2.readframes(int(1.6 * SR1)), np.int16).reshape(-1, 2)[:, 0] / 32767.0; w2.close()
        ev = a[:len(mu)] - np.tanh(mu[:len(a)] * 0.30 * 1.1) * 0.92 if False else a
        ev = np.interp(np.arange(int(len(ev) * SR / SR1)) / SR, np.arange(len(ev)) / SR1, ev)
        i0 = int((unwarp(st) - 0.3) * SR)
        if 0 <= i0 < n: j = min(n, i0 + len(ev)); sfx[i0:j] += 0.6 * ev[:j - i0]
    R.SFX[:], R.T_END = save; os.remove(tmp)
    mix = v * 1.0 + m * gain + sfx * 0.5
    mix = mix / max(1.0, np.abs(mix).max() / 0.95)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f64le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-ac", "2", "-c:a", "pcm_s16le", path], input=mix.tobytes(), check=True)
if __name__ == "__main__":
    if sys.argv[1] == "frames":
        os.makedirs(D + "v2/check", exist_ok=True)
        for ts in sys.argv[2:]: frame_real(float(ts)).save(D + f"v2/check/f_{float(ts):05.1f}.png")
    else:
        mix = D + "v2/mix.wav"; build_audio(mix); out = D + "v2/raw.mp4"; NF = int(T_REAL * 30)
        p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", "1080x1920", "-r", "30", "-i", "-", "-i", mix,
                              "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-threads", "2", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
        for k in range(NF):
            p.stdin.write(frame_real(k / 30).tobytes())
            if k % 300 == 0: print(k, NF, flush=True)
        p.stdin.close(); p.wait()
        subprocess.run(["python3", "/home/claude/changes_batch/norm.py", out, D + "english_origin_v2.mp4"], check=True)
        os.remove(out); os.remove(mix); print("EODONE")
