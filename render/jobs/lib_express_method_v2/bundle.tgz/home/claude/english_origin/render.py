import json, math, subprocess, sys, wave, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
Image.MAX_IMAGE_PIXELS = None

DIR = "/home/claude/english_origin/"
W, H, FPS = 1080, 1920, 30
T_END = 63.0
NF = int(T_END * FPS)
CY = 800  # screen y of camera centre

FD = "/home/claude/quran/fonts/"
_FC = {}
def F(w, s):
    k = (w, s)
    if k not in _FC: _FC[k] = ImageFont.truetype(FD + f"Heebo-{w}.ttf", s, layout_engine=ImageFont.Layout.RAQM)
    return _FC[k]
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
NAVY1, NAVY2, SKY, GOLD = hx("#0E1E3A"), hx("#163260"), hx("#59A5DF"), hx("#D2AA53")
WHITE, MUTED = (255, 255, 255), (172, 192, 220)
LONDON = (51.51, -0.13)

def ease(x): x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)
def eout(x): x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3
def eback(x):
    x = max(0.0, min(1.0, x)); c = 1.7
    return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def merc(lat):
    lat = max(-85.0, min(85.0, lat))
    return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))
def is_he(s): return any("֐" <= c <= "׿" for c in s)

# ---------------- maps ----------------
MAPS = []
for nm in ("L0", "L1"):
    m = json.load(open(DIR + f"maps/{nm}.json")); m["im"] = Image.open(DIR + f"maps/{nm}.png").convert("RGB"); m["yt"] = merc(m["lat1"])
    MAPS.append(m)
OCEAN = (9, 21, 44)

def render_map(cam):
    lon, lat, z = cam; cy = merc(lat)
    out = Image.new("RGB", (W, H), OCEAN)
    levels = [MAPS[0]] + ([MAPS[1]] if z > 15 else [])
    for m in levels:
        s = m["s"]; im = m["im"]
        # screen rect -> map pixel box
        x0 = (lon - W / 2 / z - m["lon0"]) * s; x1 = (lon + W / 2 / z - m["lon0"]) * s
        y0 = (m["yt"] - (cy + CY / z)) * s; y1 = (m["yt"] - (cy - (H - CY) / z)) * s
        k = W / (x1 - x0)  # screen px per map px
        cx0, cy0, cx1, cy1 = max(0, x0), max(0, y0), min(im.width, x1), min(im.height, y1)
        if cx1 - cx0 < 2 or cy1 - cy0 < 2: continue
        dx0, dy0 = int(round((cx0 - x0) * k)), int(round((cy0 - y0) * k))
        dw, dh = int(round((cx1 - cx0) * k)), int(round((cy1 - cy0) * k))
        if dw < 2 or dh < 2: continue
        piece = im.resize((dw, dh), Image.BILINEAR, box=(cx0, cy0, cx1, cy1))
        out.paste(piece, (dx0, dy0))
    return out

def P(cam, lat, lon):
    clon, clat, z = cam
    return (W / 2 + (lon - clon) * z, CY + (merc(clat) - merc(lat)) * z)

# ---------------- camera ----------------
KEYS = [
    (0.0, 30, 35, 3.6), (1.0, 30, 35, 3.6), (3.3, 44, 46, 11.5), (7.6, 42, 48, 12.5),
    (10.0, 16, 53, 19), (10.6, 16, 53, 19), (12.8, 3, 53.6, 34), (14.4, 2, 53.2, 36),
    (15.4, 6, 47.5, 17), (17.4, 6, 47.5, 17.5), (18.4, 4, 56, 26), (21.8, 4, 56, 27),
    (22.8, 0, 50.6, 48), (26.8, 0, 50.7, 50), (27.8, -0.4, 51.4, 80), (30.4, -0.4, 51.4, 84),
    (31.4, 11, 46, 16), (33.4, 11, 46, 16.5), (35.0, 21, 27, 4.1), (49.0, 21, 27, 4.25),
    (50.0, 34, 12, 3.45), (54.4, 34, 12, 3.6), (55.4, 16, 45, 14.5), (58.8, 16, 45, 15.5),
    (63.0, 16, 45, 15.5)]
def camera(t):
    for (t0, a0, b0, z0), (t1, a1, b1, z1) in zip(KEYS, KEYS[1:]):
        if t0 <= t <= t1:
            u = ease((t - t0) / (t1 - t0)) if t1 > t0 else 1
            lat = math.degrees(2 * math.atan(math.exp(math.radians(merc(b0) + (merc(b1) - merc(b0)) * u))) - math.pi / 2)
            return (a0 + (a1 - a0) * u, lat, math.exp(math.log(z0) + (math.log(z1) - math.log(z0)) * u))
    return KEYS[-1][1:]

# ---------------- text cache ----------------
_TC = {}
def timg(s, f, col, shadow=True):
    k = (s, f.path, f.size, col, shadow)
    if k in _TC: return _TC[k]
    rtl = is_he(s)
    kw = dict(direction="rtl", language="he") if rtl else {}
    dd = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    w = int(dd.textlength(s, font=f, **kw)) + 40; h = int(f.size * 1.7)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((w / 2, h / 2), s, font=f, fill=col + (255,), anchor="mm", **kw)
    if shadow:
        sh = Image.new("RGBA", (w, h), (0, 0, 0, 0)); ImageDraw.Draw(sh).text((w / 2, h / 2 + 3), s, font=f, fill=(3, 8, 20, 200), anchor="mm", **kw)
        sh = sh.filter(ImageFilter.GaussianBlur(5)); sh.alpha_composite(im); im = sh
    _TC[k] = im; return im

def put(dst, im, cx, cy, alpha=1.0, scale=1.0):
    if alpha <= 0.01 or scale <= 0.02: return
    if abs(scale - 1) > 0.01:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BILINEAR)
    if alpha < 0.99:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im = im.copy(); im.putalpha(a)
    dst.paste(im, (int(cx - im.width / 2), int(cy - im.height / 2)), im)

def txt(dst, s, w, size, col, cx, cy, alpha=1.0, scale=1.0, shadow=True):
    im = timg(s, F(w, size), col, shadow); put(dst, im, cx, cy, alpha, scale); return im.width - 40

def pop(t, t0, dur=0.28):
    """scale/alpha for pop-in at t0"""
    if t < t0: return 0.0, 0.0
    u = (t - t0) / dur
    return min(1.0, u * 1.6), (0.55 + 0.45 * eback(u))

# ---------------- sprites ----------------
def glow_sprite(r, col, core=0.25):
    S = r * 2 + 1; yy, xx = np.mgrid[0:S, 0:S]; d = np.sqrt((xx - r) ** 2 + (yy - r) ** 2) / r
    a = np.clip(np.exp(-d * d * 4.0) * 0.85 + (d < core) * 1.0, 0, 1) * (d <= 1)
    arr = np.zeros((S, S, 4), np.uint8); arr[..., :3] = col; arr[..., 3] = (a * 255).astype(np.uint8)
    im = Image.fromarray(arr, "RGBA")
    c = Image.new("RGBA", (S, S), (0, 0, 0, 0)); ImageDraw.Draw(c).ellipse([r - r * core * 0.7, r - r * core * 0.7, r + r * core * 0.7, r + r * core * 0.7], fill=(255, 255, 255, 255))
    im.alpha_composite(c); return im
GLOW_G = glow_sprite(46, GOLD); GLOW_S = glow_sprite(34, SKY); GLOW_W = glow_sprite(26, (235, 240, 255))

def grad_panel(y0, y1, a0, a1):
    a = np.linspace(a0, a1, y1 - y0)[:, None].repeat(W, 1)
    arr = np.zeros((y1 - y0, W, 4), np.uint8); arr[..., :3] = (6, 14, 32); arr[..., 3] = (a * 255).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")
TOPP = grad_panel(0, 480, 0.92, 0.0)
BOTP = grad_panel(1020, H, 0.0, 0.94)

LOGO = Image.open("/home/claude/origins/logo.png").convert("RGBA")

# ---------------- drawing helpers ----------------
def bez(p0, p2, u, bulge=0.22):
    mx, my = (p0[0] + p2[0]) / 2, (p0[1] + p2[1]) / 2; dx, dy = p2[0] - p0[0], p2[1] - p0[1]
    p1 = (mx - dy * bulge, my + dx * bulge * 0.0 - abs(dx) * bulge - abs(dy) * 0.05)
    return ((1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * p1[0] + u * u * p2[0], (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * p1[1] + u * u * p2[1])

def arc_line(d, a, b, u0, u1, col, width=4, alpha=255, bulge=0.22, glow=True):
    if u1 <= u0: return None
    n = 40; pts = [bez(a, b, u0 + (u1 - u0) * i / n, bulge) for i in range(n + 1)]
    if glow: d.line(pts, fill=col + (int(alpha * 0.22),), width=width * 4, joint="curve")
    d.line(pts, fill=col + (alpha,), width=width, joint="curve")
    return pts[-1]

def chip(dst, d, en, he, cx, cy, alpha, scale, col=WHITE, sub=SKY, w_en=44):
    if alpha <= 0: return
    a = timg(en, F(800, w_en), col); b = timg(he, F(700, 30), sub)
    ww = max(a.width, b.width) - 10; hh = 116
    bw, bh = ww * scale, hh * scale
    d.rounded_rectangle([cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2], radius=int(22 * scale), fill=(14, 30, 58, int(225 * alpha)), outline=SKY + (int(120 * alpha),), width=2)
    put(dst, a, cx, cy - 20 * scale, alpha, scale); put(dst, b, cx, cy + 30 * scale, alpha, scale)
    return ww

def chip_w(en, he, w_en=44):
    return max(timg(en, F(800, w_en), WHITE).width, timg(he, F(700, 30), SKY).width) - 10

def chip_row(dst, d, items, t, t0, cy, gap=0.2, w_en=44, maxw=980):
    """items: list of (en, he). returns list of start times (for sfx)"""
    ws = [chip_w(e, h, w_en) for e, h in items]
    rows = [[]]; cur = 0
    for i, w in enumerate(ws):
        if rows[-1] and cur + w + 18 > maxw: rows.append([]); cur = 0
        rows[-1].append(i); cur += w + 18
    for r, idxs in enumerate(rows):
        tot = sum(ws[i] for i in idxs) + 18 * (len(idxs) - 1); x = W / 2 - tot / 2
        for i in idxs:
            al, sc = pop(t, t0 + i * gap)
            chip(dst, d, items[i][0], items[i][1], x + ws[i] / 2, cy + r * 132, al, sc, w_en=w_en)
            x += ws[i] + 18

def pin(dst, d, x, y, col, alpha=1.0, r=9):
    d.ellipse([x - r - 6, y - r - 6, x + r + 6, y + r + 6], fill=col + (int(60 * alpha),))
    d.ellipse([x - r, y - r, x + r, y + r], fill=col + (int(255 * alpha),), outline=(255, 255, 255, int(220 * alpha)), width=2)

def fade(t, t0, t1, fi=0.25, fo=0.25):
    if t < t0 or t > t1: return 0.0
    return min(1.0, (t - t0) / fi if fi else 1, (t1 - t) / fo if fo else 1)

def title_block(dst, t, t0, t1, en, he, sub_en=None, sub_he=None, y=1110, en_size=60, he_size=48, col=WHITE):
    a = fade(t, t0, t1)
    if a <= 0: return
    sl = 1 - eout((t - t0) / 0.35)
    txt(dst, en, 900, en_size, col, W / 2, y + 30 * sl, a)
    txt(dst, he, 800, he_size, SKY, W / 2, y + en_size + 14 + 30 * sl, a)
    if sub_en:
        a2 = fade(t, t0 + 0.35, t1)
        txt(dst, sub_en, 400, 34, MUTED, W / 2, y + en_size + he_size + 52, a2)
        txt(dst, sub_he, 400, 32, MUTED, W / 2, y + en_size + he_size + 94, a2)

# ---------------- year counter ----------------
YEARS = [(3.4, -4000), (7.3, -3000), (7.6, -3000), (10.0, -500), (10.6, -500), (11.9, 449), (14.4, 449), (15.0, 597),
         (17.6, 597), (18.2, 793), (22.0, 793), (22.6, 1066), (27.0, 1066), (27.6, 1476), (28.6, 1476), (29.2, 1600),
         (30.6, 1600)]
def year_at(t):
    for (t0, y0), (t1, y1) in zip(YEARS, YEARS[1:]):
        if t0 <= t <= t1: return y0 + (y1 - y0) * eout((t - t0) / (t1 - t0)) if t1 > t0 else y1
    return YEARS[-1][1]
def year_strs(t, y):
    approx = t < 10.6 or 28.6 < t
    if y < 0:
        v = int(round(-y / 100.0) * 100)
        return (("c. " if approx else "") + f"{v:,} BCE".replace(",", ""), ("בערך " if approx else "") + f"{v} לפני הספירה")
    v = int(round(y))
    if 28.6 < t: return ("c. 1600", "בערך 1600")
    return (f"{v} CE" if v < 1000 else f"{v}", f"{v} לספירה")

STOLEN_EVENTS = []  # times when the stolen-words counter increments
def header(dst, d, t):
    if 3.4 <= t < 31.0:
        a = min(fade(t, 3.4, 31.0, 0.3, 0.4), 1)
        y = year_at(t); en, he = year_strs(t, y)
        txt(dst, en, 900, 92, GOLD, 330, 318, a); txt(dst, he, 700, 36, MUTED, 330, 392, a)
    n = sum(1 for e in STOLEN_EVENTS if e <= t)
    if 14.8 <= t < 49.4 and n > 0:
        a = fade(t, 14.8, 49.4, 0.3, 0.3)
        bump = 0.0
        last = max([e for e in STOLEN_EVENTS if e <= t] or [-9])
        if t - last < 0.25: bump = 0.25 * (1 - (t - last) / 0.25)
        cx = 840 if t < 31.0 else W / 2
        txt(dst, str(n), 900, 80, WHITE, cx, 312, a, 1 + bump)
        txt(dst, "words stolen", 700, 28, SKY, cx, 380, a)
        txt(dst, "מילים שנגנבו", 700, 28, SKY, cx, 416, a)

# ---------------- scene data ----------------
STEPPE = (47.5, 38.0); JUT = (55.6, 9.4); ENG = (52.7, -1.2)
FAMILY = [("Hindi", "הינדי", 26.0, 77.0), ("Persian", "פרסית", 33.0, 53.0), ("Greek", "יוונית", 39.0, 22.0), ("Latin", "לטינית", 42.5, 12.5), ("Celtic", "קלטית", 52.5, -7.5)]

WORLD = [  # en, he, language en, language he, note, lat, lon
    ("chocolate", "שוקולד", "Nahuatl, via Spanish", "נאוואטל, דרך ספרדית", "Aztec Mexico", 19.4, -99.1),
    ("tomato", "עגבנייה", "Nahuatl, via Spanish", "נאוואטל, דרך ספרדית", "from tomatl", 17.6, -96.0),
    ("boss", "בוס", "Dutch", "הולנדית", "from baas, 'master'", 52.37, 4.9),
    ("kindergarten", "גן ילדים", "German", "גרמנית", "'children's garden'", 51.0, 10.5),
    ("robot", "רובוט", "Czech", "צ'כית", "robota, 'forced labour'", 50.08, 14.43),
    ("algebra", "אלגברה", "Arabic", "ערבית", "al-jabr, 'reuniting broken parts'", 33.3, 44.4),
    ("coffee", "קפה", "Arabic, via Turkish", "ערבית, דרך טורקית", "from qahwa", 15.4, 44.2),
    ("safari", "ספארי", "Swahili, from Arabic", "סוואהילית, מערבית", "safar, 'journey'", -6.16, 39.2),
    ("shampoo", "שמפו", "Hindi/Urdu", "הינדי/אורדו", "champo, 'press! knead!'", 28.6, 77.2),
    ("pajamas", "פיג'מה", "Hindi/Urdu, from Persian", "הינדי/אורדו, מפרסית", "'leg garment'", 25.0, 81.0),
    ("tea", "תה", "Min Chinese", "סינית (מין)", "te, Fujian coast", 24.48, 118.09),
    ("ketchup", "קטשופ", "Hokkien Chinese (debated)", "סינית הוקיין (שנוי במחלוקת)", "ke-tsiap, 'fish sauce'", 26.5, 119.5),
    ("tsunami", "צונאמי", "Japanese", "יפנית", "'harbour wave'", 35.68, 139.7),
]
CHUTZ = ("chutzpah", "חוצפה", "Yiddish, from Hebrew", "יידיש, מעברית", "", 52.2, 21.0)
HEBREW = [("hallelujah", "הללויה"), ("amen", "אמן"), ("jubilee", "יובל"), ("cherub", "כרוב")]
JERUSALEM = (31.78, 35.22)
SPREAD = [("USA", "ארה\"ב", 39.0, -98.0), ("Canada", "קנדה", 56.0, -106.0), ("Jamaica", "ג'מייקה", 18.1, -77.3), ("Nigeria", "ניגריה", 9.0, 8.0),
          ("South Africa", "דרום אפריקה", -30.0, 24.0), ("India", "הודו", 22.0, 79.0), ("Singapore", "סינגפור", 1.35, 103.8),
          ("Australia", "אוסטרליה", -25.0, 134.0), ("New Zealand", "ניו זילנד", -41.0, 174.0)]
TLV = (32.08, 34.78)
BACK = [("מייל", "mail"), ("סטארטאפ", "startup"), ("מיטינג", "meeting")]

# timings for part 2
P2_T0 = 35.1; P2_STEP = 0.8
WT = [P2_T0 + i * P2_STEP for i in range(len(WORLD))]
CHUTZ_T = WT[-1] + P2_STEP
HEB_T = CHUTZ_T + 1.15
HEB_TS = [HEB_T + 0.35 + i * 0.3 for i in range(4)]
FLY = 0.5

SFX = []  # (kind, time)
def sfx(kind, tt): SFX.append((kind, tt))

# Part 1 chips (en, he) with start times
CH_LATIN = [("candle", "נר"), ("altar", "מזבח"), ("school", "בית ספר")]
CH_NORSE = [("sky", "שמיים"), ("egg", "ביצה"), ("knife", "סכין"), ("they", "הם")]
CH_SHAKES = [("bedroom", "חדר שינה"), ("swagger", "התרברבות"), ("lonely", "בודד")]
CH_REN = [("skeleton", "שלד"), ("atmosphere", "אטמוספרה"), ("education", "חינוך")]
T_LATIN, T_NORSE, T_WINDOW, T_NORMAN_TAB, T_SHAKES, T_REN = 15.7, 19.0, 20.4, 23.4, 29.3, 31.9
for i in range(3): STOLEN_EVENTS.append(T_LATIN + i * 0.2); sfx("pop", T_LATIN + i * 0.2)
for i in range(4): STOLEN_EVENTS.append(T_NORSE + i * 0.2); sfx("pop", T_NORSE + i * 0.2)
STOLEN_EVENTS.append(T_WINDOW); sfx("ding", T_WINDOW)
for i in range(3): STOLEN_EVENTS.append(T_NORMAN_TAB + 0.6 + i * 0.55); sfx("pop", T_NORMAN_TAB + 0.6 + i * 0.55)
for i in range(3): STOLEN_EVENTS.append(T_SHAKES + i * 0.2); sfx("pop", T_SHAKES + i * 0.2)
for i in range(3): STOLEN_EVENTS.append(T_REN + i * 0.2); sfx("pop", T_REN + i * 0.2)
for tt in WT: STOLEN_EVENTS.append(tt + FLY); sfx("whoosh_s", tt); sfx("pop", tt + FLY)
STOLEN_EVENTS.append(CHUTZ_T + FLY); sfx("whoosh_s", CHUTZ_T); sfx("pop", CHUTZ_T + FLY)
for tt in HEB_TS: STOLEN_EVENTS.append(tt + FLY); sfx("pop", tt + FLY)
sfx("whoosh_s", HEB_TS[0])
for tt in (1.0, 7.6, 10.6, 14.4, 17.6, 22.0, 27.0, 30.6, 33.4, 49.3, 54.6, 58.8): sfx("whoosh", tt)
sfx("boom", 0.0); sfx("boom", 22.0)
for i in range(len(SPREAD)): sfx("tick", 50.3 + i * 0.32)
for i in range(3): sfx("pop", 56.2 + i * 0.45)
sfx("ding", 53.2); sfx("ding", 57.9)

# ---------------- frame ----------------
def frame(t):
    if t < 1.0: return hook(t)
    if t >= 58.8: return endcard(t)
    cam = camera(t)
    img = render_map(cam)
    d = ImageDraw.Draw(img, "RGBA")
    pp = lambda ll: P(cam, *ll)

    # ---------- Part 1 ----------
    if 1.0 <= t < 3.4:
        a = fade(t, 1.0, 3.4, 0.3, 0.3)
        txt(img, "Where did English", 900, 76, WHITE, W / 2, 1130, a)
        txt(img, "come from?", 900, 76, WHITE, W / 2, 1215, a)
        txt(img, "מאיפה הגיעה האנגלית?", 800, 54, SKY, W / 2, 1300, a)
        a2 = fade(t, 1.6, 3.4, 0.25, 0.3)
        txt(img, "Follow the words.", 700, 44, GOLD, W / 2, 1390, a2)
        txt(img, "עקבו אחרי המילים.", 700, 40, GOLD, W / 2, 1446, a2)

    if 3.4 <= t < 31.0:
        p1a = fade(t, 3.4, 31.0, 0.3, 0.4)
        # family lines from steppe
        if 3.4 <= t < 8.4:
            fa = fade(t, 4.2, 8.4, 0.3, 0.5)
            for i, (en, he, la, lo) in enumerate(FAMILY):
                u = eout((t - 4.2 - i * 0.18) / 0.7)
                if u <= 0: continue
                e = arc_line(d, pp(STEPPE), pp((la, lo)), 0, u, MUTED, 2, int(170 * fa), 0.12, glow=False)
                if u > 0.95:
                    x, y = pp((la, lo)); pin(img, d, x, y, MUTED, fa, 5)
                    txt(img, en, 700, 28, WHITE, x, y - 50, fa); txt(img, he, 700, 25, SKY, x, y - 22 - 0, fa) if False else txt(img, he, 700, 25, SKY, x, y + 32, fa)
        # trail
        pts = []
        def seg(a, b, u, bulge=0.12):
            return [bez(pp(a), pp(b), u * i / 30, bulge) for i in range(31)]
        if t >= 3.4: pts = [pp(STEPPE)]
        if t >= 7.9:
            u = eout((t - 7.9) / 2.0); pts = seg(STEPPE, JUT, u)
        if t >= 10.9:
            pts = seg(STEPPE, JUT, 1) + seg(JUT, ENG, eout((t - 10.9) / 1.6), 0.18)
        if len(pts) > 1:
            d.line(pts, fill=GOLD + (int(55 * p1a),), width=16, joint="curve")
            d.line(pts, fill=GOLD + (int(230 * p1a),), width=5, joint="curve")
        hx_, hy_ = pts[-1]
        pr = (t * 1.3) % 1.0
        d.ellipse([hx_ - 14 - 60 * pr, hy_ - 14 - 60 * pr, hx_ + 14 + 60 * pr, hy_ + 14 + 60 * pr], outline=GOLD + (int(200 * (1 - pr) * p1a),), width=3)
        put(img, GLOW_G, hx_, hy_, p1a)
        # Angles / Saxons / Jutes side boats
        if 10.9 <= t < 14.6:
            ba = fade(t, 10.9, 14.6, 0.2, 0.3)
            for (src, dst_, nm, nmh) in [((54.6, 9.8), (54.0, -1.6), "Angles", "אנגלים"), ((53.3, 8.2), (51.6, -0.4), "Saxons", "סקסונים"), ((56.3, 8.8), (51.2, 1.0), "Jutes", "יוטים")]:
                u = eout((t - 10.9) / 1.7)
                x, y = bez(pp(src), pp(dst_), u, 0.15)
                arc_line(d, pp(src), pp(dst_), 0, u, SKY, 3, int(200 * ba), 0.15)
                put(img, GLOW_S, x, y, ba)
                lx = x + 70 if nm != "Angles" else x + 70
                la_ = ba * fade(t, 10.9, 12.4, 0.2, 0.3)
                ox, oy = {"Angles": (0, -80), "Saxons": (0, 46), "Jutes": (120, 0)}[nm]
                txt(img, nm, 800, 30, WHITE, x + ox, y + oy - 18, la_)
                txt(img, nmh, 700, 26, SKY, x + ox, y + oy + 16, la_)
        # incoming influences
        def influx(t0, srcs, col, label=None):
            if t < t0: return
            u = eout((t - t0) / 1.0)
            for s_ in srcs:
                arc_line(d, pp(s_), pp(ENG), 0, u, col, 4, int(230 * p1a), 0.2)
                xs, ys = pp(s_); pin(img, d, xs, ys, col, p1a)
            if u < 1:
                for s_ in srcs:
                    x, y = bez(pp(s_), pp(ENG), u, 0.2); put(img, GLOW_W, x, y, p1a)
        if 14.4 <= t < 17.8:
            influx(14.5, [(41.9, 12.5)], GOLD)
            xs, ys = pp((41.9, 12.5)); a = fade(t, 14.6, 17.8)
            txt(img, "Rome", 800, 32, WHITE, xs, ys + 44, a); txt(img, "רומא", 700, 28, SKY, xs, ys + 80, a)
        if 17.6 <= t < 22.2:
            influx(17.7, [(60.4, 5.3), (55.7, 12.0)], SKY)
            xs, ys = pp((60.4, 5.3)); a = fade(t, 17.8, 22.2)
            txt(img, "Vikings", 800, 34, WHITE, xs + 20, ys - 50, a); txt(img, "ויקינגים", 700, 30, SKY, xs + 20, ys - 14, a)
        if 22.0 <= t < 27.2:
            influx(22.1, [(49.18, -0.37)], WHITE)
            xs, ys = pp((49.18, -0.37)); a = fade(t, 22.2, 27.2)
            txt(img, "Normandy", 800, 34, WHITE, xs, ys + 46, a); txt(img, "נורמנדי", 700, 30, SKY, xs, ys + 84, a)
        if 27.0 <= t < 31.0:
            xs, ys = pp((51.5, -0.13)); a = fade(t, 27.2, 31.0)
            txt(img, "Westminster", 800, 32, WHITE, xs, ys + 46, a); txt(img, "וסטמינסטר", 700, 28, SKY, xs, ys + 82, a)
        if 30.6 <= t < 33.6:
            pass

    if 30.6 <= t < 34.0:
        ra = fade(t, 30.8, 34.0, 0.3, 0.4)
        u = eout((t - 30.9) / 1.0)
        for s_, col, nm, nmh in [((41.9, 12.5), GOLD, "Latin", "לטינית"), ((37.98, 23.73), SKY, "Greek", "יוונית")]:
            arc_line(d, pp(s_), pp(ENG), 0, u, col, 4, int(230 * ra), 0.2)
            xs, ys = pp(s_); pin(img, d, xs, ys, col, ra)
            txt(img, nm, 800, 32, WHITE, xs, ys + 44, ra); txt(img, nmh, 700, 28, SKY, xs, ys + 80, ra)
        x, y = pp(ENG); put(img, GLOW_G, x, y, ra)

    # ---------- Part 2 ----------
    if 33.4 <= t < 49.6:
        wa = fade(t, 34.0, 49.6, 0.4, 0.4)
        lx, ly = pp(LONDON)
        # pins accumulated
        for i, w in enumerate(WORLD + [CHUTZ]):
            t0 = WT[i] if i < len(WORLD) else CHUTZ_T
            if t < t0: continue
            x, y = pp((w[5], w[6])); col = GOLD if i == len(WORLD) else SKY
            pin(img, d, x, y, col, wa * min(1, (t - t0) / 0.15), 7)
            u = eout((t - t0) / FLY)
            arc_line(d, (x, y), (lx, ly), 0, u, col, 2, int(110 * wa), 0.18, glow=False)
            if u < 1:
                hx2, hy2 = bez((x, y), (lx, ly), u, 0.18)
                put(img, GLOW_W, hx2, hy2, wa)
                txt(img, w[0], 800, 30, WHITE, hx2, hy2 - 34, wa)
        if t >= HEB_T:
            jx, jy = pp(JERUSALEM); pin(img, d, jx, jy, GOLD, wa, 9)
            for k, tt in enumerate(HEB_TS):
                if t < tt: continue
                u = eout((t - tt) / FLY)
                arc_line(d, (jx, jy), (lx, ly), 0, u, GOLD, 3, int(160 * wa), 0.12 + 0.07 * k, glow=False)
                if u < 1:
                    hx2, hy2 = bez((jx, jy), (lx, ly), u, 0.12 + 0.07 * k); put(img, GLOW_G, hx2, hy2, wa * 0.8)
        # London glow pulse
        last = max([e for e in STOLEN_EVENTS if e <= t] or [-9]); pulse = max(0, 1 - (t - last) / 0.35)
        put(img, GLOW_G, lx, ly, wa, 0.7 + 0.6 * pulse)
        txt(img, "London", 800, 28, WHITE, lx - 70, ly - 30, wa)

    # ---------- Part 3 ----------
    if 49.2 <= t < 55.0:
        sa = fade(t, 49.4, 55.0, 0.4, 0.4)
        lx, ly = pp(LONDON)
        for i, (en, he, la, lo) in enumerate(SPREAD):
            t0 = 50.3 + i * 0.32
            if t < t0: continue
            u = eout((t - t0) / 0.6); x, y = pp((la, lo))
            arc_line(d, (lx, ly), (x, y), 0, u, GOLD, 3, int(200 * sa), 0.16)
            if u > 0.9:
                a2 = sa * min(1, (u - 0.9) * 10)
                rr = 10 + 18 * eback(min(1, (t - t0 - 0.5) / 0.4))
                d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=GOLD + (int(70 * a2),), outline=GOLD + (int(220 * a2),), width=2)
                ox = min(max(x, 90), W - 90)
                txt(img, en, 800, 26, WHITE, ox, y - 74, a2); txt(img, he, 700, 24, SKY, ox, y - 46, a2)
        put(img, GLOW_G, lx, ly, sa)

    # ---------- Twist ----------
    if 54.4 <= t < 58.8:
        ta = fade(t, 54.8, 58.8, 0.4, 0.3)
        lx, ly = pp(LONDON); tx_, ty_ = pp(TLV)
        pin(img, d, lx, ly, SKY, ta); pin(img, d, tx_, ty_, GOLD, ta, 11)
        txt(img, "London", 800, 30, WHITE, lx, ly - 44, ta); txt(img, "Tel Aviv", 800, 30, WHITE, tx_ - 20, ty_ + 46, ta)
        txt(img, "תל אביב", 700, 28, SKY, tx_ - 20, ty_ + 82, ta)
        for k in range(3):
            t0 = 55.7 + k * 0.45
            if t < t0: continue
            u = eout((t - t0) / FLY); bu = -0.15 - 0.08 * k
            arc_line(d, (lx, ly), (tx_, ty_), 0, u, SKY, 3, int(180 * ta), bu)
            if u < 1:
                x, y = bez((lx, ly), (tx_, ty_), u, bu); put(img, GLOW_S, x, y, ta)
                txt(img, BACK[k][0], 800, 34, WHITE, x, y - 36, ta)

    # ---------- overlays: gradient panels ----------
    img.paste(TOPP, (0, 0), TOPP); img.paste(BOTP, (0, 1020), BOTP)
    d = ImageDraw.Draw(img, "RGBA")
    header(img, d, t)

    # ---------- cards ----------
    title_block(img, t, 3.5, 7.7, "Proto-Indo-European", "פרוטו-הודו-אירופית", "One leading theory: born on the Pontic steppe", "תיאוריה מובילה: נולדה בערבות שמצפון לים השחור")
    if 4.6 <= t < 7.7:
        a = fade(t, 4.6, 7.7)
        txt(img, "Grandma of English, Hindi, Persian, Greek, Latin", 700, 30, GOLD, W / 2, 1400, a)
        txt(img, "סבתא של אנגלית, הינדי, פרסית, יוונית ולטינית", 700, 30, GOLD, W / 2, 1446, a)
    title_block(img, t, 7.7, 10.6, "Germanic tribes", "השבטים הגרמאניים", "Northern Germany and Denmark", "צפון גרמניה ודנמרק")
    title_block(img, t, 10.7, 12.5, "Angles, Saxons and Jutes", "אנגלים, סקסונים ויוטים", "cross the sea to Britain", "חוצים את הים לבריטניה", en_size=56)
    if 12.4 <= t < 14.5:
        a = fade(t, 12.4, 14.5); al, sc = pop(t, 12.4, 0.3)
        txt(img, "Old English is born", 900, 64, WHITE, W / 2, 1120, a, sc)
        txt(img, "נולדה האנגלית העתיקה", 800, 50, SKY, W / 2, 1196, a, sc)
        a2 = fade(t, 12.9, 14.5)
        txt(img, "Englaland = land of the Angles", 800, 44, GOLD, W / 2, 1300, a2)
        txt(img, "אנגליה = ארץ האנגלים", 800, 42, GOLD, W / 2, 1360, a2)
    title_block(img, t, 14.6, 17.7, "Christianity brings Latin", "הנצרות מביאה לטינית", y=1100)
    if 15.6 <= t < 17.7:
        chip_row(img, d, CH_LATIN, t, T_LATIN, 1335)
    title_block(img, t, 17.8, 22.1, "Vikings bring Old Norse", "הוויקינגים מביאים נורדית עתיקה", y=1100)
    if 18.9 <= t < 20.4:
        chip_row(img, d, CH_NORSE, t, T_NORSE, 1335)
    if 20.4 <= t < 22.1:
        a = fade(t, 20.4, 22.1, 0.15); al, sc = pop(t, 20.4, 0.3)
        txt(img, "window", 900, 96, WHITE, W / 2, 1290, a, sc)
        txt(img, "Old Norse vindauga: \"wind eye\"", 800, 50, GOLD, W / 2, 1382, a, sc)
        txt(img, "חלון = \"עין הרוח\"", 800, 46, SKY, W / 2, 1446, a, sc)
    title_block(img, t, 22.2, 27.1, "1066: the Normans bring French", "הנורמנים מביאים צרפתית", y=1080, en_size=54)
    if 23.4 <= t < 27.1:
        a = fade(t, 23.4, 27.1)
        txt(img, "On the farm: English", 800, 30, SKY, 290, 1250, a); txt(img, "בחווה: אנגלית", 700, 28, MUTED, 290, 1288, a)
        txt(img, "On the plate: French", 800, 30, GOLD, 790, 1250, a); txt(img, "בצלחת: צרפתית", 700, 28, MUTED, 790, 1288, a)
        for i, (an, ah, me, mh) in enumerate([("cow", "פרה", "beef", "בשר בקר"), ("pig", "חזיר", "pork", "בשר חזיר"), ("sheep", "כבש", "mutton", "בשר כבש")]):
            tt = T_NORMAN_TAB + 0.6 + i * 0.55; y = 1352 + i * 62
            al, sc = pop(t, tt - 0.25); txt(img, f"{an}  {ah}", 800, 42, WHITE, 290, y, a * al, sc)
            al2, sc2 = pop(t, tt)
            if al2 > 0:
                d.line([(515, y), (560, y)], fill=MUTED + (int(255 * a * al2),), width=4)
                d.polygon([(568, y), (552, y - 9), (552, y + 9)], fill=MUTED + (int(255 * a * al2),))
            txt(img, f"{me}  {mh}", 800, 42, GOLD, 790, y, a * al2, sc2)
        if t > 25.6:
            a3 = fade(t, 25.6, 27.1)
            txt(img, "Peasants raised it. Nobles ate it.", 700, 30, WHITE, W / 2, 1546 - 20, a3 * 0)  # kept off: below safe zone
    title_block(img, t, 27.1, 29.2, "1476: Caxton's printing press", "מכונת הדפוס של קקסטון", "Spelling starts to freeze", "האיות מתחיל לקפוא", y=1100, en_size=54)
    title_block(img, t, 29.2, 30.9, "First recorded in Shakespeare", "תועדו לראשונה אצל שייקספיר", y=1100, en_size=54)
    if 29.2 <= t < 30.9:
        chip_row(img, d, CH_SHAKES, t, T_SHAKES, 1335)
    title_block(img, t, 30.9, 33.6, "Renaissance: Latin and Greek", "הרנסנס: לטינית ויוונית", y=1100, en_size=54)
    if 31.8 <= t < 33.6:
        chip_row(img, d, CH_REN, t, T_REN, 1335)

    # Part 2 cards
    if 33.6 <= t < 35.2:
        a = fade(t, 33.6, 35.2, 0.25, 0.2); al, sc = pop(t, 33.6, 0.3)
        txt(img, "Then English went shopping.", 900, 58, WHITE, W / 2, 1170, a, sc)
        txt(img, "Worldwide.", 900, 58, GOLD, W / 2, 1240, a, sc)
        txt(img, "ואז האנגלית יצאה לשופינג עולמי", 800, 46, SKY, W / 2, 1320, a, sc)
    for i, w in enumerate(WORLD + [CHUTZ]):
        t0 = WT[i] if i < len(WORLD) else CHUTZ_T
        t1 = t0 + (P2_STEP if i < len(WORLD) else 1.15)
        if not (t0 <= t < t1): continue
        u = (t - t0); al, sc = pop(t, t0, 0.22)
        a = min(1, (t1 - t) / 0.1)
        col = GOLD if i == len(WORLD) else WHITE
        txt(img, w[0], 900, 104 if len(w[0]) < 10 else 92, col, W / 2, 1150, a * al, sc)
        txt(img, w[1], 800, 58, SKY, W / 2, 1250, a * al, sc)
        # language pill
        l1 = timg(w[2], F(700, 32), GOLD); l2 = timg(w[3], F(700, 30), GOLD)
        txt(img, w[2], 700, 32, GOLD, W / 2, 1338, a * al)
        txt(img, w[3], 700, 30, GOLD, W / 2, 1382, a * al)
        if w[4]: txt(img, w[4], 400, 30, MUTED, W / 2, 1440, a * al)
    if HEB_T <= t < 49.4:
        a = fade(t, HEB_T, 49.4, 0.2, 0.3)
        txt(img, "And from Hebrew, via the Bible", 900, 46, GOLD, W / 2, 1100, a)
        txt(img, "ומהעברית, דרך התנ\"ך", 800, 42, GOLD, W / 2, 1156, a)
        for k, (en, he) in enumerate(HEBREW):
            al, sc = pop(t, HEB_TS[k] + FLY - 0.1)
            cx = W / 2 + (-235 if k % 2 == 0 else 235); cy = 1265 + (k // 2) * 140
            chip(img, d, en, he, cx, cy, a * al, sc, w_en=50)
    # Part 3 cards
    if 49.4 <= t < 55.0:
        a = fade(t, 49.4, 55.0, 0.3, 0.4)
        txt(img, "Then English went everywhere", 900, 54, WHITE, W / 2, 1110, a)
        txt(img, "ואז האנגלית הגיעה לכל מקום", 800, 44, SKY, W / 2, 1176, a)
        u = (t - 50.0) / 3.2
        if 50.0 <= t < 53.2:
            a1 = a * fade(t, 50.0, 53.2, 0.25, 0.2)
            txt(img, "c. 1600: 5 to 7 million speakers", 800, 44, WHITE, W / 2, 1290, a1)
            txt(img, "בערך 1600: 5 עד 7 מיליון דוברים", 700, 36, SKY, W / 2, 1352, a1)
        if t >= 53.2:
            al, sc = pop(t, 53.2, 0.3)
            txt(img, "Today: about 1.5 billion", 900, 70, GOLD, W / 2, 1290, a * al, sc)
            txt(img, "English speakers", 700, 36, WHITE, W / 2, 1368, a * al)
            txt(img, "היום: כ-1.5 מיליארד דוברי אנגלית", 700, 36, SKY, W / 2, 1418, a * al)
        yr = int(1600 + (2026 - 1600) * eout(min(1, max(0, u))))
        txt(img, str(yr), 900, 92, GOLD, W / 2, 318, a)
        if t >= 53.2: txt(img, "Source: Ethnologue 2025", 400, 26, MUTED, W / 2, 392, a)
    # twist
    if 54.6 <= t < 58.8:
        a = fade(t, 54.6, 58.8, 0.3, 0.3)
        txt(img, "Plot twist:", 800, 40, GOLD, W / 2, 1180, a)
        txt(img, "Hebrew now borrows back", 900, 56, WHITE, W / 2, 1240, a)
        txt(img, "והעברית לווה בחזרה", 800, 46, SKY, W / 2, 1306, a)
        for k, (heb, en) in enumerate(BACK):
            al, sc = pop(t, 56.2 + k * 0.45)
            cx = W / 2 + (k - 1) * 300
            chip(img, d, heb, en, cx, 1420, a * al, sc, w_en=52)
        if t > 57.8:
            al, sc = pop(t, 57.8)
            txt(img, "The thief became the lender.", 800, 38, GOLD, W / 2, 1520, a * al, sc)
    return img

def hook(t):
    img = Image.new("RGB", (W, H), GOLD); d = ImageDraw.Draw(img, "RGBA")
    al, sc = pop(t, 0.0, 0.18)
    txt(img, "English", 900, 150, NAVY1, W / 2, 700, 1, sc, shadow=False)
    txt(img, "is a thief.", 900, 150, NAVY1, W / 2, 860, 1, sc, shadow=False)
    txt(img, "Here's what it stole.", 800, 64, NAVY2, W / 2, 1010, 1, sc, shadow=False)
    txt(img, "האנגלית היא גנבת.", 900, 72, NAVY1, W / 2, 1150, 1, sc, shadow=False)
    txt(img, "הנה מה שהיא גנבה.", 700, 54, NAVY2, W / 2, 1234, 1, sc, shadow=False)
    return img

_BG = None
def endcard(t):
    global _BG
    if _BG is None:
        g = np.linspace(0, 1, H)[:, None, None]
        _BG = Image.fromarray((np.array(NAVY1) * (1 - g) + np.array(NAVY2) * g).repeat(W, 1).astype(np.uint8), "RGB")
    img = _BG.copy(); d = ImageDraw.Draw(img, "RGBA")
    al, sc = pop(t, 58.8, 0.35)
    lg = LOGO.resize((340, 340), Image.LANCZOS)
    put(img, lg, W / 2, 640, al, sc)
    a2 = fade(t, 59.1, 63.5, 0.3, 0.1)
    txt(img, "English has always borrowed.", 800, 46, WHITE, W / 2, 920, a2)
    txt(img, "Your turn to speak it.", 800, 46, GOLD, W / 2, 982, a2)
    txt(img, "האנגלית תמיד שאלה מילים. עכשיו תורך לדבר אותה.", 700, 34, SKY, W / 2, 1050, a2)
    a3 = fade(t, 59.6, 63.5, 0.3, 0.1); al3, sc3 = pop(t, 59.6)
    d.rounded_rectangle([140, 1150, 940, 1260], radius=55, fill=SKY + (int(255 * a3),))
    txt(img, "Follow @expressenglishcom", 900, 46, WHITE, W / 2, 1203, a3, shadow=False)
    txt(img, "for more", 700, 36, WHITE, W / 2, 1300, a3)
    txt(img, "עקבו אחרי \u200e@expressenglishcom לעוד", 700, 34, SKY, W / 2, 1352, a3)
    txt(img, "English Express  ·  @noamroz__", 700, 30, MUTED, W / 2, 1440, a3)
    return img

# ---------------- audio ----------------
def build_audio(path):
    SR = 44100; n = int(SR * T_END); out = np.zeros(n); rng = np.random.default_rng(7)
    def place(sig, st, g):
        i = int(st * SR); j = min(n, i + len(sig))
        if i < n and j > i: out[i:j] += g * sig[:j - i]
    def lp(x, a):
        y = np.empty_like(x); s = 0.0
        for i in range(len(x)): s += a * (x[i] - s); y[i] = s
        return y
    tt = np.arange(int(0.12 * SR)) / SR
    POP = np.sin(2 * np.pi * np.cumsum(520 + 700 * np.exp(-tt * 40)) / SR) * np.exp(-tt * 38)
    nz = rng.standard_normal(int(0.55 * SR)); tw = np.arange(len(nz)) / SR
    env = np.sin(np.pi * np.clip(tw / 0.55, 0, 1)) ** 2
    WH = lp(nz, 0.08) * env; WH = WH - lp(WH, 0.02); WH /= np.abs(WH).max()
    nz2 = rng.standard_normal(int(0.32 * SR)); tw2 = np.arange(len(nz2)) / SR
    WHS = lp(nz2, 0.15) * np.sin(np.pi * tw2 / 0.32) ** 2; WHS /= np.abs(WHS).max()
    tb = np.arange(int(0.9 * SR)) / SR
    BOOM = np.sin(2 * np.pi * np.cumsum(45 + 90 * np.exp(-tb * 12)) / SR) * np.exp(-tb * 4.5)
    td = np.arange(int(1.0 * SR)) / SR
    DING = (np.sin(2 * np.pi * 1318 * td) + 0.5 * np.sin(2 * np.pi * 1976 * td)) * np.exp(-td * 5) * np.minimum(1, td / 0.004)
    tk = np.arange(int(0.05 * SR)) / SR; TICK = np.sin(2 * np.pi * 1800 * tk) * np.exp(-tk * 90)
    for k, st in SFX:
        if k == "pop": place(POP, st, 0.30)
        elif k == "whoosh": place(WH, st - 0.25, 0.28)
        elif k == "whoosh_s": place(WHS, st, 0.12)
        elif k == "boom": place(BOOM, st, 0.55)
        elif k == "ding": place(DING, st, 0.16)
        elif k == "tick": place(TICK, st, 0.18)
    w = wave.open(DIR + "music_eo.wav"); mus = np.frombuffer(w.readframes(w.getnframes()), np.int16).reshape(-1, 2)[:, 0] / 32767.0
    m = np.zeros(n); L = min(n, len(mus)); m[:L] = mus[:L]
    fo = int(1.5 * SR); m[-fo:] *= np.linspace(1, 0, fo)
    mix = m * 0.30 + out
    mix = np.tanh(mix * 1.1) * 0.92
    st = np.stack([mix, mix], 1)
    wo = wave.open(path, "wb"); wo.setnchannels(2); wo.setsampwidth(2); wo.setframerate(SR); wo.writeframes((st * 32767).astype(np.int16).tobytes()); wo.close()

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "frames":
        os.makedirs(DIR + "check", exist_ok=True)
        for ts in sys.argv[2:]:
            frame(float(ts)).save(DIR + f"check/f_{float(ts):05.1f}.png")
    elif mode == "audio":
        build_audio(DIR + "mix.wav")
    elif mode == "video":
        build_audio(DIR + "mix.wav")
        out = DIR + "english_origin_v1.mp4"
        p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                              "-i", DIR + "mix.wav", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-threads", "1",
                              "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
        import time; t0 = time.time()
        for i in range(NF):
            p.stdin.write(frame(i / FPS).tobytes())
            if i % 150 == 0: print(i, NF, round(time.time() - t0), flush=True)
        p.stdin.close(); p.wait(); print("done", round(time.time() - t0))
