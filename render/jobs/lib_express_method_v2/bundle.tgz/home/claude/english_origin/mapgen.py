"""Builds two Mercator map rasters (world L0 and Europe/Near East L1) from world-atlas 50m topojson.
Copied approach from /home/claude/vid/topo.py (read only), extended to countries + coast/border split."""
import json, math, numpy as np
from PIL import Image, ImageDraw

TOPO = "/home/claude/geo/package/countries-50m.json"
OUT = "/home/claude/english_origin/maps/"
OCEAN = (9, 21, 44)
LAND = (31, 58, 104)
BORDER = (52, 86, 138)
COAST = (78, 124, 182)
GRID = (17, 33, 62)

def merc(lat):
    lat = max(-85.0, min(85.0, lat))
    return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))

def decode():
    t = json.load(open(TOPO)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]
    arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a:
            x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    use = [0] * len(arcs)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    polys = []
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        rings = g["arcs"] if g["type"] == "Polygon" else [r for p in g["arcs"] for r in p]
        for ring in rings:
            pts = []
            for i in ring:
                use[i if i >= 0 else ~i] += 1; pts.extend(arc(i))
            polys.append(pts)
    coast = [arcs[i] for i in range(len(arcs)) if use[i] == 1]
    border = [arcs[i] for i in range(len(arcs)) if use[i] >= 2]
    return polys, coast, border

def build(name, lon0, lon1, lat0, lat1, s, ss, lw):
    S = s * ss
    yt = merc(lat1)
    Wd = int((lon1 - lon0) * S); Hd = int((yt - merc(lat0)) * S)
    im = Image.new("RGB", (Wd, Hd), OCEAN); d = ImageDraw.Draw(im)
    P = lambda lon, lat: ((lon - lon0) * S, (yt - merc(lat)) * S)
    # graticule every 15 deg
    for lo in range(-180, 181, 15):
        if lon0 <= lo <= lon1: d.line([P(lo, lat0), P(lo, lat1)], fill=GRID, width=max(1, ss))
    for la in range(-75, 90, 15):
        if lat0 <= la <= lat1: d.line([P(lon0, la), P(lon1, la)], fill=GRID, width=max(1, ss))
    polys, coast, border = decode()
    def unwrap(p):
        out = [p[0]]; off = 0.0
        for (x0, _), (x1, y1) in zip(p, p[1:]):
            if x1 - x0 > 180: off -= 360
            elif x0 - x1 > 180: off += 360
            out.append((x1 + off, y1))
        return out
    def split(ln):
        segs = [[ln[0]]]
        for a, b in zip(ln, ln[1:]):
            if abs(b[0] - a[0]) > 180: segs.append([])
            segs[-1].append(b)
        return [g for g in segs if len(g) > 1]
    polys = [q for p in polys for k in (-360, 0, 360) for q in [[(x + k, y) for x, y in unwrap(p)]]]
    coast = [g for l in coast for g in split(l)]; border = [g for l in border for g in split(l)]
    for p in polys:
        a = np.array(p)
        if a[:, 0].max() < lon0 - 2 or a[:, 0].min() > lon1 + 2 or a[:, 1].max() < lat0 - 2 or a[:, 1].min() > lat1 + 2: continue
        d.polygon([P(x, y) for x, y in p], fill=LAND)
    for ln in border:
        d.line([P(x, y) for x, y in ln], fill=BORDER, width=lw * ss)
    for ln in coast:
        d.line([P(x, y) for x, y in ln], fill=COAST, width=lw * ss)
    if ss > 1: im = im.resize((Wd // ss, Hd // ss), Image.LANCZOS)
    im.save(OUT + name + ".png")
    json.dump(dict(lon0=lon0, lon1=lon1, lat0=lat0, lat1=lat1, s=s), open(OUT + name + ".json", "w"))
    print(name, im.size)

if __name__ == "__main__":
    import os; os.makedirs(OUT, exist_ok=True)
    build("L0", -180, 180, -60, 80, 14, 2, 1)
    build("L1", -15, 60, 20, 75, 90, 1, 2)
