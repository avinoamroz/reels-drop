"""Bespoke reelkit scenes for "Babysitters, not colonizers?" (@noamroz__, 30 Oct 2026).
compare : hook at frame 0 that shrinks into a title, then a 2-column table COLONIZER vs BABYSITTER, one row per trait,
          cells / fact / check+cross marks appear on their words (marks r<k>_l, r<k>_r, r<k>_f, r<k>_m), stickers s0, s1.
verdict : "In my view" card with the score.
other   : the other side, items on marks i0.., i1..
loop    : last line back to the hook.
Layout keeps x 60..920 (right 160 px clear for IG buttons) and y <= 1540 (bottom 380 px clear). No subtitles."""
import math
import render as RD
from render import P, T, pill, PP, fade_in, block, block_h, shadow_box, col
from kit import ease, ramp, lerp, St, sa, rr, circ, box

RD.draw_subs = lambda c, t, items: None          # bottom 380 px stays clear: no burned-in subtitles
CX = 490; L, R = 60, 920; CW = R - L              # content column centre and edges
COLX = (270, 710); COLW = 420                      # column centres and widths
SRC_Y = (1480, 1520)

def mark(c, x, y, ok, a, s, r=40):
    if a <= 0.01 or s <= 0.01: return
    c.save(); c.translate(x, y); c.scale(s, s)
    circ(c, 0, 3, r + 4, P["navy"], 0.18 * a); circ(c, 0, 0, r, P["green"] if ok else P["red"], a, stroke=P["white"], sw=5)
    sa(c, P["white"], a); c.set_line_width(9); c.set_line_cap(1); c.set_line_join(1)
    if ok: c.move_to(-r * 0.45, 0); c.line_to(-r * 0.12, r * 0.33); c.line_to(r * 0.5, -r * 0.38)
    else: c.move_to(-r * 0.38, -r * 0.38); c.line_to(r * 0.38, r * 0.38); c.move_to(r * 0.38, -r * 0.38); c.line_to(-r * 0.38, r * 0.38)
    c.stroke(); c.restore()

def sources(c, t, S, items):
    """items [(t_from, "line 1", "line 2")]: the latest due one is drawn, 34 px grey, above the bottom safe zone"""
    cur = None
    for tf, *ls in items:
        if t >= tf - 0.01: cur = (tf, ls)
    if not cur: return
    a = fade_in(t, cur[0], S, 0.3)
    for k, l in enumerate(cur[1]):
        if l: T(c, l, 34, CX, SRC_Y[k], P["grey"], a, 1.0, 700, maxw=CW, src=True)

def tm(S, k, d=None):
    return S["times"].get(k, d if d is not None else 999)

def sc_compare(c, t, S):
    rows = S["rows"]; hook_end = tm(S, "shrink", 2.6)
    u = ease((t - hook_end) / 0.55)                      # 0 = hook layout, 1 = table layout
    # ---- hook (frame 0): two big lines + "Let's check." ; then the small title
    if u < 1:
        a = 1 - u; br = 1 + 0.015 * math.sin(t * 2.4)
        block(c, S["hook1"], 104, CX, 330 - 60 * u, P["navy"], a, br, maxw=CW, max_lines=1)
        block(c, S["hook2"], 120, CX, 450 - 60 * u, P["blue"], a, br, maxw=CW, max_lines=1)
        w_ = ease(t / 0.9) if t > 0 else 0.0
        box(c, CX - 300 * w_, 528, 600 * w_, 12, 6, P["gold"], a)
        pill(c, S["hook3"], 64, CX, 620, P["navy"], P["white"], a, 1 + 0.03 * math.sin(t * 3.2), outline=P["gold"])
    if u > 0:
        block(c, S["title"], 66, CX, 240, P["navy"], u, 1.0, hl=P["blue"], maxw=CW, max_lines=1)
        box(c, CX - 260, 288, 520, 8, 4, P["gold"], u)
    # ---- column headers (on screen from frame 0, slide up with the table)
    hy = lerp(760, 345, u)
    for k, (lab, cc) in enumerate(S["cols"]):
        pill(c, lab, 58, COLX[k], hy, col(cc), P["white"], 1.0, 1.0, outline=P["white"], w=900, padx=0.5, padh=1.4)
    # ---- rows
    y0s = [lerp(860, 420, u) + k * lerp(150, 262, u) for k in range(len(rows))]
    rh = lerp(120, 236, u)
    for k, rw in enumerate(rows):
        y0 = y0s[k]; tl = tm(S, f"r{k}_l"); tr_ = tm(S, f"r{k}_r"); tf = tm(S, f"r{k}_f"); tmk = tm(S, f"r{k}_m")
        on = t >= tl - 0.1
        if u < 1 and not on:      # hook: empty placeholder rows under the headers
            for j in (0, 1):
                box(c, COLX[j] - COLW / 2, y0, COLW, rh, 26, P["white"], 0.55 * (1 - u), stroke=P["silver"], sw=3)
                T(c, "?", 64, COLX[j], y0 + rh / 2, P["silver"], 1 - u, 1.0, 900)
            continue
        if not on: continue
        a = fade_in(t, tl - 0.1, S, 0.25); dx = 220 * (1 - ease((t - tl + 0.1) / 0.35))
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, L, y0, CW, rh, 30, P["card"], stroke=P["silver"], sw=3, sh=6)
        c.restore(); St.a = old
        win = rw["match"]; mm = ramp(t, tmk - 0.05, tmk + 0.3) if t >= tmk - 0.05 else 0.0
        for j, key, tt in ((0, "l", tl), (1, "r", tr_)):
            if t < tt - 0.1: continue
            if j == win and mm > 0:
                box(c, COLX[j] - COLW / 2 + 6, y0 + 8, COLW - 12, 140, 22, P["green"], 0.14 * mm)
            dim = 1 - 0.5 * mm if j != win else 1.0
            aa, ss = PP(t, tt, S)
            block(c, rw[key], 58, COLX[j] - 32, y0 + 80, P["navy"] if j == 0 else P["blue"], aa * dim, ss, maxw=COLW - 76, max_lines=2, lh=1.06)
        box(c, CX - 2, y0 + 22, 4, 116, 2, P["silver"], a)
        if t >= tf - 0.1:
            af = fade_in(t, tf - 0.1, S, 0.3)
            block(c, rw["fact"], 40, CX, y0 + 190, P["gold_text"], af, 1.0, w=800, maxw=CW - 50, max_lines=2, lh=1.08)
        if t >= tmk - 0.1:
            for j in (0, 1):
                am, sm = PP(t, tmk + 0.12 * j, S, bounce=2.6)
                mark(c, COLX[j] + COLW / 2 - 40, y0 + 80, j == win, am, sm, r=32)
    # ---- babysitter stickers (in the empty 4th row slot, before it fills)
    for k, st in enumerate(S.get("stickers", [])):
        ts_, te = tm(S, f"s{k}"), tm(S, f"s{k}_end")
        if not (ts_ - 0.1 <= t <= te + 0.3): continue
        a, s = PP(t, ts_, S, bounce=2.4); a *= 1 - ramp(t, te, te + 0.25)
        c.save(); c.translate(CX, y0s[3] + rh / 2); c.rotate(math.radians(st.get("rot", -3))); c.translate(-CX, -(y0s[3] + rh / 2))
        pill(c, st["en"], 56, CX, y0s[3] + rh / 2, col(st.get("color", "gold")), P["white"], a, s, outline=P["white"], padx=0.5)
        c.restore()
    sources(c, t, S, [(tm(S, x["at"], 0), *x["lines"]) for x in S["sources"]])

def sc_verdict(c, t, S):
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); pill(c, S["score"], 46, CX, 300, P["navy"], P["white"], a, s, outline=P["gold"])
    shadow_box(c, L, 400, CW, 860, 44, P["card"], a, stroke=P["gold"], sw=5)
    a, s = PP(t, t0 + 0.1, S); block(c, "In my view:", 64, CX, 500, P["grey"], a, s, maxw=CW - 80)
    tn = tm(S, "not"); a, s = PP(t, tn, S); block(c, "Not colonizing.", 98, CX, 650, P["navy"], a, s, maxw=CW - 80, max_lines=1)
    k = ramp(t, tn + 0.5, tn + 0.9)
    if k > 0: box(c, CX - 370, 650, 740 * k, 12, 6, P["red"], a)
    tb = tm(S, "baby"); a, s = PP(t, tb - 0.4, S); block(c, "More like", 76, CX, 820, P["navy"], a, s, maxw=CW - 80)
    a, s = PP(t, tb, S, bounce=2.8); block(c, "*babysitting.*", 112, CX, 960, P["navy"], a, s, hl=P["blue"], maxw=CW - 60, max_lines=1)
    tp = tm(S, "pal"); a = fade_in(t, tp, S)
    block(c, S["note"], 52, CX, 1150, P["gold_text"], a, 1.0, w=800, maxw=CW - 100, max_lines=2)
    sources(c, t, S, [(t0, *S["src"])])

def sc_other(c, t, S):
    t0 = S["t0"]; a, s = PP(t, t0 + 0.05, S)
    block(c, S["head"], 76, CX, 330, P["navy"], a, s, hl=P["blue"], maxw=CW, max_lines=2)
    a, s = PP(t, t0 + 0.2, S); pill(c, "THE OTHER SIDE", 44, CX, 480, P["gold"], P["white"], a, s)
    y = 580
    for k, it in enumerate(S["items"]):
        ti = tm(S, f"i{k}", t0 + 0.3)
        if t < ti - 0.1: y += 290; continue
        a = fade_in(t, ti - 0.1, S, 0.25); dx = 200 * (1 - ease((t - ti + 0.1) / 0.35))
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, L, y, CW, 260, 30, P["card"], stroke=P["red"], sw=4, sh=6)
        T(c, it["tag"], 46, L + 40, y + 52, P["red"], 1.0, 1.0, 900, anchor="l", maxw=CW - 80)
        block(c, it["en"], 56, CX, y + 165, P["navy"], 1.0, 1.0, maxw=CW - 70, max_lines=2, lh=1.08)
        c.restore(); St.a = old; y += 290
    sources(c, t, S, [(tm(S, x["at"], t0), *x["lines"]) for x in S["sources"]])

def sc_loop(c, t, S):
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.02, S); block(c, "So,", 80, CX, 520, P["grey"], a, s)
    a, s = PP(t, t0 + 0.12, S); br = 1 + 0.015 * math.sin(t * 2.4)
    block(c, "Colonizers", 116, CX, 690, P["navy"], a, s * br, maxw=CW, max_lines=1)
    a, s = PP(t, tm(S, "baby", t0 + 0.6), S); block(c, "or *babysitters?*", 116, CX, 840, P["navy"], a, s * br, hl=P["blue"], maxw=CW, max_lines=1)
    w_ = ease((t - t0 - 0.3) / 0.8) if t > t0 + 0.3 else 0
    box(c, CX - 300 * w_, 925, 600 * w_, 12, 6, P["gold"], a)
    for k, (lab, cc) in enumerate(S["cols"]):
        a2, s2 = PP(t, t0 + 0.4 + 0.15 * k, S); pill(c, lab, 58, COLX[k], 1080, col(cc), P["white"], a2, s2, outline=P["white"], padx=0.5, padh=1.4)
    a = fade_in(t, t0 + 0.6, S); block(c, "You decide.", 60, CX, 1240, P["gold_text"], a, 1.0)
