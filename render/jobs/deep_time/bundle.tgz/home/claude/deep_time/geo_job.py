"""GitHub-side: fetch PALEOMAP palaeocoordinates (palaeoverse reconstruction files, Jones 2024, Zenodo 13798790,
CC BY 4.0; model PALEOMAP, Scotese & Wright 2018), keep present-day land cells (Natural Earth 1:50m, public domain),
and pack lon/lat per 1 Myr (0 to 260 Ma) losslessly into geo.mp4 for the container."""
import subprocess, sys, os, io, json, zlib, time
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "rdata", "pandas", "xarray"], check=True)
import numpy as np, requests, rdata
sys.path.insert(0, "/home/claude/deep_time"); from datapack import pack
URL = "https://zenodo.org/records/13798790/files/PALEOMAP.RDS?download=1"
for i in range(5):
    try:
        r = requests.get(URL, timeout=300); r.raise_for_status(); raw = r.content; break
    except Exception as e:
        print("retry", e); time.sleep(10)
print("downloaded", len(raw))
meta = requests.get("https://zenodo.org/api/records/13798790", timeout=60).json()
print("LICENSE", json.dumps(meta.get("metadata", {}).get("license")), "TITLE", meta.get("metadata", {}).get("title"), "DOI", meta.get("doi"))
parsed = rdata.parser.parse_data(raw)
obj = rdata.conversion.convert(parsed)
print("TYPE", type(obj))
import pandas as pd
df = obj if isinstance(obj, pd.DataFrame) else pd.DataFrame(obj)
print("SHAPE", df.shape); print("COLS", list(df.columns[:8]), "...", list(df.columns[-4:]))
print(df.iloc[:2, :8].to_string())
cols = list(df.columns)
low = [str(c).lower() for c in cols]
def find(*names):
    for n in names:
        for k, c in enumerate(low):
            if c == n: return cols[k]
lng0 = find("lng", "lon", "longitude", "plng"); lat0 = find("lat", "latitude", "plat")
print("present cols", lng0, lat0)
from shapely.geometry import shape; from shapely.ops import unary_union; import shapely
g = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
land = unary_union([shape(f["geometry"]).buffer(0) for f in g["features"]]); shapely.prepare(land)
x = df[lng0].to_numpy(float); y = df[lat0].to_numpy(float)
keep = shapely.contains_xy(land, x, y) | shapely.contains_xy(land.buffer(0.5), x, y)
print("cells", len(x), "land", int(keep.sum()))
# reconstructed columns: pairs per age; detect by numbers in the name
import re
ages = {}
for c in cols:
    m = re.search(r"(\d+(?:\.\d+)?)", str(c))
    if not m or c in (lng0, lat0): continue
    a = float(m.group(1)); s = str(c).lower()
    kind = "lng" if ("lng" in s or "lon" in s) else ("lat" if "lat" in s else None)
    if kind: ages.setdefault(a, {})[kind] = c
A = sorted(a for a in ages if "lng" in ages[a] and "lat" in ages[a] and a <= 260)
print("ages", len(A), A[:3], A[-3:])
L = np.stack([df[ages[a]["lng"]].to_numpy(float)[keep] for a in A]); B = np.stack([df[ages[a]["lat"]].to_numpy(float)[keep] for a in A])
enc = lambda v: np.where(np.isfinite(v), np.round(v * 100), -32768).astype("<i2")
buf = io.BytesIO()
np.savez(buf, ages=np.array(A, "f4"), lon0=x[keep].astype("f4"), lat0=y[keep].astype("f4"), lon=enc(L), lat=enc(B))
data = zlib.compress(buf.getvalue(), 9); print("packed bytes", len(data), "nan share", float(np.mean(~np.isfinite(L))))
os.makedirs("/home/claude/deep_time/out", exist_ok=True); pack(data, "/home/claude/deep_time/out/geo.mp4"); print("OK")
