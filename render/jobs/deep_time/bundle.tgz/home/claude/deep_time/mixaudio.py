"""Narration + 'journey' bed + SFX -> mix.m4a (-14 LUFS, -1.5 dBTP) for engine.py."""
import sys, subprocess, numpy as np
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/deep_time")
import mix, engine as E
SR = 48000
vo = mix.load("/home/claude/deep_time/vo.wav")
dur = E.T_TOTAL
def boom(d=1.6):
    n = int(d * SR); t = np.arange(n) / SR; rng = np.random.default_rng(3)
    x = np.sin(2 * np.pi * (55 - 25 * t) * t) * np.exp(-t * 2.6) + 0.5 * np.convolve(rng.normal(0, 1, n), np.ones(60) / 60, "same") * np.exp(-t * 4)
    return x / np.abs(x).max()
ev = [(E.Le(7) + 0.05, "whoosh", 0), (E.L(10) - 0.4, "whoosh", 0), (E.Le(12) + 0.05, "whoosh", 0), (E.L(14) - 0.35, "whoosh", 0),
      (E.wt(6, "asteroid") + 0.08, boom(), 4), (E.wt(15, "israel"), "ding", 0)]
for k, v in E.SITES.items(): ev.append((v[4], "pop", -2))
music = mix.bed("journey", dur)
mix.mix(vo, dur, music, ev, "/home/claude/deep_time/work_mix.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "/home/claude/deep_time/work_mix.wav", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "/home/claude/deep_time/mix.m4a"], check=True)
import os; os.remove("/home/claude/deep_time/work_mix.wav"); print("mix ok", dur)
