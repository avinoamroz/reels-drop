"""deep_time: deep-time globe race for @noamroz__ (1080x1920, 30 fps).
Continents: PALEOMAP (Scotese and Wright 2018) palaeocoordinates of present-day land cells, palaeoverse reconstruction files
(Jones 2024, Zenodo 13798790, CC BY 4.0), 1 Myr steps, interpolated per frame. Present-day land: Natural Earth 1:50m (public domain).
  python3 engine.py --stills 0,5,16 OUT.png     contact sheet of chosen times (local QA)
  python3 engine.py                             full render to out/deep_time.mp4 (GitHub)
"""
import json, math, os, sys, subprocess, functools, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = "/home/claude/deep_time"; W, H, FPS = 1080, 1920, 30
TM = json.load(open(f"{D}/timing.json")); WORDS = TM["words"]; LS = TM["lines"]
T_END = round(LS[-1][1] + 0.25, 2); T_TOTAL = T_END + 0.8          # last 0.8 s cross-fades into frame 0 (loop)
F_XB = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"; F_B = "/usr/share/fonts/opentype/inter/Inter-Bold.otf"
F_SB = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"; F_SUB = "/root/.fonts/Heebo-ExtraBold.ttf"
F_EMO = "/root/.fonts/NotoColorEmoji.ttf"
PHOTO = {"qafzeh": "/home/claude/reels-drop/photos/dt_qafzeh.jpg", "jericho": "/home/claude/reels-drop/photos/dt_jericho.jpg"}
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
NAVY0, NAVY1 = (0.035, 0.07, 0.16), (0.07, 0.14, 0.30)
SKY = (0x45 / 255, 0xA4 / 255, 0xDD / 255); YEL = (1.0, 0.82, 0.25); WHITE = (1, 1, 1)
GOLD = (0.83, 0.66, 0.25); GOLD_PS = (0x9E / 255, 0x7C / 255, 0x34 / 255); GREEN = (46 / 255, 204 / 255, 113 / 255)
CORAL = (1.0, 0.55, 0.42); AMBER = (1.0, 0.72, 0.30)

def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ss(x): x = clamp(x); return x * x * (3 - 2 * x)
def ramp(t, a, b): return ss((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u

# ---------------------------------------------------------------- timing helpers
LINES = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
_LW = []
k = 0
for l in LINES:
    n = len(l.split()); _LW.append(WORDS[k:k + n]); k += n
def L(i): return LS[i - 1][0]
def Le(i): return LS[i - 1][1]
def wt(i, word, end=False):
    for w in _LW[i - 1]:
        if re.sub(r"[^a-z]", "", w["w"].lower()).startswith(word.lower()): return w["e"] if end else w["s"]
    raise KeyError((i, word))

# ---------------------------------------------------------------- age timeline (years ago); log-eased between keys
AGE_K = [(0, 250e6), (L(2), 250e6), (L(3) + 0.2, 236e6), (wt(3, "dinosaurs"), 230e6), (L(4), 226e6), (Le(4) + 0.3, 180e6),
         (wt(5, "walks"), 100e6), (Le(5), 99e6), (L(6) + 0.2, 92e6), (wt(6, "asteroid"), 66e6), (Le(6), 65.5e6),
         (wt(7, "rises"), 20e6), (Le(7), 19.5e6), (L(8) + 1.2, 3e6), (L(9) + 0.4, 1.5e6), (Le(9), 1.5e6),
         (L(10) + 0.3, 790e3), (Le(10), 790e3), (L(11) + 0.3, 180e3), (Le(11), 180e3), (L(12) + 0.3, 100e3), (Le(12), 100e3),
         (L(13) + 0.1, 60e3), (L(14) - 0.15, 15e3), (L(14) + 0.3, 11e3), (wt(15, "about"), 11e3), (wt(15, "three", True), 3e3), (99, 3e3)]
def age(t):
    for (t0, a0), (t1, a1) in zip(AGE_K, AGE_K[1:]):
        if t <= t1:
            u = ss((t - t0) / max(1e-6, t1 - t0)); return math.exp(lerp(math.log(a0), math.log(a1), u))
    return AGE_K[-1][1]
def counter_text(a):
    if a >= 1e6:
        m = a / 1e6
        s = f"{round(m):,}" if m >= 9.95 else (f"{m:.1f}".rstrip("0").rstrip("."))
        return s, "million years ago"
    if a >= 20000: return f"{int(round(a / 1000.0) * 1000):,}", "years ago"
    return f"{int(round(a / 100.0) * 100):,}", "years ago"

# ---------------------------------------------------------------- continents
def to_v(lon, lat):
    lo, la = np.radians(lon), np.radians(lat)
    return np.stack([np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)], -1)
_g = np.load(f"{D}/geo/paleomap_land.npz")
AGES = _g["ages"]; assert AGES[0] == 1 and AGES[-1] == 260
lon0, lat0 = _g["lon0"].astype(np.float64), _g["lat0"].astype(np.float64)
_lon = np.vstack([np.round(lon0 * 100)[None], _g["lon"]]).astype(np.float64); _lat = np.vstack([np.round(lat0 * 100)[None], _g["lat"]]).astype(np.float64)
VALID = (_lon != -32768) & (_lat != -32768)
V = to_v(_lon / 100, _lat / 100).astype(np.float32)             # (261, N, 3), index = Ma
ISR = np.where((lon0 > 34) & (lon0 < 35.95) & (lat0 > 29.4) & (lat0 < 33.4))[0]
def cells(a_years):
    a = clamp(a_years / 1e6, 0, 259.999); i = int(a); f = a - i
    v = V[i] * (1 - f) + V[i + 1] * f; ok = VALID[i] & VALID[i + 1]
    v = v / np.linalg.norm(v, axis=1, keepdims=True); return v, ok
def isr_center(a_years):
    v, _ = cells(a_years); c = v[ISR].mean(0); c /= np.linalg.norm(c)
    return math.degrees(math.atan2(c[1], c[0])), math.degrees(math.asin(c[2]))

# ---------------------------------------------------------------- camera (orthographic globe)
GC = (540, 900); R0 = 450
def basis(lon, lat):
    c = to_v(lon, lat); e = np.array([-math.sin(math.radians(lon)), math.cos(math.radians(lon)), 0.0]); n = np.cross(c, e)
    return c, e, n
def slerp_ll(a, b, u):
    va, vb = to_v(*a), to_v(*b); w = math.acos(clamp(float(va @ vb), -1, 1))
    v = va if w < 1e-6 else (math.sin((1 - u) * w) * va + math.sin(u * w) * vb) / math.sin(w)
    return math.degrees(math.atan2(v[1], v[0])), math.degrees(math.asin(clamp(v[2], -1, 1)))
def cam_globe(t):
    a = age(t); lo, la = isr_center(a); off = -28 * ramp(math.log(a), math.log(66e6), math.log(200e6))
    return (lo + off, clamp(la + 12, -40, 40), R0)
Z1 = (36.0, 22.0, 900.0); Z2 = (35.28, 32.72, 15500.0); Z3 = (48.0, 24.0, 430.0); Z4 = (35.15, 31.55, 10500.0)
CAMK = [(L(8) - 0.1, None), (L(9) + 0.6, Z1), (L(10) - 0.35, Z1), (L(10) + 1.1, Z2), (Le(12) + 0.05, Z2),
        (L(13) + 0.9, Z3), (L(14) - 0.3, Z3), (L(14) + 1.2, Z4)]
def cam(t):
    if t <= CAMK[0][0]: return cam_globe(t)
    for (t0, c0), (t1, c1) in zip(CAMK, CAMK[1:]):
        if t <= t1:
            c0 = c0 or cam_globe(t0); c1 = c1 or cam_globe(t1); u = ss((t - t0) / max(1e-6, t1 - t0))
            lo, la = slerp_ll(c0[:2], c1[:2], u); return (lo, la, math.exp(lerp(math.log(c0[2]), math.log(c1[2]), u)))
    lo, la, r = CAMK[-1][1]; return (lo, la, r * (1 + 0.05 * ss((t - CAMK[-1][0]) / 10)))
class Proj:
    def __init__(s, c):
        s.lon, s.lat, s.R = c; s.c, s.e, s.n = basis(s.lon, s.lat)
    def xy(s, v):
        v = np.asarray(v, np.float64); return GC[0] + s.R * (v @ s.e), GC[1] - s.R * (v @ s.n), v @ s.c
    def ll(s, lon, lat):
        x, y, z = s.xy(to_v(lon, lat)); return float(x), float(y), float(z)

# ---------------------------------------------------------------- vector land (present day)
def _load_geo():
    from shapely.geometry import shape
    out = []
    for f in json.load(open(GEO))["features"]:
        p = f["properties"]; iso = p.get("ISO_A2"); g = shape(f["geometry"])
        polys = [g] if g.geom_type == "Polygon" else list(g.geoms)
        rings = []
        for pg in polys:
            pg = pg.simplify(0.02)
            if pg.is_empty: continue
            xy = np.array(pg.exterior.coords); rings.append(to_v(xy[:, 0], xy[:, 1]))
        b = g.bounds; out.append(dict(iso=iso, rings=rings, ctr=to_v((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), geom=g))
    return out
LAND = _load_geo()
PS_RINGS = [r for c in LAND if c["iso"] == "PS" for r in c["rings"]]

# ---------------------------------------------------------------- text
@functools.lru_cache(maxsize=4096)
def _font(path, size): return ImageFont.truetype(path, size)
def _pil_to_surface(im):
    a = np.array(im.convert("RGBA"), np.uint8); al = a[..., 3:4].astype(np.uint16)
    pm = (a[..., :3].astype(np.uint16) * al // 255).astype(np.uint8)
    bgra = np.concatenate([pm[..., 2:3], pm[..., 1:2], pm[..., 0:1], a[..., 3:4]], -1).copy()
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, im.width, im.height); st = s.get_stride()
    buf = np.ndarray((im.height, st // 4, 4), np.uint8, s.get_data()); buf[:, :im.width] = bgra; s.mark_dirty(); return s
@functools.lru_cache(maxsize=2048)
def text_surf(s, size, path=F_XB, color=WHITE, track=0):
    f = _font(path, size); b = f.getbbox(s); w = int(f.getlength(s) + track * len(s)) + 8; h = int(size * 1.35)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im); col = tuple(int(c * 255) for c in color) + (255,)
    if track:
        x = 4
        for ch in s: d.text((x, size * 0.12), ch, font=f, fill=col); x += f.getlength(ch) + track
    else: d.text((4, size * 0.12), s, font=f, fill=col)
    return _pil_to_surface(im)
@functools.lru_cache(maxsize=64)
def emoji_surf(e, size):
    f = _font(F_EMO, 109); im = Image.new("RGBA", (150, 150), (0, 0, 0, 0)); ImageDraw.Draw(im).text((10, 10), e, font=f, embedded_color=True)
    bb = im.getbbox(); im = im.crop(bb); sc = size / max(im.size); im = im.resize((max(1, int(im.width * sc)), max(1, int(im.height * sc))), Image.LANCZOS)
    return _pil_to_surface(im)
def blit(c, s, x, y, a=1.0, anchor="c", scale=1.0):
    if a <= 0.005: return
    w, h = s.get_width() * scale, s.get_height() * scale
    x0 = x - w / 2 if anchor == "c" else (x if anchor == "l" else x - w)
    c.save(); c.translate(x0, y - h / 2); c.scale(scale, scale); c.set_source_surface(s, 0, 0); c.paint_with_alpha(a); c.restore()
def text(c, s, size, x, y, color=WHITE, a=1.0, path=F_XB, anchor="c", maxw=960, track=0):
    sf = text_surf(s, size, path, color, track); sc = min(1.0, maxw / sf.get_width()); blit(c, sf, x, y, a, anchor, sc)
    return sf.get_width() * sc
def tw(s, size, path=F_XB): return _font(path, size).getlength(s)
def rrect(c, x, y, w, h, r):
    c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def wrap(s, size, maxw, path=F_SB):
    out, cur = [], ""
    for w_ in s.split():
        tr = (cur + " " + w_).strip()
        if tw(tr, size, path) <= maxw or not cur: cur = tr
        else: out.append(cur); cur = w_
    return out + [cur]
def pill(c, lines, x, y, a, anchor="c", border=SKY):
    """lines: [(text, size, color, path)]; x,y = anchor point (centre / left-middle / right-middle)"""
    if a <= 0.01: return None
    ws = [tw(t, s, p) for t, s, _, p in lines]; hs = [s * 1.22 for _, s, _, _ in lines]
    w = max(ws) + 56; h = sum(hs) + 30; x0 = x - w / 2 if anchor == "c" else (x if anchor == "l" else x - w); y0 = y - h / 2
    x0 = clamp(x0, 40, W - 40 - w)
    c.save(); rrect(c, x0, y0 + 6, w, h, 26); c.set_source_rgba(0, 0, 0, 0.35 * a); c.fill()
    rrect(c, x0, y0, w, h, 26); c.set_source_rgba(0.05, 0.10, 0.22, 0.92 * a); c.fill_preserve()
    c.set_source_rgba(*border, a); c.set_line_width(3.5); c.stroke(); c.restore()
    yy = y0 + 15
    for (t, s, col, p), hh in zip(lines, hs):
        text(c, t, s, x0 + w / 2, yy + hh / 2, col, a, p); yy += hh
    return (x0, y0, w, h)

# ---------------------------------------------------------------- scene data
LABELS = [  # (t_on, emoji, name): "who lived here"
    (L(1) + 2.55, "\U0001F98E", "Nobody you know"), (wt(3, "dinosaurs"), "\U0001F996", "Dinosaurs"),
    (wt(6, "asteroid"), "☄️", "The asteroid"), (wt(6, "game") + 0.6, "\U0001F418", "Mammals"),
    (wt(9, "early"), "\U0001F9CD", "Early humans"), (wt(11, "modern"), "\U0001F9CD", "Modern humans"),
    (wt(13, "spread"), "\U0001F30D", "Humans, everywhere"), (wt(14, "jericho"), "\U0001F3D8️", "The first towns"),
    (wt(15, "israel"), "\U0001F1EE\U0001F1F1", "Israel")]
SRC = [  # (t_on, t_off, text)
    (0, L(5) - 0.2, "Continents: PALEOMAP plate model (Scotese and Wright 2018), via palaeoverse (Jones 2024), CC BY 4.0"),
    (L(5) - 0.2, L(6) - 0.2, "Footprints: Avnimelech 1962, Nature (Beit Zayit, Cretaceous)"),
    (L(6) - 0.2, L(7) - 0.2, "Chicxulub impact: Renne et al. 2013, Science"),
    (L(7) - 0.2, L(9) - 0.2, "Land bridge: Straume et al. 2025, Nature Reviews Earth and Environment"),
    (L(9) - 0.2, L(10) - 0.2, "Ubeidiya: about 1.5 million years old (Archaeology, AIA, 2022)"),
    (L(10) - 0.2, L(11) - 0.2, "Fire: Goren-Inbar et al. 2004, Science"),
    (L(11) - 0.2, L(12) - 0.2, "Misliya jaw, 177,000 to 194,000 years: Hershkovitz et al. 2018, Science"),
    (L(12) - 0.2, L(13) - 0.2, "Qafzeh burials, about 100,000 years: Smithsonian Human Origins. Photo: Wapondaponda, CC BY-SA 3.0"),
    (L(13) - 0.2, L(14) - 0.2, "Routes: Lopez, van Dorp and Hellenthal 2015, Evolutionary Bioinformatics"),
    (L(14) - 0.2, L(15) - 0.2, "Jericho, settled about 10,000 BCE. Photo: Reinhard Dietrich, public domain"),
    (L(15) - 0.2, 999, "First mention of Israel: Merneptah Stele, about 1208 BCE. Map: Natural Earth")]
SITES = {  # name: (lon, lat, title, detail, t_on, t_off, side, dy)
    "ubeidiya": (35.56, 32.69, "Ubeidiya", "1.5 million years ago", wt(9, "early"), Le(12) + 0.1, "r", 770),
    "gby": (35.63, 33.01, "Gesher Benot Ya'aqov", "Fire, 790,000 years ago", wt(10, "fire"), Le(12) + 0.1, "r", 580),
    "misliya": (34.99, 32.73, "Misliya Cave", "Oldest modern human jaw|outside Africa", wt(11, "mount"), Le(12) + 0.1, "l", 790),
    "qafzeh": (35.32, 32.69, "Qafzeh", "Graves, 100,000 years ago", wt(12, "some"), Le(12) + 0.1, "r", 975),
    "skhul": (34.97, 32.67, "Skhul", "Graves, 100,000 years ago", wt(12, "graves"), Le(12) + 0.1, "l", 975),
    "jericho": (35.44, 31.87, "Jericho", "One of the first towns", wt(14, "jericho"), L(15) + 1.0, "r", 760)}
ERECTUS = [(36.0, -3.0), (38.5, 8.0), (33.5, 24.0), (35.56, 32.69)]
SAPIENS = [[(38, 8), (43.4, 12.6), (52, 18), (60, 24), (75, 20), (95, 18), (105, 10), (115, -3), (133, -23)],
           [(33, 25), (35, 31), (38, 37), (30, 42), (20, 46), (5, 47), (-3, 42)],
           [(60, 24), (70, 40), (90, 47), (110, 52), (135, 62), (170, 66), (-165, 65), (-150, 62), (-120, 52), (-100, 40), (-80, 10), (-65, -15)],
           [(105, 10), (115, 25), (120, 35), (130, 40)]]
def gc_path(pts, n=24):
    out = []
    for a, b in zip(pts, pts[1:]):
        for k in range(n): out.append(to_v(*slerp_ll(a, b, k / n)))
    out.append(to_v(*pts[-1])); return np.array(out)
ERECTUS_P = gc_path(ERECTUS); SAPIENS_P = [gc_path(p) for p in SAPIENS]
SUBS = [  # per script line: (display text, spoken word count)
    "L1", [("250 million years ago,", 7), ("no Israel. Just Pangaea.", 4)], [("The first locals?", 3), ("Technically... dinosaurs.", 2)],
    [("Then Pangaea starts to crack.", 5)], [("100 million years ago,", 5), ("a dinosaur walks near Jerusalem.", 5), ("Its footprints turn up in a garden.", 7)],
    [("66 million years ago:", 4), ("the asteroid. Game over.", 4)], [("Then Arabia breaks off Africa,", 5), ("crashes into Asia,", 3), ("and a land bridge rises, right here.", 7)],
    [("The hallway out of Africa.", 5)], [("1.5 million years ago,", 7), ("early humans walk through it.", 5)],
    [("790,000 years ago:", 7), ("fire, by the Jordan.", 4)], [("180,000 years ago, Mount Carmel:", 9), ("the oldest modern human jaw", 5), ("outside Africa.", 2)],
    [("100,000 years ago:", 5), ("some of the oldest graves on Earth.", 7)], [("Then humans spread across the planet.", 6)],
    [("11,000 years ago: Jericho,", 5), ("one of the first towns.", 5)],
    [("About 3,000 years ago,", 5), ("a new name appears here: Israel.", 6), ("And everyone argues about one question.", 6)]]
SUB_T = []
for i, chunks in enumerate(SUBS):
    ws = _LW[i]; k = 0
    if chunks == "L1": SUB_T.append([ws[4]["s"], ws[5]["e"], "Really first?"]); continue
    assert sum(n for _, n in chunks) in (0, len(ws)), (i + 1, sum(n for _, n in chunks), len(ws))
    for txt_, n in chunks: SUB_T.append([ws[k]["s"], ws[k + n - 1]["e"], txt_]); k += n
for a, b in zip(SUB_T, SUB_T[1:]): a[1] = min(b[0], max(a[1] + 0.35, a[1]))

# ---------------------------------------------------------------- drawing
_bg = None
def background(c):
    global _bg
    if _bg is None:
        _bg = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); b = cairo.Context(_bg)
        g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *NAVY0); g.add_color_stop_rgb(0.5, *NAVY1); g.add_color_stop_rgb(1, *NAVY0)
        b.set_source(g); b.paint()
        rng = np.random.default_rng(7)
        for _ in range(160):
            b.arc(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(0.6, 1.6), 0, 2 * math.pi); b.set_source_rgba(1, 1, 1, rng.uniform(0.08, 0.3)); b.fill()
    c.set_source_surface(_bg, 0, 0); c.paint()

def draw_land(c, pr, a):
    """present-day vector land, orthographic; Israel gold, Judea/Samaria and Gaza darker gold, Green Line green"""
    if a <= 0.01: return
    def path(r):
        x, y, z = pr.xy(r)
        if (z < 0.02).all(): return False
        keep = z > 0.02; x, y = np.where(keep, x, np.nan), np.where(keep, y, np.nan)
        started = False
        for xi, yi in zip(x, y):
            if np.isnan(xi): continue
            if not started: c.move_to(xi, yi); started = True
            else: c.line_to(xi, yi)
        c.close_path(); return started
    lw = clamp(pr.R / 9000, 0.8, 2.2)
    for cty in LAND:
        if float(cty["ctr"] @ pr.c) < 0.35 and pr.R > 1200: continue
        col = GOLD if cty["iso"] == "IL" else (GOLD_PS if cty["iso"] == "PS" else (0.20, 0.39, 0.64))
        any_ = False
        for r in cty["rings"]: any_ = path(r) or any_
        if not any_: c.new_path(); continue
        c.set_source_rgba(*col, a); c.fill_preserve(); c.set_source_rgba(0.30, 0.52, 0.78, 0.7 * a); c.set_line_width(lw); c.stroke()
    if pr.R > 2500:
        for r in PS_RINGS: path(r)
        c.set_source_rgba(*GREEN, a); c.set_line_width(5); c.set_dash([14, 8]); c.stroke(); c.set_dash([])

def draw_arrow(c, pr, P, u, col, a, width=7):
    if u <= 0 or a <= 0.01: return
    n = max(2, int(len(P) * clamp(u)))
    x, y, z = pr.xy(P[:n]); vis = z > 0.03
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for lw_, al in ((width * 2.6, 0.18), (width, 1.0)):
        started = False
        for i in range(n):
            if not vis[i]: started = False; continue
            if not started: c.move_to(x[i], y[i]); started = True
            else: c.line_to(x[i], y[i])
        c.set_source_rgba(*col, a * al); c.set_line_width(lw_); c.stroke()
    if vis[-1] and n >= 2:
        dx, dy = x[-1] - x[-2], y[-1] - y[-2]; L_ = math.hypot(dx, dy) or 1; dx, dy = dx / L_, dy / L_; s = width * 3.2
        c.move_to(x[-1] + dx * s, y[-1] + dy * s); c.line_to(x[-1] - dy * s * 0.8, y[-1] + dx * s * 0.8); c.line_to(x[-1] + dy * s * 0.8, y[-1] - dx * s * 0.8)
        c.close_path(); c.set_source_rgba(*col, a); c.fill()

def pin(c, x, y, a, col=YEL, pulse=0.0):
    if a <= 0.01: return
    if pulse > 0:
        c.arc(x, y, 14 + 40 * pulse, 0, 2 * math.pi); c.set_source_rgba(*col, a * (1 - pulse) * 0.7); c.set_line_width(4); c.stroke()
    c.arc(x, y, 15, 0, 2 * math.pi); c.set_source_rgba(0.05, 0.1, 0.22, a); c.fill()
    c.arc(x, y, 11, 0, 2 * math.pi); c.set_source_rgba(*col, a); c.fill()

def photo(c, key, x, y, w, h, a, t0, t):
    if a <= 0.01: return
    s = _photo(key, int(w * 1.12), int(h * 1.12)); z = 1.0 + 0.06 * clamp((t - t0) / 4)
    c.save(); rrect(c, x, y + 8, w, h, 28); c.set_source_rgba(0, 0, 0, 0.4 * a); c.fill()
    rrect(c, x, y, w, h, 28); c.clip(); c.translate(x + w / 2, y + h / 2); c.scale(z, z)
    c.set_source_surface(s, -s.get_width() / 2, -s.get_height() / 2); c.paint_with_alpha(a); c.restore()
    c.save(); rrect(c, x, y, w, h, 28); c.set_source_rgba(1, 1, 1, 0.9 * a); c.set_line_width(4); c.stroke(); c.restore()
@functools.lru_cache(maxsize=8)
def _photo(key, w, h):
    im = Image.open(PHOTO[key]).convert("RGB"); sc = max(w / im.width, h / im.height)
    im = im.resize((int(im.width * sc) + 1, int(im.height * sc) + 1), Image.LANCZOS)
    l, t_ = (im.width - w) // 2, (im.height - h) // 2; return _pil_to_surface(im.crop((l, t_, l + w, t_ + h)))

def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s); background(c)
    a_y = age(t); pr = Proj(cam(t)); R = pr.R
    # ocean
    if R < 1400:
        g = cairo.RadialGradient(GC[0] - R * 0.3, GC[1] - R * 0.35, R * 0.1, GC[0], GC[1], R)
        g.add_color_stop_rgb(0, 0.10, 0.22, 0.45); g.add_color_stop_rgb(1, 0.04, 0.10, 0.24)
        c.arc(GC[0], GC[1], R + 26, 0, 2 * math.pi); c.set_source_rgba(*SKY, 0.07); c.fill()
        c.arc(GC[0], GC[1], R + 10, 0, 2 * math.pi); c.set_source_rgba(*SKY, 0.12); c.fill()
        c.arc(GC[0], GC[1], R, 0, 2 * math.pi); c.set_source(g); c.fill()
    else:
        u = ramp(R, 1400, 2600); c.set_source_rgba(0.05, 0.12, 0.27, u); c.paint()
    # dots
    vec_a = ramp(R, 820, 2400) * (1.0 if a_y < 4e6 else 0.0)
    dot_a = 1.0 - ramp(R, 1100, 2600)
    c.save(); c.arc(GC[0], GC[1], max(R, 1), 0, 2 * math.pi); c.clip()
    if vec_a > 0: draw_land(c, pr, vec_a)
    if dot_a > 0.01:
        v, ok = cells(a_y); x, y, z = pr.xy(v); m = ok & (z > 0.0) & (x > -20) & (x < W + 20) & (y > -20) & (y < H + 20)
        rad = clamp(R / 410 * 2.7, 2.7, 6.0)
        isr = np.zeros(len(v), bool); isr[ISR] = True
        for sel, col, rr in ((m & ~isr, SKY, rad), (m & isr, GOLD, rad * 1.6)):
            zz = z[sel]; xs, ys = x[sel], y[sel]
            for lo, hi in ((0, 0.25), (0.25, 0.55), (0.55, 1.01)):
                b = (zz >= lo) & (zz < hi)
                if not b.any(): continue
                al = dot_a * (0.35 + 0.65 * math.sqrt((lo + hi) / 2)) * (1 - 0.6 * vec_a if col is SKY else 1)
                for xi, yi in zip(xs[b], ys[b]): c.arc(xi, yi, rr, 0, 2 * math.pi); c.new_sub_path()
                c.set_source_rgba(*col, al); c.fill()
    c.restore()
    # Israel marker on the globe
    lo_i, la_i = isr_center(a_y); xi, yi, zi = pr.ll(lo_i, la_i)
    ring_a = ramp(t, L(2) - 0.2, L(2) + 0.3) * (1 - ramp(t, L(8) + 1.0, L(9) + 0.2))
    if ring_a > 0 and zi > 0:
        ph = (t * 0.8) % 1.0
        c.arc(xi, yi, 26 + 26 * ph, 0, 2 * math.pi); c.set_source_rgba(*YEL, ring_a * (1 - ph) * 0.8); c.set_line_width(4); c.stroke()
        c.arc(xi, yi, 24, 0, 2 * math.pi); c.set_source_rgba(*YEL, ring_a); c.set_line_width(4); c.stroke()
        a1 = ramp(t, L(2) + 0.3, L(2) + 0.7) * (1 - ramp(t, L(5) - 0.4, L(5)))
        pill(c, [("Israel, today", 46, WHITE, F_B)], xi, yi - 92, a1 * ring_a)
        a2 = ramp(t, wt(5, "walks"), wt(5, "walks") + 0.4) * (1 - ramp(t, Le(5) + 0.2, L(6)))
        pill(c, [("Dinosaur footprints", 50, YEL, F_XB), ("Beit Zayit, near Jerusalem", 40, WHITE, F_SB)], xi, yi - 115, a2 * ring_a)
        a3 = ramp(t, wt(7, "land"), wt(7, "land") + 0.4) * (1 - ramp(t, L(8) + 0.6, L(8) + 1.0))
        pill(c, [("Africa meets Asia", 50, YEL, F_XB), ("about 20 million years ago", 40, WHITE, F_SB)], xi, yi - 115, a3 * ring_a)
    # asteroid
    ta = wt(6, "asteroid")
    if ta - 0.7 < t < ta + 0.1:
        u = (t - (ta - 0.7)) / 0.8; x0_, y0_ = 80, 420; x1_, y1_ = GC[0] - R * 0.55, GC[1] - R * 0.15
        hx, hy = lerp(x0_, x1_, u), lerp(y0_, y1_, u)
        g = cairo.LinearGradient(hx - 260 * (x1_ - x0_) / 900, hy - 260 * (y1_ - y0_) / 900, hx, hy); g.add_color_stop_rgba(0, 1, 0.8, 0.5, 0); g.add_color_stop_rgba(1, 1, 0.95, 0.8, 1)
        c.move_to(hx - 260 * (x1_ - x0_) / 900, hy - 260 * (y1_ - y0_) / 900); c.line_to(hx, hy); c.set_source(g); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
        c.arc(hx, hy, 9, 0, 2 * math.pi); c.set_source_rgb(1, 1, 0.9); c.fill()
    fl = clamp(1 - (t - ta - 0.1) / 0.7) if t >= ta + 0.1 else 0
    # arrows
    ae = ramp(t, wt(9, "early") - 0.2, Le(9) + 0.2) ; aea = 1 - ramp(t, L(10) + 0.2, L(10) + 0.8)
    draw_arrow(c, pr, ERECTUS_P, ae, AMBER, aea, 9)
    for k_, P in enumerate(SAPIENS_P):
        u = ramp(t, L(13) + 0.1 + 0.25 * k_, L(14) + 0.2 + 0.2 * k_); draw_arrow(c, pr, P, u, CORAL, 1 - ramp(t, L(14) + 0.4, L(14) + 1.0), 8)
    # site pins and labels (zoomed)
    for key, (lo, la, ttl, det, t0, t1, side, dy) in SITES.items():
        a = ramp(t, t0 - 0.05, t0 + 0.3) * (1 - ramp(t, t1, t1 + 0.4))
        if a <= 0.01: continue
        x, y, z = pr.ll(lo, la)
        if z <= 0 or not (-50 < x < W + 50): continue
        newest = max((v_[4] for v_ in SITES.values() if v_[4] <= t), default=t0)
        dim = 1.0 if t0 >= newest - 0.01 or key == "jericho" else 0.55
        pin(c, x, y, a, YEL, clamp((t - t0) / 0.8) if t - t0 < 0.8 else 0)
        if R < 5000: continue
        ly = dy; lx = 1040 if side == "r" else 40
        bx = pill(c, [(ttl, 50, YEL if dim == 1 else WHITE, F_XB)] + [(d_, 38, WHITE, F_SB) for d_ in det.split("|")], lx, ly, a * dim, "r" if side == "r" else "l",
                  border=SKY if dim == 1 else (0.3, 0.45, 0.65))
        if bx:
            ex = bx[0] if side == "r" else bx[0] + bx[2]
            c.move_to(x, y); c.line_to(ex, ly); c.set_source_rgba(*YEL, 0.8 * a * dim); c.set_line_width(3); c.stroke()
    # photos
    aq = ramp(t, wt(12, "some"), wt(12, "some") + 0.4) * (1 - ramp(t, Le(12), Le(12) + 0.35))
    photo(c, "qafzeh", 330, 1070, 420, 270, aq, wt(12, "some"), t)
    aj = ramp(t, wt(14, "jericho") + 0.2, wt(14, "jericho") + 0.6) * (1 - ramp(t, L(15) + 0.6, L(15) + 1.0))
    photo(c, "jericho", 330, 1010, 420, 300, aj, wt(14, "jericho"), t)
    # Israel name at the end
    ai = ramp(t, wt(15, "israel"), wt(15, "israel") + 0.4)
    if ai > 0:
        pill(c, [("ISRAEL", 64, YEL, F_XB), ("first named about 1208 BCE", 38, WHITE, F_SB)], 250, 760, ai)
    # top and bottom shade for legibility on full-screen maps
    shade = ramp(R, 480, 900)
    if shade > 0:
        g = cairo.LinearGradient(0, 0, 0, 560); g.add_color_stop_rgba(0, *NAVY0, 0.95 * shade); g.add_color_stop_rgba(1, *NAVY0, 0)
        c.rectangle(0, 0, W, 560); c.set_source(g); c.fill()
        g = cairo.LinearGradient(0, 1240, 0, H); g.add_color_stop_rgba(0, *NAVY0, 0); g.add_color_stop_rgba(0.35, *NAVY0, 0.9 * shade); g.add_color_stop_rgba(1, *NAVY0, 0.97 * shade)
        c.rectangle(0, 1240, W, H - 1240); c.set_source(g); c.fill()
    # header: hook, then "who lived here" label
    hk = 1 - ramp(t, L(1) + 2.45, L(1) + 2.85)
    if hk > 0:
        text(c, "Who was here", 120, 540, 272, WHITE, hk); text(c, "first?", 130, 540, 392, SKY, hk)
    cur = None
    for k_, (t0, em, nm) in enumerate(LABELS):
        if t >= t0: cur = k_
    if cur is not None:
        t0, em, nm = LABELS[cur]; a = ramp(t, t0, t0 + 0.35) * (1 - hk)
        text(c, "WHO LIVED HERE?", 40, 540, 262, SKY, a, F_B, track=4)
        wn = tw(nm, 92); es = emoji_surf(em, 92); tot = es.get_width() + 24 + wn; x0 = 540 - tot / 2
        dy = 18 * (1 - ss((t - t0) / 0.35))
        blit(c, es, x0 + es.get_width() / 2, 375 + dy, a); text(c, nm, 92, x0 + es.get_width() + 24 + wn / 2, 378 + dy, WHITE, a, maxw=960)
        if cur > 0 and t - t0 < 0.35:
            p0, pe, pn = LABELS[cur - 1]; ap = 1 - ramp(t, t0, t0 + 0.3)
            pass
    # counter
    num, unit = counter_text(a_y)
    text(c, num, 200, 540, 1386, YEL, 1.0, F_XB); text(c, unit, 56, 540, 1532, WHITE, 0.92, F_SB)
    # source label
    for t0, t1, s_ in SRC:
        a = ramp(t, t0 + 0.22, t0 + 0.45) * (1 - ramp(t, t1, t1 + 0.2))
        if a > 0.01:
            ls = wrap(s_, 36, 960)
            for j, l in enumerate(ls): text(c, l, 36, 540, 1600 + j * 42 - (len(ls) - 1) * 21 + 0, (0.80, 0.86, 0.95), a, F_SB)
    # subtitles
    for t0, t1, s_ in SUB_T:
        if t0 - 0.05 <= t < t1 + 0.05:
            a = ramp(t, t0 - 0.05, t0 + 0.05) * (1 - ramp(t, t1, t1 + 0.05))
            ls = wrap(s_, 54, 900, F_SUB); lh = 66; hh = len(ls) * lh + 26; ww = max(tw(l, 54, F_SUB) for l in ls) + 56; y0 = 1700 - hh / 2
            rrect(c, 540 - ww / 2, y0, ww, hh, 22); c.set_source_rgba(0.02, 0.05, 0.12, 0.82 * a); c.fill()
            for j, l in enumerate(ls): text(c, l, 54, 540, y0 + 13 + lh / 2 + j * lh, WHITE, a, F_SUB)
    # flash
    if fl > 0: c.set_source_rgba(1, 0.97, 0.9, 0.75 * fl); c.paint()
    return s

def render_t(t):
    if t > T_END:
        u = ss((t - T_END) / (T_TOTAL - T_END)); s1 = frame(min(t, T_END)); s0 = frame(0.0)
        c = cairo.Context(s1); c.set_source_surface(s0, 0, 0); c.paint_with_alpha(u); return s1
    return frame(t)

def contact(ts, out):
    ims = []
    for t in ts:
        s = render_t(t); a = np.ndarray((H, W, 4), np.uint8, s.get_data())[..., [2, 1, 0]].copy()
        im = Image.fromarray(a).resize((360, 640), Image.LANCZOS); d = ImageDraw.Draw(im); d.text((8, 8), f"{t:.1f}s", fill=(255, 80, 80)); ims.append(im)
    cols = min(6, len(ims)); rows = -(-len(ims) // cols); sheet = Image.new("RGB", (cols * 360, rows * 640))
    for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * 360, (i // cols) * 640))
    sheet.save(out)

def seg_render(args):
    k, n_seg, out = args
    nf = int(round(T_TOTAL * FPS)); fr = range(k * nf // n_seg, (k + 1) * nf // n_seg)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", out], stdin=subprocess.PIPE)
    for f in fr:
        s = render_t(f / FPS); p.stdin.write(bytes(s.get_data()))
    p.stdin.close(); p.wait(); return out

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--stills":
        contact([float(x) for x in sys.argv[2].split(",")], sys.argv[3]); sys.exit()
    from multiprocessing import Pool
    os.makedirs(f"{D}/out", exist_ok=True); n = 4
    segs = [f"{D}/out/seg{k}.mp4" for k in range(n)]
    with Pool(n) as pool: pool.map(seg_render, [(k, n, segs[k]) for k in range(n)])
    open(f"{D}/out/segs.txt", "w").write("".join(f"file '{s}'\n" for s in segs))
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"{D}/out/segs.txt", "-i", f"{D}/mix.m4a",
                    "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "copy", "-t", f"{T_TOTAL:.3f}", "-movflags", "+faststart", f"{D}/out/deep_time.mp4"], check=True)
    for s_ in segs: os.remove(s_)
    print("done", T_TOTAL)
