"""House voice chain on the Cartesia clip: rubberband pitch 0.9715 (formants kept), bass g=2 f=135, clean_vo, atempo 1.1, 0.3 s lead.
Writes vo.wav (48 kHz mono) and timing.json (words and line spans in reel time)."""
import json, os, re, subprocess, shutil, sys
D = "/home/claude/deep_time"; SRC = "/home/claude/reels-drop/voice/deep_time.wav"; WJ = "/home/claude/reels-drop/voice/deep_time_words.json"
TEMPO, LEAD = 1.1, 0.3
tmp = f"{D}/work"; os.makedirs(f"{tmp}/a", exist_ok=True); os.makedirs(f"{tmp}/b", exist_ok=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", SRC, "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135", "-ar", "48000", "-ac", "1", f"{tmp}/a/vo.wav"], check=True)
subprocess.run(["python3", "/home/claude/reelkit/clean_vo.py", f"{tmp}/a", f"{tmp}/b"], check=True, capture_output=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{tmp}/b/vo.wav", "-af", f"atempo={TEMPO},adelay={int(LEAD*1000)}", "-ar", "48000", "-ac", "1", f"{D}/vo.wav"], check=True)
shutil.rmtree(tmp)
W = json.load(open(WJ)); lines = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
words = [dict(w=x["word"], s=x["start"] / TEMPO + LEAD, e=x["end"] / TEMPO + LEAD) for x in W]
norm = lambda s: re.sub(r"[^a-z0-9']", "", s.lower())
spans, k = [], 0
for l in lines:
    n = len(l.split()); seg = words[k:k + n]
    assert [norm(x["w"]) for x in seg] == [norm(x) for x in l.split()], (l, [x["w"] for x in seg])
    spans.append([round(seg[0]["s"], 3), round(seg[-1]["e"], 3)]); k += n
assert k == len(words)
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f"{D}/vo.wav"], capture_output=True, text=True).stdout)
json.dump(dict(words=words, lines=spans, vo_dur=dur), open(f"{D}/timing.json", "w"), indent=0)
for i, (l, s) in enumerate(zip(lines, spans), 1): print(i, s, l[:60])
print("vo", dur)
