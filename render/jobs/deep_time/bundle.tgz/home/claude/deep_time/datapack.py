"""Pack bytes into a lossless rgb mp4 (libx264rgb qp 0) and back. Used to bring GitHub-side data home."""
import subprocess, struct, numpy as np, sys
W, H = 1080, 1920
def pack(data: bytes, out):
    b = struct.pack("<Q", len(data)) + data
    fr = W * H * 3; n = -(-len(b) // fr); b = b + bytes(n * fr - len(b))
    p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", "1", "-i", "-",
                        "-c:v", "libx264rgb", "-qp", "0", "-preset", "ultrafast", out], input=b, check=True)
def unpack(path) -> bytes:
    b = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True).stdout
    n = struct.unpack("<Q", b[:8])[0]; return b[8:8 + n]
if __name__ == "__main__":
    import os, zlib
    d = zlib.compress(np.random.randint(-30000, 30000, 3_000_000).astype("<i2").tobytes() + b"end")
    pack(d, "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/dt/t.mp4")
    e = unpack("/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/dt/t.mp4"); print("roundtrip", e == d, len(d), os.path.getsize("/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/dt/t.mp4"))
