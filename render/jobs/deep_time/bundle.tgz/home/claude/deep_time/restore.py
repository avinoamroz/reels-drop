"""Soft-word restore: wherever clean_vo sits 4 dB+ under the dry chain on a word, cross-fade the dry chain back in (15 ms ramps)."""
import json, sys, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit"); import mix
DRY = sys.argv[1]; v = mix.load("/home/claude/deep_time/vo.wav"); d = mix.load(DRY); n = min(len(v), len(d)); v, d = v[:n], d[:n]
T = json.load(open("/home/claude/deep_time/timing.json")); m = np.zeros(n); r = int(0.015 * 48000)
db = lambda x: 20 * np.log10(np.sqrt((x ** 2).mean()) + 1e-9)
for w in T["words"]:
    a, b = int(w["s"] * 48000), int(w["e"] * 48000)
    if db(d[a:b]) - db(v[a:b]) > 4:
        m[a:b] = 1; print("restore", w["w"], round(w["s"], 2))
m = np.convolve(m, np.ones(2 * r) / (2 * r), "same")
sf.write("/home/claude/deep_time/vo.wav", (v * (1 - m) + d * m).astype(np.float32), 48000, subtype="PCM_24")
