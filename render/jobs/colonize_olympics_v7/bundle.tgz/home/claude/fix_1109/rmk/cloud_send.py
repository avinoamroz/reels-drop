"""cloud_send.py name:card [name:card ...]: render body + opener wrap on GitHub (4 cores, enough memory), publish <card>.mp4 + 540p, cloud ASR."""
import sys, os, subprocess, time
sys.path.insert(0, "/home/claude/reelkit"); import cloud_render as CR
R = "/home/claude/fix_1109/rmk"
def _git(*a, check=True):
    if a[:1] == ("pull",): a = ("-c", "gc.auto=0", "pull", "-q", "--rebase", "--autostash", "origin", "main")
    elif a[:1] in (("push",), ("commit",)): a = ("-c", "gc.auto=0") + a
    for k in range(6):
        r = subprocess.run(["git", "-C", CR.REPO, *a], capture_output=True, text=True)
        if r.returncode == 0 or not check: return r
        time.sleep(5)
    raise subprocess.CalledProcessError(r.returncode, a, r.stdout, r.stderr)
CR.git = _git
jobs, KEEP = [], {}
for arg in sys.argv[1:]:
    n, card = arg.split(":")
    own = [f"{R}/{n}/work/timing.json", f"{R}/{n}/work/mix.m4a", f"{R}/{n}/tts.txt"]
    KEEP[card] = own
    jobs.append(dict(id=card, cmd=(f"python3 -m pip install -q opencv-python-headless && cd {R} && python3 eng.py {n} render {R}/{n}/work/body.mp4 && "
                                   f"python3 finalize.py {n} {card} --no-publish"),
                     out=f"{R}/{n}/work/{card}.mp4", entry=[f"{R}/{x}" for x in ("eng.py", "finalize.py", "op_wrap_p.py", "rlib.py", f"cfg_{n}.py")], add=own + ["/usr/share/fonts/opentype/inter", "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"]))
it = iter([j["id"] for j in jobs]); _c = CR.collect
def coll(e, a):
    card = next(it); out = []
    for f in _c(e, a):
        if f.startswith(("/home/claude/reels-drop", "/home/claude/lm_prev")) or "/__pycache__/" in f: continue
        if f.startswith(R + "/") and not (f.endswith(".py") and f.count("/") == R.count("/") + 1) and f not in KEEP[card]: continue
        if f.endswith("/cloud_render.py"): continue
        out.append(f)
    print(card, len(out), "files", round(sum(os.path.getsize(f) for f in out) / 1e6, 1), "MB"); return out
CR.collect = coll
CR.send(jobs)
