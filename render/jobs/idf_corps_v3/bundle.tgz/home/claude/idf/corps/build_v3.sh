#!/bin/bash
# idf_corps_v3: no Comment IDF CTA, 7-minute card then the closing question, tail 0.7 s
set -e; cd /home/claude/idf/corps
python3 render_v3.py --vo v3/vo_v3.wav --segs v3/segs_v3.json --seven --out v3/corps_v3_raw.mp4
ffmpeg -y -v error -i v3/corps_v3_raw.mp4 -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000 -c:a aac -b:a 160k -movflags +faststart v3/idf_corps_v3.mp4
