# render_v2: new hook, script_v2 + engine_v2, IDF cheat sheet CTA.
#!/usr/bin/env python3
"""Reel 1: "Corps, not corpse" for @expressenglishcom (collab @noamroz__).
  python3 render.py                    -> corps_v1.mp4 (music only, timing from word counts)
  python3 render.py --vo vo/noam.mp3   -> corps_vo.mp4 (cards timed to Noam's voice; silence split, whisper small fallback)
  python3 render.py --frames 0.5,4     -> check/f_*.png
Script: script.py. Facts: facts.json. Engine: ../common/engine.py.
No Drive clip of Noam on core vs corpse was found, so the cold open is animated.
No IDF emblems or photos: every icon below is an original geometric glyph."""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "common")); sys.path.insert(0, HERE)
from engine_v2 import *
from script_v2 import LINES

RED = (232, 96, 110)

# ------------------------------------------------------------------ original icons (drawn at 4x)
def ic_infantry(d, S, c):   # double chevron
    w = S // 14
    for k in (0, 1):
        y = S * (0.38 + 0.22 * k); d.line([(S * .22, y + S * .16), (S * .5, y - S * .06), (S * .78, y + S * .16)], fill=c, width=w, joint="curve")
def ic_armor(d, S, c):      # track loop with wheels
    w = S // 16; d.rounded_rectangle([S * .14, S * .46, S * .86, S * .76], radius=S * .15, outline=c, width=w)
    for i in range(4): x = S * (.27 + .155 * i); d.ellipse([x - S * .05, S * .56, x + S * .05, S * .66], outline=c, width=w // 2 + 2)
    d.rounded_rectangle([S * .3, S * .28, S * .62, S * .46], radius=S * .05, outline=c, width=w); d.line([(S * .62, S * .36), (S * .88, S * .31)], fill=c, width=w)
def ic_artillery(d, S, c):  # trajectory arc and point
    w = S // 16; d.arc([S * .12, S * .2, S * .88, S * 1.3], 200, 340, fill=c, width=w)
    d.ellipse([S * .74, S * .44, S * .88, S * .58], fill=c); d.line([(S * .12, S * .8), (S * .88, S * .8)], fill=c, width=w // 2 + 2)
def ic_engineer(d, S, c):   # bridge
    w = S // 16; d.arc([S * .16, S * .36, S * .84, S * 1.0], 180, 360, fill=c, width=w)
    d.line([(S * .1, S * .5), (S * .9, S * .5)], fill=c, width=w)
    for x in (.3, .5, .7): d.line([(S * x, S * .5), (S * x, S * (.56 if x != .5 else .38) + (S * .06 if x != .5 else 0))], fill=c, width=w // 2 + 2)
    d.line([(S * .16, S * .5), (S * .16, S * .8)], fill=c, width=w); d.line([(S * .84, S * .5), (S * .84, S * .8)], fill=c, width=w)
def ic_intel(d, S, c):      # lens
    w = S // 16; d.ellipse([S * .2, S * .2, S * .7, S * .7], outline=c, width=w); d.ellipse([S * .36, S * .36, S * .54, S * .54], fill=c)
    d.line([(S * .66, S * .66), (S * .84, S * .84)], fill=c, width=w * 2)
def ic_c4i(d, S, c):        # network nodes
    w = S // 20; P = [(.5, .22), (.22, .5), (.78, .5), (.36, .8), (.64, .8)]
    for a, b in [(0, 1), (0, 2), (1, 3), (2, 4), (3, 4), (1, 2), (0, 3)]: d.line([(S * P[a][0], S * P[a][1]), (S * P[b][0], S * P[b][1])], fill=c, width=w)
    for x, y in P: d.ellipse([S * x - S * .07, S * y - S * .07, S * x + S * .07, S * y + S * .07], fill=c)
def ic_medical(d, S, c):    # plain plus in a ring
    w = S // 16; d.ellipse([S * .14, S * .14, S * .86, S * .86], outline=c, width=w)
    d.rounded_rectangle([S * .43, S * .28, S * .57, S * .72], radius=S * .03, fill=c); d.rounded_rectangle([S * .28, S * .43, S * .72, S * .57], radius=S * .03, fill=c)
def ic_gear(d, S, c):
    w = S // 16; cx = cy = S / 2
    for i in range(8):
        a = i * math.pi / 4; d.line([(cx + math.cos(a) * S * .22, cy + math.sin(a) * S * .22), (cx + math.cos(a) * S * .38, cy + math.sin(a) * S * .38)], fill=c, width=int(S * .1))
    d.ellipse([S * .24, S * .24, S * .76, S * .76], fill=c); d.ellipse([S * .39, S * .39, S * .61, S * .61], fill=(0, 0, 0, 0))
def ic_shield(d, S, c):
    w = S // 16; d.line([(S * .5, S * .14), (S * .82, S * .26), (S * .78, S * .58), (S * .5, S * .86), (S * .22, S * .58), (S * .18, S * .26), (S * .5, S * .14)], fill=c, width=w, joint="curve")
    d.line([(S * .38, S * .5), (S * .48, S * .6), (S * .64, S * .4)], fill=c, width=w, joint="curve")
def ic_book(d, S, c):
    w = S // 18
    d.line([(S * .5, S * .3), (S * .5, S * .78)], fill=c, width=w)
    d.line([(S * .5, S * .3), (S * .3, S * .24), (S * .12, S * .28), (S * .12, S * .74), (S * .3, S * .7), (S * .5, S * .78)], fill=c, width=w, joint="curve")
    d.line([(S * .5, S * .3), (S * .7, S * .24), (S * .88, S * .28), (S * .88, S * .74), (S * .7, S * .7), (S * .5, S * .78)], fill=c, width=w, joint="curve")
def ic_house(d, S, c):
    w = S // 16; d.line([(S * .14, S * .5), (S * .5, S * .18), (S * .86, S * .5)], fill=c, width=w, joint="curve")
    d.line([(S * .24, S * .44), (S * .24, S * .82), (S * .76, S * .82), (S * .76, S * .44)], fill=c, width=w, joint="curve")
    d.rounded_rectangle([S * .42, S * .58, S * .58, S * .82], radius=S * .03, outline=c, width=w // 2 + 2)
def ic_air(d, S, c):        # paper plane
    w = S // 18; P = [(S * .12, S * .5), (S * .88, S * .2), (S * .62, S * .84), (S * .48, S * .6), (S * .12, S * .5)]
    d.line(P, fill=c, width=w, joint="curve"); d.line([(S * .48, S * .6), (S * .88, S * .2)], fill=c, width=w)
def ic_navy(d, S, c):       # waves
    w = S // 16
    for k in range(3):
        y = S * (.34 + .16 * k); pts = [(S * (.12 + .76 * i / 24), y + S * .05 * math.sin(i / 24 * 4 * math.pi)) for i in range(25)]
        d.line(pts, fill=c, width=w, joint="curve")

UNITS = {  # key -> list of (english, hebrew, tag, icon, note)
 "ground": [("Infantry", "חיל הרגלים", "Infantry and Paratroopers Corps", ic_infantry),
            ("Armored Corps", "חיל השריון", "Corps", ic_armor),
            ("Artillery Corps", "חיל התותחנים", "Corps", ic_artillery),
            ("Combat Engineering Corps", "חיל ההנדסה הקרבית", "Corps", ic_engineer)],
 "tech":   [("Intelligence Corps", "חיל המודיעין", "Military Intelligence Directorate", ic_intel),
            ("C4I Corps", "חיל התקשוב", "also: Teleprocessing Corps", ic_c4i),
            ("Medical Corps", "חיל הרפואה", "Corps", ic_medical)],
 "more":   [("Technological and Logistics Directorate", "אגף הטכנולוגיה והלוגיסטיקה", "Directorate, not a corps", ic_gear),
            ("Military Police", "המשטרה הצבאית", "Military Police Corps", ic_shield),
            ("Education and Youth Corps", "חיל החינוך והנוער", "Corps", ic_book)],
 "cmd":    [("Home Front Command", "פיקוד העורף", "Command, not a corps", ic_house),
            ("Israeli Air Force", "חיל האוויר", "In English: no \"corps\"", ic_air),
            ("Israeli Navy", "חיל הים", "In English: no \"corps\"", ic_navy)],
}
PHRASE = {"ground": ["Infantry", "Armored", "Artillery", "Combat"], "tech": ["Intelligence", "C4I", "Medical"],
          "more": ["Technological", "Military", "Education"], "cmd": ["Home", "Air Force", "Navy"]}

def unit_card(fr, y, item, a, dy):
    en, he, tag, ic = item
    put(fr, rrect_sprite(960, 200, 34), W / 2, y + dy, a)
    put(fr, rrect_sprite(132, 132, 30, fill=SKY + (34,), outline=SKY + (90,)), 128, y + dy, a)
    put(fr, icon_sprite(en, 92, ic), 128, y + dy, a)
    size = 46
    while F("en", 700, size).getlength(en) > 740: size -= 1
    T(fr, en, 222, y + dy - 34, size, 700, WHITE, a, "lm")
    T(fr, he, 1000, y + dy + 30, 38, 700, (196, 222, 244), a, "rm", fam="he")
    T(fr, tag, 222, y + dy + 62, 24, 500, MUTED, a, "lm")

def big_word(fr, s, x, y, size, a, color=WHITE, dim_idx=(), strike_idx=(), hi_idx=(), track=0.02):
    """draw a word letter by letter so single letters can be dimmed / struck / highlighted"""
    f = F("en", 800, size); widths = [f.getlength(ch) for ch in s]; kern = size * track
    total = sum(widths) + kern * (len(s) - 1); xx = x - total / 2
    for i, ch in enumerate(s):
        col = (90, 108, 146) if i in dim_idx else (SKY if i in hi_idx else color)
        T(fr, ch, xx + widths[i] / 2, y, size, 800, col, a)
        if i in strike_idx:
            put(fr, pill_sprite(int(widths[i] + 10), max(8, size // 12), SKY), xx + widths[i] / 2, y + size * 0.05, a)
        xx += widths[i] + kern
    return total

def check(fr, x, y, s, a, ok=True):
    def fn(d, S, c):
        w = S // 9
        if ok: d.line([(S * .2, S * .52), (S * .42, S * .74), (S * .82, S * .3)], fill=c, width=w, joint="curve")
        else: d.line([(S * .25, S * .25), (S * .75, S * .75)], fill=c, width=w); d.line([(S * .75, S * .25), (S * .25, S * .75)], fill=c, width=w)
    put(fr, icon_sprite("ok" if ok else "no", s, fn, SKY if ok else RED), x, y, a)

def draw(fr, k, lt, dur, t, R):
    A = lambda t0=0.0, d=0.38: enter(lt, t0, d)
    if k == "hook":
        if lt < R.hook_max:   # the hook: on screen from frame 0, for at most 1 s
            T(fr, "If you served in the IDF,", W / 2, 600, 76, 800, WHITE)
            T(fr, "you probably make this mistake.", W / 2, 700, 64, 800, WHITE)
            big_word(fr, "CORPS", W / 2, 930, 230, 1.0, SKY)
            T(fr, "שירתתם בצה\"ל? כנראה שאתם טועים בזה", W / 2, 1110, 48, 700, (196, 222, 244), fam="he")
        else:
            a, dy = A(R.hook_max, 0.3)
            big_word(fr, "CORPS", W / 2, 760 + dy * 0, 230, 1.0, SKY)
            T(fr, "How do you say it?", W / 2, 960 + dy, 60, 700, WHITE, a)
            T(fr, "איך אומרים את זה?", W / 2, 1040 + dy, 44, 500, MUTED, a, fam="he")
    elif k == "not":
        a1, d1 = A(R.at_phrase(k, "Corps") - 0.05); a2, d2 = A(R.at_phrase(k, "Not"))
        put(fr, rrect_sprite(940, 330, 46, fill=SKY + (30,), outline=SKY + (110,)), W / 2, 600 + d1, a1)
        big_word(fr, "CORPS", W / 2, 560 + d1, 170, a1); T(fr, "/kɔːr/   = \"core\"", W / 2, 690 + d1, 50, 600, SKY, a1)
        check(fr, 920, 470 + d1, 70, a1, True)
        put(fr, rrect_sprite(940, 330, 46), W / 2, 1000 + d2, a2)
        big_word(fr, "CORPSE", W / 2, 960 + d2, 150, a2, color=(150, 164, 196)); T(fr, "/kɔːrps/", W / 2, 1090 + d2, 50, 600, MUTED, a2)
        check(fr, 920, 870 + d2, 70, a2, False)
    elif k == "silent":
        a, dy = A(0); tp = R.at_phrase(k, "The P")
        u = ease((lt - tp) / 0.4)
        big_word(fr, "CORPS", W / 2, 640 + dy, 250, a, dim_idx=(3, 4) if u > 0.5 else (), strike_idx=(3, 4) if u > 0.5 else ())
        a2, d2 = A(R.at_phrase(k, "said core"))
        T(fr, "= core", W / 2, 880 + d2, 110, 800, SKY, a2)
        T(fr, "/kɔːr/", W / 2, 1000 + d2, 56, 500, WHITE, a2)
        a3, d3 = A(tp + 0.2)
        put(fr, rrect_sprite(640, 92, 46, fill=SKY + (36,), outline=SKY + (120,)), W / 2, 1150 + d3, a3)
        T(fr, "P and S are silent", W / 2, 1150 + d3, 44, 700, WHITE, a3)
    elif k == "plural":
        a1, d1 = A(0); a2, d2 = A(R.at_phrase(k, "and said"))
        for x, top, word, ipa, say, aa, dd in [(300, "one", "corps", "/kɔːr/", "core", a1, d1), (780, "two", "corps", "/kɔːrz/", "cores", a2, d2)]:
            put(fr, rrect_sprite(440, 560, 46), x, 760 + dd, aa)
            T(fr, top.upper(), x, 560 + dd, 30, 700, MUTED, aa)
            T(fr, word, x, 680 + dd, 110, 800, WHITE, aa)
            T(fr, ipa, x, 800 + dd, 46, 500, MUTED, aa)
            T(fr, f"\"{say}\"", x, 920 + dd, 72, 800, SKY, aa)
        a3, d3 = A(R.at_phrase(k, "same spelling") + 0.1)
        T(fr, "Same spelling. Add a Z sound.", W / 2, 1140 + d3, 42, 600, WHITE, a3)
    elif k == "corpse":
        a, dy = A(0)
        big_word(fr, "CORPSE", W / 2, 640 + dy, 200, a, hi_idx=(3, 4))
        T(fr, "/kɔːrps/", W / 2, 820 + dy, 60, 500, WHITE, a)
        a2, d2 = A(R.at_phrase(k, "is a dead"))
        put(fr, rrect_sprite(760, 120, 60), W / 2, 1000 + d2, a2)
        T(fr, "= a dead body", W / 2, 1000 + d2, 60, 700, WHITE, a2)
        T(fr, "P and S: you hear them", W / 2, 1140 + d2, 40, 600, SKY, a2)
    elif k == "corpus":
        a, dy = A(0)
        big_word(fr, "CORPUS", W / 2, 640 + dy, 190, a)
        T(fr, "/ˈkɔːrpəs/", W / 2, 810 + dy, 58, 500, WHITE, a)
        a2, d2 = A(R.at_phrase(k, "a collection"))
        for i in range(4):
            put(fr, rrect_sprite(150, 190, 18, fill=(255, 255, 255, 26), outline=SKY + (110,)), W / 2 - 150 + i * 100, 1020 + d2 - i * 10, a2)
            for j in range(4): put(fr, pill_sprite(90 - 20 * (j == 3), 8, SKY), W / 2 - 150 + i * 100, 960 + j * 32 + d2 - i * 10, a2 * 0.8)
        T(fr, "= a collection of texts", W / 2, 1180 + d2, 48, 700, SKY, a2)
    elif k == "say":
        a, dy = A(0)
        put(fr, rrect_sprite(960, 760, 56, fill=(255, 255, 255, 16)), W / 2, 820 + dy, a)
        T(fr, "YOU SAY", 300, 540 + dy, 34, 700, MUTED, a); T(fr, "SAY IT", 780, 540 + dy, 34, 700, SKY, a)
        T(fr, "אתם אומרים", 300, 590 + dy, 32, 500, MUTED, a, fam="he"); T(fr, "תגידו", 780, 590 + dy, 32, 500, SKY, a, fam="he")
        put(fr, rrect_sprite(2, 560, 1, fill=(255, 255, 255, 50), outline=(255, 255, 255, 0), ow=0), W / 2, 850 + dy, a)
        a1, d1 = A(0.15)
        T(fr, "corpse", 300, 800 + d1, 104, 800, (150, 164, 196), a1, strike=RED)
        T(fr, "/kɔːrps/", 300, 920 + d1, 44, 500, MUTED, a1)
        a2, d2 = A(R.at_phrase(k, "Say core") - 0.05)
        sc = 1 + 0.06 * math.sin(clamp((lt - R.at_phrase(k, "Say core")) / 0.5) * math.pi)
        put(fr, text_sprite("core", 130, 800, SKY), 780, 800 + d2, a2, scale=sc)
        T(fr, "/kɔːr/", 780, 920 + d2, 44, 500, WHITE, a2)
        T(fr, "spelled: corps", 780, 1030 + d2, 34, 600, MUTED, a2)
    elif k == "intro":
        a, dy = A(0)
        T(fr, "The IDF", W / 2, 640 + dy, 120, 800, WHITE, a)
        T(fr, "in English", W / 2, 770 + dy, 120, 800, SKY, a)
        a2, d2 = A(0.5)
        T(fr, "corps  ·  directorates  ·  commands", W / 2, 920 + d2, 40, 600, MUTED, a2)
        T(fr, "חילות, אגפים ופיקודים", W / 2, 990 + d2, 40, 500, (196, 222, 244), a2, fam="he")
    elif k in UNITS:
        items = UNITS[k]; n = len(items); gap = 228; y0 = 800 - (n - 1) * gap / 2 + (0 if n == 4 else 30)
        ah = 1.0 if k != "ground" else ease(lt / 0.3)
        T(fr, "THE IDF IN ENGLISH", 60, 300, 30, 800, SKY, ah, "lm")
        T(fr, "צה\"ל באנגלית", 1020, 300, 32, 700, (196, 222, 244), ah, "rm", fam="he")
        for i, it in enumerate(items):
            a, dy = A(max(0, R.at_phrase(k, PHRASE[k][i]) - 0.12), 0.34)
            ghost = 0.22 * ease(lt / 0.3)
            unit_card(fr, y0 + i * gap, it, max(a, ghost), dy * a)
    elif k == "ask":
        a, dy = A(0)
        def bubble(d, S, c):
            w = S // 22; d.rounded_rectangle([S * .08, S * .14, S * .92, S * .72], radius=S * .16, outline=c, width=w)
            d.line([(S * .3, S * .72), (S * .24, S * .9), (S * .46, S * .72)], fill=c, width=w, joint="curve")
            for i in range(3): d.ellipse([S * (.3 + .2 * i) - S * .04, S * .4, S * (.3 + .2 * i) + S * .04, S * .48], fill=c)
        put(fr, icon_sprite("bubble", 220, bubble), W / 2, 500 + dy, a)
        T(fr, "Which corps", W / 2, 740 + dy, 104, 800, WHITE, a)
        T(fr, "were you in?", W / 2, 860 + dy, 104, 800, WHITE, a)
        a2, d2 = A(R.at_phrase(k, "Write"))
        T(fr, "Write it in the comments", W / 2, 1020 + d2, 50, 700, SKY, a2)
        T(fr, "I served in the ______ Corps.", W / 2, 1110 + d2, 40, 500, MUTED, a2)
    elif k == "kw":
        a, dy = A(0)
        T(fr, "COMMENT", W / 2, 520 + dy, 44, 700, WHITE, a)
        sc = 1 + 0.035 * math.sin(max(0, lt - 0.5) * 3.2)
        put(fr, pill_sprite(560, 230, SKY), W / 2, 720 + dy, a, scale=sc)
        T(fr, "IDF", W / 2, 718 + dy, 150, 800, WHITE, a)
        a2, d2 = A(0.4)
        T(fr, "Get the IDF cheat sheet", W / 2, 920 + d2, 42, 600, WHITE, a2)
        T(fr, "דף הדרגות והחילות באנגלית", W / 2, 985 + d2, 38, 500, (196, 222, 244), a2, fam="he")
        a3, d3 = A(0.8)
        T(fr, "@expressenglishcom", W / 2, 1150 + d3, 46, 700, WHITE, a3)
        T(fr, "with @noamroz__", W / 2, 1212 + d3, 38, 500, MUTED, a3)

if __name__ == "__main__":
    Reel(HERE, LINES, draw, "corps", seed=1, bpm=98, key=0).run()
