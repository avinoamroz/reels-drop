"""Reel 1, "Corps, not corpse". One dict per spoken line: en (narration + caption), he (subtitle), tts (ElevenLabs text).
python3 script.py  writes narration.txt and tts.txt"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))

LINES = [
 dict(key="hook", en="Israelis say this wrong all the time.", he="ישראלים אומרים את זה לא נכון כל הזמן."),
 dict(key="not", en="Corps. Not corpse.", he="אומרים \"קור\", לא \"קורפס\".", tts="Core. Not corpse."),
 dict(key="silent", en="Corps is said core. P and S are silent.", he="את Corps הוגים \"קור\". ה־P וה־S לא נשמעות.", tts="Core, is said core. P and S are silent."),
 dict(key="plural", en="Plural: same spelling, said cores.", he="ברבים: אותו כתיב, והוגים \"קורז\".", tts="Plural: same spelling, said cores."),
 dict(key="corpse", en="Corpse, with the P and S, is a dead body.", he="Corpse, עם P ועם S, זו גופה.", tts="Corpse, with the P and S, is a dead body."),
 dict(key="corpus", en="And corpus? A collection of texts.", he="ו־Corpus? זה אוסף של טקסטים.", tts="And corpus? A collection of texts."),
 dict(key="say", en="So don't say corpse. Say core.", he="אז אל תגידו \"קורפס\". תגידו \"קור\".", tts="So don't say corpse. Say core."),
 dict(key="ground", en="Infantry. Armored Corps. Artillery Corps. Combat Engineering Corps.", he="חיל הרגלים. חיל השריון. חיל התותחנים. חיל ההנדסה הקרבית.", tts="Infantry. Armored Core. Artillery Core. Combat Engineering Core."),
 dict(key="tech", en="Intelligence Corps. C4I Corps. Medical Corps.", he="חיל המודיעין. חיל התקשוב. חיל הרפואה.", tts="Intelligence Core. C-four-I Core. Medical Core."),
 dict(key="more", en="Technological and Logistics Directorate. Military Police. Education and Youth Corps.", he="אגף הטכנולוגיה והלוגיסטיקה. המשטרה הצבאית. חיל החינוך והנוער.", tts="Technological and Logistics Directorate. Military Police. Education and Youth Core."),
 dict(key="cmd", en="Home Front Command. The Air Force. The Navy.", he="פיקוד העורף. חיל האוויר. חיל הים.", tts="Home Front Command. The Air Force. The Navy."),
 dict(key="ask", en="So which corps were you in? Write it in the comments.", he="אז באיזה חיל הייתם? כתבו לי בתגובות.", tts="So which core were you in? Write it in the comments."),
 dict(key="kw", en="And comment IDF to get the full map of units in English.", he="ותגיבו IDF כדי לקבל את המפה המלאה של היחידות באנגלית.", tts="And comment I-D-F, to get the full map of units in English."),
]
BREAK = ' <break time="0.8s" /> '

if __name__ == "__main__":
    for l in LINES:
        for k in ("en", "he", "tts"):
            assert "\u2014" not in l.get(k, "") and "\u2013" not in l.get(k, ""), l
    open(os.path.join(HERE, "narration.txt"), "w", encoding="utf8").write("\n".join(l["en"] for l in LINES) + "\n")
    open(os.path.join(HERE, "tts.txt"), "w", encoding="utf8").write(BREAK.join(l.get("tts", l["en"]) for l in LINES) + "\n")
    print("ok", len(LINES), "lines")
