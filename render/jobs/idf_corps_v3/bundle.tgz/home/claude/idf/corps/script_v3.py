"""v2 (26 Oct 2026): new hook, pronunciation detour cut (plural, corpse, corpus, say) to reach the corps fast, Cartesia voice, CTA comment IDF for the cheat sheet. Reel 1, "Corps, not corpse". One dict per spoken line: en (narration + caption), he (subtitle), tts (ElevenLabs text).
python3 script.py  writes narration.txt and tts.txt"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))

LINES = [
 dict(key="hook", en="If you served in the IDF, you probably make this mistake.", he="אם שירתתם בצה\"ל, כנראה שאתם עושים את הטעות הזאת.",
      tts="If you served in the I-D-F, you probably make this mistake."),
 dict(key="not", en="Corps. Not corpse.", he="אומרים \"קור\", לא \"קורפס\".", tts="Core. Not corpse."),
 dict(key="silent", en="Corps is said core. The P and S are silent.", he="את Corps הוגים \"קור\". ה־P וה־S לא נשמעות.", tts="Core, is said core. The P and S are silent."),
 dict(key="ground", en="Infantry. Armored Corps. Artillery Corps. Combat Engineering Corps.", he="חיל הרגלים. חיל השריון. חיל התותחנים. חיל ההנדסה הקרבית.", tts="Infantry. Armored Core. Artillery Core. Combat Engineering Core."),
 dict(key="tech", en="Intelligence Corps. C4I Corps. Medical Corps.", he="חיל המודיעין. חיל התקשוב. חיל הרפואה.", tts="Intelligence Core. C-four-I Core. Medical Core."),
 dict(key="more", en="Technological and Logistics Directorate. Military Police. Education and Youth Corps.", he="אגף הטכנולוגיה והלוגיסטיקה. המשטרה הצבאית. חיל החינוך והנוער.", tts="Technological and Logistics Directorate. Military Police. Education and Youth Core."),
 dict(key="cmd", en="Home Front Command. The Air Force. The Navy.", he="פיקוד העורף. חיל האוויר. חיל הים.", tts="Home Front Command. The Air Force. The Navy."),
 dict(key="ask", en="So which corps were you in?", he="אז באיזה חיל הייתם?", tts="So which core were you in?"),
]
BREAK = ' <break time="0.8s" /> '

if __name__ == "__main__":
    for l in LINES:
        for k in ("en", "he", "tts"):
            assert "\u2014" not in l.get(k, "") and "\u2013" not in l.get(k, ""), l
    open(os.path.join(HERE, "narration_v3.txt"), "w", encoding="utf8").write("\n".join(l["en"] for l in LINES) + "\n")
    open(os.path.join(HERE, "tts_v3.txt"), "w", encoding="utf8").write(BREAK.join(l.get("tts", l["en"]) for l in LINES) + "\n")
    print("ok", len(LINES), "lines")
