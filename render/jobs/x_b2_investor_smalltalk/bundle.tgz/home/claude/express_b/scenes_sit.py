"""scenes_sit.py (1 Nov, Express batch B): scene-first situational English. Every beat is a little stage:
the Israeli (blue stick figure, the speaker) and the other person (orange, passive) at a table with a prop.
House colour code: blue = speaker / active, orange = passive listener, red = the new (wrong) line, green = the fix.

  {"type": "sit", "line": N, "place": "Board meeting", "ask": "optional line the orange person says",
   "neg": "I'm agree", "neg_he": "small Hebrew line", "pos": "I agree", "tip": "optional short green tip",
   "prop": "emoji on the table", "score": k, "of": 5, "marks": {"n": phrase, "p": phrase}}

Timeline inside a beat: scene start -> the orange bubble (ask) if any; mark n -> the blue figure's bubble with the wrong
line (red outline), the orange figure gets a '?' and the Hebrew line shows under the stage; mark p -> the bubble turns
green with the fix, the orange figure nods and smiles, the score chip ticks up, the tip pops.
  {"type": "sit_hook", "line": 1, "hook": "big hook text", "ask": "optional bubble", "prop": .., "of": 5}
Big hook (>=120 px) on top from frame 0, stage below. Scene types from scenes_x (speaker end card, title) are exported,
and the scenes_x loop patches (cross-fade into frame 0, looping bed) are applied."""
import sys, math, importlib.util
_p = "/home/claude/express_1031_cta/scenes_x.py"
_s = importlib.util.spec_from_file_location("scenes_x", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
for _k, _v in vars(_m).items():
    if _k.startswith("sc_"): globals()[_k] = _v
import render as RD
from render import P, T, PP, fade_in, block, block_h, source, draw_emoji, pill, shadow_box
from kit import ease, St, sa, rr

BLUE = (0x2A / 255, 0x88 / 255, 0xD4 / 255, 1.0); ORANGE = (0xF2 / 255, 0x8C / 255, 0x28 / 255, 1.0)
YF = 1400; HF = 540; XB = 250; XO = 830          # floor line, figure height, blue x, orange x


def _line(c, pts, w, color):
    sa(c, color, St.a); c.set_line_width(w); c.set_line_cap(1); c.set_line_join(1)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()


def figure(c, x, yf, h, color, t, mode, face=1, ph=0.0, smile=False, tilt=0.0):
    """stick figure at (x, yf). modes: talk (front arm gestures), listen (gentle nod), puzzled (head tilt, arms out)"""
    lw = h * 0.045; hr = h * 0.115
    bob = math.sin(t * 2.4 + ph) * h * 0.006
    hip = (x, yf - h * 0.45 + bob); neck = (x + face * h * 0.015, yf - h * 0.80 + bob)
    tl = tilt if mode != "puzzled" else tilt + 0.22 * face * -1
    head = (neck[0] + face * h * 0.02 + math.sin(tl) * hr, neck[1] - hr * 1.05)
    step = math.sin(t * 2.0 + ph) * h * 0.008
    _line(c, [(hip[0] - h * 0.11 + step, yf), hip, (hip[0] + h * 0.11 - step, yf)], lw, color)
    _line(c, [hip, neck], lw, color)
    sh = (neck[0], neck[1] + h * 0.05)
    if mode == "talk":
        a = 0.6 + 0.45 * math.sin(t * 5.5 + ph)
        el = (sh[0] + face * h * 0.17, sh[1] + h * 0.10); hd = (el[0] + face * h * 0.14 * math.cos(a), el[1] - h * 0.14 * math.sin(a))
        _line(c, [sh, el, hd], lw, color)
        _line(c, [sh, (sh[0] - face * h * 0.08, sh[1] + h * 0.17), (sh[0] - face * h * 0.06, sh[1] + h * 0.32)], lw, color)
    elif mode == "puzzled":     # elbows out, forearms open (a shrug), no hands drawn
        for s_ in (1, -1):
            el = (sh[0] + s_ * h * 0.15, sh[1] + h * 0.16)
            _line(c, [sh, el, (el[0] + s_ * h * 0.07, el[1] - h * 0.09)], lw, color)
    else:
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.09, sh[1] + h * 0.17), (sh[0] + s_ * h * 0.07, sh[1] + h * 0.33)], lw, color)
    sa(c, color, St.a); c.set_line_width(lw); c.new_sub_path(); c.arc(head[0], head[1], hr, 0, 2 * math.pi); c.stroke()
    nod = math.sin(t * 4.0 + ph) * hr * 0.12 if (mode == "listen" and smile) else 0
    ex = head[0] + face * hr * 0.30; ey = head[1] - hr * 0.15 + nod
    for dx in (-hr * 0.22, hr * 0.22):
        c.new_sub_path(); c.arc(ex + dx, ey, hr * 0.09, 0, 2 * math.pi); c.fill()
    c.set_line_width(lw * 0.7)
    my = head[1] + hr * 0.38 + nod
    if smile:
        c.new_sub_path(); c.arc(ex, my - hr * 0.22, hr * 0.32, 0.18 * math.pi, 0.82 * math.pi); c.stroke()
    elif mode == "puzzled":     # wavy unsure mouth
        c.move_to(ex - hr * 0.2, my); c.curve_to(ex - hr * 0.07, my - hr * 0.12, ex + hr * 0.07, my + hr * 0.12, ex + hr * 0.2, my); c.stroke()
    else:
        c.move_to(ex - hr * 0.2, my); c.line_to(ex + hr * 0.2, my); c.stroke()
    return head


def table(c, prop, t, S):
    sa(c, P["navy"], 0.10 * St.a); c.rectangle(40, YF + 6, 1000, 8); c.fill()
    sa(c, (0.80, 0.66, 0.46, 1.0), St.a); rr(c, 395, YF - 225, 290, 26, 10); c.fill()
    sa(c, (0.62, 0.48, 0.30, 1.0), St.a)
    for x in (425, 640): c.rectangle(x, YF - 200, 16, 200); c.fill()
    if prop: draw_emoji(c, prop, 540, YF - 290 + 5 * math.sin(t * 2.0), 120)


def bubble(c, text, sz, tail_x, tail_y, stroke, color, a, s, y0=430, he=None):
    """speech bubble across the width (x 70..1010), centred at y0 (+ its own height), tail down to (tail_x, tail_y)"""
    if a <= 0.01: return
    hb = mb_h(text, sz); bh = hb + 80; top = y0
    old = St.a; St.a *= a
    c.save(); c.translate(540, top + bh / 2); c.scale(s, s); c.translate(-540, -(top + bh / 2))
    bx = min(max(tail_x, 220), 860)
    sa(c, P["navy"], 0.10 * St.a); rr(c, 73, top + 10, 934, bh, 48); c.fill()
    sa(c, P["card"], St.a); c.move_to(bx - 46, top + bh - 2); c.line_to(tail_x, tail_y); c.line_to(bx + 46, top + bh - 2); c.close_path(); c.fill()
    RD.box(c, 70, top, 940, bh, 48, P["card"], 1.0, stroke=stroke, sw=6)
    sa(c, P["card"], St.a); c.rectangle(bx - 40, top + bh - 8, 80, 14); c.fill()
    sa(c, stroke, St.a); c.set_line_width(6); c.set_line_join(1)
    c.move_to(bx - 46, top + bh - 1); c.line_to(tail_x, tail_y); c.line_to(bx + 46, top + bh - 1); c.stroke()
    mb(c, text, sz, 540, top + bh / 2, color, 1.0, 1.0, 800, hl=P["blue"], maxw=840, max_lines=3)
    c.restore(); St.a = old
    return bh


def mb_h(text, sz, maxw=840, max_lines=3):
    """height of text with optional explicit breaks ('|' = new line, each line kept on one line)"""
    if "|" not in text: return block_h(text, sz, 800, maxw, max_lines)
    return sum(block_h(l, sz, 800, maxw, 1) for l in text.split("|"))


def mb(c, text, sz, x, yc, color, a, s, w=800, hl=None, maxw=840, max_lines=3):
    if "|" not in text: return block(c, text, sz, x, yc, color, a, s, w, hl=hl, maxw=maxw, max_lines=max_lines)
    ls = text.split("|"); hs = [block_h(l, sz, w, maxw, 1) for l in ls]; y = yc - sum(hs) / 2
    c.save(); c.translate(x, yc); c.scale(s, s); c.translate(-x, -yc)
    for l, h in zip(ls, hs): block(c, l, sz, x, y + h / 2, color, a, 1.0, w, hl=hl, maxw=maxw, max_lines=1); y += h
    c.restore(); return sum(hs)


def sc_sit_title(c, t, S):
    """title card with explicit line breaks: icon, en ('|' breaks), he, optional sub (mark 'sub') + sub_he"""
    t0 = S["t0"]; sz = S.get("size", 112); en = S["en"]; sub = S.get("sub")
    h_en = mb_h(en, sz, 960, 3); h_he = block_h(S.get("he", ""), 62, 700, 940, 2) if S.get("he") else 0
    h_sub = (block_h(sub, 66, 800, 940, 2) + (70 if S.get("sub_he") else 0)) if sub else 0
    total = 230 + h_en + 40 + h_he + (70 + h_sub if sub else 0); y = max(330, (330 + 1460) / 2 - total / 2)
    a, s = PP(t, t0 + 0.05, S); draw_emoji(c, S["icon"], 540, y + 100 + 10 * math.sin(t * 2.6), 190, a, s); y += 230
    a, s = PP(t, t0 + 0.08, S); mb(c, en, sz, 540, y + h_en / 2, P["navy"], a, s, 900, hl=P["blue"], maxw=960); y += h_en
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: RD.box(c, 540 - 330 * u, y + 6, 660 * u, 12, 6, P["gold"], a)
    y += 40
    if S.get("he"):
        a, s = PP(t, t0 + 0.25, S); block(c, S["he"], 62, 540, y + h_he / 2, P["blue"], a, s, 700, maxw=940, max_lines=2); y += h_he
    if sub:
        y += 70; ts = S["times"].get("sub", t0 + 1.0); a, s = PP(t, ts, S); hs = block_h(sub, 66, 800, 940, 2)
        block(c, sub, 66, 540, y + hs / 2, P["navy"], a, s, 800, hl=P["gold_text"], maxw=940, max_lines=2); y += hs
        if S.get("sub_he"):
            a, s = PP(t, ts + 0.25, S); T(c, S["sub_he"], 58, 540, y + 40, P["blue"], a, s, 700, maxw=940)
    source(c, t, S)


def chips(c, t, S, tp):
    """top row: place pill (left) and the live score chip (right)"""
    pl = S.get("place"); a, s = PP(t, S["t0"] + 0.02, S)
    if pl: pill(c, pl, 44, 320, 330, P["navy"], P["white"], a, s, w=800)
    of = S.get("of")
    if of:
        k = S.get("score", 0); done = tp is not None and t >= tp
        v = k if done else max(0, k - 1)
        sc = 1.0
        if done: sc = 1 + 0.18 * math.exp(-6 * max(0, t - tp)) * math.sin(min(math.pi, (t - tp) * 9))
        lab = S.get("score_label") or S["_spec"].get("score_label", "Sounds senior")
        pill(c, f"{lab} {v}/{of}", 44, 790 if pl else 540, 330, P["green"] if v else P["silver"], P["white"], a, s * sc, w=800)


def sc_sit(c, t, S):
    t0 = S["t0"]; tn = S["times"].get("n", t0 + 0.6); tp = S["times"].get("p", tn + 1.6)
    chips(c, t, S, tp)
    asking = S.get("ask") and t < tn - 0.1
    wrong = tn - 0.1 <= t < tp - 0.08; fixed = t >= tp - 0.08
    # stage
    fa = fade_in(t, t0, S, 0.3); old = St.a; St.a *= fa
    table(c, S.get("prop"), t, S)
    hb = figure(c, XB, YF, HF, BLUE, t, "talk" if (wrong or fixed) else "listen", 1, 0.0, smile=fixed)
    ho = figure(c, XO, YF, HF, ORANGE, t, "talk" if asking else ("puzzled" if wrong else "listen"), -1, 1.3, smile=fixed)
    if wrong:
        qa_ = fade_in(t, tn, S, 0.2)
        T(c, "?", 120, XO + 120, ho[1] - 70 + 8 * math.sin(t * 5), ORANGE, qa_, 1.0, 900)
    St.a = old
    # bubbles
    if S.get("ask"):
        a = fade_in(t, t0 + 0.05, S, 0.2) * (1 - fade_in(t, tn - 0.25, S, 0.15))
        bubble(c, S["ask"], 72, XO - 30, ho[1] - 70, ORANGE, P["navy"], a, 1.0)
    if t >= tn - 0.1:
        a, s = PP(t, tn - 0.1, S, bounce=2.2)
        if not fixed:
            bh = bubble(c, S["neg"], 92, XB + 30, hb[1] - 70, P["red"], P["red"], a, s)
        else:
            pa, ps = PP(t, tp - 0.08, S, bounce=2.4)
            bubble(c, S["pos"], 88, XB + 30, hb[1] - 70, P["green"], P["green"], 1.0, ps)
            # small struck "Not:" line under the bubble keeps the contrast for a beat
    # bottom line: Hebrew meaning while wrong, tip when fixed
    yb = 1490
    if wrong and S.get("neg_he"):
        a = fade_in(t, tn, S, 0.25)
        T(c, S["neg_he"], 60, 540, yb, P["red"], a, 1.0, 700, maxw=940)
    if fixed and S.get("tip"):
        a, s = PP(t, tp + 0.15, S, bounce=2.2)
        pill(c, S["tip"], 56, 540, yb, P["green"], P["white"], a, s, w=800)
    source(c, t, S)


def sc_sit_hook(c, t, S):
    t0 = S["t0"]
    a, s = PP(t, t0, S)
    hh = mb_h(S["headline"], 128, 960, 2)
    mb(c, S["headline"], 128, 540, 330 + hh / 2, P["navy"], a, s * (1 + 0.012 * math.sin(t * 2.2)), 900, hl=P["red"], maxw=960, max_lines=2)
    u = ease((t - 0.15) / 0.8) if t > 0.15 else 0.0
    if u > 0: RD.box(c, 540 - 330 * u, 330 + hh + 14, 660 * u, 12, 6, P["gold"], a)
    tb = S["times"].get("b", t0 + 1.2)
    old = St.a
    table(c, S.get("prop"), t, S)
    talking = t >= tb
    hb = figure(c, XB, YF, HF, BLUE, t, "puzzled" if S.get("puzzled_blue") else ("talk" if talking else "listen"), 1, 0.0)
    ho = figure(c, XO, YF, HF, ORANGE, t, "talk" if not talking else "listen", -1, 1.3)
    if S.get("sub"):
        a2, s2 = PP(t, tb, S); T(c, S["sub"], 64, 540, 330 + hh + 90, P["blue"], a2, s2, 800, maxw=960)
    if S.get("he"):
        a3 = fade_in(t, tb + 0.2, S, 0.3); T(c, S["he"], 60, 540, 1490, P["gold_text"], a3, 1.0, 700, maxw=940)
    St.a = old
    source(c, t, S)


def sc_sit_end(c, t, S):
    """lead-in last beat (loops into frame 0): same stage, the blue figure says the lead-in in a navy bubble"""
    t0 = S["t0"]
    table(c, S.get("prop"), t, S)
    hb = figure(c, XB, YF, HF, BLUE, t, "talk", 1, 0.0)
    figure(c, XO, YF, HF, ORANGE, t, "listen", -1, 1.3)
    if S.get("say"):
        a, s = PP(t, t0 + 0.05, S, bounce=2.2)
        bubble(c, S["say"], 88, XB + 30, hb[1] - 70, P["blue"], P["navy"], a, s)
    source(c, t, S)
