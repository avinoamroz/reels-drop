"""Professional reelkit scenes (27 Oct 2026 fixes): full-bleed real footage / photos with a navy grade and clean type,
two-panel comparisons, numbered steps, word tiles, a needs pyramid, and the closing question.
House colours: silver background, navy #163260, blue #2A88D4, gold #B8923F. Fonts come from kit (Inter / Heebo).
Video: "src" may be a video file (.ts / .mp4); frames are streamed with ffmpeg in order (seek when time jumps)."""
import math, os, subprocess
import numpy as np, cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, image_surf, clean
from kit import W, H, FPS, ease, ramp, lerp, St, sa, rr, line as kline, circ, box, is_he

LIGHT_HE = (0.80, 0.88, 0.97, 1.0)
VIDEO_EXT = (".ts", ".mp4", ".mov", ".m4v", ".webm")

def M(S, k, d=None):
    return S["times"].get(k, d if d is not None else S["t0"] + 0.3)

# ------------------------------------------------------------------ video reader
class Clip:
    def __init__(s, path, w, h, ss=0.0, speed=1.0):
        s.path, s.w, s.h, s.ss, s.speed = path, int(w) // 2 * 2, int(h) // 2 * 2, ss, speed
        s.p = None; s.idx = -1; s.frame = None; s.eof = False
    def _open(s, k):
        if s.p: s.p.kill(); s.p.wait()
        t = s.ss + k * s.speed / FPS
        vf = f"setpts=PTS/{s.speed},fps={FPS},scale={s.w}:{s.h}:force_original_aspect_ratio=increase,crop={s.w}:{s.h},format=bgra"
        s.p = subprocess.Popen(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", s.path, "-an", "-vf", vf, "-f", "rawvideo", "pipe:1"],
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        s.idx = k - 1; s.eof = False
    def get(s, k):
        k = max(0, int(k))
        if s.p is None or k < s.idx or k > s.idx + 45: s._open(k)
        n = s.w * s.h * 4
        while s.idx < k and not s.eof:
            b = s.p.stdout.read(n)
            if len(b) < n: s.eof = True; break
            s.idx += 1; s.frame = b
        if s.frame is None: return None
        return cairo.ImageSurface.create_for_data(bytearray(s.frame), cairo.FORMAT_ARGB32, s.w, s.h, s.w * 4)
_clips = {}
def media_surf(S, t, w, h):
    src = S["src"]
    if src.lower().endswith(VIDEO_EXT):
        key = (id(S), int(w), int(h))
        if key not in _clips: _clips[key] = Clip(src, w, h, S.get("ss", 0.0), S.get("speed", 1.0))
        cl = _clips[key]
        if not hasattr(cl, "kmax"):
            try: d = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", src], capture_output=True, text=True).stdout.strip())
            except Exception: d = 5.0
            d = min(d - S.get("ss", 0.0), S.get("dur", 1e9))
            scene = max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"] + 0.3)
            if "speed" not in S: cl.speed = max(0.6, min(1.0, d / scene))
            cl.kmax = max(0, int((d - 0.2) * FPS / cl.speed))
        k = min(cl.kmax, int(round((t - S["t0"]) * FPS)))
        return cl.get(k)
    return image_surf(src, w, h)

def draw_media(c, t, S, x0, y0, pw, ph, radius=0):
    """media with a slow push-in, clipped to the box"""
    dur = max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"]); u = min(1.0, max(0.0, (t - S["t0"]) / dur))
    z0, z1 = S.get("zoom", [1.0, 1.08]); z = lerp(z0, z1, ease(u)); dx, dy = S.get("pan", [0.0, -0.02])
    surf = media_surf(S, t, pw * 1.1, ph * 1.1)
    c.save()
    if radius: rr(c, x0, y0, pw, ph, radius)
    else: c.rectangle(x0, y0, pw, ph)
    c.clip()
    sa(c, P["navy"]); c.paint()
    if surf is not None:
        c.translate(x0 + pw / 2 + dx * pw * u, y0 + ph / 2 + dy * ph * u); c.scale(z / 1.1, z / 1.1)
        c.set_source_surface(surf, -surf.get_width() / 2, -surf.get_height() / 2); c.paint_with_alpha(St.a)
    c.restore()

def grade(c, top=0.30, bottom=0.88, y_start=0.40):
    """navy grade for legible type over footage"""
    g = cairo.LinearGradient(0, 0, 0, H)
    n = P["navy"]
    g.add_color_stop_rgba(0.0, n[0], n[1], n[2], top * St.a)
    g.add_color_stop_rgba(0.20, n[0], n[1], n[2], 0.0)
    g.add_color_stop_rgba(y_start, n[0], n[1], n[2], 0.0)
    g.add_color_stop_rgba(0.72, n[0], n[1], n[2], bottom * 0.85 * St.a)
    g.add_color_stop_rgba(1.0, n[0], n[1], n[2], bottom * St.a)
    c.rectangle(0, 0, W, H); c.set_source(g); c.fill()

def kicker(c, t, S, y, tk, text=None):
    s = text or S.get("kicker")
    if not s: return y
    a, sc = PP(t, tk, S)
    pill(c, s, 36, 540, y, P["gold"], P["white"], a, sc, w=800); return y + 80

def src_line(c, t, S, y=1525, light=True):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + 0.5, S)
    T(c, s, 30, 540, y, (1, 1, 1, 0.78) if light else P["grey"], a, 1.0, 700, maxw=940, src=True)

# ------------------------------------------------------------------ full-bleed footage with type in the lower third
def sc_media(c, t, S):
    draw_media(c, t, S, 0, 0, W, H)
    grade(c, bottom=S.get("grade", 0.9))
    t0 = S["t0"]; en, he, big, sub = S.get("en"), S.get("he"), S.get("big"), S.get("sub")
    h_en = block_h(en, S.get("size", 84), 900, 940, 3); h_big = 230 if big else 0
    h_sub = block_h(sub, 58, 900, 940, 2) if sub else 0; h_he = block_h(he, 50, 700, 940, 2) if he else 0
    total = (80 if S.get("kicker") else 0) + h_en + h_big + (h_sub + 16 if sub else 0) + (h_he + 20 if he else 0)
    y = S.get("y_bottom", 1440) - total
    y = kicker(c, t, S, y + 30, t0 + 0.05) - 30 if S.get("kicker") else y
    a, s = PP(t, t0 + 0.1, S)
    if en:
        block(c, en, S.get("size", 84), 540, y + h_en / 2, P["white"], a, s, hl=P["gold2"], maxw=940, max_lines=3); y += h_en
    if big:
        tb = M(S, "big", t0 + 0.1); a2, s2 = PP(t, tb, S, bounce=1.6)
        br = 1 + 0.012 * math.sin(t * 2.6)
        T(c, big, 220, 540, y + 112, P["gold2"], a2, s2 * br, 900, maxw=960); y += h_big
    if sub:
        ts = M(S, "sub", t0 + 0.4); a3, s3 = PP(t, ts, S)
        block(c, sub, 58, 540, y + 16 + h_sub / 2, P["white"], a3, s3, hl=P["gold2"], maxw=940, max_lines=2); y += h_sub + 16
    if he:
        th = M(S, "he", t0 + 0.3); a4, s4 = PP(t, th, S)
        block(c, he, 50, 540, y + 20 + h_he / 2, LIGHT_HE, a4, s4, w=700, maxw=940, max_lines=2)
    src_line(c, t, S)

# ------------------------------------------------------------------ framed footage on silver (low-res clips)
def sc_framed(c, t, S):
    t0 = S["t0"]; y = 300
    y = kicker(c, t, S, y, t0 + 0.05)
    x0, x1, y0, y1 = 110, 970, y, 1080
    a = fade_in(t, t0, S, 0.3); old = St.a; St.a *= a
    sa(c, P["navy"], 0.14); rr(c, x0 + 4, y0 + 16, x1 - x0, y1 - y0, 34); c.fill()
    draw_media(c, t, S, x0, y0, x1 - x0, y1 - y0, radius=34)
    rr(c, x0, y0, x1 - x0, y1 - y0, 34); sa(c, P["white"]); c.set_line_width(8); c.stroke()
    St.a = old
    yy = y1 + 50; en, he = S.get("en"), S.get("he")
    a, s = PP(t, M(S, "en", t0 + 0.2), S); h = block_h(en, 72, 900, 940, 3)
    block(c, en, 72, 540, yy + h / 2, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=3); yy += h + 14
    if he:
        a, s = PP(t, M(S, "he", t0 + 0.4), S); hh = block_h(he, 48, 700, 940, 2)
        block(c, he, 48, 540, yy + hh / 2, P["blue"], a, s, w=700, maxw=940, max_lines=2)
    src_line(c, t, S, light=False)

# ------------------------------------------------------------------ headline helper on silver
def head(c, t, S, y=320):
    t0 = S["t0"]; y = kicker(c, t, S, y, t0 + 0.02)
    en, he = S.get("title"), S.get("title_he")
    if en:
        a, s = PP(t, t0 + 0.05, S); h = block_h(en, 78, 900, 940, 3)
        block(c, en, 78, 540, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=3); y += h + 10
        a, s = PP(t, t0 + 0.15, S); box(c, 540 - 110 * a, y, 220 * a, 6, 3, P["gold"], a); y += 30
    if he:
        a, s = PP(t, t0 + 0.2, S); hh = block_h(he, 50, 700, 940, 2)
        block(c, he, 50, 540, y + hh / 2, P["blue"], a, s, w=700, maxw=940, max_lines=2); y += hh
    return y + 40

# ------------------------------------------------------------------ two panels: left vs right (stacked)
def panel(c, t, S, P_, x, y, w, h, tk, dark):
    a, s = PP(t, tk, S, bounce=1.5)
    if a <= 0.01: return
    c.save(); c.translate(x + w / 2, y + h / 2); c.scale(s, s); c.translate(-(x + w / 2), -(y + h / 2))
    fill = P[P_.get("color", "navy")] if dark else P["white"]
    shadow_box(c, x, y, w, h, 34, fill, a, stroke=None if dark else P["silver"], sw=4)
    box(c, x, y + 34, 10, h - 68, 5, P[P_.get("accent", "gold")], a)
    goldp = dark and P_.get("color") == "gold"
    fg = P["white"] if dark else P["navy"]; hl = (P["navy"] if goldp else P["gold2"]) if dark else P["blue"]
    yy = y + 70
    if P_.get("tag"):
        T(c, P_["tag"], 34, x + w / 2, yy, (P["white"] if goldp else P["gold2"]) if dark else P["gold_text"], a, 1, 800, maxw=w - 80); yy += 60
    hl_ = block_h(P_.get("en"), 66, 900, w - 90, 2)
    block(c, P_.get("en"), 66, x + w / 2, yy + hl_ / 2, fg, a, 1, hl=hl, maxw=w - 90, max_lines=2); yy += hl_ + 14
    if P_.get("he"):
        hh = block_h(P_["he"], 44, 700, w - 90, 2)
        block(c, P_["he"], 44, x + w / 2, yy + hh / 2, (P["navy"] if goldp else LIGHT_HE) if dark else P["blue"], a, 1, w=700, maxw=w - 90, max_lines=2)
    c.restore()
def sc_compare(c, t, S):
    y = head(c, t, S, S.get("y", 330))
    L, R = S["left"], S["right"]; ph = S.get("panel_h", 400); gap = 60
    y0 = max(y, (1470 - (2 * ph + gap)) / 2 + 120)
    panel(c, t, S, L, 90, y0, 900, ph, M(S, "left", S["t0"] + 0.3), L.get("dark", True))
    a, s = PP(t, M(S, "right", S["t0"] + 1.0), S)
    if a > 0.01:
        if S.get("vs", "vs"): circ(c, 540, y0 + ph + gap / 2, 44, P["gold"], a, stroke=P["white"], sw=6)
        T(c, S.get("vs", "vs"), 36, 540, y0 + ph + gap / 2 + 2, P["white"], a, s, 900)
    panel(c, t, S, R, 90, y0 + ph + gap, 900, ph, M(S, "right", S["t0"] + 1.0), R.get("dark", False))
    src_line(c, t, S, light=False)

# ------------------------------------------------------------------ numbered steps / list
def sc_steps(c, t, S):
    y = head(c, t, S, S.get("y", 330)); items = S["items"]; n = len(items)
    ih = S.get("item_h", 190); gap = 30; y0 = max(y + 10, (1460 + y - n * (ih + gap)) / 2)
    for k, it in enumerate(items):
        tk = M(S, f"i{k}", S["t0"] + 0.4 + 0.7 * k); a, s = PP(t, tk, S, bounce=1.5)
        if a <= 0.01: continue
        yy = y0 + k * (ih + gap)
        c.save(); c.translate(540, yy + ih / 2); c.scale(s, s); c.translate(-540, -(yy + ih / 2))
        dark = it.get("dark", False)
        shadow_box(c, 90, yy, 900, ih, 30, P["navy"] if dark else P["white"], a, stroke=None if dark else P["silver"], sw=4)
        lab = it.get("n", str(k + 1)) if S.get("numbers", True) else None
        tx0 = 540
        if lab:
            circ(c, 175, yy + ih / 2, 50, P["gold"] if not it.get("strike") else P["silver"], a); T(c, lab, 50, 175, yy + ih / 2 + 2, P["white"], a, 1, 900)
            tx0 = 590
        fg = P["white"] if dark else (P["grey"] if it.get("strike") else P["navy"])
        mw = 700 if lab else 820
        he_ = it.get("he"); hh = 46 if he_ else 0
        block(c, it["en"], 54, tx0, yy + ih / 2 - hh / 2, fg, a, 1, hl=P["gold2"] if dark else P["blue"], maxw=mw, max_lines=2)
        if he_: T(c, he_, 38, tx0, yy + ih / 2 + 52, LIGHT_HE if dark else P["blue"], a, 1, 700, maxw=mw)
        if it.get("strike"):
            u = ramp(t, tk + 0.5, tk + 0.9)
            if u > 0: kline(c, [(tx0 - mw / 2 + 10, yy + ih / 2 - hh / 2), (tx0 - mw / 2 + 10 + (mw - 20) * u, yy + ih / 2 - hh / 2)], P["red"], 7, a)
        c.restore()
    src_line(c, t, S, light=False)

# ------------------------------------------------------------------ word tiles (2 x 2)
def sc_tiles(c, t, S):
    y = head(c, t, S, S.get("y", 330)); items = S["items"]
    tw, th, gap = 430, 300, 40; y0 = max(y + 20, (1460 + y - (2 * th + gap)) / 2)
    for k, it in enumerate(items):
        tk = M(S, f"i{k}", S["t0"] + 0.4 + 0.5 * k); a, s = PP(t, tk, S, bounce=1.7)
        if a <= 0.01: continue
        x = 540 - tw - gap / 2 + (k % 2) * (tw + gap); yy = y0 + (k // 2) * (th + gap)
        c.save(); c.translate(x + tw / 2, yy + th / 2); c.scale(s, s); c.translate(-(x + tw / 2), -(yy + th / 2))
        dark = k in S.get("dark", [0, 3])
        shadow_box(c, x, yy, tw, th, 34, P["navy"] if dark else P["white"], a, stroke=None if dark else P["silver"], sw=4)
        box(c, x + tw / 2 - 40, yy + 60, 80, 6, 3, P["gold"], a)
        T(c, it["en"], 70, x + tw / 2, yy + th / 2 + 6, P["white"] if dark else P["navy"], a, 1, 900, maxw=tw - 50)
        T(c, it.get("he", ""), 42, x + tw / 2, yy + th / 2 + 78, LIGHT_HE if dark else P["blue"], a, 1, 700, maxw=tw - 50)
        c.restore()
    if S.get("footer"):
        tf = M(S, "footer", S["t0"] + 2.5); a, s = PP(t, tf, S)
        yy = y0 + 2 * th + gap + 90
        pill(c, S["footer"], 50, 540, yy, P["navy"], P["white"], a, s, outline=P["gold"])
        if S.get("footer_he"): T(c, S["footer_he"], 40, 540, yy + 90, P["blue"], a, s, 700)
    src_line(c, t, S, light=False)

# ------------------------------------------------------------------ needs pyramid (6 tiers: 4 personality navy, 2 spirit gold)
TIERS = [("CERTAINTY", "ודאות"), ("VARIETY", "גיוון"), ("SIGNIFICANCE", "משמעות"), ("CONNECTION", "קשר ואהבה"),
         ("GROWTH", "צמיחה"), ("CONTRIBUTION", "תרומה")]
def sc_pyramid(c, t, S):
    y = head(c, t, S, S.get("y", 300)); t0 = S["t0"]
    base_y = 1300; th = 118; gap = 12; wb = 920; wt = 330
    for k, (en, he) in enumerate(TIERS):
        tk = S["times"].get(f"n{k}", (t0 + 0.3 + 0.1 * k) if S.get("all_on") else 1e9); a, s = PP(t, tk, S, bounce=1.4)
        y1 = base_y - k * (th + gap); y0 = y1 - th
        wl = lerp(wb, wt, k / 5); wu = lerp(wb, wt, (k + 0.9) / 5)
        spirit = k >= 4
        if a <= 0.01:
            c.move_to(540 - wl / 2, y1); c.line_to(540 + wl / 2, y1); c.line_to(540 + wu / 2, y0); c.line_to(540 - wu / 2, y0); c.close_path()
            sa(c, P["silver"], 0.35 * St.a); c.fill(); continue
        c.save(); c.translate(540, (y0 + y1) / 2); c.scale(1, s); c.translate(-540, -(y0 + y1) / 2)
        c.move_to(540 - wl / 2, y1); c.line_to(540 + wl / 2, y1); c.line_to(540 + wu / 2, y0); c.line_to(540 - wu / 2, y0); c.close_path()
        dim = 1.0 - 0.55 * ramp(t, M(S, "dim", 1e9), M(S, "dim", 1e9) + 0.4) * (0 if spirit else 1)
        sa(c, P["gold"] if spirit else P["navy"], a * dim); c.fill()
        T(c, en, 40 if k < 4 else 34, 540, (y0 + y1) / 2 - 14, P["white"], a, 1, 900, maxw=wu - 40)
        T(c, he, 30, 540, (y0 + y1) / 2 + 26, LIGHT_HE if not spirit else P["white"], a, 1, 700, maxw=wu - 40)
        c.restore()
    for key, en, he, col, yy in (("lab_p", "NEEDS OF THE PERSONALITY", "צורכי האישיות", "navy", base_y + 50),
                                 ("lab_s", "NEEDS OF THE SPIRIT", "צורכי הנשמה", "gold", base_y - 6 * (th + gap) - 40)):
        tk = M(S, key, 1e9); a, s = PP(t, tk, S)
        if a > 0.01:
            pill(c, en, 34, 540, yy, P[col], P["white"], a, s, w=800)
            T(c, he, 34, 540, yy + (62 if key == "lab_p" else -62), P["blue"] if col == "navy" else P["gold_text"], a, s, 700)
    for key, en, he, col in (("survive", "SURVIVE", "לשרוד", "navy"), ("fulfilled", "FULFILLED", "להתמלא", "gold_text")):
        tk = M(S, key, 1e9); a, s = PP(t, tk, S, bounce=1.8)
        if a > 0.01 and not (key == "survive" and M(S, "fulfilled", 1e9) <= t):
            T(c, en, 74, 540, base_y + 195, P[col], a, s, 900); T(c, he, 42, 540, base_y + 252, P["blue"], a, s, 700)

# ------------------------------------------------------------------ the closing question on silver
def sc_question(c, t, S):
    t0 = S["t0"]; br = 1 + 0.01 * math.sin(t * 2.4)
    y = 620
    a, s = PP(t, t0 + 0.05, S); h = block_h(S["en"], 92, 900, 940, 3)
    block(c, S["en"], 92, 540, y + h / 2, P["navy"], a, s * br, hl=P["gold_text"], maxw=940, max_lines=3); y += h + 20
    a, s = PP(t, t0 + 0.2, S); box(c, 540 - 130 * a, y, 260 * a, 7, 3, P["gold"], a); y += 50
    if S.get("he"):
        hh = block_h(S["he"], 56, 700, 940, 2); a, s = PP(t, t0 + 0.3, S)
        block(c, S["he"], 56, 540, y + hh / 2, P["blue"], a, s, w=700, maxw=940, max_lines=2); y += hh + 50
    a, s = PP(t, t0 + 0.6, S)
    T(c, S.get("sub", "Tell me in the comments"), 50, 540, y + 20, P["navy"], a, s, 800)
    T(c, S.get("sub_he", "כתבו לי בתגובות"), 40, 540, y + 85, P["blue"], a, s, 700)
    T(c, S.get("follow", "Follow *@noamroz__*"), 46, 540, y + 175, P["navy"], a, s, 800, hl=P["gold_text"])

# ------------------------------------------------------------------ fact card on silver (study + source)
def sc_fact(c, t, S):
    y = head(c, t, S, S.get("y", 360)); t0 = S["t0"]
    tk = M(S, "card", t0 + 0.4); a, s = PP(t, tk, S, bounce=1.4)
    if a > 0.01:
        ch = S.get("card_h", 560); y0 = max(y + 20, (1450 + y - ch) / 2)
        c.save(); c.translate(540, y0 + ch / 2); c.scale(s, s); c.translate(-540, -(y0 + ch / 2))
        shadow_box(c, 90, y0, 900, ch, 36, P["navy"], a)
        box(c, 90, y0, 900, 14, 7, P["gold"], a)
        if S.get("tag"): T(c, S["tag"], 36, 540, y0 + 80, P["gold2"], a, 1, 800, maxw=820)
        hb = block_h(S["en"], 70, 900, 800, 3)
        block(c, S["en"], 70, 540, y0 + ch / 2 - 10, P["white"], a, 1, hl=P["gold2"], maxw=800, max_lines=3)
        if S.get("he"): block(c, S["he"], 44, 540, y0 + ch / 2 + hb / 2 + 50, LIGHT_HE, a, 1, w=700, maxw=800, max_lines=2)
        c.restore()
    src_line(c, t, S, light=False)
