"""rk_stage.py: reelkit split into a local prep stage (voice chain, SSE timing, timeline, mix) and a render-only stage.
  prep   SPEC SSE_PREFIX OUT [--preview]   -> OUT/vo.wav, OUT/timing.json, OUT/mix.wav, OUT/preview.png
  render SPEC OUT/timing.json OUT/mix.wav OUT.mp4   (cloud: frames + the local mix, no TTS / ASR)"""
import os, sys, json, time
sys.path.insert(0, os.path.join("/home/claude", "reelkit"))
def prep(spec_p, pre, out, preview):
    import voice, render as RD, mix as MX, make_reel_sse as MRS
    os.makedirs(out, exist_ok=True)
    spec = RD.load_spec(spec_p); sdir = os.path.dirname(os.path.abspath(spec_p))
    sp = spec["script"]; sp = sp if os.path.isabs(sp) else os.path.join(sdir, sp)
    lines = voice.read_script(sp); r = MRS.sse_process(voice, pre, lines, print)
    keep = [k - 1 for k in spec["use_lines"]] if spec.get("use_lines") else None
    vo, tim = voice.select(r["vo"], r["timing"], keep, gap_max=spec.get("gap_max", 0.6), gap_new=spec.get("gap_new", 0.45))
    voice.write(out, vo, tim, r["report"])
    R = RD.Reel(spec, tim); print("T_END", R.T_END, "warn", R.warn)
    RD.preview(R, R.keytimes(), f"{out}/preview.png")
    if preview: return
    last = R.scenes[-1]; end_at = last["times"].get("keyword", last["t0"]) if last["type"] == "cta" else R.T_END - 2.0
    bed = MX.bed(spec.get("music", "doc_piano"), R.T_END, end_at); ev = [(tt, k, 0.0) for tt, k in R.sfx_events()]
    MX.mix(vo, R.T_END, bed, ev, f"{out}/mix.wav", music_db=spec.get("music_db", -17.0), log=print)
def render(spec_p, tim_p, wav, mp4):
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "rk"))
    import render as RD
    R = RD.Reel(RD.load_spec(spec_p), json.load(open(tim_p)))
    v = RD.render_video(R, wav, mp4, log=print); print("rendered", v["sec"], "s", v["frames"], "frames")
if __name__ == "__main__":
    a = sys.argv[1:]
    if a[0] == "prep": prep(a[1], a[2], a[3], "--preview" in a)
    else: render(*a[1:5])
