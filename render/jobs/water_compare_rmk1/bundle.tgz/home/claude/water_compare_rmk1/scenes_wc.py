"""water_compare_rmk1 scenes (1 Nov 2026): the daily_1101 house scenes (dark keynote stage, photo, label, circular loop)
plus two scenes for the water remake:
- sc_wmap: dark map of Israel and its neighbours. mode "count" (hook): a value pill per country (flag + count-up number,
  Israel in yellow), with a leader line to the country. mode "pipes": zoomed on Israel, animated water lines from the
  coast to Jordan, the Palestinian Authority (West Bank) and Gaza, each label popping on its spoken word.
  House map rules: whole land of Israel incl. Golan in gold, West Bank and Gaza a slightly different gold, Green Line green.
- sc_card: a country scorecard, 4 rows x 3 columns (metric, country, Israel), the same 4 metrics on every card,
  "no data" where nothing is sourced, plus one headline fact under the country name."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))
from shapely.geometry import Polygon as _Poly

GOLDL = kit.hx("#C9A24A"); GOLDD = kit.hx("#A8853A"); SEA = (0.05, 0.12, 0.24); LAND = (0.15, 0.23, 0.40)
BORD = (0.35, 0.45, 0.62); GREEN = (46 / 255, 204 / 255, 113 / 255); GREY = (0.72, 0.77, 0.85)
GOLAN = _Poly([(35.62, 33.25), (35.628, 33.278), (35.704, 33.306), (35.715, 33.331), (35.79, 33.335), (35.83, 33.30),
               (35.82, 33.26), (35.83, 33.20), (35.815, 33.14), (35.82, 33.10), (35.85, 33.04), (35.87, 32.97), (35.88, 32.90),
               (35.87, 32.83), (35.84, 32.76), (35.836, 32.729), (35.791, 32.754), (35.683, 32.708), (35.644, 32.69),
               (35.64, 32.82), (35.635, 32.90), (35.62, 33.0), (35.60, 33.1), (35.60, 33.2)])
def _flag(iso): return "".join(chr(0x1F1E6 + ord(ch) - 65) for ch in iso.upper())
def _ring_path(c, pts):
    c.move_to(*pts[0])
    for q in pts[1:]: c.line_to(*q)
    c.close_path()

def _wbase(view, box_):
    G = geo(); mv = MapView(view, box_); s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(s)
    x0, y0, x1, y1 = box_
    bc.rectangle(x0, y0, x1 - x0, y1 - y0); sa(bc, SEA); bc.fill()
    bc.rectangle(x0, y0, x1 - x0, y1 - y0); bc.clip()
    for k, v in G.items():
        rg = mv.rings(v["g"], 0.5)
        if not rg: continue
        _path(bc, rg); sa(bc, GOLDL if k == "IL" else GOLDD if k == "PS" else LAND); bc.fill_preserve()
        sa(bc, BORD); bc.set_line_width(1.4); bc.stroke()
    pts = [mv.P(x, y) for x, y in GOLAN.exterior.coords]; _ring_path(bc, pts); sa(bc, GOLDL); bc.fill()
    if "PS" in G:
        rg = mv.rings(G["PS"]["g"], 0.3)
        if rg: _path(bc, rg); sa(bc, GREEN); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
    return mv, s

def _vpill(c, t, S, it, mv, tin, hook):
    """flag + number pill with a leader line to (lon, lat); counts up from 0 over 1.2 s"""
    a, s = (1.0, 1.0) if hook else PP(t, tin, S, s0=0.5, bounce=1.4)
    if a <= 0.01: return
    u = 1.0 if hook else ease(min(1.0, max(0.0, (t - max(0.0, tin)) / 1.2)))   # hook: final values at frame 0 (and on the loop frame)
    hl = it.get("hl"); px, py = it["px"]; ax, ay = mv.P(*it["at_ll"])
    sa(c, YEL if hl else WHITE, 0.85 * a); c.set_line_width(4); c.move_to(ax, ay); c.line_to(px, py); c.stroke()
    circ(c, ax, ay, 9, YEL if hl else WHITE, a)
    if hl:   # pulsing ring on Israel: motion from frame 0
        ph = (t * 0.9) % 1.0; circ(c, ax, ay, 14 + 46 * ph, YEL, 0.55 * (1 - ph) * a)
        s = s * (1.0 + 0.035 * math.sin(t * 4.0))
    v = it["v"] * u; txt = f"{v:,.0f}"
    sz = 74 if hl else 62; f = kit.font(sz, 900); tw = f.getlength(txt) + 22 + kit.font(38, 800).getlength("m³")
    pw = tw + 150; ph = sz * 1.45
    c.save(); c.translate(px, py); c.scale(s, s)
    sa(c, (0, 0, 0), 0.30 * a); rr(c, -pw / 2 + 4, -ph / 2 + 10, pw, ph, ph / 2); c.fill()
    sa(c, YEL if hl else INK, (1.0 if hl else 0.92) * a); rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.fill()
    sa(c, WHITE if not hl else INK, 0.6 * a); c.set_line_width(3); rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.stroke()
    c.restore()
    draw_emoji(c, _flag(it["flag"]), px - pw / 2 * s + 58 * s, py, 64 * s, a, 1.0)
    col_ = RD.c255(INK if hl else WHITE)
    kit.tx(c, txt, sz * s, px - pw / 2 * s + 108 * s, py + 3, w=900, col=col_, a=a, shadow=False, maxw=600, anchor="l")
    kit.tx(c, "m³", 38 * s, px - pw / 2 * s + 108 * s + f.getlength(txt) * s + 12 * s, py + 10, w=800, col=col_, a=a, shadow=False, maxw=120, anchor="l")
    if it.get("en"):
        kit.tx(c, it["en"], 40 * s, px, py + ph / 2 * s + 30, w=800, col=RD.c255(YEL if hl else WHITE), a=a, shadow=True, maxw=500)

def _flow(c, t, mv, p0, p1, tin, lift=0.35):
    """animated water line from p0 to p1 (lon, lat): grows over 0.7 s, then dashes run along it"""
    if t < tin - 0.02: return
    g = ease(min(1.0, (t - tin) / 0.7))
    (x0, y0), (x1, y1) = mv.P(*p0), mv.P(*p1)
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2 - lift * math.hypot(x1 - x0, y1 - y0)
    pts = []
    for i in range(41):
        u = g * i / 40; pts.append(((1 - u) ** 2 * x0 + 2 * (1 - u) * u * mx + u * u * x1, (1 - u) ** 2 * y0 + 2 * (1 - u) * u * my + u * u * y1))
    c.set_line_cap(cairo.LINE_CAP_ROUND)
    sa(c, (0.02, 0.06, 0.14), 0.6); c.set_line_width(22); c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.stroke()
    sa(c, SKY, 0.95); c.set_line_width(14); c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.stroke()
    c.set_dash([4, 26], -(t * 90) % 30); sa(c, WHITE, 0.95); c.set_line_width(8); c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.stroke(); c.set_dash([])
    if g >= 1.0:
        r = 16 + 6 * math.sin(t * 5); circ(c, x1, y1, r, SKY, 0.95); circ(c, x1, y1, r * 0.45, WHITE, 1.0)

def sc_wmap(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); _stage_bg(c, t, S)
    box_ = tuple(S.get("box", (0, 600, W, 1395)))
    if "_mv" not in S: S["_mv"], S["_base"] = _wbase(S["view"], box_)
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a0 = 1.0 if hook else RD.fade_in(t, t0, S, 0.3)
    c.save(); c.rectangle(x0, y0, x1 - x0, y1 - y0); c.clip()
    u = min(1.0, max(0.0, (t - t0) / max(1.0, ((S["t1"] or t0 + 4) - t0)))); z = lerp(1.0, S.get("zoom", 1.05), ease(u))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(a0)
    if S.get("mode") == "pipes":
        for k, fl in enumerate(S["flows"]):
            _flow(c, t, mv, fl["from"], fl["to"], S["times"].get(f"f{k}", t0 + 0.5 + 0.8 * k), fl.get("lift", 0.35))
    c.restore()
    # soft top/bottom fades so the map melts into the stage
    for ya, yb, up in ((y0, y0 + 90, True), (y1 - 90, y1, False)):
        g = cairo.LinearGradient(0, ya, 0, yb)
        g.add_color_stop_rgba(0, 0.03, 0.06, 0.14, 1.0 if up else 0.0); g.add_color_stop_rgba(1, 0.03, 0.06, 0.14, 0.0 if up else 1.0)
        c.rectangle(0, ya, W, yb - ya); c.set_source(g); c.fill()
    if S.get("mode") == "pipes":
        for k, fl in enumerate(S["flows"]):
            tk = S["times"].get(f"f{k}", t0 + 0.5 + 0.8 * k) + 0.5; a2, s2 = PP(t, tk, S)
            if a2 > 0.01:
                px, py = fl["label_px"]; px = cx + (px - cx) * z; py = cy + (py - cy) * z
                pill(c, fl["en"], 54, px, py, INK, WHITE, a2, s2, outline=SKY, w=900, padh=1.35)
    else:
        for k, it in enumerate(S["items"]):
            tin = S["times"].get(f"i{k}", t0 + 0.08 * k)
            _vpill(c, t, S, it, mv, tin, hook and tin <= RD.HOOK_GRACE)
    # headline
    if S.get("en"):
        a1, s1 = (1.0, 1.0) if hook else PP(t, t0 + 0.05, S)
        br = 1.0 + 0.012 * math.sin(t * 2.2) if hook else 1.0
        _wtext(c, S["en"], S.get("size", 128), S.get("en_y", 455), a=a1, sc=s1 * br, max_lines=2)
    if S.get("unit"):
        kit.tx(c, S["unit"], 44, 540, S.get("unit_y", 625), w=800, col=RD.c255(WHITE), a=0.9 * a0, shadow=True, maxw=1000)
    la = 1.0 if hook else RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1428, la)

def sc_card(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S)
    a1, s1 = PP(t, t0 + 0.05, S)
    f = kit.font(108, 900); nm = S["name"]; tw = f.getlength(nm); xf = 540 - (tw + 140) / 2
    draw_emoji(c, _flag(S["flag"]), xf + 55, 395, 110, a1, s1)
    kit.tx(c, nm, 108, xf + 140, 400, w=900, col=RD.c255(WHITE), a=a1, shadow=True, maxw=900, anchor="l")
    ah, sh = PP(t, S["times"].get("head", t0 + 0.4), S)
    _wtext(c, S["head"], 70, 560, a=ah, sc=sh, max_lines=2, maxw=990)
    # table
    ty = 720; CX, IX = 700, 930
    ahd = RD.fade_in(t, t0 + 0.25, S)
    kit.tx(c, S.get("short", nm), 46, CX, ty, w=900, col=RD.c255(YEL), a=ahd, shadow=False, maxw=230)
    draw_emoji(c, _flag("IL"), IX - 70, ty, 46, ahd, 1.0)
    kit.tx(c, "Israel", 46, IX + 20, ty, w=900, col=RD.c255(SKY), a=ahd, shadow=False, maxw=200)
    for k, row in enumerate(S["rows"]):
        y = ty + 95 + 150 * k; tk = t0 + 0.35 + 0.3 * k
        a, s = PP(t, tk, S, s0=0.8, bounce=1.0)
        if a <= 0.01: continue
        sa(c, WHITE, 0.07 * a); rr(c, 30, y - 62, 1020, 128, 26); c.fill()
        kit.tx(c, row["en"], 52, 62, y - (14 if row.get("sub") else 0), w=900, col=RD.c255(WHITE), a=a, shadow=False, maxw=470, anchor="l")
        if row.get("sub"): kit.tx(c, row["sub"], 36, 62, y + 34, w=700, col=RD.c255(GREY), a=a, shadow=False, maxw=470, anchor="l")
        for x, v, cc in ((CX, row["c"], YEL), (IX, row["il"], SKY)):
            nd = v == "no data"
            kit.tx(c, v, 44 if nd else 58, x, y + 2, w=700 if nd else 900, col=RD.c255(GREY if nd else cc), a=a, shadow=False, maxw=225)
    la = RD.fade_in(t, t0 + 0.5, S)
    if S.get("source"): _label(c, S["source"], 1428, la)

def sc_hook(c, t, S):
    S["hook"] = True; sc_wmap(c, t, S)
