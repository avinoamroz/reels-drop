"""Daily scenes, 31 Oct 2026: ENGLISH ONLY, BIG TEXT, FULL SCREEN, CIRCULAR (Noam, 30 to 31 Oct).
Loaded by reelkit as the spec's scene_module, so the sc_* functions here replace the built-in ones of the same name.
- Layout: content uses the whole width (x 20..1060), headings 100 px, numbers 250 px. Key text stays between y 250 and
  y 1580 (top ~220 px and bottom ~330 px kept free for the IG UI). Sources sit under the content at y 1428 (34 px),
  subtitles at y 1530 (54 px).
- No Hebrew is drawn: any *_he / he field is ignored (build.py also strips them).
- Circular: the last 0.5 s cross-fade into the exact frame 0 (the last frame equals frame 0), and the music bed is cut on
  whole bars from bar 2 of the bed (past its fade-in) and time-fitted to the reel, so the loop lands on a downbeat.
Scene types: title, big_number, cards_grid, map_highlight, city_map, rows."""
import math, re
import numpy as np
import cairo
import render as RD
import kit
from render import P, T, pill, PP, fade_in, MapView, geo, _path, col, block, block_h, shadow_box, icon_of, draw_emoji, box, count, fmt, clean
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, FPS

TOP = 345; CB = 1400; X0, X1 = 20, 1060
RD.SUB_Y = 1530; RD.SOURCE_Y = 1428; RD.CONTENT_BOTTOM = CB
_subs = getattr(RD, "_subs_orig", RD.sub_surfs); RD._subs_orig = _subs
RD.sub_surfs = lambda pieces, sz=54, maxw=1000: _subs(pieces, sz, maxw)

def heading(c, t, S, y=TOP):
    en = S.get("title") or S.get("heading")
    if not en: return y - 30
    a, s = PP(t, S["t0"] + 0.05, S); h1 = block_h(en, 100, 900, 1010, 2)
    block(c, en, 100, 540, y + h1 / 2, P["navy"], a, s, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=2)
    return y + h1 + 30
RD.heading = heading

# ------------------------------------------------------------------ circular: last 0.5 s fade into frame 0
_draw = getattr(RD.Reel, "_draw_orig", RD.Reel.draw); RD.Reel._draw_orig = _draw
def _draw_loop(self, c, t):
    L = float(self.spec.get("loop_fade", 0.5))
    if t < self.T_END - L - 1e-6: return _draw(self, c, t)
    if not hasattr(self, "_f0"):
        s0 = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); _draw(self, cairo.Context(s0), 0.0); s0.flush(); self._f0 = s0
    _draw(self, c, t)
    u = min(1.0, max(0.0, (t - (self.T_END - L)) / max(1e-3, L - 1.0 / FPS)))
    c.set_source_surface(self._f0, 0, 0); c.paint_with_alpha(ease(u))
RD.Reel.draw = _draw_loop

# ------------------------------------------------------------------ circular: music bed cut on whole bars
try:
    import mix as MX
    BPM = {"journey": 100, "doc_piano": 86, "warm": 96, "bounce": 118, "skip": 104}
    _bed = getattr(MX, "_bed_orig", MX.bed); MX._bed_orig = _bed
    def bed_loop(name, dur, end_at=None):
        if name not in BPM: return _bed(name, dur, end_at)
        bar = 240.0 / BPM[name]; nb = max(4, int(round(dur / bar))); L = nb * bar; off = 2 * bar
        raw = _bed(name, off + L + 4.0, off + L + 4.0)          # long render, no ending inside the cut
        seg = raw[:, int(round(off * MX.SR)):int(round((off + L) * MX.SR))]
        n = int(dur * MX.SR); x = np.linspace(0, seg.shape[1] - 1, n)   # time-fit (under 3 %) so the cut ends on a downbeat
        out = np.vstack([np.interp(x, np.arange(seg.shape[1]), ch) for ch in seg])
        f = int(0.012 * MX.SR); out[:, :f] *= np.linspace(0, 1, f); out[:, -f:] *= np.linspace(1, 0, f)
        return out / (np.abs(out).max() + 1e-12)
    MX.bed = bed_loop
except Exception as e:   # preview without mix still works
    print("bed_loop not installed:", e)

# ------------------------------------------------------------------ scenes
def sc_title(c, t, S):
    en = S.get("en"); em = icon_of(S); size = S.get("size", 118)
    h_en = block_h(en, size, 900, 1010, 3); total = (270 if em else 0) + h_en + 40
    y = max(300, (TOP + CB) / 2 - total / 2); t0 = S["t0"]
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 120 + 10 * math.sin(t * 2.6), 230, a, s * (1 + 0.03 * math.sin(t * 3.1))); y += 270
    a, s = PP(t, t0 + 0.08, S); breath = 1 + 0.012 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, size, 540, y + h_en / 2, P["navy"], a, s * breath, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=3); y += h_en
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 380 * u, y + 10, 760 * u, 14, 7, P["gold"], a)
    RD.source(c, t, S)

def sc_big_number(c, t, S):
    y = heading(c, t, S); steps = S["steps"]; ts = S["times"]["steps"]
    cy = max(y + 340, 820); x0, x1, y0, y1 = X0 + 10, X1 - 10, cy - 320, cy + 320
    a, s = PP(t, S["t0"] + 0.1, S, s0=0.6, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
    shadow_box(c, x0, y0, x1 - x0, y1 - y0, 34, P["card"], stroke=P["navy"], sw=7)
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]; dec = st.get("decimals", 0)
    hk = S.get("hook") and ts[0] <= RD.HOOK_GRACE
    if k == 0: v = st["value"] if hk else count(t, ts[0], st.get("dur", 1.2), st.get("from", 0), st["value"])
    else:
        pv = steps[k - 1]["value"]; big = max(abs(pv), abs(st["value"])) / max(1e-9, min(abs(pv), abs(st["value"]))) > 20
        v = count(t, ts[k], st.get("dur", 1.3), pv, st["value"], log=big)
    if t < ts[0] - 0.05 and not hk: v = st.get("from", 0)
    num = f"{v:.{dec}f}" if S.get("year") else fmt(v, dec)
    lab = clean(f"{st.get('prefix', '')}{num}{st.get('suffix', '')}")
    T(c, lab, S.get("size", 250), 540, cy - 80, col(st.get("color"), "blue"), 1.0, 1.0, 900, maxw=960)
    pa = ramp(t, ts[k] - 0.05, ts[k] + 0.25) if k else 1.0
    hl_ = block_h(st.get("label", ""), 76, 800, 940, 2)
    block(c, st.get("label", ""), 76, 540, cy + 130 + hl_ / 2 - 38, P["navy"], pa, 1.0, 800, hl=P["gold_text"], maxw=940, max_lines=2)
    c.restore(); St.a = old
    if S.get("note"):
        a2, s2 = PP(t, S["times"].get("note", S["t0"] + 1.5), S, bounce=2.4)
        pill(c, S["note"], 58, 540, min(y1 + 105, CB - 30), col(S.get("note_color"), "navy"), P["white"], a2, s2, outline=P["gold"])
    RD.source(c, t, S)

def sc_cards_grid(c, t, S):
    y = heading(c, t, S) + 10; cards = S["cards"]; ts = S["times"]["cards"]; n = len(cards)
    cols = S.get("cols", 2 if n <= 4 else 3); rows = -(-n // cols)
    gap = 24; WW = X1 - X0 - 20; cw = (WW - gap * (cols - 1)) / cols; avail = CB - y - 10
    ch = min(cw * 1.5, (avail - gap * (rows - 1)) / rows)
    for k, cd in enumerate(cards):
        r_, q = divmod(k, cols); in_row = min(cols, n - r_ * cols)
        x0 = X0 + 10 + (WW - (in_row * cw + (in_row - 1) * gap)) / 2 + q * (cw + gap); y0 = y + r_ * (ch + gap)
        a, s = PP(t, ts[k], S, s0=0.5, bounce=1.6)
        if a <= 0.01: continue
        cx, cy = x0 + cw / 2, y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
        shadow_box(c, x0, y0, cw, ch, 28, P["card"], stroke=col(cd.get("color"), "navy"), sw=5)
        parts = []; isz = min(cw, ch) * 0.34
        if icon_of(cd): parts.append(("i", isz + 10))
        if cd.get("value"): parts.append(("v", 120))
        hl_ = block_h(cd.get("label"), 58, 800, cw - 36, 3); parts.append(("l", hl_))
        yy = cy - sum(p[1] for p in parts) / 2
        for kind, hgt in parts:
            if kind == "i": draw_emoji(c, icon_of(cd), cx, yy + hgt / 2, isz, rot=0.04 * math.sin(t * 2 + k))
            if kind == "v": T(c, cd["value"], min(110, cw * 0.26), cx, yy + hgt / 2, col(cd.get("value_color") or cd.get("color"), "blue"), 1, 1, 900, maxw=cw - 30)
            if kind == "l": block(c, cd.get("label"), 58, cx, yy + hgt / 2, P["navy"], 1, 1, 800, maxw=cw - 36, max_lines=3)
            yy += hgt
        c.restore(); St.a = old
    RD.source(c, t, S)

def sc_rows(c, t, S):
    y = heading(c, t, S); items = S["items"]; n = len(items)
    rh = min(300, (CB - y - 20) / max(1, n)); bh = rh - 26
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2)
    for k, it in enumerate(items):
        tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        if t < tk - 0.07 and not hk: continue
        a = 1.0 if hk else fade_in(t, tk - 0.07, S, 0.2); u = 1.0 if hk else ease((t - tk + 0.07) / 0.35)
        yy = y + rh * k + rh / 2; dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, X0 + 10, yy - bh / 2, X1 - X0 - 20, bh, min(44, bh / 2.6), P["card"], stroke=col(it.get("color"), "silver"), sw=4, sh=6)
        em = icon_of(it); xt = 540
        if em: draw_emoji(c, em, 120, yy, min(100, bh * 0.5)); xt = 590
        block(c, it.get("en", ""), min(74, bh * 0.36), xt, yy, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=840 if em else 980, max_lines=2)
        c.restore(); St.a = old
    RD.source(c, t, S)

ISRAEL_VIEW = [33.9, 29.35, 36.1, 33.45]
def _base(S, view, box_, G):
    keep = St.a; St.a = 1.0
    mv = MapView(view, box_); base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
    bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
    for k, v in G.items():
        rg = mv.rings(v["g"], 0.6)
        if not rg: continue
        _path(bc, rg); sa(bc, P["gold"] if k in ("IL", "PS") else P["land"]); bc.fill_preserve()
        sa(bc, P["border"]); bc.set_line_width(1.6); bc.stroke()
    if "PS" in G:   # the Green Line in green (house rule)
        rg = mv.rings(G["PS"]["g"], 0.3)
        if rg: _path(bc, rg); sa(bc, P["green"]); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
    St.a = keep; return mv, base

def sc_city_map(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB)
    if "_mv" not in S: S["_mv"], S["_base"] = _base(S, S.get("view", ISRAEL_VIEW), box_, geo())
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"])))
    z = lerp(1.0, S.get("zoom", 1.08), ease(u)); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    shown = []
    for k, p in enumerate(S.get("points", [])):
        tk = S["times"].get(f"p{k}", S["t0"] + 0.4 + 0.8 * k); hk = S.get("hook") and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); cc = col(p.get("color"), "navy")
        pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 22 + 80 * (1 - pr), P["white"], 0.5 * pr * uu)
        circ(c, px, py, 24 * uu, P["white"], uu); circ(c, px, py, 16 * uu, cc, uu)
        shown.append((k, p, tk, px, py))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    for k, p, tk, px, py in shown:
        px = cx + (px - cx) * z; py = cy + (py - cy) * z
        dx = 1 if p.get("side", "r") == "r" else -1
        lx = p.get("lx") or (px + dx * 240); ly = py + p.get("dy", 0)
        hw = max(kit.font(80, 900).getlength(clean(p.get("value") or "").replace("*", "")) * 0.5 + 60,
                 kit.font(56, 800).getlength(clean(p.get("en") or "").replace("*", "")) * 0.5 + 50)
        lx = min(max(lx, X0 + 10 + hw), X1 - 10 - hw) if hw < 500 else 540
        a2, s2 = PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        c.save(); sa(c, P["navy"], 0.8 * a2); c.set_line_width(5); c.move_to(px, py); c.line_to(lx - dx * 150, ly); c.stroke(); c.restore()
        ny = ly
        if p.get("value"): pill(c, p["value"], 80, lx, ly - 50, P["navy"] if p.get("color") in (None, "gold") else col(p.get("color")), P["white"], a2, s2, outline=P["gold"], w=900, padh=1.3); ny = ly + 50
        if p.get("en"): pill(c, p["en"], 56, lx, ny + 14, P["white"], P["navy"], a2, s2, outline=col(p.get("color"), "navy"), w=800, padh=1.3)
    St.a = old
    RD.source(c, t, S)

def sc_map_highlight(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB); G = geo()
    if "_mv" not in S:
        view = S.get("view") or RD.auto_view([h["iso"] for h in S["highlights"]] + ["IL"], box_, 0.12)
        S["_mv"], S["_base"] = _base(S, view, box_, G)
        S["_hl"] = [(S["_mv"].rings(G[h["iso"]]["g"], 0.4), h) for h in S["highlights"] if h["iso"] in G]
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"]))); z = lerp(1.0, S.get("zoom", 1.08), ease(u))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    ts = S["times"]["highlights"]; labels = []
    for k, (rg, h) in enumerate(S["_hl"]):
        hk = S.get("hook") and ts[k] <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, ts[k] - 0.05, ts[k] + 0.3)
        if uu <= 0.01: continue
        _path(c, rg); sa(c, col(h.get("color"), "red"), 0.88 * uu); c.fill_preserve(); sa(c, P["white"], uu); c.set_line_width(2.4 / z); c.stroke()
        labels.append((k, h, uu))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    if "_lab" not in S:
        placed = []; S["_lab"] = {}
        for k, (rg, h) in enumerate(S["_hl"]):
            lon, lat = h.get("at_lonlat") or (lambda p: (p.x, p.y))(RD._main_poly(G[h["iso"]]["g"]).representative_point())
            px, py = mv.P(lon, lat); px = min(max(px, 300), 780); py = min(max(py + h.get("dy", 0), y0 + 70), y1 - 90)
            for dy in (0, 130, -130, 260, -260):
                if not any(abs(q[1] - (py + dy)) < 115 and abs(q[0] - px) < 420 for q in placed): py += dy; break
            placed.append((px, py)); S["_lab"][k] = (px, py)
    for k, h, uu in labels:
        if h.get("label") is False: continue
        px, py = S["_lab"][k]; px = cx + (px - cx) * z; py = cy + (py - cy) * z
        a2, s2 = PP(t, ts[k] + 0.1, S)
        pill(c, h.get("en") or G[h["iso"]]["name"], 54, px, py, P["white"], P["navy"], a2, s2, outline=col(h.get("color"), "red"), w=800, padh=1.35)
    St.a = old
    RD.source(c, t, S)

# ================================================================== PHOTO BEATS (v2, 31 Oct 2026, Noam: "add real photos")
# sc_photo: a real photo full-bleed (or a large rounded panel over a blurred copy), slow Ken Burns 1.0 -> 1.08 with cubic
# easing, a dark navy gradient so white text stays readable, the beat's existing big text on top, and a small credit
# label (36 px) at the bottom. Fields: src, credit, title, en, steps [{value, label, at, color}], source, mode, focus, size.
from PIL import Image, ImageFilter, ImageOps
WHITE = (1.0, 1.0, 1.0); YEL = kit.hx("#FFC93C"); SKY = kit.hx("#45A4DD"); INK = (0.03, 0.07, 0.16)
def _ease3(u):
    u = min(1.0, max(0.0, u)); return 4 * u * u * u if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
_PH = {}
def _cover(path, w, h, fx=0.5, fy=0.5, blur=0):
    k = (path, int(w), int(h), fx, fy, blur)
    if k not in _PH:
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        im = ImageOps.fit(im, (int(w), int(h)), Image.LANCZOS, centering=(fx, fy))
        if blur: im = im.filter(ImageFilter.GaussianBlur(blur))
        _PH[k] = kit.pil2cairo(im.convert("RGBA"))
    return _PH[k]
def _wtext(c, s, sz, y, color=WHITE, hl=YEL, maxw=1000, max_lines=3, a=1.0, sc=1.0, src=False):
    """white multi-line text with the kit shadow, centred at y; returns its height"""
    if not s: return 0
    if max_lines == 1:
        while kit.font(sz, 900).getlength(RD.clean(s).replace("*", "")) > maxw and sz > 64: sz -= 4
    z, ls = RD.wrap(s, sz, 900, maxw, max_lines); step = z * 1.14; h = step * len(ls)
    if a <= 0.005 or abs(sc) < 1e-3: return h
    c.save(); c.translate(540, y); c.scale(sc, sc); c.translate(-540, -y)
    for k, l in enumerate(ls):
        kit.tx(c, RD.clean(l), z, 540, y - h / 2 + step * (k + 0.5), w=900 if not src else 700, col=RD.c255(color), a=a,
               hl=RD.c255(hl), shadow=True, src=src, maxw=maxw + 4)
    c.restore(); return h
def _label(c, s, y, a):
    """small credit / source label on a dark pill, 36 px"""
    s = RD.clean(s); f = kit.font(36, 700)
    while f.getlength(s) > 1000 and len(s) > 10: s = s[:-2]
    tw = f.getlength(s); sa(c, INK, 0.55 * a); rr(c, 540 - tw / 2 - 22, y - 27, tw + 44, 54, 27); c.fill()
    kit.tx(c, s, 36, 540, y, w=700, col=RD.c255(WHITE), a=0.92 * a, shadow=False, src=True, maxw=1004)
def sc_photo(c, t, S):
    t0 = S["t0"]; t1 = S["t1"] if S["t1"] is not None else t0 + 4.0
    u = _ease3((t - t0) / max(1.0, t1 + 0.25 - t0)); z = 1.0 + 0.08 * u
    fx, fy = S.get("focus", [0.5, 0.5]); a = St.a
    c.save()
    if S.get("mode") == "panel":
        bg = _cover(S["src"], W, H, fx, fy, blur=28)
        c.set_source_surface(bg, 0, 0); c.paint_with_alpha(a)
        sa(c, INK, 0.55); c.rectangle(0, 0, W, H); c.fill()
        im = Image.open(S["src"]); ar = im.width / im.height
        pw = 1040; ph = min(1000, pw / ar)
        if S.get("panel_h") and S["panel_h"] < ph: ph = S["panel_h"]; pw = min(1040, ph * ar)
        px, py = 540 - pw / 2, S.get("panel_y", 860) - ph / 2
        sa(c, (0, 0, 0), 0.35); rr(c, px + 4, py + 18, pw, ph, 36); c.fill()
        c.save(); rr(c, px, py, pw, ph, 36); c.clip()
        fg = _cover(S["src"], pw, ph, fx, fy); cx, cy = px + pw * fx, py + ph * fy
        c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
        c.set_source_surface(fg, px, py); c.paint_with_alpha(a); c.restore()
        sa(c, WHITE, 0.55); c.set_line_width(3); rr(c, px, py, pw, ph, 36); c.stroke()
    else:
        img = _cover(S["src"], W, H, fx, fy); cx, cy = W * fx, H * fy
        c.save(); c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
        c.set_source_surface(img, 0, 0); c.paint_with_alpha(a); c.restore()
        g = cairo.LinearGradient(0, 0, 0, H)
        for off, al in ((0.0, 0.80), (0.24, 0.42), (0.40, 0.30), (0.58, 0.42), (0.74, 0.70), (1.0, 0.92)):
            g.add_color_stop_rgba(off, INK[0], INK[1], INK[2], al * S.get("dim", 1.0) * a)
        c.set_source(g); c.paint()
    c.restore()
    y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 100, 0, max_lines=2, a=0) or 0
        _wtext(c, S["title"], 100, y + h1 / 2, a=a1, sc=s1, max_lines=2); y += h1 + 30
    if S.get("en"):
        a2, s2 = PP(t, t0 + 0.12, S); sz = S.get("size", 112)
        _wtext(c, S["en"], sz, S.get("en_y", 800), a=a2, sc=s2, max_lines=3)
    steps = S.get("steps") or []
    if steps:
        ts = [S["times"].get(f"s{i}", t0 + 0.3 + 1.6 * i) for i in range(len(steps))]; k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]
        a3, s3 = PP(t, ts[k], S, s0=0.6, bounce=1.4)
        cy = S.get("value_y", 840)
        _wtext(c, st["value"], S.get("vsize", 210), cy, color=YEL if st.get("color") != "white" else WHITE, a=a3, sc=s3, max_lines=1)
        if st.get("label"):
            _wtext(c, st["label"], 72, cy + 175, a=a3, sc=s3, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1352 if S.get("credit") else 1418, la)
    if S.get("credit"): _label(c, S["credit"], 1418, la)

# ================================================================== d01 additions (1 Nov 2026)
# - a headline label held on screen the whole reel (spec "label"), drawn on top of everything incl. the loop cross-fade,
#   so the last frame still equals frame 0
# - sc_stage: Apple-keynote dark stage, one big number (optional count-up) + one line, credit/source label
# - sc_river: "Which river? Which sea?" map quiz with a 3-2-1 counter, the Jordan + Mediterranean reveal and a
#   true-scale Belgium outline dropped over the land between the river and the sea
import json as _json
_draw_l = getattr(RD.Reel, "_draw_lbl_orig", RD.Reel.draw); RD.Reel._draw_lbl_orig = _draw_l
def _draw_label(self, c, t):
    _draw_l(self, c, t)
    s = self.spec.get("label")
    if not s: return
    keep = St.a; St.a = 1.0
    f = kit.font(40, 800); tw = f.getlength(s)
    sa(c, INK, 0.72); rr(c, 540 - tw / 2 - 34, 258 - 34, tw + 68, 68, 34); c.fill()
    sa(c, SKY, 0.95); c.set_line_width(3); rr(c, 540 - tw / 2 - 34, 258 - 34, tw + 68, 68, 34); c.stroke()
    kit.tx(c, s, 40, 540, 258, w=800, col=RD.c255(WHITE), a=1.0, shadow=False, maxw=1000)
    St.a = keep
RD.Reel.draw = _draw_label

def _stage_bg(c, t, S):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, 0.03, 0.06, 0.14); g.add_color_stop_rgb(1, 0.06, 0.12, 0.27)
    c.set_source(g); c.paint_with_alpha(St.a)
    x = 540 + 120 * math.sin(t * 0.35); y = 880 + 90 * math.cos(t * 0.28)
    rg = cairo.RadialGradient(x, y, 0, x, y, 720); rg.add_color_stop_rgba(0, SKY[0], SKY[1], SKY[2], 0.20 * St.a); rg.add_color_stop_rgba(1, SKY[0], SKY[1], SKY[2], 0)
    c.set_source(rg); c.paint()

def _fmt_step(st, u):
    if "num" not in st: return st["value"]
    v0 = st.get("from", 0); v = v0 + (st["num"] - v0) * ease(min(1.0, max(0.0, u)))
    d = st.get("dec", 0); s = f"{v:,.{d}f}"
    return st.get("prefix", "") + s + st.get("suffix", "")

def sc_stage(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S); y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 100, 0, max_lines=2, a=0) or 0
        _wtext(c, S["title"], 100, y + h1 / 2, a=a1, sc=s1, max_lines=2); y += h1 + 30
    if S.get("en"):
        a2, s2 = PP(t, t0 + 0.12, S); _wtext(c, S["en"], S.get("size", 112), S.get("en_y", 800), a=a2, sc=s2, max_lines=3)
    steps = S.get("steps") or []
    if steps:
        ts = [S["times"].get(f"s{i}", t0 + 0.3 + 1.6 * i) for i in range(len(steps))]
        k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]
        a3, s3 = PP(t, ts[k], S, s0=0.6, bounce=1.4)
        u = 1.0 if (S.get("hook") and ts[k] <= RD.HOOK_GRACE) else (t - ts[k]) / st.get("dur", 1.1)
        cy = S.get("value_y", 840)
        _wtext(c, _fmt_step(st, u), S.get("vsize", 230), cy, color=YEL if st.get("color") != "white" else WHITE, a=a3, sc=s3, max_lines=1)
        if st.get("label"): _wtext(c, st["label"], 72, cy + 190, a=a3, sc=s3, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)

# ------------------------------------------------------------------ river quiz map
_RG = {}
def _region():
    if not _RG:
        from shapely.geometry import shape
        d = _json.load(open(S_GEO)); _RG["rivers"] = {k: shape(v) for k, v in d["rivers"].items()}; _RG["lakes"] = {k: shape(v) for k, v in d["lakes"].items()}
    return _RG
S_GEO = "/home/claude/druze_syria_1102/geo_ds.json"
def _lines(g):
    return [g] if g.geom_type == "LineString" else [x for x in getattr(g, "geoms", []) if x.geom_type == "LineString"]
def sc_river(c, t, S):
    from shapely.geometry import Polygon
    from shapely import affinity
    G = geo(); R = _region(); box_ = (0, 560, W, 1640)
    if "_mv" not in S: S["_mv"] = MapView(S.get("view", [30.2, 27.6, 40.2, 35.6]), box_)
    mv = S["_mv"]; tm = S["times"]
    tq = tm.get("rev", 99); tb = tm.get("bel", 99)
    # zoom from region to the land once the answer is in
    zt = ease(min(1.0, max(0.0, (t - tq + 0.2) / 1.6)))
    cx0, cy0 = mv.P(35.2, 31.6); z = 1.0 + 1.1 * zt
    c.save(); c.rectangle(0, 0, W, H); sa(c, (0.05, 0.12, 0.24)); c.fill(); c.rectangle(0, 0, W, 240); sa(c, (0.15, 0.23, 0.40)); c.fill()
    c.translate(540, 960); c.scale(z, z); c.translate(-(540 + (cx0 - 540) * zt), -(960 + (cy0 - 960) * zt))
    for k, v in G.items():
        rg = mv.rings(v["g"], 0.5)
        if not rg: continue
        _path(c, rg); sa(c, kit.hx("#B8923F") if k in ("IL", "PS") else (0.15, 0.23, 0.40)); c.fill_preserve()
        sa(c, (0.35, 0.45, 0.62)); c.set_line_width(1.4 / z); c.stroke()
    if "PS" in G:
        rg = mv.rings(G["PS"]["g"], 0.2)
        if rg: _path(c, rg); sa(c, (46 / 255, 204 / 255, 113 / 255)); c.set_line_width(3.2 / z); c.set_dash([9 / z, 6 / z]); c.stroke(); c.set_dash([])
    for nm, lk in R["lakes"].items():
        if nm not in ("Dead Sea", "Sea of Galilee"): continue
        for p in ([lk] if lk.geom_type == "Polygon" else list(lk.geoms)):
            pts = [mv.P(x, y) for x, y in p.exterior.coords]; c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.close_path()
        sa(c, (0.05, 0.12, 0.24)); c.fill()
    pulse = 0.5 + 0.5 * math.sin(t * 7)
    for nm, g in R["rivers"].items():
        win = nm == "Jordan"
        if t < tq: colr, wdt, al = SKY, 7 + 3 * pulse, 1.0
        elif win: colr, wdt, al = YEL, 9, 1.0
        else: colr, wdt, al = SKY, 4, max(0.25, 1 - (t - tq) / 0.6)
        for ln in _lines(g):
            pts = [mv.P(x, y) for x, y in ln.coords]; c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]
            sa(c, colr, al); c.set_line_width(wdt / z); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
    # Belgium at true scale over the land
    if t > tb - 0.05 and "BE" in G:
        be = G["BE"]["g"]; be = max(be.geoms, key=lambda p: p.area) if be.geom_type == "MultiPolygon" else be
        k = math.cos(math.radians(50.6)) / math.cos(math.radians((mv.lat0 + mv.lat1) / 2))
        c0 = be.centroid; be = affinity.translate(affinity.scale(be, xfact=k, yfact=1.0, origin=c0), 35.15 - c0.x, 31.55 - c0.y)
        ub = ease(min(1.0, (t - tb) / 0.6))
        pts = [mv.P(x, y) for x, y in be.exterior.coords]; c.move_to(*pts[0]); [c.line_to(*q) for q in pts[1:]]; c.close_path()
        sa(c, WHITE, 0.22 * ub); c.fill_preserve(); sa(c, WHITE, 0.95 * ub); c.set_line_width(5 / z); c.stroke()
    c.restore()
    # labels (screen space)
    def lab(s, lon, lat, col_, a):
        x, y = mv.P(lon, lat); x = 540 + (x - (540 + (cx0 - 540) * zt)) * z; y = 960 + (y - (960 + (cy0 - 960) * zt)) * z
        if a > 0.01: pill(c, s, 50, min(max(x, 220), 860), y, P["navy"], P["white"], a, 1.0, outline=col_, w=800, padh=1.3)
    if t < tq:
        for s, lon, lat in (("Nile", 30.5, 29.6), ("Euphrates", 38.3, 34.9), ("Jordan", 36.4, 32.25)): lab(s, lon, lat, SKY, 1.0)
        for s, lon, lat in (("Mediterranean", 32.4, 33.6), ("Red Sea", 33.7, 29.2)): lab(s, lon, lat, SKY, 1.0)
    else:
        a = ramp(t, tq, tq + 0.3); am = ramp(t, tm.get("med", tq), tm.get("med", tq) + 0.3)
        lab("Jordan River", 35.95, 32.25, YEL, a * (1 - ramp(t, tb, tb + 0.3)))
        lab("Mediterranean", 34.25, 31.95, YEL, am * (1 - ramp(t, tb, tb + 0.3)))
    # countdown
    for i, key in enumerate(("c3", "c2", "c1")):
        tk = tm.get(key)
        if tk is None or t < tk - 0.05 or t > tk + 0.9 or t > tq: continue
        a3, s3 = PP(t, tk, S, s0=0.4, bounce=1.6); fa = a3 * (1 - ramp(t, tk + 0.6, tk + 0.9))
        circ(c, 540, 900, 190 * s3, INK, 0.78 * fa)
        _wtext(c, str(3 - i), 300, 900, color=YEL, a=a3 * (1 - ramp(t, tk + 0.6, tk + 0.9)), sc=s3, max_lines=1)
    # headline
    ah = 1.0 if t < tq else 1 - ramp(t, tq, tq + 0.3)
    if ah > 0.01: _wtext(c, S.get("title", ""), 120, 420, a=ah, max_lines=2)
    if t > tb:
        ab, sb = PP(t, tb + 0.2, S)
        _wtext(c, "Smaller than *Belgium*", 104, 430, a=ab, sc=sb, max_lines=2)
        _wtext(c, "~28,000 km² vs 30,689 km²", 64, 1300, a=ab, max_lines=1)
    if S.get("source") and t > tq: _label(c, S["source"], 1418, ramp(t, tq, tq + 0.4))

# ================================================================== druze_syria (2 Nov 2026)
# sc_dmap: full-bleed map of the Druze heartlands (Galilee, Carmel, Golan, Mount Lebanon, Jabal al-Druze / Sweida), the whole
#   land of Israel in gold incl. the Golan, West Bank and Gaza a darker gold, Green Line green; slow zoom from frame 0 and
#   pulsing heartland dots. Phases by marks: "hl" labels, "pop" population counters, "brit" / "fr" mandate outlines,
#   "golan" 1967 Golan highlight. Fields: title, title_y, end_note, phases.
# sc_score: split-screen live scorecard ISRAEL | SYRIA, rows revealed by marks r<i> (label), r<i>l, r<i>r; "pre" rows shown at once.
DS_GEO = "/home/claude/druze_syria_1102/geo_ds.json"
_DG = {}
def _dgeo():
    if not _DG:
        from shapely.geometry import Polygon, box as sbox
        d = _json.load(open(DS_GEO)); _DG.update(d)
        g = Polygon(d["isr"][0]).buffer(0).intersection(sbox(35.64, 32.68, 36.0, 33.42))
        ps = [g] if g.geom_type == "Polygon" else [p for p in g.geoms if p.geom_type == "Polygon"]
        _DG["golan"] = [[list(xy) for xy in p.exterior.coords] for p in ps]
        b = Polygon(d["isr"][0]).buffer(0).difference(g)
        bs = [b] if b.geom_type == "Polygon" else [p for p in b.geoms if p.geom_type == "Polygon"]
        _DG["brit"] = [[list(xy) for xy in p.exterior.coords] for p in bs]
    return _DG
NIGHT = kit.hx("#0B1426"); NAVY = kit.hx("#163261"); GOLD_IL = kit.hx("#B8923F"); GOLD_PA = kit.hx("#8C6C2A")
GREENL = kit.hx("#3FBF7F"); LAND = kit.hx("#1E2E50"); CORAL = kit.hx("#E5674F"); GOLDT = kit.hx("#FFCD50")
HEART = [("Galilee", 35.33, 32.97, -1, 0), ("Carmel", 35.04, 32.70, -1, 60), ("Golan", 35.76, 33.22, 1, 40),
         ("Mount Lebanon", 35.62, 33.72, -1, -30), ("Sweida", 36.60, 32.70, 1, 0)]
def _poly(c, P, rings):
    for r in rings:
        for i, (lo, la) in enumerate(r):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.close_path()
def _tl(c, s, sz, x, y, col_=WHITE, a=1.0, w=900, maxw=460, max_lines=3, lh=1.12):
    """multi-line text centred at (x, y), wrapped to maxw; returns its height"""
    z, ls = RD.wrap(s, sz, w, maxw, max_lines); step = z * lh; h = step * len(ls)
    if a > 0.005:
        for k, l in enumerate(ls):
            kit.tx(c, RD.clean(l), z, x, y - h / 2 + step * (k + 0.5), w=w, col=RD.c255(col_), a=a, hl=RD.c255(YEL), shadow=True, maxw=maxw + 6)
    return h
def _pill2(c, s, sz, x, y, a, outline=SKY, fg=WHITE, bg=INK, w=800):
    if a <= 0.01: return
    s = RD.clean(s); f = kit.font(sz, w); tw = f.getlength(s.replace("*", "")); hh = sz * 1.5
    x = min(max(x, 30 + tw / 2 + 28), W - 30 - tw / 2 - 28)
    sa(c, bg, 0.78 * a); rr(c, x - tw / 2 - 28, y - hh / 2, tw + 56, hh, hh / 2); c.fill()
    sa(c, outline, 0.95 * a); c.set_line_width(3); rr(c, x - tw / 2 - 28, y - hh / 2, tw + 56, hh, hh / 2); c.stroke()
    kit.tx(c, s, sz, x, y, w=w, col=RD.c255(fg), a=a, shadow=False, maxw=1000)
def sc_dmap(c, t, S):
    G = _dgeo(); t0 = S["t0"]; tm = dict(S["times"]); ph = S.get("phases", [])
    for k_ in ("hl", "pop", "brit", "fr", "golan"): tm.setdefault(k_, t0 - 5)
    if "fr" not in ph: tm["fr"] = 1e9
    if "_mv" not in S: S["_mv"] = MapView(S.get("view", [34.05, 29.45, 37.25, 34.5]), (0, 520, W, 1700))
    mv = S["_mv"]; T1 = S["t1"] if S["t1"] is not None else t0 + 5
    u = _ease3((t - t0) / max(1.0, T1 - t0)); z = S.get("z_from", 1.0) + (S.get("z_to", 1.07) - S.get("z_from", 1.0)) * u
    fx, fy = mv.P(*S.get("focus", (35.6, 32.4)))
    sa(c, NIGHT); c.rectangle(0, 0, W, H); c.fill()
    c.save(); c.translate(fx, fy); c.scale(z, z); c.translate(-fx, -fy); P = mv.P
    for iso in ("EG", "SA", "JO", "IQ", "TR", "CY", "LB", "SY"):
        if iso not in G["me"]: continue
        _poly(c, P, G["me"][iso]); sa(c, LAND); c.fill_preserve(); sa(c, SKY, 0.35); c.set_line_width(2 / z); c.stroke()
    _poly(c, P, G["isr"]); sa(c, GOLD_IL); c.fill()
    _poly(c, P, G["pal"]); sa(c, GOLD_PA); c.fill()
    _poly(c, P, G["lakes"]); sa(c, NIGHT); c.fill()
    sa(c, GREENL); c.set_line_width(3.2 / z); c.set_dash([10 / z, 6 / z])
    for ln in G["green"]:
        for k, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if k == 0 else c.line_to)(x, y)
        c.stroke()
    c.set_dash([])
    # mandates
    if "brit" in ph:
        ab = ramp(t, tm["brit"], tm["brit"] + 0.4) * (1 - 0.6 * ramp(t, tm["fr"], tm["fr"] + 0.4))
        if ab > 0.01:
            _poly(c, P, G["brit"]); _poly(c, P, G["pal"]); sa(c, WHITE, 0.18 * ab); c.fill_preserve(); sa(c, WHITE, ab); c.set_line_width(6 / z); c.stroke()
    if "fr" in ph:
        af = ramp(t, tm["fr"], tm["fr"] + 0.4)
        if af > 0.01:
            for iso in ("SY", "LB", "golan"):
                _poly(c, P, G[iso] if iso == "golan" else G["me"][iso]); sa(c, SKY, 0.30 * af); c.fill_preserve(); sa(c, SKY, af); c.set_line_width(6 / z); c.stroke()
    if "golan" in ph:
        ag = ramp(t, tm["golan"], tm["golan"] + 0.4); pu = 0.5 + 0.5 * math.sin(t * 5)
        if ag > 0.01:
            _poly(c, P, G["golan"]); sa(c, YEL, (0.45 + 0.35 * pu) * ag); c.fill_preserve(); sa(c, WHITE, ag); c.set_line_width(4 / z); c.stroke()
    # heartlands: glowing dots from frame 0
    for k, (nm, lo, la, side, dy) in enumerate(HEART):
        x, y = P(lo, la); pu = 0.5 + 0.5 * math.sin(t * 3.2 + k * 1.3)
        rg = cairo.RadialGradient(x, y, 0, x, y, (60 + 18 * pu) / z)
        rg.add_color_stop_rgba(0, SKY[0], SKY[1], SKY[2], 0.75); rg.add_color_stop_rgba(1, SKY[0], SKY[1], SKY[2], 0)
        c.set_source(rg); c.arc(x, y, (60 + 18 * pu) / z, 0, 6.2832); c.fill()
        circ(c, x, y, 13 / z, WHITE, 1.0); circ(c, x, y, 8 / z, SKY, 1.0)
    c.restore()
    def scr(lo, la):
        x, y = mv.P(lo, la); return fx + (x - fx) * z, fy + (y - fy) * z
    # top shade for the headline
    g = cairo.LinearGradient(0, 0, 0, 720)
    g.add_color_stop_rgba(0, NIGHT[0], NIGHT[1], NIGHT[2], 0.96); g.add_color_stop_rgba(0.7, NIGHT[0], NIGHT[1], NIGHT[2], 0.75); g.add_color_stop_rgba(1, NIGHT[0], NIGHT[1], NIGHT[2], 0)
    c.set_source(g); c.rectangle(0, 0, W, 720); c.fill()
    if "hl" in ph:
        for k, (nm, lo, la, side, dy) in enumerate(HEART):
            tk = tm["hl"] + 0.22 * k; a = 1.0 if (S.get("hook") and tk <= RD.HOOK_GRACE) else ramp(t, tk, tk + 0.3)
            x, y = scr(lo, la); lx = x + side * 210
            if a > 0.01:
                sa(c, WHITE, 0.8 * a); c.set_line_width(3); c.move_to(x + side * 16, y); c.line_to(lx - side * 120, y + dy); c.stroke()
                _pill2(c, nm, 46, lx, y + dy, a)
    if "pop" in ph:
        for k, (lab, num, lo, la, src) in enumerate((("Israel", 150000, 34.35, 31.55, "CBS, 2022"), ("Syria", 700000, 36.75, 31.95, "2010 estimate"))):
            tk = tm["pop"] + 0.5 * k; a, s = PP(t, tk, S)
            if a <= 0.01: continue
            x, y = scr(lo, la); x = 250 if k == 0 else 830
            v = num * ease(min(1.0, max(0.0, (t - tk) / 1.2)))
            sa(c, INK, 0.8 * a); rr(c, x - 190, y - 105, 380, 210, 34); c.fill()
            sa(c, GOLDT if k == 0 else SKY, a); c.set_line_width(3); rr(c, x - 190, y - 105, 380, 210, 34); c.stroke()
            kit.tx(c, lab, 52, x, y - 55, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=360)
            kit.tx(c, f"~{v:,.0f}", 76, x, y + 12, w=900, col=RD.c255(YEL), a=a, shadow=False, maxw=360)
            kit.tx(c, src, 36, x, y + 72, w=700, col=RD.c255(WHITE), a=0.85 * a, shadow=False, maxw=360)
    if "brit" in ph:
        a = ramp(t, tm["brit"] + 0.1, tm["brit"] + 0.4); _pill2(c, "British Mandate", 52, 250, scr(34.6, 32.05)[1], a, outline=WHITE)
    if "fr" in ph:
        a = ramp(t, tm["fr"] + 0.1, tm["fr"] + 0.4); _pill2(c, "French Mandate", 52, 800, 640, a, outline=SKY)
    if "golan" in ph:
        a, s = PP(t, tm["golan"] + 0.1, S); x, y = scr(35.8, 33.05)
        _pill2(c, "1967: the Golan", 56, 820, y + 120, a, outline=YEL)
        a2 = ramp(t, tm.get("majdal", tm["golan"] + 0.8), tm.get("majdal", tm["golan"] + 0.8) + 0.3); xm, ym = scr(35.77, 33.27)
        if a2 > 0.01:
            circ(c, xm, ym, 14, WHITE, a2); circ(c, xm, ym, 9, YEL, a2); sa(c, WHITE, 0.8 * a2); c.set_line_width(3); c.move_to(xm + 14, ym); c.line_to(700, ym - 70); c.stroke()
            _pill2(c, "Majdal Shams", 46, 830, ym - 70, a2, outline=YEL)
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S)
        _wtext(c, S["title"], S.get("tsize", 118), S.get("title_y", 440), a=a1, sc=s1, max_lines=2)
    if S.get("end_note"):
        a, s = PP(t, tm.get("note", t0 + 0.8), S); _pill2(c, S["end_note"], 44, 540, 1330, a, outline=SKY)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)

def sc_score(c, t, S):
    t0 = S["t0"]; tm = S["times"]; _stage_bg(c, t, S); pre = S.get("pre", 0)
    a1, s1 = PP(t, t0 + 0.05, S)
    if S.get("title"): _wtext(c, S["title"], 96, 400, a=a1, sc=s1, max_lines=1)
    # column heads + divider
    for x, nm, colr in ((282, "ISRAEL", GOLDT), (798, "SYRIA", SKY)):
        kit.tx(c, nm, 76, x, 540, w=900, col=RD.c255(colr), a=a1, shadow=False, maxw=480)
    sa(c, WHITE, 0.35 * a1); c.set_line_width(3); c.move_to(540, 495); c.line_to(540, 585); c.stroke()
    sa(c, WHITE, 0.35 * a1); c.move_to(40, 600); c.line_to(1040, 600); c.stroke()
    for i, R_ in enumerate(S["rows"]):
        y = 640 + 250 * i
        def at(key):
            if i < pre or key in S.get("shown", []): return 1.0, 1.0
            return PP(t, tm.get(key, t0 + 0.5 + i), S)
        a, s = at(f"r{i}")
        if a > 0.01:
            kit.tx(c, R_["label"], 60, 540, y + 10, w=900, col=RD.c255(YEL), a=a, shadow=False, maxw=600)
        for side, key, x, colr in (("l", f"r{i}l", 282, GOLDT), ("r", f"r{i}r", 798, CORAL if R_.get("bad_r") else SKY)):
            a2, s2 = at(key)
            if a2 <= 0.01: continue
            sa(c, colr, 0.16 * a2); rr(c, x - 240, y + 52, 480, 170, 26); c.fill()
            sa(c, colr, 0.75 * a2); c.set_line_width(3); rr(c, x - 240, y + 52, 480, 170, 26); c.stroke()
            _tl(c, R_[side], 54, x, y + 137, a=a2, maxw=440, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)
