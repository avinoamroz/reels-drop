"""Scenes for "Jews: hard to live with, impossible to get rid of" (@noamroz__), loaded by reelkit via spec "scene_module".
empire: one big name card per power that tried to wipe out the Jews (year chip, icon, name EN/HE, fact EN/HE, what fell),
        a result row (the holiday or day we still mark), a counter "They tried: N" on top and "Still here: the Jews" below.
        Ancient powers get a crack + GONE stamp; the Holocaust, pogroms, 1948 and 7 October beats are quiet (no stamp, no bounce).
rome:   the Rome card plus the Arch of Titus (menorah) next to the State of Israel emblem (menorah), drawn, no photos.
fair:   the "In my view" line (Germany today).
end:    the punchline "They tried to kill us. They failed. Let's eat.", Am Yisrael Chai, the question and a down arrow.
No faces, no photos, no symbols of the perpetrators."""
import math
import cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, draw_emoji, flag_emoji, source
import kit
from kit import ease, ramp, lerp, St, sa, rr, line as kline, circ, box, font, is_he

CX0, CX1 = 80, 1000            # card x
CY0 = 372                      # card top
TALLY_Y = 1374

def M(S, k, d): return S["times"].get(k, d)

def _pop(t, t0, S, quiet=False):
    if S.get("hook") and t0 <= RD.HOOK_GRACE: return 1.0, 1.0
    if quiet: return ramp(t, t0, t0 + 0.35), 1.0
    return kit.pop(t, t0, 0.45, 0.3, 1.8)

def star(c, x, y, r, colr, a=1.0):
    """Star of David: two outlined triangles"""
    sa(c, colr, a); c.set_line_width(max(3, r * 0.2)); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for k in (0, 1):
        c.new_path()
        for j in range(3):
            ang = -math.pi / 2 + k * math.pi + j * 2 * math.pi / 3
            (c.move_to if j == 0 else c.line_to)(x + r * math.cos(ang), y + r * math.sin(ang))
        c.close_path(); c.stroke()

# ------------------------------------------------------------------ persistent counter + tally
def _persist_alpha(t, S):
    cur = S["t0"] <= t < S["t1"]
    if cur: return St.a if S.get("first") else 1.0
    if S.get("last") and t >= S["t1"]: return St.a
    return 0.0

def counter(c, t, S):
    a = _persist_alpha(t, S)
    if a <= 0.01: return
    old = St.a; St.a = a
    n = S["n"]; tn = S["t0"] + 0.12
    _, s = kit.pop(t, tn, 0.4, 0.6, 2.2)
    T(c, "They tried to wipe us out:", 40, 500, 262, P["navy"], 1, 1, 800, anchor="r", maxw=600)
    pill(c, str(n), 50, 568, 262, P["red"] if S.get("quiet") else P["navy"], P["white"], 1, s, w=900, padx=0.55, padh=1.35)
    T(c, "ניסו להשמיד אותנו", 34, 540, 318, P["blue"], 1, 1, 700, maxw=700)
    T(c, "Still here:", 40, 470, TALLY_Y, P["grey"], 1, 1, 700, anchor="r", maxw=400)
    T(c, "*the Jews*", 46, 486, TALLY_Y, P["navy"], 1, 1, 900, hl=P["gold_text"], anchor="l", maxw=360)
    star(c, 752, TALLY_Y - 2, 24 * (1 + 0.06 * math.sin(t * 3)), P["blue"])
    T(c, "עדיין כאן: היהודים", 34, 540, TALLY_Y + 46, P["gold_text"], 1, 1, 700, maxw=700)
    St.a = old

# ------------------------------------------------------------------ crack + stamp on the icon
def _crack_path(c, x, y, h, side):
    pts = [(x + 10, y - h / 2), (x - 14, y - h / 4), (x + 12, y), (x - 10, y + h / 4), (x + 6, y + h / 2)]
    big = 400
    c.move_to(pts[0][0], pts[0][1])
    for p in pts[1:]: c.line_to(*p)
    c.line_to(x + side * big, y + h / 2); c.line_to(x + side * big, y - h / 2); c.close_path()

def icon_cracked(c, t, e, x, y, px, a, s, tg):
    """emoji that splits along a zigzag crack at tg and fades to a ghost"""
    if tg is None or t < tg:
        draw_emoji(c, e, x, y + 5 * math.sin(t * 2.2), px, a, s); return
    u = ease(min(1.0, (t - tg) / 0.5)); ga = a * (1 - 0.7 * u)
    for side in (-1, 1):
        c.save(); _crack_path(c, x, y, px * 1.2, side); c.clip()
        c.translate(x + side * 26 * u, y + 30 * u); c.rotate(side * 0.16 * u); c.translate(-x, -y)
        draw_emoji(c, e, x, y, px, ga, s); c.restore()

def stamp(c, t, tg, x, y, en, he, a):
    if tg is None or t < tg: return
    al, s = kit.pop(t, tg, 0.35, 1.8, 1.4)
    c.save(); c.translate(x, y); c.rotate(-0.2); c.scale(s, s); old = St.a; St.a *= a * al
    w, h = 300, 132
    sa(c, P["red"], 0.10); rr(c, -w / 2, -h / 2, w, h, 16); c.fill()
    sa(c, P["red"]); c.set_line_width(8); rr(c, -w / 2, -h / 2, w, h, 16); c.stroke()
    T(c, en, 70, 0, -16, P["red"], 1, 1, 900, maxw=w - 30)
    T(c, he, 38, 0, 38, P["red"], 1, 1, 700, maxw=w - 30)
    St.a = old; c.restore()

# ------------------------------------------------------------------ the card
def card(c, t, S, y1=1150, icon_y=None, icon_px=200, compact=False):
    t0 = S["t0"]; q = S.get("quiet"); dark = S.get("dark")
    a, s = _pop(t, t0 + 0.02, S, q)
    fill = P["navy"] if dark else P["card"]; ink = P["white"] if dark else P["navy"]; ink2 = kit.hx("#E6C77E") if dark else P["blue"]
    c.save(); c.translate(540, (CY0 + y1) / 2); c.scale(s, s); c.translate(-540, -(CY0 + y1) / 2); old = St.a; St.a *= a
    shadow_box(c, CX0, CY0, CX1 - CX0, y1 - CY0, 34, fill, stroke=P["gold"] if not q else P["silver"], sw=5)
    y = CY0 + 62
    pill(c, S["year"], 40, 540, y, P["gold"] if not dark else kit.hx("#E6C77E"), P["white"] if not dark else P["navy"], 1, 1, w=800)
    if S.get("tag"): pill(c, S["tag"], 28, 880, y, P["white"], P["gold_text"], 1, 1, outline=P["gold"], w=800, padh=1.4)
    iy = icon_y or (y + 60 + icon_px / 2)
    tg = M(S, "gone", None) if S.get("crack") else None
    if S.get("flags"):
        fl = S["flags"]; n = len(fl); sz = 118
        for k, f in enumerate(fl):
            xx = 540 + (k - (n - 1) / 2) * (sz + 34)
            draw_emoji(c, flag_emoji(f), xx, iy + 6 * math.sin(t * 2.4 + k), sz, 1, 1)
    else:
        icon_cracked(c, t, S["icon"], 540, iy, icon_px, 1, 1, tg)
    y = iy + icon_px / 2 + 70
    hn = block_h(S["en"], 92 if not compact else 80, 900, 880, 1)
    block(c, S["en"], 92 if not compact else 80, 540, y, ink, 1, 1, hl=ink2, maxw=880, max_lines=1); y += hn / 2 + 40
    T(c, S["he"], 58 if not compact else 52, 540, y, ink2, 1, 1, 700, maxw=860); y += 70
    hf = block_h(S["fact"], 42, 700, 840, 2)
    block(c, S["fact"], 42, 540, y + hf / 2 - 10, ink, 1, 1, w=700, hl=ink2, maxw=840, max_lines=2); y += hf + 6
    if S.get("fact_he"):
        hh = block_h(S["fact_he"], 38, 700, 840, 2)
        block(c, S["fact_he"], 38, 540, y + hh / 2 - 6, ink2 if dark else P["grey"], 1, 1, w=700, maxw=840, max_lines=2); y += hh
    if S.get("fell"):
        T(c, S["fell"], 34, 540, y1 - 46, P["grey"] if not dark else P["silver"], 1, 1, 700, maxw=840)
    St.a = old; c.restore()
    if tg is not None and S.get("stamp_en"):
        stamp(c, t, tg + 0.12, 800, iy + 10, S["stamp_en"], S["stamp_he"], a)

def result_row(c, t, S, y=1246):
    if not S.get("res"): return
    tr = M(S, "res", S["t0"] + 0.7); q = S.get("quiet")
    a, s = _pop(t, tr, S, q)
    if a <= 0.01: return
    R = S["res"]
    z = 50; f = font(z, 800)
    tw = f.getlength(R["en"].replace("*", "")); emw = 64 if R.get("icon") else 0
    pw = tw + emw + 80; ph = 84
    c.save(); c.translate(540, y); c.scale(s, s); old = St.a; St.a *= a
    sa(c, P["navy"], 0.16); rr(c, -pw / 2, -ph / 2 + 8, pw, ph, ph / 2); c.fill()
    g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0)
    if q:
        g.add_color_stop_rgb(0, *P["navy"][:3]); g.add_color_stop_rgb(1, *P["navy"][:3]); fg = P["white"]
    else:
        g.add_color_stop_rgb(0, *P["gold"][:3]); g.add_color_stop_rgb(0.5, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3]); fg = P["navy"]
    rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(4); c.stroke()
    T(c, R["en"], z, -emw / 2, 3, fg, 1, 1, 800, hl=P["navy"] if not q else kit.hx("#E6C77E"), maxw=900)
    if R.get("icon"): draw_emoji(c, R["icon"], tw / 2 - emw / 2 + 44, 0, 56, 1, 1)
    T(c, R["he"], 38, 0, 76, P["blue"] if not q else P["navy"], 1, 1, 700, maxw=900)
    St.a = old; c.restore()

def sc_empire(c, t, S):
    counter(c, t, S)
    card(c, t, S)
    result_row(c, t, S)
    source(c, t, S)

# ------------------------------------------------------------------ Rome: arch of Titus + emblem of Israel
def menorah(c, x, y, s, colr, a=1.0, lw=7):
    """seven-branched menorah, stem from (x, y + 80s) up to y - 90s"""
    c.save(); c.translate(x, y); c.scale(s, s); sa(c, colr, a); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.move_to(0, -90); c.line_to(0, 70); c.stroke()
    for r in (28, 54, 80):
        c.new_path(); c.arc(0, -90, r, 0, math.pi); c.stroke()
    for xx in (-80, -54, -28, 0, 28, 54, 80):
        circ(c, xx, -96, 6, colr, a)
    c.move_to(-34, 82); c.line_to(34, 82); c.stroke(); c.move_to(-20, 70); c.line_to(20, 70); c.stroke()
    c.restore()

def arch(c, x, y, a):
    old = St.a; St.a *= a
    stone = kit.hx("#E9E0CC"); edge = kit.hx("#8E7A55")
    c.new_path(); c.rectangle(x - 150, y - 150, 300, 260)
    c.new_sub_path(); c.arc_negative(x, y - 20, 70, 0, math.pi); c.line_to(x - 70, y + 110); c.line_to(x + 70, y + 110); c.close_path()
    c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD); sa(c, stone); c.fill_preserve(); sa(c, edge); c.set_line_width(4); c.stroke()
    c.set_fill_rule(cairo.FILL_RULE_WINDING)
    box(c, x - 166, y - 176, 332, 32, 4, stone, 1, stroke=edge, sw=3)
    for k in (-1, 1): box(c, x + k * 118 - 10, y - 140, 20, 250, 4, kit.hx("#DCD1B8"), 1)
    menorah(c, x, y + 30, 0.55, P["gold"], 1, 9)
    St.a = old

def emblem(c, x, y, a):
    old = St.a; St.a *= a
    c.new_path(); c.move_to(x - 120, y - 150); c.line_to(x + 120, y - 150); c.line_to(x + 120, y + 40)
    c.curve_to(x + 120, y + 120, x + 40, y + 150, x, y + 170); c.curve_to(x - 40, y + 150, x - 120, y + 120, x - 120, y + 40); c.close_path()
    sa(c, P["blue"]); c.fill_preserve(); sa(c, P["white"]); c.set_line_width(6); c.stroke()
    menorah(c, x, y + 6, 0.62, P["white"], 1, 9)
    for k in (-1, 1):
        c.save(); sa(c, P["white"]); c.set_line_width(4); c.new_path()
        c.move_to(x + k * 92, y + 110); c.curve_to(x + k * 118, y + 20, x + k * 110, y - 60, x + k * 84, y - 110); c.stroke()
        for j in range(5):
            u = j / 5; lx = x + k * (92 + 20 * math.sin(u * 3)); ly = y + 100 - 200 * u
            c.save(); c.translate(lx, ly); c.rotate(k * 0.8); c.scale(1, 0.45); c.arc(0, 0, 12, 0, 2 * math.pi); c.restore(); c.fill()
        c.restore()
    T(c, "ישראל", 34, x, y + 128, P["white"], 1, 1, 700, maxw=200)
    St.a = old

def sc_rome(c, t, S):
    counter(c, t, S)
    card(c, t, S, y1=1000, icon_y=CY0 + 150, icon_px=110, compact=True)
    ta = M(S, "arch", S["t0"] + 1.5); te = M(S, "emblem", ta + 1.2)
    for (tt, fn, x, en, he_) in ((ta, arch, 290, "Arch of Titus, Rome, c. 81 CE", "שער טיטוס, רומא"),
                                 (te, emblem, 790, "Emblem of Israel, 1949", "סמל מדינת ישראל, 1949")):
        a, s = _pop(t, tt, S)
        if a <= 0.01: continue
        c.save(); c.translate(x, 1170); c.scale(s, s); c.translate(-x, -1170)
        shadow_box(c, x - 225, 1016, 450, 318, 28, P["card"], a, stroke=P["gold"], sw=4)
        c.save(); c.translate(x, 1140); c.scale(0.68, 0.68); c.translate(-x, -1140); fn(c, x, 1140, a); c.restore()
        T(c, en, 30, x, 1282, P["navy"], a, 1, 800, maxw=420); T(c, he_, 28, x, 1314, P["blue"], a, 1, 700, maxw=420)
        c.restore()
    if t >= te:
        u = ease(min(1, (t - te) / 0.5)); c.set_dash([12, 10])
        kline(c, [(520, 1170), (520 + 40 * u, 1170)], P["gold"], 6, St.a); c.set_dash([])
        if u > 0.9:
            c.move_to(572, 1170); c.line_to(552, 1156); c.line_to(552, 1184); c.close_path(); sa(c, P["gold"], St.a); c.fill()
    source(c, t, S)

# ------------------------------------------------------------------ the fair line
def sc_fair(c, t, S):
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.02, S)
    pill(c, "IN MY VIEW", 40, 540, 330, P["navy"], P["white"], a, s, w=900)
    T(c, "לדעתי", 40, 540, 400, P["blue"], a, s, 700)
    a, s = PP(t, t0 + 0.2, S)
    h = block_h(S["en"], 74, 900, 900, 2); block(c, S["en"], 74, 540, 470 + h / 2, P["navy"], a, s, hl=P["blue"], maxw=900, max_lines=2)
    y = 470 + h + 50; T(c, S["he"], 50, 540, y, P["blue"], a, s, 700, maxw=900)
    tg = M(S, "germany", t0 + 2.0)
    a, s = PP(t, tg, S)
    if a > 0.01:
        shadow_box(c, CX0, 800, CX1 - CX0, 560, 34, P["card"], a, stroke=P["gold"], sw=5)
        for k, e in enumerate((flag_emoji("DE"), "🤝", flag_emoji("IL"))):
            draw_emoji(c, e, 540 + (k - 1) * 210, 930 + 6 * math.sin(t * 2.4 + k), 150, a, s)
        h2 = block_h(S["en2"], 62, 900, 860, 2); block(c, S["en2"], 62, 540, 1080 + h2 / 2 - 20, P["navy"], a, s, hl=P["blue"], maxw=860, max_lines=2)
        T(c, S["he2"], 46, 540, 1080 + h2 + 26, P["blue"], a, s, 700, maxw=860)
        T(c, S["note"], 34, 540, 1316, P["grey"], a, 1, 700, maxw=860)
    source(c, t, S)

# ------------------------------------------------------------------ the end card
def arrow_down(c, x, y, a):
    old = St.a; St.a *= a
    g = cairo.LinearGradient(x - 50, y - 70, x + 50, y + 70); g.add_color_stop_rgb(0, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
    c.new_path(); c.move_to(x - 26, y - 70); c.line_to(x + 26, y - 70); c.line_to(x + 26, y + 4); c.line_to(x + 62, y + 4)
    c.line_to(x, y + 74); c.line_to(x - 62, y + 4); c.line_to(x - 26, y + 4); c.close_path()
    c.set_source(g); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(5); c.stroke()
    St.a = old

def sc_end(c, t, S):
    t0 = S["t0"]; tm = S["times"]
    a, s = PP(t, t0 + 0.02, S)
    h = block_h(S["intro"], 48, 800, 980, 1); block(c, S["intro"], 48, 540, 300 + h / 2, P["grey"], a, s, w=800, maxw=980, max_lines=1)
    hh = block_h(S["intro_he"], 40, 700, 900, 2); block(c, S["intro_he"], 40, 540, 300 + h + 14 + hh / 2, P["blue"], a, s, w=700, maxw=900, max_lines=2)
    y = 300 + h + hh + 70
    for k, (en, he_, key) in enumerate(S["lines3"]):
        a, s = PP(t, tm.get(key, t0 + 0.6 * (k + 1)), S)
        T(c, en, 80, 540, y, P["navy"], a, s, 900, hl=P["blue"], maxw=940)
        T(c, he_, 48, 540, y + 66, P["blue"], a, s, 700, maxw=900)
        if k == 2 and a > 0.01: draw_emoji(c, "🍽️", 540 + font(80, 900).getlength(en.replace("*", "")) / 2 + 70, y - 4, 84, a, s * (1 + 0.05 * math.sin(t * 4)))
        y += 150
    y += 20
    ta = tm.get("chai", t0 + 3.0); a, s = PP(t, ta, S)
    if a > 0.01:
        box(c, 540 - 330 * ease(min(1, (t - ta) / 0.6)), y - 70, 660 * ease(min(1, (t - ta) / 0.6)), 6, 3, P["gold"], a)
        T(c, "Am Yisrael Chai", 84, 540, y + 10, P["gold_text"], a, s, 900, maxw=940)
        T(c, "עם ישראל חי", 58, 540, y + 82, P["navy"], a, s, 700, maxw=900)
    y += 190
    tq = tm.get("q", ta + 0.9); a, s = PP(t, tq, S)
    if a > 0.01:
        T(c, "What's *YOUR* favorite holiday?", 62, 540, y, P["navy"], a, s, 900, hl=P["blue"], maxw=960)
        T(c, "מה החג האהוב עליכם?", 50, 540, y + 64, P["blue"], a, s, 700, maxw=900)
        arrow_down(c, 540, y + 180 + 14 * math.sin(t * 6), fade_in(t, tq + 0.15, S, 0.25))
