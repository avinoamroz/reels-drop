"""local step (needs ../../safety_v4 and ../../rehook): music bed + stamps/whoosh/hits under work/vo.wav -> work/mix.m4a (-14 LUFS, <= -1.5 dBTP)"""
import sys, os, runpy, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
D = "/home/claude/series_more/safe_p2_v2"; CFG = f"{D}/cfg_v2.py"
import audio_v4 as AU, rk
C = runpy.run_path(CFG); dur = C["T_END"]
vo, sr = sf.read(C["VO"]); assert sr == AU.SR
bed = AU.doc_music(dur, flip_at=C["TURN"] - 0.3, end_ring=0.8)
ev = [(t0 - 0.02, AU.stamp(i) * (0.9 + 0.2 * AU.rng.random()), -2.0) for i, t0 in enumerate(C["STAMPS"])]
ev.append((C["WHOOSH"] - 0.2, AU.jet_whoosh(1.4), -1.0))
for h in C["HITS"]: ev.append((h, AU.soft_hit(), -4.0))
mix_wav = f"{D}/work/mix.wav"; rep = AU.mix(vo, dur, ev, mix_wav, music_db=-19.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mix_wav); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mix_wav)
json.dump(dict(T_END=dur, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", J["final_I"], J["final_TP"])
