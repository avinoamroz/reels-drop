# safe_p2_v2: "Where did they go?" Jews in Arab countries (and Iran) 1948 vs today. Rebuild of safe_p2 (cfg_p2.py) for Noam's 30 Oct note:
# narration re-recorded as 21 short Cartesia clips (one idea each, numbers spelled out, "Today?" as its own question so the small number
# lands at the end of its own phrase), stitched by stitch.py. Fixes: no PART badge, no subtitle bar duplicating the caption, the
# "Still there today" chip only appears on the first "Today?" (it used to mirror the 1948 chip during the reveal burst), the 1948 chip
# reaches its full 856,000 on "thousand". Last line loops back to the hook. Engine: engine_v2.py (copy of engine_p2.py). Sources: facts.md
import json, re, math
D = "/home/claude/series_more/safe_p2_v2"
TAG = "safe_p2_v2"; OUT = f"{D}/work/silent.mp4"; FINAL = f"{D}/safe_p2_v2.mp4"; SNAPDIR = f"{D}/work/snaps"; VO = f"{D}/work/vo.wav"
RED, AMB, GRN, GOLDC, CITY = "#F0525A", "#A78BFA", "#34C97F", "#F2D58A", "#64D2FF"
ISR_GOLD = "#B8923F"; GREEN_LINE = "#2ECC71"
WORDS = json.load(open(f"{D}/work/words.json"))["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def W_(li, i, end=False): return LW[li][i]["t1" if end else "t0"]
def LS(li): return LW[li][0]["t0"]
def LE(li): return LW[li][-1]["t1"]
VO_END = LE(20); T_END = round(VO_END + 0.6, 2)

SUBS = []            # no burned-in subtitle bar: the bilingual caption above the sources says the same thing (bug c)
SUB_BOTTOM = 1650

PART = None          # no "Part X" badge (bug b)
TITLES = [(0, "Where did they go?", "לאן הם הלכו?")]
TY = 300; T_FS = 50; T_HFS = 42; T_GAP = 58
CHIP_Y = 438; CHIP_H = 140; CHIP_X = [40, 335, 630]; CHIP_W = 280; CHIP_NFS = 62
PANEL = (0, 592, 1080, 640)
EV_Y = 1244; EV_FS = 50; EV_HFS = 40; EV_W = 860; EV_X = 480
DISC_Y = 1432; DISC_FS = 30; DISC_LH = 34
LAB_EN, LAB_HE, LAB_L2 = 38, 34, 30
RS = 2.6
TURN = W_(14, 0)

WIDE0 = (26.0, 29.0, 74.0); WIDE1 = (25.0, 29.5, 68.0); NAFR = (3.0, 30.5, 34.0); EGY = (32.0, 29.0, 24.0); LEV = (40.5, 32.5, 20.0)
YEM = (45.0, 21.0, 26.0); IRN = (48.0, 30.5, 30.0); FLOW = (10.0, 33.5, 82.0)
CAM = [(0, *WIDE0), (LS(2) - 0.4, *WIDE1), (LS(2) + 0.5, *NAFR), (LE(4) + 0.3, *NAFR), (LS(5) + 0.4, *EGY), (LE(6) + 0.3, *EGY),
       (LS(7) + 0.4, *LEV), (LE(8) + 0.2, *LEV), (LS(9) + 0.5, *YEM), (LE(10) + 0.2, *YEM), (LS(11) + 0.5, *IRN), (LE(12) + 0.1, *IRN),
       (LS(13) + 0.9, *FLOW), (99, *FLOW)]

C_ = {}
def c(name, he, r, ll, lab, jews, show, then_lab=None, en=None, l2=None, cat="amb"):
    C_[name] = dict(he=he, cat=cat, r=r, ll=ll, lab=lab, l2=l2, jews=jews, lab_to=show[1], lab_show=show, en=en or name, jstart=r)
    if then_lab: C_[name]["then_lab"] = then_lab
# reveal burst from "Arab" to the end of "thousand" (line 1), biggest first, so the 1948 chip hits its full total on the number;
# each country shrinks on the small number after its own "Today?"
_ord = ["Morocco", "Algeria", "Iraq", "Tunisia", "Egypt", "Yemen", "Libya", "Syria", "Lebanon"]
_t0 = W_(1, 3); _dt = (W_(1, 11, True) - 0.25 - _t0) / (len(_ord) - 1); R = {n: _t0 + i * _dt for i, n in enumerate(_ord)}
c("Morocco", "מרוקו", R["Morocco"], (-6.3, 32.0), (1, -0.9), (265000, 2100, "~2,100", W_(3, 1), 99), (LS(2), LE(3) + 0.6))
c("Algeria", "אלג'יריה", R["Algeria"], (2.6, 28.5), (0, 1), (140000, 200, "<200", W_(4, 4), 99), (W_(4, 0), LE(4) + 0.4))
c("Tunisia", "תוניסיה", R["Tunisia"], (9.4, 34.0), (0.3, -1), (105000, 1000, "~1,000", W_(4, 5), 99), (W_(4, 1), LE(4) + 0.4))
c("Libya", "לוב", R["Libya"], (17.5, 27.5), (0.2, 1), (38000, 0, "0", W_(4, 6), 99), (W_(4, 3), LE(4) + 0.4))
c("Egypt", "מצרים", R["Egypt"], (29.0, 26.5), (-0.4, 1), (75000, 100, "~100", W_(6, 1), 99), (LS(5), LE(6) + 0.5))
c("Iraq", "עיראק", R["Iraq"], (43.8, 33.0), (0.3, 1), (135000, 4, "4", W_(8, 1), 99), (LS(7), LE(8) + 0.4))
c("Syria", "סוריה", R["Syria"], (38.6, 35.4), (0.2, -1), (30000, 5, "~5", W_(8, 1), 99), (LS(7) + 0.3, LE(8) + 0.4))
c("Lebanon", "לבנון", R["Lebanon"], (35.85, 33.9), (-1, 0.3), (5000, 100, "<100", W_(8, 1), 99), (LS(7) + 0.3, LE(8) + 0.4))
c("Yemen", "תימן", R["Yemen"], (46.5, 15.8), (-1, 0.2), (63000, 0, "0", W_(10, 1), 99), (LS(9), LE(10) + 0.4), l2=None)
c("Iran", "איראן", W_(11, 0), (53.0, 32.0), (0, -1), (100000, 9000, "~9,000", W_(12, 1), 99), (W_(11, 0), LE(12) + 0.4), then_lab="100,000+", cat="amb")
COUNTRIES_STATUS = C_
ARAB = [n for n in C_ if n != "Iran"]
RK = 0.12
STAMPS = sorted(v["r"] for v in C_.values())

ISR = (34.95, 31.6); FR = (2.3, 46.6); AM = (-19.0, 27.0)
_f0 = W_(14, 0); _f1 = W_(15, 3); _fa = W_(15, 6); _fe = LE(15) + 0.6
FLOWS = [(C_[n]["ll"], ISR, _f0 + 0.08 * i, _fe, GRN, 3) for i, n in enumerate(_ord + ["Iran"])]
FLOWS += [(C_[n]["ll"], FR, _f1 + 0.1 * i, _fe, "#C9D4E8", 2) for i, n in enumerate(["Algeria", "Morocco", "Tunisia"])]
FLOWS += [(C_["Morocco"]["ll"], AM, _fa, _fe, "#C9D4E8", 2), (C_["Iraq"]["ll"], AM, _fa + 0.1, _fe, "#C9D4E8", 2)]
GROUPS = [dict(r=_f0, lab_to=_fe, ll=ISR, dr=(1, 0.6), en="Israel", he="ישראל", l2="600,000+", cat="grn"),
          dict(r=_f1, lab_to=_fe, ll=FR, dr=(0.3, -1), en="France", he="צרפת", l2=None, cat="amb"),
          dict(r=_fa, lab_to=_fe, ll=AM, dr=(0.8, 1), en="To the Americas", he="לאמריקה", l2=None, cat="amb")]

T_TODAY = LS(3)      # first "Today?": the "Still there today" chip appears here, not with the 1948 chip (bug a)
def _cur(n, b):
    then, now, _, sh0, _ = C_[n]["jews"]
    u = min(1, max(0, (b - sh0) / 1.0)); u = u * u * (3 - 2 * u)
    return math.exp(math.log(then) * (1 - u) + math.log(max(now, 1)) * u) if u < 1 else now
def CHIPS_FN(b):
    rv = [n for n in ARAB if b >= C_[n]["r"]]
    if not rv: return []
    s0 = sum(C_[n]["jews"][0] for n in rv); sc = sum(_cur(n, b) for n in ARAB)
    last = max(C_[n]["r"] for n in rv); pp0 = 1 - min(1, (b - last) / 0.22)
    shs = [C_[n]["jews"][3] for n in ARAB if b >= C_[n]["jews"][3]]; pp1 = (1 - min(1, (b - max(shs)) / 0.3)) if shs else 0
    done = all(b >= C_[n]["jews"][3] + 1.0 for n in ARAB)
    a0 = min(1, (b - _t0) / 0.3)
    out = [("Arab countries, 1948", "ארצות ערב, 1948", f"{int(round(s0, -3)):,}", GOLDC, a0, pp0)]
    if b >= T_TODAY:
        a1 = min(1, (b - T_TODAY) / 0.3)
        out.append(("Still there today", "נשארו שם היום", "<4,000" if done else f"{int(round(sc, -2 if sc > 10000 else -1)):,}", CITY, a1,
                    max(pp1, 1 - min(1, (b - T_TODAY) / 0.3))))
    if b >= _f0: out.append(("Rebuilt lives in Israel", "בנו חיים בישראל", "600,000+", GRN, min(1, (b - _f0) / 0.3), 1 - min(1, (b - _f0) / 0.3)))
    return out
COUNTERS_A = []; COUNTERS_B = []

# unused Part 1 features (kept off)
DJERBA = dict(ll=(0, 0), r=999, to=999); AREA_A = []
WB = dict(r=999, to=999, he="", en="", ll=(35.3, 32.0), lab=(1, 0), l2=None, lab_to=999)
GAZA = dict(r=999, to=999, he="", en="", ll=(34.4, 31.4), lab=(-1, 0), l2=None)
SIGN = dict(r=999, to=999, x=40, y=990, w=880, head="", lines=[])
CITIES = []; PINS = []; CITY_LEGEND = ("", "")
MAP_LEGEND = dict(r=_f0 - 0.6)

# one caption per narrated line: a new item every 2 to 3 s
EVENTS = [(0, "Where can Jews\nwalk safely?", "איפה יהודי יכול להסתובב בבטחה?"),
 (LS(1), "1948: about 850,000 Jews\nin Arab countries", "1948: כ-850,000 יהודים בארצות ערב"),
 (LS(2), "Morocco: 265,000 in 1948", "מרוקו: 265,000 ב-1948"),
 (LS(3), "Morocco: 265,000 in 1948.\nToday: about 2,100", "מרוקו: 265,000 ב-1948. היום: כ-2,100"),
 (LS(4), "Algeria, Tunisia, Libya:\nalmost all gone", "אלג'יריה, תוניסיה, לוב: כמעט כולם עזבו"),
 (LS(5), "Egypt: 75,000 in 1948", "מצרים: 75,000 ב-1948"),
 (LS(6), "Egypt: 75,000 in 1948.\nToday: about 100", "מצרים: 75,000 ב-1948. היום: כ-100"),
 (LS(7), "Iraq: 135,000 in 1948", "עיראק: 135,000 ב-1948"),
 (LS(8), "Iraq: 135,000 in 1948.\nToday: 4", "עיראק: 135,000 ב-1948. היום: 4"),
 (LS(9), "Yemen: 63,000 in 1948", "תימן: 63,000 ב-1948"),
 (LS(10), "Yemen: 63,000 in 1948.\nToday: none", "תימן: 63,000 ב-1948. היום: אף אחד"),
 (LS(11), "Iran, not Arab:\n100,000+ in 1948", "איראן, לא ערבית: 100,000+ ב-1948"),
 (LS(12), "Iran, not Arab: 100,000+.\nToday: about 9,000", "איראן, לא ערבית: 100,000+. היום: כ-9,000"),
 (LS(13), "Where did they go?", "לאן הם הלכו?"),
 (_f0, "600,000+ rebuilt their\nlives in Israel", "יותר מ-600,000 בנו את חייהם בישראל"),
 (LS(15), "Others: France and\nthe Americas", "אחרים: לצרפת ולאמריקה")]
DISC = {0: ["Jews 1948 and today: DellaPergola, AJYB, via JVL.", "Rounded. Sources differ, most of all for 1948."],
        LS(7) - 0.2: ["Iraq 4 (DellaPergola 2023). Syria ~5 (JTA 2025).", "Lebanon <100 (JVL 2018). Yemen includes Aden."],
        LS(11) - 0.2: ["Iran 1948: estimates 100,000 to 150,000.", "Today: 9,826 (2016 census), ~9,100 (2023)."],
        LS(13) - 0.2: ["Israel: CBS immigrants by country of birth (JVL).", "Gold: Israel. Green: 1949 armistice line."]}

HOOK = {"dur": 1.2, "lines": [(720, "Where can Jews", "#0E1E3A", 70), (800, "walk safely?", "#0E1E3A", 84),
                              (900, "Arab countries: 1948 vs today", "#0E1E3A", 50),
                              (1000, "איפה יהודי יכול להסתובב בבטחה?", "#0E1E3A", 46), (1068, "ארצות ערב: 1948 מול היום", "#0E1E3A", 50),
                              (1150, "A map  |  מפה", "#0E1E3A", 30)]}
# reveal (line 16 to 17, about 70 to 75% in), fairness, the loss, then the loop line back to the hook (end card under 1 s after the voice)
T_CARDS = [("CARD1", LS(16) - 0.15), ("REV2", LS(17) - 0.15), ("FAIR", LS(18) - 0.15), ("CARD2", LS(19) - 0.15), ("END", LS(20) - 0.15)]
CARDS = {
 "CARD1": dict(edge="#D2AA53", ew=4, y=500, h=640, lines=[(600, "In 1948", "#a9bbd8", 46, 800), (730, "about 850,000", "#D2AA53", 104, 900),
     (840, "Jews in Arab countries", "#FFFFFF", 48, 800), (950, "ב-1948: כ-850,000 יהודים", "#D2AA53", 46, 800), (1012, "בארצות ערב", "#D2AA53", 46, 800),
     (1090, "Sum by country: 856,000. Sources differ.", "#a9bbd8", 30, 700)]),
 "REV2": dict(edge="#64D2FF", ew=4, y=500, h=640, lines=[(600, "Today", "#a9bbd8", 46, 800), (730, "under 4,000", "#FFFFFF", 110, 900),
     (840, "down from about 850,000", "#D2AA53", 48, 800), (950, "היום: פחות מ-4,000", "#FFFFFF", 50, 800),
     (1012, "מתוך כ-850,000", "#D2AA53", 46, 800), (1090, "DellaPergola, AJYB 2023, via JVL", "#a9bbd8", 30, 700)]),
 "FAIR": dict(edge="#a9bbd8", ew=3, y=470, h=760, lines=[(560, "To be fair:", "#FFFFFF", 58, 900), (636, "the reasons differed.", "#FFFFFF", 58, 900),
     (726, "Some were expelled.", "#D2AA53", 46, 800), (782, "Some fled violence.", "#D2AA53", 46, 800), (838, "Some chose Zionism.", "#D2AA53", 46, 800),
     (936, "ולמען ההגינות: הסיבות היו שונות.", "#FFFFFF", 42, 800), (996, "חלק גורשו, חלק ברחו מאלימות,", "#D2AA53", 42, 800),
     (1050, "וחלק בחרו בציונות.", "#D2AA53", 42, 800), (1150, "Historians still debate the mix.  |  היסטוריונים עדיין חלוקים.", "#a9bbd8", 30, 700)]),
 "CARD2": dict(edge="#a9bbd8", ew=3, y=560, h=520, lines=[(660, "Communities 2,000+ years old", "#FFFFFF", 54, 900),
     (740, "are almost gone.", "#FFFFFF", 54, 900),
     (860, "קהילות בנות יותר מ-2,000 שנה", "#FFFFFF", 46, 800), (924, "כמעט נעלמו.", "#FFFFFF", 46, 800),
     (1020, "Arab countries + Iran, 1948 vs today", "#a9bbd8", 30, 700)]),
 "END": dict(edge="#D2AA53", ew=4, y=560, h=520, lines=[(650, "So where can Jews", "#FFFFFF", 60, 900), (740, "walk safely today?", "#D2AA53", 72, 900),
     (860, "אז איפה יהודי יכול", "#FFFFFF", 48, 800), (924, "להסתובב בבטחה היום?", "#D2AA53", 48, 800),
     (1020, "Arab countries + Iran, 1948 vs today", "#a9bbd8", 30, 700)]),
}
WHOOSH = _f0 - 0.45
HITS = [T_CARDS[0][1], T_CARDS[1][1], T_CARDS[2][1]]

from PIL import ImageFont as _IF
_D = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))
_txt = [e[1] + e[2] for e in EVENTS] + [l for v in DISC.values() for l in v] + [l[1] for cd in CARDS.values() for l in cd["lines"]] + [l[1] for l in HOOK["lines"]]
assert not any(d in s for s in _txt for d in _D)
assert not any(re.search(r"part\s*\d|חלק\s*\d", s, re.I) for s in _txt), "no Part X"
_f = _IF.truetype("/home/claude/vid/fonts/Heebo-700.ttf", DISC_FS * 2)
for _v in DISC.values():
    for _l in _v: assert _f.getlength(_l) <= 900 * 2, ("source line too wide", _l)
