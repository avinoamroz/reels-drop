"""common.py: shared drawing, timing, subtitle and render helpers for israel_money_100 and world_money_3000
(adapted from jews_white/engine.py). Brand: night #0B1426, navy #163261, sky #45A4DD, gold #FFCD50, Heebo."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"


def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def mixc(c1, c2, u): return tuple(lerp(a, b, u) for a, b in zip(c1[:3], c2[:3])) + (1.0,)

NIGHT, NAVY, NAVY2, SKY, GOLD = hx("#0B1426"), hx("#163261"), hx("#1E3F78"), hx("#45A4DD"), hx("#FFCD50")
RED, GREENB, MUTE, INK, LINE = hx("#E5484D"), hx("#3FBF7F"), hx("#9AA7BE"), hx("#F4F6FA"), hx("#24324D")
GREEN = (46 / 255, 204 / 255, 113 / 255, 1); WHITE = (1, 1, 1, 1)
GOLD_IL, GOLD_PA = hx("#E0B252"), hx("#B8923F")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    if a <= 0.01 or not s: return 0
    size = int(size)
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def parts(c, ps, size, y, a=1.0, w=900, sc=1.0, maxw=980, cx=540):
    while size > 64 and sum(font(size, w).getlength(s) for s, _ in ps) > maxw: size -= 2
    tot = sum(font(size, w).getlength(s) for s, _ in ps); x = cx - tot / 2
    c.save(); c.translate(cx, y); c.scale(sc, sc); c.translate(-cx, -y)
    for s, col in ps: x += text(c, s, size, x, y, w, col, a, "l")
    c.restore()
def fit(s, size, maxw, w=800, mn=36):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def wrap(s, size, maxw, w=800):
    out, cur = [], ""
    for wd in s.split():
        tst = (cur + " " + wd).strip()
        if font(size, w).getlength(tst) <= maxw or not cur: cur = tst
        else: out.append(cur); cur = wd
    if cur: out.append(cur)
    return out
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def poly(c, rings, P):
    for r in rings:
        for i, (lo, la) in enumerate(r):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.close_path()
def pin(c, x, y, col, a, sc=1.0):
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.scale(sc, sc)
    c.move_to(0, 0); c.curve_to(-6, -14, -20, -22, -20, -36); c.arc(0, -36, 20, math.pi, 0); c.curve_to(20, -22, 6, -14, 0, 0); c.close_path()
    c.set_source_rgba(*col[:3], a); c.fill_preserve(); c.set_source_rgba(1, 1, 1, a); c.set_line_width(3); c.stroke()
    c.arc(0, -36, 7, 0, 6.283); c.set_source_rgba(*NIGHT[:3], a); c.fill(); c.restore()


class Timing:
    def __init__(self, D, tail=1.15):
        TM = json.load(open(f"{D}/timing.json")); self.L = TM["lines"]; self.n = len(self.L)
        self.END = round(self.L[-1]["t1"] + tail, 2)
        self.CUT = [0.0] + [self.L[i]["t0"] - 0.15 for i in range(1, self.n)] + [self.END]
        self.T_FADE = self.END - 0.85
    @staticmethod
    def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
    def wt(self, li, word, nth=0, end=False):
        ws = [w for w in self.L[li]["words"] if self.norm(w["w"]).startswith(self.norm(word))]
        if not ws: return self.L[li]["t0"]
        return ws[min(nth, len(ws) - 1)]["t1" if end else "t0"]
    def lt(self, li): return self.L[li]["t0"]
    def scene(self, t):
        for i in range(self.n):
            if t < self.CUT[i + 1]: return i
        return self.n - 1


def build_subs(TM, repl):
    items = []
    for L in TM.L:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in repl:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower().rstrip(".,?") == a_.lower():
                    hit = (n, b_ + (ws[i + n - 1]["w"][-1] if ws[i + n - 1]["w"][-1] in ".,?" else "")); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;").replace("SIXTY", "sixty")
    return items
def draw_subs(c, t, subs, bottom=1712, size=54):
    for a0, a1, s in subs:
        if a0 <= t < a1:
            f = font(size, 800); lines = wrap(s, size, 900); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = bottom - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.84); c.fill()
            for n, l in enumerate(lines): text(c, l, size, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return


def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NIGHT[:3], 1); g.add_color_stop_rgba(0.55, *hx("#10203F")[:3], 1); g.add_color_stop_rgba(1, *NAVY[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1000, 760, SKY, 0.10); return s
def to_np(s):
    s.flush(); a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)
def load_photo(path, w, h):
    """cover-crop a photo to w x h (returns a cairo surface), None if missing"""
    if not path or not os.path.exists(path): return None
    im = Image.open(path).convert("RGB"); sc = max(w / im.width, h / im.height) * 1.1
    im = im.resize((int(im.width * sc), int(im.height * sc)), Image.LANCZOS)
    return pil2cairo(im.convert("RGBA"))


def run(D, TM, frame, args):
    if "--frames" in args:
        out = args[args.index("--qa") + 1] if "--qa" in args else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in args[args.index("--frames") + 1].split(","):
            tt = float(x); img = frame(tt)
            if tt >= TM.T_FADE:
                u = ease((tt - TM.T_FADE) / (TM.END - TM.T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
            Image.fromarray(img).save(f"{out}/f_{tt:06.2f}.png")
        print("END", TM.END); return
    outp = args[args.index("--out") + 1] if "--out" in args else f"{D}/out.mp4"
    n = int(round(TM.END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{TM.END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= TM.T_FADE:
            u = ease((tt - TM.T_FADE) / (TM.END - TM.T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, TM.END)
