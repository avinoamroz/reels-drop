"""arab_econ_fix: what holds many Arab economies back (4 sourced numbers vs the EU and Israel), and the 6 fixes the
World Bank and IMF point to, each with a real regional example. Region map (Arab League sky, EU steel, the whole land
of Israel gold with West Bank and Gaza darker gold and the Green Line green, plus a zoom inset), scorecard rows sorted
best first, then a checklist that lights up. Circular: "It all starts with these..." -> frame 0 "4 numbers holding
Arab economies back". Icons and type only.
python3 engine.py [--frames t1,t2,...] [--out path.mp4]"""
import os, sys, math, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

D = os.path.dirname(os.path.abspath(__file__)); ARGS = sys.argv[1:]
TM = Timing(D); wt, CUT, END = TM.wt, TM.CUT, TM.END

GR = json.load(open(f"{D}/geo_region.json")); GIL = json.load(open(f"{D}/geo_il.json"))
SEA = hx("#0E2348"); OTHER = hx("#1C3566"); EUC = hx("#8FA3C7"); ARABC = SKY
COL = {"arab": ARABC, "eu": EUC, "il": GOLD_IL}

# ------------------------------------------------------------------ map
class View:
    def __init__(self, lon, lat, k, cosl=None):
        self.lon, self.lat, self.k = lon, lat, k; self.cf = cosl or math.cos(math.radians(lat))
    def P(self, cx, cy):
        return lambda lo, la: (cx + (lo - self.lon) * self.cf * self.k, cy - (la - self.lat) * self.k)

V1 = View(22, 36, 13.5)            # Europe + Middle East + North Africa
V2 = View(43, 27, 14.0)            # Middle East close-up
IL_C = (34.9, 31.6)

def draw_il(c, P, a, lw=3.0):
    poly(c, GIL["isr"], P); c.set_source_rgba(*GOLD_IL[:3], a); c.fill()
    poly(c, GIL["pal"], P); c.set_source_rgba(*GOLD_PA[:3], a); c.fill()
    if GIL.get("lakes"):
        poly(c, GIL["lakes"], P); c.set_source_rgba(*SEA[:3], a); c.fill()
    c.set_source_rgba(*GREEN[:3], a); c.set_line_width(lw)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()

def draw_map(c, rect, view, a, glow_g=None, hi=None, t=0.0, inset=True, dim_others=1.0):
    """glow_g: {group: strength 0..1}; hi: {ADM0_A3 or 'IL': (colour, strength)}"""
    if a <= 0.01: return
    x0, y0, w, h = rect; P = view.P(x0 + w / 2, y0 + h / 2); glow_g = glow_g or {}; hi = hi or {}
    c.save(); rr(c, x0, y0, w, h, 34); c.set_source_rgba(*SEA[:3], a); c.fill_preserve(); c.clip()
    for code, f in GR.items():
        g = f["g"]; base = OTHER if g == "other" else COL[g]
        if g == "arab": col = mixc(hx("#2B5C91"), ARABC, glow_g.get("arab", 0))
        elif g == "eu": col = mixc(hx("#4A5F86"), EUC, glow_g.get("eu", 0))
        else: col = OTHER
        if code in hi: col = mixc(col, hi[code][0], hi[code][1])
        poly(c, f["rings"], P); c.set_source_rgba(*col[:3], a * (dim_others if code not in hi else 1.0)); c.fill_preserve()
        c.set_source_rgba(*NIGHT[:3], 0.55 * a); c.set_line_width(1.1); c.stroke()
    draw_il(c, P, a, 2.2)
    if "IL" in hi and hi["IL"][1] > 0.01:
        x, y = P(*IL_C); ph = (t * 1.1) % 1.0
        c.set_source_rgba(*GOLD[:3], a * hi["IL"][1] * (1 - ph)); c.set_line_width(4); c.arc(x, y, 14 + 46 * ph, 0, 6.283); c.stroke()
    for code, (colr, s) in hi.items():
        if code == "IL" or s <= 0.01 or code not in GR: continue
        xs, ys = zip(*[P(lo, la) for r in GR[code]["rings"] for lo, la in r]); x, y = sum(xs) / len(xs), sum(ys) / len(ys)
        ph = (t * 1.1) % 1.0; c.set_source_rgba(*colr[:3], a * s * (1 - ph)); c.set_line_width(4); c.arc(x, y, 18 + 60 * ph, 0, 6.283); c.stroke()
    c.restore()
    rr(c, x0, y0, w, h, 34); c.set_source_rgba(*SKY[:3], 0.35 * a); c.set_line_width(2); c.stroke()
    if inset:                                   # zoom inset: the whole land of Israel with the Green Line
        ix, iy = P(IL_C[0], IL_C[1]); cx_, cy_, R = x0 + 150, y0 + h - 132, 112
        c.set_source_rgba(1, 1, 1, 0.55 * a); c.set_line_width(2); c.move_to(ix, iy); c.line_to(cx_ + R * 0.7, cy_ - R * 0.7); c.stroke()
        c.arc(ix, iy, 13, 0, 6.283); c.stroke()
        c.save(); c.arc(cx_, cy_, R, 0, 6.283); c.set_source_rgba(*SEA[:3], a); c.fill_preserve(); c.clip()
        Pz = View(35.0, 31.45, 52.0).P(cx_ + 6, cy_)
        for code in ("EGY", "JOR", "SYR", "LBN", "SAU"):
            if code in GR: poly(c, GR[code]["rings"], Pz); c.set_source_rgba(*mixc(hx("#2B5C91"), ARABC, glow_g.get("arab", 0))[:3], a); c.fill()
        draw_il(c, Pz, a, 2.6); c.restore()
        c.arc(cx_, cy_, R, 0, 6.283); c.set_source_rgba(*GOLD[:3], 0.9 * a); c.set_line_width(3); c.stroke()
    if not inset: return
    # legend chips
    lx = x0 + w - 24; ly = y0 + 54
    for lab, colr in (("Israel", GOLD_IL), ("EU", EUC), ("Arab League", ARABC)):
        tw = font(38, 800).getlength(lab); bx = lx - tw - 52
        rr(c, bx - 12, ly - 38, tw + 76, 54, 16); c.set_source_rgba(*NIGHT[:3], 0.78 * a); c.fill()
        c.arc(bx + 12, ly - 11, 11, 0, 6.283); c.set_source_rgba(*colr[:3], a); c.fill()
        text(c, lab, 38, bx + 34, ly, 800, WHITE, a, "l"); ly += 64

# ------------------------------------------------------------------ data
#   name, value, display, group, (line, word that lands it)
ROWS = [
    dict(li=2, title="Women at work", sub="Women 15+ in the labour force",
         cells=[("Israel", 62, "62%", "il", "Israel"), ("EU", 52, "52%", "eu", "Europe"), ("MENA region", 19, "19%", "arab", "About")],
         src="World Bank 2025 (MENA, Israel). OECD 2019 (EU)"),
    dict(li=3, title="Youth without jobs", sub="Unemployment, ages 15 to 24",
         cells=[("Israel", 6.0, "6%", "il", "Israel"), ("EU", 14.7, "14.7%", "eu", "Europe"), ("Arab States", 26.2, "26.2%", "arab", "Twenty")],
         src="ILO 2025 (Arab States). Eurostat, Dec 2025. World Bank 2025 (Israel)"),
    dict(li=4, title="Clean government", sub="Corruption Perceptions Index, 100 = very clean",
         cells=[("Israel", 64, "64", "il", "Israel"), ("EU", 64, "64", "eu", "Europe"), ("Arab average", 34, "34", "arab", "Arab")],
         src="Transparency International, CPI 2024. Arab: average of 21 scored members"),
    dict(li=5, title="Trade with neighbours", sub="Share of trade inside its own region",
         cells=[("EU", 60, "60%+", "eu", "Europe"), ("Arab League", 11, "11%", "arab", "Arab"), ("Israel", None, "no data", "il", None)],
         src="International Trade Centre (ITC)"),
]
FIX = [
    dict(li=7, label="Grow beyond oil", big=75, fmt="{:.0f}%", cap="of the UAE economy is outside oil", hi={"ARE": GOLD},
         src="UAE Ministry of Economy: non-oil 74.6% of real GDP, Jan to Sep 2024", w="three"),
    dict(li=8, label="Bring women in", big=36, frm=17, fmt="{:.0f}%", cap="Saudi women in the labour force, 2017 to 2024", hi={"SAU": GOLD},
         src="World Bank (2017: 17.4%). GASTAT, Q3 2024: 36.2%", w="seventeen", w2="thirty"),
    dict(li=9, label="Clean it up", big=68, fmt="{:.0f}", cap="UAE corruption score. Israel 64, EU 64.", hi={"ARE": GOLD},
         src="Transparency International, CPI 2024", w="sixty"),
    dict(li=10, label="Invest in research", big=6.3, fmt="{:.1f}%", cap="of Israel's GDP goes to R&D. Highest in the world.", hi={"IL": GOLD},
         src="OECD, 2023. EU: 2.2% (Eurostat, 2024)", w="six"),
    dict(li=11, label="Open trade", big=1, fmt="${:.0f}B+", cap="UAE and Israel trade a year, every year since 2021", hi={"ARE": GOLD, "IL": GOLD},
         src="UN Comtrade 2021 to 2024 (ORF Middle East, 2025). UAE boycott law ended Aug 2020", w="over", arc=True),
    dict(li=12, label="End the wars", big=226, fmt="${:.0f}B", cap="lost by Syria's economy to war. 4x its 2010 GDP.", hi={"SYR": RED},
         src="World Bank, The Toll of War, 2017", w="two", red=True),
]
for R in ROWS:
    R["ta"] = [wt(R["li"], c_[4]) - 0.08 if c_[4] else None for c_ in R["cells"]]
for F in FIX:
    F["t0"] = TM.lt(F["li"]); F["tw"] = wt(F["li"], F["w"]) - 0.1
    if "w2" in F: F["tw2"] = wt(F["li"], F["w2"]) - 0.1

HOOK_RECT = (56, 650, 968, 560); ROW_RECT = (56, 470, 968, 560)
def lerp4(a, b, u): return tuple(lerp(p, q, u) for p, q in zip(a, b))

# ------------------------------------------------------------------ pieces
def draw_hook(c, t, a):
    if a <= 0.01: return
    br = 1 + 0.025 * math.sin(t * 3.0)
    text(c, "4 numbers", 168, 540, 410, 900, GOLD, a, sc=br)
    text(c, "holding Arab", 112, 540, 530, 900, WHITE, a)
    text(c, "economies back", 112, 540, 640 - 12, 900, WHITE, a)
def dots(c, n_on, a, y=300, n=4, col=GOLD, check=False, t_on=None, t=0.0):
    gap = 84 if n == 4 else 74; x0 = 540 - gap * (n - 1) / 2
    for k in range(n):
        on = k < n_on; x = x0 + gap * k
        c.arc(x, y, 26, 0, 6.283)
        if on: c.set_source_rgba(*col[:3], a); c.fill()
        else: c.set_source_rgba(1, 1, 1, 0.35 * a); c.set_line_width(3); c.stroke()
        if check and on: tick(c, x, y, 15, NIGHT, a)
        elif not check: text(c, str(k + 1), 38, x, y + 14, 900, NIGHT if on else WHITE, a * (1 if on else 0.6))
def tick(c, x, y, s, col, a, u=1.0):
    if a <= 0.01 or u <= 0: return
    pts = [(x - s, y), (x - s * 0.3, y + s * 0.7), (x + s, y - s * 0.75)]
    c.set_source_rgba(*col[:3], a); c.set_line_width(s * 0.42); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0]); L1 = clamp(u * 2); c.line_to(lerp(pts[0][0], pts[1][0], L1), lerp(pts[0][1], pts[1][1], L1))
    if u > 0.5: L2 = clamp(u * 2 - 1); c.line_to(lerp(pts[1][0], pts[2][0], L2), lerp(pts[1][1], pts[2][1], L2))
    c.stroke()

def row_glow(R, t):
    g = {}
    for (nm, v, d, grp, w), ta in zip(R["cells"], R["ta"]):
        if ta is None or grp == "il": continue
        g[grp] = 0.35 + 0.65 * ramp(t, ta, ta + 0.3)
    return g
def row_hi(R, t):
    for (nm, v, d, grp, w), ta in zip(R["cells"], R["ta"]):
        if grp == "il" and ta is not None and t >= ta: return {"IL": (GOLD, 1 - ramp(t, ta + 1.5, ta + 2.5))}
    return {}

def draw_row(c, t, R, a):
    if a <= 0.01: return
    text(c, R["title"], fit(R["title"], 104, 960, 900), 540, 412, 900, WHITE, a)
    vmax = max(v for _, v, _, _, _ in R["cells"] if v is not None)
    y0 = 1112
    for k, ((nm, v, d, grp, w), ta) in enumerate(zip(R["cells"], R["ta"])):
        tt = ta if ta is not None else R["ta"][1] + 0.6
        u = eout((t - tt) / 0.6); aa = a * clamp((t - tt + 0.05) / 0.25)
        y = y0 + k * 138
        rr(c, 70, y - 8, 940, 124, 22); c.set_source_rgba(1, 1, 1, 0.06 * a); c.fill()
        if aa <= 0.01: continue
        colr = COL[grp]
        text(c, nm, 54, 100, y + 52, 800, WHITE, aa, "l")
        if v is None:
            text(c, d, 60, 980, y + 54, 800, MUTE, aa, "r"); continue
        cur = v * u
        s = (d.replace(f"{v:g}", f"{cur:.1f}" if "." in d else f"{cur:.0f}")) if u < 1 else d
        text(c, s, 68, 980, y + 56, 900, GOLD, aa, "r")
        rr(c, 100, y + 80, max(10, 860 * (v / vmax) * u), 22, 11); c.set_source_rgba(*colr[:3], aa); c.fill()
        if k == 0 and u >= 1:
            text(c, "best", 38, 100 + font(54, 800).getlength(nm) + 20, y + 50, 800, GREENB, aa * ramp(t, tt + 0.6, tt + 0.9), "l")
    text(c, R["sub"], fit(R["sub"], 44, 960, 700), 540, 1084, 700, MUTE, a)

# checklist (part 2)
CLX, CLY, CLH = 70, 486, 168
def fix_state(t):
    on = [k for k, F in enumerate(FIX) if t >= F["t0"] - 0.15]
    return on
def draw_checklist(c, t, a):
    if a <= 0.01: return
    t6 = TM.lt(6)
    for k, F in enumerate(FIX):
        y = CLY + k * CLH
        app = ramp(t, t6 + 0.1 + 0.2 * k, t6 + 0.4 + 0.2 * k)
        aa = a * app
        if aa <= 0.01: continue
        lit = t >= F["t0"] - 0.15; cur = lit and (k == len(FIX) - 1 or t < FIX[k + 1]["t0"] - 0.15) and t < CUT[13]
        u = ramp(t, F["t0"] - 0.15, F["t0"] + 0.25)
        if cur: rr(c, CLX - 10, y - 4, 466, CLH - 18, 24); c.set_source_rgba(1, 1, 1, 0.10 * aa); c.fill()
        cx, cy = CLX + 40, y + 70; colr = RED if F.get("red") else GREENB
        c.arc(cx, cy, 34, 0, 6.283); c.set_source_rgba(1, 1, 1, 0.4 * aa); c.set_line_width(3); c.stroke()
        if u > 0:
            c.arc(cx, cy, 34 * eob(u), 0, 6.283); c.set_source_rgba(*GREENB[:3], aa); c.fill(); tick(c, cx, cy, 17, NIGHT, aa, u)
        lines = wrap(F["label"], 56, 350)
        for n, ln in enumerate(lines):
            text(c, ln, 56, CLX + 96, y + 52 + 62 * n + (31 if len(lines) == 1 else 0), 800, WHITE, aa * (0.55 + 0.45 * u), "l")
def draw_fix_panel(c, t, a):
    if a <= 0.01: return
    on = fix_state(t)
    if not on: return
    k = on[-1]; F = FIX[k]
    ua = ramp(t, F["t0"] - 0.15, F["t0"] + 0.2)
    rect = (550, 470, 470, 470)
    hi = {code: (col, 1.0) for code, col in F["hi"].items()}
    draw_map(c, rect, V2, a, glow_g={"arab": 0.0}, hi=hi, t=t, inset=False, dim_others=1.0)
    if F.get("arc"):
        P = V2.P(rect[0] + rect[2] / 2, rect[1] + rect[3] / 2); x1, y1 = P(54.4, 24.4); x2, y2 = P(*IL_C)
        mx, my = (x1 + x2) / 2, min(y1, y2) - 120; u = eout((t - F["t0"]) / 0.9)
        c.save(); rr(c, *rect, 34); c.clip(); c.set_source_rgba(*GOLD[:3], a); c.set_line_width(6); c.set_dash([18, 12], -t * 60)
        n = 30
        for i in range(int(n * u) + 1):
            s = i / n; bx = (1 - s) ** 2 * x1 + 2 * (1 - s) * s * mx + s * s * x2; by = (1 - s) ** 2 * y1 + 2 * (1 - s) * s * my + s * s * y2
            (c.move_to if i == 0 else c.line_to)(bx, by)
        c.stroke(); c.restore()
    if "frm" in F:
        if t < F["tw"]: v = None
        elif t < F["tw2"]: v = F["frm"] * eout((t - F["tw"]) / 0.5)
        else: v = lerp(F["frm"], F["big"], eout((t - F["tw2"]) / 0.9))
    else:
        v = F["big"] * eout((t - F["tw"]) / 0.9) if t >= F["tw"] else None
    if v is not None:
        s = F["fmt"].format(v if F["big"] != 1 else 1)
        text(c, s, fit(F["fmt"].format(F["big"]), 150, 450, 900), 785, 1110, 900, RED if F.get("red") else GOLD, a * ua)
    for n, ln in enumerate(wrap(F["cap"], 52, 450)):
        text(c, ln, 52, 785, 1200 + 64 * n, 800, WHITE, a * ua)

def draw_payoff(c, t, a):
    if a <= 0.01: return
    l = 13
    for k, (s, w_, size, col) in enumerate((("It's not the people.", "not", 92, WHITE), ("It's the system.", "system", 104, GOLD),
                                            ("And some are already", "some", 68, SKY), ("changing it.", "some", 68, SKY))):
        ta = wt(l, w_) - 0.25; u = ramp(t, ta, ta + 0.3)
        text(c, s, size, 540, 1130 + [0, 130, 250, 336][k] + (1 - eout((t - ta) / 0.4)) * 24, 900, col, a * u)

SRC_ROW = {R["li"]: R["src"] for R in ROWS}; SRC_FIX = {F["li"]: F["src"] for F in FIX}
def draw_source(c, t):
    i = TM.scene(t); s = SRC_ROW.get(i) or SRC_FIX.get(i)
    if i == 6: s = "IMF Regional Economic Outlook, MENA. World Bank MENAAP Update, Oct 2025"
    if i in (0, 1): s = "Map: Natural Earth. Green Line: 1949 armistice line"
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1]))
    for n, ln in enumerate(wrap(s, 38, 960, 700)[:2]):
        text(c, ln, 38, 540, 1566 + 46 * n, 700, MUTE, a)

REPL = [("Four numbers", "4 numbers"), ("one in five", "1 in 5"), ("fifty-two percent", "52%"), ("sixty-two", "62"),
        ("Twenty-six percent", "26%"), ("fifteen", "15"), ("six percent", "6%"), ("six", "6"), ("thirty-four", "34"),
        ("sixty-four", "64"), ("eleven percent", "11%"), ("over sixty", "over 60"), ("seventeen percent", "17%"),
        ("thirty-six", "36%"), ("sixty-eight", "68"), ("two hundred and twenty-six billion dollars", "$226 billion"),
        ("a billion dollars", "$1 billion"), ("three quarters", "three quarters")]
SUBS = build_subs(TM, REPL)
BG = bg_surface()

def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = TM.scene(t)
    if i <= 1:
        draw_hook(c, t, 1.0 if i == 0 else 1 - ramp(t, CUT[2] - 0.35, CUT[2]))
        sweep = 0.5 + 0.5 * math.sin(t * 2.4)
        draw_map(c, HOOK_RECT, V1, 1.0, glow_g={"arab": 0.45 + 0.55 * ramp(t, 0.3, 1.2) * sweep, "eu": 0.35}, hi={"IL": (GOLD, 1.0)}, t=t)
        if i == 1:
            u = ramp(t, CUT[1], CUT[1] + 0.35)
            text(c, "and the fixes that", 70, 540, 1300, 900, SKY, u); text(c, "already work", 70, 540, 1384, 900, SKY, u)
            dots(c, sum(1 for k in range(6) if t >= CUT[1] + 0.4 + 0.18 * k), u, y=1480, n=6, col=GREENB, check=True)
    elif i <= 5:
        R = ROWS[i - 2]; m = ramp(t, CUT[2], CUT[2] + 0.5)
        rect = lerp4(HOOK_RECT, ROW_RECT, eout((t - CUT[2]) / 0.5))
        draw_map(c, rect, V1, 1.0, glow_g=row_glow(R, t) | {"eu": row_glow(R, t).get("eu", 0.3)}, hi=row_hi(R, t), t=t)
        ra = ramp(t, CUT[i], CUT[i] + 0.3) * (1 - ramp(t, CUT[i + 1] - 0.2, CUT[i + 1]))
        dots(c, i - 1, m, y=300)
        draw_row(c, t, R, ra)
    elif i <= 12:
        a6 = ramp(t, CUT[6], CUT[6] + 0.35)
        text(c, "What works?", 112, 540, 360, 900, WHITE, a6)
        text(c, "World Bank and IMF advice", 46, 540, 428, 700, MUTE, a6)
        draw_checklist(c, t, a6)
        draw_fix_panel(c, t, a6)
    else:
        a = 1.0 if i == 13 else 1 - ramp(t, CUT[14], CUT[14] + 0.4)
        u = ramp(t, CUT[13], CUT[13] + 0.4)
        dots(c, 6, a * u, y=300, n=6, col=GREENB, check=True)
        if i == 13:
            draw_map(c, ROW_RECT, V1, u, glow_g={"arab": 0.6 + 0.3 * math.sin(t * 2), "eu": 0.35},
                     hi={"ARE": (GOLD, 0.8), "SAU": (GOLD, 0.8), "MAR": (GOLD, 0.5), "IL": (GOLD, 0.6)}, t=t)
            draw_payoff(c, t, 1.0)
        else:
            v = eout((t - CUT[14]) / 0.6)
            rect = lerp4(ROW_RECT, HOOK_RECT, v)
            draw_map(c, rect, V1, 1.0, glow_g={"arab": 0.7, "eu": 0.35}, hi={"IL": (GOLD, 1.0)}, t=t)
            b = ramp(t, CUT[14], CUT[14] + 0.3)
            text(c, "It all starts", 104, 540, 440, 900, WHITE, b)
            text(c, "with these...", 104, 540, 560, 900, GOLD, b)
    draw_source(c, t)
    draw_subs(c, t, SUBS)
    return to_np(s)

def SFX():
    ev = []
    for R in ROWS: ev += [(ta + 0.05, "pop", -2) for ta in R["ta"] if ta is not None]
    ev += [(F["t0"] - 0.1, "pop", 0) for F in FIX]
    ev += [(CUT[i] - 0.1, "whoosh", -3) for i in (2, 6, 13)]
    ev += [(wt(13, "system") - 0.1, "ding", -1)]
    return ev

if __name__ == "__main__":
    run(D, TM, frame, ARGS)
