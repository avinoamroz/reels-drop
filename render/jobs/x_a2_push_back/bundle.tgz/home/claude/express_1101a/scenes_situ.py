"""scenes_situ.py (1 Nov, Express batch A): situational English scenes. A visual scene first (office, Zoom, email, meeting)
with stick figures in the house colour code (blue = the speaker / active, orange = the listener / passive), then the English
line as what the Israeli says (red speech bubble), what the American hears (orange), and what to say (green card, new words
highlighted). Hebrew only as one small bottom line. Loads scenes_x (speaker end card, loop cross-fade, looping bed).

Scene types
  situ_hook  {"en": hook (<= 6 words), "setting": office|zoom|email|meeting, "react": "?!"}
  situ       {"setting", "neg", "hear", "pos", "he", "n": "1 of 4", "verb": "Say"|"Write", "hear_label": "They hear",
              "marks": {"n": wrong line spoken, "h": hear spoken, "p0": correction spoken}}
  situ_text  {"en", "sub", "marks": {"s": sub spoken}}  payoff card, both figures happy
  seven      {"marks": {"f": "Then explain"}}  7-minute fluency card
  share      {"en", "emoji"}  share line end card (no keyword)
  meter      {"neg" (the sentence), "value", "prev", "label", "bad": bool, "n", "marks": {"v": value spoken, "l": label spoken}}
"""
import importlib.util, math
_p = "/home/claude/express_1031_cta/scenes_x.py"
_s = importlib.util.spec_from_file_location("scenes_x", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
for _k, _v in vars(_m).items():
    if _k.startswith("sc_"): globals()[_k] = _v
import render as RD
from render import P, T, PP, fade_in, source, block, block_h, shadow_box, pill, draw_emoji, series_chip
from kit import ease, St, sa, rr, lerp, ramp, font as kfont
_mark = _m._mark

BLUE = (0x2A / 255, 0x88 / 255, 0xD4 / 255, 1.0); ORANGE = (0xF2 / 255, 0x8C / 255, 0x28 / 255, 1.0)
INK = (0.086, 0.196, 0.376, 1.0)


def _line(c, pts, w, color):
    sa(c, color, St.a); c.set_line_width(w); c.set_line_cap(1); c.set_line_join(1)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()


def figure(c, x, yf, h, color, t, mode, face=1, ph=0.0):
    """stick figure, feet at (x, yf), height h. modes: talk, listen, facepalm, shock, happy"""
    lw = h * 0.05; hr = h * 0.12
    bob = math.sin(t * 2.4 + ph) * h * 0.006
    if mode == "happy": bob = -abs(math.sin(t * 6 + ph)) * h * 0.02
    if mode == "shock": bob = -h * 0.015
    hip = (x, yf - h * 0.45 + bob); neck = (x, yf - h * 0.80 + bob)
    head = (neck[0] + face * h * 0.01, neck[1] - hr * 1.05)
    _line(c, [(hip[0] - h * 0.11, yf), hip, (hip[0] + h * 0.11, yf)], lw, color)
    _line(c, [hip, neck], lw, color)
    sh = (neck[0], neck[1] + h * 0.05)
    if mode == "talk":
        a = 0.6 + 0.45 * math.sin(t * 5.5 + ph)
        el = (sh[0] + face * h * 0.17, sh[1] + h * 0.10); hd = (el[0] + face * h * 0.14 * math.cos(a), el[1] - h * 0.14 * math.sin(a))
        _line(c, [sh, el, hd], lw, color)
        _line(c, [sh, (sh[0] - face * h * 0.08, sh[1] + h * 0.17), (sh[0] - face * h * 0.06, sh[1] + h * 0.32)], lw, color)
    elif mode == "facepalm":   # forearm up to the forehead (a plain line, no hand shape)
        _line(c, [sh, (sh[0] + face * h * 0.16, sh[1] + h * 0.02), (head[0] + face * hr * 0.2, head[1] - hr * 0.1)], lw, color)
        _line(c, [sh, (sh[0] - face * h * 0.08, sh[1] + h * 0.17), (sh[0] - face * h * 0.06, sh[1] + h * 0.32)], lw, color)
    elif mode == "shock":      # both arms up and out
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.15, sh[1] - h * 0.04), (sh[0] + s_ * h * 0.22, sh[1] - h * 0.16)], lw, color)
    elif mode == "happy":      # arms up in a V
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.12, sh[1] - h * 0.10), (sh[0] + s_ * h * 0.18, sh[1] - h * 0.24)], lw, color)
    else:
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.09, sh[1] + h * 0.17), (sh[0] + s_ * h * 0.07, sh[1] + h * 0.33)], lw, color)
    sa(c, color, St.a); c.set_line_width(lw); c.new_sub_path(); c.arc(head[0], head[1], hr, 0, 2 * math.pi); c.stroke()
    ex = head[0] + face * hr * 0.28; ey = head[1] - hr * 0.12
    sa(c, color, St.a)
    er = hr * (0.13 if mode == "shock" else 0.09)
    for dx in (-hr * 0.22, hr * 0.22):
        c.new_sub_path(); c.arc(ex + dx, ey, er, 0, 2 * math.pi); c.fill()
    c.set_line_width(lw * 0.7)
    if mode == "happy":
        c.new_sub_path(); c.arc(ex, head[1] + hr * 0.15, hr * 0.38, 0.15 * math.pi, 0.85 * math.pi); c.stroke()
    elif mode == "shock":
        c.new_sub_path(); c.arc(ex, head[1] + hr * 0.45, hr * 0.16, 0, 2 * math.pi); c.stroke()
    elif mode == "facepalm":
        c.new_sub_path(); c.arc(ex, head[1] + hr * 0.62, hr * 0.3, 1.15 * math.pi, 1.85 * math.pi); c.stroke()
    else:
        c.move_to(ex - hr * 0.2, head[1] + hr * 0.4); c.line_to(ex + hr * 0.2, head[1] + hr * 0.4); c.stroke()
    return head


def _panel(c, x0, y0, x1, y1, a=1.0):
    sa(c, INK, 0.10 * a * St.a); rr(c, x0 + 3, y0 + 12, x1 - x0, y1 - y0, 40); c.fill()
    sa(c, P["white"], 0.92 * a * St.a); rr(c, x0, y0, x1 - x0, y1 - y0, 40); c.fill()


def _setting(c, kind, x0, y0, x1, y1, t, spk, lis, h, yf):
    """draw the setting and the two figures; spk/lis are figure modes"""
    if kind == "zoom":   # three call tiles: You (blue), two Americans (orange)
        n = 3; gap = 22; tw = (x1 - x0 - 40 - gap * (n - 1)) / n; ty0 = yf - h - 40; th = h + 60
        names = ["You", "Mike", "Sarah"]
        for k in range(n):
            tx = x0 + 20 + k * (tw + gap)
            sa(c, (0.13, 0.16, 0.22, 1.0), St.a); rr(c, tx, ty0, tw, th, 26); c.fill()
            if k == 0:
                sa(c, BLUE, St.a); c.set_line_width(7); rr(c, tx, ty0, tw, th, 26); c.stroke()
            c.save(); rr(c, tx, ty0, tw, th, 26); c.clip()
            sa(c, (0.20, 0.24, 0.32, 1.0), St.a); c.arc(tx + tw / 2, ty0 + th + 40, tw * 0.55, 0, 2 * math.pi); c.fill()
            fx = tx + tw / 2; fh = h * 0.92
            figure(c, fx, ty0 + th + 10, fh, BLUE if k == 0 else ORANGE, t, spk if k == 0 else lis, 1 if k == 0 else -1, k * 1.3)
            c.restore()
            T(c, names[k], 38, tx + 70, ty0 + th - 34, P["white"], 1.0, 1.0, 700, maxw=200)
        return (x0 + 20 + tw / 2, ty0 - 4)
    if kind == "email":  # laptop on the left with the American reading it on the right
        lx0, ly0, lx1, ly1 = (x0 + x1) / 2 - 190, yf - h * 0.62, (x0 + x1) / 2 + 190, yf - 30
        sa(c, (0.80, 0.83, 0.88, 1.0), St.a); rr(c, lx0, ly0, lx1 - lx0, ly1 - ly0, 18); c.fill()
        sa(c, (0.20, 0.28, 0.42, 1.0), St.a); rr(c, lx0 + 16, ly0 + 16, lx1 - lx0 - 32, ly1 - ly0 - 32, 10); c.fill()
        sa(c, (0.80, 0.83, 0.88, 1.0), St.a); rr(c, lx0 - 40, ly1 - 4, lx1 - lx0 + 80, 26, 10); c.fill()
        T(c, "To: New York", 40, (lx0 + lx1) / 2, (ly0 + ly1) / 2 - 10, P["white"], 1.0, 1.0, 700, maxw=320)
        sa(c, INK, 0.25 * St.a); c.rectangle(x0 + 20, yf + 4, x1 - x0 - 40, 8); c.fill()
        hd = figure(c, x0 + 150, yf, h, BLUE, t, spk, 1, 0.0)
        figure(c, x1 - 150, yf, h, ORANGE, t, lis, -1, 1.3)
        return (hd[0] + 40, hd[1] - h * 0.14)
    # office / meeting: desk line, window, the Israeli (blue) left and the American (orange) right
    if kind == "office":
        wx0, wy0 = (x0 + x1) / 2 - 110, yf - h - 10
        sa(c, (0.85, 0.91, 0.97, 1.0), St.a); rr(c, wx0, wy0, 220, 170, 14); c.fill()
        sa(c, INK, 0.35 * St.a); c.set_line_width(5); rr(c, wx0, wy0, 220, 170, 14); c.stroke()
        c.move_to(wx0 + 110, wy0); c.line_to(wx0 + 110, wy0 + 170); c.move_to(wx0, wy0 + 85); c.line_to(wx0 + 220, wy0 + 85); c.stroke()
    if kind == "meeting":
        sa(c, (0.62, 0.48, 0.34, 1.0), St.a); rr(c, (x0 + x1) / 2 - 150, yf - h * 0.42, 300, 26, 10); c.fill()
        c.rectangle((x0 + x1) / 2 - 10, yf - h * 0.42, 20, h * 0.42); c.fill()
    sa(c, INK, 0.25 * St.a); c.rectangle(x0 + 20, yf + 4, x1 - x0 - 40, 8); c.fill()
    hd = figure(c, x0 + 190, yf, h, BLUE, t, spk, 1, 0.0)
    figure(c, x1 - 190, yf, h, ORANGE, t, lis, -1, 1.3)
    return (hd[0] + 40, hd[1] - h * 0.14)


def _bubble(c, x0, y0, x1, y1, tail, color, a):
    old = St.a; St.a *= a
    sa(c, INK, 0.12 * St.a); rr(c, x0 + 3, y0 + 10, x1 - x0, y1 - y0, 34); c.fill()
    sa(c, P["white"], St.a); rr(c, x0, y0, x1 - x0, y1 - y0, 34); c.fill()
    tx, ty = tail
    c.move_to(min(max(tx - 40, x0 + 40), x1 - 120), y1 - 2); c.line_to(tx, ty); c.line_to(min(max(tx + 30, x0 + 110), x1 - 40), y1 - 2); c.close_path()
    sa(c, P["white"], St.a); c.fill()
    sa(c, color, St.a); c.set_line_width(6); rr(c, x0, y0, x1 - x0, y1 - y0, 34); c.stroke()
    St.a = old


def sc_situ_hook(c, t, S):
    series_chip(c, t, S)
    hk = S["en"]; hh = block_h(hk, 126, 900, 960, 3)
    block(c, hk, 126, 540, 360 + hh / 2, P["navy"], 1.0, 1.0 + 0.012 * math.sin(t * 2.2), 900, hl=P["blue"], maxw=960, max_lines=3)
    y0 = 360 + hh + 60; y1 = 1450
    _panel(c, 70, y0, 1010, y1)
    h = min(520, (y1 - y0) - 140); yf = y1 - 50
    mode_l = "facepalm" if (t % 3.0) > 0.4 else "shock"
    _setting(c, S.get("setting", "office"), 70, y0, 1010, y1, t, "talk", mode_l, h, yf)
    r = S.get("react", "?!")
    if r:
        T(c, r, 110, 1010 - 190 + 8 * math.sin(t * 5), yf - h - 70, ORANGE, 1.0, 1.0 + 0.06 * math.sin(t * 6), 900)
    source(c, t, S)


def sc_situ(c, t, S):
    t0 = S["t0"]; tn = S["times"].get("n", t0 + 0.05); th = S["times"].get("h", tn + 1.6); tp = S["times"].get("p0", th + 1.6)
    # counter
    if S.get("n"):
        a, s = PP(t, t0 + 0.02, S); pill(c, S["n"], 44, 540, 300, P["navy"], P["white"], a, s, w=800)
    # scene panel
    x0, y0, x1, y1 = 70, 360, 1010, 970
    pa = fade_in(t, t0, S, 0.25); old = St.a; St.a *= pa
    _panel(c, x0, y0, x1, y1)
    lis = "listen" if t < th - 0.05 else ("facepalm" if S.get("react", "facepalm") == "facepalm" else "shock")
    if t >= tp: lis = "happy"
    spk = "talk" if t < th else ("listen" if t < tp else "happy")
    kind = S.get("setting", "office"); h = 290; yf = y1 - 40
    tail = _setting(c, kind, x0, y0, x1, y1, t, spk, lis, h, yf)
    St.a = old
    # speech bubble (or the email text) with the wrong line
    neg = S["neg"]; hn = block_h(neg, 70, 800, 820, 2)
    ba, bs = PP(t, tn - 0.1, S)
    if ba > 0.01:
        by0 = y0 + 26; by1 = by0 + hn + 56
        _bubble(c, x0 + 30, by0, x1 - 30, by1, (tail[0] + 10, by1 + 50), P["red"], ba)
        old = St.a; St.a *= ba
        block(c, neg, 70, 540, (by0 + by1) / 2, P["red"], 1.0, 1.0, 800, maxw=820, max_lines=2)
        if t >= tp - 0.05:   # strike through as the fix lands
            k = ease((t - tp + 0.05) / 0.3); z, ls = RD.wrap(neg, 70, 800, 820, 2)
            for j, l in enumerate(ls):
                lw_ = min(820, kfont(z, 800).getlength(l.replace("*", "")))
                yl = (by0 + by1) / 2 - z * 1.14 * len(ls) / 2 + z * 1.14 * (j + 0.5)
                sa(c, P["red"], 0.85 * St.a); c.set_line_width(7); c.move_to(540 - lw_ / 2, yl + 4); c.line_to(540 - lw_ / 2 + lw_ * k, yl + 4); c.stroke()
        St.a = old
    # what they hear
    ha, hs = PP(t, th - 0.1, S, bounce=2.2)
    if ha > 0.01:
        pill(c, S.get("hear_label", "They hear"), 46, 540, 1040, ORANGE, P["white"], ha, hs, w=800)
        block(c, S["hear"], 76, 540, 1130, ORANGE, ha, hs, 900, maxw=940, max_lines=1)
    # what to say
    pos = S["pos"]; hp = block_h(pos, 80, 800, 800, 2); cy0 = 1225; ph = hp + 70
    qa, qs = PP(t, tp - 0.1, S, bounce=2.2)
    if qa > 0.01:
        old = St.a; St.a *= qa
        c.save(); c.translate(540, cy0 + ph / 2); c.scale(qs, qs); c.translate(-540, -(cy0 + ph / 2))
        shadow_box(c, 70, cy0, 940, ph, 44, P["card"], stroke=P["green"], sw=6, sh=8)
        pill(c, S.get("verb", "Say"), 42, 180, cy0, P["green"], P["white"], 1.0, 1.0, w=800)
        _mark(c, 130, cy0 + ph / 2, 30, True)
        block(c, pos, 80, 580, cy0 + ph / 2, P["green"], 1.0, 1.0, 800, hl=P["blue"], maxw=800, max_lines=2)
        c.restore(); St.a = old
        if S.get("he"): T(c, S["he"], 56, 540, cy0 + ph + 55, P["gold_text"], qa, 1.0, 700, maxw=900)
    source(c, t, S)


def sc_situ_text(c, t, S):
    t0 = S["t0"]; ts = S["times"].get("s", t0 + 1.4)
    en = S["en"]; he_ = block_h(en, 110, 900, 960, 3)
    a, s = PP(t, t0 + 0.05, S); block(c, en, 110, 540, 330 + he_ / 2, P["navy"], a, s, 900, hl=P["blue"], maxw=960, max_lines=3)
    y = 330 + he_ + 40
    if S.get("sub"):
        hs_ = block_h(S["sub"], 80, 800, 940, 2); a2, s2 = PP(t, ts, S, bounce=2.2)
        block(c, S["sub"], 80, 540, y + hs_ / 2, P["green"], a2, s2, 800, hl=P["blue"], maxw=940, max_lines=2); y += hs_ + 40
    y0 = max(y, 860); y1 = 1460
    pa = fade_in(t, t0 + 0.1, S, 0.3); old = St.a; St.a *= pa
    _panel(c, 70, y0, 1010, y1)
    _setting(c, S.get("setting", "office"), 70, y0, 1010, y1, t, "happy", "happy", min(420, y1 - y0 - 110), y1 - 45)
    St.a = old
    if S.get("he"): T(c, S["he"], 56, 540, y1 + 50, P["gold_text"], a, 1.0, 700, maxw=900)
    source(c, t, S)


def _phone(c, x, y, a):
    old = St.a; St.a *= a
    sa(c, INK, St.a); rr(c, x - 110, y - 190, 220, 380, 36); c.fill()
    sa(c, (0.15, 0.68, 0.38, 1.0), St.a); rr(c, x - 92, y - 165, 184, 320, 22); c.fill()
    for k, w_ in enumerate((120, 90, 130)):   # voice-note bars
        sa(c, P["white"], St.a); rr(c, x - 70, y - 120 + k * 80, w_, 46, 23); c.fill()
    St.a = old


def sc_seven(c, t, S):
    t0 = S["t0"]; tf = S["times"].get("f", t0 + 3.5)
    a, s = PP(t, t0 + 0.05, S)
    T(c, "7 minutes", 170, 540, 400, P["gold"], a, s * (1 + 0.01 * math.sin(t * 2.5)), 900, maxw=960)
    block(c, "Talk to *yourself* in English on WhatsApp", 76, 540, 580, P["navy"], a, s, 800, hl=P["blue"], maxw=940, max_lines=2)
    _phone(c, 540, 900, a)
    fa, fs = PP(t, tf - 0.05, S, bounce=2.2)
    if fa > 0.01:
        block(c, "Then explain it to a *friend*", 76, 540, 1170, P["navy"], fa, fs, 800, hl=P["blue"], maxw=940, max_lines=2)
        old = St.a; St.a *= fa
        figure(c, 380, 1470, 230, BLUE, t, "talk", 1, 0.0); figure(c, 700, 1470, 230, ORANGE, t, "listen", -1, 1.0)
        St.a = old
    source(c, t, S)


def sc_share(c, t, S):
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S)
    draw_emoji(c, S.get("emoji", "📨"), 540, 470 + 8 * math.sin(t * 2.6), 170, a, s)
    en = S["en"]; he_ = block_h(en, 100, 900, 960, 3)
    block(c, en, 100, 540, 700 + he_ / 2, P["navy"], a, s, 900, hl=P["blue"], maxw=960, max_lines=3)
    y0 = 700 + he_ + 70; y1 = 1460
    if y1 - y0 > 300:
        old = St.a; St.a *= fade_in(t, t0 + 0.1, S, 0.3)
        _panel(c, 70, y0, 1010, y1)
        _setting(c, S.get("setting", "office"), 70, y0, 1010, y1, t, "talk", "happy", min(380, y1 - y0 - 100), y1 - 40)
        St.a = old


def sc_meter(c, t, S):
    """politeness meter: the sentence in a blue speaker's bubble, a 0 to 10 meter whose needle glides from prev to value
    on mark v, a big score and a label (red and shaking when "bad")."""
    t0 = S["t0"]; tv = S["times"].get("v", t0 + 1.6); tl = S["times"].get("l", tv + 0.6); bad = S.get("bad")
    if S.get("n"):
        a, s = PP(t, t0 + 0.02, S); pill(c, S["n"], 44, 540, 300, P["navy"], P["white"], a, s, w=800)
    x0, y0, x1, y1 = 70, 360, 1010, 960
    pa = fade_in(t, t0, S, 0.25); old = St.a; St.a *= pa
    _panel(c, x0, y0, x1, y1)
    lis = "listen" if t < tv else ("shock" if bad else ("happy" if S["value"] >= 7 else "listen"))
    tail = _setting(c, S.get("setting", "office"), x0, y0, x1, y1, t, "talk", lis, 300, y1 - 40)
    St.a = old
    neg = S["neg"]; hn = block_h(neg, 68, 800, 820, 3)
    ba, bs = PP(t, t0 + 0.05, S)
    by0 = y0 + 26; by1 = by0 + hn + 56
    _bubble(c, x0 + 30, by0, x1 - 30, by1, (tail[0] + 10, by1 + 50), P["red"] if bad else BLUE, ba)
    block(c, neg, 68, 540, (by0 + by1) / 2, P["red"] if bad else P["navy"], ba, 1.0, 800, hl=P["blue"], maxw=820, max_lines=3)
    # meter
    mx0, mx1, my = 120, 960, 1060
    u = ease(min(1.0, max(0.0, (t - tv) / 0.8))); v = lerp(S.get("prev", 0), S["value"], u)
    if bad and t > tv + 0.8: v = S["value"] + 0.15 * math.sin(t * 30)
    ga = fade_in(t, t0 + 0.05, S, 0.3); old = St.a; St.a *= ga
    for k in range(10):   # 10 segments, red to green, the last one red again (too polite)
        cc = [P["red"], P["red"], P["amber"], P["amber"], P["gold"], P["gold"], P["green"], P["green"], P["green"], P["red"]][k]
        sx = mx0 + k * (mx1 - mx0) / 10
        sa(c, cc, (0.95 if v >= k + 0.5 else 0.22) * St.a); rr(c, sx + 4, my - 34, (mx1 - mx0) / 10 - 8, 68, 16); c.fill()
    T(c, "0", 40, mx0, my + 76, P["grey"], 1.0, 1.0, 700); T(c, "10", 40, mx1, my + 76, P["grey"], 1.0, 1.0, 700)
    nx = mx0 + (mx1 - mx0) * min(10, max(0, v)) / 10
    sa(c, INK, St.a); c.move_to(nx - 22, my - 62); c.line_to(nx + 22, my - 62); c.line_to(nx, my - 30); c.close_path(); c.fill()
    St.a = old
    va, vs = PP(t, tv - 0.05, S, bounce=2.4)
    if va > 0.01:
        T(c, f"{S['value']}/10", 150, 540, 1260, P["red"] if bad else P["gold"], va, vs, 900)
    la, ls_ = PP(t, tl - 0.05, S, bounce=2.2)
    if la > 0.01:
        block(c, S["label"], 80, 540, 1400, P["red"] if bad else P["navy"], la, ls_, 800, hl=P["blue"], maxw=940, max_lines=1)
        if S.get("he"): T(c, S["he"], 56, 540, 1490, P["gold_text"], la, 1.0, 700, maxw=900)
    source(c, t, S)
