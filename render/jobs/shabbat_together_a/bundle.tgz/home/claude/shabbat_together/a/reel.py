"""shabbat_together_a: "Once a week, Israel stops." (@noamroz__, English, 1 Nov 2026). Engine: /home/claude/shabbat_together/tools/eng.py.
Beats: hook over a Tel Aviv sunset sky, Friday at sunset (Jerusalem Shabbat-times sign, Tel Aviv promenade), the same little scene in
millions of homes (candles / wine / challah panels), 2 in 3 Israeli Jews have a special Friday dinner (IDI 2009) and most are not
Orthodox (Pew 2016), "Ever been to one?", Noam hosting newcomers at an illustrated table, Kiddush (native clip), phones face down and the
aunt, "nobody's in a hurry", the Tel Aviv record tease (GWR 2,761, New York 2025; ours: 3,000, April 2027, noamroz.com/shabbat),
Shabbat Shalom (native clip), lead-in "That's why..." at the hook place with a 0.45 s cross-fade into frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py --out work/silent.mp4"""
import sys, os, json, math, argparse
sys.path.insert(0, "/home/claude/shabbat_together/tools")
from eng import *
D = "/home/claude/shabbat_together/a"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
LW = load_words(D); S, E, WX = make_timing(LW)
T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def b0(li): return S(li) - 0.2

CR = {"tlv9": "Tel Aviv sunset. Photo: Equalhuman, CC0",
      "sign": "Jerusalem. Photo: Danielrosehill, CC BY 4.0",
      "tlv5": "Tel Aviv. Photo: Levi Meir Clancy, CC0",
      "cst": "Photo: Oleg Yunakov, CC BY-SA 4.0",
      "kcup": "Photo: Dimitri, CC BY-SA 3.0",
      "ch6": "Photo: Aviv Hod, CC BY 3.0",
      "chw": "Photo: HaJunkiyada, CC BY-SA 4.0"}

CR3 = ["Photos: Oleg Yunakov, CC BY-SA 4.0.", "Dimitri, CC BY-SA 3.0. Aviv Hod, CC BY 3.0"]
HOOK_A, HOOK_B = "Once a week,", "Israel stops."
HS = 150; HY1, HY2 = 760, 940
HOOK_END = S(1) - 0.15; END_T = S(15) - 0.15
LEAD = "That's why..."

def phones(canvas, t, t0, t1, y=1250):
    a = vis(t, t0, t1, 0.4, 0.3)
    if a <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    for i, x in enumerate((250, 540, 830)):
        u = seg(t, t0 + 0.15 * i, t0 + 0.15 * i + 0.4); yy = y - 40 * (1 - u)
        d.rounded_rectangle((x - 70, yy - 130, x + 70, yy + 130), 30, fill=(28, 28, 34, int(255 * a * u)), outline=(90, 90, 100, int(255 * a * u)), width=4)
        d.rounded_rectangle((x - 40, yy - 112, x + 4, yy - 60), 14, fill=(55, 55, 64, int(255 * a * u)))
        d.ellipse((x - 30, yy - 100, x - 8, yy - 78), fill=(15, 15, 18, int(255 * a * u)))
    canvas.alpha_composite(lay)

def dots3(canvas, t, t0, t1, y=640):
    a = vis(t, t0, t1, 0.4, 0.3)
    if a <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); g = hx(GOLD).astype(int)
    for i, x in enumerate((300, 540, 780)):
        u = seg(t, t0 + 0.25 + 0.3 * i, t0 + 0.55 + 0.3 * i)
        d.ellipse((x - 92, y - 92, x + 92, y + 92), outline=(255, 255, 255, int(200 * a)), width=8)
        if i < 2 and u > 0: d.ellipse((x - 80, y - 80, x + 80, y + 80), fill=(g[0], g[1], g[2], int(255 * a * u)))
    canvas.alpha_composite(lay)

def bars(canvas, t, t0, t1, y1=560, y2=800):
    a = vis(t, t0, t1, 0.4, 0.3)
    if a <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); X0, XW = 70, 940
    u1 = seg(t, t0 + 0.2, t0 + 1.0); u2 = seg(t, t0 + 0.7, t0 + 1.6)
    s = hx(SKY).astype(int); g = hx(GOLD).astype(int)
    d.rounded_rectangle((X0, y1, X0 + XW * 2761 / 3000 * max(u1, 0.02), y1 + 90), 22, fill=(s[0], s[1], s[2], int(255 * a)))
    w2 = XW * max(u2, 0.02)
    for k in range(int(w2 // 40) + 1):                              # dashed gold bar: a goal, not a result
        xa = X0 + k * 40; xb = min(X0 + w2, xa + 26)
        if xb > xa: d.rounded_rectangle((xa, y2, xb, y2 + 90), 10, fill=(g[0], g[1], g[2], int(255 * a)))
    canvas.alpha_composite(lay)
    v1 = roll(t, t0 + 0.2, 0.8, 0, 2761); v2 = roll(t, t0 + 0.7, 0.9, 0, 3000)
    text(canvas, t, "New York, 2025", y1 - 52, 60, t0, t1, fk="dsb", cx=540)
    text(canvas, t, f"{int(round(v1)):,}", y1 + 45, 64, t0 + 0.2, t1, fk="db", color="#06121E", tab=True, cx=X0 + 150)
    text(canvas, t, "World record", y1 + 45, 52, t0 + 1.0, t1, fk="dsb", color="#06121E", cx=X0 + XW * 2761 / 3000 - 170)
    text(canvas, t, "Tel Aviv, April 2027", y2 - 52, 60, t0 + 0.6, t1, fk="dsb", color=GOLD)
    text(canvas, t, f"{int(round(v2)):,}?", y2 + 150, 76, t0 + 0.7, t1, fk="db", color=GOLD, tab=True)

SEATS = [(130, "#B98FD8", "grandma"), (310, "#45A4DD", "newcomer"), (470, "#F08A4B", "friend"), (630, "#6E7A3A", "host"),
         (790, "#E36A8A", "plain"), (950, "#4FB286", "friend")]

def glow_at(t):
    return 0.08 + 0.10 * seg(t, b0(6), b0(6) + 1.0) * (1 - seg(t, b0(10), b0(10) + 0.8)) + 0.08 * seg(t, b0(12), b0(12) + 1.0) * (1 - seg(t, END_T, END_T + 0.6))

def frame_raw(t):
    im = stage(glow_at(t))
    # ---- hook (frame 0) and lead-in (same place)
    bleed(im, t, "tlv9.jpg", 0.5, 0.45, -1, HOOK_END, ain=0.01, aout=0.45, dark=0.45, span=(0, HOOK_END + 0.5))
    if t < HOOK_END + 0.5: credit(im, t, CR["tlv9"], 0, HOOK_END, y=1500, inst=True)
    z = 1 + 0.03 * seg(t, 0, HOOK_END)
    text(im, t, HOOK_A, HY1, HS, 0, HOOK_END, inst=True, zoom=z)
    text(im, t, HOOK_B, HY2, HS, 0, HOOK_END, inst=True, zoom=z, color=GOLD)
    bleed(im, t, "tlv9.jpg", 0.5, 0.45, END_T, T_END + 1, ain=0.6, dark=0.45, span=(0, HOOK_END + 0.5))
    if t > END_T: credit(im, t, CR["tlv9"], END_T + 0.3, T_END + 1, y=1500)
    text(im, t, LEAD, HY1, HS, END_T + 0.1, T_END + 1, ain=0.55)
    # ---- line 1: Friday at sunset
    t0, t1 = b0(1), b0(2); tb = S(1, WX(1, "Even")) - 0.3
    BOX = (60, 250, 1020, 900)
    photo(im, t, "sign.jpg", 0.5, 0.5, t0, tb + 0.2, BOX); credit(im, t, CR["sign"], t0 + 0.1, tb, y=935)
    photo(im, t, "tlv5.jpg", 0.42, 0.5, tb, t1, BOX, ain=0.4); credit(im, t, CR["tlv5"], tb + 0.1, t1, y=935)
    text(im, t, "Friday. Sunset.", 1050, 112, t0 + 0.05, t1)
    text(im, t, "Shops close.", 1195, 80, S(1, WX(1, "shops")) - 0.25, t1, fk="dsb")
    text(im, t, "Streets go quiet.", 1300, 80, S(1, WX(1, "streets")) - 0.25, t1, fk="dsb")
    text(im, t, "Even Tel Aviv slows down.", 1405, fit("Even Tel Aviv slows down.", "dsb", 80), tb + 0.1, t1, fk="dsb", color=GOLD)
    # ---- line 2: millions of homes
    t0, t1 = b0(2), b0(3)
    text(im, t, "Millions of homes.", 860, fit("Millions of homes.", "db", 124), t0, t1)
    text(im, t, "The same little scene.", 1030, fit("The same little scene.", "db", 104), S(2, WX(2, "same")) - 0.2, t1, color=GOLD)
    # ---- line 3: candles / wine / challah, three tall panels
    t0, t1 = b0(3), b0(4)
    items = [("cst.jpg", 0.5, 0.45, "2 candles", "candles"), ("kcup.jpg", 0.5, 0.45, "Wine", "wine"), ("ch6.jpg", 0.5, 0.5, "2 challahs", "braided")]
    for i, (f, fx, fy, lab, w_) in enumerate(items):
        ta = S(3, WX(3, w_)) - 0.35; x0 = 60 + i * 325
        photo(im, t, f, fx, fy, ta, t1, (x0, 330, x0 + 305, 1130), r=28)
        text(im, t, lab, 1210, fit(lab, "dsb", 64, 300), ta + 0.1, t1, fk="dsb", color=GOLD if i == 2 else WHITE, cx=x0 + 152)
    text(im, t, "Under a cloth.", 1340, 72, S(3, WX(3, "under")) - 0.2, t1, fk="dm", color=GREY)
    credit(im, t, CR3, t0 + 0.3, t1, y=1470)
    # ---- line 4: 2 in 3
    t0, t1 = b0(4), b0(5)
    dots3(im, t, t0, t1)
    text(im, t, "More than 2 in 3", 920, 140, t0 + 0.15, t1, color=GOLD)
    text(im, t, "Israeli Jews", 1080, 100, S(4, WX(4, "Israeli")) - 0.2, t1)
    s = "have a special Friday dinner"; text(im, t, s, 1210, fit(s, "dm", 70), S(4, WX(4, "special")) - 0.3, t1, fk="dm")
    # ---- line 5: most are not Orthodox
    t0, t1 = b0(5), b0(6) - 0.05
    text(im, t, "And most of them", 780, 84, t0, t1, fk="dm")
    text(im, t, "aren't Orthodox.", 950, fit("aren't Orthodox.", "db", 140), S(5, WX(5, "even")) - 0.2, t1, color=SKY)
    s = "Orthodox: about 1 in 5 Israeli Jews"; text(im, t, s, 1130, fit(s, "dm", 62), S(5, WX(5, "Orthodox")) + 0.1, t1, fk="dm", color=GREY)
    # ---- lines 6 and 7: the table (empty, then guests)
    t0, t1 = b0(6), b0(8)
    a = vis(t, t0, t1, 0.5, 0.35)
    if a > 0.004:
        seats = [(x, c, k, S(7, WX(7, "newcomers")) - 0.2 + 0.18 * i) for i, (x, c, k) in enumerate(SEATS)]
        im.alpha_composite(table_layer(t, seats, y_table=1180, alpha=a))
    text(im, t, "Ever been to one?", 420, fit("Ever been to one?", "db", 130), t0, S(7) - 0.25)
    text(im, t, "I host dinners", 330, 104, S(7) - 0.2, t1)
    text(im, t, "for newcomers.", 450, 92, S(7, WX(7, "newcomers")) - 0.25, t1, fk="dsb")
    text(im, t, "Jews and non-Jews.", 570, 92, S(7, WX(7, "Jews")) - 0.2, t1, fk="dsb", color=GOLD)
    s = "Just to share beautiful moments."; text(im, t, s, 1420, fit(s, "dm", 70), S(7, WX(7, "share")) - 0.3, t1, fk="dm")
    # ---- lines 8 and 9: Kiddush
    t0, t1 = b0(8), b0(10)
    photo(im, t, "kcup.jpg", 0.5, 0.42, t0, t1, (190, 260, 890, 1080)); credit(im, t, CR["kcup"], t0 + 0.1, t1, y=1115)
    text(im, t, "A blessing over the wine", 1215, fit("A blessing over the wine", "dsb", 76), t0 + 0.05, t1, fk="dsb")
    text(im, t, "Kiddush.", 1385, 160, S(9) - 0.1, t1, color=GOLD)
    # ---- line 10: phones and the aunt
    t0, t1 = b0(10), b0(11); ta = S(10, WX(10, "Someone's")) - 0.25
    text(im, t, "Phones: face down.", 430, fit("Phones: face down.", "db", 110), t0 + 0.05, t1)
    phones(im, t, t0 + 0.1, t1, y=700)
    text(im, t, "Someone's aunt:", 960, 84, ta, t1, fk="dm")
    v = roll(t, S(10, WX(10, "three")) - 0.2, 0.6, 0, 3)
    text(im, t, f"+{int(round(v))} portions", 1130, 150, S(10, WX(10, "eat")) - 0.2, t1, color=GOLD, tab=True)
    text(im, t, "(you will eat them)", 1285, 64, S(10, WX(10, "portions")), t1, fk="dm", color=GREY)
    # ---- line 11: nobody's in a hurry
    t0, t1 = b0(11), b0(12)
    photo(im, t, "chw.jpg", 0.5, 0.45, t0, t1, (60, 250, 1020, 1050)); credit(im, t, CR["chw"], t0 + 0.1, t1, y=1085)
    text(im, t, "For a few hours,", 1200, 92, t0 + 0.05, t1, fk="dsb")
    text(im, t, "nobody's in a hurry.", 1340, fit("nobody's in a hurry.", "db", 110), S(11, WX(11, "nobody's")) - 0.2, t1, color=GOLD)
    # ---- line 12: 3,000 people on the beach
    t0, t1 = b0(12), b0(13)
    photo(im, t, "tlv5.jpg", 0.55, 0.5, t0, t1, (60, 250, 1020, 860)); credit(im, t, CR["tlv5"], t0 + 0.1, t1, y=895)
    text(im, t, "Now picture that", 1000, 84, t0 + 0.05, t1, fk="dm")
    v = roll(t, S(12, WX(12, "three")) - 0.2, 0.9, 8, 3000, log=True)
    text(im, t, f"{int(round(v)):,} people", 1160, 140, S(12, WX(12, "three")) - 0.25, t1, color=GOLD, tab=True)
    text(im, t, "On the beach in Tel Aviv.", 1310, fit("On the beach in Tel Aviv.", "dsb", 80), S(12, WX(12, "On")) - 0.2, t1, fk="dsb")
    # ---- lines 13 and 14: the record, then Shabbat Shalom
    t0, t1 = b0(13), END_T
    text(im, t, "Largest Shabbat dinner", 330, fit("Largest Shabbat dinner", "db", 96), t0, t1)
    bars(im, t, t0, t1, y1=540, y2=800)
    tb = S(14) - 0.15
    text(im, t, "We're going for it.", 1110, 96, S(13, WX(13, "We're")) - 0.2, tb, fk="dsb")
    text(im, t, "Shabbat Shalom.", 1110, 130, tb, t1, color=GOLD)
    text(im, t, "Link in bio: noamroz.com/shabbat", 1270, fit("Link in bio: noamroz.com/shabbat", "dsb", 64), S(13, WX(13, "record")) - 0.2, t1, fk="dsb", color=SKY)
    sources(im, t, SOURCES); subtitles(im, t, SUBS)
    return im

CH = [(1, 0, "Friday, around sunset."), (1, "The", "The shops close."), (1, "streets", "The streets go quiet."), (1, "Even", "Even Tel Aviv slows down."),
      (2, 0, "And in millions of homes,"), (2, "the", "the same little scene."),
      (3, 0, "Two candles. A cup of wine."), (3, "braided", "Two braided loaves, under a cloth."),
      (4, 0, "More than two out of three"), (4, "Israeli", "Israeli Jews sit down"), (4, "to", "to a special Friday dinner."),
      (5, 0, "And most of them aren't even Orthodox."), (6, 0, "Ever been to one?"),
      (7, 0, "I host dinners for newcomers,"), (7, "Jews", "Jews and non-Jews,"), (7, "just", "just to share beautiful moments."),
      (8, 0, "We start with a blessing"), (8, "over", "over the wine. It's called..."), (9, 0, "Kiddush."),
      (10, 0, "Phones go face down."), (10, "Someone's", "Someone's aunt makes you eat"), (10, "three", "three more portions."),
      (11, 0, "And for a few hours,"), (11, "nobody's", "nobody's in a hurry."),
      (12, 0, "Now picture that with 3,000 people."), (12, "On", "On the beach in Tel Aviv."),
      (13, 0, "April 2027."), (13, "We're", "We're going for the world record."), (14, 0, "Shabbat Shalom, everyone.")]
SUBS = build_subs(CH, LW, S, E, WX)
SOURCES = [(0, []),
           (b0(4), ["Special Friday night meal, 69% of Israeli Jews:", "Guttman Center (IDI) for AVI CHAI, 2009"]),
           (b0(5), ["Haredi 9% + Dati 13% of Israeli Jews:", "Pew Research Center, 2016"]),
           (b0(6), []),
           (b0(13), ["Record: 2,761 people, Javits Center, New York,", "21 Nov 2025: Guinness World Records"]),
           (END_T, [])]

F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + list(CR.values()) + CR3 + [HOOK_A, HOOK_B, LEAD] + L
guards(_txt, len((HOOK_A + " " + HOOK_B).split()))
for c in list(CR.values()) + CR3: assert CREDF.getlength(c) <= 990, ("credit too wide", c)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
if __name__ == "__main__": run(frame, T_END, A.out, A.snaps, D)
