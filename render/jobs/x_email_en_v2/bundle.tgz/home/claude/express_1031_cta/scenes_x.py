"""Copy for the Express 27 Oct batch (from daily_1027): city_map.
Israel map (whole land gold, Green Line green, as in map_highlight) with city dots that pop on their words.
Spec: {"type": "city_map", "line": N, "title", "title_he", "view": [lon0, lat0, lon1, lat1] (default Israel),
       "points": [{"lon", "lat", "en", "he", "value", "side": "r"|"l", "color"}], "marks": {"p0": phrase, ...}, "legend", "source"}
Point k appears at S["times"]["p<k>"] (the builder writes the marks)."""
import math, re
import cairo
import render as RD
# Hebrew-first reels: let phrase lookup ("at") match Hebrew words too (render.norm_w keeps only a-z0-9)
RD.norm_w = lambda w: re.sub(r"[^a-z0-9'\u05d0-\u05ea]", "", w.lower().replace("\u2019", "'"))
from render import P, T, pill, PP, fade_in, heading, source, MapView, geo, _path, col, CONTENT_BOTTOM
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H

ISRAEL_VIEW = [33.9, 29.35, 36.1, 33.45]

def sc_city_map(c, t, S):
    y = heading(c, t, S); box_ = (60, y, 1020, CONTENT_BOTTOM - 20)
    if "_mv" not in S:
        keep = St.a; St.a = 1.0
        G = geo(); mv = MapView(S.get("view", ISRAEL_VIEW), box_); S["_mv"] = mv
        base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
        bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
        for k, v in G.items():
            rg = mv.rings(v["g"], 0.6)
            if not rg: continue
            _path(bc, rg); sa(bc, P["gold"] if k in ("IL", "PS") else P["land"]); bc.fill_preserve()
            sa(bc, P["border"]); bc.set_line_width(1.6); bc.stroke()
        if "PS" in G:
            rg = mv.rings(G["PS"]["g"], 0.3)
            if rg:
                _path(bc, rg); sa(bc, P["green"]); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
        S["_base"] = base; St.a = keep
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    sa(c, P["navy"], 0.12); rr(c, x0 + 3, y0 + 14, x1 - x0, y1 - y0, 30); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"])))
    z = lerp(1.0, S.get("zoom", 1.05), ease(u)); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    pts = S.get("points", []); shown = []
    for k, p in enumerate(pts):
        tk = S["times"].get(f"p{k}", S["t0"] + 0.4 + 0.8 * k)
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); cc = col(p.get("color"), "navy")
        pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 18 + 70 * (1 - pr), P["white"], 0.5 * pr * uu)
        circ(c, px, py, 19 * uu, P["white"], uu); circ(c, px, py, 13 * uu, cc, uu)
        shown.append((k, p, tk, px, py))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    for k, p, tk, px, py in shown:   # labels on top, unclipped
        px = cx + (px - cx) * z; py = cy + (py - cy) * z
        side = p.get("side", "r"); dx = 1 if side == "r" else -1
        lx = min(max(px + dx * 210, 220), 860) if not p.get("lx") else p["lx"]; ly = py + p.get("dy", 0)
        a2, s2 = PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        c.save(); sa(c, P["navy"], 0.8 * a2); c.set_line_width(4); c.move_to(px, py); c.line_to(lx - dx * 120, ly); c.stroke(); c.restore()
        if p.get("value"):
            pill(c, p["value"], 64, lx, ly - 40, col(p.get("color"), "navy"), P["white"], a2, s2, outline=P["gold"], w=900, padh=1.35)
            ny = ly + 40
        else: ny = ly
        if p.get("en"): pill(c, p["en"], 46, lx, ny + 12, P["white"], P["navy"], a2, s2, outline=col(p.get("color"), "navy"), w=800, padh=1.35)
        if p.get("he"): T(c, p["he"], 38, lx, ny + 76, P["navy"], a2, s2, 700, maxw=380)
    St.a = old
    if S.get("legend"):
        la = fade_in(t, S["t0"] + 0.5, S); T(c, S["legend"], 40, 540, y1 - 50, P["navy"], la, 1, 800, maxw=880)
    source(c, t, S)

from render import shadow_box, icon_of, draw_emoji
def sc_rows(c, t, S):
    """bullet rows with two centred lines (big line + smaller line under), for Hebrew-first or long English lines.
    items [{icon/flag, en, he, color}], times from marks i0.. (builder); optional footer {en, he, color} at mark 'footer'."""
    y = heading(c, t, S); items = S["items"]; n = len(items); foot = S.get("footer")
    room_ = CONTENT_BOTTOM - y - (170 if foot else 20); rh = min(235, room_ / max(1, n)); bh = rh - 24
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2)
    for k, it in enumerate(items):
        tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        if t < tk - 0.07 and not hk: continue
        a = 1.0 if hk else fade_in(t, tk - 0.07, S, 0.2); u = 1.0 if hk else ease((t - tk + 0.07) / 0.35)
        yy = y + rh * k + rh / 2; dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, 80, yy - bh / 2, 920, bh, min(40, bh / 2.6), P["card"], stroke=col(it.get("color"), "silver"), sw=3, sh=6)
        em = icon_of(it)
        if em: draw_emoji(c, em, 150, yy, min(84, bh * 0.55))
        two = bool(it.get("he"))
        T(c, it.get("en", ""), min(62, bh * 0.34), 575, yy - (bh * 0.2 if two else 0), P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=760)
        if two: T(c, it["he"], min(46, bh * 0.25), 575, yy + bh * 0.24, P["gold_text"], 1.0, 1.0, 700, maxw=760)
        c.restore(); St.a = old
    if foot:
        tf = S["times"].get("footer", S["t0"] + span + 0.6)
        a, s = PP(t, tf, S, bounce=2.4); yy = y + rh * n + 80
        pill(c, foot.get("en", ""), 52, 540, yy, col(foot.get("color"), "red"), P["white"], a, s, w=900)
        if foot.get("he"): T(c, foot["he"], 44, 540, yy + 88, col(foot.get("color"), "red"), a, s, w=700)
    source(c, t, S)

def sc_big_number(c, t, S):
    """big_number with "year": true prints the numbers without thousands separators (2016, not 2,016)."""
    if not S.get("year"): return RD.sc_big_number(c, t, S)
    f = RD.fmt; RD.fmt = lambda v, dec=0: f"{v:.{dec}f}"
    try: return RD.sc_big_number(c, t, S)
    finally: RD.fmt = f

# ------------------------------------------------------------------ 31 Oct: SPEAKER end card + seamless loop (express_1031_cta)
import numpy as np
import kit as KIT
import mix as MX
from render import block, block_h, hand_down, icon

def sc_speaker(c, t, S):
    """SPEAKER CTA end card, English only, centred, every text >= 64 px. Three beats that pop on their spoken words:
    the question (scene start), "4 habits you need to master" (mark h), "Comment SPEAKER" (mark k, SPEAKER in the accent blue)."""
    t0 = S["t0"]; th = S["times"].get("h", t0 + 2.6); tk = S["times"].get("k", t0 + 5.0)
    q = "Want to become a *fluent English speaker?*"; h2 = "*4 habits* you need to master"
    hq = block_h(q, 96, 900, 940, 3); hh = block_h(h2, 76, 900, 960, 2)
    total = 175 + hq + 60 + hh + 80 + 90 + 190 + 120
    y = max(330, (330 + 1460) / 2 - total / 2)
    a, s = PP(t, t0 + 0.05, S); draw_emoji(c, "🗣️", 540, y + 80 + 8 * math.sin(t * 2.6), 150, a, s); y += 175
    a, s = PP(t, t0 + 0.12, S); block(c, q, 96, 540, y + hq / 2, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=3); y += hq + 60
    a, s = PP(t, th, S, bounce=2.2); block(c, h2, 76, 540, y + hh / 2, P["navy"], a, s, hl=P["gold"], maxw=960, max_lines=2); y += hh + 80
    a, s = PP(t, tk - 0.05, S); T(c, "Comment", 80, 540, y + 40, P["navy"], a, s, 800); y += 90
    a, s = PP(t, tk + 0.2, S, bounce=2.4); T(c, "SPEAKER", 170, 540, y + 95, P["blue"], a, s * (1 + 0.02 * math.sin(max(0, t - tk) * 3)), 900); y += 190
    ha = fade_in(t, tk + 0.4, S, 0.2); icon(c, 540, y + 50 + 12 * math.sin(t * 7), 0.6, hand_down, a=ha)

# loop: over the last loop_xfade seconds the whole frame cross-fades into frame 0 (same background, the hook already up),
# so the replay is continuous
_draw0 = RD.Reel.draw
def _draw_loop(s, c, t):
    _draw0(s, c, t)
    X = float(s.spec.get("loop_xfade", 0) or 0)
    if X and t > s.T_END - X:
        u = KIT.ease((t - (s.T_END - X)) / X)
        c.push_group(); _draw0(s, c, 0.0); c.pop_group_to_source(); c.paint_with_alpha(u)
        _draw0_t = t; KIT.CUR["t"] = _draw0_t
RD.Reel.draw = _draw_loop

# music: render the bed 1 s longer and fold that overflow over the first second (equal power), so the bed's last sample
# runs straight into its first one when the reel loops
_bed0 = MX.bed
def _bed_loop(name, dur, end_at=None):
    X = 1.0; full = _bed0(name, dur + X, end_at); n = int(dur * MX.SR); k = int(X * MX.SR)
    if not name or full.shape[1] < n + k: return full[:, :n]
    out = full[:, :n].copy(); f = np.linspace(0, 1, k)
    out[:, :k] = full[:, :k] * np.sqrt(f) + full[:, n:n + k] * np.sqrt(1 - f)
    return out / (np.abs(out).max() + 1e-12)
MX.bed = _bed_loop
