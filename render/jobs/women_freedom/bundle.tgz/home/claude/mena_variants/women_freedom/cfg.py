"""women_freedom: Where are women freest in the Middle East? (variant of lib_mena_rights_v4)"""
WHITE, GOLD, NAVY2, SILVER, YELLOW = "#FFFFFF", "#D2AA53", "#0C1E3E", "#C9D1DC", "#FFD54A"

def build(wt, lt, LINES):
    CC = {"Israel": "il", "Turkey": "tr", "Lebanon": "lb", "Jordan": "jo", "Egypt": "eg", "Iraq": "iq", "Saudi Arabia": "sa", "Iran": "ir",
          "UAE": "ae", "Qatar": "qa", "Yemen": "ye"}
    # rows: travel without a male guardian (HRW 2023, WBL 2.0) | drive | vote and run for parliament | equal inheritance (WBL)
    #       | marital rape a crime (Equality Now 2025; Israel 1980 ruling; Turkey TCK 102) | a woman has led the government
    #       | women in parliament %, IPU 1 Aug 2026 (unscored, tie breaker)
    TAB = {
        "Israel":       ["V", "V", "V", "V", "V", "V", "N"],
        "Turkey":       ["V", "V", "V", "V", "V", "V", "N"],
        "Lebanon":      ["V", "V", "V", "X", "X", "X", "N"],
        "Jordan":       ["~", "V", "V", "X", "X", "X", "N"],
        "Egypt":        ["V", "V", "V", "X", "X", "X", "N"],
        "Iraq":         ["~", "V", "V", "X", "X", "X", "N"],
        "Saudi Arabia": ["~", "V", "X", "X", "X", "X", "N"],
        "Iran":         ["X", "V", "V", "X", "X", "X", "N"],
        "UAE":          ["V", "V", "~", "X", "X", "X", "N"],
        "Qatar":        ["~", "V", "X", "X", "X", "X", "N"],
        "Yemen":        ["X", "V", "X", "X", "X", "X", "N"],
    }
    PCT = {"Israel": 25.8, "Turkey": 19.9, "Lebanon": 6.3, "Jordan": 19.6, "Egypt": 26.9, "Iraq": 25.5, "Saudi Arabia": 19.9, "Iran": 4.9,
           "UAE": 50.0, "Qatar": 6.1, "Yemen": 0.0}
    NUMROW = {c: (f"{v:.1f}" if v not in (0.0, 50.0) else f"{v:.0f}") for c, v in PCT.items()}
    EXPECT = {"Israel": 6, "Turkey": 6, "Lebanon": 3, "Jordan": 2, "Egypt": 3, "Iraq": 2, "Saudi Arabia": 1, "Iran": 2, "UAE": 2, "Qatar": 1, "Yemen": 1}
    LABELS = [("Travel with", "no guardian"), ("Can", "drive"), ("Vote and", "run"), ("Inherit", "equally"), ("Marital rape", "a crime"),
              ("A woman led", "government"), ("Women in", "parliament %")]
    G = {}
    G["A"] = dict(cols=["Lebanon", "Egypt", "Jordan", "Iraq"], t_in=lt(4) - 0.45,
                  fill={"Lebanon": wt(4, "Lebanon"), "Egypt": wt(4, "Egypt"), "Jordan": wt(5, "Jordan"), "Iraq": wt(5, "Iraq")},
                  score={"Lebanon": wt(4, "Three"), "Egypt": wt(4, "each"), "Jordan": wt(5, "Two"), "Iraq": wt(5, "each")}, stagger=0.1)
    G["B"] = dict(cols=["Saudi Arabia", "Iran", "UAE"], t_in=lt(6) - 0.45,
                  fill={"Saudi Arabia": wt(6, "Saudi"), "Iran": wt(7, "Iran"), "UAE": wt(8, "UAE")},
                  score={"Saudi Arabia": wt(6, "one"), "Iran": wt(7, "two"), "UAE": wt(8, "two")},
                  pulse=[("Saudi Arabia", 1, wt(6, "drive")), ("Iran", 0, wt(7, "passport")), ("UAE", 6, wt(8, "Half"))], stagger=0.1)
    G["C"] = dict(cols=["Qatar", "Yemen"], t_in=lt(9) - 0.45,
                  fill={"Qatar": wt(9, "Qatar"), "Yemen": wt(9, "Yemen")},
                  score={"Qatar": wt(9, "One"), "Yemen": wt(9, "each")}, stagger=0.1)
    T_TR, T_ISR = wt(11, "Turkey"), wt(12, "Israel")
    G["D"] = dict(cols=["Turkey", "Israel", "Lebanon", "Egypt"], t_in=lt(10) - 0.3,
                  fill={"Turkey": T_TR + 0.25, "Israel": T_ISR + 0.25, "Lebanon": -9, "Egypt": -9},
                  score={"Turkey": wt(11, "Six"), "Israel": wt(12, "Six"), "Lebanon": -9, "Egypt": -9}, mystery=["Turkey", "Israel"], stagger=0.09)
    ROWT = [wt(2, "travel"), wt(2, "Drive"), wt(2, "Vote"), wt(3, "Inherit"), wt(3, "marital"), wt(3, "led"), wt(3, "government", end=True) + 0.1]
    SUBS = {
        1: [(4, "6 questions. 11 countries.")],
        2: [(7, "Can she travel without a male guardian?"), (6, "Drive? Vote and run for parliament?")],
        3: [(7, "Inherit equally? Is marital rape a crime?"), (6, "Has a woman led the government?")],
        4: [(5, "Lebanon and Egypt. 3 each.")],
        5: [(5, "Jordan and Iraq. 2 each.")],
        6: [(3, "Saudi Arabia, 1."), (7, "Women could only drive from 2018.")],
        7: [(2, "Iran, 2."), (6, "A married woman needs her husband's"), (4, "OK for a passport.")],
        8: [(3, "The UAE, 2."), (7, "Half its parliament is women, by decree.")],
        9: [(5, "Qatar and Yemen. 1 each.")],
        10: [(3, "Two countries left.")],
        11: [(5, "Turkey. 6 out of 6.")],
        12: [(6, "And Israel. 6 out of 6.")],
        13: [(5, "Tie breaker: women in parliament."), (4, "Israel, about 26%."), (3, "Turkey, about 20%.")],
        14: [(7, "Golda Meir led Israel in 1969."), (4, "24 years before Turkey's"), (4, "first woman prime minister.")],
    }
    t_g, t_t, t_b = wt(14, "Golda"), wt(14, "Twenty-four"), wt(14, "before")

    def stat_card(base, t, E):
        F, hexa, DR, clamp, ease, back, paste_c = E["F"], E["hexa"], E["DR"], E["clamp"], E["ease"], E["back"], E["paste_c"]
        T0, TQ = E["T_STAT"], E["T_Q"]
        a = clamp((t - T0) / 0.3) * (1 - clamp((t - TQ) / 0.3))
        if a <= 0: return
        d = DR(base); d.rectangle((0, 0, 1080, 1920), fill=hexa(NAVY2, int(255 * a)))
        d.text((60, 300), "First woman", font=F(110, 900), fill=hexa(WHITE, int(255 * a)), anchor="ls")
        d.text((60, 420), "to lead the", font=F(110, 900), fill=hexa(WHITE, int(255 * a)), anchor="ls")
        d.text((60, 540), "government", font=F(110, 900), fill=hexa(GOLD, int(255 * a)), anchor="ls")
        fl = E["FLAG"]
        def block(y, flag, year, name, k, col):
            if k <= 0: return
            im = fl[flag].resize((190, round(fl[flag].height * 190 / fl[flag].width)))
            paste_c(base, im, 160 + (1 - ease(k)) * -80, y + 70, a * clamp(k * 2))
            d.text((300, y + 105), year, font=F(int(150 * max(0.3, back(k))), 900), fill=hexa(col, int(255 * a * clamp(k * 2))), anchor="ls")
            d.text((300, y + 185), name, font=F(64, 800), fill=hexa(WHITE, int(255 * a * clamp(k * 2))), anchor="ls")
        block(650, "Israel", "1969", "Golda Meir, Israel", clamp((t - t_g + 0.1) / 0.4), GOLD)
        block(950, "Turkey", "1993", "Tansu Çiller, Turkey", clamp((t - t_t + 0.1) / 0.4), WHITE)
        k3 = clamp((t - t_b) / 0.35)
        if k3 > 0:
            d.text((60, 1260), "24 years later", font=F(84, 900), fill=hexa(YELLOW, int(255 * a * k3)), anchor="ls")
            d.text((60, 1335), "The other 9 countries: never.", font=F(52, 800), fill=hexa(SILVER, int(255 * a * k3)), anchor="ls")
        d.text((60, 1405), "Sources: Britannica; Knesset; Grand National Assembly", font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")

    return dict(CC=CC, TAB=TAB, NUMROW=NUMROW, TIEBREAK=PCT, EXPECT=EXPECT, LABELS=LABELS, NSCORED=6, RH=114, LABEL_SZ=52, LABEL_GAP=27, ICON=0.92,
                G=G, ORDER=["A", "B", "C", "D"], ROWT=ROWT, MYSTERY={"Turkey": T_TR, "Israel": T_ISR},
                T_ISR=T_ISR, T_SB=lt(13) - 0.25, T_STAT=lt(14) - 0.2, T_Q=lt(15) - 0.2,
                HOOK=[("Where are", WHITE), ("women", GOLD, " freest", WHITE), ("in the", WHITE), ("Middle East?", WHITE)],
                COUNT_LINE="6 questions. 11 countries.", TITLE="Where are women freest?",
                SRC=["World Bank WBL 2024, HRW, Equality Now,", "IPU Aug 2026. Amber = partly, no point."],
                SB_TITLE="Score out of 6", SB_COL="% MPs", SB_HI={"Israel": wt(13, "Israel"), "Turkey": wt(13, "Turkey")},
                SB_SRC=["Tie breaker: women in parliament,", "IPU Parline, 1 Aug 2026. Sources in caption."],
                SUBS=SUBS, stat_card=stat_card)
