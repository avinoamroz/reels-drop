"""who_rules_lebsyr: "Who really rules Syria and Lebanon?" Map with a moving camera (Syria, Iran's road to Hezbollah cut in
Dec 2024, Lebanon close-up), a "Ruler?" chip per country, a 4-row scorecard (Lebanese state vs Hezbollah), the cost for
Lebanon, the 5 things the deals on the table require, and a loop back to frame 0. Icons and type only.
   python3 engine.py [--frames t1,t2,...] [--out path.mp4]   (DIR: timing.json, geo.json, mix.m4a)"""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"


def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u

NAVYD, NAVY, SKY, YEL = hx("#0B1426"), hx("#163261"), hx("#45A4DD"), hx("#FFCD50")
RED, GREEN, GOLD = hx("#E5484D"), hx("#3FBF7F"), hx("#C9A85C")
GL = (46 / 255, 204 / 255, 113 / 255, 1); SILVER = hx("#CBD3E3"); WHITE = (1, 1, 1, 1)
GOLD_IL, GOLD_PA = hx("#E0B252"), hx("#B8923F")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    if a <= 0.01 or not s: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def parts(c, ps, size, y, a=1.0, w=900, sc=1.0, maxw=960, x=540):
    while size > 40 and sum(font(size, w).getlength(s) for s, _ in ps) > maxw: size -= 2
    tot = sum(font(size, w).getlength(s) for s, _ in ps); xx = x - tot / 2
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    for s, col in ps: xx += text(c, s, size, xx, y, w, col, a, "l")
    c.restore()
def fit(s, size, maxw, w=800, mn=36):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def ftext(c, s, size, x, y, maxw, w=800, col=WHITE, a=1.0, align="c", mn=36):
    return text(c, s, fit(s, size, maxw, w, mn), x, y, w, col, a, align)
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def card(c, x, y, w, h, col=WHITE, a=1.0, fa=0.07, stroke=None, r=34):
    rr(c, x, y, w, h, r); c.set_source_rgba(*col[:3], fa * a); c.fill()
    if stroke:
        rr(c, x, y, w, h, r); c.set_source_rgba(*stroke[:3], 0.9 * a); c.set_line_width(4); c.stroke()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def check(c, x, y, s, col, a):          # tick in a circle
    c.set_source_rgba(*col[:3], a); c.arc(x, y, s, 0, 6.283); c.fill()
    c.move_to(x - s * 0.45, y + s * 0.02); c.line_to(x - s * 0.1, y + s * 0.36); c.line_to(x + s * 0.5, y - s * 0.34)
    c.set_source_rgba(*NAVYD[:3], a); c.set_line_width(s * 0.22); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
def icon_build(c, x, y, s, col, a):     # a simple building (women's centre)
    c.set_source_rgba(*col[:3], a); c.move_to(x - s, y - s * 0.3); c.line_to(x, y - s * 1.0); c.line_to(x + s, y - s * 0.3); c.close_path(); c.fill()
    rr(c, x - s * 0.8, y - s * 0.3, s * 1.6, s * 1.1, 4); c.fill()
    c.set_source_rgba(*NAVYD[:3], a)
    for dx in (-0.45, 0, 0.45): rr(c, x + dx * s - s * 0.13, y - s * 0.1, s * 0.26, s * 0.55, 3); c.fill()
def icon_coin(c, x, y, s, col, a):
    c.set_source_rgba(*col[:3], a); c.arc(x, y, s, 0, 6.283); c.fill()
    text(c, "$", int(s * 1.3), x, y + s * 0.45, 900, NAVYD, a)

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 1.2, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1
T_FADE = END - 0.85
def sa(t, i0, i1=None, fi=0.3, fo=0.3):
    """alpha of a block living from scene i0 to scene i1 (inclusive)"""
    i1 = i0 if i1 is None else i1
    return ramp(t, CUT[i0], CUT[i0] + fi) * (1 - ramp(t, CUT[i1 + 1] - fo, CUT[i1 + 1]))

# ------------------------------------------------------------------ map with a moving camera
GEO = json.load(open(f"{D}/geo.json"))
COSF = math.cos(math.radians(33.5))
CLIP = (600, 1345)
VH = (37.9, 33.4, 92.0, 540, 975)       # Lebanon, Syria, Israel
VW = (43.6, 33.4, 52.0, 540, 975)       # out to Tehran
VL = (35.85, 33.86, 440.0, 540, 975)    # Lebanon close-up
def vmix(a, b, u):
    return (lerp(a[0], b[0], u), lerp(a[1], b[1], u), math.exp(lerp(math.log(a[2]), math.log(b[2]), u)), a[3], a[4])
def cam(t):
    keys = [(0, VH), (CUT[2] + 0.05, VH), (CUT[2] + 0.95, VW), (CUT[3] - 0.05, VW), (CUT[3] + 0.8, VH), (CUT[4] - 0.05, VH), (CUT[4] + 0.95, VL)]
    v = keys[-1][1]
    for (t0, a), (t1, b) in zip(keys, keys[1:]):
        if t < t1: v = vmix(a, b, ease((t - t0) / max(1e-6, t1 - t0))); break
    br = 1 + 0.012 * math.sin(t * 0.9)                      # slow breathing: motion from frame 0
    return (v[0], v[1], v[2] * br, v[3], v[4])
def proj(v):
    clon, clat, s, cx, cy = v
    return lambda lon, lat: (cx + (lon - clon) * COSF * s, cy - (lat - clat) * s)
def poly(c, P, rings):
    for r in rings:
        for i, (lo, la) in enumerate(r):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.close_path()
BASE = hx("#24324D")
# places (lon, lat)
TEH, BAG, BUK, DAM, BEI = (51.39, 35.69), (44.37, 33.31), (40.92, 34.45), (36.29, 33.51), (35.50, 33.89)
TANF, HERMON = (38.62, 33.50), (35.80, 33.30)
HZ_SY = [(36.57, 34.51), (37.16, 36.20), (36.29, 33.51), (36.72, 34.73), (38.27, 35.33)]   # Qusayr, Aleppo, Damascus, Homs, Deir ez-Zor area
HZ_LB = [("Beirut suburbs", 35.51, 33.85, "l"), ("Bekaa", 36.21, 34.00, "l"), ("South", 35.42, 33.25, "r")]
def mark_t(): return wt(5, "said") - 0.1
def draw_map(c, t, a):
    if a <= 0.01: return
    v = cam(t); P = proj(v); i = scene_at(t)
    c.save(); c.rectangle(0, CLIP[0], W, CLIP[1] - CLIP[0]); c.clip()
    c.push_group()
    for iso in ("EG", "SA", "JO", "IQ", "IR", "TR", "CY", "KW", "LB", "SY"):
        poly(c, P, GEO["me"][iso]); c.set_source_rgba(*BASE[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.35); c.set_line_width(2); c.stroke()
    # Syria: government fill from scene 3
    gs = ramp(t, CUT[3] + 0.3, CUT[3] + 1.0)
    if gs > 0:
        gs *= 1 - 0.75 * ramp(t, CUT[4], CUT[4] + 0.8)       # dim Syria when the camera reaches Lebanon
        poly(c, P, GEO["me"]["SY"]); c.set_source_rgba(*SKY[:3], 0.55 * gs); c.fill()
    hs = ramp(t, CUT[1], CUT[1] + 0.4) * (1 - ramp(t, CUT[2], CUT[2] + 0.4))
    if hs > 0:
        poly(c, P, GEO["me"]["SY"]); c.set_source_rgba(*SKY[:3], 0.95 * hs); c.set_line_width(6); c.stroke()
    # Lebanon: state fill from scene 4
    ls = ramp(t, CUT[4] + 0.4, CUT[4] + 1.1)
    if ls > 0:
        poly(c, P, GEO["me"]["LB"]); c.set_source_rgba(*SKY[:3], 0.6 * ls); c.fill_preserve(); c.set_source_rgba(1, 1, 1, 0.9 * ls); c.set_line_width(4); c.stroke()
    if i == 0:                                              # hook: both countries pulse
        pu = 0.5 + 0.5 * math.sin(t * 4.2)
        for iso in ("SY", "LB"):
            poly(c, P, GEO["me"][iso]); c.set_source_rgba(*YEL[:3], 0.55 + 0.4 * pu); c.set_line_width(5); c.stroke()
    poly(c, P, GEO["isr"]); c.set_source_rgba(*GOLD_IL[:3], 1); c.fill()
    poly(c, P, GEO["pal"]); c.set_source_rgba(*GOLD_PA[:3], 1); c.fill()
    poly(c, P, GEO["lakes"]); c.set_source_rgba(*hx("#2A4A85")[:3], 1); c.fill()
    c.set_source_rgba(*GL[:3], 1); c.set_line_width(3)
    for ln in GEO["green"]:
        for k, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if k == 0 else c.line_to)(x, y)
        c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a)
    # country names (only where the view shows them)
    s = v[2]
    wide = clamp((80 - s) / 20); mid = 1 - wide if s < 200 else 0.0; close = clamp((s - 250) / 100)
    nm = [("SYRIA", 38.6, 35.1, mid), ("SYRIA", 38.9, 35.9, wide), ("LEBANON", 35.2, 34.25, mid),
          ("ISRAEL", 34.55, 30.9, 1.0 if s < 200 else 0.0), ("IRAQ", 43.5, 34.2, 1.0 if s < 200 else 0.0), ("IRAN", 50.0, 33.2, wide),
          ("JORDAN", 37.4, 31.0, mid), ("LEBANON", 35.62, 34.42, close), ("SYRIA", 36.45, 33.35, close)]
    for n_, lo, la, al in nm:
        if al > 0.01:
            x, y = P(lo, la); text(c, n_, 44, x, y, 800, WHITE, a * al * (0.9 if n_ != "LEBANON" else 1))
    # scene 1: Hezbollah in Syria, then Assad falls
    fell = wt(1, "fell") - 0.1
    h1 = ramp(t, CUT[1] + 0.5, CUT[1] + 0.9) * (1 - ramp(t, fell, fell + 0.5))
    if h1 > 0.01:
        for k, (lo, la) in enumerate(HZ_SY):
            u = clamp((t - CUT[1] - 0.5 - 0.12 * k) / 0.3); x, y = P(lo, la)
            c.set_source_rgba(*RED[:3], a * h1 * u); c.arc(x, y, 16 * eob(u), 0, 6.283); c.fill()
            c.set_source_rgba(1, 1, 1, a * h1 * u); c.set_line_width(3); c.arc(x, y, 16 * eob(u), 0, 6.283); c.stroke()
    # scene 2: the road from Tehran
    if CUT[2] <= t < CUT[3] + 0.3:
        ra = sa(t, 2, 2, 0.3, 0.3)
        pts = [P(*q) for q in (TEH, BAG, BUK, DAM, BEI)]
        segl = [math.dist(pts[k], pts[k + 1]) for k in range(4)]; tot = sum(segl)
        u = eout((t - CUT[2] - 0.6) / 1.4); cutt = wt(2, "Cut") - 0.1; cu = ramp(t, cutt, cutt + 0.25)
        col = tuple(lerp(RED[j], SILVER[j], cu) for j in range(3))
        c.set_source_rgba(*col, a * ra); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_dash([22, 16])
        rem = tot * u; c.move_to(*pts[0])
        for k in range(4):
            if rem <= 0: break
            f = min(1, rem / segl[k]); c.line_to(lerp(pts[k][0], pts[k + 1][0], f), lerp(pts[k][1], pts[k + 1][1], f)); rem -= segl[k]
        c.stroke(); c.set_dash([])
        for k, (nm_, q) in enumerate((("Tehran", TEH), ("Baghdad", BAG), ("Damascus", DAM), ("Beirut", BEI))):
            x, y = P(*q); c.set_source_rgba(1, 1, 1, a * ra); c.arc(x, y, 10, 0, 6.283); c.fill()
            dy = 52 if nm_ in ("Baghdad", "Damascus") else -26
            text(c, nm_, 40, x + (0 if nm_ != "Beirut" else -10), y + dy, 700, WHITE, a * ra, "c" if nm_ != "Beirut" else "r")
        if cu > 0:
            x, y = P(39.6, 34.3); sc_ = eob(clamp((t - cutt) / 0.35)); r = 46 * sc_
            c.set_source_rgba(*RED[:3], a * ra * cu); c.arc(x, y, r + 12, 0, 6.283); c.fill()
            c.set_source_rgba(1, 1, 1, a * ra * cu); c.set_line_width(12); c.set_line_cap(cairo.LINE_CAP_ROUND)
            c.move_to(x - r * 0.55, y - r * 0.55); c.line_to(x + r * 0.55, y + r * 0.55); c.move_to(x + r * 0.55, y - r * 0.55); c.line_to(x - r * 0.55, y + r * 0.55); c.stroke()
    # scene 3: two Syria facts on the map
    if CUT[3] <= t < CUT[4] + 0.3:
        fa = sa(t, 3, 3, 0.3, 0.3)
        for k, (q, lab, col, dt, al) in enumerate(((TANF, "Missiles for Hezbollah seized, Jul 2026", RED, 0.9, "l"), (HERMON, "Israel's buffer zone", GOLD, 1.5, "l"))):
            u = clamp((t - CUT[3] - dt) / 0.3)
            if u <= 0: continue
            x, y = P(*q)
            c.set_source_rgba(*col[:3], a * fa * u); c.arc(x, y, 14 * eob(u), 0, 6.283); c.fill()
            c.set_source_rgba(1, 1, 1, a * fa * u); c.set_line_width(3); c.arc(x, y, 14 * eob(u), 0, 6.283); c.stroke()
            if k == 0:
                ftext(c, "Missiles for Hezbollah", 44, x - 40, y + 66, 520, 800, WHITE, a * fa * u, "l", 36)
                ftext(c, "seized, July 2026", 42, x - 40, y + 116, 520, 700, SILVER, a * fa * u, "l", 36)
            else:
                text(c, "Israel's", 44, x - 34, y - 14, 800, GOLD, a * fa * u, "r")
                text(c, "buffer zone", 44, x - 34, y + 38, 800, GOLD, a * fa * u, "r")
    # scene 5: Hezbollah strongholds in Lebanon
    h5 = ramp(t, CUT[5] + 0.6, CUT[5] + 1.0) * (1 - ramp(t, CUT[6] - 0.35, CUT[6]))
    if h5 > 0.01:
        for k, (lab, lo, la, al) in enumerate(HZ_LB):
            u = clamp((t - CUT[5] - 0.6 - 0.2 * k) / 0.3); x, y = P(lo, la)
            c.set_source_rgba(*RED[:3], a * h5 * u * 0.35); c.arc(x, y, 58 * eob(u), 0, 6.283); c.fill()
            c.set_source_rgba(*RED[:3], a * h5 * u); c.arc(x, y, 18 * eob(u), 0, 6.283); c.fill()
            c.set_source_rgba(1, 1, 1, a * h5 * u); c.set_line_width(3); c.arc(x, y, 18 * eob(u), 0, 6.283); c.stroke()
            text(c, lab, 44, x + (40 if al == "l" else -40), y + 15, 800, WHITE, a * h5 * u, al)
    c.restore()

# ------------------------------------------------------------------ "Ruler?" chips (the counter for each country)
def switch(c, x, y, pos, a):
    """pill switch: pos 0 = Government (left, sky), 1 = Hezbollah (right, red)"""
    rr(c, x - 70, y - 28, 140, 56, 28); c.set_source_rgba(1, 1, 1, 0.14 * a); c.fill()
    col = tuple(lerp(SKY[j], RED[j], pos) for j in range(3))
    c.set_source_rgba(*col, a); c.arc(x - 42 + 84 * pos, y, 22, 0, 6.283); c.fill()
def chip(c, x0, name, t, a, resolved, lines, pos):
    if a <= 0.01: return
    card(c, x0, 1395, 470, 140, WHITE, a, 0.08, YEL if resolved else None, 30)
    text(c, name, 44, x0 + 30, 1450 - 8 * (len(lines) > 1) * resolved, 900, SKY if not resolved else WHITE, a, "l")
    text(c, "Ruler?", 40, x0 + 30, 1506, 700, SILVER, a * (1 - resolved))
    switch(c, x0 + 380, 1436, pos, a)
    if resolved > 0.01:
        if len(lines) == 1: ftext(c, lines[0], 52, x0 + 30, 1508, 420, 900, YEL, a * resolved, "l", 36)
        else:
            ftext(c, lines[0], 40, x0 + 30, 1490, 310, 800, WHITE, a * resolved, "l", 36)
            ftext(c, lines[1], 40, x0 + 30, 1523, 310, 800, YEL, a * resolved, "l", 36)
def draw_chips(c, t):
    i = scene_at(t)
    if 6 <= i <= 9 or i >= 11: return
    a = 1.0 if i <= 5 else sa(t, 10)
    if i <= 5: a *= 1 - ramp(t, CUT[6] - 0.3, CUT[6])
    sw = 0.5 + 0.5 * math.sin(t * 3.0)                      # the swinging toggle until it resolves
    sy_r = ramp(t, wt(3, "rules") - 0.1, wt(3, "rules") + 0.3)
    chip(c, 55, "SYRIA", t, a, sy_r, ["Government"], lerp(sw, 0.0, sy_r))
    lb_r = ramp(t, wt(10, "banned") - 0.1, wt(10, "banned") + 0.4)
    chip(c, 555, "LEBANON", t, a, lb_r, ["Paper: the state", "War: Hezbollah"], lerp(0.5 + 0.5 * math.sin(t * 3.0 + 1.6), 0.75, lb_r))

# ------------------------------------------------------------------ top titles over the map (scenes 0-5)
def draw_tops(c, t):
    i = scene_at(t)
    if i == 0:
        a = 1 - ramp(t, CUT[1] - 0.25, CUT[1])
        text(c, "Who really rules", 116, 540, 400, 900, WHITE, a)
        ftext(c, "Syria and Lebanon?", 116, 540, 540, 990, 900, YEL, a)
        return
    if i == 1:
        a = sa(t, 1); fell = wt(1, "fell") - 0.1
        b = 1 - ramp(t, fell - 0.1, fell + 0.2)
        text(c, "2012 to 2024", 60, 540, 360, 800, SKY, a * b)
        ftext(c, "Hezbollah fought for Assad", 84, 540, 470, 990, 900, WHITE, a * b)
        e = ramp(t, fell, fell + 0.3)
        text(c, "Assad fell", 120, 540, 440, 900, YEL, a * e, sc=max(0.01, eob(clamp((t - fell) / 0.4))))
        text(c, "8 December 2024", 56, 540, 530, 800, WHITE, a * e)
    elif i == 2:
        a = sa(t, 2); cutt = wt(2, "Cut") - 0.1; e = ramp(t, cutt, cutt + 0.25)
        ftext(c, "Iran's road to Hezbollah", 88, 540, 400, 990, 900, WHITE, a)
        parts(c, [("Through Syria. ", WHITE), ("Cut.", YEL)] if e > 0.5 else [("Through Syria.", WHITE)], 76, 520, a)
    elif i == 3:
        a = sa(t, 3)
        parts(c, [("Syria: ", WHITE), ("the government", SKY)], 92, 400, a)
        text(c, "President Ahmed al-Sharaa", 56, 540, 500, 800, SILVER, a)
        o = ramp(t, wt(3, "out") - 0.1, wt(3, "out") + 0.2)
        text(c, "Hezbollah: out", 56, 540, 570, 900, RED, a * o)
    elif i == 4:
        a = sa(t, 4)
        text(c, "Lebanon, on paper", 92, 540, 380, 900, WHITE, a)
        items = [("President", "Joseph Aoun", "president"), ("Prime minister", "Nawaf Salam", "prime"), ("Army", "~65,000 serving", "army")]
        for k, (r_, n_, w_) in enumerate(items):
            t0 = wt(4, w_) - 0.15; u = clamp((t - t0) / 0.3)
            x = 70 + k * 320
            card(c, x, 420 + (1 - eout(u)) * 20, 300, 150, SKY, a * u, 0.16, None, 26)
            ftext(c, r_, 40, x + 150, 475, 270, 700, SILVER, a * u, "c", 36)
            ftext(c, n_, 48, x + 150, 540, 270, 900, WHITE, a * u, "c", 36)
    elif i == 5:
        a = sa(t, 5, 5, 0.3, 0.35)
        text(c, "Cabinet, August 2025", 56, 540, 360, 800, SKY, a)
        ftext(c, "Weapons for the state only", 84, 540, 460, 990, 900, WHITE, a)
        s = mark_t(); e = ramp(t, s, s + 0.25)
        text(c, "Hezbollah: No.", 92, 540, 570, 900, RED, a * e, sc=max(0.01, eob(clamp((t - s) / 0.4))))

def draw_srcs(c, t):
    i = scene_at(t)
    S = {1: "Assad regime fell, 8 Dec 2024",
         2: "Land route through Syria, cut with Assad's fall",
         3: "SANA via Al Jazeera, Jul 2026; UN, Aug 2026",
         4: "Army size: INSS, March 2026",
         5: "Lebanese cabinet, 5 and 7 Aug 2025"}
    if i in S:
        s = S[i]; text(c, s, fit(s, 38, 980, 700), 540, 1372, 700, SILVER, sa(t, i))

# ------------------------------------------------------------------ scenes 6-10: the scorecard
SC = [("Fighters", ("~65,000", "army, serving (INSS)"), ("<40,000 est.", "plus reserves (Alma)"), 0, (6, "Fighters"), (6, "army")),
      ("The law and the UN", ("On its side", "UN 1559, 1701, cabinet"), ("Against it", "refuses to disarm"), 0, (7, "law"), (7, "state")),
      ("Outside money, 2025", ("~$0.5 billion", "foreign aid (INSS est.)"), ("~$1 billion", "from Iran (US Treasury)"), 1, (8, "Money"), (8, "Hezbollah")),
      ("Who starts the war?", ("Banned it", "the same day"), ("Opened fire", "2 March 2026"), 1, (9, "last"), (10, "opened"))]
def draw_score(c, t):
    i = scene_at(t)
    if not 6 <= i <= 10: return
    a = sa(t, 6, 10, 0.35, 0.35)
    # header with live score
    sc = [0, 0]
    for _, _, _, win, _, wn in SC:
        if t >= wt(*wn): sc[win] += 1
    for k, (lab, col) in enumerate((("Lebanese state", SKY), ("Hezbollah", RED))):
        x = 290 + 500 * k
        card(c, x - 235, 262, 470, 120, col, a, 0.18, None, 30)
        ftext(c, lab, 52, x - 200 if k == 0 else x + 200, 340, 300, 900, WHITE, a, "l" if k == 0 else "r", 40)
        text(c, str(sc[k]), 84, x + 175 if k == 0 else x - 175, 352, 900, YEL, a, "c")
    for k, (lab, L, R, win, ap, wn) in enumerate(SC):
        t0 = wt(*ap) - 0.15; u = clamp((t - t0) / 0.35)
        if u <= 0: continue
        y = 410 + k * 228 + (1 - eout(u)) * 20
        text(c, lab, 46, 540, y + 40, 800, SILVER, a * u)
        tw = wt(*wn) - 0.05; wv = ramp(t, tw, tw + 0.3)
        reveal = 1.0 if k < 3 else wv                           # last row: question marks until it is decided
        for side, (big, sub) in enumerate((L, R)):
            x = 60 if side == 0 else 560; col = SKY if side == 0 else RED
            won = wv if side == win else 0
            card(c, x, y + 60, 460, 156, col, a * u, 0.14 + 0.16 * won, YEL if won > 0.5 else None, 28)
            if reveal < 1:
                text(c, "?", 90, x + 230, y + 170, 900, WHITE, a * u * (1 - reveal))
            ftext(c, big, 66, x + 230, y + 132, 400, 900, YEL if won > 0.5 else WHITE, a * u * reveal, "c", 40)
            ftext(c, sub, 38, x + 230, y + 188, 420, 700, SILVER, a * u * reveal, "c", 36)
            if won > 0.01: check(c, x + 16 if side == 0 else x + 444, y + 76, 26 * eob(won), GREEN, a * u * won)
    if i == 9:
        s = wt(9, "Two"); e = ramp(t, s - 0.1, s + 0.2) * (1 - ramp(t, wt(9, "last") - 0.2, wt(9, "last")))
        text(c, "2 : 2", 150, 540, 1340, 900, YEL, a * e, sc=max(0.01, eob(clamp((t - s + 0.1) / 0.4))))
    s = "INSS Mar 2026; Alma Aug 2026 (est.); US Treasury, Nov 2025"
    text(c, s, fit(s, 38, 980, 700), 540, 1372, 700, SILVER, a * (1 if i < 10 else 0))
    if i == 10:
        s2 = "Lebanese cabinet decision, 2 March 2026"
        text(c, s2, fit(s2, 38, 980, 700), 540, 1372, 700, SILVER, a)

# ------------------------------------------------------------------ scene 11: the cost for Lebanon
def draw_cost(c, t):
    a = sa(t, 11)
    if a <= 0.01: return
    text(c, "Lebanon paid", 120, 540, 520, 900, WHITE, a)
    t0 = wt(11, "four") - 0.2; u = eout((t - t0) / 1.0)
    text(c, f"{int(round(4389 * u)):,}", 230, 540, 830, 900, YEL, a * clamp((t - t0 + 0.3) / 0.3))
    text(c, "killed since 2 March 2026", 64, 540, 940, 800, WHITE, a)
    d0 = wt(11, "says") - 0.1; b = ramp(t, d0, d0 + 0.3)
    parts(c, [("Over ", WHITE), ("1 million", YEL), (" displaced", WHITE)], 76, 1110, a * b)
    s = "Lebanon Health Ministry, 2 Mar to 12 Oct 2026"
    text(c, s, fit(s, 40, 980, 700), 540, 1250, 700, SILVER, a)
    text(c, "Displaced: UN figures, 2026", 38, 540, 1310, 700, SILVER, a * b)

# ------------------------------------------------------------------ scenes 12-14: what the deals require
REQ = [("Disarm Hezbollah", "UN 1559 (2004), 1701 (2006)", "Disarm", 1),
       ("Army in all of Lebanon", "June 2026 framework", "army", 1),
       ("Israel pulls back, in steps", "June 2026 framework", "Israel", 1),
       ("Rebuild, after disarmament", "World Bank: $11 billion (2025)", "Rebuild", 0),
       ("Iran stops arms and money", "Lebanon's foreign minister, Oct 2026", "Iran", 0)]
def draw_req(c, t):
    a = sa(t, 12, 14, 0.35, 0.35)
    if a <= 0.01: return
    i = scene_at(t)
    text(c, "What the deals", 96, 540, 360, 900, WHITE, a)
    text(c, "on the table require", 80, 540, 455, 900, SKY, a)
    st = CUT[14] + 0.1
    for k, (en, src, w_, started) in enumerate(REQ):
        t0 = wt(13, w_) - 0.15 if i >= 13 else 1e9
        u = clamp((t - t0) / 0.3)
        if u <= 0:
            continue
        y = 505 + k * 148 + (1 - eout(u)) * 20
        card(c, 60, y, 960, 134, WHITE, a * u, 0.08, None, 28)
        c.set_source_rgba(*SKY[:3], a * u); c.arc(122, y + 67, 36, 0, 6.283); c.fill()
        text(c, str(k + 1), 52, 122, y + 86, 900, NAVYD, a * u)
        ftext(c, en, 56, 182, y + 64, 590, 900, WHITE, a * u, "l", 40)
        ftext(c, src, 38, 182, y + 112, 590, 700, SILVER, a * u, "l", 36)
        v = clamp((t - st - 0.15 * k) / 0.3)
        if v > 0:
            col = hx("#F5A524") if started else RED; lab = "Started" if started else "Not yet"
            rr(c, 790, y + 37, 205, 62, 31); c.set_source_rgba(*col[:3], a * v); c.fill()
            text(c, lab, 42, 892, y + 82, 900, NAVYD, a * v, sc=max(0.01, eob(v)))
    z = wt(14, "Zero") - 0.1; e = ramp(t, z, z + 0.25)
    if i >= 14:
        parts(c, [("Done: ", WHITE), ("0 of 5", YEL)], 120, 1400, a * e, sc=max(0.01, eob(clamp((t - z) / 0.4))))

# ------------------------------------------------------------------ scene 15: one army
def draw_one(c, t):
    a = sa(t, 15)
    if a <= 0.01: return
    text(c, "Many Lebanese", 112, 540, 560, 900, WHITE, a)
    text(c, "want one army", 112, 540, 690, 900, SKY, a)
    # Lebanon silhouette, one colour
    P = proj((35.85, 33.86, 250.0, 540, 980))
    poly(c, P, GEO["me"]["LB"]); c.set_source_rgba(*SKY[:3], 0.8 * a); c.fill()
    m = wt(15, "problem") - 0.1; e = ramp(t, m, m + 0.3)
    text(c, "The problem:", 76, 540, 1250, 800, WHITE, a * e)
    text(c, "the militia", 100, 540, 1360, 900, YEL, a * e, sc=max(0.01, eob(clamp((t - m) / 0.4))))

# ------------------------------------------------------------------ scene 16: lead-in to the hook
def draw_lead(c, t):
    a = ramp(t, CUT[16], CUT[16] + 0.3) * (1 - ramp(t, END - 1.25, END - 1.0))
    if a <= 0.01: return
    text(c, "So next time", 116, 540, 820, 900, WHITE, a)
    text(c, "someone asks you...", 116, 540, 960, 900, YEL, a)

# ------------------------------------------------------------------ subtitles
REPL = [("Hamas", "HAMAS"), ("four thousand", "4,000"), ("Two to two", "2 to 2")]
SUB_BOTTOM = 1712
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                cand = " ".join(w["w"] for w in ws[i:i + n])
                core = cand.rstrip(".,:?!")
                if core.lower() == a_.lower(): hit = (n, b_ + cand[len(core):]); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs(); SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return


# ------------------------------------------------------------------ frame
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1E3F78")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1000, 760, SKY, 0.10); return s
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = scene_at(t)
    if i <= 5:
        draw_map(c, t, 1.0 if i < 5 else 1 - ramp(t, CUT[6] - 0.35, CUT[6]))
    draw_tops(c, t); draw_srcs(c, t); draw_chips(c, t)
    draw_score(c, t); draw_cost(c, t); draw_req(c, t); draw_one(c, t); draw_lead(c, t)
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); img = frame(tt)
            if tt >= T_FADE:
                u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
            Image.fromarray(img).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= T_FADE:
            u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
