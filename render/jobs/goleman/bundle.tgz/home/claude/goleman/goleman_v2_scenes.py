"""Bespoke reelkit scenes for the Goleman reel v2 (@noamroz__): food only. Picky eating until 19, the amygdala as the
brain's alarm (Goleman 1995), corrective experiences, the gradual ladder, the FOOD comment CTA.
Reuses the v1 look and helpers from goleman_scenes.py (same folder). All food is drawn as vector icons (no emoji)."""
import math, os, sys
import cairo
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path: sys.path.insert(0, HERE)
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, diamond, image_surf
from kit import ease, ramp, lerp, St, sa, rr, line as kline, circ, box
import goleman_scenes as G
from goleman_scenes import hx, M, he_line, head, underline, xmark, check, view_pill, ellipse, card, place, brain, bread, tomato, cucumber, plate

# ------------------------------------------------------------------ vector food (around 0,0, about 200 px)
RICE, BROWN, BROWN2, FAT = hx("#FFFFFF"), hx("#A65A3A"), hx("#7E3F26"), hx("#F1D2C2")
GOLDEN, GOLDEN2 = hx("#D9933B"), hx("#B06E22")
POT, POT2 = hx("#D8B26E"), hx("#B08840")
LET, LET2 = hx("#7CC45B"), hx("#3E8E3A")
KETCH, MUST, MUST2 = hx("#D63A2E"), hx("#E8B923"), hx("#B88A10")

def bowl(c, w=110):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 70, w, 20); c.fill()
    c.move_to(-w, 0); c.curve_to(-w + 10, 100, w - 10, 100, w, 0); c.close_path()
    sa(c, P["white"]); c.fill_preserve(); sa(c, P["blue"]); c.set_line_width(6); c.stroke()
    kline(c, [(-w * 0.72, 46), (w * 0.72, 46)], P["blue"], 5, 0.5)
def rice(c):
    bowl(c)
    c.move_to(-104, 2); c.curve_to(-90, -80, 90, -80, 104, 2); c.close_path(); sa(c, hx("#FBFAF5")); c.fill_preserve(); sa(c, P["silver"]); c.set_line_width(4); c.stroke()
    for k in range(22):
        x = -78 + (k * 37) % 156; y = -8 - ((k * 23) % 50)
        c.save(); c.translate(x, y); c.rotate(k * 0.9); ellipse(c, 0, 0, 8, 3.6); sa(c, P["silver"], 0.9); c.fill(); c.restore()
def steak(c):
    sa(c, P["navy"], 0.12); ellipse(c, 6, 74, 120, 18); c.fill()
    def shape(s):
        c.move_to(-110 * s, -10 * s); c.curve_to(-120 * s, -80 * s, 20 * s, -90 * s, 70 * s, -60 * s)
        c.curve_to(130 * s, -30 * s, 120 * s, 60 * s, 40 * s, 66 * s); c.curve_to(-30 * s, 72 * s, -100 * s, 60 * s, -110 * s, -10 * s); c.close_path()
    shape(1.0); sa(c, FAT); c.fill_preserve(); sa(c, BROWN2); c.set_line_width(5); c.stroke()
    shape(0.84); sa(c, BROWN); c.fill()
    for k in range(4): kline(c, [(-70 + k * 40, -40), (-30 + k * 40, 40)], BROWN2, 9, 0.85)
def drumstick(c):
    c.save(); c.rotate(-0.6)
    box(c, 40, -14, 110, 28, 14, P["white"], 1, stroke=P["silver"], sw=4)
    circ(c, 152, -16, 18, P["white"], 1, stroke=P["silver"], sw=4); circ(c, 152, 16, 18, P["white"], 1, stroke=P["silver"], sw=4)
    box(c, 40, -14, 110, 28, 14, P["white"])
    c.move_to(60, -26); c.curve_to(20, -90, -130, -80, -120, 0); c.curve_to(-130, 80, 20, 90, 60, 26); c.close_path()
    sa(c, GOLDEN); c.fill_preserve(); sa(c, GOLDEN2); c.set_line_width(6); c.stroke()
    sa(c, P["white"], 0.35); ellipse(c, -50, -30, 36, 12); c.fill()
    c.restore()
def potato_one(c, x, y, s, rot):
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    c.move_to(-80, 0); c.curve_to(-80, -55, 70, -65, 85, -5); c.curve_to(95, 50, -60, 60, -80, 0); c.close_path()
    sa(c, POT); c.fill_preserve(); sa(c, POT2); c.set_line_width(6 / s); c.stroke()
    for (dx, dy) in ((-40, -10), (10, 18), (40, -20), (-10, -25)): circ(c, dx, dy, 4.5, POT2)
    c.restore()
def potatoes(c):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 70, 120, 18); c.fill()
    potato_one(c, -40, 20, 0.95, 0.15); potato_one(c, 55, -15, 0.8, -0.35)
def salad(c):
    bowl(c)
    for (x, y, r) in ((-70, -6, 34), (-30, -34, 36), (20, -30, 38), (66, -8, 34), (0, -4, 30)):
        circ(c, x, y, r, LET, 1, stroke=LET2, sw=4)
    for (x, y) in ((-40, -18), (36, -40)): circ(c, x, y, 17, G.TOM, 1, stroke=G.TOM2, sw=3)
    circ(c, 10, -10, 16, G.CUKE2, 1, stroke=G.CUKE, sw=5)
def bottle(c, body, cap, label, txt):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 108, 64, 12); c.fill()
    box(c, -18, -118, 36, 30, 8, cap, 1, stroke=P["navy"], sw=4)
    c.move_to(-14, -90); c.line_to(14, -90); c.line_to(54, -40); c.line_to(54, 96); c.curve_to(54, 108, -54, 108, -54, 96); c.line_to(-54, -40); c.close_path()
    sa(c, body); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(5); c.stroke()
    box(c, -50, -6, 100, 62, 8, P["white"]); T(c, txt, 24, 0, 25, label, 1, 1, 900, maxw=100)
    sa(c, P["white"], 0.3); box(c, -40, -36, 10, 120, 5, P["white"], 0.3)
def ketchup(c): bottle(c, KETCH, P["white"], KETCH, "SAUCE")
def mustard(c): bottle(c, MUST, P["navy"], MUST2, "MUSTARD")
def mayo(c):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 100, 74, 12); c.fill()
    box(c, -76, -96, 152, 40, 12, P["blue"], 1, stroke=P["navy"], sw=5)
    box(c, -70, -58, 140, 156, 26, hx("#FBF7E9"), 1, stroke=P["navy"], sw=5)
    box(c, -56, -10, 112, 60, 8, P["white"], 1, stroke=P["silver"], sw=3); T(c, "MAYO", 32, 0, 21, P["blue"], 1, 1, 900, maxw=104)
def veggies(c):
    c.save(); c.translate(36, 34); c.scale(0.8, 0.8); cucumber(c); c.restore()
    c.save(); c.translate(-46, -6); c.scale(0.62, 0.62); tomato(c); c.restore()
    for (x, y, r) in ((-96, 62, 30), (-62, 80, 26), (-116, 30, 22)): circ(c, x, y, r, LET, 1, stroke=LET2, sw=4)
def cuke(c):
    c.save(); c.scale(1.05, 1.05); cucumber(c); c.restore()
def hand(c):
    """open hand, palm up-ish (fingers up)"""
    for k, (x, h) in enumerate(((-48, 92), (-16, 108), (16, 104), (48, 86))):
        box(c, x - 14, -h, 28, h + 20, 14, hx("#F2C9A0"), 1, stroke=hx("#B57B4C"), sw=4)
    c.save(); c.translate(-62, 30); c.rotate(-0.9); box(c, -14, -70, 28, 80, 14, hx("#F2C9A0"), 1, stroke=hx("#B57B4C"), sw=4); c.restore()
    box(c, -64, -14, 128, 110, 40, hx("#F2C9A0"), 1, stroke=hx("#B57B4C"), sw=4)
    box(c, -60, -10, 120, 30, 14, hx("#F2C9A0"))
def scent(c, t=0.0):
    c.save(); c.translate(0, 40); c.scale(0.7, 0.7); tomato(c); c.restore()
    for k in range(3):
        x0 = -40 + k * 40; ph = t * 3 + k
        pts = [(x0 + 12 * math.sin(ph + j * 0.9), -40 - j * 14) for j in range(8)]
        kline(c, pts, P["blue"], 6, 0.85)
def spoon_dot(c):
    c.save(); c.rotate(-0.5)
    box(c, 10, -10, 170, 20, 10, P["silver"], 1, stroke=P["grey"], sw=3)
    ellipse(c, -40, 0, 56, 34); sa(c, P["silver"]); c.fill_preserve(); sa(c, P["grey"]); c.set_line_width(4); c.stroke()
    ellipse(c, -40, 0, 44, 24); sa(c, hx("#EEF1F5")); c.fill()
    circ(c, -40, 0, 8, G.TOM, 1, stroke=G.TOM2, sw=2)
    c.restore()
def bite(c):
    """slice of bread with a bite out of it, small tomato pieces"""
    c.save(); c.scale(0.8, 0.8); bread(c); c.restore()
    for (x, y) in ((-30, -10), (10, 10), (-10, 34), (30, -24)): box(c, x - 9, y - 9, 18, 18, 4, G.TOM)
    sa(c, P["card"]);
    for (x, y, r) in ((92, -96, 30), (104, -60, 26)): c.new_sub_path(); c.arc(x, y, r, 0, 2 * math.pi)
    c.fill()
def full_plate(c):
    sa(c, P["navy"], 0.12); ellipse(c, 6, 18, 150, 66); c.fill()
    ellipse(c, 0, 0, 150, 66); sa(c, P["white"]); c.fill_preserve(); sa(c, P["silver"]); c.set_line_width(5); c.stroke()
    ellipse(c, 0, 0, 116, 48); sa(c, hx("#EEF1F5")); c.fill()
    for (x, y, r) in ((-60, -6, 24), (-30, -22, 26), (0, -6, 22)): circ(c, x, y, r, LET, 1, stroke=LET2, sw=3)
    for (x, y) in ((-44, 10), (-12, -30)): circ(c, x, y, 12, G.TOM, 1, stroke=G.TOM2, sw=2)
    for (x, y) in ((44, -6), (74, 6), (54, 22)): circ(c, x, y, 13, G.CUKE2, 1, stroke=G.CUKE, sw=4)
    ellipse(c, 60, -24, 22, 10); sa(c, MUST); c.fill()
def bell(c, calm=0.0, t=0.0):
    col = tuple(lerp(a, b, calm) for a, b in zip(P["red"], P["green"]))
    sh = (1 - calm) * 0.12 * math.sin(t * 26)
    c.save(); c.rotate(sh)
    c.move_to(-90, 60); c.curve_to(-80, 40, -70, 10, -70, -20); c.curve_to(-70, -80, -30, -110, 0, -110)
    c.curve_to(30, -110, 70, -80, 70, -20); c.curve_to(70, 10, 80, 40, 90, 60); c.close_path()
    sa(c, col); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    box(c, -100, 56, 200, 24, 12, col, 1, stroke=P["navy"], sw=6)
    circ(c, 0, 98, 18, P["gold"], 1, stroke=P["navy"], sw=5); circ(c, 0, -116, 12, P["gold"], 1, stroke=P["navy"], sw=4)
    sa(c, P["white"], 0.35); ellipse(c, -34, -50, 12, 30); c.fill()
    c.restore()
    if calm < 0.99:
        for k in range(3):
            ph = (t * 1.6 + k / 3) % 1; r = 130 + 80 * ph; a = (1 - ph) * (1 - calm)
            for sgn in (-1, 1):
                c.save(); sa(c, P["red"], a); c.set_line_width(8); c.set_line_cap(cairo.LINE_CAP_ROUND)
                a0 = (math.pi - 0.45) if sgn < 0 else -0.45; c.new_sub_path(); c.arc(0, -10, r, a0, a0 + 0.9); c.stroke(); c.restore()
def person(c, col=None, x=0, y=0, s=1.0):
    col = col or P["navy"]
    circ(c, x, y - 70 * s, 30 * s, col); c.new_sub_path()
    c.move_to(x - 50 * s, y + 40 * s); c.curve_to(x - 50 * s, y - 40 * s, x + 50 * s, y - 40 * s, x + 50 * s, y + 40 * s); c.close_path(); sa(c, col); c.fill()
def two_people(c):
    person(c, P["blue"], -48, 30, 1.0); person(c, P["navy"], 52, 30, 1.0)
    # heart
    c.save(); c.translate(2, -96); c.scale(1.1, 1.1)
    c.move_to(0, 18); c.curve_to(-34, -6, -20, -34, 0, -18); c.curve_to(20, -34, 34, -6, 0, 18); c.close_path(); sa(c, P["red"]); c.fill(); c.restore()
def repeat(c, t=0.0):
    c.save(); c.rotate(t * 1.5)
    for k in range(2):
        c.save(); c.rotate(k * math.pi); sa(c, P["blue"]); c.set_line_width(18); c.set_line_cap(cairo.LINE_CAP_ROUND)
        c.new_sub_path(); c.arc(0, 0, 72, 0.25, math.pi - 0.35); c.stroke()
        ax, ay = 72 * math.cos(math.pi - 0.35), 72 * math.sin(math.pi - 0.35)
        c.move_to(ax - 30, ay - 4); c.line_to(ax + 4, ay - 34); c.line_to(ax + 18, ay + 10); c.close_path(); c.fill(); c.restore()
    c.restore()
def calm(c, t=0.0):
    """cup of tea with steam"""
    sa(c, P["navy"], 0.12); ellipse(c, 4, 84, 100, 14); c.fill()
    c.new_sub_path(); c.arc(78, 10, 30, -math.pi / 2, math.pi / 2); sa(c, P["navy"]); c.set_line_width(10); c.stroke()
    c.move_to(-80, -30); c.line_to(80, -30); c.curve_to(80, 60, 50, 80, 0, 80); c.curve_to(-50, 80, -80, 60, -80, -30); c.close_path()
    sa(c, P["white"]); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    box(c, -68, 4, 136, 18, 8, P["gold2"])
    for k in range(3):
        x0 = -40 + k * 40; pts = [(x0 + 10 * math.sin(t * 2.5 + k + j * 0.9), -44 - j * 12) for j in range(7)]
        kline(c, pts, P["silver"], 6)
def calendar(c, txt="Tomorrow"):
    shadow_box(c, -110, -100, 220, 210, 24, P["card"], stroke=P["navy"], sw=5)
    box(c, -110, -100, 220, 60, 24, P["blue"]); box(c, -110, -64, 220, 24, 0, P["blue"])
    for x in (-60, 60): box(c, x - 8, -122, 16, 44, 8, P["navy"])
    T(c, "+1", 84, 0, 34, P["navy"], 1, 1, 900, maxw=200)
def refresh(c, t=0.0):
    c.save(); c.rotate(-t * 1.2)
    sa(c, P["green"]); c.set_line_width(20); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.new_sub_path(); c.arc(0, 0, 80, 0.4, 2 * math.pi - 0.3); c.stroke()
    ax, ay = 80 * math.cos(0.4), 80 * math.sin(0.4)
    c.move_to(ax - 34, ay - 6); c.line_to(ax + 30, ay - 10); c.line_to(ax + 4, ay + 44); c.close_path(); c.fill()
    c.restore()
def bulb(c):
    circ(c, 0, -40, 70, hx("#FFF4CF"), 1, stroke=P["navy"], sw=7); box(c, -30, 30, 60, 50, 10, P["silver"], 1, stroke=P["navy"], sw=6)
    for j in range(5):
        aa = -math.pi + j * math.pi / 4; kline(c, [(100 * math.cos(aa), -40 + 100 * math.sin(aa)), (120 * math.cos(aa), -40 + 120 * math.sin(aa))], P["gold"], 7)

ICON = dict(rice=rice, steak=steak, drumstick=drumstick, potatoes=potatoes, salad=salad, ketchup=ketchup, mustard=mustard, mayo=mayo,
            veggies=veggies, cuke=cuke, hand=hand, spoon=spoon_dot, bite=bite, full_plate=full_plate, two_people=two_people)

def mark_check(c, t, x, y, tk, s=46):
    u = ramp(t, tk, tk + 0.35)
    if u > 0: circ(c, x, y, s, P["green"], u, stroke=P["white"], sw=6); check(c, x, y + 2, s * 1.15, P["white"], u, u)

# ------------------------------------------------------------------ 1. hook: until 19, only these four
def sc_food_hook(c, t, S):
    tm = S["times"]; sc = 1 + 0.012 * math.sin(t * 2.4)
    block(c, "Until I was *19*,", 104, 540, 320, P["navy"], 1, sc, hl=P["gold_text"], maxw=940, max_lines=1)
    block(c, "I *only* ate this.", 84, 540, 435, P["navy"], 1, sc, hl=P["blue"], maxw=940, max_lines=1)
    underline(c, t, 330, 750, 385, 0.15)
    block(c, S["he"], 46, 540, 535, P["blue"], 1, 1, w=700, maxw=940, max_lines=2)
    items = (("rice", "Rice", "אורז", 300, 810), ("steak", "Meat", "בשר", 780, 810),
             ("drumstick", "Chicken", "עוף", 300, 1190), ("potatoes", "Potatoes", "תפוחי אדמה", 780, 1190))
    for k, (key, en, he, x, y) in enumerate(items):
        bob = 8 * math.sin(t * 2.2 + k * 1.7)
        card(c, x, y + bob, 420, 350)
        place(c, x, y - 40 + bob, 0.9, ICON[key])
        T(c, en, 46, x, y + 100 + bob, P["navy"], 1, 1, 800, maxw=380)
        T(c, he, 34, x, y + 148 + bob, P["gold_text"], 1, 1, 700, maxw=380)
        mark_check(c, t, x + 160, y - 130 + bob, tm.get(key, 0.6 + 0.4 * k))
    tt = tm.get("thats", 4.0); a, s = PP(t, tt, S, bounce=2.2)
    if a > 0.01: pill(c, "That's it.", 58, 540, 1450, P["navy"], P["white"], a, s, outline=P["gold"])

# ------------------------------------------------------------------ 2. what I would not eat + nightmare to host
def sc_no_list(c, t, S):
    tm = S["times"]; tn = tm["night"]
    al1 = 1 - ramp(t, tn - 0.15, tn + 0.15); al2 = ramp(t, tn - 0.1, tn + 0.25)
    if al1 > 0.01:
        old = St.a; St.a *= al1
        y = head(c, t, S, "What I *wouldn't* eat", "בלי ירקות טריים, חוץ ממלפפון. בלי רטבים, בלי מיונז, בלי חרדל.", y=290, sz=86)
        items = (("veggies", "Fresh veggies", "ירקות טריים", "veg", False), ("cuke", "Except cucumber", "חוץ ממלפפון", "cuke", True),
                 ("ketchup", "Sauces", "רטבים", "sauce", False), ("mayo", "Mayo", "מיונז", "mayo", False), ("mustard", "Mustard", "חרדל", "mustard", False))
        pos = ((200, 790), (540, 790), (880, 790), (370, 1160), (710, 1160))
        for k, ((key, en, he, mk, ok), (x, yy)) in enumerate(zip(items, pos)):
            tk = tm[mk]; a, s = PP(t, tk - 0.25, S, bounce=1.6)
            if a <= 0.01: continue
            card(c, x, yy, 310, 330, a, s, stroke=P["green"] if ok else None)
            place(c, x, yy - 40, 0.72 * s, ICON[key], a)
            T(c, en, 38, x, yy + 92, P["green"] if ok else P["navy"], a, s, 800, maxw=280)
            T(c, he, 30, x, yy + 136, P["gold_text"], a, s, 700, maxw=280)
            if ok: mark_check(c, t, x + 112, yy - 128, tk + 0.1, 40)
            else:
                u = ramp(t, tk + 0.1, tk + 0.45)
                if u > 0: c.save(); c.translate(x, yy - 40); xmark(c, 0, 0, 70, u, 0.92); c.restore()
        St.a = old
    if al2 > 0.01:
        old = St.a; St.a *= al2
        a, sc = PP(t, tn, S)
        block(c, "A *nightmare* for other families to host", 80, 540, 420, P["navy"], a, sc, hl=P["red"], maxw=940, max_lines=3)
        T(c, "הייתי סיוט למשפחות שאירחו אותי.", 46, 540, 600, P["blue"], a, sc, 700)
        # dinner table: full host spread on one side, my plate with only rice and chicken
        ta = S["t0"]; a2, s2 = PP(t, tn + 0.2, S, bounce=1.5); s2 = max(s2, 0.02)
        c.save(); c.translate(540, 960); c.scale(s2, s2); old2 = St.a; St.a *= a2
        box(c, -470, 80, 940, 40, 20, hx("#C9D3DF")); box(c, -470, 80, 940, 14, 7, hx("#AEB9C8"))
        for k, (fn, x, s_) in enumerate(((salad, -360, 0.95), (mayo, -175, 0.8), (ketchup, -15, 0.78), (veggies, 170, 0.9), (mustard, 365, 0.78))):
            c.save(); c.translate(x, -20 + 6 * math.sin(t * 2 + k)); c.scale(s_, s_); fn(c); c.restore()
        St.a = old2; c.restore()
        a3, s3 = PP(t, tn + 0.6, S, bounce=2.0)
        if a3 > 0.01:
            c.save(); c.translate(540, 1320); c.scale(s3, s3); old2 = St.a; St.a *= a3
            shadow_box(c, -300, -110, 600, 220, 30, P["card"], stroke=P["red"], sw=5)
            T(c, "Me:", 40, -200, -40, P["grey"], 1, 1, 700)
            T(c, "Just rice, please.", 50, 40, -40, P["navy"], 1, 1, 900, maxw=400)
            T(c, "רק אורז, תודה.", 40, 0, 40, P["gold_text"], 1, 1, 700, maxw=540)
            St.a = old2; c.restore()
        St.a = old

# ------------------------------------------------------------------ 3. book (reuses v1)
def sc_book(c, t, S): G.sc_book(c, t, S)

# ------------------------------------------------------------------ 4. amygdala = the brain's alarm
def sc_alarm(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "The *amygdala*: the brain's alarm", S["he"], y=270, sz=80)
    tg = M(S, "amyg"); ta = M(S, "alarm")
    gl = ramp(t, tg, tg + 0.5) * (0.75 + 0.25 * math.sin(t * 5))
    a = fade_in(t, S["t0"] + 0.1, S, 0.35)
    bx, by, bs = 540, 830, 0.92
    place(c, bx, by, bs, brain, a, 0.0, gl, t)
    ax, ay = bx + 20 * bs, by + 70 * bs
    if t > ta:   # alarm rings from the amygdala
        for k in range(3):
            ph = ((t - ta) * 1.4 + k / 3) % 1; r = 60 + 230 * ph
            c.new_sub_path(); c.arc(ax, ay, r, 0, 2 * math.pi); sa(c, P["red"], 0.55 * (1 - ph) * ramp(t, ta, ta + 0.3)); c.set_line_width(7); c.stroke()
    ts = M(S, "store"); a2, s2 = PP(t, ts, S, bounce=1.6)
    pill(c, "storehouse of emotional memory", 46, 540, 1130, P["navy"], P["white"], a2, s2, outline=P["gold"], w=800)
    T(c, "מחסן של זיכרון רגשי", 40, 540, 1215, P["gold_text"], a2, s2, 700, maxw=900)
    tl = M(S, "salad"); a3, s3 = PP(t, tl, S, bounce=1.8)
    if a3 > 0.01:
        place(c, 330, 1370, 0.6 * s3, salad, a3)
        kline(c, [(450, 1370), (lerp(450, 560, ramp(t, tl + 0.1, tl + 0.4)), 1370)], P["gold"], 8, a3)
        ta2, ts2 = PP(t, tl + 0.35, S, bounce=2.4)
        pill(c, "Threat!", 56, 730, 1352, P["red"], P["white"], ta2, ts2)
        T(c, "סלט הרגיש לי כמו איום", 34, 730, 1440, P["gold_text"], ta2, ts2, 700, maxw=420)
    RD.source(c, t, S)

# ------------------------------------------------------------------ 5. in my view: understanding is not enough
def sc_view(c, t, S):
    tm = S["times"]
    view_pill(c, t, S, y=270, tk=S["t0"] + 0.02)
    a, sc = PP(t, S["t0"] + 0.1, S)
    block(c, "Understanding *is not enough*", 78, 540, 410, P["navy"], a, sc, hl=P["red"], maxw=940, max_lines=2)
    he_line(c, t, S, S["he"], 545, S["t0"] + 0.25, sz=44)
    for k, (lab, he, key) in enumerate((("Understanding", "הבנה", None), ("A *corrective* experience", "חוויה מתקנת", "corr"))):
        x = 290 if k == 0 else 790; tk = S["t0"] + 0.3 if k == 0 else tm["corr"]
        a, sc = PP(t, tk, S)
        if a <= 0.01: continue
        old = St.a; St.a *= a; c.save(); c.translate(x, 930); c.scale(sc, sc)
        shadow_box(c, -220, -230, 440, 460, 30, P["card"], stroke=P["silver"] if k == 0 else P["green"], sw=5)
        if k == 0: bulb(c)
        else: c.save(); c.translate(0, -50); refresh(c, t); c.restore()
        T(c, lab, 42, 0, 130, P["navy"], 1, 1, 800, hl=P["green"], maxw=400)
        T(c, he, 36, 0, 185, P["gold_text"], 1, 1, 700, maxw=400)
        c.restore(); St.a = old
    xu = ramp(t, S["t0"] + 0.9, S["t0"] + 1.3)
    c.save(); c.translate(290, 870); xmark(c, 0, 0, 80, xu, 0.9); c.restore()
    mark_check(c, t, 970, 720, tm["corr"] + 0.3, 46)

# ------------------------------------------------------------------ 6. what a corrective experience is
def sc_corrective(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "A *corrective experience*", S["he"], y=270, sz=84)
    chips = (("New", "חדשה", "new", P["blue"], 210), ("Safe", "בטוחה", "safe", P["green"], 540), ("Positive", "חיובית", "pos", P["gold"], 870))
    for en, he, mk, col, x in chips:
        a, s = PP(t, tm[mk], S, bounce=2.2)
        pill(c, en, 54, x, 640, col, P["white"], a, s, w=900)
        T(c, he, 38, x, 722, P["gold_text"], a, s, 700, maxw=300)
    tf = tm["fear"]; a, s = PP(t, tf, S)
    T(c, "with the thing you *fear*", 54, 540, 820, P["navy"], a, s, 800, hl=P["red"], maxw=940)
    T(c, "עם הדבר שמפחיד אותך", 40, 540, 880, P["blue"], a, s, 700)
    tr = tm["rewrite"]; cl = ramp(t, tr, tr + 0.9)
    a2 = fade_in(t, S["t0"] + 0.3, S, 0.4)
    place(c, 540, 1110, 0.95, bell, a2, 0.0, cl, t)
    if cl > 0.6: mark_check(c, t, 650, 1010, tr + 0.6, 40)
    al_old = 1 - ramp(t, tr, tr + 0.3); al_new = ramp(t, tr + 0.1, tr + 0.4)
    T(c, "Old alarm", 52, 540, 1330, P["red"], a2 * al_old, 1, 900)
    T(c, "האזעקה הישנה", 40, 540, 1395, P["gold_text"], a2 * al_old, 1, 700)
    T(c, "*Slowly rewritten*", 56, 540, 1330, P["navy"], al_new, 1, 900, hl=P["green"])
    T(c, "נכתבת מחדש, לאט לאט", 40, 540, 1395, P["gold_text"], al_new, 1, 700)

# ------------------------------------------------------------------ 7. the recipe: 4 conditions
def sc_rules(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "How to do it", S["he"], y=270, sz=86)
    cards = (("doses", "Small doses", "מנות קטנות", "spoon"), ("rep", "Repeated", "שוב ושוב", "repeat"),
             ("calm", "Calm setting", "סביבה רגועה", "calm"), ("trust", "People you trust", "אנשים שסומכים עליהם", "two_people"))
    pos = ((300, 790), (780, 790), (300, 1190), (780, 1190))
    for k, ((mk, en, he, ic), (x, yy)) in enumerate(zip(cards, pos)):
        a, s = PP(t, tm[mk] - 0.1, S, bounce=1.8)
        if a <= 0.01: continue
        card(c, x, yy, 440, 360, a, s, stroke=P["blue"])
        if ic == "repeat": place(c, x, yy - 50, 0.8 * s, repeat, a, 0.0, t)
        elif ic == "calm": place(c, x, yy - 40, 0.8 * s, calm, a, 0.0, t)
        else: place(c, x, yy - 45, (0.75 if ic == "spoon" else 0.85) * s, ICON[ic], a)
        T(c, en, 44, x, yy + 100, P["navy"], a, s, 800, maxw=400)
        T(c, he, 34, x, yy + 148, P["gold_text"], a, s, 700, maxw=400)

# ------------------------------------------------------------------ 8. the gradual ladder
STEPS = (("smell", "Smell it", "להריח", "scent"), ("touch", "Touch it", "לגעת", "hand"), ("taste", "Tiny taste", "טעימה קטנטנה", "spoon"),
         ("bite", "Bite with a favourite", "ביס עם אוכל אהוב", "bite"), ("full", "Full portion", "מנה מלאה", "full_plate"))
def ladder(c, t, S, tops, xs, w, base, times, icon_s=0.56, labels=True, a_all=1.0):
    for k, (mk, en, he, ic) in enumerate(STEPS[:len(tops)]):
        tk = times[k]; a, s = PP(t, tk - 0.1, S, bounce=1.6); a *= a_all
        if a <= 0.01: continue
        x = xs[k]; top = tops[k]; hgt = base - top
        lit = t > tk
        c.save(); c.translate(x + w / 2, base); c.scale(1, s); c.translate(-(x + w / 2), -base)
        shadow_box(c, x + 4, top, w - 8, hgt, 18, P["card"], a=a, stroke=P["blue"] if lit else P["silver"], sw=5)
        c.restore()
        if labels:
            T(c, f"{k + 1}", 40, x + w / 2, top + 38, P["gold_text"], a, 1, 900)
            T(c, en, 30, x + w / 2, top + 80, P["navy"], a, 1, 800, maxw=w - 20) if mk != "bite" else (
                T(c, "Bite with", 30, x + w / 2, top + 78, P["navy"], a, 1, 800, maxw=w - 20), T(c, "a favourite", 30, x + w / 2, top + 112, P["navy"], a, 1, 800, maxw=w - 20))
            T(c, he, 26, x + w / 2, top + (150 if mk == "bite" else 118), P["gold_text"], a, 1, 700, maxw=w - 16)
        cy = top - 78
        if ic == "scent": place(c, x + w / 2, cy, icon_s * s, scent, a, 0.0, t)
        else: place(c, x + w / 2, cy, (icon_s * 0.9 if ic == "spoon" else icon_s) * s, ICON[ic], a)
def climber_pos(t, times, xs, tops, w):
    """index of current step and a hop between steps"""
    k = -1
    for i, tk in enumerate(times):
        if t >= tk: k = i
    if k < 0: return None
    u = ramp(t, times[k], times[k] + 0.35)
    x1 = xs[k] + w / 2; y1 = tops[k]
    if k == 0: return x1, y1, u
    x0 = xs[k - 1] + w / 2; y0 = tops[k - 1]
    return lerp(x0, x1, u), lerp(y0, y1, u) - 60 * math.sin(math.pi * u), 1.0
def sc_ladder(c, t, S):
    tm = S["times"]
    view = None
    y = head(c, t, S, "Go *gradual*", S["he"], y=260, sz=96)
    w = 186; xs = [75 + k * w for k in range(5)]; base = 1530; tops = [1320 - k * 150 for k in range(5)]
    times = [tm[s[0]] for s in STEPS]
    ladder(c, t, S, tops, xs, w, base, times)
    p = climber_pos(t, times, xs, tops, w)
    # the climber stands on the step just right of its icon? keep it on the step top, left side
    if p:
        x, yy, a = p
        c.save(); c.translate(x - 62, yy - 6); old = St.a; St.a *= a; person(c, P["navy"], 0, 0, 0.42); St.a = old; c.restore()
    tf = tm["full"]; u = ramp(t, tf + 0.3, tf + 0.7)
    if u > 0: diamond(c, xs[4] + w / 2, tops[4] - 170, 26 * u, P["gold"])

# ------------------------------------------------------------------ 9. too much? one step back
def sc_back(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Too much? *Go back one step.*", S["he"], y=270, sz=80)
    w = 300; xs = [90 + k * w for k in range(3)]; base = 1320; tops = [1170 - k * 150 for k in range(3)]
    st0 = S["t0"] + 0.1
    ladder(c, t, S, tops, xs, w, base, [st0, st0, st0], icon_s=0.55, labels=True)
    tb = tm["back"]; u = ramp(t, tb, tb + 0.6)
    # climber on step 3, hops back to step 2
    k_from, k_to = 2, 1
    x = lerp(xs[k_from] + w / 2, xs[k_to] + w / 2, u); yy = lerp(tops[k_from], tops[k_to], u) - 60 * math.sin(math.pi * u)
    c.save(); c.translate(x - 95, yy - 6); person(c, P["navy"], 0, 0, 0.5); c.restore()
    if u > 0:
        c.save(); sa(c, P["gold"]); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND)
        N = 30; pts = [(lerp(xs[2] + w / 2, xs[1] + w / 2, i / N), lerp(tops[2], tops[1], i / N) - 220 - 70 * math.sin(math.pi * i / N)) for i in range(N + 1)]
        m = max(2, int(N * u) + 1); c.move_to(*pts[0])
        for q in pts[1:m]: c.line_to(*q)
        c.stroke(); c.restore()
        if u >= 1: ex, ey = pts[-1]; kline(c, [(ex, ey), (ex + 30, ey - 22)], P["gold"], 9); kline(c, [(ex, ey), (ex + 30, ey + 22)], P["gold"], 9)
        a2, s2 = PP(t, tb + 0.4, S); pill(c, "Not failure. The method.", 44, 540, 1410, P["navy"], P["white"], a2, s2, outline=P["gold"])
        T(c, "זה לא כישלון, זו השיטה", 36, 540, 1490, P["gold_text"], a2, s2, 700)
    tt = tm["tomorrow"]; a3, s3 = PP(t, tt, S, bounce=2.0)
    if a3 > 0.01:
        c.save(); c.translate(240, 680); c.scale(0.8 * s3, 0.8 * s3); old = St.a; St.a *= a3; calendar(c); St.a = old; c.restore()
        T(c, "Try again tomorrow", 36, 240, 800, P["navy"], a3, s3, 800, maxw=360)
        T(c, "מנסים שוב מחר", 32, 240, 848, P["gold_text"], a3, s3, 700, maxw=360)

# ------------------------------------------------------------------ 10. today: full plate
def sc_plate(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Today, I eat *all of it.*", S["he"], y=290, sz=92)
    a, sc = PP(t, S["t0"] + 0.2, S, bounce=1.5)
    cy = 960
    place(c, 540, cy, 1.25 * sc, plate, a)
    parts = ((salad, -165, -25, 1.15), (veggies, 165, -30, 1.05), (mayo, -10, -55, 0.62), (mustard, 75, -60, 0.58), (drumstick, 175, 60, 0.7), (rice, -150, 70, 0.7))
    for k, (fn, dx, dy, s) in enumerate(parts):
        a2, s2 = PP(t, S["t0"] + 0.35 + 0.15 * k, S, bounce=2.0)
        place(c, 540 + dx * 1.25, cy + dy * 1.25 - 30, s * s2, fn, a2)
    mark_check(c, t, 920, 700, S["t0"] + 1.2, 56)
    tt = tm["tiny"]; a3, s3 = PP(t, tt, S, bounce=2.0)
    if a3 > 0.01:
        place(c, 250, 1330, 0.55 * s3, spoon_dot, a3)
        T(c, "It started with", 44, 640, 1300, P["navy"], a3, s3, 800, maxw=560)
        T(c, "*one tiny taste*", 56, 640, 1370, P["navy"], a3, s3, 900, hl=P["gold_text"], maxw=560)
        T(c, "והכול התחיל מטעימה אחת קטנטנה", 34, 640, 1440, P["blue"], a3, s3, 700, maxw=560)

# ------------------------------------------------------------------ 11-12. CTA: question, Comment FOOD, guide
def sc_cta(c, t, S):
    t0 = S["t0"]; tk = S["times"]["keyword"]
    a, s = PP(t, t0 + 0.05, S)
    block(c, S["en"], 74, 540, 380, P["navy"], a, s * (1 + 0.01 * math.sin(t * 2.4)), hl=P["gold_text"], maxw=940, max_lines=3)
    a, s = PP(t, t0 + 0.2, S); block(c, S["he"], 48, 540, 560, P["blue"], a, s, w=700, maxw=940, max_lines=2)
    for k, fn in enumerate((tomato, mayo, mustard, salad)):
        a3, s3 = PP(t, t0 + 0.35 + 0.12 * k, S, bounce=2.2)
        place(c, 540 + (k - 1.5) * 220, 760 + 10 * math.sin(t * 3 + k), (0.62 if fn is tomato else 0.55) * s3, fn, a3)
    a, s = PP(t, tk - 0.25, S); T(c, "Comment", 68, 540, 925, P["navy"], a, s, 900)
    a, s = PP(t, tk - 0.05, S, bounce=2.4)
    if a > 0.01:
        f = RD.font(130, 900); kw = S.get("keyword", "FOOD"); pw = f.getlength(kw) + 140; ph = 130 * 1.55; yy = 1085
        c.save(); c.translate(540, yy); c.scale(s, s); old = St.a; St.a *= a
        sa(c, P["navy"], 0.18); rr(c, -pw / 2, -ph / 2 + 12, pw, ph, ph / 2); c.fill()
        g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *P["gold"][:3]); g.add_color_stop_rgb(0.5, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
        rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(7); c.stroke()
        St.a = old; c.restore()
        T(c, kw, 130, 540, yy + 4, P["navy"], a, s, 900)
        T(c, S.get("keyword_he", ""), 48, 540, 1245, P["blue"], *PP(t, tk + 0.15, S), 700)
    tg = S["times"].get("guide", tk + 0.6); a, s = PP(t, tg, S, bounce=1.8)
    pill(c, "I'll send you the guide", 46, 540, 1355, P["navy"], P["white"], a, s, outline=P["gold"])
    T(c, "ואשלח לכם מדריך צעד אחר צעד", 38, 540, 1440, P["gold_text"], a, s, 700)
    acct = S.get("follow")
    if acct: a, s = PP(t, tg + 0.5, S); T(c, acct, 46, 540, 1520, P["navy"], a, s, 800, hl=P["gold_text"])
