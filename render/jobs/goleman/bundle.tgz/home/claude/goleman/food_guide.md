# Step by step: make peace with a food you hate
צעד אחר צעד: להשלים עם אוכל שאתם שונאים

By Noam Roz (@noamroz__)

Until I was 19, I ate rice, meat, chicken and potatoes, and that was it. No fresh vegetables apart from cucumber, no sauces, no mayo, no mustard. I was a nightmare for other families to host. Today I eat all of it, and it started with one tiny taste. This is the ladder I used.

## Why it works
In *Emotional Intelligence* (1995), Daniel Goleman describes the amygdala as the brain's alarm and a storehouse of emotional memory. So a food can set off the alarm before you even think.

In my view, understanding that is not enough. You need a **corrective experience**: a new, safe, positive experience with the thing you fear, repeated until it slowly rewrites the old alarm.

## Before you start
- Pick **one** food. Just one.
- Pick a **favourite food** to pair it with (bread, rice, anything you love).
- Pick a **calm time** (not hungry, not rushed) and, if you can, a **person you trust**.
- Rate how uncomfortable the food feels from 0 (fine) to 10 (no way).

## The ladder
1. **Have it near you.** Put it on the table during a meal. No eating, just sitting with it.
2. **Smell it.** One sniff, then carry on with your meal.
3. **Touch it.** Hold a piece, feel it, put it down.
4. **A tiny taste.** The size of a grain of rice. You are allowed to spit it out.
5. **A tiny piece with a favourite.** On bread, inside rice, with something you love.
6. **A real bite on its own.** Chew slowly, notice what is actually there.
7. **A small portion, then a full portion.**

Stay on a step for a few days, or until it feels like a 3 out of 10 or less. Then move up one.

## Tips for corrective experiences
- **Small doses.** Smaller than you think. Ridiculous is fine.
- **Repeat.** The same step, again and again. Repetition is what rewrites the alarm.
- **Calm setting.** Not when you are stressed, hungry or in a hurry.
- **People you trust.** No teasing, no pressure, no audience.
- **Say something kind out loud.** "Tasty." "This is OK." It sounds silly, and it helps.
- **Change the form.** Seeds out, cut tiny, cooked instead of raw, a milder version.
- **Too much? Go back one step**, and try again tomorrow. Not failure, the method.
- **Celebrate each step.** You are teaching your brain that this food is safe.

## My 2-week tracker
| Day | Food | Step (1 to 7) | Before (0 to 10) | After (0 to 10) | Note |
|---|---|---|---|---|---|
| 1 to 14 | | | | | |

## A gentle note
This guide is for everyday picky eating. If eating problems are severe, affect your health, or cause you real distress, please talk to a professional.
