"""Goleman v2 build: reelkit make_reel with the house voice chain at atempo 1.0 (Noam asked for slower speech).
usage: nice -n 10 python3 make_v2.py build_v2/spec_v2.json goleman_v2_vo.mp3 build_v2/out [--preview]"""
import sys
sys.path.insert(0, "/home/claude/reelkit")
import voice
voice.TEMPO = 1.0
import make_reel
make_reel.main()
