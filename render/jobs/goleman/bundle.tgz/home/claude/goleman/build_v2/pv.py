import sys, json
sys.path.insert(0, "/home/claude/reelkit")
import render as RD
spec = RD.load_spec("/home/claude/goleman/build_v2/spec_v2.json")
tim = json.load(open("/home/claude/goleman/build_v2/out/timing.json"))
R = RD.Reel(spec, tim)
for S in R.scenes: print(S["type"], round(S["t0"], 2), {k: round(v, 2) for k, v in S["times"].items() if isinstance(v, float)})
ts = [float(x) for x in sys.argv[2:]]
RD.preview(R, ts, sys.argv[1])
