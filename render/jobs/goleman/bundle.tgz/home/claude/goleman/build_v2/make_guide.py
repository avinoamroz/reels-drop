"""food_guide.pdf: 2 A4 pages, navy and gold. Content mirrors /home/claude/goleman/food_guide.md."""
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, white
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from bidi.algorithm import get_display

F = "/home/claude/vid/fonts/Heebo-{}.ttf"
for w in (400, 700, 900): pdfmetrics.registerFont(TTFont(f"H{w}", F.format(w)))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("H400", normal="H400", bold="H900", italic="H400", boldItalic="H900")
NAVY, BLUE, GOLD, GOLD2, GOLDT, GREY, SILVER, BG = (HexColor(x) for x in ("#163260", "#2A88D4", "#B8923F", "#E6C77E", "#96702A", "#5B6B82", "#D9DDE3", "#F4F5F7"))
W, H = A4; M = 18 * mm
def he(s): return get_display(s)

body = ParagraphStyle("b", fontName="H400", fontSize=10.3, leading=14.2, textColor=NAVY, spaceAfter=5)
small = ParagraphStyle("s", parent=body, fontSize=9.2, leading=12.5, textColor=GREY)
h2 = ParagraphStyle("h2", fontName="H900", fontSize=14.5, leading=18, textColor=NAVY, spaceBefore=8, spaceAfter=4)
step_t = ParagraphStyle("st", parent=body, fontSize=10.3, leading=13.6, spaceAfter=0)
def H2(en, he_):
    t = Table([[Paragraph(en, h2), Paragraph(f'<font name="H700" color="#96702A" size="11">{he(he_)}</font>', ParagraphStyle("r", parent=body, alignment=2))]],
              colWidths=[(W - 2 * M) * 0.62, (W - 2 * M) * 0.38])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("LINEBELOW", (0, 0), (-1, 0), 1.6, GOLD), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("TOPPADDING", (0, 0), (-1, -1), 6)]))
    return [t, Spacer(1, 5)]
def P(s, st=body): return Paragraph(s, st)

def page_bg(c, doc):
    c.saveState()
    c.setFillColor(BG); c.rect(0, 0, W, H, stroke=0, fill=1)
    if doc.page == 1:
        c.setFillColor(NAVY); c.rect(0, H - 58 * mm, W, 58 * mm, stroke=0, fill=1)
        c.setFillColor(GOLD); c.rect(0, H - 59.5 * mm, W, 1.5 * mm, stroke=0, fill=1)
        c.setFillColor(GOLD2); c.setFont("H700", 10); c.drawString(M, H - 15 * mm, "@noamroz__   |   FOOD GUIDE")
        c.setFillColor(white); c.setFont("H900", 23); c.drawString(M, H - 29 * mm, "Step by step:")
        c.drawString(M, H - 40 * mm, "make peace with a food you hate")
        c.setFillColor(GOLD2); c.setFont("H700", 13); c.drawRightString(W - M, H - 50.5 * mm, he("צעד אחר צעד: להשלים עם אוכל שאתם שונאים"))
        # small ladder motif
        x0, y0 = W - M - 40 * mm, H - 41 * mm
        for k in range(5):
            c.setFillColor(GOLD if k == 4 else HexColor("#2A4A80")); c.roundRect(x0 + k * 8.2 * mm, y0, 7.2 * mm, (4 + k * 4.5) * mm, 1.5 * mm, stroke=0, fill=1)
    else:
        c.setFillColor(NAVY); c.rect(0, H - 14 * mm, W, 14 * mm, stroke=0, fill=1)
        c.setFillColor(GOLD); c.rect(0, H - 15 * mm, W, 1 * mm, stroke=0, fill=1)
        c.setFillColor(white); c.setFont("H700", 10); c.drawString(M, H - 9 * mm, "Step by step: make peace with a food you hate")
    c.setFillColor(GREY); c.setFont("H400", 8.5)
    c.drawString(M, 10 * mm, "Noam Roz  |  noamroz.com  |  @noamroz__"); c.drawRightString(W - M, 10 * mm, f"{doc.page} / 2")
    c.restoreState()

doc = BaseDocTemplate("/home/claude/goleman/food_guide.pdf", pagesize=A4, title="Step by step: make peace with a food you hate", author="Noam Roz",
                      leftMargin=M, rightMargin=M, topMargin=M, bottomMargin=16 * mm)
f1 = Frame(M, 16 * mm, W - 2 * M, H - 66 * mm - 16 * mm, id="f1", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
f2 = Frame(M, 16 * mm, W - 2 * M, H - 22 * mm - 16 * mm, id="f2", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
doc.addPageTemplates([PageTemplate("p1", [f1], onPage=page_bg, autoNextPageTemplate="p2"), PageTemplate("p2", [f2], onPage=page_bg)])

S = []
S.append(P("Until I was 19, I ate rice, meat, chicken and potatoes, and that was it. No fresh vegetables apart from cucumber, no sauces, "
           "no mayo, no mustard. I was a nightmare for other families to host. Today I eat all of it, and it started with one tiny taste. "
           "<b>This is the ladder I used.</b>"))
S += H2("Why it works", "למה זה עובד")
S.append(P("In <i>Emotional Intelligence</i> (1995), Daniel Goleman describes the amygdala as the brain's alarm and a storehouse of emotional memory. "
           "So a food can set off the alarm before you even think."))
S.append(P("<b>In my view</b>, understanding that is not enough. You need a <font color='#2A88D4'><b>corrective experience</b></font>: "
           "a new, safe, positive experience with the thing you fear, repeated until it slowly rewrites the old alarm."))
S += H2("Before you start", "לפני שמתחילים")
for s in ("Pick <b>one</b> food. Just one.", "Pick a <b>favourite food</b> to pair it with (bread, rice, anything you love).",
          "Pick a <b>calm time</b> (not hungry, not rushed) and, if you can, a <b>person you trust</b>.",
          "Rate how uncomfortable the food feels from 0 (fine) to 10 (no way)."):
    S.append(P(f'<font color="#B8923F"><font name="H900" size="13">&#8226;</font></font>&nbsp;&nbsp;{s}', ParagraphStyle("li", parent=body, leftIndent=12, firstLineIndent=-12, spaceAfter=3)))
S += H2("The ladder", "הסולם")
steps = (("Have it near you.", "Put it on the table during a meal. No eating, just sitting with it.", "שיהיה לידכם"),
         ("Smell it.", "One sniff, then carry on with your meal.", "להריח"),
         ("Touch it.", "Hold a piece, feel it, put it down.", "לגעת"),
         ("A tiny taste.", "The size of a grain of rice. You are allowed to spit it out.", "טעימה קטנטנה"),
         ("A tiny piece with a favourite.", "On bread, inside rice, with something you love.", "חתיכה עם אוכל אהוב"),
         ("A real bite on its own.", "Chew slowly, notice what is actually there.", "ביס אמיתי, לבד"),
         ("A small portion, then a full portion.", "You made it. Keep it on the menu.", "מנה קטנה, ואז מלאה"))
rows = []
for k, (a, b, h) in enumerate(steps):
    num = Paragraph(f'<font name="H900" size="15" color="{"#FFFFFF"}">{k + 1}</font>', ParagraphStyle("n", parent=body, alignment=1, leading=17))
    rows.append([num, P(f"<b>{a}</b> {b}", step_t), P(f'<font name="H700" color="#96702A">{he(h)}</font>', ParagraphStyle("hr", parent=step_t, alignment=2))])
lt = Table(rows, colWidths=[11 * mm, (W - 2 * M) - 11 * mm - 44 * mm, 44 * mm])
ts = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 4.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 4.2),
      ("LINEBELOW", (1, 0), (-1, -2), 0.5, SILVER), ("LEFTPADDING", (1, 0), (1, -1), 8)]
for k in range(len(rows)): ts.append(("BACKGROUND", (0, k), (0, k), GOLD if k == len(rows) - 1 else NAVY if k > 2 else BLUE))
lt.setStyle(TableStyle(ts)); S.append(lt); S.append(Spacer(1, 6))
S.append(P("<b>Stay on a step for a few days</b>, or until it feels like a 3 out of 10 or less. Then move up one. Slow is the point.",
           ParagraphStyle("note", parent=body, backColor=HexColor("#FFFFFF"), borderColor=GOLD, borderWidth=1, borderPadding=7, borderRadius=6, spaceBefore=4)))
S.append(PageBreak())

S += H2("Tips for corrective experiences", "טיפים לחוויה מתקנת")
tips = (("Small doses.", "Smaller than you think. Ridiculous is fine."),
        ("Repeat.", "The same step, again and again. Repetition is what rewrites the alarm."),
        ("Calm setting.", "Not when you are stressed, hungry or in a hurry."),
        ("People you trust.", "No teasing, no pressure, no audience."),
        ("Say something kind out loud.", "\"Tasty.\" \"This is OK.\" It sounds silly, and it helps."),
        ("Change the form.", "Seeds out, cut tiny, cooked instead of raw, a milder version."),
        ("Too much? Go back one step,", "and try again tomorrow. Not failure, the method."),
        ("Celebrate each step.", "You are teaching your brain that this food is safe."))
tr = []
for i in range(0, len(tips), 2):
    tr.append([P(f'<font color="#B8923F"><font name="H900" size="13">&#8226;</font></font> <b>{a}</b> {b}', ParagraphStyle("tp", parent=body, fontSize=9.8, leading=13, spaceAfter=0)) for a, b in tips[i:i + 2]])
tt = Table(tr, colWidths=[(W - 2 * M) / 2] * 2)
tt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (-1, -1), white), ("BOX", (0, 0), (-1, -1), 0.8, SILVER),
                        ("INNERGRID", (0, 0), (-1, -1), 0.5, SILVER), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8)]))
S.append(tt)
S += H2("My 2-week tracker", "מעקב לשבועיים")
S.append(P("My food: ______________________________&nbsp;&nbsp;&nbsp;&nbsp;My favourite to pair it with: ______________________", small))
hs = ParagraphStyle("th", parent=body, fontName="H700", fontSize=8.8, leading=10.5, textColor=white, alignment=1, spaceAfter=0)
head = [Paragraph(x, hs) for x in ("Day", "Step<br/>(1 to 7)", "What I did", "Before<br/>(0 to 10)", "After<br/>(0 to 10)", "Note")]
data = [head] + [[Paragraph(f'<font name="H700">{d}</font>', ParagraphStyle("d", parent=body, alignment=1, spaceAfter=0, fontSize=9.5)), "", "", "", "", ""] for d in range(1, 15)]
cw = [12 * mm, 17 * mm, 52 * mm, 18 * mm, 18 * mm]; cw.append((W - 2 * M) - sum(cw))
tk = Table(data, colWidths=cw, rowHeights=[24] + [17.6] * 14)
st = [("BACKGROUND", (0, 0), (-1, 0), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("GRID", (0, 0), (-1, -1), 0.5, SILVER),
      ("BOX", (0, 0), (-1, -1), 1, NAVY), ("LINEBELOW", (0, 0), (-1, 0), 1.6, GOLD), ("TOPPADDING", (0, 0), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -1), 1)]
for r in range(1, 15): st.append(("BACKGROUND", (0, r), (-1, r), white if r % 2 else HexColor("#EEF1F5")))
st.append(("LINEBELOW", (0, 7), (-1, 7), 1.4, GOLD))
tk.setStyle(TableStyle(st)); S.append(tk)
S.append(Spacer(1, 4)); S.append(P("Before and after: how uncomfortable it felt, 0 (fine) to 10 (no way). Gold line: end of week one.", small))
S += H2("A gentle note", "הערה חשובה")
S.append(P("This guide is for everyday picky eating, shared from my own experience. If eating problems are severe, affect your health, "
           "or cause you real distress, please talk to a professional."))
doc.build(S)
print("ok")
