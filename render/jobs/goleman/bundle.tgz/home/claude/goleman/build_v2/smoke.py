import sys, json, cairo
sys.path.insert(0, "/home/claude/reelkit")
import render as RD
R = RD.Reel(RD.load_spec("/home/claude/goleman/build_v2/spec_v2.json"), json.load(open("/home/claude/goleman/build_v2/out/timing.json")))
s = cairo.ImageSurface(cairo.FORMAT_ARGB32, 1080, 1920); c = cairo.Context(s)
n = int(R.T_END * 30)
for fi in range(0, n, 2): R.draw(c, fi / 30)
print("ok", n)
