"""Bespoke reelkit scenes for the Goleman reel (@noamroz__): food aversion, the amygdala, corrective experiences,
the hourly emotion check. Loaded through the spec field "scene_module"; sc_<name>(c, t, S) is scene type <name>.
sc_cta overrides the built-in CTA (question + "Tell me in the comments" pill + pointing emoji), so the CTA hold and ding still apply."""
import math, os
import cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, diamond, draw_emoji, image_surf
from kit import ease, ramp, lerp, St, sa, rr, line as kline, circ, box

HERE = os.path.dirname(os.path.abspath(__file__))
def hx(h): return RD.kit.hx(h)
def M(S, k, d=None): return S["times"].get(k, d if d is not None else S["t0"] + 0.3)
def he_line(c, t, S, s, y, tk, sz=48, color=None, maxw=940):
    a, sc = PP(t, tk, S); return block(c, s, sz, 540, y, color or P["blue"], a, sc, w=700, maxw=maxw, max_lines=2)
def head(c, t, S, en, he, y=300, sz=82, tk=None, he_t=None, breathe=False):
    tk = S["t0"] + 0.05 if tk is None else tk
    a, sc = PP(t, tk, S); h = block_h(en, sz, 900, 940, 3)
    if breathe: sc *= 1 + 0.012 * math.sin(t * 2.4)
    block(c, en, sz, 540, y + h / 2, P["navy"], a, sc, hl=P["blue"], maxw=940, max_lines=3); y += h + 16
    if he:
        hh = block_h(he, 48, 700, 940, 2); he_line(c, t, S, he, y + hh / 2, he_t if he_t is not None else tk + 0.2); y += hh
    return y + 20
def underline(c, t, x0, x1, y, t0, d=0.9, col=None):
    u = ramp(t, t0, t0 + d)
    if u > 0.01: kline(c, [(x0, y), (lerp(x0, x1, u), y)], col or P["gold"], 9)
def xmark(c, x, y, s, u, a=1.0):
    """red X drawn in two strokes, u 0..1"""
    if u <= 0: return
    u1 = min(1, u * 2); u2 = max(0, u * 2 - 1)
    kline(c, [(x - s, y - s), (lerp(x - s, x + s, u1), lerp(y - s, y + s, u1))], P["red"], s * 0.28, a)
    if u2 > 0: kline(c, [(x + s, y - s), (lerp(x + s, x - s, u2), lerp(y - s, y + s, u2))], P["red"], s * 0.28, a)
def check(c, x, y, s, col, a=1.0, u=1.0):
    pts = [(x - 0.5 * s, y), (x - 0.15 * s, y + 0.35 * s), (x + 0.55 * s, y - 0.4 * s)]
    if u <= 0: return
    if u < 0.4: pts = [pts[0], (lerp(pts[0][0], pts[1][0], u / 0.4), lerp(pts[0][1], pts[1][1], u / 0.4))]
    elif u < 1: v = (u - 0.4) / 0.6; pts = [pts[0], pts[1], (lerp(pts[1][0], pts[2][0], v), lerp(pts[1][1], pts[2][1], v))]
    kline(c, pts, col, s * 0.16, a)
def view_pill(c, t, S, y=280, tk=None):
    a, sc = PP(t, S["t0"] + 0.02 if tk is None else tk, S)
    pill(c, "In my view", 44, 540, y, P["gold"], P["white"], a, sc, w=800)
def ellipse(c, x, y, rx, ry):
    c.save(); c.translate(x, y); c.scale(rx, ry); c.new_sub_path(); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
def card(c, x, y, w, h, a=1.0, sc=1.0, stroke=None):
    if sc <= 0.01 or a <= 0.01: return
    c.save(); c.translate(x, y); c.scale(sc, sc); shadow_box(c, -w / 2, -h / 2, w, h, 30, P["card"], a=a, stroke=stroke or P["silver"], sw=4); c.restore()
def place(c, x, y, s, fn, a=1.0, rot=0.0, *args):
    if a <= 0.01 or s <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); old = St.a; St.a *= a; fn(c, *args); St.a = old; c.restore()

# ------------------------------------------------------------------ drawn food (around 0,0, about 200 px)
BEIGE, BEIGE2, CHICK = hx("#EBD6A6"), hx("#D9BD82"), hx("#D4A955")
CRUST, CRUMB = hx("#C27F35"), hx("#F4DDAA")
TOM, TOM2, LEAF = hx("#E0463C"), hx("#B92E28"), hx("#3E9B4F")
CUKE, CUKE2 = hx("#5DAA4A"), hx("#BFE3A0")
def hummus(c):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 52, 110, 22); c.fill()
    c.move_to(-110, 0); c.curve_to(-100, 95, 100, 95, 110, 0); c.close_path(); sa(c, P["white"]); c.fill_preserve(); sa(c, P["blue"]); c.set_line_width(6); c.stroke()
    kline(c, [(-80, 44), (80, 44)], P["blue"], 5, 0.5)
    ellipse(c, 0, 0, 110, 34); sa(c, BEIGE); c.fill_preserve(); sa(c, P["blue"]); c.set_line_width(6); c.stroke()
    ellipse(c, 0, 0, 72, 20); sa(c, BEIGE2); c.set_line_width(7); c.stroke()
    ellipse(c, 0, 0, 30, 9); sa(c, P["gold2"]); c.fill()
    for (x, y) in ((-44, -6), (40, 6), (12, -14), (-14, 12)): circ(c, x, y, 8, CHICK)
    for (x, y) in ((58, -10), (-60, 8), (24, 16)): circ(c, x, y, 3.5, P["red"])
def cottage(c, scale_heap=1.0):
    sa(c, P["navy"], 0.12); ellipse(c, 4, 92, 80, 16); c.fill()
    c.move_to(-82, -40); c.line_to(82, -40); c.line_to(64, 88); c.line_to(-64, 88); c.close_path()
    sa(c, P["white"]); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    c.move_to(-78, -12); c.line_to(78, -12); c.line_to(73, 22); c.line_to(-73, 22); c.close_path(); sa(c, P["blue"]); c.fill()
    for k in range(9):
        x = -66 + k * 16.5; y = -44 - 10 * scale_heap * abs(math.sin(k * 1.3)) - 8 * scale_heap
        circ(c, x, y, 13, P["white"], 1, stroke=P["silver"], sw=3)
    for k in range(8):
        x = -58 + k * 16.5; circ(c, x, -50 - 16 * scale_heap, 11, P["white"], 1, stroke=P["silver"], sw=3)
def tomato(c, face=False):
    circ(c, 0, 10, 82, TOM, 1, stroke=TOM2, sw=6)
    sa(c, P["white"], 0.35); ellipse(c, -32, -22, 18, 11); c.fill()
    for k in range(5):
        ang = -math.pi / 2 + k * 2 * math.pi / 5
        kline(c, [(0, -66), (34 * math.cos(ang), -66 + 16 * math.sin(ang) + 6)], LEAF, 9)
    kline(c, [(0, -70), (6, -96)], LEAF, 8)
def tomato_half(c, seeds=1.0):
    circ(c, 0, 0, 82, TOM, 1, stroke=TOM2, sw=6); circ(c, 0, 0, 64, hx("#F2735F"))
    for k in range(3):
        ang = k * 2 * math.pi / 3 + 0.4; x, y = 34 * math.cos(ang), 34 * math.sin(ang)
        circ(c, x, y, 22, hx("#F7B54F"), seeds)
        for j in range(4):
            aa = j * math.pi / 2 + ang; circ(c, x + 10 * math.cos(aa), y + 10 * math.sin(aa), 4, hx("#FFF1C9"), seeds)
    kline(c, [(0, 0), (0, -64)], TOM2, 5, 0.6); kline(c, [(0, 0), (55, 32)], TOM2, 5, 0.6); kline(c, [(0, 0), (-55, 32)], TOM2, 5, 0.6)
def cucumber(c):
    c.save(); c.rotate(-0.5); box(c, -95, -28, 190, 56, 28, CUKE, 1, stroke=hx("#2E7A33"), sw=5)
    for k in range(5): circ(c, -60 + k * 30, -6 + 8 * (k % 2), 3, CUKE2)
    c.restore()
    circ(c, 74, -40, 34, CUKE2, 1, stroke=CUKE, sw=8)
    for k in range(6): aa = k * math.pi / 3; circ(c, 74 + 16 * math.cos(aa), -40 + 16 * math.sin(aa), 3, hx("#F4FBE9"))
def veg(c):
    c.save(); c.translate(36, 30); c.scale(0.95, 0.95); cucumber(c); c.restore()
    c.save(); c.translate(-40, 0); c.scale(0.7, 0.7); tomato(c); c.restore()
    for k, (x, y, r) in enumerate(((-90, 60, 30), (-58, 76, 26), (-110, 30, 22))):   # lettuce leaf lumps
        circ(c, x, y, r, hx("#7CC45B"), 1, stroke=hx("#3E8E3A"), sw=4)
def bread(c):
    c.move_to(-120, 110); c.line_to(-120, -40); c.curve_to(-160, -60, -150, -140, -80, -132); c.curve_to(-40, -170, 40, -170, 80, -132)
    c.curve_to(150, -140, 160, -60, 120, -40); c.line_to(120, 110); c.close_path(); sa(c, CRUST); c.fill()
    c.move_to(-102, 94); c.line_to(-102, -46); c.curve_to(-136, -64, -126, -120, -76, -114); c.curve_to(-36, -148, 36, -148, 76, -114)
    c.curve_to(126, -120, 136, -64, 102, -46); c.line_to(102, 94); c.close_path(); sa(c, CRUMB); c.fill()
    for (x, y) in ((-50, -40), (30, 10), (-20, 50), (60, -60), (-70, 30), (40, 70)): circ(c, x, y, 4, hx("#E2C386"))
def plate(c):
    sa(c, P["navy"], 0.12); ellipse(c, 6, 18, 330, 150); c.fill()
    ellipse(c, 0, 0, 330, 150); sa(c, P["white"]); c.fill_preserve(); sa(c, P["silver"]); c.set_line_width(6); c.stroke()
    ellipse(c, 0, 0, 260, 112); sa(c, hx("#EEF1F5")); c.fill()

FOODS = dict(hummus=hummus, cottage=cottage, veg=veg)

# ------------------------------------------------------------------ 1. hook
def sc_food_hook(c, t, S):
    tm = S["times"]
    a, sc = 1.0, 1 + 0.012 * math.sin(t * 2.4)
    block(c, "Until I was *21*,", 104, 540, 330, P["navy"], a, sc, hl=P["gold_text"], maxw=940, max_lines=1)
    block(c, "I wouldn't eat...", 84, 540, 445, P["navy"], a, sc, hl=P["blue"], maxw=940, max_lines=1)
    underline(c, t, 330, 750, 395, 0.15)
    block(c, S["he"], 46, 540, 545, P["blue"], 1, 1, w=700, maxw=940, max_lines=2)
    items = (("hummus", "Hummus", "חומוס", 300, 860), ("cottage", "Cottage", "קוטג'", 780, 860), ("veg", "Fresh vegetables", "ירקות טריים", 540, 1250))
    for k, (key, en, he, x, y) in enumerate(items):
        bob = 8 * math.sin(t * 2.2 + k * 1.7)
        card(c, x, y + bob, 400 if k < 2 else 520, 330)
        place(c, x, y - 30 + bob, 0.95, FOODS[key])
        T(c, en, 44, x, y + 112 + bob, P["navy"], 1, 1, 800, maxw=380 if k < 2 else 480)
        T(c, he, 34, x, y + 160 + bob, P["gold_text"], 1, 1, 700, maxw=380)
        tx = tm.get(key, 0.6 + k)
        u = ramp(t, tx, tx + 0.35)
        if u > 0:
            c.save(); c.translate(x, y - 30 + bob); xmark(c, 0, 0, 92, u, 0.92); c.restore()

# ------------------------------------------------------------------ 2. book card
def book(c, a=1.0):
    W_, H_ = 420, 580
    sa(c, P["navy"], 0.18 * a); rr(c, -W_ / 2 + 14, -H_ / 2 + 22, W_, H_, 16); c.fill()
    box(c, -W_ / 2 + 16, -H_ / 2 + 10, W_, H_ - 4, 12, hx("#F7F3EA"), a, stroke=P["silver"], sw=3)     # page block
    for k in range(4): kline(c, [(W_ / 2 + 4, -H_ / 2 + 30 + k * 4), (W_ / 2 + 4, H_ / 2 - 20)], P["silver"], 2, a * 0.6)
    rr(c, -W_ / 2, -H_ / 2, W_, H_, 16); sa(c, P["navy"], a); c.fill()
    box(c, -W_ / 2, -H_ / 2, 34, H_, 10, hx("#0E2244"), a)
    kline(c, [(-W_ / 2 + 70, -H_ / 2 + 60), (W_ / 2 - 40, -H_ / 2 + 60)], P["gold"], 4, a)
    kline(c, [(-W_ / 2 + 70, H_ / 2 - 60), (W_ / 2 - 40, H_ / 2 - 60)], P["gold"], 4, a)
    T(c, "EMOTIONAL", 52, 17, -120, P["gold2"], a, 1, 900, maxw=330)
    T(c, "INTELLIGENCE", 46, 17, -62, P["gold2"], a, 1, 900, maxw=330)
    diamond(c, 17, 10, 22, P["gold"], a)
    T(c, "Daniel Goleman", 40, 17, 160, P["white"], a, 1, 700, maxw=330)
def sc_book(c, t, S):
    y = head(c, t, S, "Then I read...", S["he"], y=290, sz=82)
    tb = S["t0"] + 0.15; u = ease((t - tb) / 0.7) if t > tb else 0
    bx = 540; by = lerp(1100, 900, u); rot = lerp(0.25, -0.05, u) + 0.02 * math.sin(t * 1.6)
    c.save(); c.translate(bx, by + 10 * math.sin(t * 2)); c.rotate(rot); old = St.a; St.a *= u; book(c); St.a = old; c.restore()
    tm = M(S, "title"); a, sc = PP(t, tm, S)
    block(c, "*Emotional Intelligence*", 64, 540, 1300, P["navy"], a, sc, hl=P["navy"], maxw=940, max_lines=1)
    a2, s2 = PP(t, M(S, "author"), S)
    T(c, "Daniel Goleman (1995)", 52, 540, 1390, P["gold_text"], a2, s2, 800, maxw=900)

# ------------------------------------------------------------------ 3. amygdala
def brain(c, glow=0.0, t=0.0):
    lobes = [(-150, -40, 120), (-40, -110, 120), (90, -90, 125), (170, 10, 100), (60, 50, 120), (-90, 60, 110), (-200, 40, 80)]
    for x, y, r in lobes: circ(c, x, y, r, P["navy"])
    for x, y, r in lobes: circ(c, x, y, r - 9, P["white"])
    box(c, 40, 130, 70, 140, 30, P["navy"]); box(c, 49, 130, 52, 132, 24, P["white"])
    for x, y, r in lobes[3:5]: circ(c, x, y, r - 9, P["white"])
    for pts in ([(-220, -40), (-170, -70), (-120, -30), (-70, -80)], [(-30, -170), (0, -120), (60, -150), (110, -110)],
                [(140, -60), (190, -20), (160, 40)], [(-170, 60), (-120, 20), (-60, 70), (0, 30)], [(30, -30), (80, 0), (130, -40)]):
        kline(c, pts, P["silver"], 7)
    ax, ay = 20, 70
    if glow > 0:
        rg = cairo.RadialGradient(ax, ay, 0, ax, ay, 150); rg.add_color_stop_rgba(0, *P["gold2"][:3], 0.75 * glow * St.a); rg.add_color_stop_rgba(1, *P["gold2"][:3], 0)
        c.set_source(rg); c.arc(ax, ay, 150, 0, 2 * math.pi); c.fill()
    c.save(); c.translate(ax, ay); c.rotate(-0.5); c.scale(42, 24); c.new_sub_path(); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
    g = cairo.LinearGradient(ax - 40, ay - 20, ax + 40, ay + 20); g.add_color_stop_rgb(0, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
    c.set_source(g); c.fill_preserve(); sa(c, hx("#8E6E2A")); c.set_line_width(4); c.stroke()
def sc_amygdala(c, t, S):
    y = head(c, t, S, "The *amygdala*", S["he"], y=290, sz=96)
    tg = M(S, "amyg"); gl = ramp(t, tg, tg + 0.5) * (0.75 + 0.25 * math.sin(t * 5))
    a = fade_in(t, S["t0"] + 0.1, S, 0.35)
    place(c, 520, 860, 1.15, brain, a, 0.0, gl, t)
    ax, ay = 520 + 20 * 1.15, 860 + 70 * 1.15
    ts = M(S, "store"); u = ramp(t, ts - 0.1, ts + 0.4)
    if u > 0:
        kline(c, [(ax, ay + 30), (ax, lerp(ay + 30, 1180, u))], P["gold"], 6)
        a2, s2 = PP(t, ts, S, bounce=1.6)
        pill(c, "storehouse of emotional memory", 50, 540, 1250, P["navy"], P["white"], a2, s2, outline=P["gold"], w=800)
        T(c, "המחסן של הזיכרון הרגשי", 44, 540, 1350, P["gold_text"], a2, s2, 700, maxw=900)
    RD.source(c, t, S)

# ------------------------------------------------------------------ 4. understanding is not enough
def sc_not_enough(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Understanding *wasn't enough*", S["he"], y=290, sz=80)
    # left: understanding (lightbulb) gets an X; right: new good experience gets a check
    for k, (lab, he, key) in enumerate((("Understanding", "הבנה", None), ("A new, *good* experience", "חוויה חדשה וטובה", "new"))):
        x = 290 if k == 0 else 790; tk = S["t0"] + 0.3 if k == 0 else tm["new"]
        a, sc = PP(t, tk, S)
        if a <= 0.01: continue
        old = St.a; St.a *= a; c.save(); c.translate(x, 900); c.scale(sc, sc)
        shadow_box(c, -220, -230, 440, 460, 30, P["card"], stroke=P["silver"] if k == 0 else P["blue"], sw=5)
        if k == 0:
            circ(c, 0, -60, 70, hx("#FFF4CF"), 1, stroke=P["navy"], sw=7); box(c, -30, 10, 60, 50, 10, P["silver"], 1, stroke=P["navy"], sw=6)
            for j in range(5): aa = -math.pi + j * math.pi / 4; kline(c, [(100 * math.cos(aa), -60 + 100 * math.sin(aa)), (120 * math.cos(aa), -60 + 120 * math.sin(aa))], P["gold"], 7)
        else:
            draw_emoji(c, "😋", 0, -40, 160)
        T(c, lab, 42, 0, 130, P["navy"], 1, 1, 800, hl=P["blue"], maxw=400)
        T(c, he, 34, 0, 185, P["gold_text"], 1, 1, 700, maxw=400)
        c.restore(); St.a = old
    xu = ramp(t, S["t0"] + 0.9, S["t0"] + 1.3)
    c.save(); c.translate(290, 840); xmark(c, 0, 0, 80, xu, 0.9); c.restore()
    if t > tm["good"]:
        u = ramp(t, tm["good"], tm["good"] + 0.4); circ(c, 950, 690, 46, P["green"], u); check(c, 950, 692, 54, P["white"], u, u)
    u = ramp(t, tm["new"] - 0.2, tm["new"] + 0.3)
    if u > 0: kline(c, [(520, 900), (lerp(520, 560, u), 900)], P["gold"], 10)

# ------------------------------------------------------------------ 5. bread + tiny cheese + smile + tasty, counter
def sc_bread(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "The *tiniest* bit of cheese", "פרוסת לחם, ונגיעה קטנטנה של גבינה לבנה.", y=290, sz=80)
    a = fade_in(t, tm["bread"] - 0.1, S, 0.3)
    bx, by = 400, 900
    place(c, bx, by, 1.45, bread, a)
    td = tm["dot"]; u = ramp(t, td, td + 0.4)
    if u > 0:   # spoon comes in, touches, leaves a dot
        sx = lerp(820, bx + 20, ease(min(1, u))); sy = lerp(700, by - 30, ease(min(1, u)))
        out = ramp(t, td + 0.6, td + 1.0); sx += 400 * out; sy -= 200 * out
        c.save(); c.translate(sx, sy); c.rotate(-0.6); box(c, 0, -10, 200, 20, 10, P["silver"], 1 - out); ellipse(c, -20, 0, 36, 22); sa(c, P["silver"], 1 - out); c.fill(); c.restore()
        if t > td + 0.35:
            rg = ramp(t, td + 0.35, td + 0.7)
            circ(c, bx + 20, by - 30, 30 * rg, P["gold2"], 0.25 * rg)
            circ(c, bx + 20, by - 30, 9, P["white"], 1, stroke=P["grey"], sw=2)
    ts = tm["smile"]; a2, s2 = PP(t, ts, S, bounce=2.2)
    draw_emoji(c, "😊", 810, 860, 190, a2, s2 * (1 + 0.04 * math.sin(t * 6)))
    tt = tm["tasty"]; a3, s3 = PP(t, tt, S, bounce=2.4)
    if a3 > 0.01:
        c.save(); c.translate(810, 1110); c.scale(s3, s3); old = St.a; St.a *= a3
        shadow_box(c, -190, -80, 380, 160, 40, P["card"], stroke=P["gold"], sw=6)
        sa(c, P["card"]); c.move_to(-30, -80); c.line_to(0, -120); c.line_to(30, -80); c.close_path(); c.fill()
        T(c, "Tasty!", 60, 0, -20, P["navy"], 1, 1, 900, maxw=340); T(c, "טעים לי", 46, 0, 42, P["gold_text"], 1, 1, 800, maxw=340)
        St.a = old; c.restore()
    # counter: x1 on 'tasty', then +1 every 0.55 s from 'Again'
    if t > tt:
        n = 1
        if t > tm["again"]: n = 2 + int((t - tm["again"]) / 0.5)
        n = min(n, 30); pulse = 1 + 0.15 * max(0, 1 - ((t - tm["again"]) % 0.5) / 0.2) if t > tm["again"] else 1
        a4, s4 = PP(t, tt + 0.2, S)
        pill(c, f"x{n}", 64, 540, 1330, P["navy"], P["white"], a4, s4 * pulse, outline=P["gold"])
        T(c, "שוב ושוב ושוב", 40, 540, 1430, P["blue"], fade_in(t, tm["again"], S), 1, 700)

# ------------------------------------------------------------------ 6. cottage cups growing
def sc_cottage(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Then cottage. *A little more* every day.", S["he"], y=290, sz=76)
    t1 = S["t1"]; tl = tm["more"]
    for k in range(4):
        tk = lerp(tm["cottage"] + 0.1, max(tl + 0.9, tm["cottage"] + 1.6), k / 3)
        a, sc = PP(t, tk, S, bounce=1.6)
        s = 0.55 + 0.22 * k; x = 170 + k * 250 - 10 * k; yy = 1180 - 50 * s
        place(c, x, yy - 40 * s, s * sc, cottage, a, 0.0, 0.3 + 0.5 * k)
        T(c, f"Day {k + 1}", 42, x, 1290, P["navy"], a, 1, 800, maxw=230)
        T(c, f"יום {k + 1}", 34, x, 1345, P["gold_text"], a, 1, 700, maxw=230)
    u = ramp(t, tm["more"], tm["more"] + 1.4)
    if u > 0: c.save(); kline(c, [(110, 1420), (lerp(110, 980, u), 1420)], P["gold"], 8); c.restore()

# ------------------------------------------------------------------ 7. tomatoes: way too much
def sc_tomato(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Then tomatoes.", S["he"], y=290, sz=88)
    tw = tm["too"]; a, sc = PP(t, S["t0"] + 0.25, S)
    wob = 0.0; grow = 1.0
    if t > tw: k = t - tw; wob = 0.18 * math.sin(k * 14) * math.exp(-0.6 * k) + 0.05 * math.sin(k * 5); grow = 1 + 0.25 * ramp(t, tw, tw + 0.4)
    place(c, 360, 900, 2.0 * sc * grow, tomato, a, wob)
    a2, s2 = PP(t, tw, S, bounce=2.4)
    if a2 > 0.01:
        c.save(); c.translate(540, 1300); c.rotate(-0.05 + wob * 0.3); pill(c, "Way too much", 66, 0, 0, P["red"], P["white"], a2, s2); c.restore()
    ta = tm["threw"]; a3, s3 = PP(t, ta - 0.2, S, bounce=2.0)
    qx = 800 + 6 * math.sin(t * 22) * ramp(t, ta, ta + 0.3)
    draw_emoji(c, "🤢", qx, 860, 230, a3, s3)
    T(c, "I almost threw up", 40, 800, 1020, P["navy"], a3, s3, 800, maxw=400)

# ------------------------------------------------------------------ 8. broken down + ridiculous
def sc_breakdown(c, t, S):
    tm = S["times"]; tr = tm["ridic"]
    al1 = 1 - ramp(t, tr - 0.15, tr + 0.15); al2 = ramp(t, tr - 0.1, tr + 0.25)
    if al1 > 0.01:
        old = St.a; St.a *= al1
        y = head(c, t, S, "So I *broke it down*", "אז פירקתי את זה: בלי גרעינים, חתיכות קטנטנות על לחם.", y=290, sz=88)
        # step 1: halved tomato, seeds leave
        ts = tm["seeds"]; a, sc = PP(t, S["t0"] + 0.3, S)
        sd = 1 - ramp(t, ts + 0.2, ts + 0.8)
        place(c, 280, 820, 1.25 * sc, tomato_half, a, 0.0, sd)
        if t > ts:
            for k in range(10):
                u = ramp(t, ts + 0.05 * k, ts + 0.05 * k + 0.7); ang = k * 0.63
                circ(c, 280 + 260 * u * math.cos(ang) * 0.6 + 140 * u, 820 + 200 * u * math.sin(ang) * 0.5 - 120 * u + 400 * u * u, 6, hx("#F7B54F"), 1 - u)
        T(c, "1. Seeds out", 44, 280, 990, P["navy"], *PP(t, ts, S), 800, maxw=440)
        T(c, "בלי גרעינים", 34, 280, 1040, P["gold_text"], *PP(t, ts + 0.1, S), 700, maxw=440)
        # step 2: tiny pieces on bread
        tp = tm["tiny"]; a2, s2 = PP(t, tp - 0.2, S)
        place(c, 790, 830, 1.05 * s2, bread, a2)
        for k in range(7):
            u = ramp(t, tp + 0.08 * k, tp + 0.08 * k + 0.3)
            px, py = 790 + (-70 + (k % 4) * 46 + (k // 4) * 22), 820 + (k // 4) * 52 - 20
            box(c, px - 9, py - 9 - 40 * (1 - u), 18, 18, 4, TOM, u)
        T(c, "2. Tiny pieces", 44, 790, 990, P["navy"], *PP(t, tp, S), 800, maxw=440)
        T(c, "חתיכות קטנטנות", 34, 790, 1040, P["gold_text"], *PP(t, tp + 0.1, S), 700, maxw=440)
        u = ramp(t, tp, tp + 0.4)
        if u > 0: kline(c, [(470, 830), (lerp(470, 600, u), 830)], P["gold"], 8)
        St.a = old
    if al2 > 0.01:
        old = St.a; St.a *= al2
        a, sc = PP(t, tr, S)
        block(c, "Ridiculous for a grown man.", 80, 540, 470, P["navy"], a, sc, hl=P["blue"], maxw=940, max_lines=2)
        T(c, "מגוחך לגבר בוגר.", 46, 540, 600, P["blue"], a, sc, 700)
        tb = tm["care"]; a2, s2 = PP(t, tb, S, bounce=1.8)
        gl = 0.75 + 0.25 * math.sin(t * 5)
        place(c, 520, 860, 0.78 * s2, brain, a2, 0.0, gl * a2, t)
        block(c, "But the *amygdala* doesn't care.", 74, 540, 1250, P["navy"], a2, s2, hl=P["gold_text"], maxw=940, max_lines=2)
        T(c, "אבל לאמיגדלה לא אכפת.", 46, 540, 1400, P["blue"], a2, s2, 700)
        St.a = old

# ------------------------------------------------------------------ 9. today: full plate
def sc_plate(c, t, S):
    y = head(c, t, S, "Today, I eat *all of it.*", S["he"], y=320, sz=92)
    a, sc = PP(t, S["t0"] + 0.2, S, bounce=1.5)
    cy = 1030
    place(c, 540, cy, 1.25 * sc, plate, a)
    parts = ((hummus, -190, -20, 0.95), (cottage, 200, -40, 0.75), (veg, 10, 30, 0.95), (bread, 220, 70, 0.45))
    for k, (fn, dx, dy, s) in enumerate(parts):
        a2, s2 = PP(t, S["t0"] + 0.35 + 0.15 * k, S, bounce=2.0)
        place(c, 540 + dx * 1.25, cy + dy * 1.25 - 30, s * s2, fn, a2)
    u = ramp(t, S["t0"] + 1.0, S["t0"] + 1.4)
    if u > 0: circ(c, 900, 760, 60, P["green"], u); check(c, 900, 762, 70, P["white"], u, u)

# ------------------------------------------------------------------ 10-11. hourly emotion check + timeline
EMO = (("Frustrated", "מתוסכל"), ("Happy", "שמח"), ("Bored", "משועמם"), ("Angry", "כועס"))
def clock(c, x, y, r, t, t0):
    sa(c, P["navy"], 0.12); circ(c, x + 4, y + 12, r, P["navy"], 0.12)
    circ(c, x, y, r, P["card"], 1, stroke=P["navy"], sw=10)
    for k in range(12):
        aa = k * math.pi / 6; r0 = r - (30 if k % 3 == 0 else 20)
        kline(c, [(x + r0 * math.sin(aa), y - r0 * math.cos(aa)), (x + (r - 12) * math.sin(aa), y - (r - 12) * math.cos(aa))], P["navy"] if k % 3 == 0 else P["silver"], 7 if k % 3 == 0 else 5)
    # minute hand sweeps a full turn every 1.4 s and snaps to 12; hour hand jumps an hour per turn
    el = max(0, t - t0); turns = el / 1.4; frac = turns % 1; hrs = 9 + int(turns)
    snap = ease(min(1, frac / 0.85)); mang = 2 * math.pi * snap
    hang = (hrs % 12 + snap) * math.pi / 6
    kline(c, [(x, y), (x + r * 0.5 * math.sin(hang), y - r * 0.5 * math.cos(hang))], P["navy"], 14)
    kline(c, [(x, y), (x + r * 0.78 * math.sin(mang), y - r * 0.78 * math.cos(mang))], P["blue"], 9)
    circ(c, x, y, 12, P["gold"])
    return hrs + (1 if snap > 0.98 else 0)
def sc_hourly(c, t, S):
    tm = S["times"]; t11 = tm["notice"] - 0.1
    phases = [(S["t0"], "Every round hour: *stop.*", "כל שעה עגולה: עוצרים. נותנים שם לרגש. ושואלים מה גרם לו."),
              (t11, "After a few days, *you notice*", "אחרי כמה ימים שמים לב: הוא צעק עליי בבוקר, בגלל זה אני כועס עכשיו.")]
    for k, (pa, en, he) in enumerate(phases):
        pb = phases[k + 1][0] if k + 1 < len(phases) else None
        al = ramp(t, pa, pa + 0.25) * (1 - ramp(t, pb, pb + 0.25) if pb else 1)
        if al <= 0.01: continue
        old = St.a; St.a *= al
        h = block_h(en, 76, 900, 940, 2); block(c, en, 76, 540, 290 + h / 2, P["navy"], 1, 1, hl=P["blue"], maxw=940, max_lines=2)
        block(c, he, 42, 540, 290 + h + 56, P["blue"], 1, 1, w=700, maxw=940, max_lines=2)
        St.a = old
    # part A (line 10): clock + emotion card + "What caused it?"
    alA = 1 - ramp(t, t11, t11 + 0.3)
    if alA > 0.01:
        old = St.a; St.a *= alA
        a, sc = PP(t, S["t0"] + 0.2, S)
        sc = max(sc, 0.05); c.save(); c.translate(300, 820); c.scale(sc, sc); c.translate(-300, -820); St.a *= a; hr = clock(c, 300, 820, 190, t, S["t0"] + 0.2); St.a = old; c.restore()
        T(c, f"{(hr - 1) % 12 + 1}:00", 50, 300, 1060, P["navy"], a, 1, 900)
        tn = tm["name"]; a2, s2 = PP(t, tn, S, bounce=1.8)
        if a2 > 0.01:
            k = int(max(0, t - tn) / 1.4) % len(EMO); en, he = EMO[k]
            c.save(); c.translate(770, 760); c.scale(s2, s2); old2 = St.a; St.a *= a2
            shadow_box(c, -200, -150, 400, 300, 30, P["card"], stroke=P["blue"], sw=5)
            T(c, "I feel:", 40, 0, -90, P["grey"], 1, 1, 700)
            T(c, en, 62, 0, -10, P["navy"], 1, 1, 900, maxw=360); T(c, he, 44, 0, 70, P["gold_text"], 1, 1, 700, maxw=360)
            St.a = old2; c.restore()
        tq = tm["cause"]; a3, s3 = PP(t, tq, S, bounce=2.2)
        pill(c, "What caused it?", 60, 540, 1230, P["navy"], P["white"], a3, s3, outline=P["gold"])
        T(c, "מה גרם לזה?", 44, 540, 1330, P["gold_text"], a3, s3, 700)
        St.a = old
    # part B (line 11): timeline 9:00 yelled -> 19:00 angry, faster recovery
    if t > t11:
        old = St.a; St.a *= ramp(t, t11, t11 + 0.3)
        ty = 920; u = ramp(t, t11 + 0.1, t11 + 0.9)
        kline(c, [(120, ty), (lerp(120, 960, u), ty)], P["navy"], 8)
        for k in range(11):
            xx = 140 + k * 80; aa = ramp(t, t11 + 0.1 + 0.06 * k, t11 + 0.25 + 0.06 * k)
            kline(c, [(xx, ty - 14), (xx, ty + 14)], P["silver"], 4, aa)
        ty1 = tm["yelled"]; a1, s1 = PP(t, ty1, S, bounce=1.8)
        circ(c, 140, ty, 20, P["red"], a1)
        if a1 > 0.01:
          c.save(); c.translate(250, ty - 200); c.scale(s1, s1); old2 = St.a; St.a *= a1
          shadow_box(c, -170, -95, 340, 190, 26, P["card"], stroke=P["red"], sw=5)
          T(c, "9:00", 46, 0, -48, P["red"], 1, 1, 900); T(c, "He yelled at me", 38, 0, 10, P["navy"], 1, 1, 800, maxw=310); T(c, "הוא צעק עליי", 32, 0, 58, P["gold_text"], 1, 1, 700, maxw=310)
          St.a = old2; c.restore()
        tg = tm["angry"]; a2, s2 = PP(t, tg, S, bounce=1.8)
        circ(c, 940, ty, 20, P["amber"], a2)
        if a2 > 0.01:
          c.save(); c.translate(830, ty + 200); c.scale(s2, s2); old2 = St.a; St.a *= a2
          shadow_box(c, -170, -95, 340, 190, 26, P["card"], stroke=P["amber"], sw=5)
          T(c, "19:00", 46, 0, -48, P["amber"], 1, 1, 900); T(c, "Angry", 42, 0, 10, P["navy"], 1, 1, 800, maxw=310); T(c, "כועס", 34, 0, 58, P["gold_text"], 1, 1, 700, maxw=310)
          St.a = old2; c.restore()
        tw = tm["why"]; u2 = ramp(t, tw, tw + 0.7)
        if u2 > 0:   # gold arc linking cause to feeling
            c.save(); sa(c, P["gold"]); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND)
            N = 40; pts = [(lerp(140, 940, i / N), ty - 40 - 260 * math.sin(math.pi * i / N)) for i in range(N + 1)]
            m = max(2, int(N * u2) + 1); c.move_to(*pts[0])
            for p in pts[1:m]: c.line_to(*p)
            c.stroke(); c.restore()
            if u2 >= 1: kline(c, [(940, ty - 40), (918, ty - 72)], P["gold"], 9); kline(c, [(940, ty - 40), (962, ty - 72)], P["gold"], 9)
            a4, s4 = PP(t, tw + 0.3, S); pill(c, "10 hours later", 34, 540, ty - 330, P["gold"], P["white"], a4, s4, w=800)
        tf = tm["faster"]; a5, s5 = PP(t, tf, S, bounce=2.2)
        pill(c, "Over it *faster*", 60, 540, 1360, P["green"], P["white"], a5, s5)
        T(c, "ומתגברים מהר יותר", 42, 540, 1455, P["gold_text"], a5, s5, 700)
        St.a = old

# ------------------------------------------------------------------ 12. in my view
HEADSHOT = os.path.join(HERE, "photos", "noam_headshot.jpg")
def sc_view(c, t, S):
    tm = S["times"]
    view_pill(c, t, S, y=290, tk=S["t0"] + 0.05)
    a = fade_in(t, S["t0"] + 0.15, S, 0.35); r = 150; x, y = 540, 530
    if a > 0.01 and os.path.exists(HEADSHOT):
        s = image_surf(HEADSHOT, 2 * r, 2 * r, radius=r)
        sa(c, P["navy"], 0.14 * a); c.arc(x + 4, y + 14, r + 8, 0, 2 * math.pi); c.fill()
        c.save(); c.translate(x - r, y - r); c.set_source_surface(s, 0, 0); c.paint_with_alpha(a * St.a); c.restore()
        c.new_sub_path(); c.arc(x, y, r, 0, 2 * math.pi); sa(c, P["gold"], a); c.set_line_width(8); c.stroke()
    a1, s1 = PP(t, S["t0"] + 0.3, S)
    block(c, "You don't *think* your way into feeling different.", 70, 540, 860, P["navy"], a1, s1, hl=P["red"], maxw=940, max_lines=3)
    tp = tm["practice"]; a2, s2 = PP(t, tp, S, bounce=1.8)
    block(c, "You *practice* your way there.", 84, 540, 1110, P["navy"], a2, s2, hl=P["blue"], maxw=940, max_lines=2)
    hb = block_h("You *practice* your way there.", 84, 900, 940, 2)
    underline(c, t, 330, 750, 1110 + hb / 2 + 18, tp + 0.2)
    he_line(c, t, S, S["he"], 1110 + hb / 2 + 120, tp + 0.2, sz=46)

# ------------------------------------------------------------------ 13. CTA (overrides the built-in so the pill reads "Tell me in the comments")
def sc_cta(c, t, S):
    t0 = S["t0"]; tk = S["times"]["keyword"]
    a, s = PP(t, t0 + 0.05, S)
    block(c, S["en"], 86, 540, 420, P["navy"], a, s * (1 + 0.01 * math.sin(t * 2.4)), hl=P["gold_text"], maxw=940, max_lines=3)
    a, s = PP(t, t0 + 0.2, S); block(c, S["he"], 54, 540, 610, P["blue"], a, s, w=700, maxw=940, max_lines=2)
    em = S.get("emojis") or []
    for k, e in enumerate(em):
        a3, s3 = PP(t, t0 + 0.35 + 0.12 * k, S, bounce=2.2)
        draw_emoji(c, e, 540 + (k - (len(em) - 1) / 2) * 190, 800 + 10 * math.sin(t * 3 + k), 140, a3, s3)
    a, s = PP(t, tk - 0.05, S, bounce=2.4)
    if a > 0.01:
        f = RD.font(64, 900); txt = S.get("pill", "Tell me in the comments"); pw = f.getlength(txt) + 110; ph = 64 * 1.7; yy = 1030
        c.save(); c.translate(540, yy); c.scale(s, s); old = St.a; St.a *= a
        sa(c, P["navy"], 0.18); rr(c, -pw / 2, -ph / 2 + 12, pw, ph, ph / 2); c.fill()
        g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *P["gold"][:3]); g.add_color_stop_rgb(0.5, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
        rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
        St.a = old; c.restore()
        T(c, txt, 64, 540, yy + 4, P["navy"], a, s, 900, maxw=900)
        draw_emoji(c, "👇", 540, 1200 + 16 * math.sin(t * 7), 130, fade_in(t, tk + 0.1, S, 0.2))
        if S.get("pill_he"): T(c, S["pill_he"], 50, 540, 1330, P["blue"], *PP(t, tk + 0.15, S), 700)
    acct = S.get("follow")
    if acct:
        a, s = PP(t, tk + 0.4, S); T(c, acct, 54, 540, 1430, P["navy"], a, s, 800, hl=P["gold_text"])
