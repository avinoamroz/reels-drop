"""Goleman v3 (27 Oct 2026): the v2 food-only scenes, plus Noam's own gradual steps (bread with a touch of white cheese,
cottage, tomatoes with the seeds out), "Today, I eat all of it" without the tiny-taste caption, and the closing question
with no comment keyword (FOOD is not live in ManyChat yet)."""
import math, os, sys
sys.path.insert(0, "/home/claude/goleman")
import goleman_v2_scenes as V
from goleman_v2_scenes import *          # sc_food_hook, sc_no_list, sc_book, sc_alarm, sc_view, sc_corrective, sc_rules, sc_ladder, sc_back
import goleman_scenes as G
import render as RD
from render import P, T, block, block_h, pill, PP
from kit import St, sa, rr, circ, box, ramp

def sc_story(c, t, S):
    tm = S["times"]
    y = G.head(c, t, S, "How *I* did it", S.get("he"), y=300, sz=92)
    rows = (("bread", "Bread + the *tiniest* bit of white cheese", "לחם עם טיפה קטנטנה של גבינה לבנה", G.bread, 0.62, ()),
            ("cottage", "Then *cottage*", "אחר כך קוטג'", G.cottage, 0.85, (0.6,)),
            ("tomato", "Then tomatoes, *seeds out*, tiny pieces", "ואז עגבניות, בלי גרעינים, בחתיכות קטנות", G.tomato_half, 0.85, (0.0,)))
    y0 = 560
    for k, (key, en, he, fn, sc_, args) in enumerate(rows):
        tk = tm.get(key, S["t0"] + 0.4 + k); a, s = PP(t, tk, S, bounce=1.6)
        if a <= 0.01: continue
        yy = y0 + k * 300
        G.card(c, 540, yy + 120, 920, 270, a, s)
        G.place(c, 220, yy + 120, sc_ * s, fn, a, 0.0, *args)
        block(c, en, 50, 640, yy + 95, P["navy"], a, s, hl=P["gold_text"], maxw=560, max_lines=2)
        T(c, he, 34, 640, yy + 185, P["blue"], a, s, 700, maxw=560)
        if k: 
            a2 = ramp(t, tk - 0.1, tk + 0.2)
            T(c, "STEP " + str(k + 1), 28, 220, yy + 228, P["gold_text"], a2, 1, 800)
        else: T(c, "STEP 1", 28, 220, yy + 228, P["gold_text"], a, 1, 800)

def sc_plate3(c, t, S):
    y = G.head(c, t, S, "Today, I eat *all of it.*", S["he"], y=320, sz=96)
    a, sc = PP(t, S["t0"] + 0.2, S, bounce=1.5); cy = 1000
    G.place(c, 540, cy, 1.3 * sc, G.plate, a)
    parts = ((V.salad, -165, -25, 1.15), (V.veggies, 165, -30, 1.05), (V.mayo, -10, -55, 0.62), (V.mustard, 75, -60, 0.58), (V.drumstick, 175, 60, 0.7), (V.rice, -150, 70, 0.7))
    for k, (fn, dx, dy, s) in enumerate(parts):
        a2, s2 = PP(t, S["t0"] + 0.35 + 0.15 * k, S, bounce=2.0)
        G.place(c, 540 + dx * 1.3, cy + dy * 1.3 - 30, s * s2, fn, a2)
    V.mark_check(c, t, 930, 740, S["t0"] + 1.2, 56)

def sc_ask(c, t, S):
    t0 = S["t0"]; br = 1 + 0.01 * math.sin(t * 2.4)
    a, s = PP(t, t0 + 0.05, S)
    block(c, S["en"], 84, 540, 470, P["navy"], a, s * br, hl=P["gold_text"], maxw=940, max_lines=3)
    a, s = PP(t, t0 + 0.2, S); block(c, S["he"], 52, 540, 690, P["blue"], a, s, w=700, maxw=940, max_lines=2)
    for k, fn in enumerate((G.tomato, V.mayo, V.mustard, V.salad)):
        a3, s3 = PP(t, t0 + 0.35 + 0.12 * k, S, bounce=2.2)
        G.place(c, 540 + (k - 1.5) * 220, 940 + 10 * math.sin(t * 3 + k), (0.62 if fn is G.tomato else 0.55) * s3, fn, a3)
    a, s = PP(t, t0 + 0.7, S)
    T(c, "Tell me in the comments", 54, 540, 1170, P["navy"], a, s, 800)
    T(c, "כתבו לי בתגובות", 42, 540, 1240, P["blue"], a, s, 700)
    T(c, "Follow *@noamroz__*", 48, 540, 1340, P["navy"], a, s, 800, hl=P["gold_text"])
