"""goleman v4 (29 Oct 2026): v3 scenes + the 'wouldn't eat' grid now has 6 cards (white cheese and cottage added, from Noam's own story line)."""
import math, os, sys
sys.path.insert(0, "/home/claude/fixes_1027b/gol"); sys.path.insert(0, "/home/claude/goleman")
from goleman_v3_scenes import *
import goleman_v3_scenes as V3
import goleman_v2_scenes as V
import goleman_scenes as G
from render import P, T, block, PP
from kit import St, ramp

def sc_no_list(c, t, S):
    tm = S["times"]; tn = tm["night"]
    al1 = 1 - ramp(t, tn - 0.15, tn + 0.15); al2 = ramp(t, tn - 0.1, tn + 0.25)
    if al1 > 0.01:
        old = St.a; St.a *= al1
        V.head(c, t, S, "What I *wouldn't* eat", "בלי ירקות טריים, חוץ ממלפפון. בלי גבינה לבנה וקוטג'. בלי רטבים, מיונז או חרדל.", y=290, sz=86)
        items = (("veggies", "Fresh veggies", "ירקות טריים", "veg", False), ("cuke", "Except cucumber", "חוץ ממלפפון", "cuke", True),
                 ("cheese", "White cheese, cottage", "גבינה לבנה, קוטג'", "cheese", False),
                 ("ketchup", "Sauces", "רטבים", "sauce", False), ("mayo", "Mayo", "מיונז", "mayo", False), ("mustard", "Mustard", "חרדל", "mustard", False))
        pos = ((200, 760), (540, 760), (880, 760), (200, 1130), (540, 1130), (880, 1130))
        for k, ((key, en, he, mk, ok), (x, yy)) in enumerate(zip(items, pos)):
            tk = tm[mk]; a, s = PP(t, tk - 0.25, S, bounce=1.6)
            if a <= 0.01: continue
            V.card(c, x, yy, 310, 330, a, s, stroke=P["green"] if ok else None)
            if key == "cheese": G.place(c, x, yy - 40, 0.62 * s, G.cottage, a, 0.0, 0.6)
            else: V.place(c, x, yy - 40, 0.72 * s, V.ICON[key], a)
            T(c, en, 36 if key == "cheese" else 38, x, yy + 92, P["green"] if ok else P["navy"], a, s, 800, maxw=280)
            T(c, he, 30, x, yy + 136, P["gold_text"], a, s, 700, maxw=280)
            if ok: V.mark_check(c, t, x + 112, yy - 128, tk + 0.1, 40)
            else:
                u = ramp(t, tk + 0.1, tk + 0.45)
                if u > 0: c.save(); c.translate(x, yy - 40); V.xmark(c, 0, 0, 70, u, 0.92); c.restore()
        St.a = old
    if al2 > 0.01:
        old = St.a; St.a *= al2
        a, sc = PP(t, tn, S)
        block(c, "A *nightmare* for other families to host", 80, 540, 420, P["navy"], a, sc, hl=P["red"], maxw=940, max_lines=3)
        T(c, "הייתי סיוט למשפחות שאירחו אותי.", 46, 540, 600, P["blue"], a, sc, 700)
        a2, s2 = PP(t, tn + 0.2, S, bounce=1.5); s2 = max(s2, 0.02)
        c.save(); c.translate(540, 960); c.scale(s2, s2); old2 = St.a; St.a *= a2
        V.box(c, -470, 80, 940, 40, 20, V.hx("#C9D3DF")); V.box(c, -470, 80, 940, 14, 7, V.hx("#AEB9C8"))
        for k, (fn, x, s_) in enumerate(((V.salad, -360, 0.95), (V.mayo, -175, 0.8), (V.ketchup, -15, 0.78), (V.veggies, 170, 0.9), (V.mustard, 365, 0.78))):
            c.save(); c.translate(x, -20 + 6 * math.sin(t * 2 + k)); c.scale(s_, s_); fn(c); c.restore()
        St.a = old2; c.restore()
        a3, s3 = PP(t, tn + 0.6, S, bounce=2.0)
        if a3 > 0.01:
            c.save(); c.translate(540, 1320); c.scale(s3, s3); old2 = St.a; St.a *= a3
            V.shadow_box(c, -300, -110, 600, 220, 30, P["card"], stroke=P["red"], sw=5)
            T(c, "Me:", 40, -200, -40, P["grey"], 1, 1, 700)
            T(c, "Just rice, please.", 50, 40, -40, P["navy"], 1, 1, 900, maxw=400)
            T(c, "רק אורז, תודה.", 40, 0, 40, P["gold_text"], 1, 1, 700, maxw=540)
            St.a = old2; c.restore()
        St.a = old
