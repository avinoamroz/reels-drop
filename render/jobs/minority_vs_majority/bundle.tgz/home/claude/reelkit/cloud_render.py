#!/usr/bin/env python3
"""Render reels in parallel on GitHub Actions (avinoamroz/reels-drop, workflow render.yml).

Each job runs on its own 4-core GitHub machine (up to 20 at once). The machine
recreates the /home/claude paths the build needs, runs the command as root,
and pushes <id>.mp4 to the repo root plus render/out/<id>_540.mp4 (preview).

  # 1) send one or more jobs (one push = one parallel batch)
  python3 cloud_render.py send --id pop_stocks \
      --cmd "python3 /home/claude/pop_stocks/build.py" \
      --out /home/claude/pop_stocks/final.mp4 \
      --entry /home/claude/pop_stocks/build.py [--add /home/claude/pop_stocks/vo.wav ...]
  #    or a batch file: send --batch jobs.json  ([{id,cmd,out,entry:[..],add:[..]}])
  # 2) wait and pull results into the local repo
  python3 cloud_render.py wait pop_stocks other_id [--timeout 3600]

Packing: every --entry/--add path is packed; .py files are scanned for absolute
/home/claude/... (and /root/.fonts) paths, recursively. A path with {placeholders}
packs its folder. Folders are packed without *.mp4, frames, snaps, qa, caches.
Use --add for anything a script builds a path to at runtime. No secrets: the
repo is PUBLIC, so never pack keys, tokens, or data store values.
The command must render only (no TTS / Make calls, no ASR); do those locally first.
"""
import argparse, json, os, re, subprocess, sys, tarfile, time, io

REPO = "/home/claude/reels-drop"
ALWAYS = ["/root/.fonts", "/home/claude/vid/fonts", "/usr/share/fonts/truetype/google-fonts"]
SKIP_DIRS = {"__pycache__", "snaps", "qa", "frames", "frames_hq", "tmp", ".git", "out"}
SKIP_EXT = (".mp4", ".mov", ".mkv", ".log")
PAT = re.compile(r"(/home/claude/[^\s'\"\)\],;]+|/root/\.fonts[^\s'\"\)\],;]*)")
LIMIT = 90 * 1024 * 1024
BAD = re.compile(r"(sk_car|cartesia_api|api[_-]?key\s*=\s*['\"][A-Za-z0-9]{16,}|94072)", re.I)


def git(*a, check=True):
    return subprocess.run(["git", "-C", REPO, *a], check=check, capture_output=True, text=True)


def collect(entries, adds):
    files, seen, todo = set(), set(), list(entries) + list(adds) + ALWAYS
    while todo:
        p = todo.pop()
        if "{" in p:
            p = p[:p.index("{")]
            p = p if p.endswith("/") else os.path.dirname(p)
        p = p.rstrip("/.") or p
        if p in seen or not os.path.exists(p):
            continue
        seen.add(p)
        if os.path.isdir(p):
            if p in ("/home/claude", "/root"):
                continue
            for root, dirs, fs in os.walk(p):
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith("frames")]
                for f in fs:
                    if not f.endswith(SKIP_EXT):
                        files.add(os.path.join(root, f))
        else:
            files.add(p)
            if p.endswith(".py"):
                src = open(p, errors="ignore").read()
                todo += PAT.findall(src)
    return sorted(files)


def bundle(files, dest):
    tot = 0
    with tarfile.open(dest, "w:gz") as t:
        for f in files:
            if f.endswith(".py") and not f.endswith("cloud_render.py") and BAD.search(open(f, errors="ignore").read()):
                sys.exit(f"refusing: {f} looks like it holds a secret")
            tot += os.path.getsize(f)
            t.add(f, arcname=f.lstrip("/"))
    size = os.path.getsize(dest)
    if size > LIMIT:
        sys.exit(f"bundle {dest} is {size>>20} MB (>90). Trim with explicit --add paths.")
    return size, tot


def send(jobs):
    git("pull", "-q", "--rebase", "--autostash")
    added = []
    for j in jobs:
        jd = os.path.join(REPO, "render/jobs", j["id"])
        os.makedirs(jd, exist_ok=True)
        files = collect(j.get("entry", []), j.get("add", []))
        size, raw = bundle(files, os.path.join(jd, "bundle.tgz"))
        meta = {"id": j["id"], "cmd": j["cmd"], "out": j["out"], "sent": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "nfiles": len(files)}
        json.dump(meta, open(os.path.join(jd, "job.json"), "w"), indent=1)
        done = os.path.join(REPO, "render/done", j["id"] + ".json")
        if os.path.exists(done):
            git("rm", "-q", "--cached", done, check=False); os.remove(done)
        added += [os.path.relpath(jd, REPO)]
        print(f"{j['id']}: {len(files)} files, {size>>20} MB packed")
    git("add", *added)
    git("add", "-u", "render/done", check=False)
    msg = "Render jobs: " + " ".join(j["id"] for j in jobs) + "\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_01D8gF2iekadnzKcdJnCPGVX"
    git("-c", "user.name=Noam Roz", "-c", "user.email=noam@expressenglish.co.il", "commit", "-q", "-m", msg)
    for i in range(5):
        r = git("push", "-q", check=False)
        if r.returncode == 0:
            print("pushed; GitHub is rendering. Run: cloud_render.py wait " + " ".join(j["id"] for j in jobs)); return
        git("pull", "-q", "--rebase", "--autostash", check=False); time.sleep(5)
    sys.exit("push failed: " + r.stderr)


def wait(ids, timeout):
    t0, left = time.time(), set(ids)
    while left and time.time() - t0 < timeout:
        git("pull", "-q", "--rebase", "--autostash", check=False)
        for i in sorted(left):
            d = os.path.join(REPO, "render/done", i + ".json")
            if os.path.exists(d):
                r = json.load(open(d)); left.discard(i)
                if r.get("ok"):
                    print(f"DONE {i}: {REPO}/{i}.mp4  preview {REPO}/render/out/{i}_540.mp4  ({r.get('secs')} s render)")
                else:
                    print(f"FAILED {i} rc={r.get('rc')} run https://github.com/avinoamroz/reels-drop/actions/runs/{r.get('run')}\n{r.get('log','')[-1500:]}")
        if left:
            time.sleep(30)
    if left:
        print("still waiting:", " ".join(sorted(left)), "see https://github.com/avinoamroz/reels-drop/actions")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="c", required=True)
    s = sp.add_parser("send"); s.add_argument("--id"); s.add_argument("--cmd"); s.add_argument("--out")
    s.add_argument("--entry", nargs="*", default=[]); s.add_argument("--add", nargs="*", default=[]); s.add_argument("--batch")
    w = sp.add_parser("wait"); w.add_argument("ids", nargs="+"); w.add_argument("--timeout", type=int, default=3600)
    a = ap.parse_args()
    if a.c == "send":
        send(json.load(open(a.batch)) if a.batch else [{"id": a.id, "cmd": a.cmd, "out": a.out, "entry": a.entry, "add": a.add}])
    else:
        wait(a.ids, a.timeout)
