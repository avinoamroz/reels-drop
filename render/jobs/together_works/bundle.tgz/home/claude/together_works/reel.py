"""together_works: "Can Jews and Arabs be friends?" (@noamroz__, English, 1 Nov 2026).
Apple keynote look and helpers from real_apartheid/reel.py (series_more/safe_p2_v3 engine: near-black stage, one warm glow, Inter,
cubic fades with blur-in, rolling numbers) with Ken Burns photo panels (Wikimedia Commons, credited at 36 px).
Beats: hook over Jaffa, Haifa (Holiday of Holidays), Israeli hospitals, Hand in Hand (Shalom / Salaam as native clips),
Arab engineers in high-tech, Youssef Ziadna on 7 Oct, the turn (it works, but it is not automatic), patience / openness / kindness,
then the lead-in at the hook place and a 0.45 s cross-fade into the exact frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py (silent video to work/silent.mp4)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/together_works"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing from the narration (work/words.json)
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):     # index of the first word in line li that starts with `word`
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(re.sub(r"\W", "", word).lower()): return i
    raise KeyError((li, word))
NL = max(LW) + 1
T_END = round(E(NL - 1) + 0.5, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = "#060608"; GLOW_COL = "#E8C77E"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
ISR_GOLD = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

# stage: one wide soft glow
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# text rasters at 2x, composited with sub-pixel placement, scale and blur (from engine_v3)
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 500: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
def capof(fk, size): return raster("H", fk, size)[3]
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0):
    """y_cap_mid: vertical middle of the capitals"""
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, 540, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)

# ------------------------------------------------------------------ photos (Ken Burns in a rounded panel)
PH = {  # key: (file, focus x, focus y, credit at 36 px)
}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
def photo(canvas, t, k, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35):
    a = seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout)) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC)
    sc = 0.97 + 0.03 * seg(t, t0, t0 + ain)
    m = rmask(w, h, 34); lay = crop.convert("RGBA"); lay.putalpha(m.point(lambda v: int(v * a)))
    if sc < 0.999:
        nw, nh = int(w * sc), int(h * sc); lay = lay.resize((nw, nh), Image.BICUBIC); x0 += (w - nw) // 2; y0 += (h - nh) // 2
    canvas.alpha_composite(lay, (int(x0), int(y0)))
def credit(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.45)

# ------------------------------------------------------------------ counters
def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def num_text(canvas, t, s, y, size, t0, t1, color=GOLD, ain=0.4):
    text(canvas, t, s, y, size, t0, t1, fk="db", color=color, tab=True, ain=ain)

# ------------------------------------------------------------------ flat layers: subtitles, sources
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)

# ================================================================== together_works
T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45     # 20 bars of the bed at 100 BPM
GLOW_COL = "#F0C27A"; GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
PH.update({
 "jaf": ("jaf2.jpg", 0.50, 0.55, "Jaffa. Photo: Shlomo Roded, PikiWiki Israel, CC BY 2.5"),
 "hol": ("hol1.jpg", 0.45, 0.45, "Holiday of Holidays, Haifa. Photo: Hanay, CC BY-SA 3.0"),
 "ram": ("ram1.jpg", 0.50, 0.40, "Rambam, Haifa. Photo: David Shay, CC BY-SA 3.0"),
 "hih": ("hih1.jpg", 0.55, 0.50, "Hand in Hand, Jerusalem. Photo: Matty Stern, CC BY 2.0"),
 "naz": ("naz.jpg", 0.62, 0.50, "Nazareth. Photo: Dafna Tal, IMOT, CC BY-SA 2.0"),
})
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def WX(li, word):     # index of the word in line li that equals `word` (punctuation ignored)
    k = re.sub(r"\W", "", word).lower()
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower() == k: return i
    raise KeyError((li, word))
def lerpbox(a, b, u): return tuple(lerp(x, y, u) for x, y in zip(a, b))
def photo_b(canvas, t, k, t0, t1, box, ain=0.45, aout=0.35, alpha=1.0):
    x0, y0, x1, y1 = [int(round(v)) for v in box]; photo(canvas, t, k, t0, t1, (x0, y0, x1, y1), alpha=alpha, ain=ain, aout=aout)
def credit_at(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#9A9AA0", ain=0.3, inst=(t0 <= 0))

BOX = (60, 250, 1020, 760); CRED_Y = 792; NAME_Y = 885
HOOK_BOX = (60, 760, 1020, 1440); HOOK_CRED = HOOK_BOX[3] + 34
HOOK_END = S(1) - 0.15
def b_t0(li): return S(li) - 0.2
TURN = S(8) - 0.2; END_T = S(12) - 0.12
BEATS = [("hol", 1, 1), ("ram", 2, 2), ("hih", 3, 5), ("naz", 6, 6)]

def glow_at(t):
    z = 0.07 + 0.07 * seg(t, b_t0(7), b_t0(7) + 1.2) * (1 - seg(t, TURN, TURN + 0.8))     # warmer stage on the Ziadna story
    return z + 0.09 * seg(t, TURN, TURN + 1.0) * (1 - seg(t, END_T - 0.4, END_T + 0.8))  # and on the turn

HOOK_A, HOOK_B = "Can Jews and Arabs", "be friends?"
HS = min(fit(HOOK_A, "db", 128), fit(HOOK_B, "db", 128)); HY1, HY2 = 440, 440 + HS * 1.2
END_A, END_B = "So next time someone", "says it's impossible, ask…"
ES = min(fit(END_A, "db", 128), fit(END_B, "db", 128))

def frame_raw(t):
    im = stage(glow_at(t))
    # ---- hook (line 0) over Jaffa at sunset; the lead-in (line 12) returns to the same place and size
    zoom = 1 + 0.03 * seg(t, 0, HOOK_END)
    photo_b(im, t, "jaf", -1, HOOK_END, HOOK_BOX, ain=0.01, aout=0.4)
    if t < HOOK_END + 0.5: credit_at(im, t, "jaf", -1, HOOK_END, HOOK_CRED)
    text(im, t, HOOK_A, HY1, HS, 0, HOOK_END, inst=True, zoom=zoom)
    text(im, t, HOOK_B, HY2, HS, 0, HOOK_END, inst=True, zoom=zoom, color=GOLD)
    text(im, t, END_A, HY1, ES, END_T, T_END + 1, ain=0.55); text(im, t, END_B, HY2, ES, END_T + 0.12, T_END + 1, ain=0.55, color=GOLD)
    photo_b(im, t, "jaf", END_T + 0.3, T_END + 1, HOOK_BOX, ain=0.8)
    if t > END_T: credit_at(im, t, "jaf", END_T + 0.5, T_END + 1, HOOK_CRED)
    # ---- the four places
    for k, la, lb in BEATS:
        t0 = b_t0(la); t1 = b_t0(lb + 1); photo_b(im, t, k, t0, t1, BOX, ain=0.4, aout=0.3); credit_at(im, t, k, t0 + 0.1, t1, CRED_Y)
    # Haifa
    t0, t1 = b_t0(1), b_t0(2)
    text(im, t, "Haifa", NAME_Y, 112, t0 + 0.05, t1)
    s = "Jews, Christians, Muslims"; text(im, t, s, 1020, fit(s, "dsb", 78), S(1, WX(1, "Jews")) - 0.1, t1, fk="dsb")
    text(im, t, "One festival", 1170, 140, S(1, WX(1, "share")) - 0.15, t1, color=GOLD)
    text(im, t, "Every December, since 1993", 1310, fit("Every December, since 1993", "dm", 64), S(1, WX(1, "Since")) - 0.1, t1, fk="dm", color=GREY)
    # Hospitals
    t0, t1 = b_t0(2), b_t0(3); ha = S(2, WX(2, "One")) - 0.1; hb = S(2, WX(2, "almost")) - 0.2
    text(im, t, "Israeli hospitals", NAME_Y, fit("Israeli hospitals", "db", 104), t0 + 0.05, t1)
    text(im, t, "1 in 4", 1100, 220, ha, hb, color=GOLD)
    text(im, t, "doctors is Arab", 1265, fit("doctors is Arab", "dsb", 84), S(2, WX(2, "doctors")) - 0.1, hb, fk="dsb")
    text(im, t, "49%", 1100, 220, hb, t1, color=GOLD, tab=True)
    text(im, t, "of pharmacists", 1265, fit("of pharmacists", "dsb", 84), hb + 0.1, t1, fk="dsb")
    # Hand in Hand (lines 3 to 5)
    t0, t1 = b_t0(3), b_t0(6); ka = S(3, WX(3, "two")) - 0.2; sh = S(4) - 0.12; sa = S(5) - 0.12
    s = "Hand in Hand schools"; text(im, t, s, NAME_Y, fit(s, "db", 100), t0 + 0.05, t1)
    v = roll(t, ka, 0.8, 0, 2000)
    text(im, t, f"{int(round(v)):,}+", 1090, 200, ka, sh, color=GOLD, tab=True)
    s = "Jewish and Arab kids"; text(im, t, s, 1245, fit(s, "dsb", 80), S(3, WX(3, "Jewish")) - 0.1, sh, fk="dsb")
    s = "learning in two languages"; text(im, t, s, 1350, fit(s, "dm", 66), S(3, WX(3, "languages")) - 0.35, sh, fk="dm", color=GREY)
    text(im, t, "Shalom.", 1110, 170, sh, t1)
    text(im, t, "Salaam.", 1300, 170, sa, t1, color=SKY)
    # Tech (line 6)
    t0, t1 = b_t0(6), b_t0(7); ta = S(6, WX(6, "three")) - 0.15; tb = S(6, WX(6, "over")) - 0.15
    text(im, t, "Arab engineers", NAME_Y, fit("Arab engineers", "db", 112), t0 + 0.05, t1)
    s = "in Israeli high-tech"; text(im, t, s, 1005, fit(s, "dm", 70), t0 + 0.3, t1, fk="dm", color=GREY)
    v = 350 if t < tb else roll(t, tb, 0.9, 350, 10000, log=True)
    lab = f"{int(round(v / 10) * 10):,}" + ("+" if t >= tb + 0.9 else "")
    text(im, t, lab, 1185, 210, ta, t1, color=GOLD, tab=True)
    text(im, t, "in 2008", 1340, 72, ta + 0.1, tb, fk="dsb")
    text(im, t, "in 2023", 1340, 72, tb + 0.2, t1, fk="dsb")
    # Youssef Ziadna (line 7): two cards, no photo
    t0 = b_t0(7); zb = S(7, WX(7, "He")) - 0.15; t1 = TURN; zz = 1 + 0.025 * seg(t, t0, t1)
    text(im, t, "October 7, 2023", 640, 66, t0 + 0.05, zb, fk="dm", color=GREY, zoom=zz)
    text(im, t, "A Bedouin driver", 800, fit("A Bedouin driver", "db", 110), S(7, WX(7, "Bedouin")) - 0.25, zb, zoom=zz)
    text(im, t, "Youssef Ziadna", 960, fit("Youssef Ziadna", "db", 130), S(7, WX(7, "Youssef")) - 0.15, t1, color=GOLD, zoom=zz)
    s = "drove toward the gunfire"; text(im, t, s, 1110, fit(s, "dsb", 80), S(7, WX(7, "drove")) - 0.15, zb, fk="dsb", zoom=zz)
    v = roll(t, zb + 0.1, 0.7, 0, 30)
    text(im, t, f"{int(round(v))}", 1230, 300, zb, t1, color=GOLD, tab=True, zoom=zz)
    s = "people brought out alive"; text(im, t, s, 1420, fit(s, "dsb", 80), zb + 0.25, t1, fk="dsb", zoom=zz)
    # ---- the turn (line 8)
    p0 = S(9) - 0.15
    text(im, t, "It works.", 830, 160, TURN, p0, ain=0.6)
    s = "But it isn't automatic."; text(im, t, s, 1010, fit(s, "db", 112), S(8, WX(8, "But")) - 0.15, p0, ain=0.55, color=GOLD)
    # ---- patience, openness, kindness: each word lands big on its own beat, the earlier ones step back
    o0 = S(10) - 0.12; k0 = S(11) - 0.12
    text(im, t, "It takes", 640, 76, p0, END_T, fk="dm", color=GREY)
    text(im, t, "Patience.", 800, 170, p0, END_T, alpha=1 - 0.45 * seg(t, o0, o0 + 0.4))
    text(im, t, "Openness.", 1000, 170, o0, END_T, color=SKY, alpha=1 - 0.45 * seg(t, k0, k0 + 0.4))
    text(im, t, "Kindness.", 1200, 170, k0, END_T, color=GOLD)
    text(im, t, "Every single day.", 1360, 76, S(11, WX(11, "Every")) - 0.15, END_T, fk="dsb")
    sources(im, t); subtitles(im, t)
    return im

# ------------------------------------------------------------------ subtitles (lines 0, 4, 5 and 8 to 12: the hero text is the words)
def I(li, w): return w if isinstance(w, int) else WX(li, w)
CH = [(1, 0, "Come to Haifa."), (1, "Every", "Every December, Jews, Christians and Muslims"), (1, "share", "share one festival."),
      (1, "Since", "Since 1993."), (2, 0, "Walk into an Israeli hospital."), (2, "One", "One in four doctors is Arab."),
      (2, "And", "And almost half the pharmacists."), (3, 0, "At Hand in Hand schools,"), (3, "over", "over 2,000 Jewish and Arab kids"),
      (3, "learn", "learn in two languages."), (6, 0, "In tech, Arab engineers went"), (6, "from", "from about 350 in 2008,"),
      (6, "to", "to over 10,000."), (7, 0, "And on October 7th,"), (7, 4, "a Bedouin driver, Youssef Ziadna,"),
      (7, "drove", "drove toward the gunfire."), (7, "He", "He brought 30 people out alive.")]
CH = [(li, I(li, w), s) for li, w, s in CH]
SUBS = []
for i, (li, wi, s) in enumerate(CH):
    a = S(li, wi) - 0.04; nxt = CH[i + 1] if i + 1 < len(CH) else None
    endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
    b = E(li, endw) + 0.4
    if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.06)
    SUBS.append((a, b, s)); assert len(s.split()) <= 7, s
SUB_Y = 1600; SRC_Y = 1745
def subtitles(canvas, t):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12); flat(canvas, wrap(s, SUBF, 900), SUBF, SUB_Y, 68, "#FFFFFF", 0.94 * al)
SOURCES = [(0, []),
           (b_t0(1), ["Holiday of Holidays, Beit HaGefen, since 1993:", "Christian Science Monitor, 2018"]),
           (b_t0(2), ["Arab share of Israel's health workforce, 2023:", "Rosen and Miaari, Isr J Health Policy Res, 2025"]),
           (b_t0(3), ["6 campuses, over 2,000 students:", "Hand in Hand, 2026"]),
           (b_t0(6), ["350 in 2008: Tsofen. Over 10,000 in 2023:", "NAS for Tsofen, Arabs in Hi-Tech, 2023"]),
           (b_t0(7), ["Youssef Ziadna rescued 30 people near Re'im:", "JTA, Oct 2023"]),
           (TURN, [])]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if lines and t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, SRC_Y, 50, "#9A9AA0", a)

F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + [v[3] for v in PH.values()] + [HOOK_A, HOOK_B, END_A, END_B] + L
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam|follow", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
for v in PH.values(): assert font("r", 36).getlength(v[3]) <= 980, v[3]
assert len(HOOK_A.split()) + len(HOOK_B.split()) <= 6

N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
