"""local step: warm, hopeful bed (shabbat_record/shabbat_audio.py music: D freygish, oud-ish pluck, hand drum, reed) re-timed so
exactly 20 bars fill T_END (bpm 100), cut from bar 4 on (so the groove is full at frame 0 and bar 23 (D7) resolves into bar 4 (D)
on the loop), overflow folded onto the start; strings swell under the turn (lines 8 to 11); vo from work/vo.wav -> work/mix.m4a."""
import sys, os, json, types, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/together_works"
src = open("/home/claude/shabbat_record/shabbat_audio.py").read().replace("bpm = 104;", "bpm = BPM;")
SA = types.ModuleType("sa"); SA.__dict__["__file__"] = "/home/claude/shabbat_record/shabbat_audio.py"
W = json.load(open(f"{D}/work/words.json"))["words"]
LS = lambda li: min(w["t0"] for w in W if w["li"] == li)
BARS = 20; T_END = 48.0; BPM = 4 * 60 * BARS / T_END; bar = 4 * 60 / BPM
SA.__dict__["BPM"] = BPM; exec(compile(src, "shabbat_audio_tw", "exec"), SA.__dict__)
SR = SA.SR; assert SR == AU.SR
pre = 4 * bar; s0 = LS(8) - 0.3 + pre; s1 = LS(12) - 0.6 + pre
raw = SA.music(T_END + pre + bar, swell=(s0, s1), end_fade=0.01)
i0 = int(round(pre * SR)); n = int(round(T_END * SR)); xf = int(0.6 * SR)
bed = raw[:, i0:i0 + n].copy(); tail = raw[:, i0 + n:i0 + n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
head = raw[:, i0 - int(0.02 * SR):i0]          # no click at the loop point: tiny pre-roll blend
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(LS(8) - 0.05, AU.soft_hit(), -9.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, T_END, ev, mw, music_db=-18.0, sfx_db=-14.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=T_END, bpm=BPM, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", T_END, BPM, J.get("final_I"), J.get("final_TP"))
