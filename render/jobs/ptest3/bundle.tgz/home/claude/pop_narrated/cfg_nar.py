import runpy, json
_B=runpy.run_path("/home/claude/vid/cfg_pop.py")
for _k,_v in _B.items():
    if not _k.startswith("__"): globals()[_k]=_v
OUT="/home/claude/pop_narrated/nar_silent.mp4"
HOOK=None
GOLD="#ffd166"
TL=[(-1200,0.0),(-1150,1.4),(-1050,3.43),(-586,7.03),(70,8.80),(400,10.32),(638,12.29),(1517,15.38),(1882,19.70),(1948,24.25),(1950,30.0),(2026,33.6)]
HOLD=45.0-33.6
DISC_Y=0.172
HOOK2={"dur":2.0,"fade":0.3,"dim":0.30,"box":(0.05,0.255,0.90,0.195),"lines":[
 (0.418,"3,000 years in 45 seconds.","white",46),(0.372,"Who lived here?",GOLD,60),
 (0.318,"3,000 שנה ב-45 שניות.","white",40),(0.280,"מי חי כאן?",GOLD,52)]}
_T=json.load(open("/home/claude/pop_narrated/timing.json"))
ENDCARD={"t0":_T[18]["t0"]-0.25,"dim":0.30,"box":(0.05,0.255,0.90,0.165),"lines":[
 (0.385,"Which year surprised you?","white",50),(0.338,"איזו שנה הפתיעה אתכם?",GOLD,46),
 (0.287,"Sources in the caption  |  המקורות בכיתוב","#9aa4bf",22)]}
# (line, first word, last word, EN, HE)
_C=[(1,0,2,"Who lived here?","מי חי כאן?"),
 (2,0,3,"Canaanites, Israelites and Philistines","כנענים, בני ישראל ופלשתים"),
 (2,4,6,"share the land.","חולקים את הארץ."),
 (3,0,4,"Babylon destroys the First Temple.","בבל מחריבה את בית המקדש הראשון."),
 (4,0,2,"Rome, the Second.","רומא, את השני."),
 (5,0,4,"Christians become the largest group.","הנוצרים הופכים לקבוצה הגדולה ביותר."),
 (6,0,5,"In 638, Muslims conquer Jerusalem.","ב-638 המוסלמים כובשים את ירושלים."),
 (7,0,3,"1517: the Ottomans.","1517: העות'מאנים."),
 (8,0,4,"About 7,000 Jews remain.","נשארים כ-7,000 יהודים."),
 (9,0,4,"1882: the First Aliyah.","1882: העלייה הראשונה."),
 (10,0,3,"Muslim numbers grow too.","גם מספר המוסלמים גדל."),
 (11,0,4,"1948: Israel is founded.","1948: קום מדינת ישראל."),
 (12,0,8,"About 700,000 Arabs flee or are expelled.","כ-700 אלף ערבים בורחים או מגורשים."),
 (13,0,2,"Then mass immigration,","ואז עלייה המונית,"),
 (14,0,4,"including Jews from Arab lands.","גם של יהודים מארצות ערב."),
 (15,0,5,"Today: 7.6 million Jews,","היום: 7.6 מיליון יהודים,"),
 (16,0,4,"6.9 million Muslims.","6.9 מיליון מוסלמים."),
 (17,0,7,"In my view, both have deep roots here.","לדעתי, לשני העמים שורשים עמוקים כאן.")]
SUBS=[]
for _i,(_l,_a,_b,_e,_h) in enumerate(_C):
    _w=_T[_l]["words"]; assert _b==len(_w)-1 or _i+1<len(_C) and _C[_i+1][0]==_l, (_l,_b,len(_w))
    s0=max(HOOK2["dur"],_w[_a]["t0"]-0.08); s1=_w[_b]["t1"]+0.35
    SUBS.append([s0,s1,_e,_h])
for _i in range(len(SUBS)-1): SUBS[_i][1]=min(SUBS[_i][1],SUBS[_i+1][0])
SUBS[-1][1]=min(SUBS[-1][1],ENDCARD["t0"])
