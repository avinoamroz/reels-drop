import sys, runpy, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, subprocess
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
matplotlib.rcParams["font.family"]=["Inter","Liberation Sans","DejaVu Sans"]
C=runpy.run_path(sys.argv[1]); BG=C.get("BG","#0b1020"); GRID=C.get("GRID","#1e2740"); ACC=C.get("ACCENT","#7dd3fc"); TICK=C.get("TICK","#5c6680"); FG=C.get("FG","white"); GOLD=C.get("GOLD","#ffd166"); SUBC=C.get("SUBC","#9aa4bf"); DISCC=C.get("DISCC","#5c6680"); G=C["G"]; EVENTS=C["EVENTS"]; TL=C["TL"]; ROWS=C.get("ROWS",7)
W,H,FPS=1080,1920,30
HOLD=C.get("HOLD",5); ty=[t for _,t in TL]; yy=[y for y,_ in TL]; N=int(round((TL[-1][1]+HOLD)*FPS))
import os; SNAPS=[int(round(float(x)*FPS)) for x in os.environ["SNAPS"].split(",")] if os.environ.get("SNAPS") else None
def val(pts,y):
    if y<pts[0][0]: return 0
    if y>pts[-1][0]: return pts[-1][1]
    return float(np.interp(y,[p[0] for p in pts],[p[1] for p in pts]))
def fmt_year(y):
    y=int(y) if y>2000 else int(round(y)); return f"{-y} BCE" if y<0 else (f"{y} CE" if y<1000 else str(y))
def fmt_n(v):
    if C.get("DEC"): return f"{v:.1f}" if v<100 else f"{v:.0f}"
    if C.get("USD"): return "$"+f"{int(round(v,-2)):,}"
    if v<1000: return f"{int(round(v)):,}"
    return f"{v/1e6:.2f}M" if v>=1e6 else f"{int(round(v,-3 if v>=10000 else -2)):,}"

def AY(y): return 0.43+(y-0.32)*0.335/0.51
def AX(r):
    x,y,w,h=r; top=0.70 if C.get("BANNER") else 0.748
    k=(top-0.43)/0.51
    return [0.03+x*0.85, 0.43+(y-0.32)*k, w*0.85, h*k]
PORT=plt.imread(C['PORTRAIT']) if C.get('PORTRAIT') else None
names=list(G); pos={n:None for n in names}
DOTS=None
if "MAP" in C and C["MAP"].get("mode")=="dots":
    from matplotlib.path import Path
    M=C["MAP"]; poly=Path(np.array(M["outline"])); DOT=M["dot"]; DOTS={}
    for gi,n in enumerate(names):
        if n not in M["coords"]: continue
        P=int(max(p[1] for p in G[n][2])/DOT)+3; arrs=[]
        for ki,(yr,lo,la,sx,sy) in enumerate(M["coords"][n]):
            rng=np.random.default_rng(gi*100+ki); pts=[]
            while len(pts)<P:
                q=rng.normal([lo,la],[sx,sy],size=(P*3,2)); q=q[poly.contains_points(q)]
                if M.get("exclude"): q=q[~Path(np.array(M["exclude"])).contains_points(q)]
                pts.extend(q.tolist())
            arrs.append(np.array(pts[:P]))
        DOTS[n]=([k[0] for k in M["coords"][n]],arrs)
FL={n:plt.imread(f'/home/claude/vid/flags/{c}.png') for n,c in C.get('FLAGS',{}).items()}
fig=plt.figure(figsize=(W/100,H/100),dpi=100)
ff=None if SNAPS else subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgba","-s",f"{W}x{H}","-r",str(FPS),"-i","-",
 "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-preset","medium",C["OUT"]],stdin=subprocess.PIPE)
fs=22 if ROWS<=7 else 18
for f in range(N):
    t=min(f/FPS,TL[-1][1]); year=np.interp(t,ty,yy)
    vals={n:val(G[n][2],year) for n in names}
    alive=[n for n in names if vals[n]>=C.get("MIN",1)]
    ranked=sorted(alive,key=lambda n:-vals[n])[:ROWS]
    for i,n in enumerate(ranked): pos[n]=i if pos[n] is None else pos[n]+(i-pos[n])*0.15
    for n in names:
        if n not in ranked: pos[n]=None
    if SNAPS and f not in SNAPS: continue
    fig.clf(); fig.patch.set_facecolor(BG)
    fig.text(0.5,0.835,C["T_EN"],ha="center",color=FG,fontsize=C.get("T_FS",50)-6,fontweight="bold")
    fig.text(0.5,0.802,C["T_HE"],ha="center",color=GOLD,fontsize=C.get("T_FS",50)-9,fontweight="bold")
    fig.text(0.5,0.778,C["SUB"],ha="center",color=SUBC,fontsize=19)
    if C.get("BANNER"):
        from matplotlib.patches import FancyBboxPatch
        fig.patches.append(FancyBboxPatch((0.04,0.718),0.92,0.046,boxstyle="round,pad=0.004,rounding_size=0.012",transform=fig.transFigure,facecolor="#1e3a8a",edgecolor="#60a5fa",lw=2,alpha=0.9))
        b1,b2=C["BANNER"]
        fig.text(0.5,0.749,b1,ha="center",va="center",color=FG,fontsize=C.get("BANNER_FS",24),fontweight="bold")
        fig.text(0.5,0.730,b2,ha="center",va="center",color=GOLD,fontsize=C.get("BANNER_FS",24),fontweight="bold")
    ax=fig.add_axes(AX(C.get("BAR_AX",[0.08,0.33,0.84,0.50]))); ax.set_facecolor(BG)
    mx=max([vals[n] for n in ranked]+[C.get("FLOOR",5000)]); xmax=mx*C.get("XMAXF",1.5)
    ax.set_xlim(0,xmax); ax.set_ylim(ROWS-0.4,-0.6)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_yticks([]); ax.xaxis.tick_top(); ax.tick_params(axis="x",colors=TICK,labelsize=18)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v,p:(f"{v/1e6:g}M" if v>=1e6 else (f"{int(v/1000)}k" if v>=1000 else str(int(v))))))
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(4)); ax.grid(axis="x",color=GRID,lw=1.5); ax.set_axisbelow(True)
    for n in ranked:
        v=vals[n]; p=pos[n]; heb,c,_=G[n]; lab=f"{n}  {heb}"
        ax.barh(p,v,height=0.78,color=c)
        fw=xmax*0.062 if n in FL else 0
        inside=v>xmax*0.5
        if n in FL:
            fx=xmax*0.012 if inside else v+xmax*0.012
            ax.add_artist(AnnotationBbox(OffsetImage(FL[n],zoom=0.62),(fx,p),box_alignment=(0,0.5),frameon=False,xycoords="data"))
        if inside:
            ax.text(xmax*0.012+fw,p,lab,va="center",ha="left",color=BG,fontsize=fs,fontweight="bold")
            ax.text(v+xmax*0.015,p,fmt_n(v),va="center",ha="left",color=FG,fontsize=fs+1)
        else:
            ax.text(v+xmax*0.015+fw,p-0.07,lab,va="center",ha="left",color=c,fontsize=fs,fontweight="bold")
            ax.text(v+xmax*0.015+fw,p+0.3,fmt_n(v),va="center",ha="left",color=FG,fontsize=fs-5)
    if "MAP" in C:
        M=C["MAP"]; mx2=fig.add_axes(AX(M["ax"])); mx2.set_facecolor(BG); mx2.set_aspect(1/np.cos(np.radians(31.5)))
        o=np.array(M["outline"]); mx2.fill(o[:,0],o[:,1],color="#1a2440",zorder=1); mx2.plot(o[:,0],o[:,1],color="#3a4a70",lw=1.5,zorder=2)
        if M.get("exclude"):
            ex=np.array(M["exclude"]); mx2.fill(ex[:,0],ex[:,1],facecolor="#0b1020",edgecolor="#5c6680",hatch="///",lw=1,zorder=6)
            if M.get("exclude_label"): mx2.text(ex[:,0].min()-0.03,ex[:,1].mean(),M["exclude_label"],ha="right",va="center",color="#9aa4bf",fontsize=12,zorder=7)
        for d in M.get("dashed",[]):
            d=np.array(d); mx2.plot(d[:,0],d[:,1],color="#3a4a70",lw=1,ls=(0,(3,3)),zorder=2)
        if DOTS is not None:
            allp=[]; allc=[]
            for n in names:
                if n not in DOTS: continue
                v=vals[n]; cnt=0 if v<C.get("MIN",1) else max(1,int(round(v/M["dot"])))
                if cnt==0: continue
                yrs,arrs=DOTS[n]
                if year<=yrs[0] or len(yrs)==1: A=arrs[0]
                elif year>=yrs[-1]: A=arrs[-1]
                else:
                    j=max(i for i in range(len(yrs)) if yrs[i]<=year); fr_=(year-yrs[j])/(yrs[j+1]-yrs[j]); A=arrs[j]*(1-fr_)+arrs[j+1]*fr_
                A=A[:cnt]; allp.append(A); allc+= [G[n][1]]*len(A)
            if allp:
                P_=np.vstack(allp); order=np.random.default_rng(1).permutation(len(P_)); cs=np.array(allc)[order]
                mx2.scatter(P_[order,0],P_[order,1],s=M.get("ds",7),c=cs,alpha=0.9,linewidths=0,zorder=3)
            mx2.text(0.98,0.02,M["legend"],transform=mx2.transAxes,ha="right",va="bottom",color=SUBC,fontsize=16)
        top=max([vals[n] for n in names]+[1])
        if DOTS is not None: top=None
        for n in ([] if top is None else sorted(names,key=lambda n:-vals[n])):
            v=vals[n]
            if v<C.get("MIN",1) or n not in M["coords"]: continue
            cc=M["coords"][n]
            if isinstance(cc,list):
                lo=float(np.interp(year,[q[0] for q in cc],[q[1] for q in cc])); la=float(np.interp(year,[q[0] for q in cc],[q[2] for q in cc]))
            else: lo,la=cc
            r=M["rmax"]*np.sqrt(v/top)
            mx2.scatter([lo],[la],s=r**2,color=G[n][1],alpha=0.75,edgecolors="white",linewidths=1,zorder=3)
        mx2.set_xlim(*M["xlim"]); mx2.set_ylim(*M["ylim"]); mx2.axis("off")
    for (y0,y1,ce,ch) in C.get("CALLOUTS",[]):
        if y0<=year<=y1 and C.get("PORTRAIT") and "Ben-Yehuda" in ce:
            from matplotlib.patches import FancyBboxPatch as _FB
            fig.patches.append(_FB((0.07,0.424),0.78,0.066,boxstyle="round,pad=0.004,rounding_size=0.012",transform=fig.transFigure,facecolor="#0f172a",edgecolor=GOLD,lw=2,alpha=0.96))
            pax=fig.add_axes([0.075,0.427,0.075,0.06]); pax.imshow(PORT); pax.axis("off"); pax.set_zorder(60)
            fig.text(0.50,0.470,"Eliezer Ben-Yehuda (1858-1922)",ha="center",va="center",color=GOLD,fontsize=19,fontweight="bold")
            fig.text(0.50,0.444,"אליעזר בן-יהודה, מחיה השפה העברית",ha="center",va="center",color=FG,fontsize=19,fontweight="bold")
            continue
        if y0<=year<=y1:
            from matplotlib.patches import FancyBboxPatch as _FB
            fig.patches.append(_FB((0.07,0.424),0.78,0.066,boxstyle="round,pad=0.004,rounding_size=0.012",transform=fig.transFigure,facecolor="#0f172a",edgecolor=GOLD,lw=2,alpha=0.96))
            fig.text(0.46,0.470,ce,ha="center",va="center",color=GOLD,fontsize=19,fontweight="bold")
            fig.text(0.46,0.444,ch,ha="center",va="center",color="white",fontsize=19,fontweight="bold")
    for di,(de,dh,dk,dc) in enumerate(C.get("DONUTS",[])):
        sh=max(0.0005,val(dk,year)); dax=fig.add_axes(AX([0.63,0.60-di*0.25,0.32,0.20])); dax.set_facecolor(BG)
        dax.pie([sh,1-sh],colors=[dc,GRID],startangle=90,counterclock=False,wedgeprops=dict(width=0.32,edgecolor=BG))
        dax.text(0,0.05,f"{sh*100:.1f}%" if sh<0.1 else f"{sh*100:.0f}%",ha="center",va="center",color=FG,fontsize=30,fontweight="bold")
        fig.text(0.74,AY(0.815-di*0.25),de,ha="center",color=SUBC,fontsize=18,fontweight="bold")
        fig.text(0.74,AY(0.797-di*0.25),dh,ha="center",color=SUBC,fontsize=18,fontweight="bold")
    if C.get("DONUT_NOTE") and year>=C.get("DONUT_NOTE_FROM",1990):
        fig.text(0.74,AY(0.35)-0.004,C["DONUT_NOTE"][0],ha="center",va="top",color=GOLD,fontsize=21,fontweight="bold")
        fig.text(0.74,AY(0.35)-0.028,C["DONUT_NOTE"][1],ha="center",va="top",color=GOLD,fontsize=21,fontweight="bold")
    fig.text(0.84,0.355,fmt_year(year),ha="right",color=FG,fontsize=(54 if year<0 else 64),fontweight="bold",alpha=0.9)
    fig.text(0.84,0.333,C.get("ERA_LABEL",("לפני הספירה" if year<0 else "לספירה")),ha="right",color=GOLD,fontsize=28,fontweight="bold")
    if C.get("COUNTER"):
        le,lh,kp=C["COUNTER"]; cv=sum(vals.values()) if C.get("COUNTER_SUM") else val(kp,year)
        fig.text(0.07,0.392,le+"  |  "+lh,ha="left",color=SUBC,fontsize=19,fontweight="bold")
        fig.text(0.07,0.352,("$" if C.get("USD") else "")+f"{int(round(cv,-2 if C.get('USD') else (-3 if cv>=10000 else 0))):,}",ha="left",color=ACC,fontsize=42,fontweight="bold")
    ev=[e for e in EVENTS if e[0]<=year]
    if ev:
        fig.text(0.47,0.298,ev[-1][1],ha="center",color=GOLD,fontsize=24,fontweight="bold")
        fig.text(0.47,0.273,ev[-1][2],ha="center",color=FG,fontsize=24,fontweight="bold")
    for i,l in enumerate(C["DISC"]): fig.text(0.47,C.get("DISC_Y",0.247)-0.012*i,l,ha="center",color=DISCC,fontsize=13)
    from matplotlib.patches import FancyBboxPatch as _FS
    tt=f/FPS
    for (s0,s1,se,sh) in C.get("SUBS",[]):
        if s0<=tt<s1:
            fig.patches.append(_FS((0.06,0.207),0.88,0.054,boxstyle="round,pad=0.004,rounding_size=0.014",transform=fig.transFigure,facecolor="#101a33",edgecolor="#2a3a63",lw=1.5,alpha=0.95,zorder=40))
            fz=min(30,int(30*34/max(34,len(se))*1.0)) if len(se)>34 else 30
            fig.text(0.5,0.244,se,ha="center",va="center",color=FG,fontsize=fz,fontweight="bold",zorder=41)
            fig.text(0.5,0.221,sh,ha="center",va="center",color="#c7d2fe",fontsize=min(26,fz-2),fontweight="bold",zorder=41)
            break
    ov=None
    hk=C.get("HOOK2")
    if hk and tt<hk["dur"]:
        fd=hk.get("fade",0.3); ov=(hk,1.0 if tt<hk["dur"]-fd else max(0.0,min(1.0,(hk["dur"]-tt)/fd)))
    ec=C.get("ENDCARD")
    if ec and tt>=ec["t0"]: ov=(ec,min(1.0,(tt-ec["t0"])/0.3))
    if ov:
        hc,a=ov
        fig.patches.append(matplotlib.patches.Rectangle((0,0),1,1,transform=fig.transFigure,color="#050914",alpha=hc.get("dim",0.3)*a,zorder=50))
        x,y,w,h=hc["box"]
        fig.patches.append(_FS((x,y),w,h,boxstyle="round,pad=0.01,rounding_size=0.03",transform=fig.transFigure,facecolor="#0f1a33",edgecolor=GOLD,lw=4,alpha=a,zorder=51))
        for yy_,tx,cc,fz in hc["lines"]:
            fig.text(0.5,yy_,tx,ha="center",va="center",color=cc,fontsize=fz,fontweight="bold",alpha=a,zorder=52)
    if C.get("HOOK") and f/FPS<1.0:
        a=1.0 if f/FPS<0.75 else max(0,1-(f/FPS-0.75)/0.25)
        from matplotlib.patches import FancyBboxPatch as _FH
        fig.patches.append(matplotlib.patches.Rectangle((0,0),1,1,transform=fig.transFigure,color="#050914",alpha=0.86*a,zorder=50))
        fig.patches.append(_FH((0.06,0.40),0.88,0.26,boxstyle="round,pad=0.01,rounding_size=0.03",transform=fig.transFigure,facecolor="#0f1a33",edgecolor=C["HOOK"][4],lw=4,alpha=a,zorder=51))
        if C.get("HOOK_IMG") is not None:
            hax=fig.add_axes([0.40,0.665,0.20,0.112]); hax.imshow(PORT,alpha=a); hax.axis("off"); hax.set_zorder(53)
        for yy_,tx,cc,fz in [(0.615,C["HOOK"][0],"white",40),(0.565,C["HOOK"][1],C["HOOK"][4],min(40,int(1300/max(1,len(C["HOOK"][1]))))),(0.495,C["HOOK"][2],"white",36),(0.445,C["HOOK"][3],C["HOOK"][4],36)]:
            fig.text(0.5,yy_,tx,ha="center",va="center",color=cc,fontsize=fz,fontweight="bold",alpha=a,zorder=52)
    fig.canvas.draw()
    if SNAPS: fig.savefig(os.environ["SD"]+f"/s_{f/FPS:05.2f}.png"); continue
    ff.stdin.write(fig.canvas.buffer_rgba().tobytes())
if ff: ff.stdin.close(); ff.wait()
print("done",C["OUT"],N/FPS)
