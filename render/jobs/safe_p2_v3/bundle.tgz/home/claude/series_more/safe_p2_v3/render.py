"""cloud step: silent video (engine_v3.py cfg_v3.py) + work/mix.m4a -> safe_p2_v3.mp4"""
import runpy, subprocess, os
D = "/home/claude/series_more/safe_p2_v3"; CFG = f"{D}/cfg_v3.py"; C = runpy.run_path(CFG)
subprocess.run(["nice", "-n", "10", "python3", f"{D}/engine_v3.py", CFG, "--silent"], check=True)
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", C["OUT"], "-i", f"{D}/work/mix.m4a", "-map", "0:v", "-map", "1:a", "-c", "copy",
                "-t", f"{C['T_END']:.2f}", "-movflags", "+faststart", C["FINAL"]], check=True)
os.remove(C["OUT"]); print("final", C["FINAL"])
