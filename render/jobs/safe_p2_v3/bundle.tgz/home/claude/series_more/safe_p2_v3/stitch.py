"""trim each Cartesia clip (one line each) and stitch with short gaps -> safe_p2_v3_vo.wav (44.1 kHz mono)"""
import subprocess, numpy as np, soundfile as sf, sys
D = "/home/claude/series_more/safe_p2_v3"; SR = 44100
# gap AFTER line i (s): short inside a "had X. / Today? Y." pair, longer between beats
CLIPS = ["l00", "l01", "l02", "l03", "l04", "l05", "l06", "l07", "l08", "l09", "r10c", "l11", "l12", "l13", "r14a", "r14b", "r15a", "r15b",
         "l16", "l17", "n20"]   # r* = retakes: r10c "None" fell (l10 rose like a question), r14/r15 split so "Americas" and "four thousand" keep their energy, r18b ends on "today"
GAP = {0: 0.45, 1: 0.40, 2: 0.22, 3: 0.38, 4: 0.38, 5: 0.22, 6: 0.38, 7: 0.22, 8: 0.38, 9: 0.22, 10: 0.42, 11: 0.22, 12: 0.45,
       13: 0.35, 14: 0.28, 15: 0.50, 16: 0.25, 17: 0.50, 18: 0.40, 19: 0.55}
def load(p):
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True)
    return np.frombuffer(r.stdout, np.float32).astype(np.float64)
def squeeze(y, keep=0.26, minp=0.30):
    """shorten internal pauses (40 dB under the clip peak, longer than minp) to keep seconds; Cartesia leaves 0.5 to 0.8 s at full stops"""
    hop = 441; n = len(y) // hop; L = 10 * np.log10((y[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); low = L < L.max() - 40
    segs = []; i = 0
    while i < n:
        if low[i]:
            j = i
            while j < n and low[j]: j += 1
            if (j - i) * 0.01 > minp and i > 0 and j < n: segs.append((i, j))
            i = j
        else: i += 1
    keepf = int(keep * 100); res = []; prev = 0
    for i, j in segs:
        h = keepf // 2; res.append(y[prev * hop:(i + h) * hop]); prev = j - (keepf - h)
    res.append(y[prev * hop:]); z = np.concatenate(res)
    if segs: print("  squeezed", [round((j - i) / 100, 2) for i, j in segs])
    return z
out = []; spans = []
for i, c in enumerate(CLIPS):
    x = load(f"{D}/clips/{c}.mp3"); hop = 441; n = len(x) // hop
    L = 10 * np.log10((x[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); thr = L.max() - 45
    on = np.where(L > thr)[0]; a = max(0, on[0] - 3) * hop; b = min(len(x), (on[-1] + 6) * hop)
    y = squeeze(x[a:b], keep=0.42 if c == "n20" else 0.26); f = int(0.008 * SR); y[:f] *= np.linspace(0, 1, f); y[-f:] *= np.linspace(1, 0, f)
    t0 = sum(len(z) for z in out) / SR; out.append(y); spans.append((round(t0, 3), round(t0 + len(y) / SR, 3)))
    if i in GAP: out.append(np.zeros(int(GAP[i] * SR)))
out.append(np.zeros(int(0.5 * SR))); v = np.concatenate(out); sf.write(f"{D}/safe_p2_v3_vo.wav", v.astype(np.float32), SR)
print("total", round(len(v) / SR, 2)); [print(i, s, round(s[1] - s[0], 2)) for i, s in enumerate(spans)]
