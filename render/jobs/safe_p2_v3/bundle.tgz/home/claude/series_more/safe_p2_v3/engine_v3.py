"""safe_p2_v3 keynote engine (new, replaces the map engine): a near-black stage with one soft radial glow, Inter Display / Inter only,
one idea per screen. Items come from the cfg (cfg_v3.py): 'text' items and 'num' counters (tabular digits, smooth roll, colour
and size eased), with kicker/label text attached above/below a counter. Every appearance is a cubic in-out fade with a small
scale and blur-in; every exit a short fade with a little blur. Subtitles (Inter SemiBold 54, no box) and the source label
(Inter Regular 40, grey) are drawn flat. usage: python3 engine_v3.py cfg_v3.py [--snaps 0,12.5] [--silent]"""
import sys, os, math, runpy, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
ap = argparse.ArgumentParser(); ap.add_argument("cfg"); ap.add_argument("--snaps"); ap.add_argument("--silent", action="store_true")
A = ap.parse_args(); C = runpy.run_path(A.cfg)
W, H, FPS = 1080, 1920, 30
FD = C["FONTDIR"]
FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium", dl="InterDisplay-Light",
                                              sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)

# ------------------------------------------------------------------ stage
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GX, GY, GR = C["GLOW_XY"][0], C["GLOW_XY"][1], C["GLOW_R"]
_r2 = ((xx - GX) / (GR * 0.85)) ** 2 + ((yy - GY) / GR) ** 2
GLOW = np.exp(-0.5 * _r2)[:, :, None]          # wide gaussian (sigma about GR): a gentle pool of light, no visible rim
BASE = hx(C["BG"])[None, None, :].astype(np.float32); GCOL = hx(C["GLOW_COL"])[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def glow_at(t):
    K = C["GLOW_KEYS"]; v = K[0][1]
    for (t0, v0), (t1, v1) in zip(K[:-1], K[1:]):
        if t >= t0: v = v0 + (v1 - v0) * seg(t, t0, t1)
    return v
def stage(t):
    g = glow_at(t); a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# ------------------------------------------------------------------ text rasters (2x masks)
_rc = {}
def raster(s, fk, size, track=0.0, tab=False):
    """-> (mask L at 2x, baseline y in mask, width in 1x px, cap height in 1x px)"""
    key = (s, fk, size, track, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not track and not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = []
        for ch in s: adv.append((dw if (tab and ch.isdigit()) else f.getlength(ch)) + track * size * 2)
        w = sum(adv) - track * size * 2; im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            cw = f.getlength(ch); off = (dw - cw) / 2 if (tab and ch.isdigit()) else 0
            d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 400: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, mask_info, cx, base_y, scale, color, alpha, blur):
    """composite a 2x mask: horizontal centre cx, baseline base_y, scale (1 = native size), sub-pixel placement, optional blur"""
    if alpha <= 0.004: return
    im, by, w1, _ = mask_info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k))
    m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    canvas.alpha_composite(lay, (ix, iy)) if ix >= 0 and iy >= 0 and ix + cw <= W and iy + ch <= H else _clip_comp(canvas, lay, ix, iy)
def _clip_comp(canvas, lay, ix, iy):
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + lay.width), min(H, iy + lay.height)
    if x1 <= x0 or y1 <= y0: return
    canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))

# ------------------------------------------------------------------ item state
AIN, AOUT = C["T_IN"], C["T_OUT"]
def env(it, t):
    """alpha, scale mult, blur, dy for an item's own in/out animation"""
    t0, t1 = it["t_in"], it.get("t_out", 1e9)
    if t < t0 and not it.get("inst"): return 0, 1, 0, 0
    if it.get("inst") and t < t0 + 1e-6: u = 1.0
    else: u = seg(t, t0, t0 + it.get("ain", AIN))
    v = seg(t, t1, t1 + it.get("aout", AOUT))
    a = u * (1 - v); sc = (0.965 + 0.035 * u) * (1 + 0.02 * v); blur = 11 * (1 - u) + 7 * v; dy = 16 * (1 - u)
    for (d0, d1, target) in it.get("dim", []): a *= 1 + (target - 1) * seg(t, d0, d1)
    return a, sc, blur, dy
def lerp_col(t, keys, c0):
    c = hx(c0)
    for (t0, t1, a, b) in keys: c = hx(a) + (hx(b) - hx(a)) * seg(t, t0, t1) if t >= t0 else c
    return c
def num_value(it, t):
    v = it["keys"][0][2]
    for (t0, t1, v0, v1) in it["keys"]:
        if t < t0: break
        u = seg(t, t0, t1)
        if v0 > 0 and v1 > 0: v = math.exp(math.log(v0) + (math.log(v1) - math.log(v0)) * u)
        elif v0 > v1: v = math.exp(math.log(v0 + 1) * (1 - u)) - 1          # down to 0: log roll on v+1
        else: v = v0 + (v1 - v0) * u
    return v
def num_scale(it, t):
    s = 1.0
    for (t0, t1, s0, s1) in it.get("grow", []):
        if t >= t0: s = s0 + (s1 - s0) * seg(t, t0, t1)
    return s
ITEMS = C["ITEMS"]; BYID = {it["id"]: it for it in ITEMS if "id" in it}
def num_geom(it, t):
    """centre y, current size scale, cap height (1x px) of a counter"""
    sc = num_scale(it, t); info = raster("0", it["font"], it["size"], it.get("track", 0), True)
    return it["y"], sc, info[3] * sc

# ------------------------------------------------------------------ flat layers: subtitles and sources
SUBF = ImageFont.truetype(FONTS["sb"], C["SUB_FS"]); SRCF = ImageFont.truetype(FONTS["r"], C["SRC_FS"])
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat_text(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in col) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)
def subtitles(canvas, t):
    for (a, b, s) in C["SUBS"]:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 0.0001, (b - t) / 0.12)
            flat_text(canvas, wrap(s, SUBF, 900), SUBF, C["SUB_Y"], 68, hx(C["SUB_COL"]), C["SUB_ALPHA"] * al)
def sources(canvas, t):
    S = C["SOURCES"]
    for i, (t0, lines) in enumerate(S):
        t1 = S[i + 1][0] if i + 1 < len(S) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.45)) * (1 - seg(t, t1 - 0.3, t1))
        if t >= t0 - 0.01 and a > 0: flat_text(canvas, lines, SRCF, C["SRC_Y"], C["SRC_LH"], hx(C["SRC_COL"]), a)

# ------------------------------------------------------------------ frame
def frame(t):
    im = stage(t)
    for it in ITEMS:
        a, sc, blur, dy = env(it, t)
        if a <= 0.004: continue
        if it["k"] == "num":
            v = num_value(it, t); s = it.get("fmt", "{:,}").format(int(round(v)))
            cy, gs, caph = num_geom(it, t); info = raster(s, it["font"], it["size"], it.get("track", 0), True)
            col = lerp_col(t, it.get("col", []), it["color"])
            put(im, info, 540, cy + caph / 2 + dy, gs * sc, col, a, blur)
        else:
            y = it["y"]; sc_extra = 1.0
            if "attach" in it:
                side, nid, gap = it["attach"]; cy, gs, caph = num_geom(BYID[nid], t)
                y = cy - caph / 2 - gap * (1 + 0.25 * (gs - 1)) if side == "above" else cy + caph / 2 + gap + 0.24 * BYID[nid]["size"] * (gs - 1)
            for (z0, z1, s0, s1) in it.get("zoom", []):
                if t >= z0: sc_extra = s0 + (s1 - s0) * seg(t, z0, z1)
            info = raster(it["s"], it["font"], it["size"], it.get("track", 0))
            col = lerp_col(t, it.get("col", []), it["color"])
            put(im, info, 540, y + dy, sc * sc_extra, col, a * it.get("alpha", 1.0), blur)
    sources(im, t); subtitles(im, t)
    return im.convert("RGB")

T_END = C["T_END"]; N = int(round(T_END * FPS))
if A.snaps:
    os.makedirs(C["SNAPDIR"], exist_ok=True)
    for s in A.snaps.split(","):
        t = min(float(s), (N - 1) / FPS); f = int(round(t * FPS)); f = min(f, N - 1)
        frame(f / FPS).save(f"{C['SNAPDIR']}/{C['TAG']}_{f / FPS:05.2f}.png")
    print("snaps ->", C["SNAPDIR"]); sys.exit()
ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                       "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "16", "-preset", "medium", "-tune", "grain", "-x264-params", "aq-mode=3", C["OUT"]], stdin=subprocess.PIPE)
for f in range(N):
    ff.stdin.write(frame(f / FPS).tobytes())
    if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
ff.stdin.close(); ff.wait(); print("video", C["OUT"], f"{T_END:.2f}s")
