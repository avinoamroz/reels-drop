"""mix.py: voice + playful procedural bed (reelkit 'playful', original) at -16 LUFS ducked under the voice + synthesised
page flips, stamp thuds, paper rip and the cover slam (all generated here) -> audio.m4a at -14 LUFS / -1.5 dBTP."""
import sys, json, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/bbs_rulebook"); sys.path.insert(0, "/home/claude/rehook"); sys.path.insert(0, "/home/claude/reelkit")
import reel as R, rk
import mix as rkmix
D = "/home/claude/bbs_rulebook"; SR = 48000
T = R.DUR; n = int(T * SR)
def lufs(x):
    o = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", "ebur128", "-f", "null", "-"],
                       input=x.T.astype(np.float32).tobytes(), capture_output=True).stderr.decode()
    return float(o[o.rfind("I:"):].split()[1])
vo, sr = sf.read(f"{D}/vo_final.wav"); assert sr == SR
if vo.ndim > 1: vo = vo.mean(1)
vo = np.pad(vo, (0, max(0, n - len(vo))))[:n]
# music bed, looping: crossfade the tail into the head so the loop is seamless
L = n + int(0.6 * SR)
bed = rkmix.bed("playful", L / SR, (L / SR) - 2.0)[:, :L]
xf = int(0.6 * SR); head = bed[:, :n].copy(); tail = bed[:, n:n + xf]
r = np.arange(xf) / xf; head[:, :xf] = head[:, :xf] * r[None] + tail * (1 - r)[None]; bed = head
bed *= 10 ** ((-16 - lufs(bed)) / 20)
m = np.zeros(n)
for l in R.Ls: m[int((l["t0"] - 0.08) * SR):int((l["t1"] + 0.12) * SR)] = 1
k = int(0.12 * SR); m = np.convolve(m, np.ones(k) / k, "same"); bed *= (10 ** (-9 * m / 20))[None]
# SFX (synthesised, original)
rng = np.random.default_rng(11)
sfx = np.zeros((2, n))
def put(t, y, db, pan=0.5):
    i = int(t * SR); j = min(n, i + len(y))
    if 0 <= i < n: g = 10 ** (db / 20); sfx[0, i:j] += y[:j - i] * g * (1 - pan) * 2 ** 0.5; sfx[1, i:j] += y[:j - i] * g * pan * 2 ** 0.5
def bandnoise(dur, lo, hi):
    x = rng.standard_normal(int(dur * SR)); X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    X[(f < lo) | (f > hi)] = 0; y = np.fft.irfft(X, len(x)); return y / np.abs(y).max()
def flip_snd(dur=0.34):
    y = bandnoise(dur, 900, 7000); tt = np.arange(len(y)) / SR
    env = np.sin(np.pi * np.clip(tt / dur, 0, 1)) ** 1.5 * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 26 * tt)))
    snap = bandnoise(0.05, 1500, 9000) * np.exp(-np.arange(int(0.05 * SR)) / SR * 80)
    y = y * env; y[-len(snap):] += snap * 0.8; return y / np.abs(y).max()
def thud(f0=85, dur=0.35, click=0.5):
    tt = np.arange(int(dur * SR)) / SR
    y = np.sin(2 * np.pi * f0 * tt * (1 + 0.3 * np.exp(-tt * 30))) * np.exp(-tt * 16) + click * bandnoise(dur, 200, 4000) * np.exp(-tt * 70)
    return y / np.abs(y).max()
def rip(dur=0.7):
    y = bandnoise(dur, 1200, 9000); tt = np.arange(len(y)) / SR
    crack = (rng.random(len(y)) < 0.004).astype(float); crack = np.convolve(crack, np.exp(-np.arange(200) / 30), "same")
    env = np.clip(tt / 0.05, 0, 1) * np.exp(-np.clip(tt - 0.45, 0, None) * 12) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 9 * tt)))
    y = (y * 0.7 + crack * 0.6) * env; return y / np.abs(y).max()
FL = flip_snd(); TH = thud(); SLAM = thud(60, 0.5, 0.8); RP = rip()
put(0.0, flip_snd(0.6) * np.linspace(0.3, 1, int(0.6 * SR)), -26, 0.4)    # cover lifting
put(R.flip_start(0), flip_snd(0.5), -17, 0.4)                                  # cover opens
for j in range(1, R.NR): put(R.flip_start(j), FL, -18, 0.35 + 0.1 * (j % 3))
for (li, *_ ) in R.RULES: put(R.Ls[li]["words"][-1]["t0"] - 0.05 + 0.02, TH, -17)
put(R.T13, FL, -18); put(R.S(12) - 0.05, RP, -17, 0.6); put(R.WF(12, "check") + 0.02, TH, -16)
put(R.T_SHUT, flip_snd(0.3), -17); put(R.T_SHUT + 0.30, SLAM, -15)
x = np.stack([vo, vo]) + bed + sfx
# pre-limit: smooth gain envelope so no peak exceeds -3 dBFS after the -14 LUFS gain
g = 10 ** ((-14 - lufs(x)) / 20); thr = 10 ** (-6 / 20) / g
pk = np.abs(x).max(0); need = np.minimum(1.0, thr / np.maximum(pk, 1e-9))
from scipy.ndimage import minimum_filter1d, uniform_filter1d
env = uniform_filter1d(minimum_filter1d(need, int(0.012 * SR)), int(0.006 * SR))
x = x * env[None]
J = rk.finish_audio(x, f"{D}/audio.m4a")
print("audio", T, J.get("final_I"), J.get("final_TP"), J.get("steps"))
