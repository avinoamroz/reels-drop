import json, wave, numpy as np
SR=44100; out=[]; words=[]; t=0.0
def rd(p):
    w=wave.open(p+".wav"); a=np.frombuffer(w.readframes(w.getnframes()),np.int16); return a, json.load(open(p+"_words.json"))
for p, n_keep in (("p0", 64), ("p2", None), ("p1", None)):
    a, W = rd(p)
    if n_keep is not None:
        W = W[:n_keep]; cut = int((W[-1]["end"] + 0.3) * SR); a = a[:cut]
    for x in W: words.append(dict(word=x["word"], start=x["start"] + t, end=x["end"] + t))
    out.append(a); out.append(np.zeros(int(0.5*SR), np.int16)); t += len(a)/SR + 0.5
y=np.concatenate(out)
with wave.open("raw.wav","wb") as o: o.setnchannels(1); o.setsampwidth(2); o.setframerate(SR); o.writeframes(y.tobytes())
json.dump(words, open("raw_words.json","w"))
print(len(words), round(len(y)/SR,2), words[61]["word"], words[62]["word"])
