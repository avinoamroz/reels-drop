# -*- coding: utf-8 -*-
"""bbs_rulebook (@noamroz__, 9 Nov 2026). Parody follow-up to bbs_news: a thick "BBS RULEBOOK" (parody design, no real
logo, typeface, ident or music) on a desk; pages flip, one rule per page, highlighter on the punch words, APPROVED stamp,
small doodle. Rule 13 is torn out. The book snaps shut and loops into frame 0 (cover opening).
usage: python3 reel.py [--snaps=0,1,3,...]"""
import sys, math, re
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, "/home/claude/bbs_rulebook")
import ck
from ck import *
ck.HERE = "/home/claude"
ck.SUB_Y = 1735
RID = "bbs_rulebook"
T = Timing(RID); DUR = round(T.dur + 0.95, 2)
Ls = T.lines
def S(i): return Ls[i]["t0"]
def E(i): return Ls[i]["t1"]
def WF(i, word, nth=0):
    n = 0
    for w in Ls[i]["words"]:
        if re.sub(r"[^\w]", "", w["w"].lower()) == word.lower():
            if n == nth: return w["t0"] - 0.04
            n += 1
    raise KeyError((i, word))
def T_(d, x, y, s, sz, col, w=900, anchor="mm", a=1.0, stroke=0, maxw=980, mn=36):
    if a <= 0.01: return
    ck.txt(d, x, y, s, max(mn, ck.fit(s, sz, maxw, w, mn)), col, w, anchor, max(0, min(1, a)), stroke)

NAVY = hx("#163261"); INK = hx("#163261"); PAPER = (247, 243, 232); PAPER_D = (226, 219, 201)
REDB = hx("#B3262E"); STAMP = hx("#D0312D"); HL = hx("#FFD166")

# ------------------------------------------------------------------ geometry
PX0, PX1, PY0, PY1 = 150, 958, 486, 1560          # page on screen
PW, PH = PX1 - PX0, PY1 - PY0
CX0, CX1, CY0, CY1 = 112, 972, 470, 1576          # cover

def lay(w=W, h=H): return Image.new("RGBA", (w, h), (0, 0, 0, 0))

# desk (dark navy wood) + book body (spine, page stack), cached
def make_desk():
    r = np.linspace(0, 1, H)[:, None]; x = np.arange(W)[None, :]
    base = np.array(hx("#0B1834")[:3], np.float32) * (1 - r[..., None]) + np.array(hx("#14284F")[:3], np.float32) * r[..., None]
    grain = (np.sin(x / 7.0 + 3 * np.sin(np.arange(H)[:, None] / 90.0)) * 0.5 + np.sin(x / 2.3 + np.arange(H)[:, None] / 300.0) * 0.25)
    a = base * np.ones((H, W, 1)) + grain[..., None] * 3.0
    im = Image.fromarray(a.clip(0, 255).astype(np.uint8), "RGB").convert("RGBA")
    # book shadow
    sh = lay(); ImageDraw.Draw(sh).rounded_rectangle([CX0 + 18, CY0 + 30, CX1 + 26, CY1 + 40], 30, fill=(0, 0, 0, 150))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(26)))
    d = ImageDraw.Draw(im)
    # back cover + page stack edges
    d.rounded_rectangle([CX0, CY0, CX1, CY1], 22, fill=hx("#0F2147"))
    for k in range(7, 0, -1):
        o = k * 2.2; c = tuple(int(v * (0.86 + 0.02 * (k % 2))) for v in PAPER) + (255,)
        d.rectangle([PX0, PY0 + o, PX1 + o, PY1 + o], fill=c)
    # spine binding
    d.rounded_rectangle([CX0, CY0, PX0 + 6, CY1], 18, fill=REDB)
    for y in (CY0 + 60, CY1 - 70): d.line([(CX0 + 6, y), (PX0, y)], fill=YEL, width=5)
    return im
DESK = make_desk()

# ------------------------------------------------------------------ text layout with highlight groups
def layout(text, sz, maxw, w=900):
    """'*...*' marks highlight groups. -> list of lines [(word, group or -1)], size"""
    toks, g, k = [], -1, 0
    for raw in text.split():
        st = raw.startswith("*"); en = raw.endswith("*") and len(raw) > 1
        word = raw.strip("*")
        if st: g = k
        toks.append((word, g));
        if en: g = -1; k += 1
    while True:
        lines, cur = [], []
        for t in toks:
            trial = " ".join(x[0] for x in cur + [t])
            if cur and tw(trial, sz, w) > maxw: lines.append(cur); cur = [t]
            else: cur.append(t)
        if cur: lines.append(cur)
        if len(lines) <= 4 or sz <= 72: return lines, sz
        sz -= 2

def draw_rule_text(im, text, cx, cy, sz, maxw, hl_prog, col=INK):
    """hl_prog[g] in 0..1: highlighter sweep for group g"""
    lines, sz = layout(text, sz, maxw)
    lh = sz * 1.16; y0 = cy - lh * len(lines) / 2
    d = ImageDraw.Draw(im); sp = tw(" ", sz, 900)
    pos = []
    for li, ln in enumerate(lines):
        wl = tw(" ".join(x[0] for x in ln), sz, 900); x = cx - wl / 2; y = y0 + li * lh
        for word, g in ln:
            ww = tw(word, sz, 900); pos.append((word, g, x, y, ww)); x += ww + sp
    # highlighter (behind text): per group, sweep left to right over its words in reading order
    L = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(L)
    groups = {}
    for p in pos:
        if p[1] >= 0: groups.setdefault(p[1], []).append(p)
    for g, ps in groups.items():
        u = hl_prog[g] if g < len(hl_prog) else 0
        if u <= 0: continue
        tot = sum(p[4] + sp for p in ps); run = u * tot
        for word, _, x, y, ww in ps:
            seg = min(ww + sp * 0.6, run); run -= ww + sp
            if seg <= 0: break
            ld.rounded_rectangle([x - sp * 0.3, y + sz * 0.10, x - sp * 0.3 + seg, y + sz * 1.04], 10, fill=HL[:3] + (235,))
    im.alpha_composite(L); d = ImageDraw.Draw(im)
    for word, g, x, y, ww in pos:
        ck.txt(d, x, y, word, sz, col, 900, "la")
    return y0 + lh * len(lines)

# ------------------------------------------------------------------ doodles (navy ink line art, 100-unit box)
def doodle(name, sz):
    Q = 3; n = sz * Q; im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im); u = n / 100.0
    P = lambda *xy: [v * u for v in xy]; Lw = lambda w: max(1, int(w * u))
    c = INK[:3] + (230,); y_ = HL[:3] + (255,); r_ = STAMP[:3] + (255,); lw = Lw(4)
    if name == "pencil":
        d.polygon(P(20, 80, 70, 30, 80, 40, 30, 90), outline=c, width=lw); d.polygon(P(20, 80, 30, 90, 12, 96), fill=c)
        d.line(P(64, 36, 74, 46), fill=c, width=lw)
        d.line(P(40, 70, 46, 64), fill=c, width=Lw(2))
        for k in range(3): d.arc(P(8 + k * 6, 2 + k * 6, 40 - k * 6, 34 - k * 6), 200, 330, fill=c, width=Lw(3))
    elif name == "scales":
        d.line(P(50, 12, 50, 88), fill=c, width=lw); d.line(P(30, 92, 70, 92), fill=c, width=lw)
        d.line(P(12, 26, 88, 40), fill=c, width=lw)
        d.line(P(12, 26, 4, 56), fill=c, width=Lw(2)); d.line(P(12, 26, 22, 56), fill=c, width=Lw(2)); d.chord(P(2, 46, 24, 66), 0, 180, outline=c, width=lw)
        d.line(P(88, 40, 80, 72), fill=c, width=Lw(2)); d.line(P(88, 40, 98, 72), fill=c, width=Lw(2)); d.chord(P(78, 62, 100, 82), 0, 180, outline=c, width=lw)
    elif name == "quotes":
        for ox in (10, 54):
            d.ellipse(P(ox, 30, ox + 22, 52), fill=c); d.polygon(P(ox + 2, 44, ox + 20, 46, ox + 8, 74), fill=c)
            d.ellipse(P(ox + 20, 30, ox + 42, 52), fill=c); d.polygon(P(ox + 22, 44, ox + 40, 46, ox + 28, 74), fill=c)
    elif name == "calc":
        d.rounded_rectangle(P(18, 4, 82, 96), Lw(8), outline=c, width=lw); d.rectangle(P(28, 14, 72, 34), outline=c, width=Lw(3))
        for r in range(3):
            for q in range(3): d.rounded_rectangle(P(28 + q * 16, 44 + r * 16, 38 + q * 16, 54 + r * 16), Lw(2), fill=c)
        d.text(P(76, 6)[0:2], "?", font=font(int(30 * u), 900), fill=r_)
    elif name == "rocket":
        d.polygon(P(50, 4, 66, 30, 66, 70, 34, 70, 34, 30), outline=c, width=lw); d.ellipse(P(43, 30, 57, 44), outline=c, width=Lw(3))
        d.polygon(P(34, 52, 20, 74, 34, 70), outline=c, width=lw); d.polygon(P(66, 52, 80, 74, 66, 70), outline=c, width=lw)
        d.polygon(P(40, 72, 60, 72, 50, 96), fill=r_)
    elif name == "mic":
        d.rounded_rectangle(P(36, 6, 64, 56), Lw(14), outline=c, width=lw); d.arc(P(24, 26, 76, 72), 0, 180, fill=c, width=lw)
        d.line(P(50, 72, 50, 90), fill=c, width=lw); d.line(P(34, 92, 66, 92), fill=c, width=lw)
        for k in range(3): d.line(P(40, 18 + k * 10, 60, 18 + k * 10), fill=c, width=Lw(2))
    elif name == "magnifier":
        d.ellipse(P(10, 10, 66, 66), outline=c, width=Lw(6)); d.line(P(58, 58, 90, 90), fill=c, width=Lw(9))
        for k in range(3): d.line(P(24, 28 + k * 9, 52 - k * 6, 28 + k * 9), fill=c, width=Lw(2))
    elif name == "stopwatch":
        d.ellipse(P(14, 18, 86, 90), outline=c, width=lw); d.rectangle(P(44, 4, 56, 14), outline=c, width=Lw(3))
        d.line(P(50, 54, 50, 30), fill=c, width=lw); d.line(P(50, 54, 68, 62), fill=r_, width=lw); d.ellipse(P(46, 50, 54, 58), fill=c)
    elif name == "target":
        for r, cc in ((44, c), (30, c), (16, c)): d.ellipse(P(50 - r, 54 - r, 50 + r, 54 + r), outline=cc, width=lw)
        d.ellipse(P(44, 48, 56, 60), fill=r_)
        for k, (x, y) in enumerate(((50, 54), (58, 50), (44, 60))):
            d.line(P(x, y, x + 34 - k * 4, y - 40 + k * 6), fill=c, width=Lw(3))
            d.polygon(P(x + 34 - k * 4, y - 40 + k * 6, x + 26 - k * 4, y - 38 + k * 6, x + 34 - k * 4, y - 30 + k * 6), fill=r_)
    elif name == "badge":
        d.rounded_rectangle(P(8, 22, 92, 82), Lw(8), outline=c, width=lw); d.rectangle(P(8, 22, 92, 42), fill=c)
        d.line(P(20, 62, 80, 62), fill=c, width=Lw(3)); d.line(P(40, 4, 50, 22), fill=c, width=Lw(3)); d.line(P(60, 4, 50, 22), fill=c, width=Lw(3))
    elif name == "glasses":
        d.rounded_rectangle(P(6, 36, 44, 66), Lw(12), fill=c); d.rounded_rectangle(P(56, 36, 94, 66), Lw(12), fill=c)
        d.arc(P(40, 36, 60, 52), 200, 340, fill=c, width=lw); d.line(P(6, 44, 0, 36), fill=c, width=lw); d.line(P(94, 44, 100, 36), fill=c, width=lw)
        d.line(P(14, 44, 24, 44), fill=(255, 255, 255, 200), width=Lw(3))
    elif name == "newspaper":
        d.rectangle(P(8, 14, 92, 88), outline=c, width=lw); d.rectangle(P(16, 22, 84, 36), fill=c)
        for k in range(4): d.line(P(16, 46 + k * 10, 46, 46 + k * 10), fill=c, width=Lw(2))
        d.rectangle(P(54, 44, 84, 76), outline=c, width=Lw(3)); d.line(P(54, 76, 84, 44), fill=c, width=Lw(2))
    return im.resize((sz, sz), Image.LANCZOS)

# ------------------------------------------------------------------ stamp
def make_stamp(word, sz=86, col=STAMP, rot=-13):
    w = int(tw(word, sz, 900)) + 80; h = int(sz * 1.5)
    im = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    c = col[:3] + (235,)
    d.rounded_rectangle([20, 20, 20 + w, 20 + h], 18, outline=c, width=9)
    d.rounded_rectangle([34, 34, 6 + w, 6 + h], 12, outline=c, width=3)
    d.text((20 + w / 2, 20 + h / 2), word, font=font(sz, 900), fill=c, anchor="mm")
    # worn ink texture
    rng = np.random.default_rng(len(word)); a = np.asarray(im.getchannel("A"), np.float32)
    noise = rng.random(a.shape); a = a * np.where(noise < 0.13, 0.25, 1.0)
    im.putalpha(Image.fromarray(a.clip(0, 255).astype(np.uint8)))
    return im.rotate(rot, resample=Image.BICUBIC, expand=True)
ST_OK = make_stamp("APPROVED"); ST_TORN = make_stamp("TORN OUT", 92, rot=9)

def put(im, src, cx, cy, a=1.0, sc=1.0):
    if a <= 0.01: return
    if sc != 1.0: src = src.resize((max(1, int(src.width * sc)), max(1, int(src.height * sc))), Image.BILINEAR)
    if a < 1: src = src.copy(); src.putalpha(src.getchannel("A").point(lambda v: int(v * a)))
    im.alpha_composite(src, (int(cx - src.width / 2), int(cy - src.height / 2)))

# ------------------------------------------------------------------ pages
# (line index, rule number, text, highlight triggers [(word, nth)], doodle, footnote)
RULES = [
    (0, 1, "If it isn't true, *make it up.*", [("make", 0)], "pencil", None),
    (1, 2, "Dead people matter. *Only if killed by a Jew.*", [("only", 0)], "scales", None),
    (2, 3, "HAMAS numbers: *“figures”.* Israeli numbers: *“claims”.*", [("figures", 0), ("claims", 0)], "calc", None),
    (3, 4, "Rocket at Israel? *“Sirens heard.”* Israel answers? *“Israel strikes.”*", [("sirens", 0), ("israel", 2)], "rocket", None),
    (4, 5, "Never say terrorist. Say *“militant”.* Then *“gunmen”.* Then forget.", [("militant", 0), ("gunmen", 0)], None,
     ("TRUE PART", "BBC guidelines: don't use “terrorist” without attribution.", "BBC statement, Oct 2023")),
    (5, 6, "Israeli guest? *Interrupt.* HAMAS guest? *Nod.*", [("interrupt", 0), ("nod", 0)], "mic", None),
    (6, 7, "Headline first. Facts later. *Corrections never.*", [("corrections", 0)], None,
     ("TRUE PART", "BBC News said it was wrong to speculate on the cause of the Gaza hospital blast.", "BBC News, 19 Oct 2023")),
    (7, 8, "If you must correct: *page 47.*", [("page", 0)], "magnifier", None),
    (8, 9, "The story starts *when Israel responds.*", [("when", 0)], "stopwatch", None),
    (9, 10, "When in doubt, *blame Israel.* When certain, *still blame Israel.*", [("blame", 0), ("still", 0)], "target", None),
    (10, 11, "A HAMAS spokesman is a *“health official”.*", [("health", 0)], "badge", None),
    (11, 12, "Our sources are anonymous. *Our bias isn't.*", [("our", 1)], "glasses", None),
]
NR = len(RULES)
_paper = None
def paper():
    global _paper
    if _paper is None:
        im = Image.new("RGBA", (PW, PH), PAPER + (255,)); d = ImageDraw.Draw(im)
        rng = np.random.default_rng(3); a = np.asarray(im, np.float32)
        a[..., :3] -= (rng.random((PH, PW, 1)) * 6)
        g = np.linspace(0, 1, PW)[None, :, None]; a[..., :3] -= (np.clip(1 - g / 0.08, 0, 1) * 26)   # gutter shade at the spine
        im = Image.fromarray(a.clip(0, 255).astype(np.uint8), "RGBA"); d = ImageDraw.Draw(im)
        for y in range(240, PH - 90, 64): d.line([(60, y), (PW - 40, y)], fill=(170, 196, 222, 70), width=2)
        d.line([(96, 110), (96, PH - 60)], fill=(214, 96, 96, 90), width=3)
        _paper = im
    return _paper.copy()

def page_base(r):
    """static part of a rule page (paper, header, rule number, doodle, footnote, page number)"""
    li, num, text, trig, dood, foot = r
    im = paper(); d = ImageDraw.Draw(im)
    T_(d, PW / 2, 58, "BBS EDITORIAL RULEBOOK", 38, hx("#5B6E8C"), 700, "mm", 1, maxw=PW - 120)
    d.line([(60, 92), (PW - 60, 92)], fill=hx("#5B6E8C")[:3] + (160,), width=3)
    T_(d, PW / 2, 178, f"RULE {num}", 100, SKY, 900, "mm", 1)
    if dood: put(im, doodle(dood, 230), 200, 850)
    if foot:
        hd, body, src = foot
        note = Image.new("RGBA", (680, 300), (0, 0, 0, 0)); nd = ImageDraw.Draw(note)
        nd.rectangle([8, 8, 672, 292], fill=(0, 0, 0, 60)); nd.rectangle([0, 0, 664, 284], fill=(255, 221, 120, 255))
        T_(nd, 332, 50, hd, 46, hx("#9A3B10"), 900, "mm", 1, maxw=600)
        ls = wrap(body, 42, 600, 800)
        for k, l in enumerate(ls[:3]): T_(nd, 332, 106 + k * 52, l, 42, NAVY, 800, "mm", 1, maxw=620, mn=36)
        T_(nd, 332, 106 + len(ls[:3]) * 52 + 10, src, 36, hx("#5B4A1E"), 700, "mm", 1, maxw=620)
        note = note.rotate(2.2, resample=Image.BICUBIC, expand=True)
        im.alpha_composite(note, (int(PW / 2 - note.width / 2), 650))
    T_(d, 110 if foot else PW / 2, PH - 44, f"p. {num}", 40, hx("#5B6E8C"), 700, "mm", 1)
    return im

BASES = [page_base(r) for r in RULES]
def rule_page(k, t, final=False):
    li, num, text, trig, dood, foot = RULES[k]
    im = BASES[k].copy()
    prog = [1.0 if final else ease((t - WF(li, w, n)) / 0.32) for w, n in trig]
    cy = 470 if not foot else 425
    bottom = draw_rule_text(im, text, PW / 2, cy, 96 if not foot else 80, PW - (140 if not foot else 80), prog)
    if num == 8:   # the correction, in the smallest size we allow
        d = ImageDraw.Draw(im); a = 1.0 if final else ease((t - WF(li, "font")) / 0.25)
        T_(d, PW / 2, bottom + 40, "(correction, font size 3)", 36, hx("#5B6E8C"), 700, "mm", a)
    # stamp: lands on the line's last word
    ts = Ls[li]["words"][-1]["t0"] - 0.05
    if final or t >= ts:
        u = 1.0 if final else min(1.0, (t - ts) / 0.14)
        sx, sy, k0 = (560, 850, 1.0) if not foot else (560, 1010, 0.78)
        put(im, ST_OK, sx, sy, a=min(1.0, 0.3 + u), sc=k0 * (1.0 + 0.7 * (1 - ease(u))))
    return im

# torn page (rule 13)
def torn_page(t):
    im = Image.new("RGBA", (PW, PH), hx("#0F2147")[:3] + (255,))
    rng = np.random.default_rng(13)
    stub = [(0, 0), (120, 0)]
    for y in range(40, PH, 40): stub.append((100 + rng.integers(0, 50), y))
    stub += [(120, PH), (0, PH)]
    L = Image.new("RGBA", (PW, PH), (0, 0, 0, 0)); ImageDraw.Draw(L).polygon(stub, fill=PAPER + (255,))
    im.alpha_composite(L); d = ImageDraw.Draw(im)
    T_(d, PW / 2 + 60, 150, "page missing", 52, SKY_L, 700, "mm", 1)
    # the scrap that survived
    sw, sh = 640, 470; sc = Image.new("RGBA", (sw, sh), (0, 0, 0, 0)); sd = ImageDraw.Draw(sc)
    poly = []
    for x in range(0, sw + 1, 40): poly.append((x, 8 + rng.integers(0, 22)))
    for y in range(40, sh + 1, 40): poly.append((sw - 8 - rng.integers(0, 24), y))
    for x in range(sw, -1, -40): poly.append((x, sh - 8 - rng.integers(0, 22)))
    for y in range(sh, 39, -40): poly.append((6 + rng.integers(0, 20), y))
    sd.polygon(poly, fill=PAPER + (255,))
    T_(sd, sw / 2, 110, "RULE 13", 92, SKY, 900, "mm", 1)
    T_(sd, sw / 2, 245, "Check", 96, NAVY, 900, "mm", 1)
    T_(sd, sw / 2, 350, "the source.", 96, NAVY, 900, "mm", 1, maxw=sw - 60)
    a = ease((t - S(12) - 0.1) / 0.35)
    sc = sc.rotate(-5 + 3 * (1 - a), resample=Image.BICUBIC, expand=True)
    put(im, sc, PW / 2 + 40, 640 + 60 * (1 - a), a=max(0.0, a))
    tst = WF(12, "check")
    if t >= tst:
        u = min(1.0, (t - tst) / 0.14); put(im, ST_TORN, PW / 2 + 60, 1010, a=min(1, 0.3 + u), sc=1 + 0.7 * (1 - ease(u)))
    return im

# cover
def make_cover():
    w, h = CX1 - PX0 + 14, CY1 - CY0
    im = Image.new("RGBA", (w, h), NAVY[:3] + (255,))
    rng = np.random.default_rng(5); a = np.asarray(im, np.float32); a[..., :3] += (rng.random((h, w, 1)) * 10 - 5)
    im = Image.fromarray(a.clip(0, 255).astype(np.uint8), "RGBA"); d = ImageDraw.Draw(im)
    d.rounded_rectangle([30, 30, w - 30, h - 30], 16, outline=hx("#C9A24A")[:3] + (255,), width=4)
    d.rectangle([0, 250, w, 560], fill=REDB)
    T_(d, w / 2, 405, "BBS", 250, WHITE, 900, "mm", 1)
    T_(d, w / 2, 680, "RULEBOOK", 128, YEL, 900, "mm", 1, maxw=w - 90)
    T_(d, w / 2, 790, "Barely Bothered with Sources", 50, WHITE, 700, "mm", 1, maxw=w - 100)
    T_(d, w / 2, 900, "Staff edition", 46, SKY_L, 700, "mm", 1)
    T_(d, w / 2, h - 110, "Do not fact check.", 44, hx("#C9D3E3"), 700, "mm", 1)
    return im
COVER = make_cover()
COVER_IN = Image.new("RGBA", COVER.size, hx("#0F2147")[:3] + (255,))
BACK = Image.new("RGBA", (PW, PH), tuple(int(v * 0.92) for v in PAPER) + (255,))

# ------------------------------------------------------------------ page flip (perspective, hinged at the spine)
def coeffs(dst, src):
    A, B = [], []
    for (x, y), (X, Y) in zip(dst, src):
        A.append([x, y, 1, 0, 0, 0, -X * x, -X * y]); A.append([0, 0, 0, x, y, 1, -Y * x, -Y * y]); B += [X, Y]
    return np.linalg.solve(np.array(A, float), np.array(B, float)).tolist()
def flip(im, front, back, p, x0, y0):
    """p 0..1, page hinged at x0 (top-left of the page at (x0, y0)); front shown up to 90 deg, back after"""
    if p <= 0.001: im.alpha_composite(front, (int(x0), int(y0))); return
    if p >= 0.999: return
    ang = p * math.pi; w, h = front.size; xr = x0 + w * math.cos(ang); s = 1 + 0.16 * math.sin(ang)
    cy = y0 + h / 2; top, bot = cy - h / 2 * s, cy + h / 2 * s
    # shadow on what lies below
    sh = lay(); ImageDraw.Draw(sh).rectangle([x0, y0, x0 + w, y0 + h], fill=(0, 0, 0, int(90 * math.sin(ang))))
    im.alpha_composite(sh)
    if ang <= math.pi / 2:
        src, dst = front, [(x0, y0), (xr, top), (xr, bot), (x0, y0 + h)]; shade = 0.35 * math.sin(ang)
    else:
        src, dst = back, [(xr, top), (x0, y0), (x0, y0 + h), (xr, bot)]; shade = 0.25 * math.sin(ang)
    sw, shh = src.size
    c = coeffs(dst, [(0, 0), (sw, 0), (sw, shh), (0, shh)])
    L = src.transform((W, H), Image.PERSPECTIVE, c, Image.BILINEAR)
    m = Image.new("L", src.size, 255).transform((W, H), Image.PERSPECTIVE, c, Image.BILINEAR)
    if shade > 0:
        L = Image.blend(L, Image.new("RGBA", (W, H), (10, 20, 40, 255)), shade)
    L.putalpha(m); im.alpha_composite(L)

# ------------------------------------------------------------------ timeline
FLIP = 0.42
def flip_start(k):
    """rule page k appears with a flip starting here (k = 0: cover opens)"""
    li = RULES[k][0]
    return WF(0, "rule") - 0.30 if k == 0 else S(li) - 0.24
T13 = S(12) - 0.24
T_SHUT = WF(14, "back") - 0.05
P0 = 0.13                                          # cover flip progress at frame 0 (already opening)
def cover_p(t):
    a = flip_start(0)
    if t < a: return P0 + 0.06 * ease(t / a)          # slow drift: the cover is lifting
    return min(1.0, P0 + 0.06 + (1 - P0 - 0.06) * ease((t - a) / 0.5))

def header(im, t):
    d = ImageDraw.Draw(im)
    if t < S(13) - 0.1 or t >= T_SHUT:
        T_(d, W / 2, 300, "The BBS Rulebook:", 104, WHITE, 900, "mm", 1)
        if t < flip_start(0) + 0.3 or t >= T_SHUT:
            s, col = "12 rules", YEL
        elif t < T13 + 0.2:
            k = max(j for j in range(NR) if flip_start(j) <= t + 0.2); s, col = f"Rule {RULES[k][1]} of 12", YEL
        else: s, col = "Rule 13 of 12", hx("#FF8A80")
        T_(d, W / 2, 410, s, 92, col, 900, "mm", 1)
    else:
        a = ease((t - S(13) + 0.1) / 0.3)
        T_(d, W / 2, 300, "Not every journalist", 84, WHITE, 900, "mm", a)
        T_(d, W / 2, 410, "works like this.", 84, YEL, 900, "mm", a)

def book(im, t):
    im.alpha_composite(DESK)
    # which page lies open
    if t >= T13: cur = torn_page(t)
    else:
        k = max([j for j in range(NR) if flip_start(j) + FLIP * 0.5 <= t] + [0])
        cur = rule_page(k, t)
    # flipping page on top
    if t < T13 + FLIP and t >= T13:
        under = cur; im.alpha_composite(under, (PX0, PY0))
        flip(im, rule_page(NR - 1, t, True), BACK, (t - T13) / FLIP, PX0, PY0)
    else:
        k = None
        for j in range(1, NR):
            if flip_start(j) <= t < flip_start(j) + FLIP: k = j
        if k is not None:
            im.alpha_composite(rule_page(k, t), (PX0, PY0))
            flip(im, rule_page(k - 1, t, True), BACK, (t - flip_start(k)) / FLIP, PX0, PY0)
        else:
            im.alpha_composite(cur, (PX0, PY0))
    # cover: opening at the start, slamming shut at the end
    if t < T_SHUT:
        p = cover_p(t)
    else:
        p = max(P0, 1 - (1 - P0) * ease((t - T_SHUT) / 0.34) ** 1.6)
    if p < 0.999: flip(im, COVER, COVER_IN, p, PX0 - 14, CY0)

_REP = [("forty seven", "47"), ("Hamas", "HAMAS"), ("Rule one", "Rule 1"), ("Rule thirteen", "Rule 13"), ("size three", "size 3")]
SUBS = [(a, b, s[:1].upper() + s[1:]) for a, b, s in sub_chunks(T, _REP)]
def frame(t):
    im = Image.new("RGBA", (W, H), (6, 14, 34, 255))
    book(im, t); header(im, t); draw_sub(im, SUBS, t)
    return im

if __name__ == "__main__":
    out = Out(RID, DUR, snaps_arg())
    for f, t in out.frames():
        out.put(f, t, frame(t))
    out.close()
