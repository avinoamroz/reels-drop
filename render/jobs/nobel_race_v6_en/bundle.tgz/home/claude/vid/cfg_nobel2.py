OUT="/home/claude/vid/nobel2_silent.mp4"; ROWS=6; MIN=1; FLOOR=20
T_EN="Nobel Prize winners by religion"; T_HE="זוכי פרס נובל לפי דת"; T_FS=46
SUB="By religious background  |  לפי רקע דתי"
G={"Christians":("נוצרים","#a855f7",[(1901,5),(1910,45),(1930,125),(1950,190),(1970,285),(1990,390),(2000,455),(2010,530),(2026,620)]),
 "Jews":("יהודים","#3b82f6",[(1901,0),(1905,1),(1910,3),(1930,18),(1950,42),(1970,80),(1990,120),(2000,145),(2010,175),(2026,215)]),
 "Atheists":("אתאיסטים","#a3a3a3",[(1901,0),(1910,2),(1930,7),(1950,15),(1970,30),(1990,50),(2000,70),(2010,95),(2026,115)]),
 "Muslims":("מוסלמים","#10b981",[(1977,0),(1978,1),(1979,2),(1988,3),(1994,4),(1999,5),(2005,7),(2006,8),(2011,10),(2015,12),(2026,14)]),
 "Hindus":("הינדים","#f97316",[(1912,0),(1913,1),(1930,2),(1968,3),(1983,4),(1998,5),(2009,6),(2014,7),(2019,8),(2026,9)]),
 "Buddhists":("בודהיסטים","#facc15",[(1988,0),(1989,1),(1991,2),(2000,3),(2010,4),(2026,6)]),
}
EVENTS=[(1901,"The first Nobel Prizes","פרסי נובל הראשונים"),(1921,"Einstein wins the Physics prize","איינשטיין זוכה בפרס לפיזיקה"),
 (1966,"S.Y. Agnon: the first Israeli laureate","ש\"י עגנון: הזוכה הישראלי הראשון"),(1978,"Begin and Sadat share the Peace prize","בגין וסאדאת חולקים את פרס השלום"),
 (2002,"Kahneman wins Economics","כהנמן זוכה בכלכלה"),(2011,"Shechtman wins Chemistry","שכטמן זוכה בכימיה"),
 (2026,"0.2% of humanity, 22% of Nobel Prizes","0.2% מהאנושות, 22% מפרסי הנובל")]
TL=[(1901,0),(1950,18),(2000,34),(2026,40)]
COUNTER=("Total laureates","סך הזוכים",[(1901,6),(1910,50),(1930,152),(1950,247),(1970,395),(1990,575),(2000,690),(2010,820),(2026,990)])
DISC=["Religious background, approximate. Many laureates were secular.","Based on Baruch Shalev and later laureate lists.","רקע דתי, נתונים משוערים. לפי ברוך שלו ורשימות הזוכים."]
BAR_AX=[0.05,0.33,0.56,0.50]; XMAXF=2.3
import numpy as _np
_y=list(range(1901,2027)); _J=G["Jews"][2]; _T=COUNTER[2]
_lj=[(y,float(_np.interp(y,[a for a,_ in _J],[b for _,b in _J]))/float(_np.interp(y,[a for a,_ in _T],[b for _,b in _T]))) for y in _y]
DONUTS=[("Jews: share of humanity","יהודים מכלל האנושות",[(1901,0.0067),(1939,0.0072),(1945,0.0046),(1970,0.0037),(2000,0.0021),(2026,0.0019)],"#3b82f6"),
        ("Jews: share of Nobel laureates","יהודים מכלל זוכי הנובל",_lj,"#3b82f6")]

HOOK=('Jews are 0.2% of the world.', 'Yet win 100x their share of Nobels.', 'יהודים הם 0.2% מהעולם.', 'אבל זוכים פי 100 מחלקם בנובל.', '#60a5fa')

DONUT_NOTE=("About 100x their share","בערך פי 100 מחלקם")
DONUT_NOTE_FROM=1995
