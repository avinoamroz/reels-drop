exec(open("/home/claude/vid/cfg_nobel2.py").read())
SNAPDIR="/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/en_only/snaps"
T_TOTAL=45.0; T_DATA=43.6; T_ENDC=44.2
TAG="nobel_race_v6_en"; OUT_EN="/home/claude/en_only/out/nobel_race_v6_en.mp4"; MUSIC="/home/claude/vid/music/p_t06.wav"
ROWS_EN=4
HOOK_EN=["Jews are 0.2%","of the world."]
SUB_EN="Nobel winners by religion"
SHORT_EN={}
COUNTER_EN="All winners"
SHARE_EN=[("Jews in the world",DONUTS[0][2],"#59A5DF"),("Jews among winners",DONUTS[1][2],"#E6C77E")]
REVEAL_EN=(30.0,35.6,["0.2% of humanity.","About 22% of winners."])
END_EN=["All this, while..."]
SRC_EN="Approximate. Source: Baruch Shalev, laureate lists"
ROW_H=130
