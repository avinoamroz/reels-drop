#!/usr/bin/env python3
"""endings_1101/join.py JOB_DIR OUT.mp4: cloud step. Downloads the published reel, keeps it up to Tc, appends tail.mp4,
muxes the prepared full audio (audio.flac). Render only: no TTS, no ASR."""
import json, os, subprocess, sys, urllib.request
J, out = sys.argv[1], sys.argv[2]
m = json.load(open(os.path.join(J, "meta.json")))
src = "/tmp/src_" + m["id"] + ".mp4"
if not os.path.exists(src):
    urllib.request.urlretrieve(m["src_url"], src)
os.makedirs(os.path.dirname(out), exist_ok=True)
fc = (f"[0:v]trim=end={m['Tc']},setpts=PTS-STARTPTS,fps=30,format=yuv420p[a];"
      f"[1:v]setpts=PTS-STARTPTS,fps=30,format=yuv420p[b];[a][b]concat=n=2:v=1:a=0[v]")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-i", os.path.join(J, "tail.mp4"), "-i", os.path.join(J, "audio.flac"),
                "-filter_complex", fc, "-map", "[v]", "-map", "2:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19",
                "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", out], check=True)
print("joined", out)
