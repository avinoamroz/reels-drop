"""scenes_origin.py (1 Nov): scenes for x_origin_1..3, the "Express - How it all started" deck reels.
Loads every sc_ scene from /home/claude/express_1031_cta/scenes_x.py (speaker end card, keynote2, loop cross-fade,
looping bed) and adds:

  card:    keynote2 look (deck colours) + optional "he" line per step and an optional "chip" pill on the step.
           steps [{text|value, emoji, label, he, size}], marks s0, s1, ...
  version: one Express "version" per scene: 6 progress dots, VERSION k pill, the year in gold (counts up from
           "from"), the stage name, a smaller "sub" line and a small Hebrew line. Fields v, year, from, en, sub, he;
           marks y (year), e (stage name), b (sub line).
  qa:      a question people ask (speech card, top), then "Principle #N" pill, the principle big, and a "why" line.
           Fields q, q_he, num, answer, why; marks a (principle), w (why line).
  week:    a 7 day strip, Sunday to Saturday. mode "student": only one day lit (English lesson on Zoom), the rest grey
           "Not English"; then the "items" chips (test, certificate) on marks i0... mode "speaker": the days light up one
           by one in sky blue on marks d0..d6 (or evenly), and the item chips (Netflix, work Zoom, new habit) on i0...
"""
import importlib.util, math
_p = "/home/claude/express_1031_cta/scenes_x.py"
_s = importlib.util.spec_from_file_location("scenes_x", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
for _k, _v in vars(_m).items():
    if _k.startswith("sc_"): globals()[_k] = _v
import render as RD
from render import P, T, PP, fade_in, source, block, block_h, shadow_box, pill, draw_emoji
from kit import ease, ramp, St, sa, rr, circ
DECK = _m.DECK


def _step_times(S, n):
    tm = [S["times"].get(f"s{k}", S["t0"] + 0.2 + 1.6 * k) for k in range(n)]
    if S.get("hook"): tm[0] = min(tm[0], 0.0)
    return tm


def sc_card(c, t, S):
    steps = S["steps"]; tm = _step_times(S, len(steps))
    k = max([i for i, tt in enumerate(tm) if t >= tt - 0.05] or [0]); st = steps[k]; t0k = tm[k]
    hook0 = bool(S.get("hook") and k == 0); cy = st.get("cy", 860)
    if S.get("kicker"):
        a, s = PP(t, S["t0"] + 0.05, S); pill(c, S["kicker"], 54, 540, 380, DECK["mint"], DECK["navy"], a, s, w=800)
    a, s = (1.0, 1.0) if hook0 else PP(t, t0k, S, s0=0.7, bounce=1.3)
    if hook0: s = 1.0 + 0.06 * ease(t / 1.6)      # hook: slow push-in so frame 0 and 1.5 s differ (QA motion)
    if st.get("emoji"):
        ea, es = (1.0, 1.0) if hook0 else PP(t, t0k + 0.05, S, bounce=2.2)
        if hook0: es = 1.0 + 0.18 * ease(t / 1.4)
        draw_emoji(c, st["emoji"], 540, cy - 340 + 6 * math.sin(t * 2.4) - (30 * ease(t / 1.4) if hook0 else 0), 190, ea, es)
    if "value" in st:
        prev = st["from"] if "from" in st else (steps[k - 1]["value"] if k and "value" in steps[k - 1] else 0)
        u = 1.0 if hook0 else ease((t - t0k) / st.get("dur", 1.1)); v = prev + (st["value"] - prev) * u
        T(c, f"{st.get('prefix', '')}{v:,.0f}{st.get('suffix', '')}", st.get("size", 330), 540, cy - 40, P["gold"], a, s, 900, maxw=1000)
        hb = st.get("size", 330) * 0.78
    else:
        block(c, st["text"], st.get("size", 124), 540, cy - 40, DECK["navy"], a, s, hl=DECK["skyd"], maxw=980, max_lines=3)
        hb = block_h(st["text"], st.get("size", 124), 900, 980, 3)
    yb = cy - 40 + hb / 2 + 40
    ba = ramp(t, 0.0, 1.2) if hook0 else ramp(t, t0k + 0.05, t0k + 0.45); bw = (120 + 600 * ease(ba)) if hook0 else 360 * ease(ba)
    if bw > 2: rr(c, 540 - bw / 2, yb, bw, 16, 8); sa(c, DECK["mint"], St.a); c.fill()
    y = yb + 60
    if st.get("label"):
        la = 1.0 if hook0 else ramp(t, t0k + 0.1, t0k + 0.4); lh = block_h(st["label"], st.get("label_size", 80), 900, 980, 2)
        block(c, st["label"], st.get("label_size", 80), 540, y + lh / 2, DECK["navy"], la, 1.0, hl=DECK["skyd"], maxw=980, max_lines=2); y += lh + 30
    if st.get("he"):
        ha = 1.0 if hook0 else ramp(t, t0k + 0.2, t0k + 0.5)
        T(c, st["he"], 58, 540, y + 40, P["gold_text"], ha, 1.0, 700, maxw=960)
    if st.get("chip"):
        ca, cs = (1.0, 1.0) if hook0 else PP(t, S["times"].get("chip", t0k + 0.6), S, bounce=2.2)
        pill(c, st["chip"], 64, 540, 1400, DECK["navy"], P["white"], ca, cs, outline=DECK["mint"], w=900)
    source(c, t, S)


def sc_version(c, t, S):
    t0 = S["t0"]; v = S["v"]; n = S.get("of", 6)
    ty = S["times"].get("y", t0 + 0.1); te = S["times"].get("e", ty + 0.9); tb = S["times"].get("b", te + 0.9)
    # progress dots: done ones navy, the current one grows in gold
    for k in range(n):
        x = 540 + (k - (n - 1) / 2) * 118; y = 320
        if k + 1 < v: circ(c, x, y, 24, DECK["navy"], St.a)
        elif k + 1 == v:
            u = 1.0 if S.get("hook") else ease((t - t0) / 0.5); circ(c, x, y, 24 + 10 * u, P["gold"], St.a)
            T(c, str(v), 40, x, y + 1, P["white"], 1.0, 1.0, 900)
        else: circ(c, x, y, 22, DECK["sky"], 0.35 * St.a)
    a, s = PP(t, t0 + 0.05, S); pill(c, f"VERSION {v}", 64, 540, 470, DECK["mint"], DECK["navy"], a, s, w=800)
    # the year, counting up from the previous version's year
    a, s = PP(t, ty, S, s0=0.7, bounce=1.3)
    u = 1.0 if (S.get("hook") and ty <= RD.HOOK_GRACE) else ease((t - ty) / 0.9)
    y0 = S.get("from", S["year"]); yr = round(y0 + (S["year"] - y0) * u)
    T(c, f"{S.get('year_prefix', '')}{yr}", 300, 540, 720, P["gold"], a, s, 900, maxw=1000)
    bw = 360 * ease(ramp(t, ty + 0.1, ty + 0.5))
    if bw > 2: rr(c, 540 - bw / 2, 860, bw, 16, 8); sa(c, DECK["mint"], St.a); c.fill()
    a, s = PP(t, te, S, bounce=2.0); he_ = block_h(S["en"], 104, 900, 980, 2)
    block(c, S["en"], 104, 540, 960 + he_ / 2, DECK["navy"], a, s, hl=DECK["skyd"], maxw=980, max_lines=2)
    y = 960 + he_ + 40
    if S.get("sub"):
        a, s = PP(t, tb, S, bounce=2.0); hs = block_h(S["sub"], 76, 800, 960, 2)
        block(c, S["sub"], 76, 540, y + hs / 2, DECK["skyd"], a, s, 800, hl=P["gold"], maxw=960, max_lines=2); y += hs + 30
    if S.get("he"):
        ha = ramp(t, tb + 0.2, tb + 0.5) if S.get("sub") else ramp(t, te + 0.2, te + 0.5)
        T(c, S["he"], 58, 540, y + 40, P["gold_text"], ha, 1.0, 700, maxw=960)
    source(c, t, S)


def sc_qa(c, t, S):
    t0 = S["t0"]; ta = S["times"].get("a", t0 + 2.0); tw = S["times"].get("w", ta + 2.0)
    # question: speech card with a tail, top
    a, s = PP(t, t0 + 0.05, S)
    if S.get("label"): pill(c, S["label"], 54, 540, 340, DECK["mint"], DECK["navy"], a, s, w=800)
    q = S["q"]; hq = block_h(q, 96, 800, 820, 2); bh = hq + (90 if S.get("q_he") else 0) + 80; y = 410
    old = St.a; St.a *= a; c.save(); c.translate(540, y + bh / 2); c.scale(s, s); c.translate(-540, -(y + bh / 2))
    shadow_box(c, 80, y, 920, bh, 50, P["card"], stroke=DECK["sky"], sw=5, sh=8)
    sa(c, P["card"], St.a); c.move_to(220, y + bh - 3); c.line_to(200, y + bh + 50); c.line_to(290, y + bh - 3); c.close_path(); c.fill()
    sa(c, DECK["sky"], St.a); c.set_line_width(5); c.move_to(220, y + bh); c.line_to(200, y + bh + 50); c.line_to(290, y + bh); c.stroke()
    block(c, q, 96, 540, y + 40 + hq / 2, DECK["navy"], 1.0, 1.0, 800, hl=DECK["skyd"], maxw=820, max_lines=2)
    if S.get("q_he"): T(c, S["q_he"], 58, 540, y + 40 + hq + 50, P["gold_text"], 1.0, 1.0, 700, maxw=820)
    c.restore(); St.a = old
    y += bh + 110
    # principle
    if t >= ta - 0.1:
        a, s = PP(t, ta - 0.05, S, bounce=2.2); pill(c, f"Principle #{S['num']}", 64, 540, y + 20, P["gold"], P["white"], a, s, w=800)
        a, s = PP(t, ta + 0.25, S, s0=0.7, bounce=1.3); hp = block_h(S["answer"], 112, 900, 960, 2)
        block(c, S["answer"], 112, 540, y + 130 + hp / 2, DECK["navy"], a, s, hl=DECK["skyd"], maxw=960, max_lines=2)
        y += 130 + hp + 50
    if S.get("why") and t >= tw - 0.1:
        a, s = PP(t, tw - 0.05, S, bounce=2.0); hw = block_h(S["why"], 70, 700, 940, 3)
        block(c, S["why"], 70, 540, y + hw / 2, DECK["skyd"], a, s, 700, maxw=940, max_lines=3)
    source(c, t, S)


DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
def sc_week(c, t, S):
    t0 = S["t0"]; mode = S.get("mode", "student"); sp = mode == "speaker"
    a, s = PP(t, t0 + 0.05, S)
    pill(c, S.get("kicker", "ENGLISH SPEAKER" if sp else "ENGLISH STUDENT"), 64, 540, 340, DECK["mint"] if sp else P["silver"], DECK["navy"], a, s, w=900)
    if S.get("title"): block(c, S["title"], 96, 540, 470, DECK["navy"], a, s, 800, hl=DECK["skyd"], maxw=980, max_lines=1)
    # 7 day tiles
    x0, wtile, gap, ty0, htile = 64, 124, 10, 570, 320
    da, db = S["times"].get("d0", t0 + 0.5), S["times"].get("d6", t0 + 1.6)
    dt = [S["times"].get(f"d{k}", da + (db - da) * k / 6) for k in range(7)]
    lit = S.get("lit", 1)
    for k in range(7):
        x = x0 + k * (wtile + gap); on = sp and t >= dt[k] - 0.05 or (not sp and k == lit and t >= S["times"].get("lesson", t0 + 0.6))
        u = ease((t - dt[k] + 0.05) / 0.3) if sp else 1.0
        fill = DECK["skyd"] if on else (0.88, 0.9, 0.93, 1.0)
        rr(c, x, ty0, wtile, htile, 26); sa(c, fill, St.a * (1.0 if on else 0.9)); c.fill()
        T(c, DAYS[k], 44, x + wtile / 2, ty0 + 56, P["white"] if on else P["grey"], 1.0, 1.0, 800)
        if on:
            em = (S.get("day_emoji") or ["📺", "💻", "🎧", "📺", "💻", "🎧", "📖"])[k] if sp else "💻"
            draw_emoji(c, em, x + wtile / 2, ty0 + 190, 84 * (u if sp else 1.0))
        elif not sp:
            T(c, "No", 44, x + wtile / 2, ty0 + 160, P["grey"], 1.0, 1.0, 700); T(c, "English", 36, x + wtile / 2, ty0 + 215, P["grey"], 1.0, 1.0, 700)
    y = ty0 + htile + 70
    for k, it in enumerate(S.get("items", [])):
        tk = S["times"].get(f"i{k}", t0 + 1.0 + 0.9 * k)
        if t < tk - 0.1: continue
        a, s = PP(t, tk - 0.05, S, bounce=2.2)
        old = St.a; St.a *= a; c.save(); c.translate(540, y + 90); c.scale(s, s); c.translate(-540, -(y + 90))
        shadow_box(c, 80, y, 920, 180, 56, P["card"], stroke=DECK["sky"] if sp else P["silver"], sw=4, sh=6)
        draw_emoji(c, it.get("icon", ""), 190, y + 90, 96)
        T(c, it["en"], 84, 590, y + 90, DECK["navy"], 1.0, 1.0, 800, hl=DECK["skyd"], maxw=680)
        c.restore(); St.a = old; y += 205
    source(c, t, S)
