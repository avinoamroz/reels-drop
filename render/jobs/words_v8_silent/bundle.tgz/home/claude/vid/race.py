import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, subprocess
HB=lambda x:x
matplotlib.rcParams["font.family"]=["Inter","Liberation Sans","DejaVu Sans"]
from matplotlib.patches import FancyBboxPatch

W,H,FPS=1080,1920,30
# Estimated vocabulary (dictionary-based), keyframes (year, words). None before birth.
L = {
 "Hebrew":   ("#3b82f6",[(-1100,0),(-1000,1500),(-850,4000),(-400,8000),(200,15000),(1000,30000),(1880,35000),(1922,45000),(1948,60000),(2026,80000)], ""),
 "Aramaic":  ("#a855f7",[(-1000,0),(-900,2000),(-500,6000),(200,15000),(700,20000),(2026,20000)], ""),
 "Arabic":   ("#10b981",[(300,0),(500,20000),(650,40000),(791,60000),(1290,80000),(1800,85000),(2026,120000)], ""),
 "Russian":  ("#ef4444",[(900,0),(1000,10000),(1400,20000),(1700,40000),(1800,50000),(1866,200000),(2026,230000)], ""),
 "Hindi":    ("#ec4899",[(1000,0),(1200,10000),(1400,20000),(1600,35000),(1800,45000),(1929,93000),(2026,150000)], ""),
 "English":  ("#f59e0b",[(450,0),(600,20000),(1066,50000),(1200,40000),(1400,55000),(1500,60000),(1650,100000),(1755,120000),(1828,150000),(1900,300000),(1928,400000),(2000,615000),(2026,650000)], ""),
}
HEB={"Hebrew":"עברית","Aramaic":"ארמית","Arabic":"ערבית","Russian":"רוסית","Hindi":"הינדי","English":"אנגלית"}
EVENTS=[(-1100,"Hebrew is born: the very first words","העברית נולדת: המילים הראשונות"),
 (-1000,"Oldest Hebrew inscriptions + Aramaic appears","הכתובות העבריות הקדומות, והארמית מופיעה"),
 (-500,"Aramaic becomes the language of empires","ארמית הופכת לשפת האימפריות"),
 (200,"The Mishnah expands Hebrew","המשנה מרחיבה את העברית"),
 (450,"Anglo-Saxons bring English to Britain","האנגלו-סקסים מביאים את האנגלית לבריטניה"),
 (791,"First Arabic dictionary: Kitab al-Ayn","המילון הערבי הראשון: כתאב אל-עין"),
 (1066,"Norman Conquest: French floods English","הכיבוש הנורמני: הצרפתית מציפה את האנגלית"),
 (1250,"Amir Khusrau writes in early Hindi","אמיר ח'וסרו כותב בהינדי מוקדמת"),
 (1290,"Lisan al-Arab: 80,000 Arabic entries","לסאן אל-ערב: 80,000 ערכים בערבית"),
 (1500,"Printing + Renaissance: English borrows like crazy","הדפוס והרנסנס: האנגלית שואלת מילים בלי סוף"),
 (1600,"Shakespeare coins hundreds of words","שייקספיר ממציא מאות מילים"),
 (1755,"Johnson's Dictionary of English","המילון של ג'ונסון לאנגלית"),
 (1866,"Dahl's Russian dictionary: 200,000 words","המילון הרוסי של דאל: 200,000 מילים"),
 (1881,"Ben-Yehuda revives spoken Hebrew","בן-יהודה מחייה את העברית המדוברת"),
 (1928,"Oxford English Dictionary completed","מילון אוקספורד הושלם"),
 (1929,"Hindi Shabdsagar: 93,000 words","מילון הינדי שבדסאגאר: 93,000 מילים"),
 (1948,"Hebrew becomes a state language","העברית הופכת לשפת מדינה"),
 (1950,"Hindi becomes India's official language","הינדי הופכת לשפה הרשמית של הודו"),
 (2000,"Internet age: new words every day","עידן האינטרנט: מילים חדשות כל יום")]
# nonlinear timeline: (year, seconds)
TL=[(-1150,0),(-1000,2.5),(0,9),(1500,20),(2026,40)]
HOLD=5
ty=[t for _,t in TL]; yy=[y for y,_ in TL]
N=int((TL[-1][1]+HOLD)*FPS)

def val(pts,y):
    if y<pts[0][0]: return None
    if y>pts[-1][0]:
        return pts[-1][1] if pts[-1][1]>0 or y<=pts[-1][0] else None
    xs=[p[0] for p in pts]; vs=[p[1] for p in pts]
    v=np.interp(y,xs,vs)
    if pts[-1][1]==0 and y>=pts[-1][0]: return None
    return v

def fmt_year(y):
    y=int(round(y)); return f"{-y} BCE" if y<0 else (f"{y} CE" if y<1000 else str(y))

names=list(L); pos={n:None for n in names}
fig=plt.figure(figsize=(W/100,H/100),dpi=100); fig.patch.set_facecolor("#0b1020")
ff=subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgba","-s",f"{W}x{H}","-r",str(FPS),"-i","-",
 "-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-preset","medium","/home/claude/vid/words_race_v5_silent.mp4"],stdin=subprocess.PIPE)
for f in range(N):
    t=min(f/FPS,TL[-1][1]); year=np.interp(t,ty,yy)
    vals={n:val(L[n][1],year) for n in names}
    alive=[n for n in names if vals[n] is not None]
    ranked=sorted(alive,key=lambda n:-vals[n])
    for i,n in enumerate(ranked):
        target=i; pos[n]=target if pos[n] is None else pos[n]+(target-pos[n])*0.15
    for n in names:
        if vals[n] is None: pos[n]=None
    fig.clf(); fig.patch.set_facecolor("#0b1020")
    fig.text(0.5,0.945,"How many words does",ha="center",color="white",fontsize=50,fontweight="bold")
    fig.text(0.5,0.915,"each language have?",ha="center",color="white",fontsize=50,fontweight="bold")
    fig.text(0.5,0.877,HB("כמה מילים יש בכל שפה?"),ha="center",color="#ffd166",fontsize=46,fontweight="bold")
    fig.text(0.5,0.85,"3,000 years of words  |  "+HB("שלושת אלפים שנה של מילים"),ha="center",color="#9aa4bf",fontsize=24)
    ax=fig.add_axes([0.08,0.33,0.84,0.47]); ax.set_facecolor("#0b1020")
    mx=max([vals[n] for n in alive]+[5000]); xmax=mx*1.32
    ax.set_xlim(0,xmax); ax.set_ylim(5.6,-0.6)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_yticks([]); ax.xaxis.tick_top(); ax.tick_params(axis="x",colors="#5c6680",labelsize=18)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v,p:f"{int(v/1000)}k" if v>=1000 else str(int(v))))
    ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(4)); ax.grid(axis="x",color="#1e2740",lw=1.5); ax.set_axisbelow(True)
    for n in alive:
        v=vals[n]; p=pos[n]; c=L[n][0]
        ax.barh(p,v,height=0.78,color=c)
        inside = v > xmax*0.32
        lab=n+"  "+HB(HEB[n])
        if inside: ax.text(v-xmax*0.015,p,lab,va="center",ha="right",color="#0b1020",fontsize=30,fontweight="bold")
        else: ax.text(v+xmax*0.015,p-0.0,lab,va="center",ha="left",color=c,fontsize=29,fontweight="bold")
        num=f"{int(round(v,-2)):,}"
        if inside: ax.text(v+xmax*0.015,p,num,va="center",ha="left",color="white",fontsize=30)
        else: ax.text(v+xmax*0.015,p+0.33,num,va="center",ha="left",color="white",fontsize=22)
    fig.text(0.92,0.225,fmt_year(year),ha="right",color="white",fontsize=92,fontweight="bold",alpha=0.9)
    fig.text(0.92,0.198,HB("לפני הספירה") if year<0 else HB("לספירה"),ha="right",color="#ffd166",fontsize=36,fontweight="bold")
    ev=[e for e in EVENTS if e[0]<=year]
    if ev:
        fig.text(0.5,0.143,ev[-1][1],ha="center",color="#ffd166",fontsize=29,fontweight="bold")
        fig.text(0.5,0.112,HB(ev[-1][2]),ha="center",color="white",fontsize=29,fontweight="bold")
    if not alive:
        fig.text(0.5,0.56,"Before writing:\nno recorded words\n\nלפני הכתב:\nאין מילים מתועדות",ha="center",color="#9aa4bf",fontsize=36)
    fig.text(0.5,0.055,"Estimates based on major historical dictionaries. Treat as orders of magnitude.",ha="center",color="#5c6680",fontsize=18)
    fig.text(0.5,0.035,HB("הערכות לפי מילונים היסטוריים מרכזיים. סדרי גודל בלבד."),ha="center",color="#5c6680",fontsize=18)
    fig.canvas.draw(); ff.stdin.write(fig.canvas.buffer_rgba().tobytes())
ff.stdin.close(); ff.wait(); print("done",N)
