"""'How many words does each language have?' race, narrated version (v6).
Fork of /home/claude/vid/race.py with: hook card at frame 0, safe-zone layout, all text >= 36 px,
slower timeline for narration, fact fixes, and end cards (3,000 words, 7-minute line, end card). v8: hook 1.2 s with the race moving under it, no Comment CTA, fluency card without sharing the recording.

  nice -n 15 python3 words_race_narr.py                 full silent render
  nice -n 15 python3 words_race_narr.py --qa 0,10,40    QA frames + bbox report
"""
import numpy as np, matplotlib, sys, os
matplotlib.use("Agg")
import matplotlib.pyplot as plt, subprocess
from matplotlib.patches import FancyBboxPatch, Rectangle
matplotlib.rcParams["font.family"] = ["Inter", "Liberation Sans", "DejaVu Sans"]
OUT = "/home/claude/vid/narr/words_race_v8_silent.mp4"; QA_DIR = "/home/claude/vid/narr/qa_words_v8"
QA = [float(x) for x in sys.argv[sys.argv.index("--qa") + 1].split(",")] if "--qa" in sys.argv else None
W, H, FPS = 1080, 1920, 30; BG = "#0b1020"; GOLD = "#ffd166"; SUBC = "#b4bccf"; DISCC = "#8a93ad"; MINPT = 26
# Estimated vocabulary, keyframes (year, words). Orders of magnitude only.
L = {
 "Hebrew":  ("#3b82f6", [(-1100,0),(-1000,1500),(-850,4000),(-400,8000),(200,15000),(1000,30000),(1880,35000),(1922,45000),(1948,60000),(2026,80000)]),
 "Aramaic": ("#a855f7", [(-1000,0),(-900,2000),(-500,6000),(200,15000),(700,20000),(2026,20000)]),
 # fix: Taj al-Arus (al-Zabidi, completed 1774) already had about 120,000 entries
 "Arabic":  ("#10b981", [(300,0),(500,20000),(650,40000),(791,60000),(1290,80000),(1774,120000),(2026,120000)]),
 "Russian": ("#ef4444", [(900,0),(1000,10000),(1400,20000),(1700,40000),(1800,50000),(1866,200000),(2026,230000)]),
 "Hindi":   ("#ec4899", [(1000,0),(1200,10000),(1400,20000),(1600,35000),(1800,45000),(1929,93000),(2026,150000)]),
 "English": ("#f59e0b", [(450,0),(600,20000),(1066,50000),(1200,40000),(1400,55000),(1500,60000),(1650,100000),(1755,120000),(1828,150000),(1900,300000),(1928,400000),(2000,615000),(2026,650000)]),
}
HEB = {"Hebrew": "עברית", "Aramaic": "ארמית", "Arabic": "ערבית", "Russian": "רוסית", "Hindi": "הינדי", "English": "אנגלית"}
EVENTS = [(-1100, "Hebrew's first words", "המילים העבריות הראשונות"),
 (-1000, "Hebrew inscriptions, Aramaic appears", "כתובות עבריות, והארמית מופיעה"),
 (-500, "Aramaic: the language of empires", "ארמית: שפת האימפריות"),
 (200, "The Mishnah expands Hebrew", "המשנה מרחיבה את העברית"),
 (450, "Anglo-Saxons bring English to Britain", "האנגלו-סקסים מביאים את האנגלית"),
 (791, "First Arabic dictionary: Kitab al-Ayn", "המילון הערבי הראשון: כתאב אל-עין"),
 (1066, "Norman Conquest: French floods English", "הכיבוש הנורמני: צרפתית מציפה את האנגלית"),
 (1290, "Lisan al-Arab: 80,000 Arabic entries", "לסאן אל-ערב: 80,000 ערכים בערבית"),
 (1500, "Printing: English borrows widely", "הדפוס: האנגלית שואלת מכל מקום"),
 (1600, "Shakespeare coins hundreds of words", "שייקספיר ממציא מאות מילים"),
 (1755, "Johnson's Dictionary of English", "המילון של ג'ונסון לאנגלית"),
 (1774, "Taj al-Arus: 120,000 Arabic entries", "תאג' אל-ערוס: 120,000 ערכים בערבית"),
 (1866, "Dahl's Russian dictionary: 200,000", "המילון הרוסי של דאל: 200,000 מילים"),
 (1881, "Ben-Yehuda revives spoken Hebrew", "בן-יהודה מחייה את העברית המדוברת"),
 (1928, "Oxford English Dictionary completed", "מילון אוקספורד הושלם"),
 (1948, "Hebrew becomes a state language", "העברית הופכת לשפת מדינה"),
 (2000, "Internet age: new words every day", "עידן האינטרנט: מילים חדשות כל יום")]
# nonlinear timeline (year, seconds), slowed for narration
TL = [(-1150,0),(-1100,1.3),(-1000,4.0),(300,8.5),(791,10.5),(1066,13.5),(1500,17.5),(1600,18.7),(1755,21.0),(1774,21.6),(1866,23.5),(1881,24.5),(1928,27.0),(1948,28.6),(2000,30.4),(2026,31.5)]
TOTAL = 50.0
HOOK_UNTIL = 1.2
CARD_A = (34.0, 39.2); CARD_B = (39.2, 46.7); CARD_C = (46.7, TOTAL)
ty = [t for _, t in TL]; yy = [y for y, _ in TL]; N = int(round(TOTAL * FPS))

def val(pts, y):
    if y < pts[0][0]: return None
    v = np.interp(y, [p[0] for p in pts], [p[1] for p in pts])
    return None if v <= 0 and y <= pts[0][0] else v
def fmt_year(y):
    y = int(round(y)); return f"{-y} BCE" if y < 0 else (f"{y} CE" if y < 1000 else str(y))
def ease(x): x = min(1, max(0, x)); return x * x * (3 - 2 * x)
TXT = []
def T(x, y, s, fs, **k):
    assert fs >= MINPT, (s, fs)
    t = fig.text(x, y, s, fontsize=fs, **k); TXT.append(t); return t
def card(a, lines, edge, box=(0.06, 0.33, 0.88, 0.42)):
    fig.patches.append(Rectangle((0, 0), 1, 1, transform=fig.transFigure, color="#050914", alpha=0.90 * a, zorder=50))
    fig.patches.append(FancyBboxPatch(box[:2], box[2], box[3], boxstyle="round,pad=0.01,rounding_size=0.03", transform=fig.transFigure,
                                      facecolor="#0f1a33", edgecolor=edge, lw=4, alpha=a, zorder=51))
    for (y, tx, cc, fz) in lines:
        T(0.5, y, tx, fz, ha="center", va="center", color=cc, fontweight="bold", alpha=a, zorder=52)
def fade(sec, a, b, fi=0.35, fo=0.35, last=False):
    if sec < a or sec >= b + (0 if last else fo): return 0
    x = ease((sec - a) / fi)
    return x if (last or sec < b) else x * (1 - (sec - b) / fo)

names = list(L); pos = {n: None for n in names}
fig = plt.figure(figsize=(W / 100, H / 100), dpi=100)
if QA is None:
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", OUT], stdin=subprocess.PIPE)
frames = range(N) if QA is None else [min(N - 1, int(s * FPS)) for s in QA]
for f in frames:
    TXT.clear(); sec = f / FPS
    t = min(sec, TL[-1][1]); year = np.interp(t, ty, yy)
    vals = {n: val(L[n][1], year) for n in names}
    alive = [n for n in names if vals[n] is not None and vals[n] > 0]
    ranked = sorted(alive, key=lambda n: -vals[n])
    for i, n in enumerate(ranked):
        pos[n] = i if (pos[n] is None or QA is not None) else pos[n] + (i - pos[n]) * 0.15
    for n in names:
        if n not in alive: pos[n] = None
    fig.clf(); fig.patch.set_facecolor(BG)
    T(0.5, 0.828, "Words in each language", 46, ha="center", color="white", fontweight="bold")
    T(0.5, 0.796, "כמה מילים יש בכל שפה?", 42, ha="center", color=GOLD, fontweight="bold")
    T(0.5, 0.769, "3,000 years of words  |  שלושת אלפים שנה של מילים", 27, ha="center", color=SUBC)
    ax = fig.add_axes([0.08, 0.39, 0.84, 0.355]); ax.set_facecolor(BG)
    mx = max([vals[n] for n in alive] + [5000]); xmax = mx * 1.32
    ax.set_xlim(0, xmax); ax.set_ylim(5.55, -0.55)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_yticks([]); ax.set_xticks([])
    for n in alive:
        v = vals[n]; p = pos[n]; c = L[n][0]
        ax.barh(p, v, height=0.80, color=c)
        lab = n + "  " + HEB[n]; num = f"{int(round(v, -2)):,}"
        if v > xmax * 0.45:
            TXT.append(ax.text(v - xmax * 0.015, p, lab, va="center", ha="right", color=BG, fontsize=31, fontweight="bold"))
            TXT.append(ax.text(v + xmax * 0.015, p, num, va="center", ha="left", color="white", fontsize=30, fontweight="bold"))
        else:
            TXT.append(ax.text(v + xmax * 0.015, p - 0.17, lab, va="center", ha="left", color=c, fontsize=30, fontweight="bold"))
            TXT.append(ax.text(v + xmax * 0.015, p + 0.27, num, va="center", ha="left", color="white", fontsize=27))
    if not alive:
        T(0.5, 0.62, "Before writing:", 36, ha="center", color=SUBC); T(0.5, 0.59, "no recorded words", 36, ha="center", color=SUBC)
        T(0.5, 0.54, "לפני הכתב:", 36, ha="center", color=SUBC); T(0.5, 0.51, "אין מילים מתועדות", 36, ha="center", color=SUBC)
    T(0.92, 0.330, fmt_year(year), 80, ha="right", color="white", fontweight="bold", alpha=0.92)
    T(0.92, 0.304, "לפני הספירה" if year < 0 else "לספירה", 32, ha="right", color=GOLD, fontweight="bold")
    ev = [e for e in EVENTS if e[0] <= year]
    if ev:
        T(0.5, 0.272, ev[-1][1], 30, ha="center", color=GOLD, fontweight="bold")
        T(0.5, 0.249, ev[-1][2], 30, ha="center", color="white", fontweight="bold")
    T(0.5, 0.225, "Estimates, based on major dictionaries.", 26, ha="center", color=DISCC)
    T(0.5, 0.204, "הערכות לפי מילונים מרכזיים. סדרי גודל בלבד.", 26, ha="center", color=DISCC)
    # hook
    if sec < HOOK_UNTIL + 0.4:
        a = 1.0 if sec < HOOK_UNTIL else max(0, 1 - (sec - HOOK_UNTIL) / 0.4)
        card(a, [(0.680, "Which language", "white", 82), (0.610, "has the most", "white", 82), (0.540, "words?", GOLD, 96),
                 (0.455, "לאיזו שפה יש", "white", 48), (0.405, "הכי הרבה מילים?", GOLD, 48)], "#60a5fa")
    # card A: 3,000 words
    a = fade(sec, *CARD_A)
    if a:
        k = int(round(3000 * ease((sec - CARD_A[0] - 0.3) / 1.6), -1))
        card(a, [(0.690, "About", "white", 60), (0.610, f"{k:,}", GOLD, 120), (0.530, "words cover most", "white", 56), (0.480, "everyday talk.", "white", 56),
                 (0.415, "3,000 מילים מכסות את רוב השיחה", GOLD, 40), (0.365, "Adolphs and Schmitt (2003)", SUBC, 26)], "#60a5fa")
    # card B: 7-minute line
    a = fade(sec, *CARD_B)
    if a:
        el = min(420, max(0, (sec - CARD_B[0] - 0.6) / 6.0 * 420))
        card(a, [(0.690, "Speak to yourself", "white", 60), (0.630, "in English.", "white", 60), (0.540, f"{int(el // 60)}:{int(el % 60):02d}", GOLD, 120),
                 (0.462, "Then explain it to a friend.", "white", 50), (0.405, "דברו עם עצמכם באנגלית 7 דקות,", GOLD, 40), (0.370, "ואז הסבירו את אותו רעיון לחבר", GOLD, 40)], GOLD)
    # card C: CTA
    a = fade(sec, *CARD_C, last=True)
    if a:
        card(a, [(0.670, "3,000 words.", GOLD, 96), (0.585, "7 minutes a day.", "white", 64), (0.500, "3,000 מילים, 7 דקות ביום", GOLD, 48), (0.420, "@expressenglishcom", SUBC, 40)], GOLD)
    fig.canvas.draw()
    if QA is not None:
        bad = []
        for tt in TXT:
            if not tt.get_text().strip() or tt.get_alpha() == 0: continue
            bb = tt.get_window_extent(); top = H - bb.y1; bot = H - bb.y0
            if bb.x0 < 70 or bb.x1 > 1010 or top < 260 or bot > 1540:
                bad.append(f"  OUT {tt.get_text()[:40]!r} x{bb.x0:.0f}-{bb.x1:.0f} y{top:.0f}-{bot:.0f}")
        print(f"t={sec:.1f}s year={year:.0f}", "OK" if not bad else "\n" + "\n".join(bad))
        os.makedirs(QA_DIR, exist_ok=True); fig.savefig(os.path.join(QA_DIR, f"qa_{sec:05.1f}.png"), dpi=100, facecolor=BG)
    else:
        ff.stdin.write(fig.canvas.buffer_rgba().tobytes())
if QA is None: ff.stdin.close(); ff.wait(); print("done", OUT, N / FPS, "s")
