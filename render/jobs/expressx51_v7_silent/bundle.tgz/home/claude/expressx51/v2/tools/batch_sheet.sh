#!/bin/bash
# usage: batch_sheet.sh OUTNAME DIR CLIP1 CLIP2 ...   (clip names without .MP4) -> thumbs/OUTNAME.jpg
cd /home/claude/expressx51/v2
OUT=$1; DIR=$2; shift 2
for c in "$@"; do /home/claude/expressx51/v2/tools/sheet_clip.sh "$DIR/$c.MP4" $c; done
python3 - "$OUT" "$@" <<'EOF'
from PIL import Image, ImageDraw
import sys
out, names = sys.argv[1], sys.argv[2:]; ims = []
for n in names:
    im = Image.open(f"thumbs/{n}_01.jpg"); bb = im.convert('L').point(lambda v: 255 if v > 8 else 0).getbbox()
    im = im.crop((0, 0, 1600, bb[3])); d = ImageDraw.Draw(im); d.rectangle([1490, 0, 1600, 30], fill='red'); d.text((1495, 8), n, fill='white'); ims.append(im)
H = sum(i.size[1] for i in ims); o = Image.new('RGB', (1600, H)); y = 0
for i in ims: o.paste(i, (0, y)); y += i.size[1]
o.save(f"thumbs/{out}.jpg", quality=80); print(out, o.size)
EOF
