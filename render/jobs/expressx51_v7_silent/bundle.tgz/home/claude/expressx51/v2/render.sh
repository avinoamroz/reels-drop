#!/bin/bash
# v2 resumable low-memory chunked render: plate first, then one 300-frame chunk per process (1 x264 thread, nice 15), then concat + music (+VO) + 48 kHz mux
# usage: ./render.sh                              -> expressx51_invite_v4_music.mp4 (music only)
#        ./render.sh VO.wav [manual_segs.json]    -> expressx51_invite_v4_vo.mp4 (segs: 7 [start,end] pairs, one per tts.txt line)
cd /home/claude/expressx51/v2
VO="$1"; SEGS="${2:-manual_segs.json}"; ARGS=""; CHD=chunks; LOG=render.log
if [ -n "$VO" ]; then ARGS="--vo $VO --segs $SEGS"; CHD=chunksvo; LOG=render_vo.log; rm -rf chunksvo expressx51_invite_v4_vo_video.mp4
else rm -rf chunks expressx51_invite_v4_music_video.mp4; fi
TEND=$(nice -n 15 python3 engine_x51v2.py $ARGS --plate_only 2>>$LOG | tee -a $LOG | sed -n 's/.*T_END \([0-9.]*\).*/\1/p')
NCH=$(python3 -c "import math,sys;print(math.ceil(round(float(sys.argv[1])*30)/300))" $TEND)
echo "T_END $TEND chunks: $NCH" >> $LOG
for c in $(seq 0 $((NCH-1))); do
  f=$CHD/c$(printf %02d $c).mp4
  for try in 1 2 3; do
    [ -s "$f.ok" ] && break
    nice -n 15 python3 engine_x51v2.py $ARGS --chunk $c >> $LOG 2>&1 && echo ok > "$f.ok" && echo "chunk $c ok" >> $LOG && break
    echo "chunk $c failed try $try" >> $LOG; sleep 20
  done
  [ -s "$f.ok" ] || { echo "ABORT chunk $c" >> $LOG; exit 1; }
done
nice -n 15 python3 engine_x51v2.py $ARGS --audio_only >> $LOG 2>&1 && echo "ALLDONE" >> $LOG || echo "AUDIO FAILED" >> $LOG
