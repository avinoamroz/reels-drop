"""51st ExpressX invite reel v2 (1080x1920, 30 fps, 48 kHz): REAL VIDEO B-ROLL of past ExpressX events + big type.
Base: /home/claude/expressx51/engine_x51.py (v1, photos). Same CLI and chunked low-memory pipeline, new visual approach:
  1. a B-roll PLATE (plate.mp4) is cut on the music beat from the 1080x1920 mezzanine cuts in src/ (see shots.json)
  2. each frame: plate frame -> gentle navy grade + slow push-in -> legibility gradient -> text layer (2x supersampled)
7 cards, one per tts.txt line (one line per card, no SSML breaks): hook | talks | stage | people | date | venue | cta.
Guidelines: /home/claude/video-guidelines.md (local copy of the claude.ai Project doc claude/video-guidelines.md).
usage: nice -n 15 python3 engine_x51v2.py [--snaps 0,3,12] [--chunk N] [--plate_only] [--audio_only] [--vo VO.wav] [--segs manual_segs.json]
  --vo   : narrated version. Cards re-timed to the voice from --segs ({"segs": [[start,end] x 7]}, one pair per tts.txt line),
           else vo/align.py, else uniform stretch. Shot cuts inside each card are re-snapped to the music beat grid.
Rules: headline 110 to 160 px, body 64 to 84, Hebrew 56 to 72, nothing under 36, text inside y 260 to 1540 and x 70 to 1010,
max 12 English words and 3 body lines per card, each card 3 s or more, white or yellow text only, no em or en dashes anywhere."""
import sys, os, json, math, subprocess, argparse, re, hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ap = argparse.ArgumentParser(); ap.add_argument("--vo"); ap.add_argument("--snaps"); ap.add_argument("--chunk", type=int, default=-1)
ap.add_argument("--audio_only", action="store_true"); ap.add_argument("--plate_only", action="store_true"); ap.add_argument("--segs")
A = ap.parse_args()
D = "/home/claude/expressx51/v2"; D1 = "/home/claude/expressx51"; HERE = "/home/claude/vid"; S = 2; W, H, FPS = 1080, 1920, 30
TAG = "expressx51_invite_v4"; CX = 540
MUSIC = f"{D}/music_house.py"; BPM = 120.0; BEAT = 60.0 / BPM   # v3: deep house bed, 120 BPM (v2 used comedians_compare/music_comedy.py "skip" at 116)
SIL = f"{D}/{TAG}_music_video.mp4"; FINAL = f"{D}/{TAG}_music.mp4"; NARR = f"{D}/tts.txt"; SNAPDIR = f"{D}/qa"
SEGS = A.segs or f"{D}/manual_segs.json"
LINES = [l.strip() for l in open(NARR).read().splitlines() if l.strip()]

def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY = hx("#163261"); DEEP = hx("#0E1E3A"); ROYAL = hx("#2749D3"); SKY = hx("#45A4DD"); WHITE = hx("#FFFFFF")
YEL = hx("#F5D000"); GOLD = hx("#D9B45A"); INK = hx("#0B1A36")
FONTS = {"pop7": "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf", "pop5": "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf",
         "serif": f"{D1}/fonts/Gloock-Regular.ttf", "he": f"{HERE}/fonts/Heebo-800.ttf", "he7": f"{HERE}/fonts/Heebo-700.ttf"}
_fc = {}
def font(sz, fam="pop7"):
    k = (max(1, int(sz * S)), fam)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONTS[fam], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]

# ---------------------------------------------------------------- timeline. Music version: every cut on the 116 BPM beat grid
BEATS = ["hook", "talks", "stage", "people", "date", "venue", "cta"]
NBEATS = [7, 6, 6, 6, 7, 6, 11]                  # 49 beats = 25.34 s
# shots per card: (mezzanine clip in src/, weight in beats, blurred background?)
SHOTS = {"hook":   [("sort_crowd_x", 4, 0), ("sort_arrive", 3, 0)],
         # v4: fast speaker montage, 7 different speakers from different ExpressX nights, 2 beats (1.0 s) each, speaker + audience in frame
         "talks":  [("spk_gil", 2, 0), ("spk_haim", 2, 0), ("spk_tess", 2, 0)],
         "stage":  [("spk_levi", 2, 0), ("spk_levy", 2, 0), ("spk_yonat", 2, 0)],
         "people": [("spk_karin", 2, 0), ("sort_wide_network", 4, 0)],
         "date":   [("sort_wide_talk2", 7, 1)],
         "venue":  [("sort_wide_room", 6, 1)],
         "cta":    [("sort_crowd_x", 11, 1)]}
assert len(LINES) == len(BEATS), (len(LINES), len(BEATS))
TL = [(0, 0.0)]
for i, nb in enumerate(NBEATS): TL.append((i + 1, TL[-1][1] + nb * BEAT))
T_END = TL[-1][1]
VO = A.vo; OUTFILE = FINAL
if VO:
    OUTFILE = f"{D}/{TAG}_vo.mp4"; SIL = f"{D}/{TAG}_vo_video.mp4"
    vdur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", VO], capture_output=True, text=True).stdout)
    segs = None
    if os.path.exists(SEGS):
        segs = json.load(open(SEGS))["segs"]
        if len(segs) != len(BEATS): print(f"{SEGS}: {len(segs)} segs, need {len(BEATS)}; ignoring"); segs = None
    if segs is None:
        try:
            lt = f"{D}/{TAG}_lines.txt"; open(lt, "w").write("\n".join(LINES) + "\n")
            aj = f"{D}/{TAG}_align.json"; subprocess.run(["python3", f"{HERE}/vo/align.py", VO, lt, aj], check=True)
            J = json.load(open(aj)); segs = J["segs"]
            if len(J.get("bad", [])) > len(segs) // 3 or len(segs) != len(BEATS): segs = None
        except Exception as e: print("alignment failed, stretching uniformly:", e)
    if segs:
        st = [max(0.0, a_ - 0.2) for a_, _ in segs]; st[0] = 0.0
        TL = [(k, st[k]) for k in range(len(BEATS))] + [(len(BEATS), max(vdur, segs[-1][1]) + 2.2)]
    else:
        k = (vdur + 2.2) / T_END; TL = [(b, t * k) for b, t in TL]
    T_END = TL[-1][1]
    short = [BEATS[i] for i in range(len(BEATS)) if TL[i + 1][1] - TL[i][1] < 2.0]
    if short: print("WARN cards under 2 s with this VO:", short)
TB = [t for _, t in TL]; N = int(round(T_END * FPS))
def time_of(b): return float(np.interp(b, [x for x, _ in TL], TB))

def snap(t): return round(t / BEAT) * BEAT
def build_cuts():
    """[(clip, t0, t1, blur)] covering 0..T_END; inner cuts snapped to the beat grid, kept 1.2 s or longer"""
    cuts = []
    for k, b in enumerate(BEATS):
        c0, c1 = TB[k], TB[k + 1]; sh = SHOTS[b]; tot = sum(w for _, w, _ in sh); t = c0
        for j, (clip, w, bl) in enumerate(sh):
            if j == len(sh) - 1: e = c1
            else:
                e = c0 + (c1 - c0) * sum(x[1] for x in sh[:j + 1]) / tot; es = snap(e)
                if es - t >= 0.9 and c1 - es >= 0.9: e = es
            cuts.append((clip, t, e, bl)); t = e
    return cuts
CUTS = build_cuts()
def frame_of(t): return int(round(t * FPS))
def cut_at(t):
    f = frame_of(t)
    for i, (c, a, b, bl) in enumerate(CUTS):
        if frame_of(a) <= f < frame_of(b): return i
    return len(CUTS) - 1

def smooth(u): u = max(0.0, min(1.0, u)); return u * u * (3 - 2 * u)
def ramp(x, w=0.3): return max(0.0, min(1.0, x / w))
def back(u):
    u = max(0.0, min(1.0, u)); c1 = 1.9; return 1 + (c1 + 1) * (u - 1) ** 3 + c1 * (u - 1) ** 2
def pop(t, t0, dt, w=0.34):
    u = (t - t0 - dt) / w
    if u <= 0: return 0.0, 0.88
    return ramp(u, 0.5), 0.88 + 0.12 * back(u)

# ---------------------------------------------------------------- B-roll plate (ffmpeg, one segment per cut, then concat)
PLATE_KEY = hashlib.md5(json.dumps([(c, round(a, 3), round(b, 3), bl) for c, a, b, bl in CUTS]).encode()).hexdigest()[:10]
PLATE = f"{D}/plate_{'vo' if VO else 'mus'}_{PLATE_KEY}.mp4"
def clip_len(c): return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f"{D}/src/{c}.mp4"], capture_output=True, text=True).stdout)
def build_plate():
    if os.path.exists(PLATE): return
    pd = f"{D}/plate_parts"; os.makedirs(pd, exist_ok=True); lst = []
    for i, (c, a, b, bl) in enumerate(CUTS):
        nf = frame_of(b) - frame_of(a); need = nf / FPS; L = clip_len(c) - 0.05
        sp = min(1.0, L / need)                                    # slow down only if the shot is longer than the source
        src_need = need * sp; ss = max(0.0, (L - src_need) / 2)
        vf = f"setpts=PTS/{sp:.5f}" + (",gblur=sigma=22:steps=2" if bl else "") + f",fps={FPS},trim=end_frame={nf},format=yuv420p"
        o = f"{pd}/p{i:02d}.mp4"
        subprocess.run(["nice", "-n", "15", "ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", f"{ss:.3f}", "-t", f"{src_need + 0.2:.3f}", "-i", f"{D}/src/{c}.mp4",
                        "-an", "-vf", vf, "-c:v", "libx264", "-threads", "1", "-preset", "veryfast", "-crf", "12", "-x264-params", "rc-lookahead=10", o], check=True)
        lst.append(o); print(f"plate part {i} {c} {a:.2f}-{b:.2f} speed {sp:.2f} in {ss:.2f}", flush=True)
    open(f"{pd}/list.txt", "w").write("".join(f"file '{p}'\n" for p in lst))
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"{pd}/list.txt", "-c", "copy", PLATE], check=True)
    for p in lst: os.remove(p)
    print("plate", PLATE)

class PlateReader:
    """sequential raw RGB frames from the plate starting at frame f0 (one ffmpeg, 1 thread)"""
    def __init__(self, f0):
        self.f = f0
        self.p = subprocess.Popen(["ffmpeg", "-nostdin", "-v", "error", "-threads", "1", "-ss", f"{f0 / FPS:.4f}", "-i", PLATE, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                                  stdout=subprocess.PIPE, bufsize=W * H * 3)
        self.last = None
    def read(self):
        b = self.p.stdout.read(W * H * 3)
        if len(b) == W * H * 3: self.last = np.frombuffer(b, np.uint8).reshape(H, W, 3)
        self.f += 1; return self.last
    def close(self):
        try: self.p.stdout.close(); self.p.kill()
        except Exception: pass

# ---------------------------------------------------------------- grade + push-in + legibility gradient
NAVYF = np.array(NAVY[:3], np.float32); DEEPF = np.array(DEEP[:3], np.float32)
YY = (np.arange(H, dtype=np.float32) / H)[:, None, None]
def band(c, half, peak):
    """vertical darkening profile centred at y=c (px), flat core of +-half, soft 260 px shoulders"""
    y = np.arange(H, dtype=np.float32); d = np.clip((np.abs(y - c) - half) / 260.0, 0, 1)
    return (peak * (1 - d * d * (3 - 2 * d)))[:, None, None]
VIG = None
def grade(arr, t, ci):
    global VIG
    c, a, b, bl = CUTS[ci]
    u = (t - a) / max(0.5, b - a); z = 1.0 + 0.055 * smooth(u) if not bl else 1.03 + 0.03 * u   # slow push-in per shot
    im = Image.fromarray(arr)
    if z > 1.001:
        cw, ch = W / z, H / z; x0, y0 = (W - cw) / 2, (H - ch) * 0.45
        im = im.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + cw, y0 + ch))
    x = np.asarray(im, np.float32) / 255.0
    lum = (0.299 * x[..., 0] + 0.587 * x[..., 1] + 0.114 * x[..., 2])[..., None]
    x = lum + (x - lum) * 0.86                                         # gentle desaturation
    x = np.clip((x - 0.5) * 1.06 + 0.5, 0, 1)                          # a touch of contrast
    k = 0.30 * (1 - lum) ** 1.6                                        # shadows lean navy, highlights stay clean
    x = x * (1 - k) + (NAVYF / 255.0) * k
    x[..., 2] = np.clip(x[..., 2] * 1.04 + 0.01, 0, 1); x[..., 0] *= 0.97   # cool shift
    if VIG is None:
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32); VIG = (1 - 0.28 * (((xx - W / 2) / (W * 0.75)) ** 2 + ((yy - H / 2) / (H * 0.75)) ** 2))[..., None]
    x *= VIG
    return x

GRAD = {}
def legibility(x, b):
    """dark gradient behind each card's text block (blend towards deep navy)"""
    if b not in GRAD:
        GRAD[b] = {"hook": band(900, 300, 0.66), "talks": band(1300, 170, 0.66), "stage": band(1300, 170, 0.66), "people": band(1300, 170, 0.66),
                   "date": band(820, 330, 0.68), "venue": band(950, 420, 0.68), "cta": band(1000, 430, 0.68)}[b]
    g = GRAD[b]; return x * (1 - g) + (DEEPF / 255.0) * g

# ---------------------------------------------------------------- drawing helpers (text drawn on a 2x layer)
OVER = set(); SIZES = []
def txt(d, x, y, s, sz, col, fam="pop7", anchor="mm", maxw=940, alpha=1.0, spacing=0, nominal=None):
    SIZES.append((s, nominal or sz, y))
    if alpha <= 0.01: return
    f = font(sz, fam)
    wpx = f.getlength(s) / S + spacing * (len(s) - 1)
    if maxw and wpx > maxw and s not in OVER: OVER.add(s); print(f"WARN overflow {s!r} {wpx:.0f}>{maxw}")
    fill = col[:3] + (int(col[3] * alpha),)
    if spacing:
        x0 = x - wpx / 2
        for ch in s: d.text((x0 * S, y * S), ch, font=f, fill=fill, anchor="lm"); x0 += f.getlength(ch) / S + spacing
        return
    d.text((x * S, y * S), s, font=f, fill=fill, anchor=anchor)
def A_(c, a): return c[:3] + (int(c[3] * max(0, min(1, a))),)

def brush_x(d, cx, cy, size, col, a=1.0, prog=1.0, seed=3):
    """hand-drawn X: two tapered, slightly curved brush strokes (from v1). prog 0..1 draws stroke 1 then stroke 2"""
    if a <= 0.01 or prog <= 0: return
    rng = np.random.default_rng(seed)
    strokes = [((-0.40, -0.50), (0.02, 0.02), (0.44, 0.52), 0.20, 0.09), ((0.42, -0.50), (0.04, -0.02), (-0.38, 0.54), 0.17, 0.08)]
    for k, (p0, pm, p1, w0, w1) in enumerate(strokes):
        pr = max(0.0, min(1.0, prog * 2 - k))
        if pr <= 0: continue
        n = 26; ts = np.linspace(0, pr, n)
        P = np.array([(1 - u) ** 2 * np.array(p0) + 2 * (1 - u) * u * np.array(pm) + u ** 2 * np.array(p1) for u in ts])
        dP = np.gradient(P, axis=0); nr = np.stack([-dP[:, 1], dP[:, 0]], 1); nr /= np.linalg.norm(nr, axis=1, keepdims=True) + 1e-9
        wd = (w0 + (w1 - w0) * ts) * (1 + 0.10 * rng.standard_normal(n))
        L = P + nr * wd[:, None] / 2; R = P - nr * wd[:, None] / 2
        poly = [((cx + px * size) * S, (cy + py * size) * S) for px, py in np.vstack([L, R[::-1]])]
        d.polygon(poly, fill=A_(col, a))

def wordmark(d, cx, cy, sc=1.0, a=1.0, xprog=1.0):
    """51st (gold serif) + EXPRESS (white Poppins Bold) + hand-drawn X, centred on cx, baseline at cy. EXPRESS cap height ~ 0.7 * 70 * sc"""
    SIZES.append(("51st EXPRESS X", 70 * sc, cy))
    if a <= 0.01: return
    f1, f2 = font(66 * sc, "serif"), font(70 * sc, "pop7")
    w1, w2 = f1.getlength("51st") / S, f2.getlength("EXPRESS") / S; xs = 92 * sc; g = 20 * sc
    tot = w1 + g + w2 + 6 * sc + xs; x0 = cx - tot / 2
    if tot > 940 and "wordmark" not in OVER: OVER.add("wordmark"); print(f"WARN overflow wordmark {tot:.0f}")
    d.text((x0 * S, cy * S), "51st", font=f1, fill=A_(GOLD, a), anchor="ls")
    d.text(((x0 + w1 + g) * S, cy * S), "EXPRESS", font=f2, fill=A_(WHITE, a), anchor="ls")
    brush_x(d, x0 + w1 + g + w2 + 6 * sc + xs / 2, cy - 30 * sc, xs * 1.05, WHITE, a, xprog)

HEAD = 150; BODY = 80; HEB = 66            # uniform sizes: headline / body / Hebrew

# ---------------------------------------------------------------- cards
def sc_hook(d, t, t0, t1):                  # fully visible from frame 0
    wordmark(d, CX, 680, 1.6)
    txt(d, CX, 860, "You're", HEAD, WHITE)
    txt(d, CX, 1020, "invited.", HEAD, YEL)
    txt(d, CX, 1160, "אתם מוזמנים.", HEB + 4, WHITE, "he")

def two_line(d, t, t0, l1, l2, he):
    # v4: text sits low (y 1180 to 1460) so the speakers' faces stay clear in the montage
    a, s = pop(t, t0, 0.0); txt(d, CX, 1180, l1, HEAD * s, WHITE, alpha=a, nominal=HEAD)
    a, s = pop(t, t0, 0.12); txt(d, CX, 1335, l2, HEAD * s, YEL, alpha=a, nominal=HEAD)
    a, _ = pop(t, t0, 0.35); txt(d, CX, 1462, he, HEB, WHITE, "he", alpha=a)
def sc_talks(d, t, t0, t1): two_line(d, t, t0, "Talks", "in English.", "הרצאות באנגלית.")
def sc_stage(d, t, t0, t1): two_line(d, t, t0, "On a real", "stage.", "על במה אמיתית.")
def sc_people(d, t, t0, t1): two_line(d, t, t0, "By people", "like you.", "של אנשים כמוכם.")

def sc_date(d, t, t0, t1):                  # Canva look over blurred B-roll, part 1: what and when
    a, s = pop(t, t0, 0.0, 0.4); wordmark(d, CX, 560, 1.6 * s, a, xprog=ramp(t - t0 - 0.1, 0.45))
    a, s = pop(t, t0, 0.15); txt(d, CX, 700, "TUESDAY", BODY, WHITE, "pop7", alpha=a, spacing=12)
    a, s = pop(t, t0, 0.25, 0.42); txt(d, CX, 880, "03.11.26", 160 * s, YEL, "pop7", alpha=a, nominal=160)
    a, s = pop(t, t0, 0.5); txt(d, CX, 1050, "19:00 to 22:00", BODY * s, WHITE, alpha=a, nominal=BODY)
    a, _ = pop(t, t0, 0.75); txt(d, CX, 1170, "יום שלישי בערב", HEB + 4, YEL, "he", alpha=a)

def sc_venue(d, t, t0, t1):                 # part 2: where + save the date
    a, s = pop(t, t0, 0.0); txt(d, CX, 600, "ROTHSCHILD 57", 118 * s, WHITE, alpha=a, nominal=118)
    a, s = pop(t, t0, 0.15); txt(d, CX, 740, "TEL AVIV", BODY * s, WHITE, alpha=a, nominal=BODY, spacing=10)
    brush_x(d, CX, 935, 170, YEL, 1.0, ramp(t - t0 - 0.25, 0.4), seed=5)
    a, s = pop(t, t0, 0.45); pul = 0.95 + 0.05 * math.sin((t - t0) * 2 * math.pi / (2 * BEAT))
    txt(d, CX, 1150, "SAVE THE DATE!", 114 * s * (pul if a >= 1 else 1), YEL, alpha=a, nominal=114)
    a, _ = pop(t, t0, 0.7); txt(d, CX, 1295, "שמרו את התאריך!", HEB + 4, WHITE, "he", alpha=a)

def sc_cta(d, t, t0, t1):
    a, s = pop(t, t0, 0.0); txt(d, CX, 600, "Comment", HEAD * s, WHITE, alpha=a, nominal=HEAD)
    brush_x(d, CX, 838, 300, YEL, 1.0, ramp(t - t0 - 0.2, 0.5), seed=7)
    a, s = pop(t, t0, 0.7); txt(d, CX, 1075, "and I'll send", BODY * s, WHITE, alpha=a, nominal=BODY); txt(d, CX, 1170, "you the link", BODY * s, WHITE, alpha=a, nominal=BODY)
    a, _ = pop(t, t0, 1.0); txt(d, CX, 1290, "כתבו X בתגובות ואשלח קישור", HEB, YEL, "he", alpha=a)
    a, _ = pop(t, t0, 1.3); txt(d, CX, 1410, "03.11.26 · Rothschild 57", 64, WHITE, "pop5", alpha=a)

SCENES = [sc_hook, sc_talks, sc_stage, sc_people, sc_date, sc_venue, sc_cta]
assert len(SCENES) == len(BEATS) == len(NBEATS)
HIT_BEATS = [4, 6]

XF = 0.18   # text crossfade between cards (B-roll itself hard-cuts on the beat)
SH_OFF = int(4)
def text_layer(t):
    b = min(len(BEATS) - 1, max(k for k in range(len(BEATS)) if time_of(k) <= t + 1e-9))
    t0 = time_of(b); out = None
    layers = []
    if b > 0 and t - t0 < XF: layers.append((b - 1, 1 - smooth((t - t0) / XF)))
    layers.append((b, 1.0 if b == 0 else smooth((t - t0) / XF)))
    for k, a in layers:
        if a <= 0.005: continue
        lay = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        SCENES[k](d, t, time_of(k), time_of(k + 1)); lay = lay.reduce(S)
        if a < 0.999: lay.putalpha(lay.getchannel("A").point(lambda v: int(v * a)))
        out = lay if out is None else Image.alpha_composite(out, lay)
        del d
    return b, out

def frame(t, plate_rgb):
    ci = cut_at(t); b, lay = text_layer(t)
    x = grade(plate_rgb, t, ci)
    # card blend for the gradient: follow the text crossfade
    x = legibility(x, BEATS[b])
    im = Image.fromarray((np.clip(x, 0, 1) * 255).astype(np.uint8), "RGB").convert("RGBA")
    if lay is not None:
        sh = lay.getchannel("A").filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(v * 0.75))
        shadow = Image.new("RGBA", (W, H), DEEP[:3] + (0,)); shadow.putalpha(sh)
        im.alpha_composite(shadow, (0, SH_OFF)); im.alpha_composite(lay)
    return im.convert("RGB")

# ---------------------------------------------------------------- render
print("cuts:", [(c, round(a, 2), round(b - a, 2)) for c, a, b, _ in CUTS], flush=True)
build_plate()
if A.plate_only: print("T_END", round(T_END, 2)); sys.exit()
SNAPS = [float(x) for x in A.snaps.split(",")] if A.snaps else None
if SNAPS:
    os.makedirs(SNAPDIR, exist_ok=True)
    for s in SNAPS:
        pr = PlateReader(frame_of(s)); fr = pr.read(); pr.close()
        frame(s, fr).save(f"{SNAPDIR}/{TAG}_{s:05.2f}.png")
    print("snaps ->", SNAPDIR, "| T_END", round(T_END, 2), "| cards", [(BEATS[i], round(TB[i], 2), round(TB[i + 1] - TB[i], 2)) for i in range(len(BEATS))], "| overflow warnings:", len(OVER))
    bad = sorted({(s, round(z)) for s, z, y in SIZES if z < 36 or y < 260 or y > 1540})
    print("size/zone violations:", bad); sys.exit()
CH = 300; CHD = f"{D}/{'chunksvo' if VO else 'chunks'}"
if not A.audio_only:
    FR = range(N); out = SIL
    if A.chunk >= 0: os.makedirs(CHD, exist_ok=True); FR = range(A.chunk * CH, min(N, (A.chunk + 1) * CH)); out = f"{CHD}/c{A.chunk:02d}.mp4"
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
         "-c:v", "libx264", "-threads", "1", "-x264-params", "rc-lookahead=10", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "veryfast", "-r", str(FPS), out], stdin=subprocess.PIPE)
    pr = PlateReader(FR[0])
    for f in FR:
        ff.stdin.write(frame(f / FPS, pr.read()).tobytes())
        if f % 100 == 0: print(f"frame {f}/{N}", flush=True)
    pr.close(); ff.stdin.close(); ff.wait(); print("video", out, f"{T_END:.1f}s | overflow warnings:", len(OVER))
    if A.chunk >= 0: print("NCHUNKS", (N + CH - 1) // CH); sys.exit()

# ---------------------------------------------------------------- audio: upbeat bed (+VO), mux at 48 kHz
if A.audio_only and not os.path.exists(SIL):
    nch = (N + CH - 1) // CH; lst = f"{CHD}/list.txt"
    open(lst, "w").write("".join(f"file '{CHD}/c{c:02d}.mp4'\n" for c in range(nch)))
    subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", SIL], check=True)
mus = f"{D}/{TAG}_{'vo' if VO else 'mus'}_bed.wav"
sec_beats = ",".join(str(max(1, round((TB[k + 1] - TB[k]) / BEAT))) for k in range(len(BEATS)))
subprocess.run(["nice", "-n", "15", "python3", MUSIC, mus, f"{T_END:.2f}", f"{BPM:g}", sec_beats], check=True)
base = mus
if VO: base = f"{D}/{TAG}_mix.wav"; subprocess.run(["nice", "-n", "15", "python3", f"{HERE}/vo/mix.py", VO, mus, f"{T_END:.2f}", base], check=True)
af = f"afade=t=in:st=0:d=0.05,afade=t=out:st={max(0, T_END - 1.2):.2f}:d=1.2,loudnorm=I=-14:TP=-1.5:LRA=11"
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", SIL, "-i", base, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-af", af, "-c:a", "aac", "-ar", "48000", "-b:a", "192k",
                "-t", f"{T_END:.2f}", "-movflags", "+faststart", OUTFILE], check=True)
print("final", OUTFILE)
