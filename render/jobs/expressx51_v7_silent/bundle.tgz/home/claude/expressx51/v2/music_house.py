"""Original deep house / tech-house bed for the ExpressX 51 invite (v3). Fully synthesized in numpy, no samples.
usage: python3 music_house.py OUT.wav DUR BPM SECTION_BEATS
  SECTION_BEATS: comma list of card lengths in beats (v3: 7,6,6,6,7,6,11 = hook,talks,stage,people,date,venue,cta)
A minor, 120 BPM: Am9 - Fmaj7 - Dm9 - Esus4/E7. Tight four-on-floor kick with a 100-150 Hz knock, warm sub with
saturated upper harmonics (so phones hear the bassline), closed hats + offbeat open hats, clap on 2 and 4,
side-chained filtered minor chord stabs, dark detuned pad. Impact + filter dip on the date card, 12-beat noise riser
+ snare roll into the CTA, one beat of silence, then the drop on the CTA. 48 kHz stereo 16-bit."""
import sys, numpy as np, wave
from scipy.signal import butter, sosfilt

out_p = sys.argv[1]; DUR = float(sys.argv[2]); BPM = float(sys.argv[3]); SEC = [int(x) for x in sys.argv[4].split(",")]
SR = 48000; n = int(SR * DUR); B = 60.0 / BPM
L = np.zeros(n); R = np.zeros(n)
rng = np.random.default_rng(51)
bounds = np.cumsum([0] + SEC) * B                     # card start times
T_DATE, T_VENUE, T_CTA = bounds[4], bounds[5], bounds[6]

def sos(kind, f, order=2):
    f = np.atleast_1d(f); f = np.clip(f, 20, SR / 2 - 100)
    return butter(order, f if len(f) > 1 else f[0], btype=kind, fs=SR, output="sos")
def filt(x, kind, f, order=2): return sosfilt(sos(kind, f, order), x)
def place(sig, t, g=1.0, pan=0.0, buf=None):
    i = int(round(t * SR))
    if i >= n: return
    if i < 0: sig = sig[-i:]; i = 0
    j = min(n, i + len(sig)); s = sig[:j - i] * g
    if buf is None: L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
    else: buf[0][i:j] += s * (1 - pan); buf[1][i:j] += s * (1 + pan)
def env(N, a, d, sus=0.0, curve=4.0):
    t = np.arange(N) / SR; e = np.minimum(1, t / max(a, 1e-4)) * (sus + (1 - sus) * np.exp(-t * curve / max(d, 1e-4)))
    return e
def mtof(m): return 440 * 2 ** ((m - 69) / 12)
def saw(f, N, det=0.0, ph=0.0):
    t = np.arange(N) / SR; x = 0
    for k, dd in enumerate((-det, 0, det) if det else (0,)):
        x = x + 2 * ((t * f * (1 + dd) + ph + 0.37 * k) % 1.0) - 1
    return x / (3 if det else 1)

# arrangement flags per beat
NB = int(DUR / B) + 1
def sect(t):
    for k in range(len(SEC)):
        if bounds[k] <= t < bounds[k + 1]: return k
    return len(SEC) - 1
GAP0, GAP1 = T_CTA - B, T_CTA                              # one beat of silence before the drop

# ---------------------------------------------------------------- sidechain envelope (ducks pad, stabs, bass under each kick)
duck = np.ones(n)
for b in range(NB):
    t = b * B
    if GAP0 <= t < GAP1 or t >= DUR - 0.6: continue
    i = int(t * SR); N_ = int(B * SR); tt = np.arange(N_) / SR
    shape = 1 - 0.78 * np.exp(-tt / 0.085)
    j = min(n, i + N_); duck[i:j] = np.minimum(duck[i:j], shape[:j - i])

# ---------------------------------------------------------------- kick: pitch-swept sine + 120 Hz knock + click
def kick():
    N_ = int(0.42 * SR); t = np.arange(N_) / SR
    f = 46 + 110 * np.exp(-t / 0.035); ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t / 0.20)
    knock = np.sin(2 * np.pi * 125 * t) * np.exp(-t / 0.045) * 0.45
    click = filt(rng.standard_normal(N_), "bandpass", [2500, 6000]) * np.exp(-t / 0.004) * 0.35
    k = np.tanh(1.6 * (body + knock)) + click
    return k
KICK = kick()
for b in range(NB):
    t = b * B
    if GAP0 <= t < GAP1: continue
    if T_VENUE + 8 * B <= t < GAP0 and b % 2: continue      # thin the kick near the end of the riser
    place(KICK, t, 0.62)

# ---------------------------------------------------------------- hats: closed 16ths (accents on the offbeat 8ths), open hat on offbeats
def hat(dec, bright=7000):
    N_ = int(dec * 6 * SR); t = np.arange(N_) / SR
    return filt(rng.standard_normal(N_), "highpass", bright, 4) * np.exp(-t / dec)
CH = hat(0.018); OH = hat(0.09, 6500)
for s in range(NB * 4):
    t = s * B / 4
    if GAP0 <= t < GAP1 or t >= DUR - 0.3: continue
    q = s % 4; sec = sect(t)
    g = {0: 0.15, 1: 0.24, 2: 0.45, 3: 0.24}[q]
    if sec == 0 and q in (1, 3): continue                 # hook: straight 8ths only
    place(CH, t + (0.008 if q in (1, 3) else 0), g, pan=0.25 if q % 2 else -0.15)
    if q == 2 and sec >= 1 and sec != 4: place(OH, t, 0.24, pan=-0.2)

# ---------------------------------------------------------------- clap on 2 and 4 (from the talks card), snare roll into the drop
def clap():
    N_ = int(0.25 * SR); t = np.arange(N_) / SR; x = np.zeros(N_)
    nz = filt(rng.standard_normal(N_), "bandpass", [900, 5000])
    for o in (0, 0.009, 0.018): x += np.roll(nz * np.exp(-t / 0.012), int(o * SR))
    x += nz * np.exp(-t / 0.09) * 0.6
    return x * 0.6
CLAP = clap()
for b in range(NB):
    t = b * B
    if b % 2 == 1 and t >= bounds[1] and not (GAP0 <= t < GAP1) and not (T_VENUE + 8 * B <= t < T_CTA) and t < DUR - 0.5:
        place(CLAP, t, 0.75, pan=0.05)
roll_t0 = T_CTA - 4 * B                                   # 3-beat snare roll, accelerating, rising
k = 0; t = roll_t0
while t < GAP0:
    frac = (t - roll_t0) / (GAP0 - roll_t0); step = B / (2 if frac < 0.34 else 4 if frac < 0.67 else 8)
    place(CLAP, t, 0.18 + 0.35 * frac, pan=0.1 * np.sin(k)); t += step; k += 1

# ---------------------------------------------------------------- harmony: Am9 Fmaj7 Dm9 Esus4->E7 (one chord per bar)
PROG = [(45, [57, 60, 64, 67, 71]), (41, [57, 60, 64, 65, 69]), (38, [57, 60, 62, 65, 69]), (40, [56, 59, 62, 64, 69])]
bar = 4 * B
def chord_at(t): return PROG[int(t / bar) % 4]

# sub bass: offbeat house pattern, sine + saturated harmonics for phone speakers, side-chained
bass = np.zeros(n)
for b8 in range(NB * 2):
    t = b8 * B / 2
    if t >= DUR - 0.4 or GAP0 <= t < GAP1: continue
    sec = sect(t)
    if b8 % 2 == 0 and not (sec == 6 and b8 % 4 == 0 and False): continue   # offbeats only
    root = chord_at(t)[0]
    if sec in (5,) and t >= T_VENUE + 8 * B: continue     # bass drops out under the end of the riser
    N_ = int(B / 2 * 0.92 * SR); tt = np.arange(N_) / SR
    f = mtof(root + (12 if (b8 // 2) % 8 == 7 else 0)); ph = 2 * np.pi * f * tt
    x = np.sin(ph) + 0.25 * np.sin(2 * ph)
    e = np.minimum(1, tt / 0.004) * np.minimum(1, (N_ / SR - tt) / 0.02)
    bass[int(t * SR):int(t * SR) + N_] += (x * e)[:max(0, min(N_, n - int(t * SR)))]
bass_h = np.tanh(2.5 * bass)                                # harmonics 2, 3, 4 make the line audible on phones
bass_h = filt(bass_h, "bandpass", [90, 900])
bass_out = (filt(bass, "lowpass", 140) * 0.34 + bass_h * 0.42) * duck
place(bass_out, 0, 1.0)

# dark pad: detuned saws, low-passed, high-passed at 180 Hz to keep the low end clean, pumping
pad = np.zeros(n)
for c in range(int(DUR / bar) + 1):
    t = c * bar; root, notes = PROG[c % 4]; N_ = int(bar * 1.15 * SR)
    x = sum(saw(mtof(m), N_, det=0.006, ph=0.1 * i) for i, m in enumerate(notes[:4])) / 4
    x *= env(N_, 0.35, 3.0, sus=0.7, curve=1.0)
    place(x, t, 1.0, buf=(pad, pad))
pad = filt(filt(pad, "lowpass", 1400, 2), "highpass", 180, 2)
# filter dip on the date card (pad opens again over the venue card), darker under the hook
padL = pad * duck * 0.42
place(padL, 0, 1.0, pan=-0.3); place(padL, 0.012, 0.9, pan=0.3)

# chord stabs: short detuned-saw chords on the "and" of beats, band-limited, cutoff automated per section
def stab(notes, cutoff, dur=0.16):
    N_ = int(dur * SR) + int(0.05 * SR)
    x = sum(saw(mtof(m + 12), N_, det=0.004) for m in notes[1:5]) / 4 * env(N_, 0.003, dur, curve=3.5)
    return filt(filt(x, "lowpass", cutoff, 2), "highpass", 260, 2)
CUT = {0: 900, 1: 1500, 2: 1900, 3: 2300, 4: 650, 5: 1100, 6: 3600}
stabs = [np.zeros(n), np.zeros(n)]
for b in range(NB):
    for off in (0.5, 0.75) if True else ():
        t = b * B + off * B; sec = sect(t)
        if sec == 0 and off == 0.75: continue
        if GAP0 - B <= t < GAP1 or t >= DUR - 0.8: continue
        cut = CUT[sec]
        if sec == 5: cut = 1100 + 2400 * (t - T_VENUE) / (T_CTA - T_VENUE)   # filter sweep up into the drop
        g = 0.52 if off == 0.5 else 0.28
        place(stab(chord_at(t)[1], cut), t, g, pan=(-0.35 if off == 0.5 else 0.35), buf=stabs)
for ch in (0, 1):
    stabs[ch] *= duck
L += stabs[0]; R += stabs[1]

# ---------------------------------------------------------------- FX: impact on the date card, riser into the CTA, drop impact
def impact(g=1.0):
    N_ = int(2.2 * SR); t = np.arange(N_) / SR
    boom = np.sin(2 * np.pi * (38 + 40 * np.exp(-t / 0.08)) * t) * np.exp(-t / 0.6)
    nz = filt(rng.standard_normal(N_), "lowpass", 3000) * np.exp(-t / 0.35) * 0.35
    return (np.tanh(1.4 * boom) * 0.8 + nz) * g
place(impact(0.75), T_DATE)
# riser: 12 beats of noise through a rising band-pass + rising sine, ending exactly at the gap
r0 = T_VENUE - 6 * B; rN = int((GAP0 - r0) * SR); rt = np.arange(rN) / SR; u = rt / rt[-1]
nz = rng.standard_normal(rN); ris = np.zeros(rN); seg = int(0.05 * SR)
for i in range(0, rN, seg):                                 # piecewise band-pass sweep 400 Hz -> 9 kHz
    c = 400 * (9000 / 400) ** u[i]; ris[i:i + seg] = filt(nz[max(0, i - 2048):i + seg], "bandpass", [c * 0.7, c * 1.4])[-len(ris[i:i + seg]):]
ris = ris * (u ** 2.2) * 0.9 + np.sin(2 * np.pi * np.cumsum(220 * 4 ** u) / SR) * (u ** 3) * 0.10
place(ris, r0, 0.55, pan=0.0)
place(impact(1.0), T_CTA)
# reverse-ish swell into the hook start? keep frame 0 punchy: no fade-in, kick on frame 0

# ---------------------------------------------------------------- master: glue, low-end check, gentle clip, end fade
X = np.stack([L, R])
X = np.stack([filt(ch, "highpass", 28, 2) for ch in X])                # rumble out
mud = np.stack([filt(ch, "bandpass", [220, 450]) for ch in X])
X = X - 0.30 * mud                                                    # de-mud the 220 to 450 Hz box
X = X + 0.35 * np.stack([filt(ch, "bandpass", [1200, 4500]) for ch in X])          # presence for phone speakers
X = np.tanh(1.15 * X / (np.max(np.abs(X)) + 1e-9)) / np.tanh(1.15)
fo = int(1.2 * SR); X[:, -fo:] *= np.linspace(1, 0, fo) ** 1.5
X *= 0.89 / np.max(np.abs(X))
def band_db(lo, hi):
    s = np.abs(np.fft.rfft(X[0] + X[1])) ** 2; fr = np.fft.rfftfreq(n, 1 / SR)
    return 10 * np.log10(s[(fr >= lo) & (fr < hi)].sum() / s.sum() + 1e-12)
print("energy share dB: sub<60 %.1f | 60-150 %.1f | 150-500 %.1f | 500-2k %.1f | 2k-8k %.1f | >8k %.1f" %
      tuple(band_db(a, b) for a, b in ((20, 60), (60, 150), (150, 500), (500, 2000), (2000, 8000), (8000, 24000))))
w = wave.open(out_p, "wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
w.writeframes((X.T * 32767).astype(np.int16).tobytes()); w.close(); print("ok", out_p)
