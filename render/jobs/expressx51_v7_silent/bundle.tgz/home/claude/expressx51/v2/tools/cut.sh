#!/bin/bash
# usage: cut.sh SRC START DUR NAME [CX]
# -> /home/claude/expressx51/v2/src/NAME.mp4 : 1080x1920 30 fps, no audio, CRF 14 mezzanine.
# Vertical sources are scaled; landscape sources get a 9:16 crop centred at fraction CX of the width (default 0.5), clamped to frame.
cd /home/claude/expressx51/v2
CX="${5:-0.5}"
VF="crop=w='floor(ih*9/16/2)*2':h=ih:x='max(0,min(iw-ow,iw*$CX-ow/2))':y=0,scale=1080:1920:flags=lanczos,fps=30,format=yuv420p"
nice -n 15 ffmpeg -nostdin -v error -threads 1 -ss "$2" -t "$3" -i "$1" -an -vf "$VF" -c:v libx264 -threads 1 -preset veryfast -crf 14 -y "src/$4.mp4" && echo "cut $4 ok $(ffprobe -v error -show_entries format=duration -of csv=p=0 src/$4.mp4)"
