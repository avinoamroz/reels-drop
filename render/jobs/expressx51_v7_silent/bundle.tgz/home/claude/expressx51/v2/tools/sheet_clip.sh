#!/bin/bash
# usage: sheet_clip.sh SRC NAME  -> thumbs/NAME.jpg (2 fps, keyframe-only decode, 6 per row) + duration
cd /home/claude/expressx51/v2
d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$1")
nice -n 15 ffmpeg -nostdin -v error -threads 1 -skip_frame nokey -i "$1" -an -vf "fps=2,scale=200:-2,drawtext=fontfile=/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf:text='%{pts\:hms}':x=4:y=4:fontsize=18:fontcolor=yellow:box=1:boxcolor=black@0.6,tile=8x4" -vsync vfr -y "thumbs/$2_%02d.jpg"
echo "$2 dur $d"
