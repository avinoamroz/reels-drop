"""ExpressX 51 invite v5 (1080x1920, 30 fps, 48 kHz): hook + beat-cut speaker montage with counter + 51? + details + CTA.
Branding, fonts, grade and brush X from ../v2/engine_x51v2.py; music bed from ../v2/music_house.py (120 BPM house).
usage: nice -n 15 python3 engine_v5.py --snaps 0,3,11.2 | --chunk N | --audio
Text rules (v2 guidelines): content inside x 70..1010, y 230..1560, nothing under 36 px, no em or en dashes."""
import sys, os, json, math, subprocess, argparse
import numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--chunk", type=int, default=-1); ap.add_argument("--audio", action="store_true"); ap.add_argument("--silent", action="store_true")
A = ap.parse_args()
D = "/home/claude/expressx51/v7"; V2 = "/home/claude/expressx51/v2"; S = 2; W, H, FPS = 1080, 1920, 30; CX = 540
BPM = 120.0; B = 60 / BPM
TAG = "expressx51_v7"; V7 = "/home/claude/expressx51/v7"

def hx(h, a=255): h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY = hx("#163261"); DEEP = hx("#0E1E3A"); WHITE = hx("#FFFFFF"); YEL = hx("#F5D000"); GOLD = hx("#D9B45A"); GOLD2 = hx("#E6C77E")
FONTS = {"pop7": "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf", "pop5": "/usr/share/fonts/truetype/google-fonts/Poppins-Medium.ttf",
         "serif": "/home/claude/expressx51/fonts/Gloock-Regular.ttf", "he": "/home/claude/vid/fonts/Heebo-800.ttf", "he7": "/home/claude/vid/fonts/Heebo-700.ttf"}
_fc = {}
def font(sz, fam="pop7"):
    k = (max(1, int(sz * S)), fam)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONTS[fam], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]

# ---------------------------------------------------------------- timeline (every boundary on the 120 BPM grid)
T_HOOK, T_MON, T_Q, T_X51, T_DET, T_CTA, T_END = 0.0, 2.0, 13.0, 14.5, 17.0, 23.0, 29.0
SECTIONS = "4,12,10,8,6,6,12"          # music_house cards: hook | montage A | montage B | 51?+X51 | date | venue(riser) | cta(drop)
SHOTS = json.load(open(f"{D}/shots7/shots7.json"))      # v6: v5 minus Noam's removals + invite portraits (prep_v6.py)
_o = [m for m in SHOTS if not m["new"]]; _n = [m for m in SHOTS if m["new"]]; _r = []
while _o or _n:
    if _o: _r.append(_o.pop(0))
    if _n and len(_r) > 1: _r.append(_n.pop(0))
SHOTS = _r; json.dump([m["n"] for m in SHOTS], open(f"{V7}/order.json", "w"))
PER_BEAT = [2, 2] + [3] * 16 + [4, 4, 5, 5]                  # shots per beat: every beat is a cut, about 0.17 s per face
assert sum(PER_BEAT) == len(SHOTS), (sum(PER_BEAT), len(SHOTS))
durs = [B / k for k in PER_BEAT for _ in range(k)]
assert abs(sum(durs) - (T_Q - T_MON)) < 1e-6, sum(durs)
CUTS = []; t = T_MON
for m, d in zip(SHOTS, durs): CUTS.append((m, t, t + d)); t += d
N = int(round(T_END * FPS))

# voice: line i of vo/timing.json placed at VO_AT[i] (reel time)
TIM = json.load(open(f"{V7}/timing.json")); VO_AT = [0.30, 3.00, 14.70, 17.20, 23.20]
def vo_shift(i): return VO_AT[i] - TIM["lines"][i]["t0"]
def word_t(line, w):
    for x in TIM["words"]:
        if x["line"] == line and x["w"].lower().strip(".,").startswith(w.lower()): return x["t0"] + vo_shift(line)
    raise KeyError(w)
T_COMMENT = word_t(4, "link"); T_TIME = word_t(3, "seven"); T_ROTH = word_t(3, "rothschild")

def smooth(u): u = max(0.0, min(1.0, u)); return u * u * (3 - 2 * u)
def ramp(x, w=0.3): return max(0.0, min(1.0, x / w))
def back(u): u = max(0.0, min(1.0, u)); c1 = 1.9; return 1 + (c1 + 1) * (u - 1) ** 3 + c1 * (u - 1) ** 2
def pop(t, t0, w=0.3):
    u = (t - t0) / w
    if u <= 0: return 0.0, 0.88
    return ramp(u, 0.5), 0.88 + 0.12 * back(u)

# ---------------------------------------------------------------- drawing helpers (2x layer)
SIZES = []; OVER = set()
def txt(d, x, y, s, sz, col, fam="pop7", alpha=1.0, spacing=0, nominal=None, maxw=940, anchor="mm"):
    assert "–" not in s and "—" not in s, s
    SIZES.append((s, nominal or sz, y))
    if alpha <= 0.01: return
    f = font(sz, fam); wpx = f.getlength(s) / S + spacing * (len(s) - 1)
    if maxw and wpx > maxw and s not in OVER: OVER.add(s); print(f"WARN overflow {s!r} {wpx:.0f}>{maxw}")
    fill = col[:3] + (int(col[3] * alpha),)
    if spacing:
        x0 = x - wpx / 2
        for ch in s: d.text((x0 * S, y * S), ch, font=f, fill=fill, anchor="lm"); x0 += f.getlength(ch) / S + spacing
        return
    d.text((x * S, y * S), s, font=f, fill=fill, anchor=anchor)
def A_(c, a): return c[:3] + (int(c[3] * max(0, min(1, a))),)
def brush_x(d, cx, cy, size, col, a=1.0, prog=1.0, seed=3):
    if a <= 0.01 or prog <= 0: return
    rng = np.random.default_rng(seed)
    strokes = [((-0.40, -0.50), (0.02, 0.02), (0.44, 0.52), 0.20, 0.09), ((0.42, -0.50), (0.04, -0.02), (-0.38, 0.54), 0.17, 0.08)]
    for k, (p0, pm, p1, w0, w1) in enumerate(strokes):
        pr = max(0.0, min(1.0, prog * 2 - k))
        if pr <= 0: continue
        n = 26; ts = np.linspace(0, pr, n)
        P = np.array([(1 - u) ** 2 * np.array(p0) + 2 * (1 - u) * u * np.array(pm) + u ** 2 * np.array(p1) for u in ts])
        dP = np.gradient(P, axis=0); nr = np.stack([-dP[:, 1], dP[:, 0]], 1); nr /= np.linalg.norm(nr, axis=1, keepdims=True) + 1e-9
        wd = (w0 + (w1 - w0) * ts) * (1 + 0.10 * rng.standard_normal(n))
        L = P + nr * wd[:, None] / 2; R = P - nr * wd[:, None] / 2
        d.polygon([((cx + px * size) * S, (cy + py * size) * S) for px, py in np.vstack([L, R[::-1]])], fill=A_(col, a))
def wordmark(d, cx, cy, sc=1.0, a=1.0, xprog=1.0, xcol=None):
    """EXPRESS (white Poppins Bold) + hand-drawn X, centred, baseline cy"""
    SIZES.append(("EXPRESS X", 70 * sc, cy))
    if a <= 0.01: return
    f2 = font(70 * sc, "pop7"); w2 = f2.getlength("EXPRESS") / S; xs = 92 * sc; tot = w2 + 6 * sc + xs; x0 = cx - tot / 2
    d.text((x0 * S, cy * S), "EXPRESS", font=f2, fill=A_(WHITE, a), anchor="ls")
    brush_x(d, x0 + w2 + 6 * sc + xs / 2, cy - 30 * sc, xs * 1.05, xcol or YEL, a, xprog)
def pill(d, cx, cy, w, h, col, a=1.0):
    if a <= 0.01: return
    d.rounded_rectangle(((cx - w / 2) * S, (cy - h / 2) * S, (cx + w / 2) * S, (cy + h / 2) * S), radius=h / 2 * S, fill=A_(col, a))
EMO = None
_emo = {}
def emoji(ch, px):
    if (ch, px) not in _emo:
        im = Image.new("RGBA", (140, 140), (0, 0, 0, 0)); ImageDraw.Draw(im).text((4, 4), ch, font=EMO, embedded_color=True)
        _emo[(ch, px)] = im.crop(im.getbbox()).resize((px, px), Image.LANCZOS)
    return _emo[(ch, px)]

# ---------------------------------------------------------------- backgrounds
NAVYF = np.array(NAVY[:3], np.float32) / 255; DEEPF = np.array(DEEP[:3], np.float32) / 255
def grade(x):
    lum = (0.299 * x[..., 0] + 0.587 * x[..., 1] + 0.114 * x[..., 2])[..., None]
    x = lum + (x - lum) * 0.86; x = np.clip((x - 0.5) * 1.06 + 0.5, 0, 1)
    k = 0.30 * (1 - lum) ** 1.6; x = x * (1 - k) + NAVYF * k
    x[..., 2] = np.clip(x[..., 2] * 1.04 + 0.01, 0, 1); x[..., 0] *= 0.97
    return x
def band(c, half, peak):
    y = np.arange(H, dtype=np.float32); d = np.clip((np.abs(y - c) - half) / 260.0, 0, 1)
    return (peak * (1 - d * d * (3 - 2 * d)))[:, None, None]
_still = {}
def clip_still(name, at=0.5, blur=18):
    if name not in _still:
        f = f"{V2}/src/{name}.mp4"
        raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(at), "-i", f, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
        im = Image.frombytes("RGB", (W, H), raw).filter(ImageFilter.GaussianBlur(blur))
        x = grade(np.asarray(im, np.float32) / 255) * 0.55 + DEEPF * 0.45
        _still[name] = Image.fromarray((np.clip(x, 0, 1) * 255).astype(np.uint8))
    return _still[name]
def push(im, z, fy=0.45):
    cw, ch = W / z, H / z; x0, y0 = (W - cw) / 2, (H - ch) * fy
    return im.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + cw, y0 + ch))

class Hook:
    """spk_gil (arms in the air), 1.5 s slowed to fill 0..2.0 s"""
    def get(self, t):
        f = f"{V2}/src/spk_gil.mp4"
        sp = 1.5 / 2.0; src_t = min(1.45, t * sp)
        raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{src_t:.3f}", "-i", f, "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
        im = Image.frombytes("RGB", (W, H), raw)
        im = push(im, 1.0 + 0.06 * smooth(t / T_MON), 0.30)
        x = grade(np.asarray(im, np.float32) / 255)
        g = band(1300, 230, 0.70); x = x * (1 - g) + DEEPF * g
        return Image.fromarray((np.clip(x, 0, 1) * 255).astype(np.uint8))
HOOK = Hook()

CARD_X, CARD_Y, CARD_W, CARD_H = 110, 400, 860, 944
_bg = {}
def montage_base(ci):
    if ci not in _bg:
        m = CUTS[ci][0]
        bg = Image.open(f"{D}/shots7/bg{m['n']:02d}.jpg").resize((W, H), Image.BILINEAR)
        x = np.asarray(bg, np.float32) / 255; x = grade(x) * 0.42 + DEEPF * 0.58
        base = Image.fromarray((np.clip(x, 0, 1) * 255).astype(np.uint8))
        card = Image.open(f"{D}/shots7/s{m['n']:02d}.png").convert("RGB").resize((CARD_W, CARD_H), Image.LANCZOS)
        _bg[ci] = (base, card)
        if len(_bg) > 6: _bg.pop(min(_bg))
    return _bg[ci]
def gold_frame(d, x0, y0, w, h, a=1.0, th=6):
    d.rectangle((x0 * S, y0 * S, (x0 + w) * S, (y0 + h) * S), outline=A_(GOLD, a), width=th * S)
    d.rectangle(((x0 + 14) * S, (y0 + 14) * S, (x0 + w - 14) * S, (y0 + h - 14) * S), outline=A_(GOLD2, a * 0.55), width=2 * S)

# ---------------------------------------------------------------- scenes: each returns (base RGB image, draw function for the text layer)
def sc_hook(t):
    base = HOOK.get(t)
    def draw(d):
        br = 1 + 0.025 * math.sin(t * 2 * math.pi / (2 * B))
        txt(d, CX, 1030, "50", 300 * br, GOLD, "serif", nominal=300)
        wordmark(d, CX, 1335, 1.75, xcol=GOLD)
        txt(d, CX, 1465, "evenings.", 118, WHITE)
    return base, draw

def sc_montage(t):
    ci = next(i for i, (m, a, b) in enumerate(CUTS) if a - 1e-9 <= t < b + 1e-9 or i == len(CUTS) - 1 and t >= a)
    m, a, b = CUTS[ci]; base, card = montage_base(ci)
    im = base.copy(); u = (t - a) / max(0.01, b - a)
    z = 1.03 - 0.03 * smooth(min(1, (t - a) / 0.08)) + 0.01 * u       # small punch on every cut, then a drift
    cw, ch = int(CARD_W * z), int(CARD_H * z)
    c2 = card if abs(z - 1) < 1e-3 else card.resize((cw, ch), Image.BILINEAR)
    cx0, cy0 = CX - cw // 2, CARD_Y + CARD_H // 2 - ch // 2
    if c2.size != (CARD_W, CARD_H):
        c2 = c2.crop(((cw - CARD_W) // 2, (ch - CARD_H) // 2, (cw - CARD_W) // 2 + CARD_W, (ch - CARD_H) // 2 + CARD_H)) if z > 1 else c2
        cx0, cy0 = CARD_X, CARD_Y
    im.paste(c2, (cx0, cy0))
    n = ci + 2                                     # speaker 1 is the hook (Gil)
    def draw(d):
        gold_frame(d, CARD_X - 2, CARD_Y - 2, CARD_W + 4, CARD_H + 4)
        a_, s_ = pop(t, a, 0.08)
        txt(d, CX, 285, f"{n}", 150 * (0.92 + 0.08 * s_), GOLD, "serif", nominal=150)
        txt(d, CX, 365, "SPEAKERS ON STAGE", 38, WHITE, "pop5", spacing=5)
        if m.get("x"):
            lab = f"ExpressX {m['x']}"; f = font(38, "pop5"); wl = f.getlength(lab) / S + 40
            pill(d, CARD_X + 30 + wl / 2, CARD_Y + CARD_H - 50, wl, 58, DEEP[:3] + (215,))
            txt(d, CARD_X + 30 + wl / 2, CARD_Y + CARD_H - 50, lab, 38, GOLD2, "pop5")
        al, sl = pop(t, T_MON + 0.2, 0.3)
        txt(d, CX, 1435, "Every one of them spoke", 66 * sl, WHITE, alpha=al, nominal=66)
        f1 = font(66 * sl); w1 = f1.getlength("English on a ") / S; w2 = f1.getlength("real stage.") / S; x0 = CX - (w1 + w2) / 2
        txt(d, x0 + w1 / 2, 1520, "English on a ", 66 * sl, WHITE, alpha=al, nominal=66, maxw=0)
        txt(d, x0 + w1 + w2 / 2, 1520, "real stage.", 66 * sl, GOLD, alpha=al, nominal=66, maxw=0)
    return im, draw

def sc_question(t):
    base = Image.new("RGB", (W, H), DEEP[:3])
    def draw(d):
        d.rectangle((CARD_X * S, CARD_Y * S, (CARD_X + CARD_W) * S, (CARD_Y + CARD_H) * S), fill=NAVY)
        gold_frame(d, CARD_X - 2, CARD_Y - 2, CARD_W + 4, CARD_H + 4)
        a1, s1 = pop(t, T_Q, 0.25); txt(d, CX, 790, "51?", 330 * s1, GOLD, "serif", alpha=a1, nominal=330)
        a2, s2 = pop(t, T_Q + 3 * B / 2, 0.25); txt(d, CX, 1080, "you?", 170 * s2, WHITE, alpha=a2, nominal=170)
        txt(d, CX, 285, "?", 150, GOLD, "serif"); txt(d, CX, 365, "SPEAKERS ON STAGE", 38, WHITE, "pop5", spacing=5)
        a3, _ = pop(t, T_Q + 3 * B / 2 + 0.2, 0.3); txt(d, CX, 1230, "אולי אתם?", 70, GOLD2, "he", alpha=a3)
    return base, draw

def sc_x51(t):
    base = push(clip_still("sort_wide_room"), 1.03 + 0.03 * (t - T_X51) / 2.5)
    def draw(d):
        a, s = pop(t, T_X51, 0.3); txt(d, CX, 560, "NEXT WEEK", 64, WHITE, spacing=12, alpha=a)
        a, s = pop(t, T_X51 + 0.1, 0.35); wordmark(d, CX, 790, 2.0 * s, a, xprog=ramp(t - T_X51 - 0.15, 0.4))
        a, s = pop(t, T_X51 + 0.3, 0.4); txt(d, CX, 1060, "51", 430 * s, GOLD, "serif", alpha=a, nominal=430)
        a, _ = pop(t, T_X51 + 0.6, 0.3); txt(d, CX, 1330, "ערב ExpressX ה-51, בשבוע הבא", 64, WHITE, "he", alpha=a)
    return base, draw

def sc_details(t):
    base = push(clip_still("sort_wide_talk2"), 1.03 + 0.03 * (t - T_DET) / 6)
    def draw(d):
        a, s = pop(t, T_DET, 0.3); wordmark(d, CX, 400, 1.2 * s, a)
        a, s = pop(t, T_DET + 0.15, 0.3); txt(d, CX, 520, "TUESDAY", 70, WHITE, spacing=12, alpha=a)
        a, s = pop(t, T_DET + 0.3, 0.4); txt(d, CX, 670, "03.11.26", 170 * s, GOLD, alpha=a, nominal=170)
        a, _ = pop(t, T_DET + 0.55, 0.3); txt(d, CX, 790, "יום שלישי, 3 בנובמבר", 64, GOLD2, "he", alpha=a)
        a, s = pop(t, T_TIME - 0.1, 0.3); txt(d, CX, 925, "19:00 to 22:00", 96 * s, WHITE, alpha=a, nominal=96)
        a, _ = pop(t, T_TIME + 0.15, 0.3); txt(d, CX, 1030, "19:00 עד 22:00", 64, GOLD2, "he", alpha=a)
        a, _ = pop(t, T_ROTH - 0.2, 0.3)
        if a > 0: d.line(((CX - 180) * S, 1110 * S, (CX + 180) * S, 1110 * S), fill=A_(GOLD, a), width=4 * S)
        a, s = pop(t, T_ROTH - 0.1, 0.3); txt(d, CX, 1220, "Rothschild 57", 112 * s, WHITE, alpha=a, nominal=112)
        a, s = pop(t, T_ROTH + 0.15, 0.3); txt(d, CX, 1335, "TEL AVIV", 70, WHITE, spacing=12, alpha=a)
        a, _ = pop(t, T_ROTH + 0.35, 0.3); txt(d, CX, 1440, "רוטשילד 57, תל אביב", 64, GOLD2, "he", alpha=a)
    return base, draw

def sc_cta(t):
    base = push(clip_still("sort_crowd_x"), 1.03 + 0.03 * (t - T_CTA) / 6)
    def draw(d):
        a, s = pop(t, T_CTA, 0.3); txt(d, CX, 560, "You're", 160 * s, WHITE, alpha=a, nominal=160)
        a, s = pop(t, T_CTA + 0.15, 0.3); txt(d, CX, 730, "invited.", 160 * s, GOLD, alpha=a, nominal=160)
        a, _ = pop(t, T_CTA + 0.4, 0.3); txt(d, CX, 870, "אתם מוזמנים", 76, WHITE, "he", alpha=a)
        a, s = pop(t, T_COMMENT - 0.1, 0.3)
        pul = 1 + (0.035 * math.sin((t - T_COMMENT) * 2 * math.pi / (2 * B)) if t > T_COMMENT + 0.4 else 0)
        sc = s * pul; pw, ph = 720 * sc, 170 * sc
        pill(d, CX, 1075, pw, ph, GOLD, a)
        if a > 0.01:
            f = font(92 * sc); lab = "Link in bio"; SIZES.append((lab, 92, 1075))
            d.text((CX * S, 1075 * S), lab, font=f, fill=A_(NAVY, a), anchor="mm")
        a, _ = pop(t, T_COMMENT + 0.35, 0.3); txt(d, CX, 1250, "הקישור בביו", 70, GOLD2, "he", alpha=a)
        txt(d, CX, 1335, "expressenglish.co.il/expressx", 46, WHITE, "pop5", alpha=a)
        a, _ = pop(t, T_COMMENT + 0.7, 0.3); txt(d, CX, 1470, "Tue 03.11.26  |  19:00  |  Rothschild 57", 46, WHITE, "pop5", alpha=a)
    return base, draw

SCENES = [(T_HOOK, sc_hook), (T_MON, sc_montage), (T_Q, sc_question), (T_X51, sc_x51), (T_DET, sc_details), (T_CTA, sc_cta)]
EM = []
def frame(t):
    k = max(i for i, (a, _) in enumerate(SCENES) if a <= t + 1e-9)
    base, draw = SCENES[k][1](t)
    EM.clear(); lay = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); draw(d); lay = lay.reduce(S)
    for em, x, y, a in EM:
        e = em if a >= 0.999 else em.copy()
        if a < 0.999: e.putalpha(e.getchannel("A").point(lambda v: int(v * a)))
        lay.alpha_composite(e, (x, y))
    im = base.convert("RGBA")
    sh = lay.getchannel("A").filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(v * 0.7))
    shadow = Image.new("RGBA", (W, H), DEEP[:3] + (0,)); shadow.putalpha(sh)
    im.alpha_composite(shadow, (0, 4)); im.alpha_composite(lay)
    if t < 0.12 and k == 0: pass
    return im.convert("RGB")

# ---------------------------------------------------------------- run
print("speakers:", len(CUTS) + 1, "| montage", T_MON, "to", T_Q, "| comment at", round(T_COMMENT, 2), flush=True)
if A.snaps:
    os.makedirs(f"{V7}/qa", exist_ok=True)
    for s in [float(x) for x in A.snaps.split(",")]: frame(s).save(f"{V7}/qa/snap_{s:05.2f}.png")
    bad = sorted({(s, round(z)) for s, z, y in SIZES if z < 36 or y < 230 or y > 1560}); print("size/zone violations:", bad, "| overflow:", len(OVER)); sys.exit()
CH = 300; CHD = f"{D}/chunks7"
if A.chunk >= 0:
    os.makedirs(CHD, exist_ok=True); FR = range(A.chunk * CH, min(N, (A.chunk + 1) * CH)); out = f"{CHD}/c{A.chunk:02d}.mp4"
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-threads", "1", "-x264-params", "rc-lookahead=10", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "veryfast", out], stdin=subprocess.PIPE)
    for f in FR:
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 60 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("chunk", out, "| NCHUNKS", (N + CH - 1) // CH, "| overflow", len(OVER)); sys.exit()

if A.silent:
    out = f"{V7}/{TAG}_silent.mp4"
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", out], stdin=subprocess.PIPE)
    for f in range(N): ff.stdin.write(frame(f / FPS).tobytes())
    ff.stdin.close(); ff.wait(); print("silent", out); sys.exit()

if A.audio:
    SR = 48000; n = int(T_END * SR)
    # voice: house-chain vo.wav (voice.py), each line cut at its pauses (soft endings kept) and placed at VO_AT
    vo, sr = sf.read(f"{V7}/vo.wav"); assert sr == SR
    V = np.zeros(n)
    for i, L in enumerate(TIM["lines"]):
        a0 = max(0.0, L["t0"] - 0.12); a1 = min(len(vo) / SR, L["t1"] + 0.28)
        if i + 1 < len(TIM["lines"]): a1 = min(a1, TIM["lines"][i + 1]["t0"] - 0.08)
        seg = vo[int(a0 * SR):int(a1 * SR)].copy(); fz = int(0.012 * SR); seg[:fz] *= np.linspace(0, 1, fz); seg[-fz:] *= np.linspace(1, 0, fz)
        k = int((a0 + vo_shift(i)) * SR); V[k:k + len(seg)] += seg[:n - k]
    mus = f"{V7}/{TAG}_bed.wav"
    subprocess.run(["nice", "-n", "15", "python3", f"{V2}/music_house.py", mus, f"{T_END:.2f}", f"{BPM:g}", SECTIONS], check=True)
    M, sr = sf.read(mus); assert sr == SR; M = M[:n]
    # ducking: smoothed voice envelope (attack 25 ms, release 300 ms) pulls the bed down 8 dB under speech
    e = np.sqrt(np.convolve(V ** 2, np.ones(int(0.02 * SR)) / int(0.02 * SR), "same"))
    act = e > 10 ** (-38 / 20) * np.max(np.abs(V))
    hop = 240; a = act[::hop].astype(float); env = np.zeros_like(a); ka, kr = 1 - math.exp(-hop / SR / 0.025), 1 - math.exp(-hop / SR / 0.30)
    for j in range(1, len(a)): env[j] = env[j - 1] + (a[j] - env[j - 1]) * (ka if a[j] > env[j - 1] else kr)
    duck = 10 ** (-8 * np.interp(np.arange(n), np.arange(len(env)) * hop, env) / 20)
    vrms = np.sqrt(np.mean(V[act] ** 2)); mrms = np.sqrt(np.mean(M ** 2))
    g = vrms / mrms * 10 ** (-7 / 20)                                  # bed 7 dB under the voice, 15 dB under while ducked
    X = M * (g * duck)[:, None] + V[:, None]
    X *= 0.9 / np.max(np.abs(X)); mix = f"{V7}/{TAG}_mix.wav"; sf.write(mix, X.astype(np.float32), SR, subtype="FLOAT")
    pass
    sil = f"{V7}/{TAG}_silent.mp4"
    # loudness: +8.2 dB into a 4x-oversampled limiter at -2.2 dBFS measured -14.0 LUFS / -1.9 dBTP after AAC (loudnorm linear stopped at -15)
    af = f"afade=t=out:st={T_END - 0.8:.2f}:d=0.8,volume=8.2dB,aresample=192000,alimiter=limit=0.78:level=false:attack=2:release=80,aresample=48000"
    out = f"{V7}/{TAG}.mp4"
    subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", sil, "-i", mix, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-af", af,
                    "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-t", f"{T_END:.2f}", "-movflags", "+faststart", out], check=True)
    web = f"{V7}/{TAG}_web.mp4"
    subprocess.run(["nice", "-n", "15", "ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", out, "-vf", "scale=540:960:flags=lanczos", "-c:v", "libx264", "-threads", "1",
                    "-preset", "veryfast", "-crf", "27", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", web], check=True)
    print("final", out, web)
