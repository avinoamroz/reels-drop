"""cx.py <drive download result> [-v]: list a Commons API generator=search result (pages as dict)."""
import json, sys, base64, re
d = json.load(open(sys.argv[1])); raw = d["content"]
try: txt = base64.b64decode(raw).decode()
except Exception: txt = raw
j = json.loads(txt); pg = j["query"]["pages"]; pg = pg.values() if isinstance(pg, dict) else pg
for p in sorted(pg, key=lambda p: p.get("index", 0)):
    ii = (p.get("imageinfo") or [{}])[0]; em = ii.get("extmetadata", {})
    g = lambda k: re.sub("<[^>]+>", "", (em.get(k, {}).get("value", "") or ""))[:150].replace("\n", " ")
    print(f'{p.get("index")}. {p["title"]} | {ii.get("width")}x{ii.get("height")} | {g("LicenseShortName")} | {g("Artist")} | {g("DateTimeOriginal")}')
    print("     ", g("ImageDescription")[:150])
    if "-v" in sys.argv: print("     ", ii.get("thumburl"))
