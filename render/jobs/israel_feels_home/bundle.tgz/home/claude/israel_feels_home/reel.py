"""israel_feels_home: "Why does Israel feel like home?" (@noamroz__, English, 1 Nov 2026), Noam's story.
Engine core (Apple keynote stage, Inter, cubic fades with blur-in, Ken Burns photo panels, 36 px credits) copied from
together_works/reel.py. New here: cairo stick-figure scenes (house colour code: blue = speaking / acting, orange = passive,
here the newcomer), speech bubbles, a self-drawing house outline at the hook, a drive line, and a Shabbat table with candles.
Loop: lead-in at the hook place and size, last 0.45 s cross-fades into the exact frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py (silent video to work/silent.mp4)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/israel_feels_home"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing from the narration (work/words.json)
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):     # index of the first word in line li that starts with `word`
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(re.sub(r"\W", "", word).lower()): return i
    raise KeyError((li, word))
NL = max(LW) + 1
T_END = round(E(NL - 1) + 0.5, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = "#060608"; GLOW_COL = "#E8C77E"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
ISR_GOLD = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

# stage: one wide soft glow
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# text rasters at 2x, composited with sub-pixel placement, scale and blur (from engine_v3)
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 500: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
def capof(fk, size): return raster("H", fk, size)[3]
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0):
    """y_cap_mid: vertical middle of the capitals"""
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, 540, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)

# ------------------------------------------------------------------ photos (Ken Burns in a rounded panel)
PH = {  # key: (file, focus x, focus y, credit at 36 px)
}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
def photo(canvas, t, k, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35):
    a = seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout)) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC)
    sc = 0.97 + 0.03 * seg(t, t0, t0 + ain)
    m = rmask(w, h, 34); lay = crop.convert("RGBA"); lay.putalpha(m.point(lambda v: int(v * a)))
    if sc < 0.999:
        nw, nh = int(w * sc), int(h * sc); lay = lay.resize((nw, nh), Image.BICUBIC); x0 += (w - nw) // 2; y0 += (h - nh) // 2
    canvas.alpha_composite(lay, (int(x0), int(y0)))
def credit(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.45)

# ------------------------------------------------------------------ counters
def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def num_text(canvas, t, s, y, size, t0, t1, color=GOLD, ain=0.4):
    text(canvas, t, s, y, size, t0, t1, fk="db", color=color, tab=True, ain=ain)

# ------------------------------------------------------------------ flat layers: subtitles, sources
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)

# ================================================================== israel_feels_home
T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45     # 22 bars of the bed at 100 BPM
GLOW_COL = "#F0C27A"; GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
ORANGE = "#F28C28"; NAVY = "#0E1E3A"
PH.update({
 "tlv": ("tlv_arl.jpg", 0.50, 0.55, "Arlozorov St, Tel Aviv. Photo: Rakoon, CC0"),
 # fix 1 Nov ([0:15] "a few pictures with many people in the background"): busy streets, softly blurred so no face is in focus
 "cr1": ("crowd_carmel1.jpg", 0.45, 0.55, "Carmel Market, Tel Aviv. Photo: Jorge Láscar, CC BY 2.0"),
 "cr2": ("crowd_carmel3.jpg", 0.45, 0.42, "Carmel Market, Tel Aviv. Photo: Bahnfrend, CC BY-SA 4.0"),
 "cr3": ("crowd_benyeh.jpg", 0.50, 0.62, "Ben Yehuda St, Jerusalem. Photo: Yoninah, CC BY-SA 3.0"),
 "gal": ("gal_beat.jpg", 0.50, 0.42, "Sea of Galilee. Photo: Obendorf, CC0"),
 "nova": ("nova_poppy.jpg", 0.55, 0.45, "Nova memorial site, Re'im. Photo: Relspas, CC BY-SA 4.0"),
 "shab": ("shab.jpg", 0.42, 0.62, "Shabbat table. Photo: Crzrussian, CC BY-SA 3.0"),
})
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
def WX(li, word, n=1):     # index of the n-th word in line li that equals `word` (punctuation ignored)
    k = re.sub(r"\W", "", word).lower(); c = 0
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower() == k:
            c += 1
            if c == n: return i
    raise KeyError((li, word))
def SW(li, word, n=1): return S(li, WX(li, word, n))
def photo_b(canvas, t, k, t0, t1, box, ain=0.45, aout=0.35, alpha=1.0):
    x0, y0, x1, y1 = [int(round(v)) for v in box]; photo(canvas, t, k, t0, t1, (x0, y0, x1, y1), alpha=alpha, ain=ain, aout=aout)
def credit_at(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#9A9AA0", ain=0.3, inst=(t0 <= 0))
def textx(canvas, t, s, cx, y_cap_mid, size, t0, t1, fk="db", color=WHITE, ain=T_IN, aout=T_OUT, alpha=1.0):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size); put(canvas, info, cx, y_cap_mid + info[3] / 2 + dy, sc, hx(color), a * alpha, bl)
HEF = "/root/.fonts/Heebo-ExtraBold.ttf"
def hebrew(canvas, t, s, y, size, t0, t1, color=GREY):
    a, sc, bl, dy = envl(t, t0, t1)
    if a <= 0.004: return
    f = ImageFont.truetype(HEF, size); lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((540, y + dy), s, font=f, fill=tuple(int(c) for c in hx(color)) + (int(255 * a),), anchor="mm", direction="rtl", language="he")
    canvas.alpha_composite(lay)

# ------------------------------------------------------------------ cairo layer (figures, bubbles, props)
class Layer:
    def __init__(s): s.surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); s.c = cairo.Context(s.surf); s.used = False
    def done(s, canvas):
        if not s.used: return
        s.surf.flush(); a = np.ndarray((H, W, 4), np.uint8, s.surf.get_data()).astype(np.float32)
        al = a[:, :, 3:4]; rgb = np.where(al > 0, a[:, :, 2::-1] * 255.0 / np.maximum(al, 1), 0)
        canvas.alpha_composite(Image.fromarray(np.concatenate([rgb, al], 2).clip(0, 255).astype(np.uint8), "RGBA"))
def rgb(hc): v = hx(hc) / 255.0; return float(v[0]), float(v[1]), float(v[2])
def group(L_, a, fn):
    if a <= 0.004: return
    L_.used = True; c = L_.c; c.push_group(); fn(c); c.pop_group_to_source(); c.paint_with_alpha(min(1, a))
def stroke_pts(c, pts, lw, col):
    c.set_source_rgb(*rgb(col)); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()
def figure(c, x, yf, h, col, walk=0.0, arm_l=0.0, arm_r=0.0, lean=0.0, skirt=False, bag=False, sweat=0.0, smile=1.0, talk=0.0, bun=False):
    """stick figure standing on (x, yf), height h. arm_*: 0 down, 0.5 sideways, 1 up. walk: phase in radians (0 = still)."""
    lw = h * 0.062; r = h * 0.125; sw = math.sin(walk) if walk else 0.0
    hx_ = x + lean * h * 0.18; hy = yf - h + r; neck = (hx_ - lean * h * 0.02, hy + r + lw * 0.3)
    hip = (x, yf - h * 0.42); sh = (neck[0] * 0.85 + hip[0] * 0.15, neck[1] + (hip[1] - neck[1]) * 0.18)
    st = h * 0.14
    stroke_pts(c, [hip, (x - st * 0.75 + sw * st * 0.9, yf)], lw, col); stroke_pts(c, [hip, (x + st * 0.75 - sw * st * 0.9, yf)], lw, col)
    if skirt:
        c.set_source_rgb(*rgb(col)); c.move_to(hip[0] - h * 0.04, hip[1] - h * 0.12); c.line_to(hip[0] + h * 0.04, hip[1] - h * 0.12)
        c.line_to(hip[0] + h * 0.17, hip[1] + h * 0.14); c.line_to(hip[0] - h * 0.17, hip[1] + h * 0.14); c.close_path(); c.fill()
    stroke_pts(c, [neck, hip], lw, col)
    al = h * 0.36
    def arm(side, u):
        th = 0.18 + u * math.pi * 0.82                      # angle from straight down, outward
        hand = (sh[0] + side * math.sin(th) * al, sh[1] + math.cos(th) * al)
        stroke_pts(c, [sh, hand], lw, col); return hand
    hl = arm(-1, arm_l + (0.08 * -sw if walk else 0)); hr = arm(1, arm_r + (0.08 * sw if walk else 0))
    if bag:
        bw, bh = h * 0.22, h * 0.17; bx, by = hr[0] + h * 0.01, hr[1] + h * 0.03
        c.set_source_rgb(*rgb("#D9D9DE")); c.new_path(); rr(c, bx - bw / 2, by, bw, bh, h * 0.025); c.fill()
        stroke_pts(c, [(bx - bw * 0.2, by), (bx - bw * 0.2, by - h * 0.03), (bx + bw * 0.2, by - h * 0.03), (bx + bw * 0.2, by)], lw * 0.45, "#D9D9DE")
    c.set_source_rgb(*rgb(col)); c.arc(hx_, hy, r, 0, 2 * math.pi); c.fill()
    if bun: c.arc(hx_ - r * 0.15, hy - r * 1.02, r * 0.42, 0, 2 * math.pi); c.fill()
    c.set_source_rgb(*rgb(NAVY)); er = r * 0.12
    for ex in (-0.36, 0.36): c.arc(hx_ + ex * r, hy - r * 0.12, er, 0, 2 * math.pi); c.fill()
    c.set_line_width(r * 0.11); c.set_line_cap(cairo.LINE_CAP_ROUND)
    if talk > 0.02:
        c.save(); c.translate(hx_, hy + r * 0.42); c.scale(1, max(0.2, talk)); c.arc(0, 0, r * 0.2, 0, 2 * math.pi); c.restore(); c.fill()
    elif smile >= 0: c.arc(hx_, hy + r * 0.12, r * 0.4, math.pi * (0.2 - 0.08 * (1 - smile)), math.pi * (0.8 + 0.08 * (1 - smile))); c.stroke()
    else: c.arc(hx_, hy + r * 0.62, r * 0.3, math.pi * 1.2, math.pi * 1.8); c.stroke()
    if sweat > 0.02:
        c.set_source_rgba(0.78, 0.9, 1.0, min(1, sweat)); sx, sy = hx_ + r * 1.15, hy - r * 0.3
        c.move_to(sx, sy - r * 0.45); c.curve_to(sx + r * 0.32, sy, sx + r * 0.28, sy + r * 0.32, sx, sy + r * 0.32)
        c.curve_to(sx - r * 0.28, sy + r * 0.32, sx - r * 0.32, sy, sx, sy - r * 0.45); c.fill()
    return (hx_, hy, r)
def rr(c, x, y, w, h, r):
    c.new_sub_path(); c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
BUBF = "sb"
def bubble_shape(c, cx, cy, w, h, tip):
    c.set_source_rgb(*rgb("#F5F5F7")); rr(c, cx - w / 2, cy - h / 2, w, h, h * 0.42); c.fill()
    bx = min(max(tip[0], cx - w / 2 + 50), cx + w / 2 - 50)
    c.move_to(bx - 26, cy + h / 2 - 2); c.line_to(bx + 26, cy + h / 2 - 2); c.line_to(tip[0], tip[1]); c.close_path(); c.fill()
def bubble(canvas, L_, t, s, cx, cy, tip, t0, t1, size=60):
    a, sc, bl, dy = envl(t, t0, t1, 0.35, 0.25)
    if a <= 0.004: return
    tw = font(BUBF, size).getlength(s); w = tw + 90; h = size * 1.9; cy = cy + dy * 0.5
    pop = 0.85 + 0.15 * seg(t, t0, t0 + 0.25)
    def fn(c):
        c.translate(tip[0], tip[1]); c.scale(pop, pop); c.translate(-tip[0], -tip[1]); bubble_shape(c, cx, cy, w, h, tip)
    group(L_, a, fn); L_.done(canvas); L_.__init__()
    textx(canvas, t, s, tip[0] + (cx - tip[0]) * pop, tip[1] + (cy - tip[1]) * pop, size * pop, t0, t1, fk=BUBF, color=NAVY, ain=0.35, aout=0.25)
def house(c, cx, base, w, h, u, col=GOLD, lw=9):
    pts = [(cx - w / 2, base), (cx - w / 2, base - h * 0.62), (cx, base - h), (cx + w / 2, base - h * 0.62), (cx + w / 2, base)]
    segl = [math.dist(pts[i], pts[i + 1]) for i in range(4)]; tot = sum(segl); c.set_source_rgb(*rgb(col)); c.set_line_width(lw)
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.move_to(*pts[0]); left = tot * u
    for i in range(4):
        if left <= 0: break
        f = min(1, left / segl[i]); p0, p1 = pts[i], pts[i + 1]; c.line_to(p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f); left -= segl[i]
    c.stroke()

# ------------------------------------------------------------------ timing
HOOK_END = S(1) - 0.15
B0, C0, E0, F0_, H0, I0, J0 = HOOK_END, S(3) - 0.2, S(5) - 0.2, S(6) - 0.2, S(8) - 0.25, S(12) - 0.25, S(15) - 0.2
END_T = S(16) - 0.12
BOX = (60, 250, 1020, 760); CRED_Y = 792; NAME_Y = 880
HOOK_A, HOOK_B = "Why does Israel", "feel like home?"
HS = min(fit(HOOK_A, "db", 140), fit(HOOK_B, "db", 140)); HY1, HY2 = 430, 430 + HS * 1.2
END_A, END_B = "Then you already", "know the answer to…"
ES = min(fit(END_A, "db", 128), fit(END_B, "db", 128))
NEW_X, NEW_F, NEW_H = 540, 1440, 540

def glow_at(t):
    g = 0.08 + 0.05 * seg(t, 0, 1.2) * (1 - seg(t, B0, B0 + 0.6))
    g -= 0.05 * seg(t, F0_, F0_ + 0.8) * (1 - seg(t, H0 - 0.6, H0))                  # quieter on the memorial
    g += 0.10 * seg(t, H0, H0 + 1.2) * (1 - seg(t, I0 - 0.4, I0 + 0.4))                 # warm Shabbat
    g += 0.05 * seg(t, END_T, END_T + 0.6)
    return max(0.02, g)

def newcomer_home(Lr, t, t0, t1, u_house, alpha):
    """the hook picture: the newcomer with a suitcase, a gold house outline drawing itself around them"""
    def fn(c):
        house(c, NEW_X, NEW_F + 30, 660, 760, u_house, lw=11)
        figure(c, NEW_X, NEW_F, NEW_H, ORANGE, bag=True, smile=0.6)
    group(Lr, alpha, fn)

def frame_raw(t):
    im = stage(glow_at(t)); Lr = Layer()
    # ---- A. hook (line 0) and K. the lead-in (line 16) at the same place
    zoom = 1 + 0.03 * seg(t, 0, HOOK_END)
    text(im, t, HOOK_A, HY1, HS, 0, HOOK_END, inst=True, zoom=zoom)
    text(im, t, HOOK_B, HY2, HS, 0, HOOK_END, inst=True, zoom=zoom, color=GOLD)
    if t < HOOK_END + 0.4:
        a = 1 - seg(t, HOOK_END, HOOK_END + 0.35); u = 0.42 + 0.58 * seg(t, 0.0, 1.3)
        newcomer_home(Lr, t, 0, HOOK_END, u, a)
    if t > END_T - 0.1:
        text(im, t, END_A, HY1, ES, END_T, T_END + 1, ain=0.55); text(im, t, END_B, HY2, ES, END_T + 0.12, T_END + 1, ain=0.55, color=GOLD)
        a = seg(t, END_T, END_T + 0.5); u = 0.42 * seg(t, END_T + 0.1, T_END - LOOP)
        newcomer_home(Lr, t, END_T, T_END, u, a)
    # ---- B. lines 1 and 2: alone, knows nobody
    if B0 - 0.1 < t < C0 + 0.5:
        a = seg(t, B0, B0 + 0.3) * (1 - seg(t, C0, C0 + 0.35)); w2 = SW(1, "weird") - 0.2; nb = S(2) - 0.15
        text(im, t, "Jews and non-Jews", 440, fit("Jews and non-Jews", "db", 110), B0 + 0.05, nb)
        text(im, t, "land in Israel", 580, 80, B0 + 0.3, nb, fk="dm", color=GREY)
        text(im, t, "They know", 440, 110, nb, C0)
        text(im, t, "nobody.", 600, 150, SW(2, "nobody") - 0.2, C0, color=GOLD)
        text(im, t, "?", 790, 150, w2, nb, color=GOLD)
        text(im, t, "Friends here: 0", 1505, 64, nb + 0.3, C0, fk="dsb", color=GREY)
        def fn(c): figure(c, NEW_X, NEW_F, NEW_H, ORANGE, bag=True, smile=0.0 if t > w2 else 0.6)
        group(Lr, a, fn)
    # ---- C. lines 3 and 4: the street
    if C0 - 0.1 < t < E0 + 0.5:
        t1 = E0
        a = seg(t, C0, C0 + 0.35) * (1 - seg(t, t1, t1 + 0.3))
        wk = seg(t, C0, SW(3, "street"))                                  # the newcomer walks in from the left
        nx = lerp(140, 300, wk); walking = 0 < wk < 1
        ap = [SW(3, "walk") - 0.1, SW(3, "street") - 0.1, SW(3, "talking") - 0.2]
        LX = [600, 760, 920]; FY = 1480; FH = 330
        b0, b1, b2 = S(4) - 0.1, SW(4, "Someone", 2) - 0.1, SW(4, "Someone", 3) - 0.1
        talker = 0 if t < b1 else (1 if t < b2 else 2)
        if t < b0: talker = 2
        # the street photo, then a new crowded street on each "Someone ..." beat (cross-fades)
        for k_, ta_, tb_ in (("tlv", C0, b0), ("cr1", b0, b1), ("cr2", b1, b2), ("cr3", b2, t1)):
            last = tb_ == t1
            photo_b(im, t, k_, ta_, (tb_ if last else tb_ + 0.3), BOX, ain=(0.4 if k_ == "tlv" else 0.3), aout=0.3)
            credit_at(im, t, k_, ta_ + 0.1, tb_, CRED_Y)
        def fn(c):
            figure(c, nx, FY, FH + 20, ORANGE, bag=True, walk=(t * 9 if walking else 0), smile=0.3 + 0.7 * seg(t, ap[2], ap[2] + 0.5))
            for k, (x, t_) in enumerate(zip(LX, ap)):
                u = seg(t, t_, t_ + 0.35)
                if u <= 0: continue
                c.save(); c.translate(x, FY); c.scale(1, 0.85 + 0.15 * u); c.translate(-x, -FY)
                tk = (0.5 + 0.5 * math.sin(t * 18)) if (talker == k and t > ap[2]) else 0
                figure(c, x, FY, FH, SKY, arm_l=0.55 if talker == k and t > ap[2] else 0.1, smile=1, talk=tk); c.restore()
        group(Lr, a, fn); Lr.done(im); Lr = Layer()
        # friends counter on the photo
        n = 0
        for k, t_ in enumerate(ap):
            if t >= t_: n = k + 1
        for tt, v0, v1 in ((b0, 3, 12), (b1, 12, 31), (b2, 31, 96)):
            if t >= tt: n = int(round(roll(t, tt, 0.7, v0, v1)))
        if t > ap[0] - 0.05:
            pa = a * seg(t, ap[0], ap[0] + 0.3)
            def pill(c): c.set_source_rgba(0.04, 0.04, 0.06, 0.78); rr(c, 300, 652, 480, 84, 42); c.fill()
            group(Lr, pa, pill); Lr.done(im); Lr = Layer()
            textx(im, t, f"Friends here: {n}", 540, 694, 56, ap[0], t1, fk="dsb", color=GOLD, ain=0.3)
        tip = lambda k: (LX[k] - 30, FY - FH + 10)
        bubble(im, Lr, t, "Where are you from?", 560, 990, tip(2), ap[2] + 0.1, b0 - 0.05)
        bubble(im, Lr, t, "Come for dinner!", 560, 990, tip(0), b0, b1 - 0.05)
        bubble(im, Lr, t, "I'll drive you!", 600, 990, tip(1), b1, b2 - 0.05)
        bubble(im, Lr, t, "I know a guy.", 640, 990, tip(2), b2, t1)
    # ---- E. line 5: my mother and four women at the Sea of Galilee
    if E0 - 0.1 < t < F0_ + 0.5:
        t1 = F0_; photo_b(im, t, "gal", E0, t1, BOX); credit_at(im, t, "gal", E0 + 0.1, t1, CRED_Y)
        text(im, t, "My mother", NAME_Y, 110, E0 + 0.05, t1, color=GOLD)
        s = "helped 4 Christian women"; text(im, t, s, 1000, fit(s, "dsb", 76), SW(5, "four") - 0.15, t1, fk="dsb")
        text(im, t, "from Germany", 1090, 66, SW(5, "Germany") - 0.2, t1, fk="dm", color=GREY)
        a = seg(t, E0, E0 + 0.3) * (1 - seg(t, t1, t1 + 0.3)); fw = SW(5, "four") - 0.1
        def fn(c):
            figure(c, 190, 1470, 290, SKY, skirt=True, bun=True, arm_r=0.45 * (0.5 + 0.5 * math.sin(t * 6)) * seg(t, fw, fw + 0.4))
            for k, x in enumerate((420, 580, 740, 900)):
                u = seg(t, fw + 0.12 * k, fw + 0.12 * k + 0.3)
                if u > 0:
                    c.push_group(); figure(c, x, 1470, 270, ORANGE, skirt=True, bag=(k == 3), smile=1); c.pop_group_to_source(); c.paint_with_alpha(u)
        group(Lr, a, fn)
    # ---- F/G. lines 6 and 7: the drive to the memorial, two hours each way
    if F0_ - 0.1 < t < H0 + 0.5:
        t1 = H0; photo_b(im, t, "nova", F0_, t1, BOX, ain=0.6); credit_at(im, t, "nova", F0_ + 0.1, t1, CRED_Y)
        s = "October 7th memorial"; text(im, t, s, NAME_Y, fit(s, "db", 100), SW(6, "October") - 0.2, t1)
        text(im, t, "in the south", 985, 66, SW(6, "south") - 0.25, t1, fk="dm", color=GREY)
        a = seg(t, F0_, F0_ + 0.4) * (1 - seg(t, t1, t1 + 0.3)); dv = SW(6, "drove") - 0.1; ar = SW(6, "south") + 0.3
        jf = SW(7, "Just") - 0.15; back0 = jf
        ux = seg(t, dv, ar) if t < back0 else 1 - seg(t, back0, back0 + 1.4)
        X0, X1, RY = 150, 930, 1135
        def fn(c):
            c.set_source_rgb(*rgb("#5A5A60")); c.set_line_width(6); c.set_dash([2, 22]); c.set_line_cap(cairo.LINE_CAP_ROUND)
            c.move_to(X0, RY); c.line_to(X1, RY); c.stroke(); c.set_dash([])
            for x in (X0, X1): c.set_source_rgb(*rgb(GOLD)); c.arc(x, RY, 13, 0, 2 * math.pi); c.fill()
            cx = lerp(X0, X1, ux); bob = 3 * math.sin(t * 20) if 0 < ux < 1 else 0; fl = -1 if t >= back0 else 1
            c.save(); c.translate(cx, RY - 34 + bob); c.scale(fl, 1); c.set_source_rgb(*rgb(SKY))
            rr(c, -62, -20, 124, 44, 14); c.fill(); rr(c, -34, -46, 64, 32, 12); c.fill()
            c.set_source_rgb(*rgb(NAVY)); rr(c, -22, -38, 22, 20, 5); c.fill(); rr(c, 6, -38, 18, 20, 5); c.fill()
            c.set_source_rgb(*rgb("#E5E5EA"))
            for wx in (-34, 34): c.arc(wx, 26, 15, 0, 2 * math.pi); c.fill()
            c.restore()
        group(Lr, a, fn); Lr.done(im); Lr = Layer()
        textx(im, t, "Galilee", 210, 1215, 52, dv - 0.2, t1, fk="dsb", color=GREY)
        textx(im, t, "The south", 850, 1215, 52, dv - 0.2, t1, fk="dsb", color=GREY)
        h2 = SW(7, "Two") - 0.15
        text(im, t, "2 hours", 1340, 150, h2, jf, color=GOLD)
        text(im, t, "each way", 1460, 76, SW(7, "each") - 0.15, jf, fk="dsb")
        text(im, t, "Just for fun.", 1390, 132, jf, t1, color=GOLD)
    # ---- H. lines 8 to 11: Friday night, Erev Shabbat, my table
    if H0 - 0.1 < t < I0 + 0.5:
        t1 = I0; photo_b(im, t, "shab", H0, t1, BOX); credit_at(im, t, "shab", H0 + 0.1, t1, CRED_Y)
        es = S(9) - 0.12; nw = S(10) - 0.15; jd = S(11) - 0.15
        text(im, t, "Friday night.", NAME_Y, 104, H0 + 0.05, nw)
        text(im, t, "Erev Shabbat", 1020, 130, es, nw, color=GOLD); hebrew(im, t, "ערב שבת", 1135, 66, es + 0.1, nw)
        text(im, t, "Newcomers welcome", NAME_Y, fit("Newcomers welcome", "db", 96), nw, jd)
        s = "Jews and non-Jews"; text(im, t, s, 985, 70, SW(10, "Jews") - 0.15, jd, fk="dm", color=GREY)
        s = "That's what Jews do."; text(im, t, s, NAME_Y, fit(s, "db", 100), jd, t1, color=GOLD)
        text(im, t, "That's Israel.", 985, 76, SW(11, "Israel") - 0.3, t1, fk="dsb")
        a = seg(t, nw, nw + 0.4) * (1 - seg(t, t1, t1 + 0.3)); cheer = seg(t, SW(11, "Israel") - 0.3, SW(11, "Israel") + 0.2)
        def fn(c):
            xs = [250, 395, 540, 685, 830]; cols = [ORANGE, ORANGE, SKY, ORANGE, ORANGE]
            for k, (x, col) in enumerate(zip(xs, cols)):
                u = seg(t, nw + 0.1 * k, nw + 0.1 * k + 0.3)
                if u > 0:
                    c.push_group(); figure(c, x, 1500, 350, col, arm_l=0.85 * cheer, arm_r=0.85 * cheer, smile=1, skirt=(k in (1, 4)), bun=(k == 1))
                    c.pop_group_to_source(); c.paint_with_alpha(u)
            c.set_source_rgb(*rgb("#C9A86A")); rr(c, 150, 1330, 780, 30, 10); c.fill()
            c.set_source_rgb(*rgb("#8A6E3E")); rr(c, 200, 1360, 22, 140, 8); c.fill(); rr(c, 858, 1360, 22, 140, 8); c.fill()
            c.set_source_rgb(*rgb("#E1B866")); c.save(); c.translate(612, 1318); c.scale(1.7, 1); c.arc(0, 0, 22, math.pi, 2 * math.pi); c.restore(); c.fill()
            for cx in (318, 762):
                c.set_source_rgb(*rgb("#F5F5F7")); rr(c, cx - 9, 1252, 18, 78, 4); c.fill()
                fl = 1 + 0.12 * math.sin(t * 13 + cx); c.set_source_rgb(*rgb("#FFC845"))
                c.save(); c.translate(cx, 1232); c.scale(1, fl); c.move_to(0, -24); c.curve_to(14, -6, 12, 12, 0, 14); c.curve_to(-12, 12, -14, -6, 0, -24); c.restore(); c.fill()
        group(Lr, a, fn)
    # ---- I. lines 12 to 14: rude, nosy, family
    if I0 - 0.1 < t < J0 + 0.5:
        t1 = J0; ns = SW(12, "stick") - 0.1; lf = SW(12, "like") - 0.15; q1 = S(13) - 0.1; q2 = SW(13, "Why") - 0.1; bw = S(14) - 0.15
        text(im, t, "Sometimes it's", 400, 100, I0 + 0.05, t1)
        text(im, t, "rude.", 560, 160, SW(12, "rude") - 0.2, t1, color=GOLD)
        text(im, t, "like family.", 730, 84, lf, q1, fk="dsb", color=SKY)
        text(im, t, "For better or worse.", 730, fit("For better or worse.", "db", 96), bw, t1, color=SKY)
        a = seg(t, I0, I0 + 0.35) * (1 - seg(t, t1, t1 + 0.3)); u = seg(t, ns, ns + 1.0); hug = seg(t, bw, bw + 0.5)
        sx = [lerp(150, 300, u), lerp(310, 410, u), lerp(770, 670, u), lerp(930, 780, u)]
        def fn(c):
            figure(c, 540, 1490, 380, ORANGE, sweat=seg(t, q1 + 0.3, q1 + 0.6) * (1 - hug), smile=-1 if (q1 < t < bw) else 1)
            for k, x in enumerate(sx):
                side = -1 if k < 2 else 1
                tk = (0.5 + 0.5 * math.sin(t * 18)) if ((k == 1 and q1 < t < q2 + 0.3) or (k == 2 and q2 < t < bw)) else 0
                figure(c, x, 1490, 340, SKY, lean=-side * 0.35 * u * (1 - hug), arm_l=(0.5 * hug if side > 0 else 0.15 * u), arm_r=(0.5 * hug if side < 0 else 0.15 * u), talk=tk)
        group(Lr, a, fn); Lr.done(im); Lr = Layer()
        bubble(im, Lr, t, "How much do you earn?", 470, 880, (410, 1150), q1, bw - 0.1, size=58)
        bubble(im, Lr, t, "Why aren't you married?", 610, 1040, (680, 1150), q2, bw - 0.1, size=58)
    # ---- J. line 15
    if J0 - 0.1 < t < END_T + 0.4:
        p2 = SW(15, "Have", 2) - 0.15
        text(im, t, "Have you ever", 640, 96, J0 + 0.05, END_T)
        text(im, t, "met Jews?", 800, 150, SW(15, "met") - 0.15, END_T, color=GOLD)
        text(im, t, "Have you ever", 1020, 96, p2, END_T, color=GREY)
        text(im, t, "been to Israel?", 1180, fit("been to Israel?", "db", 140), SW(15, "been") - 0.15, END_T, color=SKY)
    Lr.done(im)
    sources(im, t); subtitles(im, t)
    return im

# ------------------------------------------------------------------ subtitles (hero text carries lines 0, 7, 13, 15, 16)
SKIP = {0, 7, 13, 15, 16}
REPL = [("seventh", "7th"), ("four", "4")]
def chunks(li):
    ws = [w["w"] for w in LW[li]]; out = []; cur = []
    for i, w in enumerate(ws):
        cur.append(i)
        if (w[-1] in ".,?!" and len(cur) >= 3) or len(cur) >= 6: out.append(cur); cur = []
    if cur:
        if out and len(cur) <= 2 and len(out[-1]) + len(cur) <= 7: out[-1] += cur
        else: out.append(cur)
    return out
SUBS = []
for li in range(NL):
    if li in SKIP: continue
    if li == 9: SUBS.append((S(9) - 0.04, E(9) + 0.25, "Erev Shabbat.")); continue
    cs = chunks(li)
    for k, ids in enumerate(cs):
        s = " ".join(LW[li][i]["w"] for i in ids)
        for a_, b_ in REPL: s = re.sub(rf"\b{a_}\b", b_, s)
        a = S(li, ids[0]) - 0.04; b = E(li, ids[-1]) + 0.35
        if k + 1 < len(cs): b = min(b, S(li, cs[k + 1][0]) - 0.06)
        elif li + 1 < NL: b = min(b, S(li + 1) - 0.06)
        SUBS.append((a, b, s)); assert len(s.split()) <= 7, s
SUB_Y = 1610; SRC_Y = 1750
def subtitles(canvas, t):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12)
            lines = wrap(s, SUBF, 900); lay_h = 68 * len(lines) + 30
            ww = max(SUBF.getlength(l) for l in lines) + 56
            box = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(box).rounded_rectangle(
                (540 - ww / 2, SUB_Y - lay_h / 2, 540 + ww / 2, SUB_Y + lay_h / 2), 22, fill=(8, 8, 12, int(170 * al)))
            canvas.alpha_composite(box); flat(canvas, lines, SUBF, SUB_Y, 68, "#FFFFFF", 0.96 * al)
SOURCES = [(0, []), (F0_, ["Tiberias to Re'im: about 200 km by road,", "roughly 2 hours each way"]), (H0, [])]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if lines and t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, SRC_Y, 50, "#9A9AA0", a)

F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + [v[3] for v in PH.values()] + [HOOK_A, HOOK_B, END_A, END_B] + L
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam|follow", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
for v in PH.values(): assert font("r", 36).getlength(v[3]) <= 980, v[3]
assert len(HOOK_A.split()) + len(HOOK_B.split()) <= 6

N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
