"""roads_2000 engine: 2,000 years of roads in the Land of Israel.
Photo hook (Pilgrimage Road, City of David) -> zoom into a full-land map, a year counter runs while roads draw
(Roman, 1869 Ottoman, British Mandate, Israel, Route 6) -> zoom out to the world (Waze) -> back to the photo,
lead-in that loops to the hook. Burned-in subtitles.
python3 engine.py --reel DIR [--frames t1,t2] [--out path.mp4]   (or env REEL_DIR when imported)."""
import json, os, re, sys, math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ARGS = sys.argv[1:] if __name__ == "__main__" else []
D = (ARGS[ARGS.index("--reel") + 1] if "--reel" in ARGS else os.environ["REEL_DIR"]).rstrip("/")
W, H, FPS = 1080, 1920, 30
FONTS = os.environ.get("RK_FONTS", "/home/claude/vid/fonts")
NAVY, NAVY2, SKY, GOLD, YELLOW, WHITE, SILVER = "#163261", "#0E1E3A", "#45A4DD", "#D9B25F", "#FFD54A", "#FFFFFF", "#C9D1DC"
PSXC, GREENL, ROMAN, BRIT, ISRC = "#B8923F", (46, 204, 113), "#8B3A1E", "#F4F1EA", "#163261"
_fc = {}
def F(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def hexa(c, a=255):
    if isinstance(c, tuple): return c[:3] + (int(max(0, min(255, a))),)
    c = c.lstrip("#"); return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), int(max(0, min(255, a))))
def clamp(x): return min(1.0, max(0.0, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def eio(x): x = clamp(x); return x * x * (3 - 2 * x)

# ------------------------------------------------------------------ timing
T = json.load(open(f"{D}/timing.json")); LINES = T["lines"]
END = round(LINES[-1]["t1"] + 0.45, 2)
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]) == norm(word)]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
def le(li): return LINES[li]["t1"]

T_MAP = wt(5, "Zoom")                 # photo shrinks into Jerusalem
T_BS = lt(7)                          # Beit Shemesh 2017
T_1869 = wt(8, "Jump")
T_BRIT = wt(9, "British"); T_ISR = wt(9, "Israel")
T_KM = wt(10, "eight"); T_R6 = lt(11)
T_APP = lt(12); T_WORLD = wt(13, "Waze"); T_USERS = lt(14)
T_BACK = lt(15) - 0.2; T_Q = lt(16) - 0.1

# ------------------------------------------------------------------ photo
PH = Image.open(f"{D}/photos/hook.jpg").convert("RGB")
PH_META = json.load(open(f"{D}/photos/hook.json")) if os.path.exists(f"{D}/photos/hook.json") else {}
CREDIT = "Pilgrims Road stones. Deror_avi, CC BY-SA 3.0"
PH_FOCUS = tuple(json.load(open(f"{D}/cfg.json")).get("focus", [0.5, 0.5])) if os.path.exists(f"{D}/cfg.json") else (0.5, 0.5)
def cover(im, z, fx=0.5, fy=0.5):
    s = max(W / im.width, H / im.height) * z; w, h = im.width * s, im.height * s
    x0 = (w - W) * fx; y0 = (h - H) * fy
    box = (max(0.0, x0 / s), max(0.0, y0 / s), min(float(im.width), (x0 + W) / s), min(float(im.height), (y0 + H) / s))
    return im.resize((W, H), Image.BILINEAR, box=box)
def grad_overlay():
    y = np.linspace(0, 1, H)[:, None]
    a = np.clip(0.82 - 1.6 * y, 0, 1) * 230 + np.clip((y - 0.5) * 1.8, 0, 1) * 210
    a = np.repeat(np.clip(a, 0, 235), W, 1).astype(np.uint8)
    L = Image.new("RGBA", (W, H), hexa(NAVY2)); L.putalpha(Image.fromarray(a)); return L
GRAD = grad_overlay()
PH2 = Image.open(f"{D}/photos/recon.jpg").convert("RGB")
CREDIT2 = "Reconstruction drawing. Deror_avi, CC BY-SA 3.0"
T_RECON = lt(4) - 0.25
def photo_frame(t):
    if t < T_BACK: z = 1.0 + 0.10 * eio(t / max(1, T_MAP))
    else: z = 1.0 + 0.07 * (1 - eio((t - T_BACK) / (END - T_BACK)))     # eases back to the frame-0 zoom: the loop is seamless
    im = cover(PH, z, *PH_FOCUS).convert("RGBA")
    k = clamp((t - T_RECON) / 0.5) if t < T_BACK else 0
    if k > 0:
        im2 = cover(PH2, 1.0 + 0.08 * clamp((t - T_RECON) / 4.0), 0.3, 0.6).convert("RGBA")
        im = Image.blend(im, im2, k)
    im.alpha_composite(GRAD); return im

# ------------------------------------------------------------------ map
G = json.load(open(f"{D}/geo_roads.json"))
LON0, LAT0, KY = 35.05, 31.40, 292.0
KX = KY * math.cos(math.radians(31.4)); CY0 = 990
def P(lon, lat, cam=(LON0, LAT0, 1.0)):
    lo, la, z = cam
    return (540 + (lon - lo) * KX * z, CY0 - (lat - la) * KY * z)
def rings(geom):
    cs = geom["coordinates"]
    if geom["type"] == "Polygon": cs = [cs]
    for poly in cs:
        for r in poly: yield r
def draw_geom(d, geom, cam, fill=None, outline=None, width=2):
    for r in rings(geom):
        pts = [P(x, y, cam) for x, y in r]
        if len(pts) > 2: d.polygon(pts, fill=fill, outline=outline, width=width)
def dashed(d, pts, col, width, on=12, off=8):
    acc, draw_on = 0.0, True
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        L = math.hypot(x1 - x0, y1 - y0); s = 0.0
        while s < L:
            seg = min((on if draw_on else off) - acc, L - s)
            if draw_on:
                a, b = s / L, (s + seg) / L
                d.line([(x0 + (x1 - x0) * a, y0 + (y1 - y0) * a), (x0 + (x1 - x0) * b, y0 + (y1 - y0) * b)], fill=col, width=width)
            s += seg; acc += seg
            if acc >= (on if draw_on else off) - 1e-6: acc = 0.0; draw_on = not draw_on
def base_map(cam=(LON0, LAT0, 1.0)):
    S = 2; im = Image.new("RGBA", (W * S, H * S), hexa("#0B1A33")); d = ImageDraw.Draw(im, "RGBA")
    def Ps(x, y): p = P(x, y, cam); return (p[0] * S, p[1] * S)
    for k, g in G["local"].items():
        for r in rings(g):
            pts = [Ps(x, y) for x, y in r]
            if len(pts) > 2: d.polygon(pts, fill=hexa("#24395F"), outline=hexa("#3E5A8A"), width=2 * S)
    for r in rings(G["israel"]): d.polygon([Ps(x, y) for x, y in r], fill=hexa(GOLD))
    for r in rings(G["psx"]): d.polygon([Ps(x, y) for x, y in r], fill=hexa(PSXC))
    for r in rings(G["psx"]): dashed(d, [Ps(x, y) for x, y in r], hexa(GREENL), 4 * S, 14 * S, 9 * S)
    for r in rings(G["israel"]): d.line([Ps(x, y) for x, y in r] + [Ps(*r[0])], fill=hexa("#F3D894"), width=2 * S)
    im = im.resize((W, H), Image.LANCZOS)
    dd = ImageDraw.Draw(im, "RGBA")
    for nm, lon, lat in [("EGYPT", 33.45, 30.2), ("JORDAN", 36.55, 30.9), ("SYRIA", 36.9, 33.25), ("LEBANON", 35.62, 33.75),
                         ("Mediterranean Sea", 33.9, 32.35)]:
        dd.text(P(lon, lat, cam), nm, font=F(38 if nm[0] != "M" else 36, 800 if nm[0] != "M" else 700),
                fill=hexa("#8FA5C8", 230), anchor="mm")
    return im
CITIES = {"Jerusalem": (35.22, 31.78), "Jaffa": (34.75, 32.05), "Jericho": (35.45, 31.86), "Gaza": (34.45, 31.51), "Ashkelon": (34.56, 31.67),
          "Caesarea": (34.89, 32.50), "Acre": (35.07, 32.92), "Tyre": (35.20, 33.27), "Legio": (35.17, 32.58), "Beit She'an": (35.50, 32.50),
          "Shechem": (35.26, 32.21), "Hebron": (35.10, 31.53), "Beersheba": (34.79, 31.25), "Haifa": (34.99, 32.80), "Tiberias": (35.53, 32.79),
          "Eilat": (34.95, 29.56), "Beit Shemesh": (34.99, 31.75), "Tel Aviv": (34.78, 32.08), "Lod": (34.89, 31.95)}
C = CITIES
def via(*pts): return [C[p] if isinstance(p, str) else p for p in pts]
ROADS = {   # lon/lat polylines, simplified main routes
 "rom_jaffa": via("Jerusalem", (35.15, 31.84), (35.07, 31.88), (34.97, 31.93), "Lod", (34.82, 32.01), "Jaffa"),
 "rom_jericho": via("Jerusalem", (35.30, 31.79), (35.37, 31.82), "Jericho"),
 "rom_coast": via("Gaza", "Ashkelon", (34.66, 31.82), "Jaffa", (34.81, 32.19), "Caesarea", (34.93, 32.65), "Acre", (35.12, 33.08), "Tyre"),
 "rom_legio": via("Caesarea", (35.02, 32.55), "Legio", (35.33, 32.55), "Beit She'an"),
 "rom_north": via("Jerusalem", (35.24, 31.95), "Shechem", (35.33, 32.35), "Beit She'an", "Tiberias"),
 "rom_south": via("Jerusalem", (35.17, 31.66), "Hebron", (34.98, 31.38), "Beersheba"),
 "rom_bs": via((34.93, 31.72), (35.02, 31.77), (35.10, 31.74)),
 "otto_1869": via("Jaffa", (34.87, 31.93), (34.98, 31.84), (35.03, 31.81), (35.12, 31.80), "Jerusalem"),
 "bri_coast": via("Gaza", "Ashkelon", (34.70, 31.90), "Tel Aviv", (34.86, 32.33), (34.92, 32.60), "Haifa", "Acre", (35.10, 33.09)),
 "bri_galil": via("Haifa", (35.15, 32.73), (35.30, 32.70), "Tiberias", (35.57, 33.00), (35.58, 33.25)),
 "bri_south": via("Jerusalem", "Hebron", "Beersheba", (34.60, 31.42), "Gaza"),
 "bri_jordan": via("Jerusalem", "Jericho", (35.55, 32.10), "Beit She'an", "Tiberias"),
 "bri_center": via("Tel Aviv", "Lod", (34.98, 31.84), "Jerusalem"),
 "isr_90": via((35.58, 33.28), "Tiberias", "Beit She'an", (35.52, 32.10), "Jericho", (35.39, 31.46), (35.36, 31.10), (35.18, 30.65), (35.05, 30.0), "Eilat"),
 "isr_40": via("Lod", (34.85, 31.60), "Beersheba", (34.80, 30.61), (35.02, 30.05)),
 "isr_4": via("Ashkelon", (34.75, 31.92), (34.84, 32.10), (34.92, 32.40), "Haifa"),
 "isr_2": via("Tel Aviv", (34.84, 32.30), (34.90, 32.55), "Haifa"),
 "isr_1": via("Tel Aviv", (34.90, 31.98), (35.03, 31.81), "Jerusalem", (35.39, 31.80), "Jericho"),
 "isr_65": via((34.92, 32.45), (35.10, 32.55), (35.29, 32.60), (35.55, 32.88)),
 "isr_85": via("Acre", (35.30, 32.92), (35.55, 32.95)),
 "isr_25": via((34.55, 31.30), "Beersheba", (35.03, 31.07), (35.30, 31.07)),
 "isr_77": via("Haifa", (35.20, 32.76), "Tiberias"),
 "isr_31": via((34.90, 31.35), (35.20, 31.26), (35.38, 31.20)),
 "isr_12": via((34.90, 29.70), "Eilat"),
}
R6 = via((34.83, 31.37), (34.85, 31.60), (34.92, 31.85), (34.95, 32.00), (34.98, 32.20), (35.00, 32.40), (35.07, 32.56), (35.10, 32.68))
ROADS["isr_6"] = R6
MAPBASE = None
def cum(pts):
    c = [0.0]
    for a, b in zip(pts, pts[1:]): c.append(c[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return c
def partial(pts, k):
    if k >= 1: return pts
    if k <= 0: return pts[:1]
    c = cum(pts); L = c[-1] * k; out = [pts[0]]
    for i in range(1, len(pts)):
        if c[i] <= L: out.append(pts[i])
        else:
            f = (L - c[i - 1]) / (c[i] - c[i - 1]); a, b = pts[i - 1], pts[i]
            out.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)); break
    return out
def point_at(pts, k):
    p = partial(pts, k); return p[-1]

# road schedule: name -> (t_start, duration, colour, width, alpha_fn)
SCHED = {}
def sch(names, t0, dur, col, wid, stagger=0.0):
    for i, n in enumerate(names): SCHED[n] = (t0 + i * stagger, dur, col, wid)
sch(["rom_north", "rom_south", "rom_legio"], wt(5, "Rome") + 0.1, 1.6, ROMAN, 9, 0.25)
SCHED["rom_jaffa"] = (wt(6, "Jaffa") - 0.25, 0.9, ROMAN, 10)
SCHED["rom_jericho"] = (wt(6, "Jericho") - 0.25, 0.7, ROMAN, 10)
SCHED["rom_coast"] = (wt(6, "coast") - 0.35, 1.4, ROMAN, 10)
SCHED["rom_bs"] = (wt(7, "Beit") - 0.2, 0.6, ROMAN, 9)
SCHED["otto_1869"] = (wt(8, "paved") - 0.3, 1.0, SKY, 9)
sch(["bri_coast", "bri_center", "bri_south", "bri_galil", "bri_jordan"], T_BRIT - 0.1, 1.1, BRIT, 7, 0.18)
isr = [k for k in ROADS if k.startswith("isr_") and k != "isr_6"]
sch(isr, T_ISR - 0.1, 1.2, ISRC, 7, 0.12)
SCHED["isr_6"] = (T_R6 - 0.1, 1.1, SKY, 12)
def road_alpha(n, t):
    if n.startswith("rom") and t > T_1869: return 1 - 0.55 * clamp((t - T_1869) / 0.6)
    return 1.0
def draw_roads(L, t, cam):
    d = ImageDraw.Draw(L, "RGBA")
    for n, (t0, dur, col, wid) in SCHED.items():
        if t < t0: continue
        k = ease((t - t0) / dur); pts = [P(x, y, cam) for x, y in partial(ROADS[n], k)]
        if len(pts) < 2: continue
        a = road_alpha(n, t); z = cam[2]
        w = max(2, int(wid * min(1.0, z)))
        if n == "isr_6" and t > T_R6:
            glow = 0.5 + 0.5 * math.sin((t - T_R6) * 5)
            d.line(pts, fill=hexa(SKY, int(90 * a * glow)), width=w + 16, joint="curve")
        d.line(pts, fill=hexa(NAVY2 if col not in (ISRC, ROMAN) else "#F7E7B8", int(170 * a)), width=w + 5, joint="curve")
        d.line(pts, fill=hexa(col, int(255 * a)), width=w, joint="curve")
    # milestones: white dots every ~32 px along the Roman roads, popping after the road passes
    if t > wt(6, "Jaffa"):
        for n in ("rom_jaffa", "rom_jericho", "rom_coast", "rom_north", "rom_south", "rom_legio"):
            t0, dur, _, _ = SCHED[n]; pts = ROADS[n]; c = cum([P(x, y, cam) for x, y in pts]); Lp = c[-1]
            m = int(Lp // 34)
            for j in range(1, m + 1):
                f = j / (m + 1); tp = t0 + 0.4 + dur * f
                if t < tp: continue
                s = min(1.0, (t - tp) / 0.2) * (1 - 0.5 * clamp((t - T_1869) / 0.6))
                x, y = P(*point_at(pts, f), cam); r = 5 * s
                d.ellipse((x - r, y - r, x + r, y + r), fill=hexa(WHITE, int(240 * s)), outline=hexa(ROMAN, int(255 * s)), width=2)

def pin(base, x, y, label, a, col=YELLOW, sz=44, side="r"):
    if a <= 0: return
    d = ImageDraw.Draw(base, "RGBA"); r = 13
    d.ellipse((x - r - 5, y - r - 5, x + r + 5, y + r + 5), fill=hexa(NAVY2, int(220 * a)))
    d.ellipse((x - r, y - r, x + r, y + r), fill=hexa(col, int(255 * a)))
    if label:
        f = F(sz, 800); tw = f.getlength(label); pad = 16
        x0 = x + 26 if side == "r" else x - 26 - tw - 2 * pad
        d.rounded_rectangle((x0, y - sz * 0.75, x0 + tw + 2 * pad, y + sz * 0.75), 16, fill=hexa(NAVY2, int(225 * a)))
        txt(base, (x0 + pad, y), label, sz, WHITE, a, 800, "lm")

# ------------------------------------------------------------------ world (Waze)
CITY_W = [(34.78, 32.08), (-74.0, 40.7), (-118.2, 34.05), (-87.6, 41.9), (-95.4, 29.8), (-122.4, 37.8), (-80.2, 25.8), (-77.0, 38.9), (-71.1, 42.4),
          (-79.4, 43.7), (-73.6, 45.5), (-123.1, 49.3), (-99.1, 19.4), (-103.3, 20.7), (-46.6, -23.5), (-43.2, -22.9), (-58.4, -34.6), (-70.6, -33.4),
          (-74.1, 4.7), (-77.0, -12.0), (-66.9, 10.5), (-0.1, 51.5), (2.35, 48.85), (13.4, 52.5), (12.5, 41.9), (-3.7, 40.4), (4.9, 52.4), (16.4, 48.2),
          (21.0, 52.2), (14.4, 50.1), (19.0, 47.5), (26.1, 44.4), (23.7, 37.98), (28.98, 41.0), (-9.1, 38.7), (18.1, 59.3), (10.75, 59.9), (24.9, 60.2),
          (37.6, 55.75), (30.5, 50.45), (31.2, 30.0), (3.4, 6.5), (36.8, -1.3), (28.0, -26.2), (18.4, -33.9), (55.3, 25.2), (46.7, 24.7), (72.9, 19.1),
          (77.2, 28.6), (77.6, 12.97), (100.5, 13.75), (106.8, -6.2), (103.8, 1.35), (101.7, 3.1), (121.0, 14.6), (139.7, 35.7), (126.98, 37.57),
          (151.2, -33.9), (144.96, -37.8), (153.0, -27.5), (174.8, -36.85), (-112.1, 33.4), (-84.4, 33.75), (-97.7, 30.3), (-104.99, 39.7),
          (-90.07, 29.95), (-86.8, 36.2), (-81.7, 41.5), (-117.2, 32.7), (-122.3, 47.6), (8.5, 47.4), (9.2, 45.5), (-6.26, 53.35), (-3.2, 55.95),
          (-8.6, 41.15), (2.17, 41.39), (6.96, 50.94), (11.6, 48.1), (35.5, 33.9), (35.9, 31.95), (-56.2, -34.9), (-49.3, -25.4), (-38.5, -12.97)]
WK = 2.95; WCY = 1010
def PW(lon, lat): return (540 + (lon - 12) * WK, WCY - (lat - 15) * WK * 1.08)
def world_map():
    S = 2; im = Image.new("RGBA", (W * S, H * S), hexa("#0B1A33")); d = ImageDraw.Draw(im, "RGBA")
    for k, g in G["world"].items():
        for r in rings(g):
            pts = [(PW(x, y)[0] * S, PW(x, y)[1] * S) for x, y in r]
            if len(pts) > 2: d.polygon(pts, fill=hexa("#24395F"), outline=hexa("#3E5A8A"), width=S)
    return im.resize((W, H), Image.LANCZOS)
WORLD = None
TLV = PW(34.78, 32.08)
CITY_T = sorted(CITY_W, key=lambda c: math.hypot(PW(*c)[0] - TLV[0], PW(*c)[1] - TLV[1]))

# ------------------------------------------------------------------ text helpers
def txt(base, xy, s, sz, col=WHITE, a=1.0, w=900, anchor="mm"):
    if a <= 0.01: return
    d = ImageDraw.Draw(base, "RGBA")
    if a >= 0.999: d.text(xy, s, font=F(sz, w), fill=hexa(col), anchor=anchor); return
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); ImageDraw.Draw(L).text(xy, s, font=F(sz, w), fill=hexa(col), anchor=anchor)
    L.putalpha(L.getchannel("A").point(lambda v: int(v * a))); base.alpha_composite(L)
def rich(base, y, parts, sz, a=1.0, x=None):
    """parts: [(text, colour), ...] on one centred line"""
    f = F(sz, 900); tw = sum(f.getlength(s) for s, _ in parts); x = (W - tw) / 2 if x is None else x
    for s, c in parts: txt(base, (x, y), s, sz, c, a, anchor="ls"); x += f.getlength(s)
def panel(base, box, a, col=NAVY2, alpha=215, r=34):
    if a <= 0: return
    ImageDraw.Draw(base, "RGBA").rounded_rectangle(box, r, fill=hexa(col, int(alpha * a)))
def source(base, s, a=1.0, y=1440):
    if a <= 0.01 or not s: return
    f = F(36, 700); tw = f.getlength(s)
    panel(base, (540 - tw / 2 - 18, y - 30, 540 + tw / 2 + 18, y + 28), a, alpha=190, r=18)
    txt(base, (540, y), s, 36, SILVER, a, 700)
def win(t, t0, t1, fi=0.3, fo=0.3): return clamp((t - t0) / fi) * clamp((t1 - t) / fo)

# ------------------------------------------------------------------ phases
def hook_text(base, t, a):
    k = ease((t - lt(1) + 0.2) / 0.5)            # shrinks a little once the story starts
    sz = int(128 - 22 * k); y = 470 - 120 * k
    rich(base, y, [("This street is", WHITE)], sz, a)
    rich(base, y + sz * 1.08, [("2,000", YELLOW), (" years old.", WHITE)], sz, a)
CARDS = [  # (line, t_in word, lines[(parts, size)], source)
    (1, None, [([("Paved under", WHITE)], 76), ([("Pontius Pilate", YELLOW)], 92), ([("Roman governor of Judea, 26 to 36 CE", SILVER)], 44)], "Szanton et al., Tel Aviv journal, 2019"),
    (2, None, [([("Newest coin beneath it", WHITE)], 72), ([("30/31 CE", YELLOW)], 150)], "Szanton et al., Tel Aviv journal, 2019"),
    (3, None, [([("Pool of Siloam", WHITE)], 76), ([("up to the Temple", WHITE)], 76), ([("600 m", YELLOW)], 140)], "Szanton et al., 2019: about 600 m long, 8 m wide"),
    (4, None, [([("Walked by", WHITE)], 76), ([("Jewish pilgrims", YELLOW)], 96), ([("at every festival", WHITE)], 76)], "Pilgrimage Road, City of David, Jerusalem"),
]
def photo_cards(base, t):
    for n, (li, _, rows, src) in enumerate(CARDS):
        t0 = lt(li) - 0.15; t1 = lt(CARDS[n + 1][0]) - 0.15 if n + 1 < len(CARDS) else T_MAP
        a = win(t, t0, t1, 0.25, 0.2)
        if a <= 0: continue
        dy = (1 - ease((t - t0) / 0.35)) * 40
        hs = [int(s * 1.15) for _, s in rows]; tot = sum(hs); y0 = 1210 - tot / 2 + dy
        panel(base, (70, y0 - 40, 1010, y0 + tot + 30), a)
        y = y0
        for (parts, s), h in zip(rows, hs):
            rich(base, y + h * 0.8, parts, s, a); y += h
        source(base, src, a)
    txt(base, (540, 1502), CREDIT2 if t >= T_RECON + 0.25 else CREDIT, 36, SILVER, 0.85 * clamp(1 - (t - T_MAP) / 0.3), 700)

def year_of(t):
    keys = [(0, 31), (wt(5, "Rome"), 31), (le(6), 130), (T_1869 - 0.05, 130), (wt(8, "sixtynine", end=True) + 0.2, 1869),
            (T_BRIT, 1869), (T_ISR - 0.1, 1920), (T_ISR + 0.3, 1948), (T_KM + 1.4, 2026)]
    for (ta, ya), (tb, yb) in zip(keys, keys[1:]):
        if t <= tb: return int(round(ya + (yb - ya) * eio((t - ta) / max(0.01, tb - ta))))
    return 2026
ERA = [(T_MAP, "Roman roads"), (T_BS, "Roman roads"), (T_1869, "Ottoman era"), (T_BRIT, "British Mandate"), (T_ISR + 0.2, "Israel")]
def counter(base, t, a):
    y = year_of(t); s = str(y)
    panel(base, (0, 0, W, 410), a, NAVY2, 200, 0)
    rich(base, 300, [(s, YELLOW), (" CE" if y < 1000 else "", YELLOW)], 168, a)
    era = [e for tt, e in ERA if t >= tt - 0.1][-1] if t >= ERA[0][0] - 0.1 else ""
    txt(base, (540, 365), era, 52, WHITE, a, 800)
def map_overlays(base, t, a):
    # Beit Shemesh find
    if T_BS - 0.1 < t < T_1869 + 0.3:
        k = win(t, T_BS - 0.1, T_1869 + 0.3, 0.3, 0.3) * a; x, y = P(*C["Beit Shemesh"])
        pin(base, x, y, "Found 2017", k, YELLOW, 46, "l")
        panel(base, (90, 1180, 990, 1380), k); rich(base, 1262, [("Roman road, Beit Shemesh", WHITE)], 64, k)
        rich(base, 1340, [("Coin inside: ", WHITE), ("Pilate, 29 CE", YELLOW)], 60, k)
        source(base, "Israel Antiquities Authority, 2017", k)
    if t < T_BS and t > wt(6, "Jaffa") - 0.2:
        k = win(t, wt(6, "Jaffa") - 0.2, T_BS, 0.3, 0.3) * a
        for nm in ("Jaffa", "Jericho", "Caesarea"):
            x, y = P(*C[nm]); pin(base, x, y, nm, k * clamp((t - SCHED["rom_" + {"Jaffa": "jaffa", "Jericho": "jericho", "Caesarea": "coast"}[nm]][0] - 0.4) / 0.3), WHITE, 40, "l" if nm != "Jericho" else "r")
        source(base, "Roman Roads in Judaea (Isaac, Roll, Fischer); routes simplified", k)
    if a > 0 and t > T_MAP + 0.8:
        x, y = P(*C["Jerusalem"]); pin(base, x, y, "Jerusalem" if t < wt(6, "Jaffa") - 0.2 or t > T_1869 else "", a, YELLOW, 40)
    if T_1869 < t < T_BRIT:
        k = win(t, wt(8, "paved") - 0.2, T_BRIT, 0.3, 0.3) * a
        panel(base, (90, 1200, 990, 1370), k); rich(base, 1280, [("1869", YELLOW), (": Jaffa road paved", WHITE)], 64, k)
        rich(base, 1350, [("for Emperor Franz Joseph's visit", SILVER)], 46, k); source(base, "Globes, history of Jaffa Road", k)
    if T_BRIT - 0.1 < t < T_KM:
        k = win(t, T_BRIT - 0.1, T_KM, 0.3, 0.3) * a
        source(base, "Main routes, simplified. Green Line in green", k)
    if T_KM - 0.2 < t < T_R6:
        k = win(t, T_KM - 0.2, T_R6, 0.3, 0.3) * a; v = int(8500 * ease((t - T_KM) / 1.4)) // 10 * 10
        panel(base, (90, 1170, 990, 1385), k); rich(base, 1290, [(f"{v:,} km", YELLOW)], 120, k)
        rich(base, 1360, [("of intercity roads alone", WHITE)], 50, k)
        source(base, "State Comptroller, 2021 (Netivei Israel data, 2019)", k)
    if T_R6 - 0.1 < t < T_WORLD:
        k = win(t, T_R6 - 0.1, T_WORLD - 0.3, 0.3, 0.3) * a
        x, y = P(35.0, 32.30); pin(base, x, y, "Route 6", k, SKY, 46, "r")
        if t < T_APP:
            panel(base, (90, 1180, 990, 1380), k); rich(base, 1265, [("204 km", YELLOW)], 92, k)
            rich(base, 1345, [("not one toll booth", WHITE)], 60, k)
            source(base, "Cross-Israel Highway: cameras, no booths", k)
        else:   # a driver runs up Route 6
            f = clamp((t - T_APP) / (T_WORLD - T_APP)); x, y = P(*point_at(R6, f)); r = 16 + 3 * math.sin(t * 9)
            d = ImageDraw.Draw(base, "RGBA"); d.ellipse((x - r - 8, y - r - 8, x + r + 8, y + r + 8), fill=hexa(SKY, 90))
            d.ellipse((x - r, y - r, x + r, y + r), fill=hexa(WHITE), outline=hexa(SKY), width=5)
def world_phase(base, t):
    global WORLD
    a = clamp((t - (T_WORLD - 0.45)) / 0.45) * (1 - clamp((t - T_BACK) / 0.4))
    if a <= 0: return
    if WORLD is None: WORLD = world_map()
    zk = ease((t - (T_WORLD - 0.45)) / 1.1); z = 7.0 ** (1 - zk)        # zoom out from Israel to the world
    if z > 1.001:
        w2, h2 = W / z, H / z; cx, cy = TLV[0] + (540 - TLV[0]) * zk, TLV[1] + (WCY - TLV[1]) * zk
        x0, y0 = cx - w2 / 2, cy - h2 / 2
        x0 = min(max(0.0, x0), W - w2); y0 = min(max(0.0, y0), H - h2)
        im = WORLD.resize((W, H), Image.BILINEAR, box=(x0, y0, x0 + w2, y0 + h2))
    else: im = WORLD.copy()
    L = im.copy(); d = ImageDraw.Draw(L, "RGBA")
    for i, c in enumerate(CITY_T):
        tp = T_WORLD + 0.6 + i * 0.045
        if t < tp: continue
        s = clamp((t - tp) / 0.25); x, y = PW(*c)
        if z > 1.001: continue
        r = max(1.0, 7 * s + 2 * math.sin(t * 4 + i)); d.ellipse((x - r - 6, y - r - 6, x + r + 6, y + r + 6), fill=hexa(SKY, int(70 * s)))
        d.ellipse((x - r, y - r, x + r, y + r), fill=hexa(SKY if i else YELLOW, int(255 * s)))
    panel(L, (0, 0, W, 560), 1, NAVY2, 170, 0)
    k1 = clamp((t - T_WORLD - 0.2) / 0.3)
    rich(L, 290, [("Waze", SKY)], 150, k1)
    rich(L, 400, [("Israeli app. Google bought it, 2013", WHITE)], 52, k1)
    rich(L, 470, [("for about ", WHITE), ("$1.1 billion", YELLOW)], 60, k1)
    k2 = clamp((t - T_USERS + 0.1) / 0.3)
    if k2 > 0:
        v = int(140 * ease((t - T_USERS) / 1.2))
        panel(L, (90, 1230, 990, 1420), k2); rich(L, 1335, [(f"{v}M+", YELLOW), (" drivers", WHITE)], 100, k2)
        rich(L, 1400, [("every month", WHITE)], 50, k2)
        source(L, "CNBC, 2022: more than 140 million monthly users", k2, 1470)
    else: source(L, "Bloomberg, June 2013, via CSMonitor and Ynet", k1, 1470)
    L.putalpha(L.getchannel("A").point(lambda v: int(v * a))); base.alpha_composite(L)

def map_phase(base, t):
    global MAPBASE
    if t < T_MAP - 0.05 or t > T_WORLD + 0.8: return
    if MAPBASE is None: MAPBASE = base_map()
    a = clamp((t - T_MAP) / 0.6)
    L = MAPBASE.copy(); draw_roads(L, t, (LON0, LAT0, 1.0))
    if a < 1: L.putalpha(L.getchannel("A").point(lambda v: int(v * a)))
    base.alpha_composite(L)
    counter(base, t, a * (1 - clamp((t - T_WORLD + 0.4) / 0.3)))
    map_overlays(base, t, a)

def shrink_photo(base, t):
    """the photo flies into Jerusalem on the map"""
    k = ease((t - T_MAP) / 0.9)
    if k >= 1: return
    im = photo_frame(t); jx, jy = P(*C["Jerusalem"]); s = 1 - 0.97 * k
    w, h = max(2, int(W * s)), max(2, int(H * s)); sm = im.resize((w, h), Image.BILINEAR)
    m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), int(60 * k + 1), fill=int(255 * (1 - k ** 3)))
    x = 540 + (jx - 540) * k - w / 2; y = 960 + (jy - 960) * k - h / 2
    base.paste(sm, (int(x), int(y)), m)

def back_phase(base, t):
    a = clamp((t - T_BACK) / 0.5)
    if a <= 0: return
    im = photo_frame(t)
    if a < 1: im.putalpha(int(255 * a))
    base.alpha_composite(im)
    k = win(t, T_BACK + 0.1, T_Q, 0.3, 0.25)
    if k > 0:
        rich(base, 430, [("From a stone street", WHITE)], 96, k); rich(base, 540, [("for pilgrims", YELLOW)], 96, k)
        rich(base, 680, [("to the map", WHITE)], 96, k); rich(base, 790, [("in your pocket", SKY)], 96, k)
    q = clamp((t - T_Q) / 0.3)
    if q > 0:
        rich(base, 440, [("So next time someone", WHITE)], 92, q); rich(base, 545, [("says Jews are ", WHITE), ("new", YELLOW)], 92, q)
        rich(base, 650, [("here, show them this:", WHITE)], 92, q)
    txt(base, (540, 1502), CREDIT, 36, SILVER, 0.85 * a, 700)

def frame(t):
    base = Image.new("RGBA", (W, H), hexa("#0B1A33"))
    if t < T_MAP + 1.0:
        if t < T_MAP: base.alpha_composite(photo_frame(t))
    map_phase(base, t)
    if T_MAP <= t < T_MAP + 1.0: shrink_photo(base, t)
    if t < T_MAP + 0.2:
        a = 1 - clamp((t - T_MAP) / 0.2); hook_text(base, t, a); photo_cards(base, t)
    world_phase(base, t)
    back_phase(base, t)
    subs(base, t)
    return base.convert("RGB")

# ------------------------------------------------------------------ subtitles
REPL = [("two thousand", "2,000"), ("thirty-one", "31"), ("twenty seventeen", "2017"), ("eighteen sixty-nine", "1869"),
        ("eight and a half thousand", "8,500"), ("two hundred", "200"), ("twenty thirteen", "2013"), ("a hundred and forty million", "140 million")]
SUBF = F(54, 800); SUB_BOTTOM = 1640
SUB_ITEMS = []
for li, L_ in enumerate(LINES):
    if li in (0, len(LINES) - 1): continue           # hook and lead-in are already on screen as big type
    ws = L_["words"]; toks = [w["w"] for w in ws]; lock = [False] * len(ws)
    low = [norm(x) for x in toks]
    for ph, _ in REPL:
        p = [norm(x) for x in ph.replace("-", "- ").split()]; p = [x for x in p if x]
        pj = "".join(p)
        for i in range(len(low)):
            for j in range(i + 1, min(len(low), i + 6) + 1):
                if "".join(low[i:j]) == pj:
                    for q in range(i, j - 1): lock[q] = True
    chunks, cur = [], []
    for i, w in enumerate(ws):
        cur.append(i)
        brk = (re.search(r"[.,?!:]$", w["w"]) and len(cur) >= 2) or len(cur) >= 6
        if brk and not lock[i]: chunks.append(cur); cur = []
    if cur:
        if chunks and len(cur) == 1: chunks[-1] += cur
        else: chunks.append(cur)
    for ch in chunks:
        s = " ".join(ws[i]["w"] for i in ch)
        for a_, b_ in REPL: s = re.sub(re.escape(a_), b_, s, flags=re.I)
        s = s.replace("Route 6:", "Route 6:")
        SUB_ITEMS.append((ws[ch[0]]["t0"] - 0.05, ws[ch[-1]]["t1"] + 0.12, s))
SUB_ITEMS.sort()
for k in range(len(SUB_ITEMS) - 1):
    a0, a1, tx = SUB_ITEMS[k]; b0 = SUB_ITEMS[k + 1][0]
    SUB_ITEMS[k] = (a0, b0 if b0 - a1 < 0.25 else min(a1, b0), tx)
def wrap(s, font, maxw):
    out, cur = [], ""
    for w_ in s.split():
        tst = (cur + " " + w_).strip()
        if font.getlength(tst) <= maxw: cur = tst
        else: out.append(cur); cur = w_
    out.append(cur); return out
def subs(base, t):
    for a0, a1, s in SUB_ITEMS:
        if a0 <= t < a1:
            ls = wrap(s, SUBF, 900); lh = 66; bh = lh * len(ls) + 26; wmax = max(SUBF.getlength(l) for l in ls) + 52
            d = ImageDraw.Draw(base, "RGBA"); y0 = SUB_BOTTOM - bh
            d.rounded_rectangle((540 - wmax / 2, y0, 540 + wmax / 2, SUB_BOTTOM), 22, fill=(8, 16, 34, 215))
            for n, l in enumerate(ls): d.text((540, y0 + 13 + lh * n + lh / 2), l, font=SUBF, fill=hexa(WHITE), anchor="mm")
            return

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        for s in ARGS[ARGS.index("--frames") + 1].split(","):
            frame(float(s)).resize((540, 960), Image.LANCZOS).save(f"{out}/f_{float(s):06.2f}.jpg", quality=85)
        print("END", END); sys.exit()
    if "--subs" in ARGS:
        for x in SUB_ITEMS: print(round(x[0], 2), round(x[1], 2), x[2])
        sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
