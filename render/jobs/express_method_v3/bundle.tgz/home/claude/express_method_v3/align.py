#!/usr/bin/env python3
"""Split one narration file into the narration.txt lines (keys from beats.py) using ASR, not just pause length.

  python3 align.py noam.mp3            -> cues.json  [{key, v0, v1, asr, score}], times in the source file

Speech chunks come from ffmpeg silencedetect (short 0.25 s minimum, so shortened breaks are still found);
each chunk is transcribed with sherpa-onnx whisper turbo; a DP assigns consecutive chunks to lines by text
similarity. Numbers are compared as spoken words (8088 -> eighty eighty eight) and as digits.
Copied from /home/claude/israel_tech/align.py (same approach as /home/claude/hatikvah/work/align.py).
Then: python3 render.py --vo noam.mp3 --cues cues.json [--gap 0.4]
"""
import subprocess, re, json, difflib, functools, sys, os
import numpy as np, soundfile as sf, sherpa_onnx

HERE = os.path.dirname(os.path.abspath(__file__))
src = os.path.abspath(sys.argv[1])
sys.path.insert(0, HERE)
from beats import KEYS
txt = [l.strip() for l in open(os.path.join(HERE, "narration.txt"), encoding="utf8") if l.strip()]
assert len(txt) == len(KEYS)
wav = os.path.join(HERE, "work_vo16.wav")
subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", src, "-ar", "16000", "-ac", "1", wav], check=True)
x, sr = sf.read(wav, dtype="float32"); D = len(x) / sr

def chunks(mind):
    o = subprocess.run(["ffmpeg", "-hide_banner", "-i", wav, "-af", f"silencedetect=noise=-38dB:d={mind}", "-f", "null", "-"], capture_output=True, text=True).stderr
    st = [float(v) for v in re.findall(r"silence_start: ([\d.]+)", o)]; en = [float(v) for v in re.findall(r"silence_end: ([\d.]+)", o)]
    b, a = [], 0.0
    for s, e in zip(st, en):
        if s > a + 0.12: b.append((a, s))
        a = e
    if D - a > 0.2: b.append((a, D))
    return b
B = chunks(0.25)
M = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=M + "turbo-encoder.int8.onnx", decoder=M + "turbo-decoder.int8.onnx",
                                                 tokens=M + "turbo-tokens.txt", language="en", task="transcribe", num_threads=2)
ct = []
for a, b in B:
    seg = np.concatenate([x[int(max(0, a - 0.05) * sr):int((b + 0.1) * sr)], np.zeros(int(0.4 * sr), dtype="float32")])
    s = asr.create_stream(); s.accept_waveform(16000, seg); asr.decode_stream(s); ct.append(s.result.text.strip())

SPOKEN = {"@expressenglishcom": "at express english dot com", "10": "ten"}
def norm(t): return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", t.lower())).strip()
def spoken(t):
    for k in sorted(SPOKEN, key=len, reverse=True): t = re.sub(rf"(?<![\w,@]){re.escape(k)}(?![\d,])", SPOKEN[k], t)
    return t
REF = [(norm(t), norm(spoken(t))) for t in txt]
def sim(i, j, k):
    h = norm(" ".join(ct[i:j])); hs = norm(spoken(" ".join(ct[i:j])))
    return max(difflib.SequenceMatcher(None, h, REF[k][0]).ratio(), difflib.SequenceMatcher(None, hs, REF[k][1]).ratio(),
               difflib.SequenceMatcher(None, h, REF[k][1]).ratio())
n, m = len(txt), len(ct)
sys.setrecursionlimit(10000)
@functools.lru_cache(None)
def best(i, k):
    if k == n: return (0.0, ()) if i == m else (-1e9, ())
    if i == m: return (-1e9, ())
    r = (-1e9, ())
    for j in range(i + 1, m + 1 - (n - k - 1)):
        v, p = best(j, k + 1); v += sim(i, j, k)
        if v > r[0]: r = (v, ((i, j),) + p)
    return r
_, part = best(0, 0)
out = []
for k, (i, j) in enumerate(part):
    a, b = B[i][0], B[j - 1][1]
    out.append(dict(key=KEYS[k], v0=round(a, 3), v1=round(b, 3), asr=" / ".join(ct[i:j]), score=round(sim(i, j, k), 2)))
    print(f"{KEYS[k]:5s} {a:6.2f} {b:6.2f}  {sim(i, j, k):.2f} | {' / '.join(ct[i:j])}")
gaps = [round(out[k + 1]["v0"] - out[k]["v1"], 2) for k in range(n - 1)]
print("duration", round(D, 2), "chunks", m, "breaks", gaps)
json.dump(out, open(os.path.join(HERE, "cues.json"), "w"), indent=1)
