"""Original music bed for the express_method reel. Based on /home/claude/english_origin/music.py (via israel_tech):
optional 6th arg = duration in seconds; new style "bright" = major progression, 8th note hats and offbeat stabs
over the same pad / bass / kick / pluck engine. Output in /home/claude/express_method/.
Usage: python3 music.py TAG STYLE TRANSPOSE BPM SEED [DUR]"""
import sys, numpy as np, wave
tag,style,T,BPM,seed=sys.argv[1],sys.argv[2],int(sys.argv[3]),float(sys.argv[4]),int(sys.argv[5])
DURARG=float(sys.argv[6]) if len(sys.argv)>6 else 64.0
SR=44100; DUR=DURARG; n=int(SR*DUR); t=np.arange(n)/SR; out=np.zeros(n); rng=np.random.default_rng(seed)
def note(m): return 440*2**((m-69+T)/12)
def place(sig,st,g=1.0):
    i=int(st*SR); j=min(n,i+len(sig))
    if i<n and j>i: out[i:j]+=g*sig[:j-i]
def lp(x,a):
    y=np.empty_like(x); s=0.0
    for i in range(len(x)): s+=a*(x[i]-s); y[i]=s
    return y
beat=60/BPM; bar=4*beat; nb=int(DUR/bar)+1
PROGS=[[(45,[57,60,64]),(41,[57,60,65]),(43,[55,59,62]),(40,[55,59,64])],[(45,[57,60,64]),(43,[55,59,62]),(41,[57,60,65]),(43,[55,59,62])],[(50,[62,65,69]),(46,[58,62,65]),(48,[60,64,67]),(45,[57,61,64])],[(45,[57,60,64]),(48,[60,64,67]),(43,[55,59,62]),(41,[57,60,65])]]
if style=="comic":
    prog=[(48,[60,64,67]),(53,[60,65,69]),(55,[59,62,67]),(48,[60,64,67])]
    mel=[[72,76,79,76,74,72,74,76],[77,76,74,72,74,72,69,72],[71,74,79,77,76,74,71,74],[72,67,72,76,79,76,72,72]]
else:
    prog=[(45,[57,60,64]),(41,[57,60,65]),(43,[55,59,62]),(40,[55,59,64])]
    mel=[[69,72,76,72,74,72,71,72],[69,72,77,76,74,72,74,76],[67,71,74,71,72,71,67,71],[68,71,76,74,72,71,68,64]]
    if style=="bright":
        prog=[(48,[60,64,67]),(43,[55,59,62]),(45,[57,60,64]),(41,[57,60,65])]
        mel=[[72,76,79,76,74,76,72,67],[71,74,79,74,71,74,79,81],[72,76,81,79,76,72,76,79],[77,76,72,69,72,74,76,79]]
    elif seed>=22:
        prog=PROGS[seed%4]
        r2=np.random.default_rng(seed*7)
        mel=[[c[1][int(r2.integers(0,3))]+12*int(r2.integers(0,2))+12 if False else c[1][int(r2.integers(0,3))]+12 for _ in range(8)] for c in prog]
for b in range(nb):
    root,ch=prog[b%4]; st=b*bar; inten=min(1,0.45+st/30)
    if style=="comic":
        for q in range(4):  # oom-pah bass
            m=root-12 if q%2==0 else root-5
            tt=np.arange(int(beat*0.45*SR))/SR; place(np.sin(2*np.pi*note(m)*tt)*np.exp(-tt*9),st+q*beat,0.30)
        for q in (1,3):     # chord stabs
            tt=np.arange(int(0.18*SR))/SR; s=sum(np.sign(np.sin(2*np.pi*note(mm)*tt))*0.3+np.sin(2*np.pi*note(mm)*tt) for mm in ch)
            place(lp(s*np.exp(-tt*16),0.25),st+q*beat,0.06)
        if b>=2:            # xylophone melody
            for q,m in enumerate(mel[b%4]):
                tt=np.arange(int(0.35*SR))/SR; f=note(m)
                place((np.sin(2*np.pi*f*tt)+0.4*np.sin(2*np.pi*4*f*tt)*np.exp(-tt*30))*np.exp(-tt*10),st+q*beat/2,0.09*inten)
        if b>=1:            # woodblock + shaker
            for q in range(8):
                nz=rng.standard_normal(int(0.03*SR)); nz=(nz-lp(nz,0.5))*np.exp(-np.arange(len(nz))/SR*120); place(nz,st+q*beat/2,0.03)
            tt=np.arange(int(0.06*SR))/SR; place(np.sin(2*np.pi*900*tt)*np.exp(-tt*60),st+3.5*beat,0.08)
    else:
        L=bar+0.3; tt=np.arange(int(L*SR))/SR; pad=np.zeros_like(tt)
        for m in ch:
            for d in (-0.1,0.1): pad+=np.sin(2*np.pi*note(m-12)*2**(d/12)*tt)+0.3*np.sin(4*np.pi*note(m-12)*tt)
        env=np.minimum(1,tt/0.5)*np.minimum(1,(L-tt)/0.4); place(lp(pad*env,0.08),st,0.03)
        for q in range(8):  # driving soft bass 8ths
            tt=np.arange(int(beat*0.45*SR))/SR; place(np.sin(2*np.pi*note(root-12)*tt)*np.exp(-tt*6),st+q*beat/2,0.18*inten)
        if b>=1:
            for q in range(4):  # soft kick, snare on 2 & 4
                tt=np.arange(int(0.3*SR))/SR; f=48+55*np.exp(-tt*22); place(np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*9),st+q*beat,0.35*inten)
                if q%2: nz=rng.standard_normal(int(0.15*SR)); nz=(nz-lp(nz,0.3))*np.exp(-np.arange(len(nz))/SR*25); place(nz,st+q*beat,0.05*inten)
        if style=="bright" and b>=2:
            for q in range(8):  # closed hats on 8ths
                nz=rng.standard_normal(int(0.04*SR)); nz=(nz-lp(nz,0.7))*np.exp(-np.arange(len(nz))/SR*90); place(nz,st+q*beat/2,(0.035 if q%2 else 0.02)*inten)
            for q in range(4):  # offbeat chord stabs
                tt=np.arange(int(0.16*SR))/SR; s_=sum(np.sin(2*np.pi*note(mm)*tt)+0.3*np.sin(4*np.pi*note(mm)*tt) for mm in ch)
                place(s_*np.exp(-tt*14),st+q*beat+beat/2,0.022*inten)
        if b>=3:            # plucked melody
            for q,m in enumerate(mel[b%4]):
                tt=np.arange(int(0.5*SR))/SR; f=note(m)
                place((np.sin(2*np.pi*f*tt)+0.25*np.sin(4*np.pi*f*tt))*np.exp(-tt*5),st+q*beat/2,0.06*inten)
tt=np.arange(int(4.5*SR))/SR; fc=np.zeros_like(tt)
for m in prog[0][1]+[prog[0][0],prog[0][0]+12]: fc+=np.sin(2*np.pi*note(m)*tt)
place(fc*np.exp(-tt*0.8)*np.minimum(1,tt/0.03),DUR-5,0.05)
out=np.tanh(out*1.3); out[-int(2*SR):]*=np.linspace(1,0,int(2*SR)); out=out/np.max(np.abs(out))*0.85
st=np.stack([out,np.roll(out,int(0.012*SR))],1)
w=wave.open(f"/home/claude/express_method_v3/music_{tag}.wav","wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((st*32767).astype(np.int16).tobytes()); w.close(); print("ok")
