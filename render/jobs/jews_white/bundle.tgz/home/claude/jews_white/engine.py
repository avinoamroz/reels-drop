"""jews_white: deadpan satire. "Jews are white. Obviously." 9 illustrated Jewish figures start as white silhouettes (the claim),
each is revealed in its own colours with a sarcastic label, then the pivot: Pew 2016 (48% Mizrahi or Sephardi), a map with arrows
from 9 origins and a counter, CBS 177,600 Ethiopian Israelis, "Not a skin color. A people." Circular: the figures whiten back
into frame 0.   python3 engine.py [--frames t1,t2,...] [--out path.mp4]   (DIR: timing.json, geo_il.json, geo_world.json, mix.m4a)
Figures are flat, faceless, respectful illustrations drawn in code (no photos of people)."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"


def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def mixc(c1, c2, u): return tuple(lerp(a, b, u) for a, b in zip(c1[:3], c2[:3])) + (1.0,)

NAVYD, NAVY, ROYAL, SKY, YEL = hx("#0E1E3A"), hx("#163261"), hx("#2749D3"), hx("#45A4DD"), hx("#FFD54A")
GREEN = (46 / 255, 204 / 255, 113 / 255, 1); SILVER = hx("#C9D1DC"); WHITE = (1, 1, 1, 1)
SIL = hx("#F4F6FA")                    # "white" silhouette colour (the claim)
GOLD_IL, GOLD_PA = hx("#E0B252"), hx("#B8923F")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    if a <= 0.01 or not s: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def parts(c, ps, size, y, a=1.0, w=900, sc=1.0, maxw=980):
    """centred run of (string, colour) parts on one baseline; shrinks to fit maxw"""
    while size > 64 and sum(font(size, w).getlength(s) for s, _ in ps) > maxw: size -= 2
    tot = sum(font(size, w).getlength(s) for s, _ in ps); x = 540 - tot / 2
    c.save(); c.translate(540, y); c.scale(sc, sc); c.translate(-540, -y)
    for s, col in ps: x += text(c, s, size, x, y, w, col, a, "l")
    c.restore()
def fit(s, size, maxw, w=800, mn=36):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 1.15, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1
T_FADE = END - 0.85

# ------------------------------------------------------------------ the people (flat, faceless illustrations)
# key, place on the card, sarcastic label parts, skin, look
FIG = [
    ("yemen", "Yemen", [("Yemenite ", WHITE), ("white", YEL)], "#9A6340", "yemen"),
    ("ethiopia", "Ethiopia", [("Ethiopian ", WHITE), ("white", YEL)], "#5A3720", "kes"),
    ("morocco", "Morocco", [("Moroccan ", WHITE), ("white", YEL)], "#C48A5C", "kaftan"),
    ("iraq", "Iraq", [("Iraqi ", WHITE), ("white", YEL)], "#B27A50", "sidara"),
    ("iran", "Iran", [("Persian ", WHITE), ("white", YEL)], "#C99868", "persian"),
    ("kurd", "Kurdistan", [("Kurdish ", WHITE), ("white", YEL)], "#BE8A60", "kurd"),
    ("bukhara", "Bukhara", [("Bukharan ", WHITE), ("white", YEL)], "#D2A47C", "bukhara"),
    ("india", "India", [("Indian ", WHITE), ("white", YEL)], "#8A5636", "sari"),
    ("poland", "Poland", [("Ashkenazi: ", WHITE), ("actually white", YEL)], "#F1D2BE", "ashk"),
]
SUBL = {7: "Bene Israel", 0: "", 1: "Beta Israel"}
REVEAL_LINE = [2, 3, 4, 5, 6, 7, 8, 9, 10]
def reveal_t(k):
    li = REVEAL_LINE[k]; place = {"yemen": "Yemen", "ethiopia": "Ethiopia"}.get(FIG[k][0])
    return wt(li, place) - 0.05 if place else CUT[li] + 0.05
RT = [reveal_t(k) for k in range(9)]
T_GRID_OUT = CUT[12]              # grid leaves for the stat
T_GRID_IN = CUT[16]               # grid comes back
T_WHITEN = lt(17) + 0.1           # the loop: everyone back to "white"

def bust(c, x, y, s, k, wht, a=1.0):
    """draw figure k with its feet line at (x, y), scale s. wht 0 = true colours, 1 = white silhouette"""
    if a <= 0.01: return
    key, _, _, skin, look = FIG[k]
    def C(h): return mixc(hx(h) if isinstance(h, str) else h, SIL, wht)
    def fill(h, al=1.0): col = C(h); c.set_source_rgba(col[0], col[1], col[2], al); c.fill()
    c.save(); c.translate(x, y); c.scale(s, s)
    c.push_group()
    sk = skin
    # back hair (women)
    if look in ("persian",):
        c.move_to(-58, -150); c.curve_to(-70, -60, -78, -30, -64, -10); c.line_to(64, -10); c.curve_to(78, -30, 70, -60, 58, -150); c.close_path(); fill("#1E1410")
    if look == "sari":
        c.arc(0, -205, 30, 0, 6.283); fill("#181010")          # bun
    # neck
    rr(c, -19, -118, 38, 46, 10); fill(sk)
    # shoulders / garment
    def torso():
        c.move_to(-104, 0); c.curve_to(-102, -52, -84, -82, -30, -92); c.line_to(30, -92); c.curve_to(84, -82, 102, -52, 104, 0); c.close_path()
    torso()
    gcol = {"yemen": "#F3EFE6", "kes": "#F6F3EC", "kaftan": "#B3263A", "sidara": "#22324F", "persian": "#1F8C8C",
            "kurd": "#3D4B2E", "bukhara": "#7A2E8E", "sari": "#E8762D", "ashk": "#7D8796"}[look]
    fill(gcol)
    c.save(); torso(); c.clip()
    if look == "yemen":                     # tallit: white with dark stripes
        for yy in (-70, -52, -28):
            c.rectangle(-110, yy, 220, 9 if yy != -52 else 5); fill("#1F2433")
        c.move_to(-14, -92); c.line_to(0, -40); c.line_to(14, -92); c.close_path(); fill("#D9D3C5")
    elif look == "kes":                     # white kuta with a woven tibeb band
        for xx in (-34, 22):
            c.rectangle(xx, -92, 12, 92); fill("#2E7D4F")
            for j in range(9): c.rectangle(xx + 2, -88 + j * 10, 8, 5); fill(("#E0A526", "#C2332E")[j % 2])
    elif look == "kaftan":                  # gold trim V neckline and buttons
        c.move_to(-30, -92); c.line_to(0, -38); c.line_to(30, -92); c.set_line_width(12); col = C("#E7B94A"); c.set_source_rgba(*col[:3], 1); c.stroke()
        for j in range(4): c.arc(0, -28 + j * 9, 3.6, 0, 6.283); fill("#E7B94A")
        c.move_to(-104, -14); c.line_to(104, -14); c.set_line_width(7); c.set_source_rgba(*C("#E7B94A")[:3], 1); c.stroke()
    elif look == "sidara":                  # suit, shirt and tie
        c.move_to(-26, -92); c.line_to(0, -30); c.line_to(26, -92); c.close_path(); fill("#F4F4F2")
        c.move_to(-7, -84); c.line_to(7, -84); c.line_to(10, -40); c.line_to(0, -30); c.line_to(-10, -40); c.close_path(); fill("#8C2430")
        c.move_to(-26, -92); c.line_to(-4, -34); c.line_to(-40, -62); c.close_path(); fill("#1A2840")
        c.move_to(26, -92); c.line_to(4, -34); c.line_to(40, -62); c.close_path(); fill("#1A2840")
    elif look == "persian":                 # teal dress with a small paisley dot pattern
        for j in range(-5, 6):
            for i in range(3): c.arc(j * 20 + (i % 2) * 10, -70 + i * 26, 4, 0, 6.283); fill("#E9C46A")
        c.move_to(-24, -92); c.curve_to(-14, -70, 14, -70, 24, -92); c.close_path(); fill("#176E6E")
    elif look == "kurd":                    # white shirt, dark vest, patterned sash
        c.rectangle(-30, -92, 60, 92); fill("#ECE7DC")
        c.rectangle(-104, -30, 208, 16); fill("#B5432E")
        for j in range(-6, 7): c.rectangle(j * 16, -27, 7, 10); fill("#E6C07A")
    elif look == "bukhara":                 # chapan: vertical ikat stripes
        cols = ["#7A2E8E", "#E0A526", "#2E6FB7", "#C2332E", "#2E7D4F"]
        for j in range(-7, 8): c.rectangle(j * 15, -100, 15, 100); fill(cols[j % 5])
        c.move_to(-22, -92); c.line_to(0, -40); c.line_to(22, -92); c.close_path(); fill("#F1EBDD")
    elif look == "sari":                    # sari with a gold-bordered drape over one shoulder
        c.move_to(-60, -88); c.line_to(-20, -92); c.line_to(104, -6); c.line_to(104, 0); c.line_to(60, 0); c.close_path(); fill("#C2185B")
        c.move_to(-60, -88); c.line_to(-20, -92); c.line_to(104, -6); c.set_line_width(7); c.set_source_rgba(*C("#E7B94A")[:3], 1); c.stroke()
    elif look == "ashk":                    # hoodie
        c.move_to(-44, -94); c.curve_to(-30, -70, 30, -70, 44, -94); c.set_line_width(14); c.set_source_rgba(*C("#6A7382")[:3], 1); c.stroke()
        for xx in (-12, 12):
            c.move_to(xx, -78); c.line_to(xx, -46); c.set_line_width(3.5); c.set_source_rgba(*C("#EDEFF2")[:3], 1); c.stroke()
    c.restore()
    # head
    c.arc(0, -150, 46, 0, 6.283); fill(sk)
    c.arc(-14, -164, 22, 0, 6.283); fill(mixc(hx(sk), WHITE, 0.12), 0.35)        # soft highlight
    # hair, beards, headwear
    def cap(col, top=-196, h=26):
        c.move_to(-45, -158); c.curve_to(-44, top - 4, 44, top - 4, 45, -158); c.curve_to(30, -170, -30, -170, -45, -158); c.close_path(); fill(col)
    if look == "yemen":
        cap("#1C1410")
        c.move_to(-34, -128); c.curve_to(-30, -98, -10, -94, 0, -96); c.curve_to(10, -94, 30, -98, 34, -128); c.curve_to(20, -116, -20, -116, -34, -128); fill("#1C1410")
        for sx in (-1, 1):                    # simanim (side curls)
            c.move_to(sx * 44, -160)
            for j in range(7):
                yy = -156 + j * 9; c.line_to(sx * (46 + (5 if j % 2 else -1)), yy)
            c.set_line_width(7); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_source_rgba(*C("#1C1410")[:3], 1); c.stroke()
        c.move_to(-20, -195); c.curve_to(-14, -206, 14, -206, 20, -195); c.close_path(); fill("#3B5BA9")    # small kippah
    elif look == "kes":                       # white turban, grey beard
        c.move_to(-50, -160); c.curve_to(-56, -218, 56, -218, 50, -160); c.curve_to(30, -172, -30, -172, -50, -160); c.close_path(); fill("#F7F5EF")
        for j in range(3):
            c.move_to(-46 + j * 8, -170 - j * 10); c.curve_to(-10, -186 - j * 10, 20, -184 - j * 8, 46 - j * 6, -168 - j * 10)
            c.set_line_width(2.2); c.set_source_rgba(*C("#CFC9BC")[:3], 1); c.stroke()
        c.move_to(-34, -132); c.curve_to(-30, -100, -10, -96, 0, -98); c.curve_to(10, -96, 30, -100, 34, -132); c.curve_to(20, -120, -20, -120, -34, -132); fill("#CFCAC2")
    elif look == "kaftan":                    # headscarf with gold dots
        c.move_to(-52, -146); c.curve_to(-60, -214, 60, -214, 52, -146); c.curve_to(40, -176, -40, -176, -52, -146); c.close_path(); fill("#1E7A5A")
        for j in range(-3, 4): c.arc(j * 13, -190 + abs(j) * 2, 3.2, 0, 6.283); fill("#E7B94A")
        c.move_to(-50, -150); c.curve_to(-58, -120, -50, -100, -40, -96); c.line_to(-36, -140); c.close_path(); fill("#1E7A5A")
    elif look == "sidara":                    # Iraqi sidara cap, short hair, trimmed moustache-less face
        cap("#241A14", -192)
        c.move_to(-34, -188); c.line_to(-26, -208); c.line_to(26, -208); c.line_to(34, -188); c.close_path(); fill("#101010")
    elif look == "persian":                   # long dark hair, fringe
        cap("#1E1410", -198)
        c.move_to(-46, -158); c.curve_to(-52, -130, -50, -110, -44, -96); c.line_to(-36, -150); c.close_path(); fill("#1E1410")
        c.move_to(46, -158); c.curve_to(52, -130, 50, -110, 44, -96); c.line_to(36, -150); c.close_path(); fill("#1E1410")
    elif look == "kurd":                      # wrapped, fringed turban, dark beard
        c.move_to(-50, -160); c.curve_to(-54, -214, 54, -214, 50, -160); c.curve_to(30, -170, -30, -170, -50, -160); c.close_path(); fill("#B5432E")
        for j in range(-4, 5):
            c.arc(j * 11, -184 - (4 - abs(j)) * 2.2, 3.6, 0, 6.283); fill("#F1EBDD")
        c.move_to(-34, -128); c.curve_to(-30, -100, -10, -96, 0, -98); c.curve_to(10, -96, 30, -100, 34, -128); c.curve_to(20, -116, -20, -116, -34, -128); fill("#2A1C14")
    elif look == "bukhara":                   # tall embroidered Bukharan kippah
        cap("#3A2A1E", -192)
        c.move_to(-38, -178); c.line_to(-36, -224); c.curve_to(-20, -232, 20, -232, 36, -224); c.line_to(38, -178); c.curve_to(20, -184, -20, -184, -38, -178); c.close_path(); fill("#D9A93A")
        cols = ["#E0A526", "#C2332E", "#2E7D4F", "#F1EBDD"]
        for r_ in range(3):
            for j in range(-3, 4):
                cx_, cy_ = j * 10.5, -190 - r_ * 13; c.move_to(cx_, cy_ - 5); c.line_to(cx_ + 5, cy_); c.line_to(cx_, cy_ + 5); c.line_to(cx_ - 5, cy_); c.close_path(); fill(cols[(j + r_) % 4])
    elif look == "sari":
        cap("#181010", -198)
    elif look == "ashk":                      # light brown hair, knitted kippah
        cap("#8A6A4A", -198)
        c.move_to(-22, -193); c.curve_to(-16, -206, 16, -206, 22, -193); c.close_path(); fill("#2E6FB7")
        c.move_to(-18, -197); c.line_to(18, -197); c.set_line_width(2.5); c.set_source_rgba(*C("#F1EBDD")[:3], 1); c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a)
    if wht > 0.02:                           # faint outline so the white silhouettes still read
        pass
    c.restore()

# ------------------------------------------------------------------ grid
GX = [200, 540, 880]; GY = [890, 1175, 1460]            # feet lines of each cell row
CW, CH = 316, 272
def cell_xy(k): return GX[k % 3], GY[k // 3]
def draw_grid(c, t, a, sc=1.0):
    if a <= 0.01: return
    i = scene_at(t)
    c.save(); c.translate(540, 1130); c.scale(sc, sc); c.translate(-540, -1130)
    for k in range(9):
        x, y = cell_xy(k)
        rv = RT[k]; u = clamp((t - rv) / 0.45)
        wht = 1 - u
        if t >= T_WHITEN: wht = max(wht, ramp(t, T_WHITEN + 0.08 * k, T_WHITEN + 0.08 * k + 0.6))
        cur = (2 <= i <= 10 and REVEAL_LINE.index(i) == k) if 2 <= i <= 10 else False
        # card
        rr(c, x - CW / 2 + 6, y - CH + 4, CW - 12, CH - 8, 30)
        c.set_source_rgba(1, 1, 1, (0.10 if cur else 0.055) * a); c.fill()
        if cur:
            rr(c, x - CW / 2 + 6, y - CH + 4, CW - 12, CH - 8, 30); c.set_source_rgba(*YEL[:3], 0.9 * a * ramp(t, rv, rv + 0.3)); c.set_line_width(4); c.stroke()
        # figure: pop on reveal, gentle breathing; the all-white shimmer at the start
        pop = 1 + 0.10 * math.sin(math.pi * clamp((t - rv) / 0.5)) if 0 < t - rv < 0.5 else 1.0
        see = lt(11)
        if 0 < t - wt(11, "see") < 0.7: pop *= 1 + 0.07 * math.sin(math.pi * (t - wt(11, "see")) / 0.7 * 2) * (1 - (t - wt(11, "see")) / 0.7)
        br = 1 + 0.012 * math.sin(t * 2.2 + k)
        if u > 0 and u < 1: glow(c, x, y - 120, 150, YEL, 0.35 * (1 - u) * a)
        bust(c, x, y - 62, 0.82 * pop * br, k, wht, a)
        # shimmer over the white silhouettes (motion by 1.5 s on the hook)
        if wht > 0.5:
            ph = ((t * 0.55 + k * 0.07) % 1.6) - 0.3
            sx = x - CW / 2 + ph * CW
            g = cairo.LinearGradient(sx - 60, 0, sx + 60, 0); g.add_color_stop_rgba(0, 1, 1, 1, 0); g.add_color_stop_rgba(0.5, 1, 1, 1, 0.22 * a * wht); g.add_color_stop_rgba(1, 1, 1, 1, 0)
            c.save(); rr(c, x - CW / 2 + 6, y - CH + 4, CW - 12, CH - 8, 30); c.clip(); c.set_source(g); c.paint(); c.restore()
        # label: "?" while white, the place once revealed
        la = ramp(t, rv + 0.1, rv + 0.4) * (1 - (wht if t >= T_WHITEN else 0))
        text(c, FIG[k][1], 44, x, y - 14, 800, WHITE, a * la)
        text(c, "white", 44, x, y - 14, 800, SILVER, a * (1 - la) * 0.85)
    c.restore()

# ------------------------------------------------------------------ map
GW = json.load(open(f"{D}/geo_world.json")); GIL = json.load(open(f"{D}/geo_il.json"))
COSF = math.cos(math.radians(32)); MLON, MLAT, MK = 31.0, 33.0, 12.6; MCY = 1080
def P(lon, lat): return 540 + (lon - MLON) * COSF * MK, MCY - (lat - MLAT) * MK
IL = P(35.0, 31.6)
ORIG = {  # key: (lon, lat, label dx, label dy)
    "yemen": (44.2, 15.4, 92, 14), "ethiopia": (37.5, 12.6, -10, 52), "morocco": (-5.0, 34.0, 0, 74), "iraq": (44.4, 33.3, -64, 46),
    "iran": (51.4, 35.7, 34, 52), "kurd": (43.2, 37.4, -30, -96), "bukhara": (64.4, 39.8, 0, -96), "india": (72.9, 19.1, -20, 74),
    "poland": (21.0, 52.2, 0, -96)}
def map_bg():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    for nm, rings in GW.items():
        for r in rings:
            for i, (lo, la) in enumerate(r):
                x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
            c.close_path()
    c.set_source_rgba(*hx("#22417A")[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.30); c.set_line_width(1.3); c.stroke()
    glow(c, *IL, 90, YEL, 0.35)
    for key, col in (("isr", GOLD_IL), ("pal", GOLD_PA)):
        for r in GIL[key]:
            for i, (lo, la) in enumerate(r):
                x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
            c.close_path()
        c.set_source_rgba(*col[:3], 1); c.fill()
    c.set_source_rgba(*GREEN[:3], 1); c.set_line_width(1.6)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    s.flush(); return s
MAPBG = map_bg()
T_MAP_IN = CUT[13]; T_MAP_OUT = CUT[16]
ARR_T = [wt(13, "families") + 0.2 + 0.36 * k for k in range(9)]
def arrow_path(c, k, u):
    lo, la, _, _ = ORIG[FIG[k][0]]; x0, y0 = P(lo, la); x1, y1 = IL
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2; dx, dy = x1 - x0, y1 - y0; L = math.hypot(dx, dy)
    cx_, cy_ = mx - dy * 0.22, my + dx * 0.22 * (1 if k % 2 else -1) * 0 - abs(dx) * 0.12 - 20
    pts = []
    for j in range(41):
        s = j / 40 * u; a_ = (1 - s) ** 2; b_ = 2 * (1 - s) * s; c2 = s * s
        pts.append((a_ * x0 + b_ * cx_ + c2 * x1, a_ * y0 + b_ * cy_ + c2 * y1))
    return pts
def origins_count(t): return sum(1 for k in range(9) if t >= ARR_T[k] + 0.5)
def draw_map(c, t, a):
    if a <= 0.01: return
    c.set_source_surface(MAPBG, 0, 0); c.paint_with_alpha(a)
    i = scene_at(t)
    for k in range(9):
        t0 = ARR_T[k]; u = eout((t - t0) / 0.55)
        if u <= 0: continue
        pts = arrow_path(c, k, u)
        hi = (i == 14 and FIG[k][0] == "ethiopia") or (i == 15 and t >= wt(15, "One"))
        col = YEL if hi or i < 14 else SKY
        for j, (x, y) in enumerate(pts): (c.move_to if j == 0 else c.line_to)(x, y)
        c.set_source_rgba(*col[:3], 0.95 * a); c.set_line_width(6 if hi else 4.5); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
        if u > 0.2:   # arrow head
            (xa, ya), (xb, yb) = pts[-3], pts[-1]; ang = math.atan2(yb - ya, xb - xa)
            c.move_to(xb, yb); c.line_to(xb - 20 * math.cos(ang - 0.5), yb - 20 * math.sin(ang - 0.5)); c.line_to(xb - 20 * math.cos(ang + 0.5), yb - 20 * math.sin(ang + 0.5)); c.close_path()
            c.set_source_rgba(*col[:3], a); c.fill()
        lo, la, ldx, ldy = ORIG[FIG[k][0]]; x0, y0 = P(lo, la)
        pa = a * clamp((t - t0) / 0.3)
        c.set_source_rgba(*YEL[:3], pa); c.arc(x0, y0, 9, 0, 6.283); c.fill()
        bust(c, x0, y0 - 8, 0.33 * eob(clamp((t - t0) / 0.4)), k, 0.0, pa)
        lab = FIG[k][1]; xl = min(max(x0 + ldx, 30 + font(38, 800).getlength(lab) / 2), 1050 - font(38, 800).getlength(lab) / 2)
        yl = y0 + (ldy if ldy != 74 else 52)
        text(c, lab, 38, xl, yl, 800, WHITE, pa)
    # pulse on Israel when arrows land
    for k in range(9):
        dt = t - (ARR_T[k] + 0.55)
        if 0 < dt < 0.7:
            c.set_source_rgba(*YEL[:3], a * (1 - dt / 0.7)); c.set_line_width(3); c.arc(*IL, 14 + 60 * dt, 0, 6.283); c.stroke()

# ------------------------------------------------------------------ top zone
def fmt(v): return f"{v:,}"
def draw_top(c, t):
    i = scene_at(t)
    if i <= 1 or t >= END - 1.05:            # the hook (frame 0, and again as the loop lands)
        a = 1.0 if i <= 1 else ramp(t, END - 1.05, END - 0.8)
        text(c, "Jews are white.", 132, 540, 420, 900, WHITE, a)
        text(c, "Obviously.", 118, 540, 560, 900, YEL, a)
        u = eout(t / 1.2) if i == 0 else 1.0
        w_ = font(118, 900).getlength("Obviously.")
        c.set_source_rgba(*YEL[:3], 0.9 * a); rr(c, 540 - w_ / 2, 588, w_ * u, 10, 5); c.fill()
        return
    if 2 <= i <= 10:
        k = REVEAL_LINE.index(i)
        if t < RT[k]:                       # before the place is named: keep the last label (or "Exhibit A")
            if k == 0: text(c, "Exhibit A", 120, 540, 470, 900, WHITE, ramp(t, CUT[i], CUT[i] + 0.25))
            else: parts(c, FIG[k - 1][2], 120, 470, 1.0)
            return
        a = ramp(t, RT[k], RT[k] + 0.25); dy = (1 - eout((t - RT[k]) / 0.35)) * 26
        parts(c, FIG[k][2], 120, 470 + dy, a)
        if k in SUBL and SUBL[k]: text(c, SUBL[k], 56, 540, 560 + dy, 700, SILVER, a)
        if k == 8: text(c, "the exception", 56, 540, 560 + dy, 700, SILVER, a * ramp(t, wt(10, "actually"), wt(10, "actually") + 0.3))
        return
    if i == 11:
        a = ramp(t, CUT[11], CUT[11] + 0.25)
        text(c, "All white.", 104, 540, 400, 900, WHITE, a)
        s0 = wt(11, "Can"); u = eob(clamp((t - s0) / 0.4))
        text(c, "Can't you see?", 132, 540, 560, 900, YEL, ramp(t, s0, s0 + 0.15), sc=max(0.01, u))
        return
    if i == 13:
        a = ramp(t, CUT[13], CUT[13] + 0.3); n = origins_count(t)
        parts(c, [(str(n), YEL), (" origins", WHITE)], 150, 430, a)
        text(c, "North Africa, Middle East, Asia", fit("North Africa, Middle East, Asia", 64, 980, 800, 56), 540, 540, 800, SILVER, a)
        return
    if i == 14:
        a = ramp(t, CUT[14], CUT[14] + 0.3); t0 = wt(14, "hundred") - 0.1
        v = int(round(177600 * eout((t - t0) / 1.6), -2)) if t > t0 else 0
        text(c, fmt(v), 160, 540, 440, 900, YEL, a)
        text(c, "Israelis of Ethiopian origin", 64, 540, 545, 800, WHITE, a)
        return
    if i == 15:
        a = ramp(t, CUT[15], CUT[15] + 0.3); s1 = wt(15, "One")
        b = ramp(t, s1, s1 + 0.3)
        text(c, "9 places", 150, 540, 440, 900, YEL, a * (1 - b))
        text(c, "Thousands of km apart", 64, 540, 545, 800, WHITE, a * (1 - b) * ramp(t, wt(15, "Thousands"), wt(15, "Thousands") + 0.3))
        text(c, "One people.", 150, 540, 480, 900, YEL, b, sc=max(0.01, eob(clamp((t - s1) / 0.4))))
        return
    if i == 16:
        a = ramp(t, CUT[16], CUT[16] + 0.3); s1 = wt(16, "We")
        text(c, "Not a skin color.", 112, 540, 420, 900, WHITE, a)
        text(c, "A people.", 132, 540, 565, 900, YEL, ramp(t, s1, s1 + 0.25), sc=max(0.01, eob(clamp((t - s1) / 0.4))))
        return
    if i == 17:
        a = ramp(t, CUT[17], CUT[17] + 0.3) * (1 - ramp(t, END - 1.25, END - 1.05))
        text(c, "So next time", 104, 540, 420, 900, WHITE, a)
        text(c, "someone tells you...", 104, 540, 550, 900, WHITE, a)

def draw_stat(c, t):
    """line 12: Pew 2016: 48% Mizrahi or Sephardi, 45% Ashkenazi"""
    a = ramp(t, CUT[12] + 0.1, CUT[12] + 0.45) * (1 - ramp(t, CUT[13] - 0.2, CUT[13] + 0.15))
    if a <= 0.01: return
    t0 = wt(12, "half") - 0.2; u = eout((t - t0) / 1.0)
    text(c, "About half", 96, 540, 460, 900, WHITE, a)
    text(c, f"{int(round(48 * u))}%", 300, 540, 820, 900, YEL, a)
    text(c, "of Israel's Jews are", 66, 540, 930, 800, WHITE, a)
    text(c, "Mizrahi or Sephardi", 84, 540, 1030, 900, YEL, a * ramp(t, wt(12, "Mizrahi"), wt(12, "Mizrahi") + 0.3))
    # split bar
    x0, y0, bw, bh = 90, 1120, 900, 74; v = ramp(t, wt(12, "Mizrahi"), wt(12, "Mizrahi") + 0.9)
    rr(c, x0, y0, bw, bh, 37); c.set_source_rgba(1, 1, 1, 0.10 * a); c.fill()
    c.save(); rr(c, x0, y0, bw, bh, 37); c.clip()
    c.rectangle(x0, y0, bw * 0.48 * v, bh); c.set_source_rgba(*YEL[:3], a); c.fill()
    c.rectangle(x0 + bw * 0.48, y0, bw * 0.45 * v, bh); c.set_source_rgba(*SKY[:3], a * v); c.fill()
    c.restore()
    text(c, "48% Mizrahi or Sephardi", 40, x0 + 8, y0 + bh + 56, 800, YEL, a * v, "l")
    text(c, "45% Ashkenazi", 40, x0 + bw - 8, y0 + bh + 56, 800, SKY, a * v, "r")
    text(c, "Pew Research Center, Israel's Religiously Divided Society, 2016", fit("Pew Research Center, Israel's Religiously Divided Society, 2016", 38, 960, 700), 540, 1352, 700, SILVER, a)

SRC = {13: "Origins of Israel's Jewish communities", 14: "Israel Central Bureau of Statistics, 2024 data (Nov 2025)",
       15: "9 of the communities that came home"}
def draw_source(c, t):
    i = scene_at(t); s = SRC.get(i)
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1]))
    text(c, s, fit(s, 38, 960, 700, 36), 540, 1472, 700, SILVER, a)

# ------------------------------------------------------------------ subtitles
REPL = [("a hundred and eighty thousand", "180,000"), ("Nine places", "9 places"), ("Can't you SEE?", "Can't you see?")]
SUB_BOTTOM = 1712
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower().rstrip(".,") == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs(); SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 1); g.add_color_stop_rgba(0.6, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1B3C8C")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1050, 720, SKY, 0.12); return s
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    ga = (1 - ramp(t, T_GRID_OUT, T_GRID_OUT + 0.4)) + ramp(t, T_GRID_IN, T_GRID_IN + 0.5)
    gs = lerp(0.9, 1.0, ga)
    draw_grid(c, t, clamp(ga), gs)
    draw_stat(c, t)
    draw_map(c, t, ramp(t, T_MAP_IN, T_MAP_IN + 0.5) * (1 - ramp(t, T_MAP_OUT, T_MAP_OUT + 0.4)))
    draw_top(c, t); draw_source(c, t)
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); img = frame(tt)
            if tt >= T_FADE:
                u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
            Image.fromarray(img).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= T_FADE:
            u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
