"""render_tl.py spec.json VO_DIR out_dir/: render a reel from an already processed voice (VO_DIR/vo.wav + VO_DIR/timing.json, as voice.write
leaves them), skipping the voice chain. Same mix/render/web/QA steps as make_reel_sse.py. Used for edits made with vo_splice_tl.py."""
import os, sys, json, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); os.nice(5)
import numpy as np, soundfile as sf
def main():
    spec_p, vd, out = sys.argv[1], sys.argv[2], os.path.abspath(sys.argv[3]); T0 = time.time(); os.makedirs(f"{out}/work", exist_ok=True)
    def log(*a): print(f"[{time.time() - T0:6.1f}s]", *a, flush=True)
    import render as RD, mix as MX, qa as QA
    spec = RD.load_spec(spec_p); tim = json.load(open(f"{vd}/timing.json")); vo, sr = sf.read(f"{vd}/vo.wav")
    if vo.ndim > 1: vo = vo.mean(1)
    R = RD.Reel(spec, tim); log("T_END", R.T_END, "warn", R.warn)
    last = R.scenes[-1]
    end_at = last["times"].get("keyword", last["t0"]) if last["type"] == "cta" else R.T_END - 2.0
    bed = MX.bed(spec.get("music", "doc_piano"), R.T_END, end_at)
    ev = [(tt, k, 0.0) for tt, k in R.sfx_events()]
    wav = f"{out}/work/mix.wav"; mrep = MX.mix(vo, R.T_END, bed, ev, wav, music_db=spec.get("music_db", -17.0), log=log); mrep["bed"] = spec.get("music", "doc_piano")
    mp4 = f"{out}/reel.mp4"; vid = RD.render_video(R, wav, mp4, log=log)
    web = f"{out}/reel_web.mp4"; MX.web(mp4, web)
    rep = QA.run_all(out, R, vid, mp4, web, tim, mrep, log=log, do_asr=False); os.remove(wav)
    print(QA.summary(rep))
if __name__ == "__main__":
    main()
