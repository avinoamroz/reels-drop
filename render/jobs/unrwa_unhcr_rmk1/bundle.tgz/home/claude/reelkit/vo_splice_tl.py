"""vo_splice_tl.py: edit a processed voice (vo.wav + reelkit timing.json, words carry 'line' 0-based) without re-voicing.
  python3 vo_splice_tl.py SRC_VO.wav SRC_TIMING.json DST_DIR ops.json [--spec SRC_SPEC DST_SPEC]
ops (lines 1-based, as in specs):
  {"op":"cut","line":L,"from":i,"to":j,"text":"line text after the cut"}  remove words i..j-1 of line L
  {"op":"drop","line":L}                                                   remove line L (and the pause after it)
Writes DST_DIR/vo.wav + DST_DIR/timing.json; with --spec, remaps scene "line" numbers (scenes of dropped lines are removed)."""
import json, os, sys
import numpy as np, soundfile as sf

def main(a):
    vo, sr = sf.read(a[0]); tm = json.load(open(a[1])); dst = a[2]; ops = json.load(open(a[3]))
    L = tm["lines"]; W = tm["words"]; n = len(L)
    cuts = []  # (start, end) seconds to remove
    drop = {o["line"] - 1 for o in ops if o["op"] == "drop"}
    newtext = {}
    for o in ops:
        if o["op"] == "drop":
            i = o["line"] - 1; s = L[i]["t0"] - 0.06
            e = (L[i + 1]["t0"] - 0.06) if i + 1 < n else len(vo) / sr
            if i + 1 >= n: s = (L[i - 1]["t1"] + 0.25) if i else s
            cuts.append((s, e))
        elif o["op"] == "cut":
            i = o["line"] - 1; ws = [w for w in W if w["line"] == i]
            s = ws[o["from"]]["t0"] - 0.03 if o["from"] > 0 else ws[0]["t0"] - 0.02
            e = ws[o["to"]]["t0"] - 0.03 if o["to"] < len(ws) else ws[-1]["t1"] + 0.05
            cuts.append((s, e)); newtext[i] = (o["text"], set(range(o["from"], o["to"])))
    cuts.sort()
    def mp(t):
        sh = 0.0
        for s, e in cuts:
            if t >= e: sh += e - s
            elif t > s: return s - sh
        return t - sh
    # audio
    keep, cur = [], 0.0
    for s, e in cuts: keep.append((cur, s)); cur = e
    keep.append((cur, len(vo) / sr)); f = int(0.008 * sr); pieces = []
    for s, e in keep:
        x = vo[int(s * sr):int(e * sr)].copy()
        if len(x) > 2 * f: x[:f] *= np.linspace(0, 1, f)[:, None] if x.ndim > 1 else np.linspace(0, 1, f); x[-f:] *= (np.linspace(1, 0, f)[:, None] if x.ndim > 1 else np.linspace(1, 0, f))
        pieces.append(x)
    y = np.concatenate(pieces)
    # timing
    remap, k = {}, 0
    for i in range(n):
        if i in drop: continue
        remap[i] = k; k += 1
    words, lines = [], []
    for i in range(n):
        if i in drop: continue
        ws = [w for w in W if w["line"] == i]; rm = newtext.get(i, (None, set()))[1]
        ws = [dict(w) for j, w in enumerate(ws) if j not in rm]
        if i in newtext:
            tw = newtext[i][0].split(); assert len(tw) == len(ws), (i, len(tw), len(ws))
            for w, t in zip(ws, tw): w["w"] = t
        for w in ws: w["line"] = remap[i]; w["src_line"] = remap[i]; w["t0"] = round(mp(w["t0"]), 3); w["t1"] = round(mp(w["t1"]), 3); words.append(w)
        ln = dict(L[i]); ln["i"] = remap[i]; ln["src_line"] = remap[i]; ln["text"] = newtext[i][0] if i in newtext else ln["text"]
        ln["t0"] = ws[0]["t0"]; ln["t1"] = ws[-1]["t1"]; lines.append(ln)
    out = dict(tm); out["lines"] = lines; out["words"] = words; out["dur"] = round(len(y) / sr, 3)
    if "selected" in out: out["selected"] = list(range(len(lines)))
    os.makedirs(dst, exist_ok=True); sf.write(f"{dst}/vo.wav", y, sr, subtype="PCM_16" if sf.info(a[0]).subtype == "PCM_16" else sf.info(a[0]).subtype)
    json.dump(out, open(f"{dst}/timing.json", "w"), ensure_ascii=False, indent=0)
    print(dst, f"{len(vo)/sr:.2f}s -> {len(y)/sr:.2f}s, {len(lines)} lines")
    if "--spec" in a:
        k = a.index("--spec"); sp = json.load(open(a[k + 1])); sc = []
        for s in sp["scenes"]:
            i = s["line"] - 1
            if i in drop: continue
            s["line"] = remap[i] + 1; sc.append(s)
        sp["scenes"] = sc; json.dump(sp, open(a[k + 2], "w"), ensure_ascii=False, indent=1); print("spec", a[k + 2], len(sc), "scenes")

if __name__ == "__main__":
    main(sys.argv[1:])
