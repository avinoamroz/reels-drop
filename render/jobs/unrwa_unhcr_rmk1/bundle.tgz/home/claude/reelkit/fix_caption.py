"""fix_caption.py SRC_PAYLOAD.json DST_PAYLOAD.json NEW_ID [--keep-fair]: copy a posting payload, clean opinion markers and fair lines from its caption, point video_url at NEW_ID, set is_ai_generated and SS_PERFORMANCE."""
import json, sys
sys.path.insert(0, "/home/claude/reelkit")
from strip_opinion import clean, clean_all
src, dst, nid = sys.argv[1:4]
d = json.load(open(src)); b = json.loads(d["body"])
b["caption"] = clean(b["caption"]) if "--keep-fair" in sys.argv else clean_all(b["caption"])
b["video_url"] = f"https://raw.githubusercontent.com/avinoamroz/reels-drop/main/{nid}.mp4"
b["media_type"] = "REELS"; b["is_ai_generated"] = True; b.setdefault("share_to_feed", True)
b["trial_params"] = {"graduation_strategy": "SS_PERFORMANCE"}
d["body"] = json.dumps(b, ensure_ascii=False); d["tag"] = f"{nid}-gh"; d.setdefault("action", "init")
json.dump(d, open(dst, "w"), ensure_ascii=False, indent=1)
print(dst); print(b["caption"])
