"""strip_opinion.py: remove opinion markers ("In my view", "In my opinion", "my view", "personally I think", Hebrew לדעתי / בעיניי) from caption text.
Library: clean(text) -> text. CLI: strip_opinion.py PAYLOAD.json [--write]  (edits body.caption of a posting payload, prints a diff)."""
import json, re, sys

EN = r"(?:in my (?:view|opinion)|personally,? i think(?: that)?)"
HE = r"(?:לדעתי|בעיניי)"

def clean(s):
    U = "\u0001"  # marks a spot whose next letter must be capitalised
    s = re.sub(r"\s*(?:That's|That is|This is|It's) (?:just )?my (?:view|opinion)\.", "", s, flags=re.I)
    s = re.sub(r"\b(But|And|So|Still|Yet)\s*,?\s*" + EN + r"\s*[,:]?\s*", r"\1 ", s, flags=re.I)
    s = re.sub(r"(^|(?<=[.!?\n])\s*|(?<=[.!?] ))" + EN + r"\s*[,:]?\s*", lambda m: m.group(1) + U, s, flags=re.I | re.M)
    s = re.sub(r",?\s*" + EN + r"\s*[,:]?", "", s, flags=re.I)
    s = re.sub(r"אבל\s+" + HE + r"(?![\u0590-\u05FF])\s*[,:]?\s*", "אבל ", s)
    s = re.sub(HE + r"(?![\u0590-\u05FF])\s*[,:]?\s*", "", s)
    s = re.sub(U + r"(\W*)(\w)", lambda m: m.group(1) + m.group(2).upper(), s)
    s = s.replace(U, "")
    s = re.sub(r"[ \t]{2,}", " ", s)
    return s

if __name__ == "__main__":
    p = sys.argv[1]; d = json.load(open(p)); body = json.loads(d["body"]); c0 = body["caption"]; c1 = clean(c0)
    if c0 == c1: print(p, "no change"); sys.exit(0)
    import difflib
    for l in difflib.unified_diff(c0.splitlines(), c1.splitlines(), lineterm="", n=0): print(l)
    if "--write" in sys.argv:
        body["caption"] = c1; d["body"] = json.dumps(body, ensure_ascii=False); json.dump(d, open(p, "w"), ensure_ascii=False, indent=1); print("written", p)

FAIR = re.compile(r"(?:to be fair|למען ההגינות)", re.I)

def drop_fair(s):
    """remove every 'To be fair' / 'למען ההגינות' sentence (a whole line when the line starts with it)."""
    out = []
    for line in s.split("\n"):
        if not FAIR.search(line): out.append(line); continue
        if FAIR.match(line.strip()): out.append("\u0002"); continue
        parts = re.split(r"(?<=[.!?])\s+", line)
        keep = []; skip = False
        for p in parts:
            if FAIR.match(p.strip()): skip = True; continue
            keep.append(p)
        out.append(" ".join(keep))
    s = "\n".join(out)
    s = re.sub(r"\u0002\n(?:But|Still|Yet),? (\w)", lambda m: m.group(1).upper(), s)
    s = re.sub(r"\u0002\nאבל ", "", s)
    s = s.replace("\u0002\n", "").replace("\u0002", "")
    return re.sub(r"\n{3,}", "\n\n", s)

def clean_all(s):
    return drop_fair(clean(s))
