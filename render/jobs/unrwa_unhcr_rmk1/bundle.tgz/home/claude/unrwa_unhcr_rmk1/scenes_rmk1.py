"""Scenes for unrwa_unhcr_rmk1 (copied from daily_1101/scenes_d01.py, 1 Nov 2026; river quiz removed): ENGLISH ONLY, BIG TEXT, FULL SCREEN, CIRCULAR (Noam, 30 to 31 Oct).
Loaded by reelkit as the spec's scene_module, so the sc_* functions here replace the built-in ones of the same name.
- Layout: content uses the whole width (x 20..1060), headings 100 px, numbers 250 px. Key text stays between y 250 and
  y 1580 (top ~220 px and bottom ~330 px kept free for the IG UI). Sources sit under the content at y 1428 (34 px),
  subtitles at y 1530 (54 px).
- No Hebrew is drawn: any *_he / he field is ignored (build.py also strips them).
- Circular: the last 0.5 s cross-fade into the exact frame 0 (the last frame equals frame 0), and the music bed is cut on
  whole bars from bar 2 of the bed (past its fade-in) and time-fitted to the reel, so the loop lands on a downbeat.
Scene types: title, big_number, cards_grid, map_highlight, city_map, rows."""
import math, re
import numpy as np
import cairo
import render as RD
import kit
from render import P, T, pill, PP, fade_in, MapView, geo, _path, col, block, block_h, shadow_box, icon_of, draw_emoji, box, count, fmt, clean
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, FPS

TOP = 345; CB = 1400; X0, X1 = 20, 1060
RD.SUB_Y = 1530; RD.SOURCE_Y = 1428; RD.CONTENT_BOTTOM = CB
_subs = getattr(RD, "_subs_orig", RD.sub_surfs); RD._subs_orig = _subs
RD.sub_surfs = lambda pieces, sz=54, maxw=1000: _subs(pieces, sz, maxw)

def heading(c, t, S, y=TOP):
    en = S.get("title") or S.get("heading")
    if not en: return y - 30
    a, s = PP(t, S["t0"] + 0.05, S); h1 = block_h(en, 100, 900, 1010, 2)
    block(c, en, 100, 540, y + h1 / 2, P["navy"], a, s, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=2)
    return y + h1 + 30
RD.heading = heading

# ------------------------------------------------------------------ circular: last 0.5 s fade into frame 0
_draw = getattr(RD.Reel, "_draw_orig", RD.Reel.draw); RD.Reel._draw_orig = _draw
def _draw_loop(self, c, t):
    L = float(self.spec.get("loop_fade", 0.5))
    if t < self.T_END - L - 1e-6: return _draw(self, c, t)
    if not hasattr(self, "_f0"):
        s0 = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); _draw(self, cairo.Context(s0), 0.0); s0.flush(); self._f0 = s0
    _draw(self, c, t)
    u = min(1.0, max(0.0, (t - (self.T_END - L)) / max(1e-3, L - 1.0 / FPS)))
    c.set_source_surface(self._f0, 0, 0); c.paint_with_alpha(ease(u))
RD.Reel.draw = _draw_loop

# ------------------------------------------------------------------ circular: music bed cut on whole bars
try:
    import mix as MX
    BPM = {"journey": 100, "doc_piano": 86, "warm": 96, "bounce": 118, "skip": 104}
    _bed = getattr(MX, "_bed_orig", MX.bed); MX._bed_orig = _bed
    def bed_loop(name, dur, end_at=None):
        if name not in BPM: return _bed(name, dur, end_at)
        bar = 240.0 / BPM[name]; nb = max(4, int(round(dur / bar))); L = nb * bar; off = 2 * bar
        raw = _bed(name, off + L + 4.0, off + L + 4.0)          # long render, no ending inside the cut
        seg = raw[:, int(round(off * MX.SR)):int(round((off + L) * MX.SR))]
        n = int(dur * MX.SR); x = np.linspace(0, seg.shape[1] - 1, n)   # time-fit (under 3 %) so the cut ends on a downbeat
        out = np.vstack([np.interp(x, np.arange(seg.shape[1]), ch) for ch in seg])
        f = int(0.012 * MX.SR); out[:, :f] *= np.linspace(0, 1, f); out[:, -f:] *= np.linspace(1, 0, f)
        return out / (np.abs(out).max() + 1e-12)
    MX.bed = bed_loop
except Exception as e:   # preview without mix still works
    print("bed_loop not installed:", e)

# ------------------------------------------------------------------ scenes
def sc_title(c, t, S):
    en = S.get("en"); em = icon_of(S); size = S.get("size", 118)
    h_en = block_h(en, size, 900, 1010, 3); total = (270 if em else 0) + h_en + 40
    y = max(300, (TOP + CB) / 2 - total / 2); t0 = S["t0"]
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 120 + 10 * math.sin(t * 2.6), 230, a, s * (1 + 0.03 * math.sin(t * 3.1))); y += 270
    a, s = PP(t, t0 + 0.08, S); breath = 1 + 0.012 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, size, 540, y + h_en / 2, P["navy"], a, s * breath, hl=col(S.get("hl"), "blue"), maxw=1010, max_lines=3); y += h_en
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 380 * u, y + 10, 760 * u, 14, 7, P["gold"], a)
    RD.source(c, t, S)

def sc_big_number(c, t, S):
    y = heading(c, t, S); steps = S["steps"]; ts = S["times"]["steps"]
    cy = max(y + 340, 820); x0, x1, y0, y1 = X0 + 10, X1 - 10, cy - 320, cy + 320
    a, s = PP(t, S["t0"] + 0.1, S, s0=0.6, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
    shadow_box(c, x0, y0, x1 - x0, y1 - y0, 34, P["card"], stroke=P["navy"], sw=7)
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]; dec = st.get("decimals", 0)
    hk = S.get("hook") and ts[0] <= RD.HOOK_GRACE
    if k == 0: v = st["value"] if hk else count(t, ts[0], st.get("dur", 1.2), st.get("from", 0), st["value"])
    else:
        pv = steps[k - 1]["value"]; big = max(abs(pv), abs(st["value"])) / max(1e-9, min(abs(pv), abs(st["value"]))) > 20
        v = count(t, ts[k], st.get("dur", 1.3), pv, st["value"], log=big)
    if t < ts[0] - 0.05 and not hk: v = st.get("from", 0)
    num = f"{v:.{dec}f}" if S.get("year") else fmt(v, dec)
    lab = clean(f"{st.get('prefix', '')}{num}{st.get('suffix', '')}")
    T(c, lab, S.get("size", 250), 540, cy - 80, col(st.get("color"), "blue"), 1.0, 1.0, 900, maxw=960)
    pa = ramp(t, ts[k] - 0.05, ts[k] + 0.25) if k else 1.0
    hl_ = block_h(st.get("label", ""), 76, 800, 940, 2)
    block(c, st.get("label", ""), 76, 540, cy + 130 + hl_ / 2 - 38, P["navy"], pa, 1.0, 800, hl=P["gold_text"], maxw=940, max_lines=2)
    c.restore(); St.a = old
    if S.get("note"):
        a2, s2 = PP(t, S["times"].get("note", S["t0"] + 1.5), S, bounce=2.4)
        pill(c, S["note"], 58, 540, min(y1 + 105, CB - 30), col(S.get("note_color"), "navy"), P["white"], a2, s2, outline=P["gold"])
    RD.source(c, t, S)

def sc_cards_grid(c, t, S):
    y = heading(c, t, S) + 10; cards = S["cards"]; ts = S["times"]["cards"]; n = len(cards)
    cols = S.get("cols", 2 if n <= 4 else 3); rows = -(-n // cols)
    gap = 24; WW = X1 - X0 - 20; cw = (WW - gap * (cols - 1)) / cols; avail = CB - y - 10
    ch = min(cw * 1.5, (avail - gap * (rows - 1)) / rows)
    for k, cd in enumerate(cards):
        r_, q = divmod(k, cols); in_row = min(cols, n - r_ * cols)
        x0 = X0 + 10 + (WW - (in_row * cw + (in_row - 1) * gap)) / 2 + q * (cw + gap); y0 = y + r_ * (ch + gap)
        a, s = PP(t, ts[k], S, s0=0.5, bounce=1.6)
        if a <= 0.01: continue
        cx, cy = x0 + cw / 2, y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
        shadow_box(c, x0, y0, cw, ch, 28, P["card"], stroke=col(cd.get("color"), "navy"), sw=5)
        parts = []; isz = min(cw, ch) * 0.34
        if icon_of(cd): parts.append(("i", isz + 10))
        if cd.get("value"): parts.append(("v", 120))
        hl_ = block_h(cd.get("label"), 58, 800, cw - 36, 3); parts.append(("l", hl_))
        yy = cy - sum(p[1] for p in parts) / 2
        for kind, hgt in parts:
            if kind == "i": draw_emoji(c, icon_of(cd), cx, yy + hgt / 2, isz, rot=0.04 * math.sin(t * 2 + k))
            if kind == "v": T(c, cd["value"], min(110, cw * 0.26), cx, yy + hgt / 2, col(cd.get("value_color") or cd.get("color"), "blue"), 1, 1, 900, maxw=cw - 30)
            if kind == "l": block(c, cd.get("label"), 58, cx, yy + hgt / 2, P["navy"], 1, 1, 800, maxw=cw - 36, max_lines=3)
            yy += hgt
        c.restore(); St.a = old
    RD.source(c, t, S)

def sc_rows(c, t, S):
    y = heading(c, t, S); items = S["items"]; n = len(items)
    rh = min(300, (CB - y - 20) / max(1, n)); bh = rh - 26
    span = max(0.6, ((S["t1"] or S["t0"] + 4) - S["t0"]) - 1.2)
    for k, it in enumerate(items):
        tk = S["times"].get(f"i{k}", S["t0"] + 0.3 + span * k / max(1, n))
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        if t < tk - 0.07 and not hk: continue
        a = 1.0 if hk else fade_in(t, tk - 0.07, S, 0.2); u = 1.0 if hk else ease((t - tk + 0.07) / 0.35)
        yy = y + rh * k + rh / 2; dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, X0 + 10, yy - bh / 2, X1 - X0 - 20, bh, min(44, bh / 2.6), P["card"], stroke=col(it.get("color"), "silver"), sw=4, sh=6)
        em = icon_of(it); xt = 540
        if em: draw_emoji(c, em, 120, yy, min(100, bh * 0.5)); xt = 590
        block(c, it.get("en", ""), min(74, bh * 0.36), xt, yy, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=840 if em else 980, max_lines=2)
        c.restore(); St.a = old
    RD.source(c, t, S)

ISRAEL_VIEW = [33.9, 29.35, 36.1, 33.45]
def _base(S, view, box_, G):
    keep = St.a; St.a = 1.0
    mv = MapView(view, box_); base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
    bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
    for k, v in G.items():
        rg = mv.rings(v["g"], 0.6)
        if not rg: continue
        _path(bc, rg); sa(bc, P["gold"] if k in ("IL", "PS") else P["land"]); bc.fill_preserve()
        sa(bc, P["border"]); bc.set_line_width(1.6); bc.stroke()
    if "PS" in G:   # the Green Line in green (house rule)
        rg = mv.rings(G["PS"]["g"], 0.3)
        if rg: _path(bc, rg); sa(bc, P["green"]); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
    St.a = keep; return mv, base

def sc_city_map(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB)
    if "_mv" not in S: S["_mv"], S["_base"] = _base(S, S.get("view", ISRAEL_VIEW), box_, geo())
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"])))
    z = lerp(1.0, S.get("zoom", 1.08), ease(u)); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    shown = []
    for k, p in enumerate(S.get("points", [])):
        tk = S["times"].get(f"p{k}", S["t0"] + 0.4 + 0.8 * k); hk = S.get("hook") and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); cc = col(p.get("color"), "navy")
        pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 22 + 80 * (1 - pr), P["white"], 0.5 * pr * uu)
        circ(c, px, py, 24 * uu, P["white"], uu); circ(c, px, py, 16 * uu, cc, uu)
        shown.append((k, p, tk, px, py))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    for k, p, tk, px, py in shown:
        px = cx + (px - cx) * z; py = cy + (py - cy) * z
        dx = 1 if p.get("side", "r") == "r" else -1
        lx = p.get("lx") or (px + dx * 240); ly = py + p.get("dy", 0)
        hw = max(kit.font(80, 900).getlength(clean(p.get("value") or "").replace("*", "")) * 0.5 + 60,
                 kit.font(56, 800).getlength(clean(p.get("en") or "").replace("*", "")) * 0.5 + 50)
        lx = min(max(lx, X0 + 10 + hw), X1 - 10 - hw) if hw < 500 else 540
        a2, s2 = PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        c.save(); sa(c, P["navy"], 0.8 * a2); c.set_line_width(5); c.move_to(px, py); c.line_to(lx - dx * 150, ly); c.stroke(); c.restore()
        ny = ly
        if p.get("value"): pill(c, p["value"], 80, lx, ly - 50, P["navy"] if p.get("color") in (None, "gold") else col(p.get("color")), P["white"], a2, s2, outline=P["gold"], w=900, padh=1.3); ny = ly + 50
        if p.get("en"): pill(c, p["en"], 56, lx, ny + 14, P["white"], P["navy"], a2, s2, outline=col(p.get("color"), "navy"), w=800, padh=1.3)
    St.a = old
    RD.source(c, t, S)

def sc_map_highlight(c, t, S):
    y = heading(c, t, S); box_ = (X0, y, X1, CB); G = geo()
    if "_mv" not in S:
        view = S.get("view") or RD.auto_view([h["iso"] for h in S["highlights"]] + ["IL"], box_, 0.12)
        S["_mv"], S["_base"] = _base(S, view, box_, G)
        S["_hl"] = [(S["_mv"].rings(G[h["iso"]]["g"], 0.4), h) for h in S["highlights"] if h["iso"] in G]
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"]))); z = lerp(1.0, S.get("zoom", 1.08), ease(u))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    ts = S["times"]["highlights"]; labels = []
    for k, (rg, h) in enumerate(S["_hl"]):
        hk = S.get("hook") and ts[k] <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, ts[k] - 0.05, ts[k] + 0.3)
        if uu <= 0.01: continue
        _path(c, rg); sa(c, col(h.get("color"), "red"), 0.88 * uu); c.fill_preserve(); sa(c, P["white"], uu); c.set_line_width(2.4 / z); c.stroke()
        labels.append((k, h, uu))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    if "_lab" not in S:
        placed = []; S["_lab"] = {}
        for k, (rg, h) in enumerate(S["_hl"]):
            lon, lat = h.get("at_lonlat") or (lambda p: (p.x, p.y))(RD._main_poly(G[h["iso"]]["g"]).representative_point())
            px, py = mv.P(lon, lat); px = min(max(px, 300), 780); py = min(max(py + h.get("dy", 0), y0 + 70), y1 - 90)
            for dy in (0, 130, -130, 260, -260):
                if not any(abs(q[1] - (py + dy)) < 115 and abs(q[0] - px) < 420 for q in placed): py += dy; break
            placed.append((px, py)); S["_lab"][k] = (px, py)
    for k, h, uu in labels:
        if h.get("label") is False: continue
        px, py = S["_lab"][k]; px = cx + (px - cx) * z; py = cy + (py - cy) * z
        a2, s2 = PP(t, ts[k] + 0.1, S)
        pill(c, h.get("en") or G[h["iso"]]["name"], 54, px, py, P["white"], P["navy"], a2, s2, outline=col(h.get("color"), "red"), w=800, padh=1.35)
    St.a = old
    RD.source(c, t, S)

# ================================================================== PHOTO BEATS (v2, 31 Oct 2026, Noam: "add real photos")
# sc_photo: a real photo full-bleed (or a large rounded panel over a blurred copy), slow Ken Burns 1.0 -> 1.08 with cubic
# easing, a dark navy gradient so white text stays readable, the beat's existing big text on top, and a small credit
# label (36 px) at the bottom. Fields: src, credit, title, en, steps [{value, label, at, color}], source, mode, focus, size.
from PIL import Image, ImageFilter, ImageOps
WHITE = (1.0, 1.0, 1.0); YEL = kit.hx("#FFC93C"); SKY = kit.hx("#45A4DD"); INK = (0.03, 0.07, 0.16)
def _ease3(u):
    u = min(1.0, max(0.0, u)); return 4 * u * u * u if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
_PH = {}
def _cover(path, w, h, fx=0.5, fy=0.5, blur=0):
    k = (path, int(w), int(h), fx, fy, blur)
    if k not in _PH:
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        im = ImageOps.fit(im, (int(w), int(h)), Image.LANCZOS, centering=(fx, fy))
        if blur: im = im.filter(ImageFilter.GaussianBlur(blur))
        _PH[k] = kit.pil2cairo(im.convert("RGBA"))
    return _PH[k]
def _wtext(c, s, sz, y, color=WHITE, hl=YEL, maxw=1000, max_lines=3, a=1.0, sc=1.0, src=False):
    """white multi-line text with the kit shadow, centred at y; returns its height"""
    if not s: return 0
    if max_lines == 1:
        while kit.font(sz, 900).getlength(RD.clean(s).replace("*", "")) > maxw and sz > 64: sz -= 4
    z, ls = RD.wrap(s, sz, 900, maxw, max_lines); step = z * 1.14; h = step * len(ls)
    if a <= 0.005 or abs(sc) < 1e-3: return h
    c.save(); c.translate(540, y); c.scale(sc, sc); c.translate(-540, -y)
    for k, l in enumerate(ls):
        kit.tx(c, RD.clean(l), z, 540, y - h / 2 + step * (k + 0.5), w=900 if not src else 700, col=RD.c255(color), a=a,
               hl=RD.c255(hl), shadow=True, src=src, maxw=maxw + 4)
    c.restore(); return h
def _label(c, s, y, a):
    """small credit / source label on a dark pill, 36 px"""
    s = RD.clean(s); f = kit.font(36, 700)
    while f.getlength(s) > 1000 and len(s) > 10: s = s[:-2]
    tw = f.getlength(s); sa(c, INK, 0.55 * a); rr(c, 540 - tw / 2 - 22, y - 27, tw + 44, 54, 27); c.fill()
    kit.tx(c, s, 36, 540, y, w=700, col=RD.c255(WHITE), a=0.92 * a, shadow=False, src=True, maxw=1004)
def sc_photo(c, t, S):
    t0 = S["t0"]; t1 = S["t1"] if S["t1"] is not None else t0 + 4.0
    u = _ease3((t - t0) / max(1.0, t1 + 0.25 - t0)); z = 1.0 + 0.08 * u
    fx, fy = S.get("focus", [0.5, 0.5]); a = St.a
    c.save()
    if S.get("mode") == "panel":
        bg = _cover(S["src"], W, H, fx, fy, blur=28)
        c.set_source_surface(bg, 0, 0); c.paint_with_alpha(a)
        sa(c, INK, 0.55); c.rectangle(0, 0, W, H); c.fill()
        im = Image.open(S["src"]); ar = im.width / im.height
        pw = 1040; ph = min(1000, pw / ar); px, py = 20, S.get("panel_y", 860) - ph / 2
        sa(c, (0, 0, 0), 0.35); rr(c, px + 4, py + 18, pw, ph, 36); c.fill()
        c.save(); rr(c, px, py, pw, ph, 36); c.clip()
        fg = _cover(S["src"], pw, ph, fx, fy); cx, cy = px + pw * fx, py + ph * fy
        c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
        c.set_source_surface(fg, px, py); c.paint_with_alpha(a); c.restore()
        sa(c, WHITE, 0.55); c.set_line_width(3); rr(c, px, py, pw, ph, 36); c.stroke()
    else:
        img = _cover(S["src"], W, H, fx, fy); cx, cy = W * fx, H * fy
        c.save(); c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
        c.set_source_surface(img, 0, 0); c.paint_with_alpha(a); c.restore()
        g = cairo.LinearGradient(0, 0, 0, H)
        for off, al in ((0.0, 0.80), (0.24, 0.42), (0.40, 0.30), (0.58, 0.42), (0.74, 0.70), (1.0, 0.92)):
            g.add_color_stop_rgba(off, INK[0], INK[1], INK[2], al * S.get("dim", 1.0) * a)
        c.set_source(g); c.paint()
    c.restore()
    y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 100, 0, max_lines=2, a=0) or 0
        _wtext(c, S["title"], 100, y + h1 / 2, a=a1, sc=s1, max_lines=2); y += h1 + 30
    if S.get("en"):
        a2, s2 = PP(t, t0 + 0.12, S); sz = S.get("size", 112)
        _wtext(c, S["en"], sz, S.get("en_y", 800), a=a2, sc=s2, max_lines=3)
    steps = S.get("steps") or []
    if steps:
        ts = [S["times"].get(f"s{i}", t0 + 0.3 + 1.6 * i) for i in range(len(steps))]; k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]
        a3, s3 = PP(t, ts[k], S, s0=0.6, bounce=1.4)
        cy = S.get("value_y", 840)
        _wtext(c, st["value"], S.get("vsize", 210), cy, color=YEL if st.get("color") != "white" else WHITE, a=a3, sc=s3, max_lines=1)
        if st.get("label"):
            _wtext(c, st["label"], 72, cy + 175, a=a3, sc=s3, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1352 if S.get("credit") else 1418, la)
    if S.get("credit"): _label(c, S["credit"], 1418, la)

# ================================================================== d01 additions (1 Nov 2026)
# - a headline label held on screen the whole reel (spec "label"), drawn on top of everything incl. the loop cross-fade,
#   so the last frame still equals frame 0
# - sc_stage: Apple-keynote dark stage, one big number (optional count-up) + one line, credit/source label
# - sc_river: "Which river? Which sea?" map quiz with a 3-2-1 counter, the Jordan + Mediterranean reveal and a
#   true-scale Belgium outline dropped over the land between the river and the sea
import json as _json
_draw_l = getattr(RD.Reel, "_draw_lbl_orig", RD.Reel.draw); RD.Reel._draw_lbl_orig = _draw_l
def _draw_label(self, c, t):
    _draw_l(self, c, t)
    s = self.spec.get("label")
    if not s: return
    keep = St.a; St.a = 1.0
    f = kit.font(40, 800); tw = f.getlength(s)
    sa(c, INK, 0.72); rr(c, 540 - tw / 2 - 34, 258 - 34, tw + 68, 68, 34); c.fill()
    sa(c, SKY, 0.95); c.set_line_width(3); rr(c, 540 - tw / 2 - 34, 258 - 34, tw + 68, 68, 34); c.stroke()
    kit.tx(c, s, 40, 540, 258, w=800, col=RD.c255(WHITE), a=1.0, shadow=False, maxw=1000)
    St.a = keep
RD.Reel.draw = _draw_label

def _stage_bg(c, t, S):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, 0.03, 0.06, 0.14); g.add_color_stop_rgb(1, 0.06, 0.12, 0.27)
    c.set_source(g); c.paint_with_alpha(St.a)
    x = 540 + 120 * math.sin(t * 0.35); y = 880 + 90 * math.cos(t * 0.28)
    rg = cairo.RadialGradient(x, y, 0, x, y, 720); rg.add_color_stop_rgba(0, SKY[0], SKY[1], SKY[2], 0.20 * St.a); rg.add_color_stop_rgba(1, SKY[0], SKY[1], SKY[2], 0)
    c.set_source(rg); c.paint()

def _fmt_step(st, u):
    if "num" not in st: return st["value"]
    v0 = st.get("from", 0); v = v0 + (st["num"] - v0) * ease(min(1.0, max(0.0, u)))
    d = st.get("dec", 0); s = f"{v:,.{d}f}"
    return st.get("prefix", "") + s + st.get("suffix", "")

def sc_stage(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S); y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 100, 0, max_lines=2, a=0) or 0
        _wtext(c, S["title"], 100, y + h1 / 2, a=a1, sc=s1, max_lines=2); y += h1 + 30
    if S.get("en"):
        a2, s2 = PP(t, t0 + 0.12, S); _wtext(c, S["en"], S.get("size", 112), S.get("en_y", 800), a=a2, sc=s2, max_lines=3)
    steps = S.get("steps") or []
    if steps:
        ts = [S["times"].get(f"s{i}", t0 + 0.3 + 1.6 * i) for i in range(len(steps))]
        k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0]); st = steps[k]
        a3, s3 = PP(t, ts[k], S, s0=0.6, bounce=1.4)
        u = 1.0 if (S.get("hook") and ts[k] <= RD.HOOK_GRACE) else (t - ts[k]) / st.get("dur", 1.1)
        cy = S.get("value_y", 840)
        _wtext(c, _fmt_step(st, u), S.get("vsize", 230), cy, color=YEL if st.get("color") != "white" else WHITE, a=a3, sc=s3, max_lines=1)
        if st.get("label"): _wtext(c, st["label"], 72, cy + 190, a=a3, sc=s3, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)


# ================================================================== rmk1 additions (1 Nov 2026): split hook, two roads, scorecard
GREEN = kit.hx("#2ECC71"); RED = kit.hx("#E5484D")

def _half(c, path, x0, w, t, t0, fx, tint, z1=1.07):
    u = _ease3(min(1.0, max(0.0, (t - t0) / 6.0))); z = 1.0 + (z1 - 1.0) * u
    img = _cover(path, w, H, fx, 0.5)
    c.save(); c.rectangle(x0, 0, w, H); c.clip()
    cx, cy = x0 + w / 2, H / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(img, x0, 0); c.paint_with_alpha(St.a); c.restore()
    g = cairo.LinearGradient(0, 0, 0, H)
    for off, al in ((0.0, 0.86), (0.32, 0.62), (0.55, 0.62), (0.75, 0.70), (1.0, 0.92)):
        g.add_color_stop_rgba(off, INK[0], INK[1], INK[2], al * St.a)
    c.save(); c.rectangle(x0, 0, w, H); c.clip(); c.set_source(g); c.paint()
    sa(c, tint, 0.16); c.rectangle(x0, 0, w, H); c.fill(); c.restore()

def sc_split(c, t, S):
    """Split screen: left = UNHCR (every other refugee), right = UNRWA (one people); hook text across the top."""
    t0 = 0.0 if S.get("hook") else S["t0"]
    _half(c, S["left"]["src"], 0, 540, t, t0, S["left"].get("fx", 0.5), SKY)
    _half(c, S["right"]["src"], 540, 540, t, t0, S["right"].get("fx", 0.5), YEL)
    pulse = 0.65 + 0.35 * math.sin(t * 3.2)
    sa(c, WHITE, 0.85); c.rectangle(537, 0, 6, H); c.fill()
    rg = cairo.RadialGradient(540, 1050, 0, 540, 1050, 380); rg.add_color_stop_rgba(0, 1, 1, 1, 0.22 * pulse * St.a); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
    c.set_source(rg); c.paint()
    hk = S.get("hook")
    a1, s1 = (1.0, 1.0) if hk else PP(t, S["t0"] + 0.05, S)
    breath = 1 + 0.015 * math.sin(t * 2.4)
    _wtext(c, S["en"], S.get("size", 128), S.get("en_y", 520), a=a1, sc=s1 * breath, max_lines=2, maxw=S.get("maxw", 1000))
    for side, cx, colr in (("left", 270, SKY), ("right", 810, YEL)):
        d = S[side]; a2, s2 = (1.0, 1.0) if hk else PP(t, S["t0"] + 0.15, S)
        c.save(); c.translate(cx - 540, 0)
        _wtext(c, d["name"], 100, 1060, color=colr, hl=colr, a=a2, sc=s2, max_lines=1, maxw=470)
        _wtext(c, d["label"], 64, 1200, a=a2, sc=s2, max_lines=2, maxw=470)
        c.restore()
    la = 1.0 if hk else RD.fade_in(t, S["t0"] + 0.4, S)
    if S.get("credit"): _label(c, S["credit"], 1418, la)

def _stroke_partial(c, pts_fn, n, u):
    pts = [pts_fn(i / n) for i in range(int(n * max(0.0, min(1.0, u))) + 1)]
    if len(pts) < 2: return False
    c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; return True

def sc_roads(c, t, S):
    """Two roads from one start: a fork drawn on a dark keynote stage, moving centre dashes, Way 1 / Way 2 pills."""
    t0 = S["t0"]; _stage_bg(c, t, S); tm = S["times"]
    a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 108, 0, a=0, max_lines=2)
    _wtext(c, S["title"], 108, TOP + 20 + h1 / 2, a=a1, sc=s1, max_lines=2)
    def bez(p0, p1, p2, p3):
        return lambda u: tuple((1 - u) ** 3 * p0[i] + 3 * (1 - u) ** 2 * u * p1[i] + 3 * (1 - u) * u * u * p2[i] + u ** 3 * p3[i] for i in (0, 1))
    trunk = bez((540, 1560), (540, 1480), (540, 1400), (540, 1330))
    left = bez((540, 1330), (540, 1160), (250, 1120), (250, 900))
    right = bez((540, 1330), (540, 1160), (830, 1120), (830, 900))
    uT = ease(min(1.0, max(0.0, (t - t0 - 0.1) / 0.6)))
    tl = tm.get("w1", t0 + 0.6); tr = tm.get("w2", t0 + 1.2)
    uL = ease(min(1.0, max(0.0, (t - tl + 0.3) / 0.7))); uR = ease(min(1.0, max(0.0, (t - tr + 0.3) / 0.7)))
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for fn, u, colr in ((trunk, uT, WHITE), (left, uL, SKY), (right, uR, YEL)):
        if _stroke_partial(c, fn, 60, u): sa(c, (0.20, 0.26, 0.38), St.a); c.set_line_width(130); c.stroke()
        if _stroke_partial(c, fn, 60, u): sa(c, colr, 0.9 * St.a); c.set_line_width(8); c.set_dash([34, 30], -t * 90); c.stroke(); c.set_dash([])
    for key, x, tt, colr, sub in (("w1", 250, tl, SKY, S.get("sub1")), ("w2", 830, tr, YEL, S.get("sub2"))):
        a2, s2 = PP(t, tt, S, s0=0.5, bounce=1.6)
        if a2 <= 0.01: continue
        pill(c, "Way 1" if key == "w1" else "Way 2", 80, x, 790, P["navy"], P["white"], a2, s2, outline=colr, w=900, padh=1.35)
        if sub:
            c.save(); c.translate(x - 540, 0); _wtext(c, sub, 60, 690, color=colr, hl=colr, a=a2, sc=s2, max_lines=2, maxw=440); c.restore()
    if S.get("source"): _label(c, S["source"], 1418, RD.fade_in(t, t0 + 0.4, S))

def sc_score(c, t, S):
    """Scorecard: one row per mass displacement, a status chip per row (green Citizens, red Refugees)."""
    t0 = S["t0"]; _stage_bg(c, t, S); tm = S["times"]
    y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 96, 0, a=0, max_lines=2)
        _wtext(c, S["title"], 96, y + h1 / 2, a=a1, sc=s1, max_lines=2); y += h1 + 34
    rows = S["rows"]; n = len(rows); bot = 1370 if S.get("source") else 1420
    rh = min(230, (bot - y) / n); bh = rh - 22
    for k, r in enumerate(rows):
        tk = tm.get(f"r{k}", t0 + 0.15 + 0.12 * k)
        hk = S.get("hook") and tk <= RD.HOOK_GRACE
        if t < tk - 0.07 and not hk: continue
        a = 1.0 if hk else fade_in(t, tk - 0.07, S, 0.25); u = 1.0 if hk else ease((t - tk + 0.07) / 0.4)
        yy = y + rh * k + rh / 2; dx = 220 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        bad = r.get("bad")
        sa(c, INK, 0.62); rr(c, 30, yy - bh / 2, 1020, bh, 34); c.fill()
        sa(c, RED if bad else SKY, 0.95 if bad else 0.55); c.set_line_width(5 if bad else 3); rr(c, 30, yy - bh / 2, 1020, bh, 34); c.stroke()
        _ltext(c, r["en"], 62, 72, yy - 33, WHITE, 590)
        _ltext(c, r["num"], 56, 72, yy + 40, YEL, 590, w=800)
        st_t = tm.get(f"st{k}", tm.get("st", tk + 0.35) + (0.14 * k if f"st{k}" not in tm and "st" in tm else 0))
        hs = S.get("hook") and st_t <= RD.HOOK_GRACE
        if t >= st_t - 0.05 or hs:
            a3, s3 = (1.0, 1.0) if hs else PP(t, st_t, S, s0=0.4, bounce=1.8)
            chip = r.get("chip", "Citizens"); colr = RED if bad else GREEN
            f = kit.font(56, 900); tw = f.getlength(chip); cw = tw + 70; cx = 1050 - 34 - cw / 2
            c.save(); c.translate(cx, yy); c.scale(s3, s3); c.translate(-cx, -yy)
            sa(c, colr, 0.95 * a3); rr(c, cx - cw / 2, yy - 46, cw, 92, 46); c.fill()
            kit.tx(c, chip, 56, cx, yy, w=900, col=RD.c255(WHITE), a=a3, shadow=False, maxw=cw)
            c.restore()
        c.restore(); St.a = old
    if S.get("source"): _label(c, S["source"], 1418, RD.fade_in(t, t0 + 0.4, S))

def _ltext(c, s, sz, x, y, color, maxw, w=900):
    s = RD.clean(s).replace("*", ""); f = kit.font(sz, w)
    while f.getlength(s) > maxw and sz > 52: sz -= 2; f = kit.font(sz, w)
    kit.tx(c, s, sz, x, y, w=w, col=RD.c255(color), a=1.0, shadow=False, maxw=maxw + 4, anchor="l")
