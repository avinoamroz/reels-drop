"""this_life_v4 scenes (1 Nov, Noam's structure 13:47).
faiths: ONE screen with three photo rows (Jews, Christians, Muslims). Rows pop in on their words in the overview line,
  then each row is highlighted in turn (marks f0, f1, f2) with its own key line, credit and source.
  {"type": "faiths", "title", "rows": [{"name", "key", "src", "credit", "source"}], "marks": {"r0","r1","r2","f0","f1","f2"}}
split: about 2 billion Muslims as a 10 x 10 dot grid (1 dot = 20 million). All dots are 'build this life' blue, then at
  mark "split" the last 20 dots turn red ('if 1 in 5'), then at mark "big" a big 400 million lands.
  {"type": "split", "title", "marks": {"split","big"}, "source"}
Text 64 px or more, labels and credits 36 px or more, English only."""
import sys; sys.path.insert(0, "/home/claude/fixes_1101/looplib.py".rsplit("/", 1)[0])
import looplib; looplib.wrap(globals(), "/home/claude/this_life/scenes_tl.py")
import math
import render as RD
from render import P, T, pill, PP, fade_in, block, block_h, image_surf, col
from kit import ease, ramp, lerp, St, sa, rr, circ, box
import cairo

SKY = (0x45 / 255, 0xA4 / 255, 0xDD / 255, 1.0)
YEL = (0xFF / 255, 0xD2 / 255, 0x3F / 255, 1.0)
NAVY = (0x16 / 255, 0x32 / 255, 0x61 / 255, 1.0)
RED = (0xD6 / 255, 0x3A / 255, 0x4A / 255, 1.0)

def _src(c, t, s, t0, a=1.0, y=1490):
    """source label at 36 px, up to 2 lines"""
    if not s: return
    z, ls = RD.wrap(s, 36, 700, 940, 2, 0.99)
    z = max(z, 36)
    for k, l in enumerate(ls): T(c, l, z, 540, y - 22 * (len(ls) - 1) + 44 * k, P["grey"], a * fade_in(t, t0, {}, 0.3), 1.0, 700, src=True)

def _title(c, t, S, y=300, size=76):
    en = S.get("title")
    if not en: return y
    a, s = PP(t, S["t0"] + 0.05, S); h1 = block_h(en, size, 900, 940, 2)
    block(c, en, size, 540, y + h1 / 2 - size / 2, P["navy"], a, s, hl=SKY, maxw=940, max_lines=2)
    return y + h1 - size / 2 + 30

def sc_faiths(c, t, S):
    tm = S["times"]; rows = S["rows"]
    y = _title(c, t, S)
    top, bot, gap = y + 10, 1410, 26; rh = (bot - top - gap * 2) / 3
    foc = [tm.get(f"f{k}") for k in range(3)]
    cur = None
    for k in range(3):
        if foc[k] is not None and t >= foc[k] - 0.05: cur = k
    for k, r in enumerate(rows):
        tr = tm.get(f"r{k}", S["t0"] + 0.3 + 0.5 * k)
        a, s = PP(t, tr, S, d=0.4, s0=0.6, bounce=1.4)
        if a <= 0.01: continue
        # focus amount for this row, and dim amount when another row is focused
        on = 0.0; dim = 0.0
        if cur is not None:
            tf = foc[cur]; u = ease(min(1.0, max(0.0, (t - tf + 0.05) / 0.35)))
            if k == cur: on = u
            else:
                prev = None
                for j in range(cur):
                    if foc[j] is not None: prev = j
                dim = u if (prev is None or k != prev) else u
                # a row that was focused before fades back to dim
        x0, w = 70, 940; y0 = top + k * (rh + gap); h = rh
        sc_ = s * (1 + 0.035 * on)
        c.save(); c.translate(540, y0 + h / 2); c.scale(sc_, sc_); c.translate(-540, -(y0 + h / 2))
        old = St.a; St.a *= a
        sa(c, NAVY, 0.16); rr(c, x0 + 3, y0 + 12, w, h, 34); c.fill()
        c.save(); rr(c, x0, y0, w, h, 34); c.clip()
        u = max(0.0, t - tr); z = 1.04 + 0.05 * min(1.0, u / 30.0)
        surf = image_surf(r["src"], w * 1.16, h * 1.16)
        c.translate(x0 + w / 2, y0 + h / 2); c.scale(z / 1.16, z / 1.16)
        c.set_source_surface(surf, -w * 0.58, -h * 0.58); c.paint_with_alpha(St.a); c.restore()
        # dark gradient behind the text, left side
        c.save(); rr(c, x0, y0, w, h, 34); c.clip()
        g = cairo.LinearGradient(x0, 0, x0 + w, 0)
        g.add_color_stop_rgba(0, NAVY[0], NAVY[1], NAVY[2], 0.86 * St.a); g.add_color_stop_rgba(0.55, NAVY[0], NAVY[1], NAVY[2], (0.45 + 0.25 * on) * St.a)
        g.add_color_stop_rgba(1, NAVY[0], NAVY[1], NAVY[2], 0.10 * St.a)
        c.set_source(g); c.paint()
        if dim > 0: sa(c, (0.93, 0.94, 0.96, 1), 0.62 * dim); c.paint()
        c.restore()
        if on > 0:
            rr(c, x0, y0, w, h, 34); sa(c, YEL, on); c.set_line_width(9); c.stroke()
        # name, key line, credit
        ka = on
        ny = y0 + h / 2 - 46 * ka
        T(c, r["name"], 96, x0 + 50, ny, P["white"], 1.0, 1.0, 900, maxw=820, anchor="l")
        if ka > 0.02 and r.get("key"):
            T(c, r["key"], 64, x0 + 50, y0 + h / 2 + 62, P["white"], ka, 1.0, 800, hl=YEL, maxw=840, anchor="l")
        if r.get("credit"):
            T(c, r["credit"], 36, x0 + w - 26, y0 + 34, P["white"], 0.9, 1.0, 700, maxw=520, anchor="r", src=True)
        St.a = old; c.restore()
    if cur is not None:
        _src(c, t, rows[cur].get("source"), foc[cur] + 0.4)

def sc_split(c, t, S):
    tm = S["times"]
    y = _title(c, t, S, size=84)
    ts, tb = tm.get("split", S["t0"] + 2.5), tm.get("big", S["t0"] + 4.5)
    # 10 x 10 grid
    n, cell = 10, 80
    x0 = 540 - (n - 1) * cell / 2; y0 = y + 50
    for i in range(100):
        r_, c_ = divmod(i, n); cx, cy = x0 + c_ * cell, y0 + r_ * cell
        tk = S["t0"] + 0.25 + 0.012 * i
        a, s = PP(t, tk, S, d=0.3, s0=0.2, bounce=1.8)
        if a <= 0.01: continue
        bad = i >= 80
        u = ease(min(1.0, max(0.0, (t - ts - 0.02 * (i - 80)) / 0.3))) if bad else 0.0
        cc = tuple(lerp(SKY[j], RED[j], u) for j in range(3)) + (1.0,)
        rad = 30 * s * (1 + 0.15 * u * max(0.0, 1 - (t - ts) / 0.8))
        circ(c, cx, cy, rad, cc, a)
    gy = y0 + (n - 1) * cell + 100
    # legend
    la, ls = PP(t, S["t0"] + 1.2, S)
    circ(c, 150, gy, 22, SKY, la); T(c, "Most: build this *life*", 64, 196, gy, P["navy"], la, 1.0, 800, hl=SKY, maxw=800, anchor="l")
    ra, rs = PP(t, ts, S)
    circ(c, 150, gy + 92, 22, RED, ra); T(c, "What if *1 in 5*?", 64, 196, gy + 92, P["navy"], ra, 1.0, 800, hl=RED, maxw=800, anchor="l")
    # big number
    ba, bs = PP(t, tb, S, bounce=2.4)
    if ba > 0.01:
        by = y0 + 4 * cell
        c.save(); c.translate(540, by); c.scale(bs, bs); c.translate(-540, -by)
        old = St.a; St.a *= ba
        box(c, 90, by - 105, 900, 210, 40, NAVY, 1.0)
        T(c, "400 million", 150, 540, by, YEL, 1.0, 1.0, 900, maxw=840)
        St.a = old; c.restore()
    _src(c, t, S.get("source"), ts + 0.3, y=1500)
