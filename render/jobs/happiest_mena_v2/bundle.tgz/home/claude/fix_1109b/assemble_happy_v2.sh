#!/bin/bash
# happiest_mena_v2: render the map tail, then the same globe opener as v1 (map_open.py globe_spin_whip 2.4 s) + the new mix
set -e
D=/home/claude/daily_1104/happiest_mena_v2
cd /home/claude/fix_1109b && python3 happy_map_v2.py --endimg=/home/claude/daily_1104/happiest_mena/op_0.00.png
cd /home/claude/map_tear_opener
python3 map_open.py --style globe_spin_whip --reel $D/out/silent.mp4 --cam 35.0,27,52.9,895 --hook "Who's happiest|in the *Middle East?*" --hook-y 353 --hook-s 0.9 --out $D/out/op_full.mp4
DUR=$(python3 -c "import json;print(round(json.load(open('$D/timing.json'))['dur']+0.9,2))")
ffmpeg -nostdin -v error -y -i $D/out/op_full.mp4 -i $D/audio.m4a -filter_complex "[0:a]volume=0.8[s];[1:a][s]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.89[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -ar 48000 -t $DUR -movflags +faststart $D/out/happiest_mena_v2.mp4
