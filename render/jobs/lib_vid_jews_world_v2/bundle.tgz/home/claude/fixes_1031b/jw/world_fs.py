import sys, runpy, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, subprocess
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
sys.path.insert(0,"/home/claude/vid"); from topo import land_polys
matplotlib.font_manager.fontManager.addfont if False else None
matplotlib.rcParams["font.family"]=["Inter","Liberation Sans","DejaVu Sans"]
C=runpy.run_path(sys.argv[1]); G=C["G"]; EVENTS=C["EVENTS"]; TL=C["TL"]; FLOWS=C.get("FLOWS",[])
W,H,FPS=1080,1920,30; HOLD=C.get("HOLD",0.8); ty=[t for _,t in TL]; yy=[y for y,_ in TL]; N=int((TL[-1][1]+HOLD)*FPS)
LAND=land_polys()
def val(pts,y):
    if y<pts[0][0]: return 0
    if y>pts[-1][0]: return pts[-1][1]
    return float(np.interp(y,[p[0] for p in pts],[p[1] for p in pts]))
def fmt_year(y):
    y=int(round(y)); return f"{-y} BCE" if y<0 else (f"{y} CE" if y<1000 else str(y))
def fmt_n(v): return f"{v/1e9:.2f}B" if v>=1e9 else f"{v/1e6:.2f}M" if v>=1e6 else (f"{v/1e3:.0f}k" if v>=1e4 else f"{int(round(v,-2)):,}")
names=list(G); pos={}
FL={n:plt.imread(f"/home/claude/fixes_1031b/jw/flags/{G[n][3]}.png") for n in names if len(G[n])>3 and G[n][3]}
fig=plt.figure(figsize=(W/100,H/100),dpi=100)
import os
PV=[int(float(x)*30) for x in os.environ["PREVIEW"].split(",")] if os.environ.get("PREVIEW") else None
ff=None if PV else subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","rawvideo","-pix_fmt","rgba","-s",f"{W}x{H}","-r",str(FPS),"-i","-","-c:v","libx264","-pix_fmt","yuv420p","-crf","18","-preset","medium",C["OUT"]],stdin=subprocess.PIPE)
DOTPOOL=None
if C.get("DOTS"):
    from matplotlib.path import Path as _P
    _paths=[_P(p) for p in LAND if len(p)>=3]
    DOTPOOL={}
    for gi,n in enumerate(names):
        lo,la=G[n][4]; sx,sy=C.get("SPREAD",{}).get(n,(8,6)); need=int(max(v for _,v in G[n][2])/C["DOTS"])+3
        rng_=np.random.default_rng(100+gi); got=[]
        tries=0
        while len(got)<need and tries<40:
            q=rng_.normal([lo,la],[sx,sy],size=(max(need*4,400),2)); ok=np.zeros(len(q),bool)
            for pth in _paths:
                ok|=pth.contains_points(q)
            got.extend(q[ok].tolist()); tries+=1
        DOTPOOL[n]=np.array(got[:need]) if got else np.zeros((0,2))
rng=np.random.default_rng(3); PART=[]  # particles per flow
for fi,(y0,y1,a,b,dens) in enumerate(FLOWS):
    PART.append(rng.random(int(dens)))
ROWS=C.get("ROWS",6); RMAX=C.get("RMAX",70); VMAX=C.get("VMAX",8e6); CAM=C["CAM"]
for f in (PV if PV else range(N)):
    t=min(f/FPS,TL[-1][1]); year=np.interp(t,ty,yy); tt=f/FPS
    vals={n:val(G[n][2],year) for n in names}
    fig.clf(); fig.patch.set_facecolor("#0b1020")
    fig.text(0.5,0.952,C["T_EN"],ha="center",color="white",fontsize=C.get("T_FS",46)-4,fontweight="bold")
    fig.text(0.5,0.921,C["T_HE"],ha="center",color="#ffd166",fontsize=C.get("T_FS",46)-8,fontweight="bold")
    fig.text(0.5,0.898,C["SUB"],ha="center",color="#9aa4bf",fontsize=19)
    AXM=C["MAP_AX"]; mx=fig.add_axes(AXM); mx.set_facecolor("#0d1630")
    cx=float(np.interp(year,[k[0] for k in CAM],[k[1] for k in CAM])); cy=float(np.interp(year,[k[0] for k in CAM],[k[2] for k in CAM])); xs=float(np.interp(year,[k[0] for k in CAM],[k[3] for k in CAM]))
    ys=xs*(AXM[3]*H)/(AXM[2]*W)/C.get("MAP_ASPECT",1.15)
    for p in LAND: mx.fill(p[:,0],p[:,1],color="#22305a",lw=0.6,edgecolor="#33467a")
    mx.set_xlim(cx-xs/2,cx+xs/2); mx.set_ylim(cy-ys/2,cy+ys/2); mx.set_aspect(C.get("MAP_ASPECT",1.15)); mx.axis("off")
    # continent names (white), shown once the camera has zoomed out to the world
    _ca=min(1.0,max(0.0,(xs-C.get("CONT_XS0",100))/40.0))
    if _ca>0:
        for _nm,(_lo,_la) in C.get("CONTINENTS",{}).items():
            if cx-xs/2<_lo<cx+xs/2 and cy-ys/2<_la<cy+ys/2:
                mx.text(_lo,_la,_nm,ha="center",va="center",color="white",fontsize=C.get("CONT_FS",28),fontweight="bold",alpha=0.92*_ca,zorder=2.5)
    ZK=70.0/xs
    # flows
    for fi,(y0,y1,a,b,dens) in enumerate(FLOWS):
        if not (y0<=year<=y1): continue
        (x0,y_0),(x1,y_1)=G[a][4],G[b][4]; cx,cy=(x0+x1)/2,(y_0+y_1)/2+0.25*abs(x1-x0)+3
        ph=(PART[fi]+tt*0.45)%1.0
        bx=(1-ph)**2*x0+2*(1-ph)*ph*cx+ph**2*x1; by=(1-ph)**2*y_0+2*(1-ph)*ph*cy+ph**2*y_1
        mx.scatter(bx,by,s=14,color="#ffd166",alpha=0.85,linewidths=0,zorder=4)
    if DOTPOOL is not None:
        P_=[];CC=[]
        for n in names:
            k=int(round(vals[n]/C["DOTS"]))
            if k>0: P_.append(DOTPOOL[n][:k]); CC+= [G[n][1]]*min(k,len(DOTPOOL[n]))
        if P_:
            P_=np.vstack(P_); o=np.random.default_rng(7).permutation(len(P_))
            mx.scatter(P_[o,0],P_[o,1],s=C.get("DS",3),c=np.array(CC)[o],alpha=0.9,linewidths=0,zorder=3)
        mx.text(0.99,0.02,C.get("DOT_LEGEND",""),transform=mx.transAxes,ha="right",va="bottom",color="#9aa4bf",fontsize=13)
    for n in ([] if DOTPOOL is not None else sorted(names,key=lambda n:-vals[n])):
        v=vals[n]
        if v<C.get("MIN",500): continue
        lo,la=G[n][4]; r=(RMAX*np.sqrt(v/VMAX)+3)*max(0.55,min(1.6,ZK))
        mx.scatter([lo],[la],s=r**2,color=G[n][1],alpha=0.55,edgecolors="white",linewidths=0.8,zorder=3)
    top=sorted([n for n in names if vals[n]>=C.get("MIN",500)],key=lambda n:-vals[n])[:ROWS]
    BV=vals; BG=G; bnames=names
    if C.get("AGG"):
        BV={gname:sum(vals[n] for n in names if n.split(":")[0]==gname) for gname in C["AGG"]}
        BG={gname:(C["AGG"][gname][0],C["AGG"][gname][1]) for gname in C["AGG"]}
        bnames=list(C["AGG"])
    btop=sorted([n for n in bnames if BV[n]>=C.get("MIN",500)],key=lambda n:-BV[n])[:ROWS]
    placed=[]
    for n in ([] if C.get("AGG") else top[:5]):
        lo,la=G[n][4]
        if not (cx-xs/2<lo<cx+xs/2 and cy-ys/2<la<cy+ys/2): continue
        px=(lo-(cx-xs/2))/xs*W; py=(la-(cy-ys/2))/ys*AXM[3]*H
        if any(abs(px-qx)<150 and abs(py-qy)<60 for qx,qy in placed): continue
        placed.append((px,py)); rr=(RMAX*np.sqrt(vals[n]/VMAX)+3)*max(0.55,min(1.6,ZK))
        mx.annotate(f"{G[n][0] if False else n.split(' (')[0]}\n{fmt_n(vals[n])}",(lo,la),xytext=(0,-rr*0.5-6),textcoords="offset points",ha="center",va="top",color="white",fontsize=15,fontweight="bold",zorder=6,
                    bbox=dict(boxstyle="round,pad=0.25",fc="#0b1020",ec="none",alpha=0.65))
    # ranking bars
    ax=fig.add_axes(C["BARS_AX"]); ax.set_facecolor("#0b1020")
    mxv=max([BV[n] for n in btop]+[1000]); xmax=mxv*1.7
    for i,n in enumerate(btop): pos[n]=i if n not in pos or pos[n] is None else pos[n]+(i-pos[n])*0.15
    for n in bnames:
        if n not in btop: pos[n]=None
    ax.set_xlim(0,xmax); ax.set_ylim(ROWS-0.4,-0.6); ax.axis("off")
    for n in btop:
        v=BV[n]; p=pos[n]; heb,c=BG[n][0],BG[n][1]
        ax.barh(p,v,height=0.75,color=c)
        fw=0
        if n in FL:
            ax.add_artist(AnnotationBbox(OffsetImage(FL[n],zoom=0.55),(v+xmax*0.012,p),box_alignment=(0,0.5),frameon=False)); fw=xmax*0.06
        ax.text(v+xmax*0.015+fw,p,f"{fmt_n(v)}   {C.get('AGG_LABEL',{}).get(n,n)}  {heb}",va="center",ha="left",color="white",fontsize=20,fontweight="bold")
    tot=val(C['COUNTER'][2],year) if len(C['COUNTER'])>2 else sum(vals.values())
    fig.text(0.07,0.205,C["COUNTER"][0]+"  |  "+C["COUNTER"][1],ha="left",color="#9aa4bf",fontsize=19,fontweight="bold")
    fig.text(0.07,0.165,f"{int(round(tot,-3)):,}",ha="left",color="#7dd3fc",fontsize=40,fontweight="bold")
    fig.text(0.93,0.168,fmt_year(year),ha="right",color="white",fontsize=(54 if year<0 else 64),fontweight="bold",alpha=0.9)
    fig.text(0.93,0.146,"לפני הספירה" if year<0 else "לספירה",ha="right",color="#ffd166",fontsize=28,fontweight="bold")
    ev=[e for e in EVENTS if e[0]<=year]
    tq=TL[-1][1]-C.get("Q_LEAD",3.2)
    if tt>=tq:
        qa=min(1,(tt-tq)/0.3)
        from matplotlib.patches import FancyBboxPatch as _FQ
        fig.patches.append(_FQ((0.05,0.062),0.90,0.068,boxstyle="round,pad=0.006,rounding_size=0.015",transform=fig.transFigure,facecolor="#0f1a33",edgecolor="#ffd166",lw=3,alpha=qa))
        fig.text(0.5,0.108,C["QUESTION"][0],ha="center",va="center",color="white",fontsize=30,fontweight="bold",alpha=qa)
        fig.text(0.5,0.079,C["QUESTION"][1],ha="center",va="center",color="#ffd166",fontsize=28,fontweight="bold",alpha=qa)
    elif ev:
        te=float(np.interp(ev[-1][0],yy,ty))
        ea=1.0 if tt-te<3.0 else max(0.0,1-(tt-te-3.0)/0.3)
        if ea>0:
            fig.text(0.5,0.108,ev[-1][1],ha="center",va="center",color="#ffd166",fontsize=28,fontweight="bold",alpha=ea)
            fig.text(0.5,0.079,ev[-1][2],ha="center",va="center",color="white",fontsize=28,fontweight="bold",alpha=ea)
    for i,l in enumerate(C["DISC"]): fig.text(0.5,0.045-0.012*i,l,ha="center",color="#6b7694",fontsize=13)
    if C.get("HOOK") and f/FPS<1.0:
        a=1.0 if f/FPS<0.75 else max(0,1-(f/FPS-0.75)/0.25)
        from matplotlib.patches import FancyBboxPatch as _FH
        fig.patches.append(matplotlib.patches.Rectangle((0,0),1,1,transform=fig.transFigure,color="#050914",alpha=0.86*a,zorder=50))
        fig.patches.append(_FH((0.06,0.40),0.88,0.26,boxstyle="round,pad=0.01,rounding_size=0.03",transform=fig.transFigure,facecolor="#0f1a33",edgecolor=C["HOOK"][4],lw=4,alpha=a,zorder=51))
        for yy_,tx,cc,fz in [(0.615,C["HOOK"][0],"white",40),(0.565,C["HOOK"][1],C["HOOK"][4],40),(0.495,C["HOOK"][2],"white",36),(0.445,C["HOOK"][3],C["HOOK"][4],36)]:
            fig.text(0.5,yy_,tx,ha="center",va="center",color=cc,fontsize=fz,fontweight="bold",alpha=a,zorder=52)
    fig.canvas.draw()
    if PV: fig.savefig(f"/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/fr/jw_{f:04d}.png",dpi=30); continue
    ff.stdin.write(fig.canvas.buffer_rgba().tobytes())
if ff: ff.stdin.close(); ff.wait()
print("done",C["OUT"])
