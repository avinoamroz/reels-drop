"""Bespoke reelkit scenes for the Mandarin-by-accident reel: Chinese characters + pinyin with tone marks.
Heebo has no CJK or tone-marked vowels, so these are drawn with a Noto Sans CJK SC subset (cjk_sub.otf, SIL OFL)."""
import math
from PIL import Image, ImageDraw, ImageFont
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, c255, source
from kit import pil2cairo, St, box, rr, sa

CJK = "/home/claude/mandarin/fonts/cjk_sub.otf"
_cache = {}
def cjk(s, sz, color):
    k = (s, sz, color)
    if k not in _cache:
        f = ImageFont.truetype(CJK, sz); x0, y0, x1, y1 = f.getbbox(s); pad = 8
        im = Image.new("RGBA", (x1 - x0 + 2 * pad, y1 - y0 + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - x0, pad - y0), s, font=f, fill=c255(color))
        _cache[k] = (pil2cairo(im), im.size[0], im.size[1])
    return _cache[k]
def draw_cjk(c, s, sz, x, y, color, a=1.0, sc=1.0):
    if a * St.a <= 0.01 or abs(sc) < 1e-3: return 0
    surf, w, h = cjk(s, sz, color)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.set_source_surface(surf, -w / 2, -h / 2); c.paint_with_alpha(min(1, a * St.a)); c.restore()
    RD.FRAME_TEXT.append(s)
    return w
def M(S, k, d): return S["times"].get(k, d)

def card(c, x0, y0, w, h, a, s):
    cx, cy = x0 + w / 2, y0 + h / 2
    c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy); old = St.a; St.a *= a
    shadow_box(c, x0, y0, w, h, 30, P["card"], stroke=P["navy"], sw=6)
    St.a = old; c.restore()

def sc_phrase(c, t, S):
    """one phrase: pinyin, characters, per-character gloss, then the meaning and the 'heard, repeated, said' line"""
    t0 = S["t0"]; y = 300
    a, s = PP(t, t0 + 0.05, S); block(c, S["title"], 70, 540, y, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=2)
    a, s = PP(t, t0 + 0.2, S); T(c, S["title_he"], 52, 540, y + 90, P["blue"], a, s, 700)
    a, s = PP(t, t0 + 0.25, S, s0=0.6, bounce=1.4)
    card(c, 90, 470, 900, 560, a, s)
    chars, pys, gl = S["chars"], S["pinyin"], S["gloss"]
    n = len(chars); step = 200; x0 = 540 - step * (n - 1) / 2
    for k in range(n):
        tk = M(S, "chars", t0 + 0.4) + 0.12 * k
        a, s = PP(t, tk, S)
        x = x0 + step * k
        draw_cjk(c, pys[k], 58, x, 560, P["blue"], a, s)
        draw_cjk(c, chars[k], 150, x, 710, P["navy"], a, s * (1 + 0.015 * math.sin(max(0, t - tk) * 2.4)))
        T(c, gl[k], 40, x, 850, P["grey"], a, s, 700, maxw=190)
    a, s = PP(t, M(S, "chars", t0 + 0.4) + 0.6, S); draw_cjk(c, S["pinyin_line"], 64, 540, 960, P["gold_text"], a, s)
    tm = M(S, "mean", t0 + 2.5)
    a, s = PP(t, tm, S); pill(c, S["mean"], 64, 540, 1130, P["gold"], P["white"], a, s, w=900)
    a, s = PP(t, tm + 0.2, S); T(c, S["mean_he"], 54, 540, 1230, P["navy"], a, s, 700)
    tr = M(S, "rep", tm + 1.5)
    a, s = PP(t, tr, S); T(c, S["rep"], 56, 540, 1360, P["navy"], a, s, 900, hl=P["blue"])
    a, s = PP(t, tr + 0.2, S); T(c, S["rep_he"], 48, 540, 1440, P["blue"], a, s, 700)
    source(c, t, S)

def sc_cogito(c, t, S):
    """我 = I, then the full 我思故我在 with pinyin and meaning"""
    t0 = S["t0"]; tw = M(S, "wo", t0 + 0.3); tc = M(S, "cogito", t0 + 3.0)
    a, s = PP(t, tw, S); u = min(1.0, max(0.0, (t - tc) / 0.5))
    # 我 big, then it shrinks up as the sentence arrives
    y_big = 640 - 260 * u; sz = 1.0 - 0.45 * u
    draw_cjk(c, "wǒ", 70, 540, y_big - 230 * sz, P["blue"], a, s)
    draw_cjk(c, "我", 300, 540, y_big, P["navy"], a, s * sz)
    a2, s2 = PP(t, tw + 0.3, S); T(c, "*wǒ* = I", 80, 540, y_big + 220 * sz, P["navy"], a2 * (1 - u), s2, 900, hl=P["blue"])
    T(c, "= אני", 56, 540, y_big + 310 * sz, P["blue"], a2 * (1 - u), s2, 700)
    if t >= tc - 0.1:
        a, s = PP(t, tc, S, s0=0.6, bounce=1.4); card(c, 70, 560, 940, 520, a, s)
        chars = "我思故我在"; pys = ["wǒ", "sī", "gù", "wǒ", "zài"]; gl = ["I", "think", "therefore", "I", "am"]
        step = 176; x0 = 540 - step * 2
        for k in range(5):
            tk = tc + 0.15 + 0.1 * k; a, s = PP(t, tk, S); x = x0 + step * k
            draw_cjk(c, pys[k], 52, x, 650, P["blue"], a, s)
            draw_cjk(c, chars[k], 128, x, 790, P["gold_text"] if chars[k] == "我" else P["navy"], a, s)
            T(c, gl[k], 38, x, 920, P["grey"], a, s, 700, maxw=170)
        ti = M(S, "think", tc + 1.2)
        a, s = PP(t, ti, S); pill(c, "I think, therefore I am", 60, 540, 1160, P["gold"], P["white"], a, s, w=900)
        a, s = PP(t, ti + 0.2, S); T(c, "אני חושב, משמע אני קיים", 54, 540, 1260, P["navy"], a, s, 700)
        a, s = PP(t, ti + 0.4, S); T(c, "René Descartes, in Chinese: a classic tattoo", 42, 540, 1350, P["grey"], a, s, 700)
        T(c, "דקארט בסינית, קעקוע קלאסי", 40, 540, 1410, P["blue"], a, s, 700)
    source(c, t, S)

def sc_fluency(c, t, S):
    """the fluency CTA: title, then each English step with its Hebrew under it"""
    t0 = S["t0"]; y = 380
    a, s = PP(t, t0 + 0.05, S); block(c, S["title"], 96, 540, y, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=1)
    a, s = PP(t, t0 + 0.2, S); T(c, S["title_he"], 64, 540, y + 105, P["blue"], a, s, 700)
    y = 620
    for k, it in enumerate(S["items"]):
        tk = S["times"].get(f"i{k}", t0 + 0.6 + k)
        a, s = PP(t, tk, S)
        RD.draw_emoji(c, it["icon"], 540, y, 96, a, s)
        hb = block_h(it["en"], 60, 900, 900, 2)
        block(c, it["en"], 60, 540, y + 70 + hb / 2, P["navy"], a, s, hl=P["blue"], maxw=900, max_lines=2)
        T(c, it["he"], 50, 540, y + 70 + hb + 40, P["blue"], a, s, 700)
        y += 70 + hb + 40 + 110
    source(c, t, S)
