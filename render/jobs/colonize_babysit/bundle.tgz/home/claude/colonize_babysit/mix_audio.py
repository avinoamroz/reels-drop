"""local step: light playful bed + stamps / whoosh / pops under work/vo.wav -> work/mix.m4a (-14 LUFS, AAC 192k 48 kHz)"""
import sys, json, subprocess, os, re
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit"); import mix as MX
D = "/home/claude/colonize_babysit"
R = json.load(open(f"{D}/work/words.json")); W = R["words"]; LW = {}
for w in W: LW.setdefault(w["li"], []).append(w)
LS = lambda li: LW[li][0]["t0"]; LE = lambda li: LW[li][-1]["t1"]
def WT(li, word, occ=0, end=False):
    n = lambda s: re.sub(r"[^a-z0-9']", "", s.lower()); h = [w for w in LW[li] if n(w["w"]) == n(word)]; return h[occ]["t1" if end else "t0"]
T_END = round(LE(len(LW) - 1) + 0.6, 2)
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == 48000
if vo.ndim > 1: vo = vo.mean(1)
music = MX.bed("playful", T_END, end_at=LS(20) - 0.2)
ev = [(0.0, "ding", -4.0), (WT(15, "babysitting") - 0.06, "ding", -2.0), (LS(20) - 0.15, "ding", -5.0)]
for li in (2, 3, 4, 8, 9, 10, 12, 14, 16, 17, 19): ev.append((LS(li) - 0.35, "whoosh", -2.0))
for t in (WT(3, "here"), WT(5, "holds"), WT(6, "person", end=True) - 0.3, WT(7, "wage") - 0.2, LS(10) + 0.3, WT(10, "person", end=True) - 0.3,
          WT(11, "pay") - 0.3, WT(9, "hamas", occ=1), WT(12, "gas") - 0.3, WT(12, "water") - 0.3) + tuple(WT(14, "colonize", occ=k) - 0.05 for k in range(3)):
    ev.append((t, "pop", -3.0))
rep = MX.mix(vo, T_END, music, ev, f"{D}/work/mix.wav", music_db=-19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/work/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{D}/work/mix.m4a"], check=True)
os.remove(f"{D}/work/mix.wav"); rep["T_END"] = T_END; json.dump(rep, open(f"{D}/work/audio.json", "w"), indent=1); print(rep)
