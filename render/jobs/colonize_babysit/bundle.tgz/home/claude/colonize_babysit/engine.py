"""colonize_babysit engine: Noam's "Israel is a colonizer? Let's check." monologue reel (opinion + satire), timed to work/words.json.
usage: python3 engine.py [--snaps 0.5,12,...] [--silent]   (--silent writes work/silent.mp4; then build.py muxes work/mix.m4a)
House look: navy #163260, blue #2A88D4, gold #B8923F, silver. Map: Natural Earth 1:10m (world-atlas 2.0.2, public domain);
the land between the river and the sea is one gold shape, the Green Line in green. Safe zones: x 60..920, y 200..1540."""
import sys, os, json, math, re, argparse, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from shapely.geometry import Polygon, MultiPolygon, LineString, box
from shapely.ops import unary_union

D = "/home/claude/colonize_babysit"; FONTS = "/home/claude/vid/fonts"
GEO = "/home/claude/goals_scorecard/geodata/countries-10m.json"
W, H, FPS = 1080, 1920, 30
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--silent", action="store_true"); A = ap.parse_args()

def hx(h, a=255): h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY = hx("#163260"); NAVY0 = hx("#0C1C38"); BLUE = hx("#2A88D4"); GOLD = hx("#B8923F"); GOLD2 = hx("#E6C77E")
SILVER = hx("#C9D2DE"); SIL2 = hx("#A9BBD8"); WHITE = hx("#FFFFFF"); RED = hx("#E2485A"); GREEN = hx("#2FBF71"); AMBER = hx("#F2B035")
CARD = hx("#1E3F75"); CARD2 = hx("#13284D"); GL = hx("#2ECC71")
SEA = hx("#0A1A33"); LAND = hx("#24467E"); BORDER = (150, 180, 225, 150)

# ------------------------------------------------------------------ timing from the ASR words
R = json.load(open(f"{D}/work/words.json")); WORDS = R["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def LS(li): return LW[li][0]["t0"]
def LE(li): return LW[li][-1]["t1"]
def norm(s): return re.sub(r"[^a-z0-9']", "", s.lower())
def WT(li, word, occ=0, end=False):
    hits = [w for w in LW[li] if norm(w["w"]) == norm(word)]
    assert len(hits) > occ, (li, word, [w["w"] for w in LW[li]])
    return hits[occ]["t1" if end else "t0"]
NL = len(LW); VO_END = LE(NL - 1); T_END = round(VO_END + 0.6, 2); N = int(round(T_END * FPS))

# ------------------------------------------------------------------ fonts and text
_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", k[0])
    return _fc[k]
DASHES = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
DRAWN = set()
def tw(s, sz, w=800): return font(sz, w).getlength(s)
def fit(s, sz, w, maxw):
    while tw(s, sz, w) > maxw and sz > 20: sz -= 1
    return sz
def text(d, x, y, s, sz, col, w=800, anchor="la", a=1.0, maxw=None, shadow=True):
    assert not any(ch in s for ch in DASHES), s
    if a <= 0.01: return
    if maxw: sz = fit(s, sz, w, maxw)
    DRAWN.add(s); f = font(sz, w); c = col[:3] + (int(col[3] * a),)
    if shadow: d.text((x + 3, y + 4), s, font=f, fill=(0, 0, 0, int(120 * a)), anchor=anchor)
    d.text((x, y), s, font=f, fill=c, anchor=anchor)
def wrap(s, sz, w, maxw):
    out = [""]
    for word in s.split(" "):
        t = (out[-1] + " " + word).strip()
        if tw(t, sz, w) <= maxw or not out[-1]: out[-1] = t
        else: out.append(word)
    return out
def para(d, x, y, s, sz, col, w=800, maxw=860, lh=1.18, anchor="la", a=1.0):
    ls = wrap(s, sz, w, maxw)
    for i, l in enumerate(ls): text(d, x, y + i * sz * lh, l, sz, col, w, anchor, a)
    return y + len(ls) * sz * lh

def clamp(u): return max(0.0, min(1.0, u))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eob(u, s=1.7): u = clamp(u) - 1; return 1 + u * u * ((s + 1) * u + s)
def ramp(t, a, dur=0.25): return ease((t - a) / dur)
def win(t, a, b, fi=0.22, fo=0.22): return ramp(t, a, fi) * (1 - ramp(t, b - fo, fo))

# ------------------------------------------------------------------ geometry and maps
def topo(path):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
RAW = topo(GEO); VB = box(20, 18, 45, 38)
G = {k: v.intersection(VB) for k, v in RAW.items() if v.intersects(VB)}
LANDI = unary_union([G["Israel"], G["Palestine"]]).buffer(0.0005).buffer(-0.0005)
GLINE = G["Palestine"].boundary.intersection(G["Israel"].buffer(0.004))
_ps = list(G["Palestine"].geoms) if isinstance(G["Palestine"], MultiPolygon) else [G["Palestine"]]
GAZA = unary_union([p for p in _ps if p.centroid.x < 34.6]); WBANK = unary_union([p for p in _ps if p.centroid.x >= 34.6])
def rings(g):
    if g.is_empty: return []
    if isinstance(g, Polygon): return [list(g.exterior.coords)]
    return [list(p.exterior.coords) for p in getattr(g, "geoms", []) if isinstance(p, Polygon)]
def lines_of(g):
    if g.is_empty: return []
    if isinstance(g, LineString): return [list(g.coords)]
    return [list(x.coords) for x in getattr(g, "geoms", []) if isinstance(x, LineString)]
class Map:
    """static RGBA map of bbox (lon0, lat0, lon1, lat1) at size (w, h), 2x supersampled; proj() gives panel pixels"""
    def __init__(s, bb, w, h, hl=None, hl_col=BLUE, tol=0.002, ss=2, extra_hl=()):
        s.bb, s.w, s.h = bb, w, h; lon0, lat0, lon1, lat1 = bb; s.k = math.cos(math.radians((lat0 + lat1) / 2))
        s.sx = w / ((lon1 - lon0) * s.k); s.sy = h / (lat1 - lat0)
        im = Image.new("RGBA", (w * ss, h * ss), SEA); d = ImageDraw.Draw(im, "RGBA")
        P = lambda r: [((x - lon0) * s.k * s.sx * ss, (lat1 - y) * s.sy * ss) for x, y in r]
        bbx = box(lon0 - 1, lat0 - 1, lon1 + 1, lat1 + 1)
        for nm, g in G.items():
            if nm in ("Israel", "Palestine"): continue
            g = g.intersection(bbx).simplify(tol)
            col = LAND
            for e_nm, e_col in extra_hl:
                if nm == e_nm: col = e_col
            for r in rings(g): d.polygon(P(r), fill=col)
            for r in rings(g): d.line(P(r), fill=BORDER, width=ss)
        for r in rings(LANDI.simplify(tol)): d.polygon(P(r), fill=hx("#C9A24A")); d.line(P(r), fill=(255, 236, 190, 200), width=ss)
        if hl is not None:
            for r in rings(hl.simplify(tol)): d.polygon(P(r), fill=hl_col[:3] + (150,))
        for ln in lines_of(GLINE.simplify(tol / 2)): d.line(P(ln), fill=GL, width=int(2.2 * ss), joint="curve")
        s.im = im.resize((w, h), Image.LANCZOS)
    def proj(s, lon, lat): return ((lon - s.bb[0]) * s.k * s.sx, (s.bb[3] - lat) * s.sy)
def rounded(im, rad=28):
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, im.size[0] - 1, im.size[1] - 1], rad, fill=255)
    o = im.copy(); o.putalpha(Image.fromarray((np.array(m).astype(float) * np.array(im.split()[3]) / 255).astype(np.uint8))); return o

M_LAND = Map((33.95, 29.4, 36.15, 33.45), 330, 760, tol=0.003)
M_GAZA = Map((34.05, 31.12, 35.05, 31.68), 860, 560, hl=GAZA, hl_col=BLUE, tol=0.001)
M_WB = Map((34.55, 31.25, 35.75, 32.62), 470, 640, hl=WBANK, hl_col=BLUE, tol=0.001)
M_REG = Map((24.0, 21.5, 41.5, 33.6), 860, 640, tol=0.02, extra_hl=(("Egypt", hx("#2D5C9E")), ("Jordan", hx("#2D5C9E"))))
M_BABY = Map((33.95, 29.4, 36.15, 33.45), 330, 760, hl=unary_union([WBANK, GAZA]), hl_col=BLUE, tol=0.003)
for m in (M_LAND, M_GAZA, M_WB, M_REG, M_BABY): m.im = rounded(m.im)

# ------------------------------------------------------------------ background (motion from frame 0)
_yy = np.linspace(0, 1, H)[:, None, None]
BG = Image.fromarray((np.array(NAVY0)[None, None, :] * (1 - _yy) + np.array(NAVY)[None, None, :] * _yy * np.ones((1, W, 1))).astype(np.uint8), "RGBA")
GLOW = Image.new("RGBA", (900, 900), (0, 0, 0, 0)); ImageDraw.Draw(GLOW).ellipse([150, 150, 750, 750], fill=(42, 136, 212, 70))
GLOW = GLOW.filter(ImageFilter.GaussianBlur(120))
GLOW2 = Image.new("RGBA", (800, 800), (0, 0, 0, 0)); ImageDraw.Draw(GLOW2).ellipse([150, 150, 650, 650], fill=(184, 146, 63, 50))
GLOW2 = GLOW2.filter(ImageFilter.GaussianBlur(110))
rng = np.random.default_rng(7); DOTS = [(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(1.5, 3.5), rng.uniform(8, 22), rng.uniform(0, 6.28)) for _ in range(46)]
def background(t):
    im = BG.copy()
    im.alpha_composite(GLOW, (int(-150 + 260 * math.sin(t * 0.35)), int(250 + 180 * math.cos(t * 0.27))))
    im.alpha_composite(GLOW2, (int(500 + 200 * math.cos(t * 0.31)), int(1000 + 220 * math.sin(t * 0.22))))
    d = ImageDraw.Draw(im, "RGBA")
    for x, y, r, v, ph in DOTS:
        yy = (y - v * t * 2) % H; xx = x + 14 * math.sin(t * 0.6 + ph); a = int(55 + 40 * math.sin(t * 1.3 + ph))
        d.ellipse([xx - r, yy - r, xx + r, yy + r], fill=(201, 210, 222, a))
    return im.convert("RGB")

# ------------------------------------------------------------------ widgets
def card(d, x0, y0, x1, y1, fill=CARD2, edge=GOLD, ew=3, a=1.0, rad=30):
    d.rounded_rectangle([x0, y0, x1, y1], rad, fill=fill[:3] + (int(fill[3] * 0.92 * a),), outline=edge[:3] + (int(255 * a),), width=ew)
def pill(d, x, y, s, sz, fg, bg, a=1.0, anchor="l", pad=(20, 10), w=900, outline=None):
    L = tw(s, sz, w); x0 = x if anchor == "l" else (x - L / 2 - pad[0] if anchor == "m" else x - L - 2 * pad[0])
    d.rounded_rectangle([x0, y, x0 + L + 2 * pad[0], y + sz + 2 * pad[1] + 6], (sz + 2 * pad[1]) // 2, fill=bg[:3] + (int(bg[3] * a),),
                        outline=(outline[:3] + (int(255 * a),)) if outline else None, width=3 if outline else 0)
    text(d, x0 + pad[0], y + pad[1] - sz * 0.1, s, sz, fg, w, a=a, shadow=False)
    return x0 + L + 2 * pad[0]
def opinion(d, t, t0, x=60, y=None, a=1.0):
    """the 'In my view' tag on opinion lines"""
    u = ramp(t, t0, 0.2) * a
    if u > 0: pill(d, x, y, "IN MY VIEW", 34, NAVY, GOLD2, a=u)
def source(d, lines, a=1.0, y=1462):
    for i, l in enumerate(lines):
        assert tw(l, 34, 700) <= 860, ("source too wide", l)
        text(d, 60, y + i * 42, l, 34, SIL2, 700, a=a, shadow=False)
def mark(d, x, y, kind, u, sz=66):
    """animated check / cross / question in a box at (x, y) top-left; u 0..1 draw progress"""
    if u <= 0: return
    col = {"x": RED, "v": GREEN, "?": AMBER}[kind]
    d.rounded_rectangle([x, y, x + sz, y + sz], 14, fill=col[:3] + (int(60 * min(1, u * 2)),), outline=col, width=5)
    lw = 11; p = lambda a_, b_: (x + a_ * sz, y + b_ * sz)
    if kind == "x":
        u1, u2 = clamp(u * 2), clamp(u * 2 - 1)
        a0, b0 = p(0.24, 0.24), p(0.76, 0.76); d.line([a0, (a0[0] + (b0[0] - a0[0]) * u1, a0[1] + (b0[1] - a0[1]) * u1)], fill=col, width=lw)
        if u2 > 0:
            a1, b1 = p(0.76, 0.24), p(0.24, 0.76); d.line([a1, (a1[0] + (b1[0] - a1[0]) * u2, a1[1] + (b1[1] - a1[1]) * u2)], fill=col, width=lw)
    elif kind == "v":
        pts = [p(0.2, 0.52), p(0.42, 0.74), p(0.82, 0.28)]; seg = clamp(u * 2); seg2 = clamp(u * 2 - 1)
        d.line([pts[0], (pts[0][0] + (pts[1][0] - pts[0][0]) * seg, pts[0][1] + (pts[1][1] - pts[0][1]) * seg)], fill=col, width=lw)
        if seg2 > 0: d.line([pts[1], (pts[1][0] + (pts[2][0] - pts[1][0]) * seg2, pts[1][1] + (pts[2][1] - pts[1][1]) * seg2)], fill=col, width=lw)
    else:
        text(d, x + sz / 2, y + sz / 2 + 2, "?", int(sz * 0.8 * eob(u)), col, 900, anchor="mm", shadow=False)
TEST = ["Takes a foreign land", "Takes its riches", "Ships them home"]
def checklist(d, t, y0, marks, a=1.0, title="THE COLONIZER TEST", rows=(0, 1, 2)):
    """marks: {row: (kind, t_mark, note)}; rows 58 px, boxes 66 px"""
    card(d, 50, y0, 930, y0 + 70 + 104 * len(rows) + 10, fill=CARD2, edge=SIL2, ew=2, a=a)
    text(d, 84, y0 + 20, title, 34, GOLD2, 900, a=a, shadow=False)
    for k, r in enumerate(rows):
        y = y0 + 72 + k * 104
        d.rounded_rectangle([80, y, 146, y + 66], 14, outline=SIL2[:3] + (int(200 * a),), width=4)
        m = marks.get(r)
        if m:
            kind, tm, note = m; u = clamp((t - tm) / 0.3)
            if u > 0: mark(d, 80, y, kind, u * a)
            text(d, 172, y - 6, TEST[r], 58, WHITE, 800, a=a, maxw=730)
            if note and t >= tm: text(d, 172, y + 54, note, 36, SILVER, 700, a=a * ramp(t, tm, 0.25), maxw=730, shadow=False)
        else:
            text(d, 172, y - 6, TEST[r], 58, WHITE, 800, a=a, maxw=730)
def stamp(im, lines, t, t0, sz, col=WHITE, edge=GOLD, rot=-3.5, cy=760, a=1.0):
    """big stamp block: lines drawn on a layer, rotated, scaled in with overshoot from t0 (fully opaque at t0)"""
    if a <= 0.01: return
    lh = sz * 1.1; wmax = max(tw(l, sz, 900) for l in lines) + 90; hh = lh * len(lines) + 70
    lay = Image.new("RGBA", (int(wmax + 40), int(hh + 40)), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([20, 20, 20 + wmax, 20 + hh], 26, outline=edge, width=9, fill=(12, 28, 56, 150))
    for i, l in enumerate(lines): text(d, 20 + wmax / 2, 20 + 35 + i * lh + sz * 0.05, l, sz, col, 900, anchor="ma")
    u = clamp((t - t0) / 0.28); sc = 1.32 - 0.32 * eob(u) + 0.012 * math.sin(t * 2.6)
    lay = lay.rotate(rot, resample=Image.BICUBIC, expand=True)
    lay = lay.resize((max(1, int(lay.width * sc)), max(1, int(lay.height * sc))), Image.BICUBIC)
    if a < 1: lay.putalpha(Image.fromarray((np.array(lay.split()[3]).astype(float) * a).astype(np.uint8)))
    im.paste(lay, (int(W / 2 - 70 - lay.width / 2), int(cy - lay.height / 2)), lay)
def paste(im, src, x, y, a=1.0, dy=0.0):
    if a <= 0.01: return
    s = src if a >= 0.999 else src.copy()
    if a < 0.999: s.putalpha(Image.fromarray((np.array(src.split()[3]).astype(float) * a).astype(np.uint8)))
    im.paste(s, (int(x), int(y + dy)), s)
def magnifier(d, x, y, r, a=1.0, col=GOLD2):
    d.ellipse([x - r, y - r, x + r, y + r], outline=col[:3] + (int(255 * a),), width=10)
    d.line([x + r * 0.7, y + r * 0.7, x + r * 1.6, y + r * 1.6], fill=col[:3] + (int(255 * a),), width=16)
def bar(d, x, y, wmax, val, vmax, u, col, label, vtxt, a=1.0):
    w = max(8, wmax * (val / vmax) * ease(u))
    text(d, x, y - 4, label, 44, WHITE, 800, a=a)
    d.rounded_rectangle([x, y + 56, x + w, y + 112], 14, fill=col[:3] + (int(255 * a),))
    text(d, x + w + 16 if w < wmax - 250 else x + w - 16, y + 60, vtxt, 46, WHITE if w >= wmax - 250 else GOLD2, 900,
         anchor="la" if w < wmax - 250 else "ra", a=a * clamp(u * 3))
def arrow(d, p0, p1, u, col, wdt=9, a=1.0):
    if u <= 0: return
    x = p0[0] + (p1[0] - p0[0]) * u; y = p0[1] + (p1[1] - p0[1]) * u; c = col[:3] + (int(255 * a),)
    d.line([p0, (x, y)], fill=c, width=wdt)
    ang = math.atan2(y - p0[1], x - p0[0]); L = 26
    d.polygon([(x, y), (x - L * math.cos(ang - 0.45), y - L * math.sin(ang - 0.45)), (x - L * math.cos(ang + 0.45), y - L * math.sin(ang + 0.45))], fill=c)

# ------------------------------------------------------------------ section windows
def SW(li): return LS(li) - 0.15
T = dict(hook=0.0, defn=SW(2), isr=SW(3), gaza=SW(4), q=SW(8), hamas=SW(9), wb=SW(10), nb=SW(12), money=SW(13), say=SW(14),
         rev=SW(15), baby=SW(16), fair=SW(17), cta=SW(19), end=SW(20))
ORDER = ["hook", "defn", "isr", "gaza", "q", "hamas", "wb", "nb", "say", "rev", "baby", "fair", "cta", "end"]
def span(k):
    i = ORDER.index(k); return T[k], (T[ORDER[i + 1]] if i + 1 < len(ORDER) else T_END + 1)
STAMPS = [0.0, T["rev"] + 0.0, T["end"]]; POPS = []; WHOOSH = [T[k] for k in ORDER[1:] if k not in ("q", "end")]
GAZA_M = {0: ("?", WT(5, "holds"), "Left in 2005. Back in part since the war."),
          1: ("x", WT(6, "person", end=True) - 0.3, "About $1,257 a person, 2022"),
          2: ("x", WT(7, "wage") - 0.2, "Money flows in: about 4x the Gaza wage")}
WB_M = {0: ("?", LS(10) + 0.3, "Settlements: a real debate"),
        1: ("x", WT(10, "person", end=True) - 0.3, "About $4,458 a person, 2022"),
        2: ("x", WT(11, "pay") - 0.3, "Money flows in: more than 2x the pay")}
POPS += [GAZA_M[k][1] for k in GAZA_M] + [WB_M[k][1] for k in WB_M] + [WT(3, "here")]

# ------------------------------------------------------------------ frame
def frame(t):
    im = background(t); d = ImageDraw.Draw(im, "RGBA")
    def A(k, fi=0.22, fo=0.22): a, b = span(k); return win(t, a, b, fi, fo)
    # header chip after the hook
    if t >= T["defn"] - 0.2:
        pill(d, 60, 214, "IS ISRAEL A COLONIZER?", 34, GOLD2, CARD2, a=ramp(t, T["defn"] - 0.2) * (1 - ramp(t, T["end"] - 0.25)), outline=GOLD)
    # hook: stamp, then "Let's check."
    a = A("hook", fi=0.001)
    if a > 0:
        stamp(im, ["Israel is", "a colonizer."], t, 0.0, 108, cy=700, a=a)
        u = ramp(t, LS(1) - 0.05, 0.25)
        if u > 0:
            d = ImageDraw.Draw(im, "RGBA"); text(d, W / 2 - 60 + 50, 1020 + 40 * (1 - u), "Let's check.", 96, GOLD2, 900, anchor="ma", a=a * u)
            magnifier(d, W / 2 - 60 - 310, 1080 + 40 * (1 - u), 40, a=a * u)
        text(d, W / 2 - 50, 1300, "An opinion reel by @noamroz__", 38, SIL2, 700, anchor="ma", a=a, shadow=False)
    # definition
    a = A("defn")
    if a > 0:
        dy = 30 * (1 - ramp(t, T["defn"]))
        card(d, 50, 300 + dy, 930, 860 + dy, fill=CARD, edge=GOLD, ew=4, a=a)
        text(d, 90, 334 + dy, "colonialism", 72, GOLD2, 900, a=a); text(d, 90 + tw("colonialism", 72, 900) + 22, 360 + dy, "(noun)", 40, SIL2, 700, a=a)
        para(d, 90, 450 + dy, "“Domination of a people or area by a foreign state or nation.”", 64, WHITE, 800, maxw=800, a=a)
        text(d, 90, 780 + dy, "Merriam-Webster dictionary", 36, SIL2, 700, a=a, shadow=False)
        mk = {0: ("?", WT(2, "foreign"), None), 1: ("?", WT(2, "riches"), None), 2: ("?", WT(2, "home"), None)}
        # rows appear on their words (no marks yet: empty boxes)
        card(d, 50, 900, 930, 900 + 70 + 118 * 3 + 10, fill=CARD2, edge=SIL2, ew=2, a=a)
        text(d, 84, 920, "THE COLONIZER TEST", 34, GOLD2, 900, a=a, shadow=False)
        for r in range(3):
            u = ramp(t, mk[r][1] - 0.1, 0.2) * a; y = 972 + r * 118
            if u > 0:
                d.rounded_rectangle([80, y, 146, y + 66], 14, outline=SIL2[:3] + (int(220 * u),), width=4)
                text(d, 172 + 30 * (1 - u), y - 6, TEST[r], 58, WHITE, 800, a=u)
        source(d, ["Definition: Merriam-Webster, “colonialism”, sense 1a."], a=a)
    # Israel
    a = A("isr")
    if a > 0:
        text(d, 60, 300, "Israel?", 92, WHITE, 900, a=a)
        paste(im, M_LAND.im, 60, 430, a=a); d = ImageDraw.Draw(im, "RGBA")
        u1 = ramp(t, WT(3, "jews")); u2 = ramp(t, WT(3, "thousand"))
        card(d, 420, 430, 930, 790, fill=CARD, edge=GOLD, a=a * u1)
        text(d, 450, 450, "About 1209 BCE", 46, GOLD2, 900, a=a * u1); para(d, 450, 508, "An Egyptian stone, the Merneptah Stele, names “Israel”", 40, WHITE, 700, maxw=450, a=a * u1)
        card(d, 420, 820, 930, 1080, fill=CARD, edge=GOLD, a=a * u2)
        text(d, 450, 840, "About 1000 BCE", 46, GOLD2, 900, a=a * u2); para(d, 450, 898, "Jerusalem becomes King David’s capital", 40, WHITE, 700, maxw=450, a=a * u2)
        checklist(d, t, 1210, {0: ("x", WT(3, "here"), None)}, a=a, rows=(0,))
        source(d, ["Britannica, “Israel Stela”. Gold: the land between the", "river and the sea. Green: the 1949 armistice line."], a=a)
    # Gaza
    a = A("gaza")
    if a > 0:
        text(d, 60, 290, "Gaza", 92, WHITE, 900, a=a)
        tA, tB, tC = SW(4), LS(6) - 0.2, LS(7) - 0.2
        am = a * (1 - ramp(t, tB - 0.2, 0.25))
        if am > 0:
            paste(im, M_GAZA.im, 60, 410, a=am); d = ImageDraw.Draw(im, "RGBA")
            gx, gy = M_GAZA.proj(34.38, 31.42); text(d, 60 + gx - 40, 410 + gy - 30, "GAZA", 40, WHITE, 900, anchor="mm", a=am)
            ix, iy = M_GAZA.proj(34.80, 31.58); text(d, 60 + ix, 410 + iy, "ISRAEL", 36, NAVY, 900, anchor="mm", a=am, shadow=False)
            u = ramp(t, WT(4, "two"))
            card(d, 80, 800, 900, 958, fill=CARD, edge=GOLD, a=am * u)
            text(d, 104, 812, "2005: Israel left Gaza.", 52, GOLD2, 900, a=am * u); text(d, 104, 878, "21 settlements, about 8,000 settlers, every soldier.", 36, WHITE, 700, a=am * u, maxw=780)
            u2 = ramp(t, LS(5))
            if u2 > 0:
                card(d, 80, 700 - 10, 900, 790, fill=hx("#3A2A10"), edge=AMBER, a=am * u2)
                text(d, 104, 700, "Since the war: the army holds about 60%", 44, AMBER, 900, a=am * u2, maxw=780)
        ab = a * ramp(t, tB - 0.1)
        if ab > 0:
            dy = 30 * (1 - ramp(t, tB - 0.1))
            text(d, 60, 420 + dy, "GDP per person, 2022", 44, SIL2, 800, a=ab)
            bar(d, 60, 490 + dy, 760, 1257, 54947, ramp(t, WT(6, "twelve") - 0.1, 0.6), BLUE, "Gaza", "$1,257", a=ab)
            bar(d, 60, 650 + dy, 760, 54947, 54947, ramp(t, WT(6, "person") - 0.3, 0.6), GOLD, "Israel", "$54,947", a=ab)
            uc = ramp(t, tC)
            if uc > 0:
                card(d, 60, 820, 920, 1020, fill=CARD, edge=GREEN, a=ab * uc)
                text(d, 90, 836, "about 4x", 96, GREEN, 900, a=ab * uc)
                para(d, 470, 846, "Gazans with Israeli permits vs the average Gaza wage", 38, WHITE, 700, maxw=430, a=ab * uc)
        checklist(d, t, 1050, GAZA_M, a=a)
        srcs = ["IDF area: Israel, May 2026 (60%). UN OCHA, Oct 2026:", "about 65% of Gaza under Israeli restrictions."]
        if t >= tB: srcs = ["GDP per person: PCBS 2022 (2015 prices), World Bank.", "Wages: INSS 2022, NIS 6,350 vs 1,600 a month."]
        source(d, srcs, a=a)
    # "That's colonizing?"
    a = A("q", fi=0.12)
    if a > 0:
        d.rectangle([0, 0, W, H], fill=(8, 18, 38, int(160 * a)))
        stamp(im, ["That’s", "colonizing?"], t, T["q"] + 0.05, 112, edge=BLUE, rot=2.5, cy=800, a=a); d = ImageDraw.Draw(im, "RGBA")
    # Hamas / social services
    a = A("hamas")
    if a > 0:
        opinion(d, t, T["hamas"], y=300, a=a)
        para(d, 60, 390, "Hamas fails its own people.", 84, WHITE, 900, maxw=860, a=a)
        u = ramp(t, WT(9, "someone") - 0.1)
        if u > 0:
            dy = 40 * (1 - u)
            card(d, 60, 640 + dy, 920, 1290 + dy, fill=hx("#F4F5F7"), edge=BLUE, ew=5, a=a * u)
            d.rounded_rectangle([60, 640 + dy, 920, 740 + dy], 30, fill=BLUE[:3] + (int(255 * a * u),))
            text(d, 100, 662 + dy, "SOCIAL SERVICES", 52, WHITE, 900, a=a * u, shadow=False)
            text(d, 100, 780 + dy, "Case file", 40, hx("#5B6B82"), 800, a=a * u, shadow=False)
            text(d, 100, 840 + dy, "Guardian: Hamas", 60, NAVY, 900, a=a * u, shadow=False)
            text(d, 100, 930 + dy, "Status: failing the kids", 56, hx("#B03040"), 900, a=a * u, shadow=False, maxw=780)
            text(d, 100, 1020 + dy, "Who keeps babysitting? Israel.", 48, NAVY, 800, a=a * u * ramp(t, WT(9, "hamas", occ=1) - 0.2), shadow=False, maxw=780)
            us = ramp(t, WT(9, "hamas", occ=1), 0.18)
            if us > 0:
                lay = Image.new("RGBA", (420, 150), (0, 0, 0, 0)); dl = ImageDraw.Draw(lay)
                dl.rounded_rectangle([6, 6, 414, 144], 20, outline=RED, width=8); text(dl, 210, 75, "OVERDUE", 74, RED, 900, anchor="mm", shadow=False)
                lay = lay.rotate(-9, expand=True, resample=Image.BICUBIC); sc = 1.3 - 0.3 * eob(us)
                lay = lay.resize((int(lay.width * sc), int(lay.height * sc)))
                paste(im, lay, 560 - lay.width / 2, 1180 - lay.height / 2 + dy, a=a * us); d = ImageDraw.Draw(im, "RGBA")
        source(d, ["Satire. The joke is on Hamas, not on the people of Gaza."], a=a)
    # West Bank
    a = A("wb")
    if a > 0:
        text(d, 60, 286, "Judea and Samaria", 84, WHITE, 900, a=a, maxw=860); text(d, 60, 384, "(the West Bank)", 44, SIL2, 700, a=a)
        paste(im, M_WB.im, 60, 460, a=a * (1 - 0.0)); d = ImageDraw.Draw(im, "RGBA")
        u1 = ramp(t, WT(10, "forty-five") - 0.1 if any(norm(w["w"]) == "fortyfive" for w in LW[10]) else LS(10) + 1.0)
        card(d, 560, 460, 930, 700, fill=CARD, edge=GOLD, a=a * u1)
        text(d, 745, 478, "GDP per person", 36, SIL2, 800, anchor="ma", a=a * u1)
        text(d, 745, 530, "$4,458", 92, GOLD2, 900, anchor="ma", a=a * u1); text(d, 745, 640, "2022. Israel: $54,947", 30, SILVER, 700, anchor="ma", a=a * u1, shadow=False)
        u2 = ramp(t, LS(11))
        card(d, 560, 720, 930, 1100, fill=CARD, edge=GREEN, a=a * u2)
        n = int(170000 * ease(clamp((t - LS(11)) / 1.0)))
        text(d, 745, 736, f"{n:,}", 78, GREEN, 900, anchor="ma", a=a * u2)
        para(d, 745, 836, "worked in Israel and the settlements", 34, WHITE, 700, maxw=330, anchor="ma", a=a * u2)
        u3 = ramp(t, WT(11, "double") - 0.2)
        text(d, 745, 960, "NIS 289 a day", 40, GOLD2, 900, anchor="ma", a=a * u3); text(d, 745, 1010, "vs about 125 at home", 34, SILVER, 700, anchor="ma", a=a * u3)
        checklist(d, t, 1120, WB_M, a=a, rows=(1, 2), title="THE COLONIZER TEST")
        srcs = ["GDP per person: PCBS via MAS, 2022 (2015 prices).", "Jobs, pay: PCBS labour survey, Q2 and Q3 2023."]
        source(d, srcs, a=a)
    # neighbours (gas, water) and "where's the money going?"
    a = A("nb")
    if a > 0:
        text(d, 60, 290, "The neighbors?", 84, WHITE, 900, a=a)
        am = a * (1 - 0.55 * ramp(t, LS(13) - 0.1))
        paste(im, M_REG.im, 60, 410, a=am); d = ImageDraw.Draw(im, "RGBA")
        P = lambda lon, lat: (60 + M_REG.proj(lon, lat)[0], 410 + M_REG.proj(lon, lat)[1])
        for nm, ll in (("EGYPT", (29.6, 26.4)), ("JORDAN", (37.2, 30.6)), ("SYRIA", (38.6, 34.6)), ("LEBANON", (35.4, 33.2))):
            if ll[1] < 33.5: text(d, *P(*ll), nm, 36 if nm in ("EGYPT", "JORDAN") else 28, WHITE if nm in ("EGYPT", "JORDAN") else SIL2, 900, anchor="mm", a=am)
        src = P(34.6, 32.2)
        ug = ramp(t, WT(12, "gas") - 0.5, 0.7); uw = ramp(t, WT(12, "water") - 0.45, 0.6)
        arrow(d, src, P(31.0, 30.2), ug, GOLD2, 10, a=am); arrow(d, src, P(36.6, 31.6), ug, GOLD2, 10, a=am)
        arrow(d, P(35.3, 32.6), P(36.6, 32.3), uw, hx("#64D2FF"), 10, a=am)
        if ug > 0: text(d, *P(31.2, 31.9), "GAS", 44, GOLD2, 900, anchor="mm", a=am * ug)
        if uw > 0: text(d, *P(38.0, 32.95), "WATER", 40, hx("#64D2FF"), 900, anchor="mm", a=am * uw)
        u = ramp(t, WT(12, "gas") - 0.3)
        card(d, 60, 1070, 920, 1330, fill=CARD, edge=GOLD, a=a * u)
        text(d, 90, 1090, "Egypt and Jordan buy Israeli gas.", 48, WHITE, 900, a=a * u, maxw=800)
        text(d, 90, 1160, "13.1 billion cubic meters in 2024", 40, GOLD2, 800, a=a * u, maxw=800)
        text(d, 90, 1240, "Jordan gets Israeli water (1994 treaty).", 40, hx("#64D2FF"), 800, a=a * uw, maxw=800)
        uq = ramp(t, LS(13) - 0.1)
        if uq > 0: stamp(im, ["So where’s the", "money going?"], t, LS(13) - 0.1, 86, edge=GOLD, rot=-2.0, cy=740, a=a * uq); d = ImageDraw.Draw(im, "RGBA")
        source(d, ["Gas: Israel Energy Ministry via Enerdata. Water: INSS.", "Golan: captured 1967, annexed 1981, disputed."], a=a)
    # "colonize, colonize, colonize. No clue what it means."
    a = A("say")
    if a > 0:
        text(d, 60, 300, "People say:", 72, SIL2, 800, a=a)
        cols = [(120, 470, -6), (330, 680, 4), (150, 890, -3)]
        for k in range(3):
            tk = WT(14, "colonize", occ=k) - 0.05; u = clamp((t - tk) / 0.25)
            if u > 0:
                x, y, r = cols[k]; lay = Image.new("RGBA", (720, 170), (0, 0, 0, 0)); dl = ImageDraw.Draw(lay)
                dl.rounded_rectangle([5, 5, 715, 165], 80, fill=hx("#F4F5F7"), outline=GOLD, width=5)
                text(dl, 360, 85, "“Colonize!”", 84, NAVY, 900, anchor="mm", shadow=False)
                lay = lay.rotate(r, expand=True, resample=Image.BICUBIC); sc = 0.6 + 0.4 * eob(u); lay = lay.resize((int(lay.width * sc), int(lay.height * sc)))
                paste(im, lay, x + 360 - lay.width / 2 - 60, y + 85 - lay.height / 2, a=a)
        d = ImageDraw.Draw(im, "RGBA"); u = ramp(t, WT(14, "clue") - 0.15)
        if u > 0:
            text(d, 60, 1150 + 30 * (1 - u), "No clue what it means.", 78, GOLD2, 900, a=a * u, maxw=860)
            text(d, 60, 1260, "Remember: a foreign land, its riches, shipped home.", 38, SILVER, 700, a=a * u, maxw=860)
    # REVEAL: new verb, babysitting
    a = A("rev", fi=0.12)
    if a > 0:
        u = ramp(t, WT(15, "verb") - 0.25, 0.2)
        text(d, W / 2 - 50, 470, "New verb:", 88, SIL2, 900, anchor="ma", a=a * u)
        tb = WT(15, "babysitting") - 0.06
        if t >= tb: stamp(im, ["BABYSITTING"], t, tb, 116, col=GOLD2, edge=GOLD, rot=-3.0, cy=760, a=a); d = ImageDraw.Draw(im, "RGBA")
        ud = ramp(t, tb + 0.35)
        card(d, 60, 960, 920, 1300, fill=CARD, edge=SIL2, ew=2, a=a * ud)
        text(d, 90, 984, "babysit", 64, GOLD2, 900, a=a * ud); text(d, 90 + tw("babysit", 64, 900) + 20, 1006, "(verb, Noam’s dictionary)", 36, SIL2, 700, a=a * ud)
        para(d, 90, 1080, "To look after someone whose own guardian won’t.", 52, WHITE, 800, maxw=800, a=a * ud)
        opinion(d, t, tb + 0.35, y=1330, a=a)
    # Israel babysits Judea and Samaria, and sometimes Gaza
    a = A("baby")
    if a > 0:
        opinion(d, t, T["baby"], y=290, a=a)
        para(d, 60, 370, "Israel babysits Judea and Samaria.", 70, WHITE, 900, maxw=860, a=a)
        u2 = ramp(t, WT(16, "sometimes") - 0.1)
        text(d, 60, 548, "And sometimes, Gaza.", 70, GOLD2, 900, a=a * u2)
        paste(im, M_BABY.im, 80, 670, a=a); d = ImageDraw.Draw(im, "RGBA")
        wx, wy = M_BABY.proj(35.25, 31.95); gx, gy = M_BABY.proj(34.42, 31.42)
        u1 = ramp(t, WT(16, "babysits") - 0.05)
        pill(d, 80 + wx + 70, 670 + wy - 40, "BABYSITS", 40, NAVY, GOLD2, a=a * u1)
        d.line([80 + wx + 8, 670 + wy, 80 + wx + 70, 670 + wy - 8], fill=GOLD2[:3] + (int(255 * a * u1),), width=5)
        pill(d, 80 + gx + 120, 670 + gy + 30, "SOMETIMES", 40, NAVY, hx("#64D2FF"), a=a * u2)
        d.line([80 + gx + 6, 670 + gy + 4, 80 + gx + 120, 670 + gy + 50], fill=hx("#64D2FF")[:3] + (int(255 * a * u2),), width=5)
        source(d, ["Blue: Judea and Samaria (West Bank) and Gaza.", "Green: the 1949 armistice line."], a=a)
    # the other side, fairly
    a = A("fair")
    if a > 0:
        card(d, 50, 300, 930, 800, fill=CARD, edge=SIL2, ew=3, a=a)
        text(d, 90, 330, "To be fair:", 64, GOLD2, 900, a=a)
        para(d, 90, 420, "Palestinians and much of the world call it occupation.", 60, WHITE, 900, maxw=800, a=a)
        text(d, 90, 690, "Settlements are a real debate.", 52, SILVER, 800, a=a * ramp(t, WT(17, "occupation") - 0.1), maxw=800)
        u = ramp(t, LS(18) - 0.1)
        if u > 0:
            para(d, 60, 880 + 20 * (1 - u), "But colonizing means something specific.", 76, WHITE, 900, maxw=860, a=a * u)
        u3 = ramp(t, WT(18, "specific") - 0.1)
        if u3 > 0:
            card(d, 50, 1100, 930, 1250, fill=CARD2, edge=GOLD, a=a * u3)
            text(d, 80, 1118, "Want to say colonize?", 50, SILVER, 800, a=a * u3); text(d, 80, 1178, "Say babysits.", 56, GOLD2, 900, a=a * u3)
        source(d, ["UN and the ICJ (advisory opinion, July 2024) call it", "an occupation and say Israel’s presence is unlawful."], a=a)
    # CTA
    a = A("cta")
    if a > 0:
        text(d, W / 2 - 50, 420, "Comment", 84, WHITE, 900, anchor="ma", a=a)
        u = ramp(t, WT(19, "babysitting") - 0.08, 0.2); sc = 0.7 + 0.3 * eob(u)
        if u > 0:
            sz = int(96 * sc); pill(d, W / 2 - 50, 560, "BABYSITTING", sz, NAVY, GOLD2, a=a * clamp(u * 2), anchor="m", pad=(36, 18))
        u2 = ramp(t, WT(19, "agree") - 0.15)
        para(d, W / 2 - 50, 780, "if you agree that Israel babysits all these places.", 62, WHITE, 800, maxw=820, anchor="ma", a=a * u2)
        text(d, W / 2 - 50, 1100, "Follow @noamroz__", 44, SIL2, 800, anchor="ma", a=a * u2, shadow=False)
    # END: loop back to the hook
    a = A("end", fi=0.12, fo=0.001)
    if a > 0:
        stamp(im, ["So... is Israel", "a colonizer?"], t, T["end"], 100, cy=760, a=a); d = ImageDraw.Draw(im, "RGBA")
    return im

# ------------------------------------------------------------------ checks and output
_txt_all = []
reveal = T["rev"]
print(f"T_END {T_END}  reveal {reveal:.2f} ({100 * reveal / T_END:.0f}%)  end card hold {T_END - VO_END:.2f} s")
if A.snaps:
    os.makedirs(f"{D}/work/snaps", exist_ok=True)
    for s in A.snaps.split(","):
        frame(float(s)).save(f"{D}/work/snaps/s_{float(s):05.2f}.png")
    print("snaps", A.snaps); sys.exit()
if A.silent:
    out = f"{D}/work/silent.mp4"
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    for i in range(N):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0
    json.dump(dict(T_END=T_END, reveal=reveal, stamps=STAMPS, pops=POPS, whoosh=WHOOSH, drawn=sorted(DRAWN)), open(f"{D}/work/render.json", "w"), indent=1)
    print("silent", out)
