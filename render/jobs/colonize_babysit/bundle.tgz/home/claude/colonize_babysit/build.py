"""cloud step: silent video (engine.py) + work/mix.m4a -> colonize_babysit.mp4"""
import subprocess, os, json
D = "/home/claude/colonize_babysit"
subprocess.run(["nice", "-n", "10", "python3", f"{D}/engine.py", "--silent"], check=True)
T = json.load(open(f"{D}/work/render.json"))["T_END"]
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", f"{D}/work/silent.mp4", "-i", f"{D}/work/mix.m4a", "-map", "0:v", "-map", "1:a",
                "-c", "copy", "-t", f"{T:.2f}", "-movflags", "+faststart", f"{D}/colonize_babysit.mp4"], check=True)
os.remove(f"{D}/work/silent.mp4"); print("final", f"{D}/colonize_babysit.mp4")
