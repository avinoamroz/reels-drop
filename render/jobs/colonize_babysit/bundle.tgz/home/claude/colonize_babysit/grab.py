"""grab.py <download_json_or_raw> [name]: Drive download (base64 JSON or raw SSE) -> clips/<name>.wav + _words.json, then delete the download"""
import json, base64, sys, os, subprocess
src = sys.argv[1]; D = "/home/claude/colonize_babysit"; SC = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/colonize_babysit"
raw = open(src, "rb").read()
try:
    d = json.loads(raw); name = sys.argv[2] if len(sys.argv) > 2 else d["title"].replace("cb_", "").replace(".txt", ""); tmp = src
except Exception:
    name = sys.argv[2]; tmp = f"{SC}/wrap_{name}.json"; json.dump({"content": base64.b64encode(raw).decode()}, open(tmp, "w"))
r = subprocess.run(["python3", "/home/claude/tts_api/sse_parse.py", tmp, f"{D}/clips/{name}"], capture_output=True, text=True)
print(name, r.stdout.strip(), r.stderr.strip()[-200:])
if r.returncode == 0 and os.path.getsize(f"{D}/clips/{name}.wav") > 20000:
    os.remove(src)
    if tmp != src: os.remove(tmp)
