"""trim each Cartesia line clip, squeeze long internal pauses, stitch with short gaps -> vo_raw.wav (44.1 kHz mono) + spans.json"""
import numpy as np, soundfile as sf, json
D = "/home/claude/colonize_babysit"; SR = 44100
CLIPS = [f"l{i:02d}" for i in range(22) if i != 19]   # l19 "Want to say colonize? Say babysits." is on screen only (length)
# gap AFTER clip index i of CLIPS (21 clips: index 18 is l18, 19 is l20 CTA, 20 is l21 loop)
GAP = {0: 0.26, 1: 0.26, 2: 0.26, 3: 0.28, 4: 0.16, 5: 0.26, 6: 0.16, 7: 0.20, 8: 0.26, 9: 0.30, 10: 0.18, 11: 0.26, 12: 0.20,
       13: 0.30, 14: 0.28, 15: 0.28, 16: 0.30, 17: 0.14, 18: 0.34, 19: 0.36}
def squeeze(y, keep=0.22, minp=0.26):
    hop = 441; n = len(y) // hop; L = 10 * np.log10((y[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); low = L < L.max() - 40
    segs = []; i = 0
    while i < n:
        if low[i]:
            j = i
            while j < n and low[j]: j += 1
            if (j - i) * 0.01 > minp and i > 0 and j < n: segs.append((i, j))
            i = j
        else: i += 1
    keepf = int(keep * 100); res = []; prev = 0
    for i, j in segs:
        h = keepf // 2; res.append(y[prev * hop:(i + h) * hop]); prev = j - (keepf - h)
    res.append(y[prev * hop:]); return np.concatenate(res), [round((j - i) / 100, 2) for i, j in segs]
def load(c):
    for nm in (f"{D}/clips/{c}_fix.wav", f"{D}/clips/{c}.wav"):
        try: x, sr = sf.read(nm); return x.astype(np.float64)
        except Exception: pass
out = []; spans = []
for i, c in enumerate(CLIPS):
    x = load(c); hop = 441; n = len(x) // hop
    L = 10 * np.log10((x[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12); thr = L.max() - 45
    on = np.where(L > thr)[0]; a = max(0, on[0] - 3) * hop; b = min(len(x), (on[-1] + 6) * hop)
    y, sq = squeeze(x[a:b]); f = int(0.008 * SR); y[:f] *= np.linspace(0, 1, f); y[-f:] *= np.linspace(1, 0, f)
    t0 = sum(len(z) for z in out) / SR; out.append(y); spans.append((round(t0, 3), round(t0 + len(y) / SR, 3)))
    if sq: print(c, "squeezed", sq)
    if i in GAP: out.append(np.zeros(int(GAP[i] * SR)))
out.append(np.zeros(int(0.4 * SR))); v = np.concatenate(out); sf.write(f"{D}/vo_raw.wav", v.astype(np.float32), SR)
json.dump(spans, open(f"{D}/spans_raw.json", "w")); print("total", round(len(v) / SR, 2), "after 1.14x:", round(len(v) / SR / 1.14 + 0.3, 2))
