"""body.py N [text]: print the Cartesia SSE body for line N of tts.txt (or a retake text)."""
import json, sys
L = [l.strip() for l in open("/home/claude/colonize_babysit/tts.txt") if l.strip()]
n = int(sys.argv[1]); t = sys.argv[2] if len(sys.argv) > 2 else L[n]
print(json.dumps({"model_id": "sonic-3", "transcript": t, "voice": {"mode": "id", "id": "cd06f613-0c92-4347-9b94-b34cb4a0239f"},
  "output_format": {"container": "raw", "encoding": "pcm_s16le", "sample_rate": 44100}, "add_timestamps": True, "language": "en",
  "generation_config": {"speed": 1.1}}))
