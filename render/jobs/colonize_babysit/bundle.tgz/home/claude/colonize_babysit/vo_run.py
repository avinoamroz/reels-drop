"""house voice chain + ASR restore (v5lib.process) at atempo 1.14 -> work/vo.wav, work/words.json"""
import sys; sys.path.insert(0, "/home/claude/rehook"); import v5lib
v5lib.TEMPO = 1.14
D = "/home/claude/colonize_babysit"
lines = [l.strip() for l in open(f"{D}/spoken.txt") if l.strip()]
v5lib.process(f"{D}/vo_raw.wav", lines, f"{D}/work", log=lambda s: print(s, flush=True))
