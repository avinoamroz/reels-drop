"""BUILDING A COUNTRY (@noamroz__, pilot 31 Oct 2026): one scene module for the whole daily series.
Look (borrowed format from @thejakeabdo's "90 DAYS OF GAME"): near-black navy, small spaced-caps series tag at the top,
ONE huge condensed word, a small-caps subtitle, and a line-drawn gold animation standing on a thin horizon line.
House colours: navy-black bg, white titles, gold #B8923F accents, blue #2A88D4 sparingly, silver small text.
Loop: scene 0 ("title") and the last scene ("title", loop) draw the same frame; every ambient motion is periodic over the
reel (ph()), so the last frame matches frame 0. Key text stays in y 220..1590. Sources 34 px at the bottom of the safe area.
Spec keys used: spec["series"] = {"tag": "...", "year": "1948"}; scenes: title, beat, map, counter, stats.
Fonts: Anton (title words, numbers) and Oswald (tags, small caps), OFL, from @fontsource on npm, in ./fonts."""
import math, random, json
import cairo
from PIL import Image, ImageDraw, ImageFont
import render as RD, mix as MX, kit
from kit import ease, ramp, lerp, St, sa, rr, circ, box, hx, pil2cairo

RD.draw_subs = lambda c, t, items: None
FD = "/home/claude/series_country/fonts"
F_ANTON = FD + "/Anton-Regular.ttf"; F_OSW = FD + "/Oswald-500.ttf"; F_OSWB = FD + "/Oswald-700.ttf"
L, R = 60, 1020; CX = 540; CW = R - L
G = {"T": 50.0, "spec": {}}
HOR = 1440                       # horizon line y
SRC_Y = (1508, 1550)
BG0 = hx("#060E20"); BG1 = hx("#0B1730"); NAVY = hx("#163260")
GOLD = hx("#B8923F"); GOLD_L = hx("#E2C47A"); BLUE = hx("#2A88D4"); SILV = hx("#B9C0CA"); SIL_D = hx("#7D889A")
WHITE = hx("#FFFFFF"); GREEN = hx("#2FB36E"); RED = hx("#D9534F")
COL = dict(w=WHITE, g=GOLD_L, G=GOLD, b=BLUE, s=SILV, r=RED, n=GREEN)

_draw0 = RD.Reel.draw
def _draw(s, c, t):
    G["T"] = s.T_END; G["spec"] = s.spec; _draw0(s, c, t)
RD.Reel.draw = _draw
def ph(t, cycles): return 2 * math.pi * cycles * t / G["T"]
def tm(S, k, d=None): return S["times"].get(k, d if d is not None else 999)

# ------------------------------------------------------------------ text (Anton / Oswald via PIL, cached)
_fc, _tc = {}, {}
def fnt(path, z):
    k = (path, int(z))
    if k not in _fc: _fc[k] = ImageFont.truetype(path, int(z))
    return _fc[k]
def tw_(s, path, z, track=0.0): return fnt(path, z).getlength(s) + track * z * max(0, len(s) - 1)
def surf_text(s, path, z, col, track=0.0):
    k = (s, path, int(z), col[:3], track)
    if k in _tc: return _tc[k]
    f = fnt(path, z); asc, desc = f.getmetrics(); pad = 8
    W_ = int(tw_(s, path, z, track) + 2 * pad + 2); H_ = int(asc + desc + 2 * pad)
    im = Image.new("RGBA", (W_, H_), (0, 0, 0, 0)); d = ImageDraw.Draw(im); cc = tuple(int(v * 255) for v in col[:3]) + (255,)
    if track:
        x = pad
        for ch in s: d.text((x, pad), ch, font=f, fill=cc); x += f.getlength(ch) + track * z
    else: d.text((pad, pad), s, font=f, fill=cc)
    bb = im.getbbox() or (0, 0, W_, H_)
    _tc[k] = (pil2cairo(im), W_, H_, pad, asc, bb); return _tc[k]
def TX(c, s, path, z, x, y, col, a=1.0, sc=1.0, track=0.0, anchor="c", maxw=CW, src=False):
    """draw text with its visual (ink) centre at (x, y); shrinks to maxw"""
    s = RD.clean(s)
    if not s: return 0
    while z > 20 and tw_(s, path, z, track) > maxw: z -= 2
    surf, W_, H_, pad, asc, bb = surf_text(s, path, z, col, track)
    inkw = bb[2] - bb[0]; cy = (bb[1] + bb[3]) / 2; cx = (bb[0] + bb[2]) / 2
    if a * St.a > 0.01 and abs(sc) > 1e-3:
        c.save(); c.translate(x, y); c.scale(sc, sc)
        ox = -cx if anchor == "c" else (-bb[0] if anchor == "l" else -bb[2])
        c.set_source_surface(surf, ox, -cy); c.paint_with_alpha(min(1, a * St.a)); c.restore()
    if a * St.a > 0.5: RD.FRAME_TEXT.append(s)
    if a * St.a > 0.6 and abs(sc - 1) < 0.03:
        x0 = x - inkw / 2 if anchor == "c" else (x if anchor == "l" else x - inkw)
        (dx0, dy0), (dx1, dy1) = c.user_to_device(x0, y - (bb[3] - bb[1]) / 2), c.user_to_device(x0 + inkw, y + (bb[3] - bb[1]) / 2)
        kit.QA["text"].append((kit.CUR.get("scene"), s, z, min(dx0, dx1), min(dy0, dy1), max(dx0, dx1), max(dy0, dy1), src))
    return inkw
def fit(s, path, maxz, width, track=0.0):
    z = maxz
    while z > 24 and tw_(s, path, z, track) > width: z -= 2
    return z
def BIG(c, s, y, col=WHITE, a=1.0, sc=1.0, maxz=300, width=CW):
    """one huge Anton line spread across the width (grows to fill, capped at maxz)"""
    z = fit(s, F_ANTON, maxz, width); TX(c, s, F_ANTON, z, CX, y, col, a, sc, maxw=width + 4); return z
def CAPS(c, s, y, col=SILV, a=1.0, sc=1.0, z=46, track=0.16, path=F_OSW, maxw=CW):
    return TX(c, s.upper(), path, z, CX, y, col, a, sc, track=track, maxw=maxw)
def sources(c, t, items):
    cur = None
    for tf, *ls in items:
        if t >= tf - 0.01: cur = (tf, ls)
    if not cur: return
    a = ramp(t, cur[0], cur[0] + 0.3)
    for k, l in enumerate(cur[1]):
        if l: TX(c, l, F_OSW, 34, CX, SRC_Y[k], SIL_D, a, 1.0, track=0.02, maxw=CW, src=True)
def PP(t, t0, S, d=0.45, s0=0.3, bounce=1.6): return RD.PP(t, t0, S, d, s0, bounce)
def fade(t, t0, S, d=0.3): return RD.fade_in(t, t0, S, d)

# ------------------------------------------------------------------ background + persistent series tag + horizon
_bg = {}
def background(c, t):
    if "g" not in _bg:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, 1200, 1200); gc = cairo.Context(s)
        rg = cairo.RadialGradient(600, 600, 0, 600, 600, 600); rg.add_color_stop_rgba(0, *NAVY[:3], 0.9); rg.add_color_stop_rgba(1, *NAVY[:3], 0)
        gc.set_source(rg); gc.paint(); _bg["g"] = s
        Rn = random.Random(5); _bg["st"] = [(Rn.uniform(0, 1080), Rn.uniform(300, HOR - 40), Rn.uniform(1.2, 2.6), Rn.random() * 6.28, Rn.randint(2, 5)) for _ in range(46)]
    g = cairo.LinearGradient(0, 0, 0, 1920); g.add_color_stop_rgb(0, *BG0[:3]); g.add_color_stop_rgb(0.55, *BG1[:3]); g.add_color_stop_rgb(1, *BG0[:3])
    c.set_source(g); c.paint()
    x = 540 + 120 * math.sin(ph(t, 2)); y = 900 + 80 * math.cos(ph(t, 3)); k = 1.15
    c.save(); c.translate(x - 600 * k, y - 600 * k); c.scale(k, k); c.set_source_surface(_bg["g"], 0, 0); c.paint_with_alpha(0.55); c.restore()
    for (sx, sy, r, p, n) in _bg["st"]:                      # faint twinkling dust (periodic)
        tw = 0.5 + 0.5 * math.sin(ph(t, n) + p); sa(c, SILV, 0.08 + 0.18 * tw); c.new_sub_path(); c.arc(sx, sy, r, 0, 2 * math.pi); c.fill()
    # horizon: thin gold line with a soft glow
    for w_, a_ in ((10, 0.05), (4, 0.12), (2, 0.55)):
        sa(c, GOLD, a_); c.set_line_width(w_); c.move_to(40, HOR); c.line_to(1040, HOR); c.stroke()
    # series tag (small spaced caps), the same on every frame
    sp = G["spec"].get("series") or {}
    if sp.get("tag"):
        TX(c, sp["tag"], F_OSW, 34, CX, 262, SILV, 1.0, 1.0, track=0.28, maxw=CW)
        sa(c, GOLD, 0.9); c.rectangle(CX - 40, 300, 80, 4); c.fill()
RD.background = background

# ------------------------------------------------------------------ line-drawn icons (gold strokes, progressive reveal)
def polys_draw(c, polys, prog=1.0, col=GOLD_L, w=7, a=1.0, closed=()):
    """draw polylines up to fraction prog of their total length (the 'drawing' animation)"""
    if a <= 0.01 or prog <= 0: return
    lens = []
    for P in polys: lens.append(sum(math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1]) for i in range(len(P) - 1)))
    tot = sum(lens) or 1; left = tot * min(1, prog)
    sa(c, col, a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for P, Lp in zip(polys, lens):
        if left <= 0: break
        c.move_to(*P[0]); acc = 0
        for i in range(len(P) - 1):
            seg = math.hypot(P[i + 1][0] - P[i][0], P[i + 1][1] - P[i][1])
            if acc + seg <= left: c.line_to(*P[i + 1]); acc += seg
            else:
                u = (left - acc) / max(seg, 1e-6); c.line_to(lerp(P[i][0], P[i + 1][0], u), lerp(P[i][1], P[i + 1][1], u)); acc = left; break
        left -= Lp; c.stroke()
def arcpts(cx, cy, r, a0, a1, n=24): return [(cx + r * math.cos(lerp(a0, a1, i / n)), cy + r * math.sin(lerp(a0, a1, i / n))) for i in range(n + 1)]
def figure(c, x, y, h, t, prog=1.0, col=GOLD_L, a=1.0, walk=0.0, ph0=0.0, wave=False, carry=None, w=None):
    """stick figure, feet at (x, y); walk = stride amount (periodic swing)"""
    s = math.sin(ph(t, 26) + ph0) * walk; hr = h * 0.11; hip = (x, y - h * 0.45); neck = (x, y - h * 0.8)
    head = arcpts(x, y - h * 0.8 - hr, hr, -math.pi / 2, 1.5 * math.pi, 20)
    legs = [[(x + h * 0.16 * s, y), hip, (x - h * 0.16 * s, y)]]
    body = [[hip, neck]]
    if wave: arms = [[(x - h * 0.2, y - h * 0.52), (x, y - h * 0.72), (x + h * 0.18, y - h * 0.95 - h * 0.05 * math.sin(ph(t, 18) + ph0))]]
    else: arms = [[(x - h * 0.14 * s - h * 0.06, y - h * 0.45), (x, y - h * 0.72), (x + h * 0.14 * s + h * 0.06, y - h * 0.45)]]
    polys_draw(c, [head] + body + legs + arms, prog, col, w or max(3, h * 0.045), a)
    if carry == "flag":
        px = x + h * 0.18; top = y - h * 1.35
        polys_draw(c, [[(px, y - h * 0.95 + h * 0.4), (px, top)],
                       [(px, top), (px + h * 0.42, top + h * 0.06 + 6 * math.sin(ph(t, 14) + ph0)), (px + h * 0.4, top + h * 0.3), (px, top + h * 0.26)]],
                   prog, col, w or max(3, h * 0.045), a)
def tent(c, x, y, s, prog, col=GOLD_L, a=1.0):
    polys_draw(c, [[(x - 110 * s, y), (x, y - 120 * s), (x + 110 * s, y)], [(x - 30 * s, y), (x, y - 70 * s), (x + 30 * s, y)],
                   [(x, y - 120 * s), (x - 12 * s, y - 145 * s)]], prog, col, 7 * max(0.7, s), a)
def hut(c, x, y, s, prog, col=GOLD_L, a=1.0):
    P = [[(x - 100 * s, y), (x - 100 * s, y - 90 * s), (x, y - 140 * s), (x + 100 * s, y - 90 * s), (x + 100 * s, y), (x - 100 * s, y)],
         [(x - 25 * s, y), (x - 25 * s, y - 55 * s), (x + 25 * s, y - 55 * s), (x + 25 * s, y)]]
    for k in range(3): P.append([(x - 90 * s + k * 12 * s, y - 92 * s - k * 8 * s), (x - 10 * s, y - 128 * s + k * 0)])
    polys_draw(c, P, prog, col, 6 * max(0.7, s), a)
def ship(c, x, y, s, t, prog, col=GOLD_L, a=1.0):
    bob = 5 * math.sin(ph(t, 10)) * s
    y = y + bob
    P = [[(x - 200 * s, y - 60 * s), (x - 160 * s, y), (x + 160 * s, y), (x + 210 * s, y - 60 * s), (x - 200 * s, y - 60 * s)],
         [(x - 120 * s, y - 60 * s), (x - 120 * s, y - 110 * s), (x + 90 * s, y - 110 * s), (x + 90 * s, y - 60 * s)],
         [(x + 20 * s, y - 110 * s), (x + 20 * s, y - 175 * s), (x + 60 * s, y - 175 * s), (x + 60 * s, y - 110 * s)]]
    for k in range(4): P.append(arcpts(x - 85 * s + k * 50 * s, y - 85 * s, 9 * s, 0, 2 * math.pi, 10))
    polys_draw(c, P, prog, col, 6 * max(0.7, s), a)
    for k in range(3):                                         # smoke puffs drifting (periodic)
        u = (t / G["T"] * 9 + k / 3) % 1.0
        sa(c, SILV, a * 0.5 * (1 - u)); c.set_line_width(4); c.new_sub_path()
        c.arc(x + 40 * s - 60 * u * s, y - 195 * s - 90 * u * s, (14 + 18 * u) * s, 0, 2 * math.pi); c.stroke()
def plane(c, x, y, s, prog, col=GOLD_L, a=1.0, rot=0.0):
    c.save(); c.translate(x, y); c.rotate(rot)
    P = [[(-150 * s, 0), (130 * s, 0), (160 * s, -12 * s), (130 * s, -24 * s), (-150 * s, -24 * s), (-150 * s, 0)],
         [(-10 * s, -12 * s), (-60 * s, 70 * s), (-20 * s, 70 * s), (40 * s, -12 * s)],
         [(-10 * s, -14 * s), (-60 * s, -90 * s), (-20 * s, -90 * s), (40 * s, -14 * s)],
         [(-130 * s, -20 * s), (-165 * s, -60 * s), (-145 * s, -60 * s), (-110 * s, -22 * s)]]
    polys_draw(c, P, prog, col, 6 * max(0.7, s), a); c.restore()
def handshake(c, x, y, s, t, prog, col=GOLD_L, a=1.0):
    k = 6 * math.sin(ph(t, 16)) * s
    P = [[(x - 260 * s, y + 40 * s), (x - 80 * s, y + 10 * s + k), (x - 10 * s, y - 20 * s + k)],
         [(x + 260 * s, y + 40 * s), (x + 80 * s, y + 10 * s + k), (x + 10 * s, y - 20 * s + k)],
         [(x - 60 * s, y - 30 * s + k), (x + 60 * s, y - 30 * s + k), (x + 60 * s, y + 10 * s + k), (x - 60 * s, y + 10 * s + k), (x - 60 * s, y - 30 * s + k)]]
    polys_draw(c, P, prog, col, 7 * s, a)
def pipe(c, y, t, prog, col=GOLD_L, a=1.0):
    P = [[(80, y - 220), (300, y - 220), (380, y - 140), (700, y - 140), (780, y - 60), (1000, y - 60)]]
    polys_draw(c, P, prog, col, 14, a)
    if prog >= 1:                                              # water drops running along (periodic)
        pts = P[0]
        for k in range(6):
            u = (t / G["T"] * 10 + k / 6) % 1.0; i = u * (len(pts) - 1); j = int(i); f = i - j
            px = lerp(pts[j][0], pts[j + 1][0], f); py = lerp(pts[j][1], pts[j + 1][1], f)
            sa(c, BLUE, a); c.new_sub_path(); c.arc(px, py, 7, 0, 2 * math.pi); c.fill()
def graph(c, y, t, prog, col=GOLD_L, a=1.0, kind="spike"):
    if kind == "spike": pts = [(100, y - 40), (260, y - 70), (400, y - 140), (520, y - 330), (600, y - 70), (760, y - 55), (980, y - 50)]
    else: pts = [(100 + k * 110, y) for k in range(8)]
    if kind == "bars":
        P = [[(160 + k * 130, y), (160 + k * 130, y - 50 - k * 38)] for k in range(7)]
        polys_draw(c, P, prog, col, 34, a); return
    polys_draw(c, [pts], prog, col, 8, a)
def bridge(c, y, prog, col=GOLD_L, a=1.0):
    P = [arcpts(540, y + 40, 400, math.pi * 1.08, math.pi * 1.92, 30), [(120, y - 60), (960, y - 60)]]
    for k in range(9): xx = 220 + k * 80; P.append([(xx, y - 60), (xx, y - 60 - 0.0 + (-80 if 2 <= k <= 6 else -40))])
    polys_draw(c, P, prog, col, 6, a)
def arrows5(c, cx, cy, t, prog, col=GOLD_L, a=1.0):
    for k in range(5):
        an = math.pi * (0.95 + k * 0.275); r0 = 330; r1 = 110
        u = ease(prog * 1.25 - k * 0.06)
        if u <= 0: continue
        x0, y0 = cx + r0 * math.cos(an), cy + r0 * math.sin(an); x1 = lerp(x0, cx + r1 * math.cos(an), u); y1 = lerp(y0, cy + r1 * math.sin(an), u)
        polys_draw(c, [[(x0, y0), (x1, y1)], [(x1 + 34 * math.cos(an + 0.5), y1 + 34 * math.sin(an + 0.5)), (x1, y1), (x1 + 34 * math.cos(an - 0.5), y1 + 34 * math.sin(an - 0.5))]], 1.0, RED, 9, a)
def grid100(c, cx, cy, t, prog, hi_k, a=1.0):
    """10 x 10 dots; one turns gold after hi_k"""
    for i in range(100):
        u = ease(prog * 1.4 - i / 140)
        if u <= 0: continue
        x = cx - 234 + (i % 10) * 52; y = cy - 234 + (i // 10) * 52
        hot = i == 44 and hi_k > 0
        sa(c, RED if hot else SILV, a * u * (1 if hot else 0.55)); c.new_sub_path(); c.arc(x, y, 13 + (7 * hi_k if hot else 0), 0, 2 * math.pi); c.fill()
def doc(c, x, y, s, prog, col=GOLD_L, a=1.0):
    P = [[(x - 130 * s, y - 330 * s), (x + 90 * s, y - 330 * s), (x + 130 * s, y - 290 * s), (x + 130 * s, y), (x - 130 * s, y), (x - 130 * s, y - 330 * s)]]
    for k in range(5): P.append([(x - 90 * s, y - 260 * s + k * 50 * s), (x + (90 if k % 2 else 50) * s, y - 260 * s + k * 50 * s)])
    polys_draw(c, P, prog, col, 6 * s, a)
def ballot(c, x, y, s, t, prog, col=GOLD_L, a=1.0):
    P = [[(x - 130 * s, y), (x - 130 * s, y - 170 * s), (x + 130 * s, y - 170 * s), (x + 130 * s, y), (x - 130 * s, y)], [(x - 60 * s, y - 170 * s), (x + 60 * s, y - 170 * s)]]
    polys_draw(c, P, prog, col, 7 * s, a)
    if prog >= 1:
        u = (t / G["T"] * 12) % 1.0; yy = lerp(y - 330 * s, y - 175 * s, ease(min(1, u * 1.6)))
        polys_draw(c, [[(x - 40 * s, yy - 60 * s), (x + 40 * s, yy - 60 * s), (x + 40 * s, yy), (x - 40 * s, yy), (x - 40 * s, yy - 60 * s)]], 1, WHITE, 5 * s, a * (1 - ramp(u, 0.6, 0.62)))
def bowl(c, x, y, s, prog, col=GOLD_L, a=1.0):
    P = [arcpts(x, y - 120 * s, 150 * s, 0, math.pi, 26), [(x - 170 * s, y - 120 * s), (x + 170 * s, y - 120 * s)], [(x - 50 * s, y + 30 * s), (x + 50 * s, y + 30 * s)]]
    polys_draw(c, P, prog, col, 7 * s, a)
def un_ring(c, x, y, s, t, prog, col=GOLD_L, a=1.0):
    P = [arcpts(x, y, 150 * s, 0, 2 * math.pi, 40), arcpts(x, y, 100 * s, 0, 2 * math.pi, 34), [(x - 150 * s, y), (x + 150 * s, y)], [(x, y - 150 * s), (x, y + 150 * s)]]
    for k in range(7):
        an = math.pi * (0.62 + k * 0.12); P.append([(x + 175 * s * math.cos(an), y + 175 * s * math.sin(an)), (x + 205 * s * math.cos(an + 0.1), y + 205 * s * math.sin(an + 0.1))])
        an2 = math.pi - an + 0.0; P.append([(x - 175 * s * math.cos(an), y + 175 * s * math.sin(an)), (x - 205 * s * math.cos(an + 0.1), y + 205 * s * math.sin(an + 0.1))])
    polys_draw(c, P, prog, col, 6 * s, a)

# ------------------------------------------------------------------ the land (Natural Earth 1:50m, public domain)
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"
_geo = {}
def land():
    if not _geo:
        g = json.load(open(GEO))
        for f in g["features"]:
            a3 = f["properties"].get("ADM0_A3")
            if a3 in ("ISR", "PSX"):
                gm = f["geometry"]; polys = gm["coordinates"] if gm["type"] == "MultiPolygon" else [gm["coordinates"]]
                _geo[a3] = [p[0] for p in polys]
    return _geo
def mapP(lon, lat, box_):
    x0, y0, x1, y1 = box_; lo0, lo1, la0, la1 = 34.2, 35.95, 29.45, 33.35
    k = min((x1 - x0) / ((lo1 - lo0) * math.cos(math.radians(31.5))), (y1 - y0) / (la1 - la0))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    return (cx + (lon - (lo0 + lo1) / 2) * math.cos(math.radians(31.5)) * k, cy - (lat - (la0 + la1) / 2) * k)
def draw_land(c, box_, prog, t, a=1.0, green=0.0, fill_g=0.0):
    G_ = land()
    outer = [[mapP(lo, la, box_) for lo, la in ring] for ring in G_["ISR"]]
    psx = [[mapP(lo, la, box_) for lo, la in ring] for ring in G_["PSX"]]
    if fill_g > 0:
        for P in outer + psx:
            c.move_to(*P[0]); [c.line_to(*q) for q in P[1:]]; c.close_path()
        sa(c, GOLD, 0.12 * fill_g * a); c.fill()
    polys_draw(c, outer + psx if green <= 0 else outer, prog, GOLD_L, 5, a)
    if green > 0: polys_draw(c, psx, green, GREEN, 9, a)

# ------------------------------------------------------------------ scenes
def draw_title(c, t, S, a=1.0, s=1.0):
    """the series card: ONE huge word + small caps subtitle + figure on the horizon (frame 0 == last frame)"""
    br = 1 + 0.01 * math.sin(ph(t, 8))
    BIG(c, S["word"], 680, WHITE, a, s * br, maxz=S.get("maxz", 330))
    if S.get("sub"): CAPS(c, S["sub"], 900, GOLD_L, a, s, z=50, track=0.12)
    if S.get("sub2"): CAPS(c, S["sub2"], 970, SILV, a, s, z=40, track=0.14)
    fx = 540 + 300 * math.sin(ph(t, 2))
    figure(c, fx, HOR - 4, 300, t, 1.0, GOLD_L, a, walk=1.0, carry=S.get("carry", "flag"))
    for k, tx_ in enumerate((180, 900)):
        tent(c, tx_, HOR - 2, 0.75, 1.0, GOLD, a * 0.6)
def sc_title(c, t, S):
    if S.get("loop"):
        k = ease((t - S["t0"]) / 0.45); a, s = k, lerp(0.9, 1.0, k)
        draw_title(c, t, S, a, s)
    else:
        draw_title(c, t, S)

def stack_rows(c, t, S, rows, y0=430, gap=26):
    y = y0
    for r in rows:
        z = fit(r["t"], F_ANTON if r.get("f", "a") == "a" else F_OSWB, r.get("z", 200), CW)
        if r.get("f") == "o": z = min(z, r.get("z", 60))
        h = z * 0.86 if r.get("f", "a") == "a" else z * 1.15
        yc = y + h / 2; ti = tm(S, r["at"], S["t0"] + 0.05) if r.get("at") else S["t0"] + 0.05
        if t >= ti - 0.12:
            a, s = PP(t, ti, S)
            col = COL.get(r.get("c", "w"), WHITE)
            if r.get("f") == "o": CAPS(c, r["t"], yc, col, a, s, z=z, track=r.get("track", 0.1), path=F_OSWB)
            else: BIG(c, r["t"], yc, col, a, s, maxz=z)
        y += h + gap
    return y
def pill_label(c, t, S, txt, kind):
    a, s = PP(t, S["t0"] + 0.05, S)
    col = GOLD if kind == "view" else SIL_D
    c.save(); c.translate(CX, 380); c.scale(s, s)
    w = tw_(txt, F_OSWB, 40, 0.18) + 70; rr(c, -w / 2, -36, w, 72, 36); sa(c, col, a); c.fill()
    c.restore(); TX(c, txt, F_OSWB, 40, CX, 380, WHITE if kind == "view" else WHITE, a, s, track=0.18)
def icon(c, t, S, ic):
    if not ic: return
    n = ic["name"]; t0 = tm(S, ic["at"], S["t0"]) if ic.get("at") else S["t0"]; prog = ramp(t, t0, t0 + ic.get("d", 1.4))
    if n == "figures":
        N = ic.get("n", 5); hi = ic.get("hi", -1); th = tm(S, ic.get("hi_at"), 999) if ic.get("hi_at") else 999
        for k in range(N):
            x = 540 + (k - (N - 1) / 2) * ic.get("dx", 150); pk = ramp(t, t0 + k * 0.12, t0 + k * 0.12 + 0.9)
            colk = (BLUE if ic.get("hi_col") == "b" else GOLD_L) if (k == hi and t >= th) else (GOLD_L if hi < 0 else SILV)
            figure(c, x, HOR - 4, ic.get("h", 200), t, pk, colk, 1.0, walk=ic.get("walk", 0.25), ph0=k * 1.3)
    elif n == "flag": figure(c, 540, HOR - 4, 240, t, prog, GOLD_L, 1.0, wave=True, carry="flag")
    elif n == "ship":
        x = lerp(1250, ic.get("x", 640), ease((t - t0) / ic.get("d", 1.6)))
        ship(c, x, HOR - 10, ic.get("s", 1.15), t, 1.0)
        if ic.get("people"):
            tp = tm(S, ic["people"]);
            for k in range(6):
                u = ramp(t, tp + k * 0.25, tp + k * 0.25 + 1.0)
                if u > 0: figure(c, lerp(x - 160, 380 - k * 55, u), HOR - 4, 120, t, 1.0, GOLD_L, u, walk=0.6, ph0=k)
    elif n == "tents":
        for k in range(ic.get("n", 4)):
            pk = ramp(t, t0 + k * 0.25, t0 + k * 0.25 + 0.8); x = 540 + (k - (ic.get("n", 4) - 1) / 2) * 230
            (hut if (ic.get("huts_at") and t >= tm(S, ic["huts_at"]) and k % 2 == 0) else tent)(c, x, HOR - 3, 1.0, pk if not (ic.get("huts_at") and t >= tm(S, ic["huts_at"]) and k % 2 == 0) else ramp(t, tm(S, ic["huts_at"]), tm(S, ic["huts_at"]) + 0.8))
    elif n == "plane":
        u = ease((t - t0) / 2.2); x = lerp(-200, ic.get("x", 600), u); y = lerp(1180, ic.get("y", 1130), u)
        plane(c, x, y + 10 * math.sin(ph(t, 12)), 1.15, 1.0)
        if ic.get("people"):
            for k in range(5): figure(c, 340 + k * 110, HOR - 4, 140, t, ramp(t, tm(S, ic["people"]) + k * 0.15, tm(S, ic["people"]) + k * 0.15 + 0.8), GOLD_L, 1.0, walk=0.5, ph0=k)
    elif n == "hand": handshake(c, 540, 1260, 1.0, t, prog)
    elif n == "pipe": pipe(c, HOR, t, prog)
    elif n == "graph": graph(c, HOR - 20, t, prog, kind=ic.get("kind", "spike"))
    elif n == "bridge": bridge(c, HOR - 60, prog)
    elif n == "grid": grid100(c, 540, 1130, t, prog, ramp(t, tm(S, ic.get("hi_at"), 999), tm(S, ic.get("hi_at"), 999) + 0.4))
    elif n == "doc": doc(c, 540, HOR - 20, 1.0, prog)
    elif n == "ballot": ballot(c, 540, HOR - 4, 1.0, t, prog)
    elif n == "bowl": bowl(c, 540, HOR - 40, 1.0, prog)
    elif n == "un": un_ring(c, 540, 1240, 1.0, t, prog)
    elif n == "land": draw_land(c, (300, 980, 780, 1420), prog, t, fill_g=ic.get("fill", 0.0))
    elif n == "leaving":
        for k in range(7):
            u = (t / G["T"] * 3 + k / 7) % 1.0
            figure(c, lerp(300, 1000, u), HOR - 4, 130, t, prog, SILV, 0.9 * math.sin(math.pi * u), walk=0.6, ph0=k)
def sc_beat(c, t, S):
    if S.get("pill"): pill_label(c, t, S, S["pill"], S.get("pill_kind", "other"))
    stack_rows(c, t, S, S.get("rows", []), y0=S.get("y0", 470 if S.get("pill") else 420))
    icon(c, t, S, S.get("icon"))
    if S.get("icon2"): icon(c, t, S, S["icon2"])
    sources(c, t, [(tm(S, k, S["t0"] + 0.3) if k else S["t0"] + 0.3, *ls) for k, *ls in S.get("src", [])])

def sc_map(c, t, S):
    """the land between the river and the sea; mode invade (5 armies) or green (armistice lines)"""
    stack_rows(c, t, S, S.get("rows", []), y0=S.get("y0", 400))
    box_ = (260, 840, 820, 1420); t0 = S["t0"]
    draw_land(c, box_, ramp(t, t0, t0 + 1.2), t, green=(ramp(t, tm(S, "green"), tm(S, "green") + 1.0) if S.get("mode") == "green" else 0.0), fill_g=1.0)
    if S.get("mode") == "invade":
        # name, target lon/lat, arrow start offset (dx, dy), label anchor + position
        arm = [("EGYPT", 34.35, 30.6, -190, 40, "l", 70, None), ("TRANSJORDAN", 35.5, 31.4, 230, 60, "r", 1015, None),
               ("SYRIA", 35.75, 32.9, 200, -60, "r", 1015, None), ("LEBANON", 35.3, 33.1, -40, -110, "r", None, None),
               ("IRAQ", 35.55, 32.3, 240, 30, "r", 1015, None)]
        for k, (nm, lo, la, dx, dy, anc, lx, ly) in enumerate(arm):
            ti = tm(S, f"a{k}", t0 + 0.6 + 0.4 * k)
            if t < ti - 0.1: continue
            u = ease((t - ti + 0.1) / 0.45); px, py = mapP(lo, la, box_)
            ox, oy = px + dx, py + dy; L_ = math.hypot(dx, dy); ux, uy = -dx / L_, -dy / L_
            x1 = lerp(ox, px - ux * 20, u); y1 = lerp(oy, py - uy * 20, u)
            nx, ny = -uy, ux
            polys_draw(c, [[(ox, oy), (x1, y1)], [(x1 - ux * 28 + nx * 18, y1 - uy * 28 + ny * 18), (x1, y1), (x1 - ux * 28 - nx * 18, y1 - uy * 28 - ny * 18)]], 1.0, RED, 9, 1.0)
            a2 = fade(t, ti, S)
            if nm == "LEBANON": TX(c, nm, F_OSWB, 40, ox - 20, oy - 34, WHITE, a2, 1.0, track=0.08, anchor="r", maxw=360)
            else: TX(c, nm, F_OSWB, 40, lx, oy - 34, WHITE, a2, 1.0, track=0.08, anchor=anc, maxw=360)
    sources(c, t, [(tm(S, k, t0 + 0.3) if k else t0 + 0.3, *ls) for k, *ls in S.get("src", [])])

def fmtn(v): return f"{int(round(v)):,}"
def sc_counter(c, t, S):
    """then vs now: two big numbers and a row of figures (1 figure = the 1948 population)"""
    t0 = S["t0"]; ta, tb = tm(S, "a", t0 + 0.1), tm(S, "b", t0 + 1.5)
    a, s = PP(t, ta, S); CAPS(c, S["la"], 420, SILV, a, s, z=44)
    v = RD.count(t, ta, 0.9, S.get("a0", 0), S["va"]); BIG(c, fmtn(v) if S["va"] > 1000 else S.get("va_txt", ""), 540, GOLD_L, a, s, maxz=170)
    if t >= tb - 0.1:
        a, s = PP(t, tb, S); CAPS(c, S["lb"], 700, SILV, a, s, z=44)
        v = RD.count(t, tb, 1.4, S["va"], S["vb"]); BIG(c, fmtn(v), 830, WHITE, a, s, maxz=190)
    if S.get("badge") and t >= tm(S, "badge", 999) - 0.1:
        a, s = PP(t, tm(S, "badge"), S, bounce=2.2)
        c.save(); c.translate(CX, 990); c.scale(s, s); w = tw_(S["badge"], F_OSWB, 50, 0.1) + 80
        rr(c, -w / 2, -44, w, 88, 44); sa(c, GOLD, a); c.fill(); c.restore()
        TX(c, S["badge"], F_OSWB, 50, CX, 990, WHITE, a, s, track=0.1)
    # figures: 1 for "then", then up to ratio for "now"
    ratio = S["vb"] / S["va"]; n_full = int(ratio); frac = ratio - n_full
    n_show = 1 if t < tb else 1 + int((min(n_full, 13) - 1) * ease((t - tb) / 1.4))
    sp = min(70, 900 / max(1, min(n_full + 1, 14)))
    tot = n_show + (1 if (n_show == n_full and frac > 0.05 and t > tb + 1.4) else 0)
    x0 = 540 - (tot - 1) * sp / 2
    for k in range(tot):
        hh = 150 if not (k == n_full) else 150
        colk = GOLD_L if k == 0 else WHITE
        figure(c, x0 + k * sp, HOR - 4, hh, t, 1.0, colk, 1.0 if k < n_full else frac + 0.3, walk=0.2, ph0=k)
    sources(c, t, [(t0 + 0.3, *S["src"])])

def sc_stats(c, t, S):
    """today: tiles pop in one by one"""
    t0 = S["t0"]; CAPS(c, S.get("head", "ISRAEL TODAY"), 400, GOLD_L, *PP(t, t0 + 0.05, S), z=48, track=0.2)
    for k, it in enumerate(S["tiles"]):
        ti = tm(S, it["at"], t0 + 0.3 + 0.5 * k)
        if t < ti - 0.1: continue
        a, s = PP(t, ti, S, bounce=1.8); col_, row = k % 2, k // 2
        x = 290 + col_ * 500; y = 590 + row * 330
        c.save(); c.translate(x, y); c.scale(s, s)
        rr(c, -230, -140, 460, 280, 30); sa(c, NAVY, a * 0.9); c.fill_preserve(); sa(c, GOLD, a); c.set_line_width(4); c.stroke(); c.restore()
        TX(c, it["v"], F_ANTON, 120, x, y - 30, WHITE, a, s, maxw=420)
        TX(c, it["l"].upper(), F_OSW, 34, x, y + 80, SILV, a, s, track=0.1, maxw=420)
    figure(c, 540 + 300 * math.sin(ph(t, 2)), HOR - 4, 150, t, 1.0, GOLD_L, 1.0, walk=1.0, carry="flag")
    sources(c, t, [(t0 + 0.3, *S["src"])])

# ------------------------------------------------------------------ music: the journey bed, bar aligned and looped (from geneva_uniforms)
def _bed(name, dur, end_at=None):
    import numpy as np, importlib.util, sys
    if name != "journey_loop": return _bed0(name, dur, end_at)
    sp_ = importlib.util.spec_from_file_location("journey_audio", "/home/claude/island_israel/journey_audio.py")
    m = importlib.util.module_from_spec(sp_); sp_.loader.exec_module(m)
    bars = max(1, round(dur / 2.4)); bpm = 60 * 4 * bars / dur; bar = 4 * 60 / bpm
    x = np.asarray(m.music(dur + 4 * bar + 4, bpm=bpm), np.float64)
    if x.ndim == 1: x = np.vstack([x, x])
    sr = MX.SR; a0 = int(round(2 * bar * sr)); n = int(round(dur * sr)); F = int(round(bar / 2 * sr))
    seg = x[:, a0:a0 + n + F].copy()
    fi = np.sin(np.linspace(0, np.pi / 2, F)) ** 2
    out = seg[:, :n].copy(); out[:, :F] = seg[:, :F] * fi + seg[:, n:n + F] * (1 - fi)
    MX.LOOP_INFO = dict(bpm=round(bpm, 3), bars=bars, bar_s=round(bar, 4))
    return out / (np.abs(out).max() + 1e-12)
_bed0 = MX.bed
MX.bed = _bed
