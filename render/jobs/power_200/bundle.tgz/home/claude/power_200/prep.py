"""prep.py: town lights for power_200 -> lights.json (run locally; shapely).
Named towns (real places) plus an illustrative scatter of small lights inside the whole land of Israel
(Israel, West Bank, Gaza, Golan), clustered around real towns. Each light gets the year it switches on.
The scatter is an illustration of the grid spreading, not data."""
import json, numpy as np
from shapely.geometry import shape, Point
D = "/home/claude/power_200"
G = json.load(open(f"{D}/geo/geo.json"))
land = shape(G["israel"]).buffer(0); gaza = shape(G["gaza"]).buffer(0)
rng = np.random.default_rng(7)
# name, lon, lat, weight (cluster size), first year of grid power (illustrative spread around it)
T = [("Tel Aviv", 34.78, 32.08, 10, 1923), ("Jaffa", 34.75, 32.05, 3, 1923), ("Petah Tikva", 34.89, 32.09, 3, 1927),
     ("Rishon LeZion", 34.80, 31.96, 3, 1927), ("Haifa", 34.99, 32.80, 6, 1933), ("Jerusalem", 35.21, 31.78, 7, 1930),
     ("Tiberias", 35.53, 32.79, 2, 1934), ("Netanya", 34.86, 32.33, 3, 1940), ("Hadera", 34.92, 32.44, 2, 1935),
     ("Rehovot", 34.81, 31.89, 2, 1935), ("Nazareth", 35.30, 32.70, 2, 1950), ("Afula", 35.29, 32.61, 1.5, 1950),
     ("Safed", 35.50, 32.96, 1.5, 1950), ("Acre", 35.08, 32.93, 2, 1950), ("Beersheba", 34.79, 31.25, 4, 1955),
     ("Ashdod", 34.65, 31.80, 4, 1960), ("Ashkelon", 34.57, 31.67, 3, 1955), ("Eilat", 34.95, 29.56, 2, 1960),
     ("Dimona", 35.03, 31.07, 1.5, 1958), ("Kiryat Shmona", 35.57, 33.21, 1.5, 1955), ("Arad", 35.21, 31.26, 1, 1962),
     ("Karmiel", 35.30, 32.92, 1.5, 1965), ("Nablus", 35.26, 32.22, 3, 1965), ("Hebron", 35.10, 31.53, 3, 1965),
     ("Ramallah", 35.20, 31.90, 2.5, 1965), ("Jenin", 35.30, 32.46, 1.5, 1968), ("Bethlehem", 35.20, 31.70, 1.5, 1965),
     ("Gaza", 34.45, 31.50, 5, 1960), ("Khan Yunis", 34.30, 31.34, 2.5, 1965), ("Rafah", 34.25, 31.29, 2, 1968),
     ("Modiin", 35.01, 31.90, 2, 1996), ("Ariel", 35.17, 32.10, 1, 1980), ("Katzrin", 35.69, 32.99, 1, 1980),
     ("Mitzpe Ramon", 34.80, 30.61, 0.6, 1960), ("Yotvata", 35.06, 29.90, 0.5, 1960), ("Kfar Saba", 34.91, 32.18, 2.5, 1930),
     ("Herzliya", 34.84, 32.16, 2, 1935), ("Holon", 34.78, 32.01, 2.5, 1940), ("Lod", 34.89, 31.95, 2, 1950)]
L = []
for name, lon, lat, w, yr in T:
    L.append(dict(lon=lon, lat=lat, yr=yr, s=1.0 + 0.10 * w, b=1.0, gaza=gaza.contains(Point(lon, lat)), named=name))
W = np.array([t[3] for t in T], float); W /= W.sum()
n = 0
while n < 560:
    k = rng.choice(len(T), p=W); _, lon, lat, w, yr = T[k]
    sd = 0.035 + 0.02 * np.sqrt(w)
    x, y = lon + rng.normal(0, sd * 1.15), lat + rng.normal(0, sd)
    if not land.contains(Point(x, y)): continue
    y0 = yr + abs(rng.normal(0, 8)) + (rng.random() < 0.35) * rng.uniform(10, 60)
    L.append(dict(lon=round(x, 4), lat=round(y, 4), yr=round(min(2024, y0), 1), s=round(rng.uniform(0.35, 0.8), 2),
                  b=round(rng.uniform(0.35, 0.9), 2), gaza=gaza.contains(Point(x, y))))
    n += 1
# a thin sprinkle of rural lights (villages, kibbutzim, roads), later years
m = 0
while m < 220:
    x, y = rng.uniform(34.25, 35.85), rng.uniform(29.5, 33.3)
    if not land.contains(Point(x, y)): continue
    if y < 30.9 and rng.random() < 0.75: continue
    L.append(dict(lon=round(x, 4), lat=round(y, 4), yr=round(rng.uniform(1950, 2022), 1), s=round(rng.uniform(0.25, 0.5), 2),
                  b=round(rng.uniform(0.25, 0.6), 2), gaza=gaza.contains(Point(x, y))))
    m += 1
g = 0
gb = gaza.bounds
while g < 45:
    x, y = rng.uniform(gb[0], gb[2]), rng.uniform(gb[1], gb[3])
    if not gaza.contains(Point(x, y)): continue
    L.append(dict(lon=round(x, 4), lat=round(y, 4), yr=round(rng.uniform(1958, 2010), 1), s=round(rng.uniform(0.35, 0.7), 2),
                  b=round(rng.uniform(0.35, 0.8), 2), gaza=True))
    g += 1
json.dump(L, open(f"{D}/lights.json", "w"))
print(len(L), "lights", sum(l["gaza"] for l in L), "in Gaza")
