"""mix_step.py: doc_piano bed (loop-clean) + SFX under vo_final.wav -> work/mix.m4a (-14 LUFS, -1.5 dBTP). Recipe from crime_punish."""
import sys, os, json, re, numpy as np, soundfile as sf, subprocess
sys.path.insert(0, "/home/claude/reelkit")
import mix as MX
D = "/home/claude/power_200"
T = json.load(open(f"{D}/timing.json")); LN = T["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, w): return [x for x in LN[li]["words"] if norm(x["w"]).startswith(norm(w))][0]["t0"]
lt = lambda li: LN[li]["t0"]
END = round(LN[14]["t1"] + 0.4, 2)
vo, sr = sf.read(f"{D}/vo_final.wav")
if sr != MX.SR:
    raise SystemExit(f"sr {sr}")
m = MX._mod(*MX.BEDS["doc_piano"][:2]); n = int(END * MX.SR); f = int(0.8 * MX.SR)
x = np.asarray(m.doc_music(END + 4.5), np.float64)
if x.ndim == 1: x = np.vstack([x, x])
music = x[:, :n].copy()
music[:, :f] = x[:, :f] * np.sin(np.linspace(0, np.pi / 2, f)) + x[:, n:n + f] * np.cos(np.linspace(0, np.pi / 2, f))
music /= np.abs(music).max() + 1e-12
ev = [(wt(2, "Tel") - 0.1, "ding", 2), (wt(3, "1932") - 0.1, "whoosh", 0), (wt(4, "1948"), "whoosh", -2), (lt(5), "whoosh", -1),
      (wt(6, "1980") - 0.1, "whoosh", 0), (wt(7, "Hadera"), "pop", 0), (wt(7, "Ashkelon"), "pop", 0), (wt(8, "Tamar"), "pop", -2),
      (wt(8, "Leviathan"), "pop", -2), (lt(9), "whoosh", -1), (lt(10), "ding", 2), (lt(11), "whoosh", 0), (lt(13), "whoosh", -1),
      (lt(14), "whoosh", 0)]
os.makedirs(f"{D}/work", exist_ok=True)
rep = MX.mix(vo, END, music, ev, f"{D}/work/mix.wav", music_db=-19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/work/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{D}/work/mix.m4a"], check=True)
os.remove(f"{D}/work/mix.wav"); print(rep, END)
