"""power_200: "200 years ago: total darkness." (@noamroz__, English, 1 Nov 2026). Sibling of "3,000 years. Who lived in this land?".
A night map of the whole land of Israel (Green Line in green, West Bank and Gaza a slightly different shade) lights up as a
year counter runs from 1826 to today; a kWh-per-person counter, a neighbours scorecard, the Gaza lines, and a NASA ISS night
photo at the end. Circular: the last line "Hard to believe that..." completes with the frame 0 hook, and the last 0.45 s
cross-fade into the exact frame 0.
usage: python3 reel.py --snaps 0,3.1,... (PNGs to work/snaps) | python3 reel.py --out out.mp4 (video with work/mix.m4a)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/power_200"; FD = "/home/claude/series_more/safe_p2_v3/fonts"; HB = "/home/claude/vid/fonts/Heebo-800.ttf"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/out.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing
T = json.load(open(f"{D}/timing.json")); LN = T["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, end=False, nth=0):
    ws = [w for w in LN[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LN[li]["t0"]
def le(li): return LN[li]["t1"]
END = round(le(14) + 0.4, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = np.array([5, 7, 13], np.float32)
WHITE, GREY, YEL, SKY, RED = (245, 245, 247), (176, 180, 190), (255, 213, 74), (69, 164, 221), (232, 72, 72)
AMBER = np.array([255, 170, 70], np.float32); WARM = np.array([255, 214, 140], np.float32); COOL = np.array([200, 230, 255], np.float32)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def win(t, t0, t1, fi=0.35, fo=0.35): return min(seg(t, t0 - 0.05, t0 + fi), 1 - seg(t, t1 - fo, t1))
def lerp(a, b, u): return a + (b - a) * u
FONTS = dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium", r="Inter-Regular", sb="Inter-SemiBold")
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(HB if k == "sub" else f"{FD}/{FONTS[k]}.otf", key[1])
    return _fc[key]
def fit(s, k, size, maxw=940, mn=40):
    while font(k, size).getlength(s) > maxw and size > mn: size -= 2
    return size

# stars + vignette background
rng = np.random.default_rng(11)
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
VIG = (1 - 0.55 * (((xx - 540) / 900) ** 2 + ((yy - 980) / 1300) ** 2)).clip(0.35, 1)[:, :, None]
GLOW = np.exp(-0.5 * (((xx - 540) / 520) ** 2 + ((yy - 1000) / 640) ** 2))[:, :, None]
TOPD = (0.78 * np.clip(1 - (yy - 470) / 330, 0, 1) * np.clip((yy - 120) / 120, 0, 1))[:, :, None]
del yy, xx
STARS = [(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(0.2, 1), rng.uniform(0, 6.28), rng.uniform(0.6, 1.6)) for _ in range(140)]

# glow sprites
def sprite(sig):
    r = int(sig * 4); y, x = np.mgrid[-r:r + 1, -r:r + 1].astype(np.float32)
    core = np.exp(-0.5 * (x * x + y * y) / (0.35 * sig) ** 2); halo = np.exp(-0.5 * (x * x + y * y) / sig ** 2)
    return (core * 0.9 + halo * 0.35)[:, :, None], r
SPR = {}
def spr(sig):
    k = round(sig * 2) / 2
    if k not in SPR: SPR[k] = sprite(max(0.8, k))
    return SPR[k]
def add_light(buf, x, y, sig, col, a):
    if a <= 0.01: return
    s, r = spr(sig); xi, yi = int(round(x)), int(round(y))
    x0, y0, x1, y1 = xi - r, yi - r, xi + r + 1, yi + r + 1
    sx0, sy0 = max(0, -x0), max(0, -y0); x0c, y0c = max(0, x0), max(0, y0); x1c, y1c = min(W, x1), min(H, y1)
    if x1c <= x0c or y1c <= y0c: return
    buf[y0c:y1c, x0c:x1c] += s[sy0:sy0 + (y1c - y0c), sx0:sx0 + (x1c - x0c)] * (col * a)

# ------------------------------------------------------------------ geography (Natural Earth, public domain)
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else [gj["coordinates"]]
    return [np.array(r, float) for p in polys for r in p]
LOCAL = {k: rings_of(v) for k, v in G["local"].items() if v and v.get("coordinates")}
ISR = rings_of(G["israel"]); PSX = rings_of(G["psx"]); GAZA = rings_of(G["gaza"])
class Cam:
    def __init__(s, lon, lat, k, cy=1000): s.lon, s.lat, s.k, s.cy = lon, lat, k, cy
    @property
    def kx(s): return s.k * math.cos(math.radians(s.lat))
def cam_lerp(a, b, u): return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.k), math.log(b.k), u)), lerp(a.cy, b.cy, u))
def xy(cam, lon, lat): return 540 + (lon - cam.lon) * cam.kx, cam.cy - (lat - cam.lat) * cam.k
def path(c, cam, rings):
    for r in rings:
        xs = 540 + (r[:, 0] - cam.lon) * cam.kx; ys = cam.cy - (r[:, 1] - cam.lat) * cam.k
        c.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): c.line_to(x, y)
        c.close_path()
def draw_map(cam, lit, alpha):
    """returns premultiplied-free float RGB layer and alpha (H, W) for the map at camera cam; lit 0..1 brightens the land"""
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for k, rs in LOCAL.items(): path(c, cam, rs)
    c.set_source_rgb(14 / 255, 17 / 255, 26 / 255); c.fill_preserve(); c.set_source_rgb(40 / 255, 46 / 255, 62 / 255); c.set_line_width(1.4); c.stroke()
    g0, g1 = np.array([40, 33, 18]), np.array([92, 72, 34])           # dark gold at night -> lit gold
    gl = (g0 + (g1 - g0) * lit) / 255
    path(c, cam, ISR); c.set_source_rgb(*gl); c.fill()
    p0, p1 = np.array([34, 30, 22]), np.array([78, 64, 38])           # West Bank and Gaza: a slightly different shade
    pl = (p0 + (p1 - p0) * lit) / 255
    path(c, cam, PSX); c.set_source_rgb(*pl); c.fill_preserve()
    c.set_source_rgba(46 / 255, 204 / 255, 113 / 255, 0.9); c.set_line_width(max(2.0, min(4.0, cam.k / 120))); c.set_dash([9, 6]); c.stroke(); c.set_dash([])
    path(c, cam, ISR); c.set_source_rgba(0.85, 0.68, 0.33, 0.55); c.set_line_width(1.6); c.stroke()
    surf.flush()
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data())
    return a[:, :, [2, 1, 0]].astype(np.float32), (a[:, :, 3:4].astype(np.float32) / 255) * alpha
LIGHTS = json.load(open(f"{D}/lights.json"))
for l in LIGHTS: l["ph"] = (hash((l["lon"], l["lat"])) % 628) / 100

# ------------------------------------------------------------------ key times
T_TLV = wt(2, "1923"); T_TLV_ON = wt(2, "Tel"); T_NAH = wt(3, "1932"); T_LOOT = wt(4, "1948"); T_GRID = lt(5)
T_SOL = wt(6, "1980"); T_SOL2 = wt(6, "Today"); T_GIANT = lt(7); T_HAD = wt(7, "Hadera"); T_ASH = wt(7, "Ashkelon")
T_GAS = wt(8, "2013"); T_TAM = wt(8, "Tamar"); T_LEV = wt(8, "Leviathan"); T_COAL = lt(9); T_TODAY = lt(10); T_25 = wt(10, "25"); T_8K = wt(10, "8000")
T_NB = lt(11); T_LEB = lt(12); T_GZ = lt(13); T_120 = wt(13, "120"); T_CUT = wt(13, "After"); T_SPACE = lt(14); T_HARD = wt(14, "Hard")
YEARK = [(0, 1826), (lt(1) - 0.1, 1826), (le(1), 1899), (wt(2, "1923", True), 1923), (wt(3, "1932") - 0.3, 1923), (wt(3, "1932", True), 1932),
         (T_LOOT - 0.3, 1932), (wt(4, "1948", True), 1948), (T_GRID, 1948), (T_SOL - 0.1, 1979), (T_SOL + 0.3, 1980), (T_HAD, 1980),
         (T_HAD + 0.5, 1981), (T_ASH, 1981), (T_ASH + 0.6, 1990), (T_GAS - 0.4, 1990), (T_GAS + 0.4, 2013), (T_LEV, 2013),
         (T_LEV + 0.5, 2019), (T_COAL, 2019), (le(9), 2025), (T_TODAY, 2025), (T_TODAY + 0.6, 2026)]
def year(t):
    for (t0, y0), (t1, y1) in zip(YEARK, YEARK[1:]):
        if t < t1: return y0 + (y1 - y0) * (ease((t - t0) / (t1 - t0)) if t1 > t0 else 1)
    return YEARK[-1][1]
KWH = [(1955, 590), (1990, 4600), (2000, 6740), (2024, 7880)]
def kwh(y):
    if y <= 1955: return 590
    for (y0, v0), (y1, v1) in zip(KWH, KWH[1:]):
        if y <= y1: return v0 + (v1 - v0) * (y - y0) / (y1 - y0)
    return 7880

CAM0 = Cam(35.02, 31.40, 214, 1030); CAM1 = Cam(35.02, 31.40, 225, 1030); CAMG = Cam(34.50, 31.40, 880, 1010)
def camera(t):
    c = cam_lerp(CAM0, CAM1, seg(t, 0, T_GRID))
    if t >= T_GZ - 0.2:
        c = cam_lerp(CAM1, CAMG, seg(t, T_GZ - 0.2, T_GZ + 1.3))
        if t >= T_SPACE - 0.3: c = cam_lerp(CAMG, CAM1, seg(t, T_SPACE - 0.3, T_SPACE + 0.8))
    return c

# ------------------------------------------------------------------ text helpers
def txt(im, s, cx, cy, k, size, col=WHITE, a=1.0, anchor="mm", maxw=940):
    if a <= 0.01: return
    size = fit(s, k, size, maxw); f = font(k, size)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((cx, cy), s, font=f, fill=col + (int(255 * a),), anchor=anchor)
    im.alpha_composite(lay)
def ctext(d, s, cx, cy, k, size, col=WHITE, a=1.0, anchor="mm", maxw=940):
    if a <= 0.01: return
    size = fit(s, k, size, maxw); d.text((cx, cy), s, font=font(k, size), fill=col + (int(255 * a),), anchor=anchor)
def panel(d, box, a, r=34, fill=(10, 14, 26), op=0.82):
    if a > 0.01: d.rounded_rectangle(box, r, fill=fill + (int(255 * op * a),))

SRC = [  # (t0, t1, lines) at 38 px
    (lt(1), T_TLV - 0.2, ["Town lights in this video are an illustration.", "Map: Natural Earth. Green Line in green."]),
    (T_TLV, T_NAH - 0.25, ["First power station, Tel Aviv, 10 June 1923.", "Sources: Time Out Tel Aviv; Israel Electric Corp."]),
    (T_NAH, T_LOOT - 0.1, ["Rutenberg's Jordan power plant, 1927 to 1933.", "American Colony Photo Dept., public domain"]),
    (T_LOOT, T_GRID - 0.1, ["Opened 9 June 1932. Captured and looted, 14 May 1948.", "Source: Wikipedia, First Jordan Hydro-Electric Power House"]),
    (T_GRID, T_SOL - 0.1, ["Electricity use per person: Bank of Israel 1955;", "Ember and Energy Institute via Our World in Data"]),
    (T_SOL, T_GIANT - 0.1, ["Knesset law, 1980: solar water heaters on new homes.", "Over 90% of homes. Source: Solar power in Israel, Wikipedia"]),
    (T_GIANT, T_GAS - 0.1, ["Orot Rabin, Hadera: 2,590 MW, 1981. Rutenberg,", "Ashkelon: 2,250 MW, 1990. Source: Wikipedia"]),
    (T_GAS, T_COAL - 0.1, ["Tamar first gas 30 March 2013. Leviathan, Dec 2019.", "Source: Wikipedia, Natural gas in Israel"]),
    (T_COAL, T_TODAY - 0.1, ["Coal share of Israel's electricity, 2000 and 2025.", "Ember and Energy Institute via Our World in Data"]),
    (T_TODAY, T_NB - 0.1, ["Installed capacity, end 2024: LNRG market review, 2025.", "Use per person, 2024: Our World in Data"]),
    (T_NB, T_GZ - 0.1, ["Electricity use per person, 2024. Ember, Energy Institute", "via Our World in Data. Lebanon hours: HRW, 2024"]),
    (T_GZ, T_SPACE - 0.1, ["Before May 2021: 120 of 190 MW from Israeli lines.", "Source: UN OCHA Gaza energy map, 2021"]),
    (T_SPACE, T_HARD, ["Israel's coast at night from the ISS, 22 July 2014.", "NASA, public domain"]),
]
def sources(d, t):
    for t0, t1, ls in SRC:
        a = win(t, t0, t1, 0.3, 0.25)
        for i, s in enumerate(ls): ctext(d, s, 540, 1440 + 46 * i, "r", 38, GREY, a, maxw=980)

# ------------------------------------------------------------------ photos
def load_photo(name, box):
    im = Image.open(f"{D}/photos/{name}.jpg").convert("RGB"); bw, bh = box
    s = max(bw / im.width, bh / im.height) * 1.1
    return im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS)
PH_NAH = load_photo("pw_naharayim", (940, 540)); PH_ISS = load_photo("pw_iss_coast", (1080, 1920))
def rmask(w, h, r):
    m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w - 1, h - 1), r, fill=255); return m
MASK_NAH = rmask(940, 540, 36)

# ------------------------------------------------------------------ the frame
def lights_layer(t, cam, y):
    buf = np.zeros((H, W, 3), np.float32)
    zk = cam.k / 193
    # oil lamps (1800s): a few dim flickering amber points in old towns
    if t < T_GRID + 1:
        la = seg(t, 0.9, 2.2) * (1 - seg(t, T_GRID - 0.5, T_GRID + 1))
        for lon, lat in [(35.23, 31.78), (34.75, 32.05), (35.10, 31.53), (35.26, 32.22), (35.50, 32.96), (35.53, 32.79), (34.46, 31.50), (35.00, 32.81), (35.08, 32.93), (35.30, 32.70)]:
            x, y_ = xy(cam, lon, lat); fl = 0.55 + 0.45 * math.sin(t * 9 + lon * 50) * math.sin(t * 5.3 + lat * 70)
            add_light(buf, x, y_, 3.5, AMBER, 0.38 * la * fl)
    cut = seg(t, T_CUT + 0.2, T_CUT + 1.4)
    for l in LIGHTS:
        on = y - l["yr"]
        if on <= 0: continue
        a = min(1.0, on / 4.0) * l["b"]
        if l["gaza"]: a *= 1 - 0.8 * cut
        x, y_ = xy(cam, l["lon"], l["lat"])
        if x < -30 or x > W + 30 or y_ < -30 or y_ > H + 30: continue
        tw = 0.88 + 0.12 * math.sin(t * 2.2 + l["ph"])
        col = WARM if l.get("named") or l["ph"] > 1.3 else COOL * 0.95
        add_light(buf, x, y_, (2.2 + 4.2 * l["s"]) * min(2.2, zk ** 0.5), col, a * tw * 0.55)
        if l.get("named"): add_light(buf, x, y_, 9 * l["s"] * min(2, zk ** 0.5), WARM, a * 0.22)
    # first station burst, Tel Aviv 1923
    x, y_ = xy(cam, 34.78, 32.08)
    b = seg(t, T_TLV_ON - 0.2, T_TLV_ON + 0.3) * (1 - 0.6 * seg(t, T_TLV_ON + 0.6, T_TLV_ON + 2.5))
    add_light(buf, x, y_, 26, WARM, 0.9 * b)
    # Naharayim 1932 to 1948
    x, y_ = xy(cam, 35.57, 32.64)
    nb = seg(t, T_NAH, T_NAH + 0.5) * (1 - seg(t, T_LOOT + 0.3, T_LOOT + 1.6))
    add_light(buf, x, y_, 14, np.array([150, 220, 255], np.float32), 0.85 * nb)
    # the giants
    for tt, lon, lat in [(T_HAD, 34.88, 32.47), (T_ASH, 34.53, 31.63)]:
        x, y_ = xy(cam, lon, lat); g = seg(t, tt - 0.1, tt + 0.4) * (1 - 0.5 * seg(t, T_COAL, T_TODAY)) * (1 - seg(t, T_NB - 0.4, T_NB))
        add_light(buf, x, y_, 22, np.array([255, 196, 90], np.float32), 0.9 * g)
    # solar water heaters: cool sparkles over the towns
    sa = win(t, T_SOL + 0.2, T_GIANT + 0.4, 0.6, 0.6)
    if sa > 0:
        for i, l in enumerate(LIGHTS[:300:3]):
            x, y_ = xy(cam, l["lon"] + 0.01, l["lat"]); s_ = 0.5 + 0.5 * math.sin(t * 6 + i)
            add_light(buf, x, y_, 2.0, np.array([170, 235, 255], np.float32), 0.8 * sa * s_)
    return buf

def lit_of(y): return max(0.0, min(0.75, (y - 1923) / 120))

def base_frame(t, hook_only=False):
    cam = camera(t) if not hook_only else CAM0
    y = year(t) if not hook_only else 1826
    arr = BG[None, None, :] * VIG + GLOW * 10
    # stars
    im_st = np.zeros((H, W, 1), np.float32)
    lay_alpha = 1.0
    if hook_only or t < T_NB - 0.3 or t > T_GZ - 0.4:
        mf, ma = draw_map(cam, lit_of(y), 1.0)
        if not hook_only:
            dim = 1 - 0.6 * win(t, T_SOL + 0.1, T_GIANT, 0.4, 0.4) - 0.6 * win(t, T_COAL - 0.1, T_TODAY + 0.1, 0.4, 0.4)
            ma = ma * dim
        arr = arr * (1 - ma) + mf * ma
        L = lights_layer(t, cam, y)
        if not hook_only:
            L *= (1 - 0.55 * win(t, T_SOL + 0.1, T_GIANT, 0.4, 0.4) - 0.6 * win(t, T_COAL - 0.1, T_TODAY + 0.1, 0.4, 0.4))
        arr = arr + L
    zw = 0.25 + 0.75 * min(1.0, max(0.0, (cam.k - 240) / 300))
    arr = arr * (1 - TOPD * zw)
    im = Image.fromarray(arr.clip(0, 255).astype(np.uint8), "RGB").convert("RGBA")
    d = ImageDraw.Draw(im)
    for sx, sy, sb, ph, sz in STARS:
        if 600 < sy < 1420 and 380 < sx < 720: continue
        a = sb * (0.55 + 0.45 * math.sin(t * 1.7 + ph)) * 0.55
        d.ellipse((sx - sz, sy - sz, sx + sz, sy + sz), fill=(220, 228, 255, int(255 * a)))
    return im, cam, y

HOOK = ["200 years ago:", "total darkness."]
def hook(im, t, a):
    if a <= 0.01: return
    d = ImageDraw.Draw(im)
    br = 0.5 + 0.5 * math.sin(t * 2.4)
    ctext(d, HOOK[0], 540, 330, "db", 132, YEL, a)
    ctext(d, HOOK[1], 540, 478, "db", 132, WHITE, a)
    u = seg(t, 0.25, 1.4); w = 560 * u
    d.rounded_rectangle((540 - w / 2, 566, 540 + w / 2, 574), 4, fill=YEL + (int(200 * a * (0.7 + 0.3 * br)),))

BEATS = [  # (t0, t1, text, size)
    (lt(1), T_TLV - 0.15, "Oil lamps. No power lines.", 76),
    (T_TLV, T_NAH - 0.15, "The first power station", 76),
    (T_NAH, T_LOOT - 0.15, "Hydro power on the Jordan", 76),
    (T_LOOT, T_GRID - 0.1, "Looted in the war. Never ran again.", 72),
    (T_GRID, T_SOL - 0.1, "A national grid", 80),
    (T_GIANT, T_GAS - 0.1, "The giants", 84),
    (T_GAS, T_COAL - 0.1, "Gas under the sea", 80),
    (T_GZ, T_120 - 0.1, "Gaza", 92),
]
def labels(im, t, cam):
    d = ImageDraw.Draw(im)
    def lab(lon, lat, t0, t1, l1, l2=None, side="L", col=WHITE, size=50):
        a = win(t, t0, t1, 0.35, 0.3)
        if a <= 0.01: return
        x, y = xy(cam, lon, lat)
        if side == "L":
            xe = x - 40; d.line((x - 10, y, xe, y), fill=col + (int(200 * a),), width=3)
            ctext(d, l1, xe - 12, y - (22 if l2 else 0), "dsb", size, col, a, "rm", maxw=xe - 80)
            if l2: ctext(d, l2, xe - 12, y + 30, "r", 40, YEL, a, "rm", maxw=xe - 80)
        else:
            xs = x + 40; d.line((x + 10, y, xs, y), fill=col + (int(200 * a),), width=3)
            ctext(d, l1, xs + 12, y - (22 if l2 else 0), "dsb", size, col, a, "lm", maxw=1010 - xs - 12)
            if l2: ctext(d, l2, xs + 12, y + 30, "r", 40, YEL, a, "lm", maxw=1010 - xs - 12)
    lab(34.78, 32.08, T_TLV_ON - 0.1, T_NAH + 0.2, "Tel Aviv", "10 June 1923")
    lab(35.57, 32.64, T_NAH + 0.1, T_GRID, "Naharayim", "1932 to 1948", "R")
    lab(34.88, 32.47, T_HAD - 0.05, T_GAS - 0.1, "Hadera", "2,590 MW, 1981")
    lab(34.53, 31.63, T_ASH - 0.05, T_GAS - 0.1, "Ashkelon", "2,250 MW, 1990")
    # gas fields offshore (positions approximate: Tamar about 90 km, Leviathan about 130 km west of Haifa)
    for tt, lon, lat, name, yr_, lon2, lat2 in [(T_TAM, 34.05, 32.92, "Tamar", "2013", 34.65, 31.80), (T_LEV, 33.62, 32.98, "Leviathan", "2019", 34.92, 32.60)]:
        a = win(t, tt - 0.1, T_COAL - 0.1, 0.35, 0.3)
        if a <= 0.01: continue
        x, y = xy(cam, lon, lat); x2, y2 = xy(cam, lon2, lat2)
        u = seg(t, tt, tt + 0.9); d.line((x, y, lerp(x, x2, u), lerp(y, y2, u)), fill=SKY + (int(230 * a),), width=4)
        r = 13 + 3 * math.sin(t * 5); d.ellipse((x - r, y - r, x + r, y + r), outline=SKY + (int(255 * a),), width=5)
        d.ellipse((x - 6, y - 6, x + 6, y + 6), fill=SKY + (int(255 * a),))
        if name == "Leviathan": ctext(d, name, x + 20, y - 100, "dsb", 52, WHITE, a); ctext(d, yr_, x + 20, y - 50, "r", 44, YEL, a)
        else: ctext(d, name, x + 30, y + 56, "dsb", 52, WHITE, a); ctext(d, yr_, x + 30, y + 106, "r", 44, YEL, a)
    # red X at Naharayim after the looting
    a = win(t, T_LOOT + 0.3, T_GRID, 0.3, 0.3)
    if a > 0.01:
        x, y = xy(cam, 35.57, 32.64); r = 16
        d.line((x - r, y - r, x + r, y + r), fill=RED + (int(255 * a),), width=7); d.line((x - r, y + r, x + r, y - r), fill=RED + (int(255 * a),), width=7)

def east_edge(la):
    best = None
    for r in GAZA:
        for (x0, y0), (x1, y1) in zip(r[:-1], r[1:]):
            if (y0 - la) * (y1 - la) <= 0 and y0 != y1:
                x = x0 + (x1 - x0) * (la - y0) / (y1 - y0); best = x if best is None else max(best, x)
    return best
def gaza_lines(im, t, cam):
    a = win(t, T_GZ + 0.8, T_SPACE - 0.2, 0.5, 0.4)
    if a <= 0.01: return
    d = ImageDraw.Draw(im)
    lats = np.linspace(31.25, 31.56, 10); cut = seg(t, T_CUT + 0.1, T_CUT + 1.0)
    for i, la in enumerate(lats):
        lon_in = east_edge(la)
        x0, y0 = xy(cam, lon_in + 0.13, la + 0.025); x1, y1 = xy(cam, lon_in + 0.005, la)
        grow = seg(t, T_GZ + 0.8 + i * 0.07, T_GZ + 1.6 + i * 0.07)
        xe, ye = lerp(x0, x1, grow), lerp(y0, y1, grow)
        colr = tuple(int(lerp(c1, c2, cut)) for c1, c2 in zip(YEL, (90, 90, 100)))
        d.line((x0, y0, xe, ye), fill=colr + (int(235 * a * (1 - 0.5 * cut)),), width=6)
        if cut < 0.5 and grow >= 1:
            u = ((t * 0.9 + i * 0.13) % 1.0); px, py = lerp(x0, x1, u), lerp(y0, y1, u)
            d.ellipse((px - 7, py - 7, px + 7, py + 7), fill=(255, 245, 200, int(255 * a * (1 - 2 * cut))))
    xi, yi = xy(cam, 34.78, 31.28); ctext(d, "Israel", xi, yi, "dsb", 60, WHITE, a * 0.9)

def info(im, t, y):
    d = ImageDraw.Draw(im)
    # year label
    ya = win(t, lt(1) - 0.2, T_NB - 0.15, 0.5, 0.3)
    if ya > 0.01:
        s = "Today" if t >= T_TODAY + 0.3 else f"{int(round(y))}"
        ctext(d, s, 540, 330, "db", 190, YEL, ya)
    # beat text
    for t0, t1, s, sz in BEATS:
        ctext(d, s, 540, 500, "dsb", sz, WHITE, win(t, t0, t1, 0.35, 0.25))
    # kWh per person counter (right side, over the desert)
    ka = win(t, T_GRID + 0.4, T_NB - 0.1, 0.5, 0.3) * (1 - win(t, T_SOL, T_GIANT, 0.3, 0.3)) * (1 - win(t, T_COAL, T_TODAY, 0.3, 0.3))
    if ka > 0.01:
        v = kwh(y) if t < T_8K - 0.4 else lerp(kwh(y), 7880, seg(t, T_8K - 0.4, T_8K + 0.4))
        panel(d, (725, 1150, 1020, 1360), ka, 28)
        ctext(d, f"{int(round(v / 10) * 10):,}", 872, 1225, "db", 96, YEL, ka, maxw=290)
        ctext(d, "kWh per person", 872, 1310, "sb", 40, WHITE, ka, maxw=290)
    ga = win(t, T_25 - 0.2, T_NB - 0.1, 0.4, 0.3)
    if ga > 0.01:
        v = lerp(0, 25, seg(t, T_25 - 0.2, T_25 + 0.7))
        panel(d, (725, 920, 1020, 1130), ga, 28)
        ctext(d, f"{v:.0f} GW", 872, 995, "db", 96, YEL, ga, maxw=290)
        ctext(d, "installed, 2024", 872, 1080, "sb", 40, WHITE, ga, maxw=290)
    # solar card
    sa = win(t, T_SOL + 0.15, T_GIANT - 0.05, 0.4, 0.3)
    if sa > 0.01:
        panel(d, (70, 640, 1010, 1300), sa, 40)
        cx, cy = 540, 790; r = 54 + 4 * math.sin(t * 3)
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=YEL + (int(255 * sa),))
        for k in range(12):
            an = k * math.pi / 6 + t * 0.4
            d.line((cx + math.cos(an) * (r + 16), cy + math.sin(an) * (r + 16), cx + math.cos(an) * (r + 46), cy + math.sin(an) * (r + 46)), fill=YEL + (int(255 * sa),), width=8)
        ctext(d, "Solar water heaters", 540, 945, "dsb", 76, WHITE, sa)
        ctext(d, "on every new home", 540, 1030, "dsb", 64, WHITE, sa)
        b = seg(t, T_SOL2 - 0.1, T_SOL2 + 0.4)
        ctext(d, "9 in 10 homes today", 540, 1180, "db", 96, YEL, sa * b)
    # coal card
    ca = win(t, T_COAL + 0.05, T_TODAY - 0.05, 0.4, 0.3)
    if ca > 0.01:
        panel(d, (70, 640, 1010, 1380), ca, 40)
        ctext(d, "Coal's share of the power", 540, 700, "dsb", 68, WHITE, ca)
        base = 1290; full = 390
        for i, (yr_, v, at) in enumerate([("2000", 68.5, T_COAL), ("2025", 3.4, wt(9, "about"))]):
            x = 330 + i * 420; u = seg(t, at, at + 0.8); h = full * v / 68.5 * u
            col = (120, 124, 136) if i == 0 else YEL
            d.rounded_rectangle((x - 95, base - max(10, h), x + 95, base), 16, fill=col + (int(255 * ca * min(1, u * 3)),))
            ctext(d, f"{round(v * u):.0f}%", x, base - max(10, h) - 62, "db", 96, YEL if i else WHITE, ca * min(1, u * 3))
            ctext(d, yr_, x, base + 52, "dsb", 56, WHITE, ca * min(1, u * 3))
    # Gaza stat
    za = win(t, T_120 - 0.1, T_SPACE - 0.15, 0.35, 0.3)
    if za > 0.01:
        cut = seg(t, T_CUT - 0.05, T_CUT + 0.3)
        ctext(d, "120 of 190 MW", 540, 330, "db", 150, YEL, za * (1 - cut))
        ctext(d, "came from Israel", 540, 480, "dsb", 80, WHITE, za * (1 - cut))
        ctext(d, "Cut from October 2023", 540, 400, "db", 100, WHITE, za * cut)

ROWS = [("Saudi Arabia", 13385), ("Israel", 7883), ("Iraq", 3406), ("Jordan", 2054), ("Egypt", 2025),
        ("West Bank, Gaza", 1454), ("Syria", 984), ("Lebanon", 920)]
def scorecard(im, t):
    a = win(t, T_NB - 0.1, T_GZ - 0.05, 0.4, 0.35)
    if a <= 0.01: return
    d = ImageDraw.Draw(im)
    ctext(d, "Electricity use per person", 540, 330, "db", 84, WHITE, a)
    ctext(d, "kWh, 2024", 540, 430, "dsb", 60, YEL, a)
    y0, rh = 560, 104
    for i, (n, v) in enumerate(ROWS):
        u = seg(t, T_NB + 0.15 + i * 0.12, T_NB + 0.9 + i * 0.12); y = y0 + rh * i
        isr, leb = n == "Israel", n == "Lebanon"
        hl = seg(t, T_LEB - 0.1, T_LEB + 0.3) if leb else 0
        if isr: d.rounded_rectangle((60, y - 46, 1020, y + 46), 24, fill=(60, 48, 16, int(200 * a * u)))
        if leb: d.rounded_rectangle((60, y - 46, 1020, y + 46), 24, fill=(90, 22, 22, int(220 * a * hl)))
        ctext(d, n, 84, y, "dsb", 54, YEL if isr else WHITE, a * u, "lm", maxw=410)
        bw = 290 * v / 13385 * u
        col = YEL if isr else (RED if leb and hl > 0.5 else SKY)
        d.rounded_rectangle((505, y - 22, 505 + max(8, bw), y + 22), 11, fill=col + (int(255 * a * u),))
        ctext(d, f"{v:,}", 1000, y, "db", 54, YEL if isr else WHITE, a * u, "rm", maxw=200)
    la = a * seg(t, T_LEB + 0.2, T_LEB + 0.6)
    ctext(d, "Lebanon: about 4 hours of state power a day", 540, 1420 - 40, "sb", 44, WHITE, la, maxw=960)

def iss(im, t):
    a = seg(t, T_SPACE - 0.1, T_SPACE + 0.7) * (1 - seg(t, T_HARD - 0.1, END - LOOP))
    if a <= 0.01: return
    u = seg(t, T_SPACE - 0.1, END)
    z = lerp(1.0, 1.08, u); cw, ch = W / z, H / z
    cx, cy = PH_ISS.width / 2, PH_ISS.height * 0.48
    ph = PH_ISS.crop((int(cx - cw / 2), int(cy - ch / 2), int(cx + cw / 2), int(cy + ch / 2))).resize((W, H), Image.BILINEAR).convert("RGBA")
    ph.putalpha(int(255 * a)); im.alpha_composite(ph)
    d = ImageDraw.Draw(im)
    ctext(d, "From space, it shines", 540, 330, "db", 100, WHITE, a * seg(t, T_SPACE + 0.1, T_SPACE + 0.6))

def nah_photo(im, t):
    a = win(t, T_NAH - 0.1, T_LOOT + 0.7, 0.4, 0.4)
    if a <= 0.01: return
    u = seg(t, T_NAH - 0.1, T_LOOT + 0.7)
    z = lerp(1.0, 1.08, u); bw, bh = 940, 540
    cw, ch = PH_NAH.width / 1.1 / z, PH_NAH.height / 1.1 / z
    x0 = (PH_NAH.width - cw) / 2; y0 = (PH_NAH.height - ch) / 2
    p = PH_NAH.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((bw, bh), Image.BILINEAR)
    if t > T_LOOT:  # turns cold and dark when it is looted
        k = seg(t, T_LOOT, T_LOOT + 0.6); p = Image.blend(p, p.point(lambda v: v * 0.45), k)
    m = MASK_NAH.point(lambda v: int(v * a))
    im.paste(p, (70, 640), m)

SUBF = None
def build_subs():
    items = []
    for L in LN:
        ws = L["words"]; cur = []
        for k, w in enumerate(ws):
            cur.append(w)
            if len(cur) >= 5 or re.search(r"[.,?!]$", w["w"]) or k == len(ws) - 1:
                if len(cur) <= 1 and k < len(ws) - 1 and not re.search(r"[.?!]$", w["w"]): continue
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]; items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].replace("...", "").strip()
    return items
SUBS = build_subs()
def subs(im, t):
    f = font("sub", 54)
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            d = ImageDraw.Draw(im); w = f.getlength(s) + 52
            if w > 980:
                ws = s.split(); h = len(ws) // 2; ls = [" ".join(ws[:h]), " ".join(ws[h:])]
            else: ls = [s]
            wmax = max(f.getlength(l) for l in ls) + 52; bh = 66 * len(ls) + 26; y0 = 1625 - bh
            d.rounded_rectangle((540 - wmax / 2, y0, 540 + wmax / 2, 1625), 22, fill=(8, 12, 24, 210))
            for n, l in enumerate(ls): d.text((540, y0 + 13 + 66 * n + 33), l, font=f, fill=WHITE + (255,), anchor="mm")
            return

FRAME0 = None
def frame(t):
    global FRAME0
    im, cam, y = base_frame(t)
    if t < lt(1) + 0.3: hook(im, t, 1 - seg(t, lt(1) - 0.2, lt(1) + 0.3))
    labels(im, t, cam); gaza_lines(im, t, cam)
    nah_photo(im, t); info(im, t, y); scorecard(im, t); iss(im, t)
    # lead-in back to the hook: the dark land and the hook return while "Hard to believe that..." is said
    if t >= T_HARD - 0.1:
        h0, _, _ = base_frame(0, hook_only=True); hook(h0, 0, 1.0)
        k = seg(t, T_HARD - 0.1, END - LOOP)
        im = Image.blend(im.convert("RGB"), h0.convert("RGB"), k).convert("RGBA")
    d = ImageDraw.Draw(im); sources(d, t)
    subs(im, t)
    out = im.convert("RGB")
    if t >= END - LOOP:
        if FRAME0 is None: FRAME0 = frame(0)
        out = Image.blend(out, FRAME0, seg(t, END - LOOP, END))
    return out

if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","): frame(float(s)).save(f"{D}/work/snaps/s_{float(s):06.2f}.png")
        print("END", END); sys.exit()
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/work/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19",
                          "-pix_fmt", "yuv420p", "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", A.out], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("done", A.out, END)
