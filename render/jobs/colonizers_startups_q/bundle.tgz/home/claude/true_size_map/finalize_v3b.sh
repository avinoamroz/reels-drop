#!/bin/bash
# join v3 parts, add the -14 LUFS mix, burn in subtitles (cities make_subs.py, SUB_BOTTOM 1600), make the <16 MB final + web copy, QA sheet
set -e; cd /home/claude/true_size_map
ffmpeg -nostdin -v error -y -i parts_v3/v3_silent.mp4 -i music/true_size_v3_mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest parts_v3/v3_nosub.mp4
rm -f parts_v3/v3_silent.mp4
SUB_BOTTOM=1600 nice -n 15 python3 /home/claude/cities/subs/make_subs.py parts_v3/v3_nosub.mp4 subs_v3.txt subs_segs_v3.json parts_v3/v3_subs.mp4
rm -f parts_v3/v3_nosub.mp4
SZ=$(stat -c %s parts_v3/v3_subs.mp4)
if [ $SZ -lt 16000000 ]; then mv parts_v3/v3_subs.mp4 true_size_v3.mp4
else nice -n 15 ffmpeg -nostdin -v error -y -i parts_v3/v3_subs.mp4 -c:v libx264 -preset medium -crf 23 -pix_fmt yuv420p -c:a copy -movflags +faststart true_size_v3.mp4; rm -f parts_v3/v3_subs.mp4; fi
nice -n 15 ffmpeg -nostdin -v error -y -i true_size_v3.mp4 -c:v libx264 -preset medium -crf 27 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart true_size_v3_web.mp4
mkdir -p qa/v3/final; rm -f qa/v3/final/*.png
for t in 0.03 1.5 6 10 14 18 21.5 25 28.5 32 35 38 42 45 48.5 51 55 58 62 65 68.5 71.5 74.5 77 80.5 82.5; do
  ffmpeg -nostdin -v error -y -ss $t -i true_size_v3.mp4 -frames:v 1 qa/v3/final/f_$(printf %05.2f $t).png; done
python3 qa_sheet_v2.py qa/sheet_v3.png qa/v3/final/f_*.png
ls -la true_size_v3.mp4 true_size_v3_web.mp4 qa/sheet_v3.png
