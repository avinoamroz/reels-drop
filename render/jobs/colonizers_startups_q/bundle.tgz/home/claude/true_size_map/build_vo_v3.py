"""True size v3 narration (generated from build_vo_v2.py). v2 docstring follows:
True size v2 narration: reuse the Oct 20 take (vo/clean/noam.wav), deeper voice (rubberband pitch 0.9715, formants kept,
bass +2 dB at 135 Hz), atempo 1.1, cut into sub-line pieces (split points from silencedetect -36 dB) and re-spaced so the drags
get room; the old 7-minute + "Comment MAP" lines are replaced by lines 15 and 17 of /home/claude/growth/tts_v4.txt, taken from
/home/claude/growth/vo/vo.wav (already pitched + 1.1x, same voice), loudness matched.
out: vo3/vo_v3.wav (48 kHz mono) + vo3/segs_v3.json (pieces with times, cards with times) + subs_v3.txt / subs_segs_v3.json"""
import json, subprocess, os, numpy as np, soundfile as sf
HERE = os.path.dirname(os.path.abspath(__file__)); SR = 48000; TEMPO = 1.1
TMP = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"; os.makedirs(TMP, exist_ok=True)
RAW = f"{HERE}/vo3/raw.wav"; CI, CO = f"{TMP}/v3_in", f"{TMP}/v3_out"; os.makedirs(CI, exist_ok=True); os.makedirs(CO, exist_ok=True)
# 1. pitch -0.5 st (formants kept) + bass on the whole take, 2. clean_vo (length kept), 3. atempo 1.1
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", RAW, "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{CI}/full.wav"], check=True)
subprocess.run(["nice", "-n", "15", "python3", "/home/claude/vo_new/clean_vo.py", CI, CO, "--report"], check=True)
fast = f"{TMP}/v3_fast.wav"
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", f"{CO}/full.wav", "-af", f"atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", fast], check=True)
import shutil; shutil.rmtree(CI); shutil.rmtree(CO)
X, sr = sf.read(fast); assert sr == SR
# (id, source, a, b) source "ts": times in the original clean take (divided by TEMPO); "gr": times in growth/vo/vo.wav
# subtitle text: numbers as digits
P = [   # times in vo3/raw.wav (ASR chunks, vo3/asr.json; "Drag it down" split at the 40.29 to 40.46 pause, -42 dB)
 ("hook", "ts", 0.00, 2.80, "Psst. Greenland is lying to you."),
 ("merc", "ts", 3.31, 5.20, "This is the Mercator projection."),
 ("merc2", "ts", 5.45, 7.64, "And it's still the map most of us grew up with."),
 ("st1", "ts", 8.10, 12.75, "To keep the shapes right, it stretches the land, the farther it gets from the equator."),
 ("st2", "ts", 13.16, 16.94, "Look. These circles are all the exact same size on the globe."),
 ("st3", "ts", 17.32, 21.90, "That stretch is called distortion. And it grows, the closer you get to the poles."),
 ("glA", "ts", 22.19, 24.67, "Greenland looks as big as Africa. Right?"),
 ("glD", "ts", 24.97, 27.77, "Now, let's drag it down to the equator. To scale."),
 ("glB", "ts", 28.06, 30.63, "Africa is about 14 times bigger!"),
 ("auA", "ts", 30.94, 33.00, "Australia looks smaller than Greenland."),
 ("auB", "ts", 33.31, 36.80, "In reality? Australia is about 3.5 times bigger."),
 ("ruA", "ts", 37.14, 38.79, "Russia looks bigger than Africa."),
 ("ruD", "ts", 39.09, 40.29, "Drag it down,"),
 ("ruB", "ts", 40.46, 42.95, "and Africa is almost twice its size."),
 ("akA", "ts", 43.30, 45.11, "Alaska looks as big as Brazil."),
 ("akB", "ts", 45.46, 47.70, "Brazil is almost 5 times bigger."),
 ("euA", "ts", 48.00, 49.90, "Europe looks bigger than South America."),
 ("euB", "ts", 50.20, 53.68, "South America is about 1.7 times the size of Europe."),
 ("ilA", "ts", 53.97, 54.53, "And Israel?"),
 ("ilD", "ts", 54.81, 56.91, "Let's drag New Jersey over. To scale."),
 ("ilB", "ts", 57.25, 58.89, "They're about the same size."),
 ("eeA", "ts", 59.22, 60.79, "Mercator keeps the shapes."),
 ("eeB", "ts", 61.12, 64.70, "An equal area map, like Equal Earth, keeps the sizes."),
 ("where", "ts", 65.00, 66.32, "So, where are you from?"),
 ("dom1", "ts", 66.63, 67.55, "Let's play dominoes."),
 ("dom2", "ts", 67.80, 70.51, "Give me 2 countries you think are about the same size."),
 ("write", "ts", 70.81, 73.40, "Write them in the comments, and I'll tell you if you're close."),
]
# silence after each piece (s, output time); drags live in the long ones
GAP = {"hook": 0.4, "merc": 0.25, "merc2": 0.45, "st1": 0.4, "st2": 0.5, "st3": 0.45, "glA": 0.3, "glD": 0.9, "glB": 0.5, "auA": 1.2, "auB": 0.45,
       "ruA": 0.3, "ruD": 1.2, "ruB": 0.5, "akA": 1.2, "akB": 0.5, "euA": 1.2, "euB": 0.45, "ilA": 0.3, "ilD": 1.2, "ilB": 0.5,
       "eeA": 0.5, "eeB": 0.45, "where": 0.5, "dom1": 0.3, "dom2": 0.5, "write": 0.8}
# cards: (piece where the card starts, English words on it); a card stays until the next card starts
CARDS = [("hook", 5), ("merc", 6), ("st1", 4), ("st2", 5), ("st3", 4), ("glA", 3), ("glB", 5), ("auA", 4), ("auB", 5), ("ruA", 4), ("ruB", 5),
         ("akA", 5), ("akB", 5), ("euA", 5), ("euB", 6), ("ilA", 4), ("ilB", 6), ("eeA", 3), ("eeB", 4), ("where", 4), ("dom1", 13), ("write", 10)]
ids = [p[0] for p in P]
def clip(src, a, b):
    if src == "ts": a0, b0 = max(0.0, a - 0.05) / TEMPO, (b + 0.12) / TEMPO; s = X[int(a0 * SR):int(b0 * SR)].copy(); lead = (a - max(0.0, a - 0.05)) / TEMPO
    else: a0, b0 = a - 0.05, b + 0.12; s = G[int(a0 * SR):int(b0 * SR)].copy(); lead = 0.05
    f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f); return s, lead
clips = [clip(p[1], p[2], p[3]) for p in P]
def rms_db(s):
    v = s[np.abs(s) > 0.01]; return 20 * np.log10(np.sqrt(np.mean(v ** 2)) + 1e-9)
ts_db = 0 and np.median([rms_db(c[0]) for c, p in zip(clips, P) if p[1] == "ts"])
for i, p in enumerate(P):
    if p[1] == "gr":
        g = 10 ** ((ts_db - rms_db(clips[i][0])) / 20); clips[i] = (clips[i][0] * g, clips[i][1]); print("growth clip", p[0], "gain", round(20 * np.log10(g), 2), "dB")
LEAD = 0.12
def layout():
    st = []; t = LEAD
    for i, p in enumerate(P):
        d = (p[3] - p[2]) / (TEMPO if p[1] == "ts" else 1); st.append([t, t + d]); t += d + GAP[p[0]]
    return st
# pad gaps until every card meets max(3, words / 3 + 1) s (card from its piece start - 0.15 to the next card's start - 0.15)
for _ in range(50):
    seg = layout(); ok = True
    for k, (pid, w) in enumerate(CARDS):
        i = ids.index(pid); s0 = 0 if k == 0 else seg[i][0] - 0.15
        if k + 1 < len(CARDS): e0 = seg[ids.index(CARDS[k + 1][0])][0] - 0.15; last = ids.index(CARDS[k + 1][0]) - 1
        else: e0 = seg[-1][1] + GAP["write"]; last = len(P) - 1
        need = max(3.0, w / 3 + 1) + 0.05
        if e0 - s0 < need: GAP[ids[last]] += need - (e0 - s0); ok = False
    if ok: break
seg = layout(); T_END = seg[-1][1] + GAP["write"]
y = np.zeros(int((T_END + 1) * SR))
for (s, lead), (a, b) in zip(clips, seg):
    i = int((a - lead) * SR); y[i:i + len(s)] += s
y = y[:int(T_END * SR)]
sf.write(f"{HERE}/vo3/vo_v3.wav", y.astype(np.float32), SR, subtype="FLOAT")
seg = [[round(a, 3), round(b, 3)] for a, b in seg]
json.dump({"pieces": {p[0]: s for p, s in zip(P, seg)}, "order": ids, "gaps": {k: round(v, 3) for k, v in GAP.items()}, "t_end": round(T_END, 3),
           "cards": [c[0] for c in CARDS], "tempo": TEMPO, "pitch": "rubberband pitch=0.9715 formant=preserved, bass g=2 f=135",
           "src": "vo3/raw.wav (tts_v3.txt), pitch + bass, clean_vo, atempo 1.1"}, open(f"{HERE}/vo3/segs_v3.json", "w"), indent=1)
open(f"{HERE}/subs_v3.txt", "w").write("\n".join(p[4] for p in P) + "\n")
json.dump({"segs": seg}, open(f"{HERE}/subs_segs_v3.json", "w"))
os.remove(fast)
print("T_END", round(T_END, 2)); [print(f"{p[0]:6s} {a:6.2f} {b:6.2f}  gap {GAP[p[0]]:.2f}") for p, (a, b) in zip(P, seg)]
