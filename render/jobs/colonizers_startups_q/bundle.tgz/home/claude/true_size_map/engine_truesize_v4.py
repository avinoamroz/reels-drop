"""True size reel v4 (v3 visuals, retimed to the Cartesia narration vo4/segs_v4.json). v3: True size reel v3 (v2 + new expressive narration vo3/, new domino ending). v2 notes:
True size reel v2 (Instagram 1080x1920, 30 fps) for @expressenglishcom with @noamroz__, to video-guidelines v1 (20 Oct 2026).
Reuses v1 (engine_truesize.py): data (figures.json), geometry (geo.py), drag on the sphere (move), Mercator/Equal Earth formulas.
New in v2: big type (hook 132, headlines 120, body 70, Hebrew 62, labels 58/54, notes 42), cameras cropped to each comparison
(the map is full bleed, shapes framed into y 690 to 1440 under the counter card), a globe that unrolls into Mercator with equal
circles (Tissot) ballooning toward the poles, a Looks vs Real counter per pair, a zoom in after each drag, SPEAKER CTA.
Timing comes from vo/segs_v2.json (build_vo_v2.py): every scene cue is tied to a narration piece.
usage: nice -n 15 python3 engine_truesize_v2.py [--snaps 0.5,12] | [--frames A:B --part N] | [--mux]"""
import sys, os, json, math, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon, box
from shapely import affinity
import geo

ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--frames"); ap.add_argument("--part"); ap.add_argument("--mux", action="store_true")
A = ap.parse_args()
HERE = os.path.dirname(os.path.abspath(__file__)); S = 2; W, H, FPS = 1080, 1920, 30
FIG = json.load(open(f"{HERE}/figures.json")); VO = json.load(open(f"{HERE}/vo4/segs_v4.json"))
PC = {k: tuple(v) for k, v in VO["pieces"].items()}; T_END = VO["t_end"]; N = int(round(T_END * FPS))
def pa(k): return PC[k][0]
def pb(k): return PC[k][1]

def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
def al(c, a): return c[:3] + (int(max(0, min(1, a)) * c[3]),)
SKY = hx("#45A4DD"); SKYL = hx("#8FD0F7"); WHITE = hx("#FFFFFF"); YEL = hx("#FFCC3D")
SEA = hx("#0B1A35"); LAND = hx("#1E3D72"); BORDER = (125, 165, 225, 95); TARGET = hx("#2D5AA0"); CARD = hx("#0E1E3A", 236)
GOLD = hx("#D2AA53"); GOLDD = hx("#B8923F"); GREENC = (46, 204, 113, 255); GRID = (170, 200, 240, 70)
FONT = {w: f"{HERE}/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(round(sz * S)), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONT[w], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
# type scale (guidelines: headline 110 to 140, body 64 to 84, Hebrew 56 to 72, labels 52+, nothing under 40)
HOOK, HLS, BIG, BD, HE, LB_EN, LB_HE, NOTE = 132, 118, 116, 70, 62, 58, 54, 42

# ---------------------------------------------------------------- copy
C = FIG["cited"]; PR = FIG["pairs"]
def mk(v): return f"{v / 1e6:.2f}M km²" if v >= 1e6 else f"{v:,} km²"
def fx(v): return f"{v:.0f}x" if abs(v - round(v)) < 0.05 and v >= 10 else f"{v:.1f}x"
def looks(key):   # how much bigger the first shape looks on Mercator (from the polygons as drawn)
    return 1 / PR[key]["mercator_apparent"]
def real_ok(key, shown):
    r = PR[key]["cited"]; assert abs(r - shown) <= 0.05 * shown, (key, r, shown); return shown
T = {
 "hook":  ("Greenland is lying to you.", "גרינלנד משקרת לכם."),
 "merc":  ("The map we all grew up with", "המפה שכולנו גדלנו עליה"),
 "s0":    ("Shapes right, sizes stretched", "הצורות נכונות, הגדלים מתוחים"),
 "s1":    ("Same size on the globe", "באותו גודל על הגלובוס"),
 "s2":    ("Bigger near the poles", "גדולים יותר ליד הקטבים"),
 "ee1":   ("Mercator keeps shapes.", "מרקטור שומרת על הצורות."),
 "ee2":   ("Equal Earth keeps sizes.", "Equal Earth שומרת על הגדלים."),
 "where": ("Where are YOU from?", "מאיפה אתם?"),
 "dom":   ("Let's play dominoes", ""),
 "dom2":  ("Give me 2 countries you think are the same size", "תנו לי 2 מדינות שלדעתכם באותו גודל"),
 "write": ("Write them in the comments.", "כתבו בתגובות ואגיד לכם אם צדקתם"),
 "write2": ("I'll tell you if you're close.", ""),
}
NAMES = {"Greenland": "גרינלנד", "Africa": "אפריקה", "Australia": "אוסטרליה", "Russia": "רוסיה", "Alaska": "אלסקה", "Brazil": "ברזיל",
         "Europe": "אירופה", "South America": "דרום אמריקה", "Israel": "ישראל", "New Jersey": "ניו ג'רזי"}
# pair cards: looks value, looks sub (EN), looks HE, real value, real sub (EN), real HE, note
assert looks("Africa/Greenland") > 0.9 and looks("Africa/Greenland") < 1.15 and looks("Brazil/Alaska") > 0.85 and looks("Brazil/Alaska") < 1.1
PAIR = {
 "gl": ("same size", "Greenland and Africa", "על המפה: באותו גודל", real_ok("Africa/Greenland", 14), "Africa is bigger", "אפריקה גדולה פי 14",
        [f"Greenland {mk(C['Greenland'])} · Africa {mk(C['Africa'])}"]),
 "au": (fx(1 / looks("Australia/Greenland") ** -1 if False else 1 / PR["Australia/Greenland"]["mercator_apparent"]), "Greenland looks bigger", "גרינלנד נראית גדולה פי 3.6",
        real_ok("Australia/Greenland", 3.5), "Australia is bigger", "אוסטרליה גדולה פי 3.5", [f"Greenland {mk(C['Greenland'])} · Australia {mk(C['Australia'])}"]),
 "ru": (fx(1 / PR["Africa/Russia"]["mercator_apparent"]), "Russia looks bigger", "רוסיה נראית גדולה פי 2.5",
        real_ok("Africa/Russia", 1.8), "Africa is bigger", "אפריקה גדולה פי 1.8", [f"Russia {mk(C['Russia'])} · Africa {mk(C['Africa'])}"]),
 "ak": ("same size", "Alaska and Brazil", "על המפה: באותו גודל", real_ok("Brazil/Alaska", 4.9), "Brazil is bigger", "ברזיל גדולה פי 4.9",
        [f"Alaska {mk(C['Alaska'])} · Brazil {mk(C['Brazil'])}"]),
 "eu": (fx(1 / PR["South America/Europe"]["mercator_apparent"]), "Europe looks bigger", "אירופה נראית גדולה פי 1.7",
        real_ok("South America/Europe", 1.7), "South America is bigger", "דרום אמריקה גדולה פי 1.7", [f"Europe {mk(C['Europe'])} · S. America {mk(C['South America'])}"]),
 "il": (None, "And Israel?", "ומה עם ישראל?", real_ok("New Jersey/Israel", 1.0), "About the same size", "בערך באותו גודל",
        [f"Israel {mk(C['Israel'])}, official area (excl. West Bank, Gaza)", f"New Jersey {mk(C['New Jersey'])} · Source: Britannica"]),
}
assert PAIR["au"][0] == "3.6x" and PAIR["ru"][0] == "2.5x" and PAIR["eu"][0] == "1.7x", [PAIR[k][0] for k in ("au", "ru", "eu")]
ALL = [s for v in T.values() for s in v] + list(NAMES) + list(NAMES.values()) + [str(x) for v in PAIR.values() for x in v[:6]] + [n for v in PAIR.values() for n in v[6]]
for s_ in ALL:
    if chr(0x2013) in s_ or chr(0x2014) in s_: sys.exit(f"dash character in text: {s_!r}")

# ---------------------------------------------------------------- geometry + LODs (as v1)
SH = geo.shapes()
LODT = [0.0015, 0.006, 0.02, 0.06, 0.16]
def rings_of(g, tol, min_area):
    out = []
    for p in geo.parts(g.simplify(tol, preserve_topology=False) if tol else g):
        if isinstance(p, Polygon) and p.area >= min_area and not p.is_empty: out.append(np.array(p.exterior.coords))
    return out
BASE = []
for tol in LODT:
    lv = {}
    for k, g in geo.COUNTRIES.items():
        rs = rings_of(g, tol, 0 if k in ("Israel", "Palestine") else tol * tol * 4)
        if rs: lv[k] = rs
    BASE.append(lv)
HL = [{k: rings_of(g, tol, tol * tol * 4) for k, g in SH.items()} for tol in LODT]
def lod_for(s):
    dpp = 57.3 / s
    for i in range(len(LODT) - 1, -1, -1):
        if LODT[i] <= dpp * 0.7: return i
    return 0
def _green_lines():
    isr = geo.COUNTRIES["Israel"].buffer(0.015); out = []
    for poly in geo.parts(geo.COUNTRIES["Palestine"]):
        g = poly.exterior.intersection(isr)
        for ln in (g.geoms if hasattr(g, "geoms") else [g]):
            if ln.geom_type == "LineString" and ln.length > 0.01: out.append(np.array(ln.coords))
    return out
GREEN_LINES = _green_lines()
CENT = {k: tuple(v) for k, v in FIG["centroid"].items()}

# ---------------------------------------------------------------- projections + cameras
A1, A2, A3, A4 = 1.340264, -0.081106, 0.000893, 0.003796; EEK = math.pi / 2.70663
def fwd(lon, lat, m=0.0):
    lam = np.radians(lon); phi = np.radians(np.clip(lat, -85, 85))
    X, Y = lam, np.log(np.tan(np.pi / 4 + phi / 2))
    if m <= 0: return X, Y
    th = np.arcsin(np.sqrt(3) / 2 * np.sin(phi))
    Xe = 2 * np.sqrt(3) * lam * np.cos(th) / (3 * (9 * A4 * th ** 8 + 7 * A3 * th ** 6 + 3 * A2 * th ** 2 + A1))
    Ye = A4 * th ** 9 + A3 * th ** 7 + A2 * th ** 3 + A1 * th
    return (1 - m) * X + m * EEK * Xe, (1 - m) * Y + m * EEK * Ye
CY0 = 900
def scr(X, Y, cam):
    cx, cy, s = cam; return (540 + (X - cx) * s) * S, (CY0 - (Y - cy) * s) * S
REG = (60, 1020, 700, 1440)            # where the compared shapes are framed (x0, x1, y0, y1), under the counter card
def fit_rings(rings, m=0.0, reg=REG, pad=1.0):
    pts = np.concatenate(rings); X, Y = fwd(pts[:, 0], pts[:, 1], m)
    x0, x1, y0, y1 = reg; s = min((x1 - x0) / (X.max() - X.min()), (y1 - y0) / (Y.max() - Y.min())) * pad
    Xm, Ym = (X.max() + X.min()) / 2, (Y.max() + Y.min()) / 2
    return (Xm - ((x0 + x1) / 2 - 540) / s, Ym + ((y0 + y1) / 2 - CY0) / s, s)
def bbox_ring(lon0, lon1, lat0, lat1):
    return np.array([[lon0, lat0], [lon1, lat0], [lon1, lat1], [lon0, lat1], [(lon0 + lon1) / 2, 0.0 if lat0 < 0 < lat1 else lat0]])
def ease(u): u = max(0.0, min(1.0, u)); return u * u * (3 - 2 * u)
def ease3(u): u = max(0.0, min(1.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def lerpcam(a, b, u):
    """zoom in log scale; the centre moves in step with 1/scale so the framed point glides on screen (no overshoot on big zooms)"""
    s = math.exp(math.log(a[2]) + (math.log(b[2]) - math.log(a[2])) * u)
    w = u if abs(a[2] - b[2]) < 1e-6 * a[2] else (1 / s - 1 / a[2]) / (1 / b[2] - 1 / a[2])
    return (a[0] + (b[0] - a[0]) * w, a[1] + (b[1] - a[1]) * w, s)
def ramp(t, t0, t1): return max(0.0, min(1.0, (t - t0) / (t1 - t0))) if t1 > t0 else float(t >= t0)
def win(t, t0, t1, fi=0.3, fo=0.3): return min(ramp(t, t0, t0 + fi), 1 - ramp(t, t1 - fo, t1))

def move(rings, c0, c1):
    """v1: rotate rings on the sphere (latitude along the home meridian, then longitude about the pole), north up, true size"""
    lam0, phi0 = math.radians(c0[0]), math.radians(c0[1]); lam1, phi1 = math.radians(c1[0]), math.radians(c1[1])
    a = -(phi1 - phi0); ca, sa = math.cos(a), math.sin(a); out = []
    for r in rings:
        lam = np.radians(r[:, 0]) - lam0; phi = np.radians(r[:, 1])
        x = np.cos(phi) * np.cos(lam); y = np.cos(phi) * np.sin(lam); z = np.sin(phi)
        x2 = x * ca + z * sa; z2 = -x * sa + z * ca
        out.append(np.stack([np.degrees(np.arctan2(y, x2) + lam1), np.degrees(np.arcsin(np.clip(z2, -1, 1)))], 1))
    return out
def path(c0, c1, u): return (c0[0] + (c1[0] - c0[0]) * u, c0[1] + (c1[1] - c0[1]) * u)

# ---------------------------------------------------------------- drawing helpers
BG = None
def bg():
    global BG
    if BG is None:
        r = np.linspace(0, 1, H * S)[:, None]
        stops = [(0.0, hx("#0E1E3A")), (0.55, hx("#163261")), (1.0, hx("#2749D3"))]
        g = np.concatenate([np.interp(r, [p for p, _ in stops], [c[i] for _, c in stops]) for i in range(4)], 1)
        BG = Image.fromarray((g[:, None, :] * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
    return BG.copy()
QA = []
def is_he(s): return any("֐" <= ch <= "׿" for ch in s)
def txt(d, x, y, s, sz, col, w=800, anchor="mm", alpha=1.0, stroke=0, tag="text"):
    if alpha <= 0.01 or not s: return
    f = font(sz, w); c = al(col, alpha)
    kw = dict(font=f, anchor=anchor, direction="rtl" if is_he(s) else None)
    if stroke: kw.update(stroke_width=int(stroke * S), stroke_fill=(6, 14, 30, int(235 * alpha)))
    d.text((x * S, y * S), s, fill=c, **kw)
    if A.snaps and alpha > 0.5:
        bb = d.textbbox((x * S, y * S), s, font=f, anchor=anchor, direction=kw["direction"]); QA.append((tag, s, sz, [v / S for v in bb]))
def tw(s, sz, w): return font(sz, w).getlength(s) / S
def wrap(s, sz, w, maxw):
    """balanced greedy wrap (no lone last word)"""
    ws = s.split(); f = font(sz, w); out = [""]
    for word in ws:
        cand = (out[-1] + " " + word).strip()
        if f.getlength(cand) <= maxw * S: out[-1] = cand
        else: out.append(word)
    n = len(out)
    if n == 1: return out
    best = None
    def rec(i, k, acc):
        nonlocal best
        if k == 1:
            l = " ".join(ws[i:]); cand = acc + [l]; mw = max(f.getlength(x) for x in cand)
            if f.getlength(l) <= maxw * S and (best is None or mw < best[0]): best = (mw, cand)
            return
        for j in range(i + 1, len(ws) - k + 2): rec(j, k - 1, acc + [" ".join(ws[i:j])])
    rec(0, n, []); return best[1] if best else out
def rrect(im, box_, rad, fill_, edge=None, ew=2):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([v * S for v in box_], radius=rad * S, fill=fill_, outline=edge, width=int(ew * S) if edge else 0)
    im.alpha_composite(lay)

def rich(d, y, parts, sz, a, tag):
    """one centred line made of (text, colour) parts"""
    f = font(sz, 900); wt = sum(f.getlength(p) for p, _ in parts) / S; x = 540 - wt / 2
    for p, c in parts:
        txt(d, x, y, p, sz, c, 900, "lm", a, tag=tag); x += f.getlength(p) / S

def card_top(im, lines, a, y0=272, rise_px=14):
    """top card: lines = [(kind, payload)], kind in big (parts list) / hl (EN) / sub (EN) / he / note. Returns bottom y."""
    if a <= 0.01: return y0
    spec = {"kick": (78, 900, 1.25), "he58": (58, 800, 1.28), "hook": (HOOK, 900, 1.08), "big": (BIG, 900, 1.12), "hl": (HLS, 900, 1.1), "sub": (BD, 800, 1.22), "he": (HE, 800, 1.28), "note": (NOTE, 700, 1.32)}
    rows = []
    for kind, pl in lines:
        sz, w, lh = spec[kind]
        if kind == "big": rows.append((kind, pl, sz, w, sz * lh))
        else:
            for l in wrap(pl, sz, w, 940): rows.append((kind, l, sz, w, sz * lh))
    gap_he = 10; hgt = sum(r[4] for r in rows) + gap_he
    rise = (1 - ease(a)) * rise_px
    rrect(im, (34, y0 - 22 + rise, 1046, y0 + hgt + 22 + rise), 38, al(CARD, 0.86 * a))
    d = ImageDraw.Draw(im); y = y0 + rise
    for i, (kind, l, sz, w, lh) in enumerate(rows):
        if kind in ("he", "he58") and (i == 0 or rows[i - 1][0] not in ("he", "he58")): y += gap_he
        cy = y + lh / 2
        if kind == "big": rich(d, cy, l, sz, a, "big")
        else:
            col = {"kick": YEL, "he58": SKYL, "hook": WHITE, "hl": WHITE, "sub": WHITE, "he": SKYL, "note": SKYL}[kind]
            txt(d, 540, cy, l, sz, col, w, "mm", a, tag=kind)
        y += lh
    return y0 + hgt + 22

def label(d, cam, lonlat, name, a, m=0.0, dx=0, dy=0, he=True):
    if a <= 0.01: return
    X, Y = fwd(np.array([lonlat[0]]), np.array([lonlat[1]]), m); x, y = scr(X[0], Y[0], cam); x, y = x / S + dx, y / S + dy
    wmax = max(tw(name, LB_EN, 900), tw(NAMES[name], LB_HE, 800)) / 2; x = min(max(x, 70 + wmax), 1010 - wmax)
    txt(d, x, y - 29, name, LB_EN, WHITE, 900, "mm", a, stroke=4, tag="label")
    if he: txt(d, x, y + 29, NAMES[name], LB_HE, SKYL, 800, "mm", a, stroke=4, tag="label")

def proj_rings(rings, cam, m, wrap_=False):
    out = []
    for r in rings:
        for sh in ((0, -360, 360) if (wrap_ and m <= 0) else (0,)):
            X, Y = fwd(r[:, 0] + sh, r[:, 1], m); x, y = scr(X, Y, cam)
            if x.max() < -50 or x.min() > (W + 50) * S or y.max() < -50 or y.min() > (H + 50) * S: continue
            out.append(np.stack([x, y], 1))
    return out
def fill(d, pts_list, fillc, edge=None, ew=1.0):
    for p in pts_list:
        if len(p) < 3: continue
        d.polygon([tuple(q) for q in p], fill=fillc)
        if edge: d.line([tuple(q) for q in p] + [tuple(p[0])], fill=edge, width=max(1, int(ew * S)), joint="curve")
def world_frame(cam, m):
    L = 180 if m > 0 else 540
    lats = np.linspace(-60, 84, 80); lons = np.linspace(-L, L, 120)
    ring = np.concatenate([np.stack([np.full(80, -float(L)), lats], 1), np.stack([lons, np.full(120, 84.0)], 1),
                           np.stack([np.full(80, float(L)), lats[::-1]], 1), np.stack([lons[::-1], np.full(120, -60.0)], 1)])
    return proj_rings([ring], cam, m)
def israel(d, rings_isr, rings_pal, big):
    fill(d, rings_isr, GOLD); fill(d, rings_pal, GOLDD)
def base_map(im, cam, m, hl=None):
    lv = lod_for(cam[2]); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    fill(d, world_frame(cam, m), SEA)
    for k, rs in BASE[lv].items():
        if k in ("Israel", "Palestine"): continue
        fill(d, proj_rings(rs, cam, m, True), LAND, BORDER, 1.0)
    for k, rs in (hl or {}).items():
        fill(d, proj_rings(HL[lv][k], cam, m, True), rs.get("fill", TARGET), rs.get("edge"), rs.get("ew", 2.0))
    isr = proj_rings(BASE[lv]["Israel"], cam, m); fill(d, isr, GOLD); fill(d, proj_rings(BASE[lv]["Palestine"], cam, m), GOLDD)
    if isr and max(p[:, 1].max() - p[:, 1].min() for p in isr) > 40 * S:
        for ln in GREEN_LINES:
            for q in proj_rings([ln], cam, m): d.line([tuple(v) for v in q], fill=GREENC, width=int(3.5 * S), joint="curve")
    im.alpha_composite(lay)
def lifted(im, cam, name, c0, c1, u, a=1.0, lift=1.0, ghost=1.0, m=0.0, fa=205):
    lv = lod_for(cam[2]); rs = HL[lv][name]; lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    if ghost > 0.01:
        for p in proj_rings(rs, cam, m, True): d.line([tuple(q) for q in p] + [tuple(p[0])], fill=al(SKYL, 0.8 * ghost * a), width=int(2.4 * S))
    mv = move(rs, c0, path(c0, c1, u)) if u > 0 else rs
    pp = proj_rings(mv, cam, m, True)
    if lift > 0.01:
        sh = [p + np.array([8 * S * lift, 12 * S * lift]) for p in pp]; fill(d, sh, (0, 0, 0, int(95 * a * lift)))
    fill(d, pp, al(hx("#45A4DD", fa), a), al(WHITE, a), 3.0)
    im.alpha_composite(lay)

# ---------------------------------------------------------------- globe <-> Mercator (unroll)
GLOBE_R, GLOBE_CY = 430, 1060
GLB = {k: geo.COUNTRIES[k].simplify(0.06, preserve_topology=False) for k in geo.COUNTRIES}
WORLD = fit_rings([bbox_ring(-150, 130, -60, 84)], 0, (60, 1020, 620, 1480))       # flat world, cropped at the sides (Mercator wraps)
WORLD = (math.radians(-10), WORLD[1], WORLD[2])
def unroll_xy(lon, lat, t, lamc):
    """t = 0: orthographic globe (centre lon lamc, lat 0); t = 1: the Mercator WORLD camera. The globe opens like a cylinder
    whose radius grows (curvature a = 1 - t); x is blended from R cos(lat) to the flat scale, y from R sin(lat) to Mercator y."""
    lam = np.radians(np.asarray(lon) - lamc) if lamc is not None else np.radians(np.asarray(lon)); phi = np.radians(np.asarray(lat)); a = max(1 - t, 1e-4); e = t
    s = WORLD[2]; R = GLOBE_R * (1 - e) + 0 * e
    xs = np.sin(lam * a) / a * (R * np.cos(phi) + e * s)
    ym = np.log(np.tan(np.pi / 4 + np.clip(phi, -1.48, 1.48) / 2))
    yu = (1 - e) * GLOBE_R * np.sin(phi) + e * s * ym
    yeq = (1 - e) * GLOBE_CY + e * (CY0 + WORLD[1] * s)
    return (540 + xs) * S, (yeq - yu) * S, np.cos(lam * a) >= -1e-6
def vis_lim(t): return 180.0 if t >= 0.5 else min(180.0, 90.0 / max(1 - t, 1e-4))
def clip_geom(g, lamc, L):
    out = []
    for sh in (-360, 0, 360):
        gg = affinity.translate(g, sh - lamc).intersection(box(-L, -90, L, 90))
        for p in geo.parts(gg):
            if isinstance(p, Polygon) and not p.is_empty and p.area > 0.02: out.append(np.array(p.exterior.coords))    # relative lon
    return out
def globe_map(im, t, lamc, circles=0.0, grid=1.0, circ_grow=None):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay); L = vis_lim(t)
    def poly(ring, fillc, edge=None, ew=1.0):     # ring in relative lon
        x, y, v = unroll_xy(ring[:, 0], ring[:, 1], t, None)
        p = np.stack([x, y], 1)
        if len(p) >= 3: fill(d, [p], fillc, edge, ew)
    lo, hi = -90 + 30 * t, 90 - 6 * t
    la = np.linspace(lo, hi, 90); lo_ = np.linspace(-L, L, 90)
    sea = np.concatenate([np.stack([np.full(90, -L), la], 1), np.stack([lo_, np.full(90, hi)], 1), np.stack([np.full(90, L), la[::-1]], 1), np.stack([lo_[::-1], np.full(90, lo)], 1)])
    poly(sea, SEA)
    for k, g in GLB.items():
        rs = clip_geom(g, lamc, L) if L < 180 else clip_geom(g, lamc, 180)
        c = GOLD if k == "Israel" else GOLDD if k == "Palestine" else LAND
        for r in rs: poly(r, c, None if k in ("Israel", "Palestine") else BORDER, 1.0)
    if grid > 0.01:
        for p_ in range(-60, 90, 15):
            if not lo <= p_ <= hi: continue
            ln = np.stack([np.linspace(-L, L, 120), np.full(120, float(p_))], 1); x, y, _ = unroll_xy(ln[:, 0], ln[:, 1], t, None)
            d.line(list(zip(x, y)), fill=al(SKY if p_ == 0 else GRID, grid), width=int((4 if p_ == 0 else 2) * S))
        for m_ in range(-180, 181, 30):
            rel = (m_ - lamc + 180) % 360 - 180
            if abs(rel) > L: continue
            ln = np.stack([np.full(80, float(rel)), np.linspace(lo, hi, 80)], 1); x, y, _ = unroll_xy(ln[:, 0], ln[:, 1], t, None)
            d.line(list(zip(x, y)), fill=al(GRID, grid), width=int(2 * S))
    if circles > 0.01:      # Tissot: equal 900 km circles on the globe
        dd = 900 / 6371.0
        for i, la0 in enumerate((0, 30, -30, 55, -50, 72)):
            k = circles if circ_grow is None else circles * ease(ramp(circ_grow, i * 0.3, i * 0.3 + 0.5))
            if k <= 0.01: continue
            for lo0 in range(-150, 181, 45):
                rel = (lo0 - lamc + 180) % 360 - 180
                if abs(rel) > min(L, 179) - 8 or (t < 0.5 and abs(rel) > 80): continue
                ph0 = math.radians(la0); th = np.linspace(0, 2 * np.pi, 60); r_ = dd * (0.5 + 0.5 * k)
                lat = np.arcsin(np.sin(ph0) * np.cos(r_) + np.cos(ph0) * np.sin(r_) * np.cos(th))
                lon = math.radians(lo0) + np.arctan2(np.sin(th) * np.sin(r_) * np.cos(ph0), np.cos(r_) - np.sin(ph0) * np.sin(lat))
                x, y, v = unroll_xy((np.degrees(lon) - lamc + 180) % 360 - 180, np.degrees(lat), t, None)
                if not v.all(): continue
                fill(d, [np.stack([x, y], 1)], al(hx("#FFCC3D", 120), k), al(YEL, k), 2.6)
    im.alpha_composite(lay)
def lat_labels(d, t, lamc, a):
    for la, s in ((0, "0°"), (30, "30°N"), (60, "60°N"), (75, "75°N")):
        x, y, _ = unroll_xy(np.array([lamc - 70.0]), np.array([float(la)]), t, lamc)
        if y[0] / S < 640: continue
        txt(d, 82, y[0] / S - 30, s, 44, YEL if la == 0 else SKYL, 800, "lm", a, stroke=3, tag="grid")

# ---------------------------------------------------------------- beats (from the narration pieces)
B = [("hook", 0.0), ("merc", pa("merc") - 0.15), ("stretch", pa("st1") - 0.15), ("gl", pa("glA") - 0.15), ("au", pa("auA") - 0.15),
     ("ru", pa("ruA") - 0.15), ("ak", pa("akA") - 0.15), ("eu", pa("euA") - 0.15), ("il", pa("ilA") - 0.15), ("ee", pa("eeA") - 0.15),
     ("where", pa("where") - 0.15), ("dom", pa("dom1") - 0.15), ("write", pa("write") - 0.15)]
BS = {k: s for k, s in B}; BE = {B[i][0]: (B[i + 1][1] if i + 1 < len(B) else T_END) for i in range(len(B))}
def beat_of(t): return max((k for k, s in B if s <= t + 1e-9), key=lambda k: BS[k])

HOOKCAM = fit_rings(HL[3]["Greenland"] + HL[3]["Africa"], 0, (60, 1020, 690, 1450))
# pairs: (dragged, from, to, target, cue pieces (A, D or None, B), extra rings in the A camera, final label offsets)
DR = {
 "gl": ("Greenland", CENT["Greenland"], (CENT["Africa"][0] + 2, CENT["Africa"][1] + 4), "Africa", ("glA", "glD", "glB")),
 "au": ("Greenland", CENT["Greenland"], (CENT["Australia"][0] + 1, CENT["Australia"][1] + 1), "Australia", ("auA", None, "auB")),
 "ru": ("Russia", CENT["Russia"], (CENT["Africa"][0] + 4, CENT["Africa"][1] + 4), "Africa", ("ruA", "ruD", "ruB")),
 "ak": ("Alaska", CENT["Alaska"], CENT["Brazil"], "Brazil", ("akA", None, "akB")),
 "eu": ("Europe", CENT["Europe"], (CENT["South America"][0] + 2, CENT["South America"][1] + 2), "South America", ("euA", None, "euB")),
}
CAMA, CAMB = {}, {}
for k, (nm, c0, c1, tg, _) in DR.items():
    CAMA[k] = fit_rings(HL[3][nm] + HL[3][tg] + move(HL[3][nm], c0, c1), 0)
    CAMB[k] = fit_rings(HL[3][tg] + move(HL[3][nm], c0, c1), 0, (60, 1020, 720, 1430))
NJ_CLOSE = fit_rings([bbox_ring(-76.2, -73.4, 38.6, 41.6)], 0, (60, 1020, 760, 1400))
IL_CLOSE = fit_rings([bbox_ring(33.6, 36.6, 29.2, 33.6)], 0, (60, 1020, 850, 1440))
EE_M = HOOKCAM
EE_E = fit_rings(HL[3]["Greenland"] + HL[3]["Africa"] + [bbox_ring(-75, 60, -38, 84)], 1, (40, 1040, 790, 1440))
ENDCAM = fit_rings([bbox_ring(-180, 180, -60, 84)], 1, (20, 1060, 820, 1460))
# label anchors (lon, lat, dx, dy) for the target and the dragged shape once landed; home label offsets
LBL = {"gl": dict(home=(0, 40), tgt=(20, -22, 0, 30), drg=(0, -150)), "au": dict(home=(0, 40), tgt=(134, -30, 0, 40), drg=(0, -130)),
       "ru": dict(home=(0, 0), tgt=(22, -15, 0, 30), drg=(0, -190)), "ak": dict(home=(0, 30), tgt=(-50, -14, 0, 40), drg=(0, -110)),
       "eu": dict(home=(0, 20), tgt=(-62, -25, 0, 30), drg=(0, -130))}

def drag_scene(im, key, t):
    nm, c0, c1, tg, (pA, pD, pB) = DR[key]; b0, b1 = BS[key], BE[key]
    tB = pa(pB) - 0.15; td0 = pa(pD) + 0.1 if pD else pb(pA) + 0.15; td1 = tB - 0.05
    prev = {"gl": HOOKCAM_WORLD_END, "au": CAMB["gl"], "ru": CAMB["au"], "ak": CAMB["ru"], "eu": CAMB["ak"]}[key]
    cam = lerpcam(prev, CAMA[key], ease3(ramp(t, b0, b0 + 1.1)))
    zu = ease3(ramp(t, tB + 0.1, tB + 1.3)); cam = lerpcam(cam, CAMB[key], zu)
    u = ease3(ramp(t, td0, td1)); lift = ramp(t, td0 - 0.6, td0 - 0.1) * (1 - 0.6 * ramp(t, td1, td1 + 0.6))
    hl = {tg: {"fill": TARGET, "edge": al(WHITE, 0.95), "ew": 2.6}}
    if key == "ru": hl["Russia"] = {"fill": LAND, "edge": al(SKYL, 0.6), "ew": 1.6}
    base_map(im, cam, 0, hl)
    fo = 1 - ramp(t, b1 - 0.35, b1)
    lifted(im, cam, nm, c0, c1, u, a=ramp(t, b0 + 0.3, b0 + 0.8) * fo, lift=lift, ghost=ramp(t, td0, td0 + 0.5) * fo * (1 - zu))
    d = ImageDraw.Draw(im); L = LBL[key]
    label(d, cam, CENT[tg], tg, win(t, b0 + 0.3, tB - 0.1, 0.3, 0.25), 0, 0, 0)
    label(d, cam, c0, nm, win(t, b0 + 0.3, td0 + 0.3, 0.3, 0.3), 0, *L["home"])
    la = win(t, tB + 0.9, b1, 0.35, 0.3); lt = L["tgt"]
    label(d, cam, lt[:2], tg, la, 0, lt[2], lt[3]); label(d, cam, c1, nm, la, 0, *L["drg"])
    lv, lsub, lhe, rv, rsub, rhe, note = PAIR[key]
    aA = win(t, b0, tB, 0.01 if key == "gl" else 0.3, 0.25); aB = win(t, tB, b1, 0.25, 0.3)
    if aA > 0.01:
        card_top(im, [("big", [("Looks: ", SKYL), (lv, WHITE if lv == "same size" else YEL)]), ("sub", lsub), ("he", lhe)], aA)
    if aB > 0.01:
        k = ease3(ramp(t, tB + 0.1, tB + 1.1)); v = 1 + (rv - 1) * k
        card_top(im, [("big", [("Real: ", SKYL), (fx(v) if k < 1 else fx(rv), YEL)]), ("sub", rsub), ("he", rhe)] + [("note", n) for n in note], aB)
HOOKCAM_WORLD_END = None

def il_scene(im, t):
    b0, b1 = BS["il"], BE["il"]; c0, c1 = CENT["New Jersey"], (35.15, 31.45)
    tB = pa("ilB") - 0.15; td0 = pa("ilD") + 0.1; td1 = tB - 0.05; u = ease3(ramp(t, td0, td1))
    if t < td0: cam = lerpcam(CAMB["eu"], NJ_CLOSE, ease3(ramp(t, b0, b0 + 1.0)))
    else:   # camera rides with New Jersey across the Atlantic, pulling out half way (v1)
        cc = path(c0, c1, u); X, Y = fwd(np.array([cc[0]]), np.array([cc[1]])); s0 = NJ_CLOSE[2]; s1 = IL_CLOSE[2]
        s = math.exp(math.log(s0) + (math.log(s1) - math.log(s0)) * u - 2.2 * math.sin(math.pi * u))
        off0 = fwd(np.array([c0[0]]), np.array([c0[1]])); off1 = fwd(np.array([c1[0]]), np.array([c1[1]]))
        dx = (1 - u) * (NJ_CLOSE[0] - off0[0][0]) * s0 / s + u * (IL_CLOSE[0] - off1[0][0]) * s1 / s
        dy = (1 - u) * (NJ_CLOSE[1] - off0[1][0]) * s0 / s + u * (IL_CLOSE[1] - off1[1][0]) * s1 / s
        cam = (X[0] + dx, Y[0] + dy, s)
    base_map(im, cam, 0, {})
    fo = 1 - ramp(t, b1 - 0.35, b1)
    lifted(im, cam, "New Jersey", c0, c1, u, a=ramp(t, b0 + 0.6, b0 + 1.0) * fo, lift=ramp(t, td0 - 0.5, td0) * (1 - ramp(t, td1, td1 + 0.6)), ghost=0, fa=150)
    d = ImageDraw.Draw(im)
    label(d, cam, c0, "New Jersey", win(t, b0 + 0.6, td0 + 0.2), 0, 0, -150)
    label(d, cam, (35.0, 31.3), "Israel", win(t, tB + 0.2, b1 - 0.05), 0, -250, 10)
    label(d, cam, (35.6, 31.3), "New Jersey", win(t, tB + 0.2, b1 - 0.05), 0, 230, -170)
    lv, lsub, lhe, rv, rsub, rhe, note = PAIR["il"]
    aA = win(t, b0, tB, 0.3, 0.25); aB = win(t, tB, b1, 0.25, 0.3)
    if aA > 0.01: card_top(im, [("big", [("And Israel?", WHITE)]), ("sub", "Drag New Jersey over"), ("he", lhe)], aA)
    if aB > 0.01: card_top(im, [("big", [("Real: ", SKYL), ("1:1", YEL)]), ("sub", rsub), ("he", rhe)] + [("note", n) for n in note], aB)

def ee_scene(im, t):
    b0, b1 = BS["ee"], BE["ee"]; tB = pa("eeB") - 0.15
    m = ease3(ramp(t, tB + 0.4, tB + 3.4))
    cam = lerpcam(IL_CLOSE, EE_M, ease3(ramp(t, b0, b0 + 1.3)))
    if m > 0: cam = lerpcam(EE_M, EE_E, m)
    hl = {"Greenland": {"fill": al(SKY, 0.92), "edge": WHITE, "ew": 2.4}, "Africa": {"fill": TARGET, "edge": al(WHITE, 0.95), "ew": 2.4}}
    base_map(im, cam, m, hl)
    d = ImageDraw.Draw(im); la = win(t, b0 + 0.9, b1, 0.3, 0.3)
    label(d, cam, CENT["Greenland"], "Greenland", la, m, 0, 0); label(d, cam, CENT["Africa"], "Africa", la, m, 0, 0)
    a1 = win(t, b0, tB, 0.3, 0.25); a2 = win(t, tB, b1, 0.25, 0.3)
    if a1 > 0.01: card_top(im, [("hl", T["ee1"][0]), ("he", T["ee1"][1])], a1)
    if a2 > 0.01: card_top(im, [("hl", T["ee2"][0]), ("he", T["ee2"][1]), ("note", "Equal Earth projection, Savric et al. 2018")], a2)

CREAM = hx("#F6F1E4"); TILE_EDGE = hx("#0E1E3A")
def tile_shape(name):
    g = SH[name] if name in SH else geo.COUNTRIES[name]; return g
_SIL = {}
def silhouettes():
    """Israel (whole land: Israel gold, West Bank / Gaza #B8923F) and New Jersey in one local equal-scale frame (lon * cos 32 deg)"""
    if _SIL: return _SIL
    k = math.cos(math.radians(36))
    def loc(g, c):
        return [np.stack([(r[:, 0] - c[0]) * k, r[:, 1] - c[1]], 1) for r in rings_of(g, 0.006, 0.0001)]
    ci = (35.2, 31.4); cn = (-74.66, 40.15)
    _SIL["Israel"] = [(loc(geo.COUNTRIES["Israel"], ci), GOLD), (loc(geo.COUNTRIES["Palestine"], ci), GOLDD)]
    _SIL["New Jersey"] = [(loc(SH["New Jersey"], cn), SKY)]
    ext = max(np.abs(np.concatenate([np.concatenate(rs) for v in _SIL.values() for rs, _ in v])).max(0)[1], 1e-6)
    _SIL["_k"] = ext; return _SIL
def pips(d, cx, cy, n, r, a):
    pos = {1: [(0, 0)], 2: [(-1, -1), (1, 1)], 3: [(-1, -1), (0, 0), (1, 1)], 4: [(-1, -1), (1, -1), (-1, 1), (1, 1)]}[n]
    for px, py in pos:
        x, y = (cx + px * r * 2.6) * S, (cy + py * r * 2.6) * S; d.ellipse([x - r * S, y - r * S, x + r * S, y + r * S], fill=al(TILE_EDGE, a))
def domino(im, cx, cy, w, h, left, right, a, rot=0.0, q=0.0):
    """one tile: left / right half each a country name (silhouette), an int (pips) or '?'; q cross-fades silhouettes to '?'"""
    if a <= 0.01: return
    lay = Image.new("RGBA", (int(w * S) + 40, int(h * S) + 40), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    ox, oy = 20, 20
    d.rounded_rectangle([ox + 10, oy + 14, ox + w * S + 10, oy + h * S + 14], radius=26 * S, fill=(0, 0, 0, int(110 * a)))
    d.rounded_rectangle([ox, oy, ox + w * S, oy + h * S], radius=26 * S, fill=al(CREAM, a), outline=al(TILE_EDGE, a), width=int(4 * S))
    d.line([(ox + w * S / 2, oy + 22 * S), (ox + w * S / 2, oy + (h - 22) * S)], fill=al(TILE_EDGE, a), width=int(4 * S))
    sil = silhouettes(); half = h * 0.40
    for i, v in enumerate((left, right)):
        hx_ = ox / S + w / 4 + i * w / 2; hy = oy / S + h / 2
        if isinstance(v, int): pips(d, hx_, hy, v, h * 0.06, a); continue
        if v != "?" and q < 1:
            sc = half / sil["_k"]
            for rs, col in sil[v]:
                for r_ in rs:
                    pts = [((hx_ + x * sc) * S, (hy - y * sc) * S) for x, y in r_]
                    if len(pts) > 2: d.polygon(pts, fill=al(col, a * (1 - q)))
        if v == "?" or q > 0:
            f = font(h * 0.62, 900); qa_ = a * (1 if v == "?" else q)
            d.text((hx_ * S, hy * S), "?", font=f, anchor="mm", fill=al(hx("#2749D3"), qa_))
    if rot: lay = lay.rotate(rot, resample=Image.BICUBIC, expand=True)
    im.alpha_composite(lay, (int(cx * S - lay.width / 2), int(cy * S - lay.height / 2)))
def bubble(im, cx, cy, a, t):
    if a <= 0.01: return
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay); w, h = 300, 150; sc = 0.6 + 0.4 * ease(min(1, a * 1.4))
    x0, y0, x1, y1 = (cx - w / 2 * sc) * S, (cy - h / 2 * sc) * S, (cx + w / 2 * sc) * S, (cy + h / 2 * sc) * S
    d.rounded_rectangle([x0, y0, x1, y1], radius=40 * S * sc, fill=al(WHITE, a))
    d.polygon([((cx - 60 * sc) * S, y1 - 2), ((cx - 100 * sc) * S, y1 + 50 * S * sc), ((cx - 10 * sc) * S, y1 - 2)], fill=al(WHITE, a))
    for i in range(3):
        bob = 10 * max(0.0, math.sin(t * 7 - i * 0.9)); x = (cx + (i - 1) * 62 * sc) * S; y = (cy - bob * sc) * S; r = 17 * S * sc
        d.ellipse([x - r, y - r, x + r, y + r], fill=al(hx("#2749D3"), a))
    im.alpha_composite(lay)
CITIES = [(34.78, 32.08), (-74.0, 40.7), (-0.13, 51.5), (-46.6, -23.5), (72.9, 19.1), (151.2, -33.9), (139.7, 35.7), (-99.1, 19.4), (28.0, -26.2), (37.6, 55.8)]
def end_scene(im, key, t):
    b0, b1 = BS[key], BE[key]; a = win(t, b0, b1, 0.3, 0.3 if key != "write" else 0.01)
    cam = ENDCAM; d = ImageDraw.Draw(im)
    if key == "where":
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); dl = ImageDraw.Draw(lay)
        for i, c in enumerate(CITIES):
            k = ramp(t, b0 + 0.35 + i * 0.16, b0 + 0.6 + i * 0.16)
            if k <= 0: continue
            X, Y = fwd(np.array([c[0]]), np.array([c[1]]), 1.0); x, y = scr(X[0], Y[0], cam)
            ph = ((t - b0) * 1.1 + i * 0.37) % 1.0; rr = (14 + 70 * ph) * S
            dl.ellipse([x - rr, y - rr, x + rr, y + rr], outline=al(YEL, k * (1 - ph) * a), width=int(4 * S))
            r0 = 15 * S * k; dl.ellipse([x - r0, y - r0, x + r0, y + r0], fill=al(YEL, a), outline=al(hx("#0E1E3A"), a), width=int(2 * S))
        im.alpha_composite(lay)
        card_top(im, [("big", [("Where are", WHITE)]), ("big", [("YOU", YEL), (" from?", WHITE)]), ("he", T["where"][1])], a)
        return
    if key == "dom":
        tB = pa("dom2") - 0.15
        y0 = card_top(im, [("kick", T["dom"][0]), ("sub", T["dom2"][0]), ("he58", T["dom2"][1])], a)
        # mini tile in place of the domino glyph, right after "Let's play dominoes"
        wl = tw(T["dom"][0], 78, 900); domino(im, 540 + wl / 2 + 56, 272 + 78 * 1.25 / 2 + 4, 84, 42, 3, 2, a, rot=-8)
        sl = ease3(ramp(t, b0 + 0.25, b0 + 1.25)); bounce = math.sin(math.pi * ramp(t, b0 + 1.25, b0 + 1.6)) * 14
        gap = 6 + 600 * (1 - sl); qf = ease(ramp(t, tB + 0.3, tB + 1.1)); sep = 40 * qf
        cy = 1120 - bounce
        domino(im, 540 - 225 - gap - sep, cy, 440, 230, "Israel", 3, a, rot=-4 * (1 - sl))
        domino(im, 540 + 225 + gap + sep, cy, 440, 230, 3, "New Jersey", a, rot=4 * (1 - sl))
        if 1.25 < t - b0 < 1.75:   # click flash where the tiles meet
            k = 1 - ramp(t, b0 + 1.25, b0 + 1.75); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); dl = ImageDraw.Draw(lay)
            rr = (30 + 120 * (1 - k)) * S; dl.ellipse([540 * S - rr, cy * S - rr, 540 * S + rr, cy * S + rr], outline=al(YEL, k), width=int(6 * S)); im.alpha_composite(lay)
        if qf > 0:   # your turn: a second pair of blank tiles drops in below
            k = ease3(ramp(t, tB + 0.3, tB + 1.2))
            domino(im, 540 - 225 - 6, 1390 + (1 - k) * 220, 440, 230, "?", 4, a * k)
            domino(im, 540 + 225 + 6, 1390 + (1 - k) * 220, 440, 230, 4, "?", a * k)
        return
    if key == "write":
        card_top(im, [("hl", T["write"][0]), ("sub", T["write2"][0]), ("he58", T["write"][1])], a)
        domino(im, 540 - 225 - 6, 1030, 440, 230, "?", 4, a); domino(im, 540 + 225 + 6, 1030, 440, 230, 4, "?", a)
        bubble(im, 700, 1290, ramp(t, b0 + 0.6, b0 + 1.1) * a, t)

def frame(t):
    im = bg(); key = beat_of(t)
    if key == "hook":
        hl = {"Greenland": {"fill": al(SKY, 0.9), "edge": WHITE, "ew": 2.6}, "Africa": {"fill": TARGET, "edge": al(WHITE, 0.95), "ew": 2.6}}
        base_map(im, HOOKCAM, 0, hl); d = ImageDraw.Draw(im)
        label(d, HOOKCAM, CENT["Greenland"], "Greenland", 1.0); label(d, HOOKCAM, CENT["Africa"], "Africa", 1.0)
        card_top(im, [("hook", T["hook"][0]), ("he", T["hook"][1])], 1.0 if t < BE["hook"] - 0.3 else 1 - ramp(t, BE["hook"] - 0.3, BE["hook"]), rise_px=0)
    elif key == "merc":
        b0, b1 = BS["merc"], BE["merc"]; u = ease3(ramp(t, b0, b0 + 1.4)); cam = lerpcam(HOOKCAM, WORLD, u)
        hl = {}
        if u < 1: hl = {"Greenland": {"fill": al(SKY, 0.9 * (1 - u)), "edge": al(WHITE, 1 - u), "ew": 2.6}}
        base_map(im, cam, 0, hl)
        card_top(im, [("hl", T["merc"][0]), ("he", T["merc"][1]), ("note", "Mercator projection, 1569")], win(t, b0, b1, 0.3, 0.3))
    elif key == "stretch":
        b0, b1 = BS["stretch"], BE["stretch"]; c1, c2 = pa("st2") - 0.15, pa("st3") - 0.15
        lamc = -10.0
        if t < c1:                       # flat, grid fades in, then rolls up into the globe
            tt = 1 - ease3(ramp(t, c1 - 1.7, c1 + 0.1)); grid = ramp(t, b0 + 0.2, b0 + 0.9); circ = 0; cg = None
        elif t < c2:                     # globe turning slowly, equal circles pop in
            tt = 0.0; lamc = -10.0 + 14 * math.sin(0.5 * math.pi * ramp(t, c1, c2)); grid = 1; circ = 1; cg = t - c1 - 0.25
            lamc = -10.0 + 14 * ramp(t, c1, c2) - 14 * ease3(ramp(t, c2 - 0.6, c2))
        else:                            # unroll back to flat: circles balloon toward the poles
            tt = ease3(ramp(t, c2 + 0.1, c2 + 2.4)); grid = 1; circ = 1; cg = None
        globe_map(im, tt, lamc, circ, grid, cg)
        d = ImageDraw.Draw(im)
        if tt > 0.97: lat_labels(d, tt, lamc, 1.0 if t >= c2 else win(t, b0 + 0.4, c1 - 1.6))
        a0 = win(t, b0, c1, 0.3, 0.25); a1 = win(t, c1, c2, 0.25, 0.25); a2 = win(t, c2, b1, 0.25, 0.3)
        if a0 > 0.01: card_top(im, [("hl", T["s0"][0]), ("he", T["s0"][1])], a0)
        if a1 > 0.01: card_top(im, [("hl", T["s1"][0]), ("he", T["s1"][1])], a1)
        if a2 > 0.01: card_top(im, [("hl", T["s2"][0]), ("he", T["s2"][1])], a2)
    elif key in DR: drag_scene(im, key, t)
    elif key == "il": il_scene(im, t)
    elif key == "ee": ee_scene(im, t)
    else:
        u = ease3(ramp(t, BS["where"], BS["where"] + 1.0)); base_map(im, lerpcam(EE_E, ENDCAM, u), 1.0, {})
        dk = 0.35 * ramp(t, BS["where"], BS["where"] + 0.5) + 0.3 * ramp(t, BS["dom"], BS["dom"] + 0.5)
        ov = Image.new("RGBA", im.size, al(hx("#0E1E3A"), dk)); im.alpha_composite(ov)
        end_scene(im, key, t)
    return im
HOOKCAM_WORLD_END = WORLD     # gl starts from the flat world the stretch beat ends on

def qa_check(t):
    bad = []
    for tag, s, sz, (x0, y0, x1, y1) in QA:
        if sz < 40: bad.append(f"small {sz}px {s!r}")
        if tag != "grid" and (x0 < 66 or x1 > 1014 or y0 < 256 or y1 > 1544): bad.append(f"outside safe zone {tag} {s!r} {[round(v) for v in (x0, y0, x1, y1)]}")
    return bad

if __name__ == "__main__":
    os.makedirs(f"{HERE}/qa/v4", exist_ok=True)
    if A.snaps:
        for s_ in A.snaps.split(","):
            t = float(s_); QA.clear(); im = frame(t).reduce(S).convert("RGB"); im.save(f"{HERE}/qa/v4/snap_{t:05.2f}.png")
            for b_ in qa_check(t): print(f"QA t={t}: {b_}")
        print("snaps -> qa/v4/"); sys.exit()
    os.makedirs(f"{HERE}/parts_v4", exist_ok=True)
    if A.mux:
        parts = sorted(p for p in os.listdir(f"{HERE}/parts_v4") if p.startswith("v4_part") and p.endswith(".mp4"))
        open(f"{HERE}/parts_v4/list.txt", "w").write("".join(f"file '{HERE}/parts_v4/{p}'\n" for p in parts))
        sil = f"{HERE}/parts_v4/v4_silent.mp4"
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"{HERE}/parts_v4/list.txt", "-c", "copy", sil], check=True)
        print("silent", sil, f"{T_END:.2f}s"); sys.exit()
    f0, f1 = (int(x) for x in A.frames.split(":")) if A.frames else (0, N)
    f1 = min(f1, N); outp = f"{HERE}/parts_v4/v4_part{int(A.part or 0):02d}.mp4"
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                           "-i", "-", "-c:v", "libx264", "-preset", "fast", "-threads", "1", "-x264-params", "rc-lookahead=8:sync-lookahead=0:bframes=2", "-crf", "18", "-pix_fmt", "yuv420p", outp], stdin=subprocess.PIPE)
    for f in range(f0, f1):
        im = frame(f / FPS).reduce(S).convert("RGB"); ff.stdin.write(im.tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("part", outp, f0, f1, "of", N)
