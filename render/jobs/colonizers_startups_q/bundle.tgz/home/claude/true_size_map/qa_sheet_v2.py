"""Phone-size contact sheet: frames scaled to 390 px wide, safe zone drawn, time under each. usage: qa_sheet_v2.py OUT.png IMG..."""
import sys, re
from PIL import Image, ImageDraw, ImageFont
out, ims = sys.argv[1], sys.argv[2:]
w, h = 390, int(390 * 1920 / 1080); cols = min(7, len(ims)); rows = -(-len(ims) // cols)
sheet = Image.new("RGB", (cols * (w + 10) + 10, rows * (h + 40) + 10), (255, 255, 255)); d = ImageDraw.Draw(sheet)
f = ImageFont.truetype("/home/claude/true_size_map/fonts/Heebo-700.ttf", 20); k = w / 1080
for i, p in enumerate(ims):
    im = Image.open(p).convert("RGB").resize((w, h), Image.LANCZOS); x, y = 10 + (i % cols) * (w + 10), 10 + (i // cols) * (h + 40)
    sheet.paste(im, (x, y)); d.rectangle([x + 70 * k, y + 260 * k, x + 1010 * k, y + 1540 * k], outline=(0, 200, 255), width=1)
    m = re.search(r"(\d+\.\d+)", p.split("/")[-1]); d.text((x, y + h + 6), f"t={m.group(1) if m else p}s", fill=(0, 0, 0), font=f)
sheet.save(out); print(out, sheet.size)
