"""Contact sheet of QA stills: red centre line at x=540, cyan safe-zone lines at y=250 and y=1550, plus a text check from
the engine's per-still text boxes (qa/snap_*.json): every text inside 40..1040 horizontally, key text inside 250..1550,
headline/stat/end/chip text centred on x=540 (within 3 px).
usage: python3 qa_sheet.py OUT.png [cols]"""
import sys, os, json, glob
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); out = sys.argv[1]; cols = int(sys.argv[2]) if len(sys.argv) > 2 else 5
files = sorted(glob.glob(f"{HERE}/qa/snap_*.png")); tw, th = 324, 576
rows = (len(files) + cols - 1) // cols; sheet = Image.new("RGB", (cols * tw + (cols + 1) * 12, rows * (th + 40) + 12), (20, 20, 24))
fnt = ImageFont.truetype(f"{HERE}/fonts/Heebo-700.ttf", 22); d = ImageDraw.Draw(sheet); problems = []
for i, f in enumerate(files):
    im = Image.open(f).convert("RGB"); dd = ImageDraw.Draw(im)
    dd.line([(540, 0), (540, 1920)], fill=(255, 0, 0), width=3)
    for y in (250, 1550): dd.line([(0, y), (1080, y)], fill=(0, 230, 255), width=3)
    x = 12 + (i % cols) * (tw + 12); y = 12 + (i // cols) * (th + 40)
    sheet.paste(im.resize((tw, th), Image.LANCZOS), (x, y)); t = os.path.basename(f)[5:-4]
    d.text((x, y + th + 6), f"t = {t} s", font=fnt, fill=(230, 230, 230))
    j = f[:-4] + ".json"
    if os.path.exists(j):
        for tag, s, (x0, y0, x1, y1) in json.load(open(j)):
            if x0 < 40 or x1 > 1040: problems.append(f"{t}s {tag} overflows x [{x0:.0f},{x1:.0f}]: {s[:40]}")
            if tag in ("headline", "stat", "end", "chip", "body", "label") and (y0 < 250 or y1 > 1550): problems.append(f"{t}s {tag} outside safe y [{y0:.0f},{y1:.0f}]: {s[:40]}")
            if tag in ("headline", "stat", "end", "body") and abs((x0 + x1) / 2 - 540) > 3 and s not in ("Comment ", "MAP"):
                problems.append(f"{t}s {tag} off centre by {(x0 + x1) / 2 - 540:.1f}px: {s[:40]}")
sheet.save(out); print("sheet", out, len(files), "stills")
print("\n".join(problems) if problems else "text check: all text inside 40..1040, key text inside y 250..1550, centred")
