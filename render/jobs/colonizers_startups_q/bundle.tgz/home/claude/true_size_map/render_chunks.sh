#!/bin/bash
# Chunked, retrying render: the shared machine OOM-kills big encoders, so frames go out in 300-frame parts,
# each retried until it completes, then joined with --mux.  usage: ./render_chunks.sh [mus|vo] [extra engine args]
cd /home/claude/true_size_map; TAG=${1:-mus}; shift; EXTRA="$@"; mkdir -p parts
N=$(nice -n 15 python3 -W ignore -c "print(2874)")
for i in $(seq 0 9); do
  a=$((i*300)); b=$(((i+1)*300)); [ $a -ge $N ] && break
  ok=parts/${TAG}_part$(printf %02d $i).ok
  while [ ! -f $ok ]; do
    if nice -n 15 python3 -W ignore engine_truesize.py --frames $a:$b --part $i $EXTRA > parts/log_$i.txt 2>&1; then touch $ok
    else echo "chunk $i failed, retrying"; sleep 20; fi
  done
  echo "chunk $i done"
done
echo ALLDONE
