"""Geometry for the true size reel: Natural Earth 1:10m countries (world-atlas topojson, copied from
/home/claude/goals_scorecard/geodata) and US states (us-atlas 3.0.1, copied from /home/claude/whatif_us/dl).
Builds the comparison shapes (lon/lat degrees, antimeridian unwrapped where needed) and measures their
ellipsoidal area with a Lambert cylindrical equal-area projection on the WGS84 ellipsoid (exact for equal-area,
edges are dense so straight-edge error is negligible). Run directly to print areas -> geodata/areas.json."""
import json, math, os
import numpy as np
from shapely.geometry import Polygon, MultiPolygon, box
from shapely.ops import unary_union
from shapely import transform as _tf
def transform(f, g): return _tf(g, lambda a: np.stack(f(a[:, 0], a[:, 1]), 1))
from shapely import affinity

HERE = os.path.dirname(os.path.abspath(__file__))

def unwrap(r):
    """rings stitched across the antimeridian (Russia, Fiji, Aleutians) jump 180 -> -180: move the western half east by 360"""
    xs = [q[0] for q in r]
    if max(xs) - min(xs) > 180: return [(x + 360 if x < 0 else x, y) for x, y in r]
    return r

def topo(path, obj):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"][obj]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            rings = [unwrap(r) for r in rings]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0], [r for r in rings[1:] if len(r) >= 4]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out

COUNTRIES = topo(f"{HERE}/geodata/countries-10m.json", "countries"); COUNTRIES.pop("Antarctica", None)
STATES = topo(f"{HERE}/geodata/states-10m.json", "states")

def parts(g): return list(g.geoms) if hasattr(g, "geoms") else [g]
def shift_parts(g, test, dx):
    """move polygons whose centroid passes test(lon) by dx degrees (antimeridian unwrap)"""
    return unary_union([affinity.translate(p, dx) if test(p.centroid.x) else p for p in parts(g)])

AFRICA_N = ["Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde", "Cameroon", "Central African Rep.", "Chad",
            "Comoros", "Congo", "Côte d'Ivoire", "Dem. Rep. Congo", "Djibouti", "Egypt", "Eq. Guinea", "Eritrea", "Ethiopia", "Gabon", "Gambia",
            "Ghana", "Guinea", "Guinea-Bissau", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius",
            "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda", "São Tomé and Principe", "Senegal", "Seychelles", "Sierra Leone",
            "Somalia", "Somaliland", "South Africa", "S. Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "W. Sahara", "Zambia",
            "Zimbabwe", "eSwatini"]
SAM_N = ["Argentina", "Bolivia", "Brazil", "Chile", "Colombia", "Ecuador", "Guyana", "Paraguay", "Peru", "Suriname", "Uruguay", "Venezuela", "Falkland Is."]
EUROPE_N = ["Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herz.", "Bulgaria", "Croatia", "Czechia", "Denmark", "Estonia",
            "Finland", "France", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kosovo", "Latvia", "Liechtenstein", "Lithuania",
            "Luxembourg", "Macedonia", "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands", "Norway", "Poland", "Portugal", "Romania",
            "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "Ukraine", "United Kingdom", "Vatican",
            "Faeroe Is.", "Isle of Man", "Jersey", "Guernsey", "Åland"]
EU_BOX = box(-32, 34.5, 45, 82)          # mainland Europe + Iceland, Svalbard, Azores; drops Canaries, French Guiana etc.

def europe():
    g = unary_union([COUNTRIES[n] for n in EUROPE_N]).intersection(EU_BOX)
    ru = COUNTRIES["Russia"].intersection(box(19, 41, 60, 82))           # European Russia: west of the Urals (60 E)
    kz = COUNTRIES["Kazakhstan"].intersection(box(46, 45, 51.5, 52))     # the sliver west of the Ural river (approx.)
    tr = COUNTRIES["Turkey"].intersection(box(25, 40.2, 29.0, 42.2))     # East Thrace
    return unary_union([g, ru, kz, tr]).buffer(0)

def shapes():
    S = {}
    S["Greenland"] = COUNTRIES["Greenland"]
    S["Africa"] = unary_union([COUNTRIES[n] for n in AFRICA_N]).buffer(0)
    S["Australia"] = COUNTRIES["Australia"]
    S["Russia"] = shift_parts(COUNTRIES["Russia"], lambda x: x < -100, 360)   # Chukotka east of 180 -> lon > 180
    S["Alaska"] = shift_parts(STATES["Alaska"], lambda x: x > 100, -360)       # western Aleutians -> lon < -180
    S["Brazil"] = COUNTRIES["Brazil"]
    S["Europe"] = europe()
    fr_guiana = COUNTRIES["France"].intersection(box(-55, 1.5, -51, 6.5))
    S["South America"] = unary_union([COUNTRIES[n] for n in SAM_N] + [fr_guiana]).buffer(0)
    S["Israel"] = COUNTRIES["Israel"]
    S["Palestine"] = COUNTRIES["Palestine"]       # West Bank + Gaza (drawn #B8923F, whole land shown)
    S["New Jersey"] = STATES["New Jersey"]
    return S

# ---- WGS84 Lambert cylindrical equal-area (authalic): area in this plane == area on the ellipsoid
A_ = 6378137.0; F_ = 1 / 298.257223563; E2 = F_ * (2 - F_); E_ = math.sqrt(E2)
def _q(phi):
    s = np.sin(phi); return (1 - E2) * (s / (1 - E2 * s * s) - (1 / (2 * E_)) * np.log((1 - E_ * s) / (1 + E_ * s)))
def cea(x, y):
    lam = np.radians(np.asarray(x)); phi = np.radians(np.asarray(y))
    return A_ * lam, A_ * _q(phi) / 2
def area_km2(g): return transform(lambda x, y, z=None: cea(x, y), g).area / 1e6
def eq_centroid(g):
    """area-weighted centroid in the equal-area plane, returned as lon/lat degrees"""
    c = transform(lambda x, y, z=None: cea(x, y), g).centroid
    lon = math.degrees(c.x / A_); qv = 2 * c.y / A_
    lo, hi = -math.pi / 2, math.pi / 2
    for _ in range(60):
        mid = (lo + hi) / 2
        if _q(mid) < qv: lo = mid
        else: hi = mid
    return lon, math.degrees((lo + hi) / 2)

if __name__ == "__main__":
    S = shapes(); out = {}
    for k, g in S.items():
        a = area_km2(g); c = eq_centroid(g); out[k] = {"area_km2": round(a), "centroid": [round(c[0], 3), round(c[1], 3)]}
        print(f"{k:14s} {a:14,.0f} km2   centroid {c[0]:8.2f} {c[1]:7.2f}")
    wb = max(parts(S["Palestine"]), key=lambda p: p.area); gz = min(parts(S["Palestine"]), key=lambda p: p.area)
    out["West Bank"] = {"area_km2": round(area_km2(wb))}; out["Gaza"] = {"area_km2": round(area_km2(gz))}
    print("West Bank", out["West Bank"], "Gaza", out["Gaza"])
    json.dump(out, open(f"{HERE}/geodata/areas.json", "w"), indent=1)
