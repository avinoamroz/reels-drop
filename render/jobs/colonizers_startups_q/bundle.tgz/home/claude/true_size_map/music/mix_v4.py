"""True size v4 mix: narration + music bed at the v3 balance, then -14 LUFS / -1.5 dBTP (remix_clean.loud_finish), 48 kHz stereo s16.
The v3 mix recipe was not saved; the balance was measured from music/true_size_v3_mix.wav by least squares
(mix = 1.668 * vo + 0.761 * music per channel, so music = 0.456 x voice gain, steady, no ducking).
usage: python3 mix_v4.py VO.wav MUSIC.wav OUT.wav [ratio]"""
import sys, subprocess, numpy as np, soundfile as sf, os
import re
def measure(p):
    o = subprocess.run(["ffmpeg", "-nostats", "-hide_banner", "-i", p, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s = o[o.rfind("Summary"):]; return float(re.search(r"I:\s+(-?[\d.]+)", s).group(1)), float(re.search(r"Peak:\s+(-?[\d.]+)", s).group(1))
def loud_finish(x, sr, out_wav, target=-14.0, tp=-1.5):
    """as /home/claude/vo_new/remix_clean.loud_finish, but the limiter's 2 ms look-ahead is compensated (latency=1) so nothing shifts"""
    tmp = out_wav + ".pre.wav"; sf.write(tmp, x.astype(np.float32), sr, subtype="FLOAT"); I, P = measure(tmp); lim = 10 ** ((tp - 0.3) / 20); src = tmp
    for k in range(3):
        g = target - (I if k == 0 else I2)
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-af", f"volume={g:.2f}dB,aresample={sr*4},alimiter=limit={lim:.4f}:attack=2:release=60:level=disabled:latency=1,aresample={sr}",
                        "-c:a", "pcm_f32le", out_wav + f".{k}.wav"], check=True)
        if src != tmp: os.remove(src)
        src = out_wav + f".{k}.wav"; I2, P2 = measure(src)
        if I2 >= target - 0.2: break
    os.replace(src, out_wav); os.remove(tmp); return dict(before_I=I, before_TP=P, I=I2, TP=P2)
vo, mu, out = sys.argv[1:4]; R = float(sys.argv[4]) if len(sys.argv) > 4 else 0.456; SR = 48000
tmp = out + ".m48.wav"
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", mu, "-ar", str(SR), "-c:a", "pcm_f32le", tmp], check=True)
m, _ = sf.read(tmp); os.remove(tmp); v, sr = sf.read(vo); assert sr == SR
n = len(v); m = m[:n] if len(m) >= n else np.pad(m, ((0, n - len(m)), (0, 0)))
y = v[:, None] + R * m
f32 = out + ".f32.wav"; r = loud_finish(y, SR, f32)
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", f32, "-ar", str(SR), "-ac", "2", "-c:a", "pcm_s16le", out], check=True); os.remove(f32)
print(out, r)
