# True size reel: research and figures

All ratios are computed in code (`figures.py`, output `figures.json`); none are typed by hand. The engine asserts that each on-screen ratio is within rounding of the computed one.

## Sources (fetched 19 Oct 2026)

Note: the CIA World Factbook page now says the Factbook "has sunset", so the live country pages could not be used. Britannica was used as the primary source. Its Greenland figure (2,166,086 km²) is the same number the Factbook used.

| Area | km² | sq mi | Source |
|---|---|---|---|
| Greenland | 2,166,086 | 836,330 | Britannica, Greenland summary https://www.britannica.com/summary/Greenland and largest countries list https://www.britannica.com/print/article/2130540 |
| Africa | 30,152,882 | 11,642,094 | Britannica, Africa summary https://www.britannica.com/summary/Africa |
| Australia | 7,688,126 | 2,968,401 | Britannica, Australia summary https://www.britannica.com/summary/Australia (Geoscience Australia gives 7,688,287: https://www.ga.gov.au/scientific-topics/national-location-information/dimensions/australias-size-compared) |
| Russia | 17,075,400 | 6,592,846 | Britannica, largest countries list https://www.britannica.com/print/article/2130540 |
| Brazil | 8,510,418 | 3,285,890 | Britannica, Brazil summary https://www.britannica.com/summary/Brazil |
| Alaska | 1,723,337 | 665,384 | Britannica, "What's the largest U.S. state by area?" (US Census Bureau, total area incl. water) https://www.britannica.com/print/article/2240001 |
| New Jersey | 22,591 | 8,723 | same Britannica states article (Census, total area incl. water) |
| Europe | 10,400,000 (approx.) | 4,000,000 | Britannica, Europe summary, "approximate, including European Russia" https://www.britannica.com/summary/Europe |
| South America | 17,824,370 | 6,882,027 | Britannica, South America summary https://www.britannica.com/summary/South-America |
| Israel | 22,072 | 8,522 | Britannica, Israel summary https://www.britannica.com/summary/Israel (footnote: excludes the West Bank and the Gaza Strip) |

CIA Factbook comparative line for Israel, "slightly larger than New Jersey", via IndexMundi (Factbook mirror, updated 2021): https://www.indexmundi.com/israel/area_comparative.html

Projection references (from knowledge; I could not fetch them because the web search budget ran out):
- Mercator projection, Gerardus Mercator, 1569. It is conformal, and its scale factor at latitude φ is sec φ, so area grows as sec² φ. See J. P. Snyder, *Map Projections: A Working Manual*, USGS Professional Paper 1395 (1987), https://doi.org/10.3133/pp1395
- Equal Earth projection: B. Šavrič, T. Patterson, B. Jenny, "The Equal Earth map projection", *International Journal of Geographical Information Science* 33(3), 2019 (online 2018), https://doi.org/10.1080/13658816.2018.1504949. The polynomial coefficients A1..A4 used in the engine come from that paper.

## Computed ratios (figures.py)

| Pair | From cited areas | From Natural Earth polygons | How it looks on Mercator | On screen |
|---|---|---|---|---|
| Africa / Greenland | 13.92 | 13.88 | 0.95 (looks the same size) | 14x |
| Australia / Greenland | 3.55 | 3.57 | 0.27 (Greenland looks 3.6x bigger) | 3.5x |
| Africa / Russia | 1.77 | 1.76 | 0.40 (Russia looks 2.5x bigger) | 1.8x |
| Brazil / Alaska | 4.94 | 5.54 | 1.10 (about the same) | almost 5x / 4.9x |
| South America / Europe | 1.71 | 1.77 | 0.60 (Europe looks 1.7x bigger) | 1.7x |
| New Jersey / Israel | 1.02 | 0.92 | 1.15 (NJ looks 15% bigger) | about the same size, 1:1 |

Drag rescale (cos(lat_from) / cos(lat_to) per axis, centroids from the polygons):
- Greenland 72.0°N to Africa 6.0°N: linear x0.31, area x0.096
- Greenland to Australia 25.3°S: linear x0.34
- Russia 59.6°N to Africa: linear x0.51
- Alaska 63.4°N to Brazil 10.4°S: linear x0.46
- Europe 52.6°N to South America 13.4°S: linear x0.62
- New Jersey 40.2°N to Israel 31.4°N: linear x0.90

## Method
- Geometry: Natural Earth 1:10m countries (world-atlas topojson) and US states (us-atlas 3.0.1). Both are public domain, copied into `geodata/`.
- Polygon areas: WGS84 Lambert cylindrical equal-area. It is an exact equal-area projection, so planar area = ellipsoidal area (`geo.py`).
- Drag: each shape is rotated on the sphere. First it moves along its home meridian to change latitude, then about the pole to change longitude, so it stays north-up and keeps its true shape and size. It is then drawn in Mercator, so its on-screen size follows the local sec φ scale exactly. This is more exact than scaling the whole shape by one cos ratio, because shapes that span many degrees of latitude (Russia, Greenland) also bend, as they do on the globe.
- Morph: every vertex is interpolated between Mercator and Equal Earth (Equal Earth scaled to the same width).

## Caveats
- Regions are defined as follows. Africa: the 56 African countries/territories in Natural Earth, including Madagascar and Sinai (via Egypt). Europe: the European countries, plus Russia west of 60°E, East Thrace and a small Kazakh sliver; the Caucasus and Cyprus are excluded. South America includes French Guiana and the Falklands. The polygon areas match the cited figures within 0.4% to 4%.
- Alaska and New Jersey: Census totals include inland and coastal water. The us-atlas outlines are close to land area, so polygon Alaska is 1.53M km² and polygon NJ is 20,153 km². The on-screen figures are the cited totals.
- Israel's 22,072 km² (Britannica) excludes the West Bank and Gaza. The map shows the whole land in gold (Israel incl. Golan: gold #D2AA53; West Bank/Gaza: #B8923F; Green Line: green). Natural Earth puts the Golan inside Israel. West Bank 5,940 km² and Gaza 334 km² are polygon values, not shown on screen.
- Europe's 10.4M km² is Britannica's own "approximate" figure.
- The Green Line is drawn only once Israel is more than 40 px tall on screen. In world views Israel is a few pixels and gold only.
