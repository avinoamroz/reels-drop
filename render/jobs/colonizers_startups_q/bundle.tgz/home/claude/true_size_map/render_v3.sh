#!/bin/bash
# v3 chunked render: 300-frame parts, two workers (one per core), each part retried until it completes
cd /home/claude/true_size_map; mkdir -p parts_v3
N=$(python3 -c "import json;print(int(round(json.load(open('vo3/segs_v3.json'))['t_end']*30)))")
work(){ for i in $(seq $1 2 20); do a=$((i*300)); [ $a -ge $N ] && break; b=$(((i+1)*300)); ok=parts_v3/v3_part$(printf %02d $i).ok
  until [ -f $ok ]; do nice -n 15 python3 -W ignore engine_truesize_v3.py --frames $a:$b --part $i > parts_v3/log_$i.txt 2>&1 && touch $ok || sleep 15; done
  echo "part $i done $(date +%T)"; done; }
work 0 & P0=$!; work 1 & P1=$!; wait $P0 $P1; echo ALLDONE
