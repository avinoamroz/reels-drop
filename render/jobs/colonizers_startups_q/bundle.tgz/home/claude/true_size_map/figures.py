"""All on-screen ratios, computed here (not typed by hand). Cited areas (km2) come from Britannica (fetched 19 Oct 2026,
see research.md). Also computes the same ratios from the Natural Earth polygons (ellipsoidal area) and the apparent
ratio on a Mercator map (area in the Mercator plane), as a cross check. Writes figures.json for the engine."""
import json, math, os
import numpy as np
from shapely import transform as _tf
import geo

HERE = os.path.dirname(os.path.abspath(__file__))
CITED = {   # km2, source key -> research.md
    "Greenland":     (2166086,  "Britannica, Greenland summary / largest countries list"),
    "Africa":        (30152882, "Britannica, Africa summary"),
    "Australia":     (7688126,  "Britannica, Australia summary / largest countries list"),
    "Russia":        (17075400, "Britannica, largest countries list"),
    "Alaska":        (1723337,  "Britannica, largest US states (US Census Bureau, total area)"),
    "Brazil":        (8510418,  "Britannica, Brazil summary / largest countries list"),
    "Europe":        (10400000, "Britannica, Europe summary (approx., incl. European Russia)"),
    "South America": (17824370, "Britannica, South America summary"),
    "Israel":        (22072,    "Britannica, Israel summary (excludes West Bank and Gaza Strip)"),
    "New Jersey":    (22591,    "Britannica, largest US states (US Census Bureau, total area)"),
}
PAIRS = [("Africa", "Greenland"), ("Australia", "Greenland"), ("Africa", "Russia"), ("Brazil", "Alaska"),
         ("South America", "Europe"), ("New Jersey", "Israel")]

def merc_area(g):
    """area in the Mercator plane (unit sphere radians^2): what the eye compares on the familiar map"""
    def f(a):
        lam = np.radians(a[:, 0]); phi = np.radians(np.clip(a[:, 1], -85, 85))
        return np.stack([lam, np.log(np.tan(np.pi / 4 + phi / 2))], 1)
    return _tf(g, f).area

if __name__ == "__main__":
    S = geo.shapes(); out = {"pairs": {}, "cited": {k: v[0] for k, v in CITED.items()}, "polygon_km2": {}, "centroid": {}}
    for k in CITED:
        out["polygon_km2"][k] = round(geo.area_km2(S[k])); out["centroid"][k] = geo.eq_centroid(S[k])
    print(f"{'pair':28s} {'cited':>7s} {'polygon':>8s} {'Mercator looks':>15s}")
    for big, small in PAIRS:
        rc = CITED[big][0] / CITED[small][0]; rp = out["polygon_km2"][big] / out["polygon_km2"][small]
        rm = merc_area(S[big]) / merc_area(S[small])
        out["pairs"][f"{big}/{small}"] = {"cited": rc, "polygon": rp, "mercator_apparent": rm}
        print(f"{big + ' / ' + small:28s} {rc:7.3f} {rp:8.3f} {rm:15.3f}")
    # local Mercator linear scale = sec(lat); moving a shape from lat1 to lat2 rescales it by cos(lat1)/cos(lat2) per axis
    print("\nlinear rescale when dragged (cos(lat_from)/cos(lat_to)), area factor = square:")
    drags = [("Greenland", "Africa"), ("Greenland", "Australia"), ("Russia", "Africa"), ("Alaska", "Brazil"), ("Europe", "South America"), ("New Jersey", "Israel")]
    out["drags"] = {}
    for a, b in drags:
        la, lb = out["centroid"][a][1], out["centroid"][b][1]; k = math.cos(math.radians(la)) / math.cos(math.radians(lb))
        out["drags"][f"{a}->{b}"] = {"lat_from": la, "lat_to": lb, "linear": k, "area": k * k}
        print(f"  {a:12s} {la:6.1f} -> {b:13s} {lb:6.1f}: linear x{k:.3f}, area x{k * k:.3f}")
    nj_vs_isr_merc = out["pairs"]["New Jersey/Israel"]["mercator_apparent"]
    print(f"\nNew Jersey looks {100 * (nj_vs_isr_merc - 1):.0f}% bigger than Israel on Mercator (polygons), cited true difference {100 * (CITED['New Jersey'][0] / CITED['Israel'][0] - 1):.1f}%")
    json.dump(out, open(f"{HERE}/figures.json", "w"), indent=1)
