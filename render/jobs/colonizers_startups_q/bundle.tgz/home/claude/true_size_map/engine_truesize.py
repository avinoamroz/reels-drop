"""True size reel (Instagram 1080x1920, 30 fps) for @expressenglishcom with @noamroz__.
Mercator world map from frame 0; countries are lifted and dragged toward the equator while being re-projected at true
relative scale (each shape is rotated on the sphere so its centroid follows the drag path, then projected with Mercator,
so its on-screen size follows the local Mercator scale sec(latitude) exactly: dragging from lat1 to lat2 rescales it by
cos(lat1)/cos(lat2) per axis); then the whole map morphs from Mercator to Equal Earth (equal-area, formulas from
Savric, Patterson & Jenny 2018). Map rule: Israel incl. Golan in gold, West Bank / Gaza #B8923F, Green Line (46,204,113).
Geometry: Natural Earth 1:10m via world-atlas / us-atlas (copied into ./geodata), see geo.py. Ratios: figures.py.
Rendering: PIL at 2x then downsampled (pattern from /home/claude/doubles_map/engine_doubles.py), music: music/tune.py atlas.
usage: nice -n 15 python3 engine_truesize.py [--snaps 0.5,12] [--qa] [--frames A:B --part N] [--vo VO.wav --segs SEGS.json]
  default: music-only version -> true_size_mus.mp4
  --snaps : PNG stills at those seconds -> qa/
  --part  : render only frames A..B to parts/partN.mp4 (for running two processes on two cores); --mux joins parts + music
  --vo    : narrated version: each beat is stretched to its narration line (SEGS json {"segs": [[start, end], ...]}, one per
            beat, as in tts.txt), music is re-made to the new length and ducked under the voice -> true_size_vo.mp4"""
import sys, os, json, math, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon
import geo

ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--qa", action="store_true")
ap.add_argument("--frames"); ap.add_argument("--part"); ap.add_argument("--mux", action="store_true")
ap.add_argument("--vo"); ap.add_argument("--segs")
A = ap.parse_args()
HERE = os.path.dirname(os.path.abspath(__file__)); S = 2; W, H, FPS = 1080, 1920, 30
FIG = json.load(open(f"{HERE}/figures.json"))

def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
def al(c, a): return c[:3] + (int(max(0, min(1, a)) * c[3]),)
NAVY = hx("#163261"); SKY = hx("#45A4DD"); SKYL = hx("#8FD0F7"); WHITE = hx("#FFFFFF"); SUBC = hx("#B4C4DE")
SEA = hx("#0B1A35"); LAND = hx("#1E3D72"); BORDER = (125, 165, 225, 95); TARGET = hx("#2D5AA0"); CARD = hx("#0E1E3A", 236)
GOLD = hx("#D2AA53"); GOLDD = hx("#B8923F"); GREENC = (46, 204, 113, 255); GRID = (170, 200, 240, 55)
FONT = {w: f"{HERE}/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(round(sz * S)), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONT[w], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
# type scale (uniform sizes): headline EN/HE, body EN/HE, chip EN/HE, map label EN/HE, stat number
HL_EN, HL_HE, BD_EN, BD_HE, CH_EN, CH_HE, LB_EN, LB_HE, NUM = 58, 50, 42, 38, 40, 38, 32, 29, 104

# ---------------------------------------------------------------- copy (every on-screen string lives here)
T = {
 "hook":    ("Greenland is lying to you.", "גרינלנד משקרת לכם."),
 "merc":    ("This map is the Mercator projection.", "המפה הזאת היא היטל מרקטור."),
 "stretch": ("The farther from the equator, the more it stretches.", "ככל שמתרחקים מקו המשווה, המפה נמתחת יותר."),
 "tissot":  ("Same size on the globe", "באותו גודל על הגלובוס"),
 "gl1":     ("Greenland looks as big as Africa.", "גרינלנד נראית בגודל של אפריקה."),
 "gl2":     ("Now drag it to the equator, to scale.", "עכשיו נגרור אותה לקו המשווה, בקנה מידה."),
 "gl3":     ("Africa is 14x bigger.", "אפריקה גדולה פי 14."),
 "au1":     ("Australia looks smaller than Greenland.", "אוסטרליה נראית קטנה מגרינלנד."),
 "au2":     ("Australia is 3.5x bigger.", "אוסטרליה גדולה פי 3.5."),
 "ru1":     ("Russia looks bigger than Africa.", "רוסיה נראית גדולה מאפריקה."),
 "ru2":     ("Africa is 1.8x bigger.", "אפריקה גדולה פי 1.8."),
 "ak1":     ("Alaska looks as big as Brazil.", "אלסקה נראית בגודל של ברזיל."),
 "ak2":     ("Brazil is almost 5x bigger.", "ברזיל גדולה כמעט פי 5."),
 "eu1":     ("Europe looks bigger than South America.", "אירופה נראית גדולה מדרום אמריקה."),
 "eu2":     ("South America is 1.7x bigger.", "דרום אמריקה גדולה פי 1.7."),
 "il1":     ("And Israel?", "ומה עם ישראל?"),
 "il2":     ("About the size of New Jersey.", "בערך בגודל של ניו ג'רזי."),
 "ee1":     ("Mercator keeps the shapes.", "מרקטור שומרת על הצורות."),
 "ee2":     ("Equal Earth keeps the sizes.", "Equal Earth שומרת על הגדלים."),
 "q":       ("Which country surprised you?", "איזו מדינה הכי הפתיעה אתכם?"),
 "seven":   ("The best way to improve your fluency is by speaking to yourself in English, and explaining complicated topics. "
             "Record yourself for seven minutes on WhatsApp. Then, try to share it with an English speaking friend.",
             "הדרך הטובה ביותר לשפר את השטף שלכם היא לדבר עם עצמכם באנגלית ולהסביר נושאים מורכבים. "
             "הקליטו את עצמכם 7 דקות בוואטסאפ. ואז, נסו לשתף את ההקלטה עם חבר דובר אנגלית."),
 "cta":     ("Comment MAP", "כתבו MAP בתגובות"),
}
WORDS = {"projection": "היטל", "equator": "קו המשווה", "latitude": "קו רוחב", "distortion": "עיוות", "to scale": "בקנה מידה"}
NAMES = {"Greenland": "גרינלנד", "Africa": "אפריקה", "Australia": "אוסטרליה", "Russia": "רוסיה", "Alaska": "אלסקה", "Brazil": "ברזיל",
         "Europe": "אירופה", "South America": "דרום אמריקה", "Israel": "ישראל", "New Jersey": "ניו ג'רזי"}
C = FIG["cited"]
def mk(v): return f"{v / 1e6:.2f}M km²" if v >= 1e6 else f"{v:,} km²"
def ratio_ok(key, shown):   # on-screen ratio must match the computed one
    r = FIG["pairs"][key]["cited"]; assert abs(r - shown) <= 0.15 * shown, (key, r, shown); return r
ratio_ok("Africa/Greenland", 14); ratio_ok("Australia/Greenland", 3.5); ratio_ok("Africa/Russia", 1.8)
ratio_ok("Brazil/Alaska", 4.9); ratio_ok("South America/Europe", 1.7); ratio_ok("New Jersey/Israel", 1.0)
STAT = {
 "gl": (f"Greenland {mk(C['Greenland'])}", f"Africa {mk(C['Africa'])}"),
 "au": (f"Greenland {mk(C['Greenland'])}", f"Australia {mk(C['Australia'])}"),
 "ru": (f"Russia {mk(C['Russia'])}", f"Africa {mk(C['Africa'])}"),
 "ak": (f"Alaska {mk(C['Alaska'])}", f"Brazil {mk(C['Brazil'])}"),
 "eu": (f"Europe {mk(C['Europe'])}", f"South America {mk(C['South America'])}"),
 "il": (f"Israel {mk(C['Israel'])}", f"New Jersey {mk(C['New Jersey'])}"),
}
BIGNUM = {"gl": "14x", "au": "3.5x", "ru": "1.8x", "ak": "4.9x", "eu": "1.7x", "il": "1:1"}
ALL_TEXT = [s for v in T.values() for s in v] + list(WORDS) + list(WORDS.values()) + list(NAMES) + list(NAMES.values()) + \
           [s for v in STAT.values() for s in v] + list(BIGNUM.values())
for s_ in ALL_TEXT:
    if chr(0x2013) in s_ or chr(0x2014) in s_: sys.exit(f"dash character in text: {s_!r}")

# ---------------------------------------------------------------- geometry + LODs
SH = geo.shapes()
LODT = [0.0015, 0.006, 0.02, 0.06, 0.16]          # simplify tolerance (deg) per level
def rings_of(g, tol, min_area):
    out = []
    for p in geo.parts(g.simplify(tol, preserve_topology=False) if tol else g):
        if isinstance(p, Polygon) and p.area >= min_area and not p.is_empty: out.append(np.array(p.exterior.coords))
    return out
BASE = []
for tol in LODT:
    lv = {}
    for k, g in geo.COUNTRIES.items():
        keep_small = k in ("Israel", "Palestine")
        rs = rings_of(g, tol, 0 if keep_small else tol * tol * 4)
        if rs: lv[k] = rs
    BASE.append(lv)
HL = [{k: rings_of(g, tol, tol * tol * 4) for k, g in SH.items()} for tol in LODT]
def lod_for(s):
    dpp = 57.3 / s      # degrees per px at the equator (Mercator stretches poleward, so this is conservative)
    for i in range(len(LODT) - 1, -1, -1):
        if LODT[i] <= dpp * 0.7: return i
    return 0
# Green Line: West Bank / Gaza outline where it borders Israel (pattern from /home/claude/peoples_map/engine_peoples.py)
def _green_lines():
    isr = geo.COUNTRIES["Israel"].buffer(0.015); out = []
    for poly in geo.parts(geo.COUNTRIES["Palestine"]):
        g = poly.exterior.intersection(isr)
        for ln in (g.geoms if hasattr(g, "geoms") else [g]):
            if ln.geom_type == "LineString" and ln.length > 0.01: out.append(np.array(ln.coords))
    return out
GREEN_LINES = _green_lines()
CENT = {k: tuple(v) for k, v in FIG["centroid"].items()}

# ---------------------------------------------------------------- projections + camera
A1, A2, A3, A4 = 1.340264, -0.081106, 0.000893, 0.003796; EEK = math.pi / 2.70663
def fwd(lon, lat, m=0.0):
    lam = np.radians(lon); phi = np.radians(np.clip(lat, -85, 85))
    X, Y = lam, np.log(np.tan(np.pi / 4 + phi / 2))
    if m <= 0: return X, Y
    th = np.arcsin(np.sqrt(3) / 2 * np.sin(phi))
    Xe = 2 * np.sqrt(3) * lam * np.cos(th) / (3 * (9 * A4 * th ** 8 + 7 * A3 * th ** 6 + 3 * A2 * th ** 2 + A1))
    Ye = A4 * th ** 9 + A3 * th ** 7 + A2 * th ** 3 + A1 * th
    return (1 - m) * X + m * EEK * Xe, (1 - m) * Y + m * EEK * Ye
CY0 = 900
def scr(X, Y, cam):
    cx, cy, s = cam; return (540 + (X - cx) * s) * S, (CY0 - (Y - cy) * s) * S
def fit(lon0, lon1, lat0, lat1, m=0.0, wpx=1000, hpx=840, yc=CY0):
    X0, Y0 = fwd(lon0, lat0, m); X1, Y1 = fwd(lon1, lat1, m)
    if m > 0: X0, X1 = fwd(lon0, 0.0, m)[0], fwd(lon1, 0.0, m)[0]     # Equal Earth is widest at the equator
    s = min(wpx / abs(X1 - X0), hpx / abs(Y1 - Y0))
    return ((X0 + X1) / 2, (Y0 + Y1) / 2 + (yc - CY0) / s, s)
WORLD = fit(-180, 180, -60, 84, 0, 4000, 870, 905)       # Mercator world, sides cropped a little so the map is big
WORLD_EE = fit(-180, 180, -60, 84, 1, 1060, 2000, 1010)   # Equal Earth world, whole oval, sitting under the headline
def ease(u): u = max(0.0, min(1.0, u)); return u * u * (3 - 2 * u)
def ease3(u): u = max(0.0, min(1.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def lerpcam(a, b, u):
    return (a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, math.exp(math.log(a[2]) + (math.log(b[2]) - math.log(a[2])) * u))
def ramp(t, t0, t1): return max(0.0, min(1.0, (t - t0) / (t1 - t0))) if t1 > t0 else float(t >= t0)
def win(t, t0, t1, fi=0.3, fo=0.3): return min(ramp(t, t0, t0 + fi), 1 - ramp(t, t1 - fo, t1))

def move(rings, c0, c1):
    """rotate rings on the sphere: first along the meridian of c0 (latitude change), then about the pole (longitude);
    keeps north up and true shape/size, so the Mercator drawing shows the real size at the new latitude"""
    lam0, phi0 = math.radians(c0[0]), math.radians(c0[1]); lam1, phi1 = math.radians(c1[0]), math.radians(c1[1])
    a = -(phi1 - phi0); ca, sa = math.cos(a), math.sin(a); out = []
    for r in rings:
        lam = np.radians(r[:, 0]) - lam0; phi = np.radians(r[:, 1])
        x = np.cos(phi) * np.cos(lam); y = np.cos(phi) * np.sin(lam); z = np.sin(phi)
        x2 = x * ca + z * sa; z2 = -x * sa + z * ca
        out.append(np.stack([np.degrees(np.arctan2(y, x2) + lam1), np.degrees(np.arcsin(np.clip(z2, -1, 1)))], 1))
    return out
def path(c0, c1, u):
    return (c0[0] + (c1[0] - c0[0]) * u, c0[1] + (c1[1] - c0[1]) * u)

# ---------------------------------------------------------------- beats (default durations, s); VO version stretches them
BEATS = [("hook", 3.0), ("merc", 5.5), ("stretch", 10.0), ("gl", 10.5), ("au", 7.5), ("ru", 7.5), ("ak", 7.0), ("eu", 7.5),
         ("il", 9.0), ("ee", 9.0), ("q", 3.6), ("seven", 11.5), ("cta", 4.2)]
DUR = [d for _, d in BEATS]
if A.vo:
    segs = json.load(open(A.segs))["segs"]; assert len(segs) == len(BEATS), "one narration line per beat (tts.txt)"
    vdur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", A.vo], capture_output=True, text=True).stdout)
    starts = [0.0] + [max(0.0, s[0] - 0.15) for s in segs[1:]] + [max(vdur + 1.5, segs[-1][1] + 2.5)]
    DUR = [max(0.8, starts[i + 1] - starts[i]) for i in range(len(BEATS))]
START = np.cumsum([0] + DUR)[:-1].tolist(); T_END = float(sum(DUR)); N = int(round(T_END * FPS))
def beat_of(t):
    k = max(i for i in range(len(BEATS)) if START[i] <= t + 1e-9)
    return k, BEATS[k][0], (t - START[k]) * BEATS[k][1] / DUR[k]      # local time in default seconds

# ---------------------------------------------------------------- drawing helpers
BG = None
def bg():
    global BG
    if BG is None:
        r = np.linspace(0, 1, H * S)[:, None]
        stops = [(0.0, hx("#0E1E3A")), (0.55, hx("#163261")), (1.0, hx("#2749D3"))]
        g = np.concatenate([np.interp(r, [p for p, _ in stops], [c[i] for _, c in stops]) for i in range(4)], 1)
        BG = Image.fromarray((g[:, None, :] * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
    return BG.copy()
QA = []
def txt(d, x, y, s, sz, col, w=800, anchor="mm", alpha=1.0, stroke=0, tag="text"):
    if alpha <= 0.01: return
    f = font(sz, w); c = al(col, alpha)
    kw = dict(font=f, anchor=anchor, direction="rtl" if any("\u0590" <= ch <= "\u05ff" for ch in s) else None)
    if stroke: kw.update(stroke_width=int(stroke * S), stroke_fill=(6, 14, 30, int(235 * alpha)))
    d.text((x * S, y * S), s, fill=c, **kw)
    if A.qa or A.snaps:
        bb = d.textbbox((x * S, y * S), s, font=f, anchor=anchor, direction=kw["direction"], stroke_width=kw.get("stroke_width", 0)); QA.append((tag, s, [v / S for v in bb]))
def wrap(s, sz, w, maxw):
    """greedy line count, then balanced breaks (minimise the widest line) so no lone last word"""
    f = font(sz, w); out = [""]
    for word in s.split():
        cand = (out[-1] + " " + word).strip()
        if f.getlength(cand) <= maxw * S: out[-1] = cand
        else: out.append(word)
    n = len(out); ws = s.split()
    if n == 1: return out
    from functools import lru_cache
    @lru_cache(None)
    def best(i, k):   # words i.. into k lines -> (max width, lines)
        if k == 1: l = " ".join(ws[i:]); return (f.getlength(l), (l,))
        res = (1e18, ())
        for j in range(i + 1, len(ws) - k + 2):
            l = " ".join(ws[i:j]); wl = f.getlength(l)
            if wl > maxw * S: break
            sub = best(j, k - 1); res = min(res, (max(wl, sub[0]), (l,) + sub[1]))
        return res
    r = best(0, n); return list(r[1]) if r[1] else out
def rrect(im, box, rad, fill, edge=None, ew=2):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([v * S for v in box], radius=rad * S, fill=fill, outline=edge, width=int(ew * S) if edge else 0)
    im.alpha_composite(lay)

def headline(im, key, a, y0=300):
    """EN + HE headline at the top of the safe zone, in a soft navy card; wraps instead of shrinking (uniform sizes)"""
    if a <= 0.01: return
    en, he = T[key]; le = wrap(en, HL_EN, 900, 930); lh = wrap(he, HL_HE, 800, 930)
    lhE, lhH = HL_EN * 1.16, HL_HE * 1.22; hgt = len(le) * lhE + len(lh) * lhH + 14
    rise = (1 - ease(a)) * 14
    rrect(im, (40, y0 - 26 + rise, 1040, y0 + hgt + 26 + rise), 34, al(CARD, 0.82 * a))
    d = ImageDraw.Draw(im); y = y0 + lhE / 2 + rise
    for l in le: txt(d, 540, y, l, HL_EN, WHITE, 900, "mm", a, tag="headline"); y += lhE
    y += 14
    for l in lh: txt(d, 540, y, l, HL_HE, SKYL, 800, "mm", a, tag="headline"); y += lhH

def chip(im, word, a, y=1468):
    """vocabulary pill: English word + Hebrew gloss, centred"""
    if a <= 0.01: return
    he = WORDS[word]; fe, fh = font(CH_EN, 900), font(CH_HE, 800)
    we, wh = fe.getlength(word) / S, fh.getlength(he) / S; gap = 34; wt = we + wh + gap + 76
    x0 = 540 - wt / 2; rise = (1 - ease(a)) * 12
    rrect(im, (x0, y - 40 + rise, x0 + wt, y + 40 + rise), 40, al(CARD, 0.94 * a), al(SKY, a), 3)
    d = ImageDraw.Draw(im)
    txt(d, x0 + 38 + we / 2, y + rise, word, CH_EN, WHITE, 900, "mm", a, tag="chip")
    d.line([((x0 + 38 + we + gap / 2) * S, (y - 20 + rise) * S), ((x0 + 38 + we + gap / 2) * S, (y + 20 + rise) * S)], fill=al(SKY, a), width=int(2 * S))
    txt(d, x0 + 38 + we + gap + wh / 2, y + rise, he, CH_HE, SKYL, 800, "mm", a, tag="chip")

def stat(im, key, a, y=1395):
    """result card at the bottom of the safe zone: big ratio + the two cited areas"""
    if a <= 0.01: return
    rise = (1 - ease(a)) * 14
    rrect(im, (90, y - 105 + rise, 990, y + 140 + rise), 36, al(CARD, 0.95 * a), al(SKY, 0.9 * a), 3)
    d = ImageDraw.Draw(im)
    txt(d, 540, y - 22 + rise, BIGNUM[key], NUM, SKY, 900, "mm", a, tag="stat")
    l1, l2 = STAT[key]
    txt(d, 540, y + 62 + rise, l1, BD_EN - 6, WHITE, 700, "mm", a, tag="stat")
    txt(d, 540, y + 106 + rise, l2, BD_EN - 6, WHITE, 700, "mm", a, tag="stat")

def label(d, cam, lonlat, name, a, m=0.0, dx=0, dy=0):
    if a <= 0.01: return
    X, Y = fwd(np.array([lonlat[0]]), np.array([lonlat[1]]), m); x, y = scr(X[0], Y[0], cam); x, y = x / S + dx, y / S + dy
    txt(d, x, y - 18, name, LB_EN, WHITE, 900, "mm", a, stroke=3.2, tag="label")
    txt(d, x, y + 18, NAMES[name], LB_HE, SKYL, 800, "mm", a, stroke=3.2, tag="label")

def proj_rings(rings, cam, m, wrap_=False):
    out = []
    for r in rings:
        for sh in ((0, -360, 360) if (wrap_ and m <= 0) else (0,)):
            X, Y = fwd(r[:, 0] + sh, r[:, 1], m); x, y = scr(X, Y, cam)
            if x.max() < -50 or x.min() > (W + 50) * S or y.max() < -50 or y.min() > (H + 50) * S: continue
            out.append(np.stack([x, y], 1))
    return out
def fill(d, pts_list, fillc, edge=None, ew=1.0):
    for p in pts_list:
        if len(p) < 3: continue
        d.polygon([tuple(q) for q in p], fill=fillc)
        if edge: d.line([tuple(q) for q in p] + [tuple(p[0])], fill=edge, width=max(1, int(ew * S)), joint="curve")

def world_frame(cam, m):
    """outline of the map itself (lon -180..180, lat -60..84) in the current projection"""
    L = 180 if m > 0 else 540      # Mercator wraps sideways (no visible edge when the camera pans past 180)
    lats = np.linspace(-60, 84, 80); lons = np.linspace(-L, L, 120)
    ring = np.concatenate([np.stack([np.full(80, -float(L)), lats], 1), np.stack([lons, np.full(120, 84.0)], 1),
                           np.stack([np.full(80, float(L)), lats[::-1]], 1), np.stack([lons[::-1], np.full(120, -60.0)], 1)])
    return proj_rings([ring], cam, m)

def base_map(im, cam, m, hl=None, grid=0.0):
    """sea + all countries (Israel gold, West Bank / Gaza #B8923F, Green Line) + highlighted shapes"""
    lv = lod_for(cam[2]); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    fill(d, world_frame(cam, m), SEA)
    if grid > 0.01:   # parallels every 30 degrees, equator brighter
        for la in (-30, 0, 30, 60):
            lo = np.linspace(-180, 180, 200); p = proj_rings([np.stack([lo, np.full(200, float(la))], 1)], cam, m)
            for q in p: d.line([tuple(v) for v in q], fill=al(SKY if la == 0 else GRID, grid * (1 if la == 0 else 1.0)), width=int((4 if la == 0 else 1.5) * S))
    for k, rs in BASE[lv].items():
        if k in ("Israel", "Palestine"): continue
        fill(d, proj_rings(rs, cam, m, True), LAND, BORDER, 1.0)
    for k, rs in (hl or {}).items():
        fill(d, proj_rings(HL[lv][k], cam, m, True), rs.get("fill", TARGET), rs.get("edge"), rs.get("ew", 2.0))
    fill(d, proj_rings(BASE[lv]["Israel"], cam, m), GOLD); fill(d, proj_rings(BASE[lv]["Palestine"], cam, m), GOLDD)
    isr = proj_rings(BASE[lv]["Israel"], cam, m)
    if isr and max(p[:, 1].max() - p[:, 1].min() for p in isr) > 40 * S:     # Green Line once Israel is big enough to see it
        for ln in GREEN_LINES:
            for q in proj_rings([ln], cam, m): d.line([tuple(v) for v in q], fill=GREENC, width=int(3.5 * S), joint="curve")
    im.alpha_composite(lay)

def lifted(im, cam, name, c0, c1, u, a=1.0, lift=1.0, ghost=1.0, m=0.0):
    """the dragged copy: ghost outline at home, drop shadow, sky fill, white edge"""
    lv = lod_for(cam[2]); rs = HL[lv][name]; lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    if ghost > 0.01:
        for p in proj_rings(rs, cam, m, True): d.line([tuple(q) for q in p] + [tuple(p[0])], fill=al(SKYL, 0.75 * ghost * a), width=int(2 * S))
    mv = move(rs, c0, path(c0, c1, u)) if u > 0 else rs
    pp = proj_rings(mv, cam, m, True)
    if lift > 0.01:
        sh = [p + np.array([7 * S * lift, 11 * S * lift]) for p in pp]; fill(d, sh, (0, 0, 0, int(95 * a * lift)))
    fill(d, pp, al(hx("#45A4DD", 205), a), al(WHITE, a), 2.6)
    im.alpha_composite(lay)

def tissot(im, cam, t0, lt, a):
    """equal 700 km circles on the globe, popping in from the equator outward"""
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay); dd = 700 / 6371.0
    for i, la in enumerate((0, 30, -30, 55, -55, 70)):
        k = ease(ramp(lt, t0 + i * 0.45, t0 + i * 0.45 + 0.5)) * a
        if k <= 0.01: continue
        for lo in (-120, -60, 0, 60, 120):
            ph0 = math.radians(la); th = np.linspace(0, 2 * np.pi, 72); r_ = dd * (0.4 + 0.6 * k)
            lat = np.arcsin(np.sin(ph0) * np.cos(r_) + np.cos(ph0) * np.sin(r_) * np.cos(th))
            lon = math.radians(lo) + np.arctan2(np.sin(th) * np.sin(r_) * np.cos(ph0), np.cos(r_) - np.sin(ph0) * np.sin(lat))
            for p in proj_rings([np.stack([np.degrees(lon), np.degrees(lat)], 1)], cam, 0):
                fill(d, [p], al(hx("#45A4DD", 120), k), al(SKYL, k), 2.2)
    im.alpha_composite(lay)

def lat_labels(d, cam, a):
    for la, s in ((0, "0°"), (30, "30°"), (60, "60°"), (-30, "30°")):
        X, Y = fwd(np.array([0.0]), np.array([float(la)])); _, y = scr(X[0], Y[0], cam)
        txt(d, 1024, y / S - 18, s, 26, SKYL if la == 0 else SUBC, 800, "rm", a, stroke=2.5, tag="grid")

# ---------------------------------------------------------------- scenes
G0 = CENT["Greenland"]
DRAGS = {   # beat: (shape, from, to, target highlight, camera bbox, label positions)
 "gl": ("Greenland", G0, (CENT["Africa"][0] + 2, CENT["Africa"][1] + 2), "Africa", (-78, 60, -36, 84)),
 "au": ("Greenland", G0, CENT["Australia"], "Australia", (-75, 160, -45, 84)),
 "ru": ("Russia", CENT["Russia"], (CENT["Africa"][0] + 4, CENT["Africa"][1] + 4), "Africa", (-25, 195, -38, 82)),
 "ak": ("Alaska", CENT["Alaska"], CENT["Brazil"], "Brazil", (-182, -28, -36, 73)),
 "eu": ("Europe", CENT["Europe"], CENT["South America"], "South America", (-95, 70, -57, 82)),
}
CAMS = {k: fit(*v[4][:2], *v[4][2:]) for k, v in DRAGS.items()}
NJ_CLOSE = fit(-79.4, -69.9, 36.6, 43.6); IL_CLOSE = fit(30.4, 39.9, 28.0, 35.0)
il_mid = fit(-85, 45, 15, 55)

def drag_scene(im, key, lt, cam_prev):
    name, c0, c1, tgt, _ = DRAGS[key]; dur = dict(BEATS)[key]
    cam = lerpcam(cam_prev, CAMS[key], ease3(ramp(lt, 0, 1.0)))
    lift = ramp(lt, 0.9, 1.4); u = ease3(ramp(lt, 1.8 if key != "gl" else 2.6, 5.0 if key != "gl" else 7.0))
    hl = {tgt: {"fill": TARGET, "edge": al(WHITE, 0.9), "ew": 2.2}}
    if key == "ru": hl["Russia"] = {"fill": LAND, "edge": al(SKYL, 0.6), "ew": 1.6}
    base_map(im, cam, 0, hl)
    fade_out = 1 - ramp(lt, dur - 0.45, dur)
    lifted(im, cam, name, c0, c1, u, a=ramp(lt, 0.6, 1.0) * fade_out, lift=lift * (1 - 0.6 * ramp(lt, 5.0, 6.0)), ghost=ramp(lt, 1.4, 2.0) * fade_out)
    d = ImageDraw.Draw(im); la = win(lt, 0.4, dur - 0.3)
    TDY = {"gl": 60, "au": 0, "ru": 100, "ak": 120, "eu": 110}; HDY = {"gl": 0, "au": 0, "ru": 0, "ak": 0, "eu": -20}
    label(d, cam, CENT[tgt], tgt, la, 0, 0, TDY[key])
    label(d, cam, c0, name, la * (1 - ramp(lt, 1.6, 2.0)), 0, 0, HDY[key])
    first, second = {"gl": ("gl1", "gl3"), "au": ("au1", "au2"), "ru": ("ru1", "ru2"), "ak": ("ak1", "ak2"), "eu": ("eu1", "eu2")}[key]
    t_res = 5.4 if key != "gl" else 7.4
    if key == "gl":
        headline(im, "gl1", win(lt, 0.0, 3.6)); headline(im, "gl2", win(lt, 3.6, t_res)); chip(im, "to scale", win(lt, 3.8, t_res + 0.1))
    else:
        headline(im, first, win(lt, 0.0, t_res))
    headline(im, second, win(lt, t_res, dur, 0.35, 0.35)); stat(im, key, win(lt, t_res + 0.15, dur, 0.4, 0.35))
    return cam

def il_scene(im, lt, cam_prev):
    c0, c1 = CENT["New Jersey"], (35.15, 31.45); dur = dict(BEATS)["il"]
    u = ease3(ramp(lt, 2.0, 5.4))
    if lt < 2.0: cam = lerpcam(cam_prev, NJ_CLOSE, ease3(ramp(lt, 0, 1.4)))
    else:   # camera rides with New Jersey across the Atlantic, pulling out half way
        cc = path(c0, c1, u); X, Y = fwd(np.array([cc[0]]), np.array([cc[1]])); s0 = NJ_CLOSE[2]; s1 = IL_CLOSE[2]
        s = math.exp(math.log(s0) + (math.log(s1) - math.log(s0)) * u - 2.6 * math.sin(math.pi * u))
        # keep the shape's centre where the close-up cameras put it
        off0 = fwd(np.array([c0[0]]), np.array([c0[1]])); off1 = fwd(np.array([c1[0]]), np.array([c1[1]]))
        dx = (1 - u) * (NJ_CLOSE[0] - off0[0][0]) * s0 / s + u * (IL_CLOSE[0] - off1[0][0]) * s1 / s
        dy = (1 - u) * (NJ_CLOSE[1] - off0[1][0]) * s0 / s + u * (IL_CLOSE[1] - off1[1][0]) * s1 / s
        cam = (X[0] + dx, Y[0] + dy, s)
    base_map(im, cam, 0, {})
    fo = 1 - ramp(lt, dur - 0.45, dur)
    lifted(im, cam, "New Jersey", c0, c1, u, a=ramp(lt, 0.9, 1.3) * fo, lift=ramp(lt, 1.3, 1.8) * (1 - ramp(lt, 5.4, 6.2)), ghost=0)
    d = ImageDraw.Draw(im)
    label(d, cam, c0, "New Jersey", win(lt, 1.0, 2.2), 0, 0, -180)
    label(d, cam, (35.0, 31.3), "Israel", win(lt, 5.6, dur - 0.1), 0, -270, 40)
    headline(im, "il1", win(lt, 0.0, 5.5)); headline(im, "il2", win(lt, 5.5, dur, 0.35, 0.35))
    chip(im, "to scale", win(lt, 2.2, 5.4)); stat(im, "il", win(lt, 5.7, dur, 0.4, 0.35))
    return cam

def ee_scene(im, lt, cam_prev):
    dur = dict(BEATS)["ee"]; m = ease3(ramp(lt, 3.2, 6.2))
    cam0 = lerpcam(cam_prev, WORLD, ease3(ramp(lt, 0, 1.4)))
    cam = lerpcam(cam0, WORLD_EE, m) if lt > 3.2 else cam0
    hl = {"Greenland": {"fill": al(SKY, 0.9), "edge": WHITE, "ew": 2}, "Africa": {"fill": TARGET, "edge": al(WHITE, 0.9), "ew": 2}}
    base_map(im, cam, m, hl)
    d = ImageDraw.Draw(im); la = win(lt, 6.0, dur, 0.4, 0.35)
    label(d, cam, CENT["Greenland"], "Greenland", la, m, 0, -62); label(d, cam, CENT["Africa"], "Africa", la, m, 0, 40)
    # projection name pill under the map
    a1 = win(lt, 0.8, 4.4); a2 = win(lt, 4.4, dur, 0.4, 0.35)
    for nm, a in (("Mercator", a1), ("Equal Earth", a2)):
        if a > 0.01:
            fe = font(CH_EN, 900); w_ = fe.getlength(nm) / S + 80
            rrect(im, (540 - w_ / 2, 1428, 540 + w_ / 2, 1508), 40, al(CARD, 0.94 * a), al(SKY, a), 3)
            txt(ImageDraw.Draw(im), 540, 1468, nm, CH_EN, WHITE, 900, "mm", a, tag="chip")
    headline(im, "ee1", win(lt, 0.0, 4.4)); headline(im, "ee2", win(lt, 4.4, dur, 0.35, 0.35))
    return cam

def end_card(im, key, lt, dur):
    a = win(lt, 0.0, dur, 0.35, 0.35 if key != "cta" else 0.01)
    if a <= 0.01: return
    rise = (1 - ease(a)) * 16
    if key == "seven":
        le = wrap(T["seven"][0], BD_EN, 800, 820); lh = wrap(T["seven"][1], BD_HE, 700, 820)
        lE, lH = BD_EN * 1.32, BD_HE * 1.36; hgt = len(le) * lE + len(lh) * lH + 50; y0 = 900 - hgt / 2
        rrect(im, (70, y0 - 60 + rise, 1010, y0 + hgt + 60 + rise), 40, al(CARD, 0.96 * a), al(SKY, 0.8 * a), 3)
        d = ImageDraw.Draw(im); y = y0 + lE / 2 + rise
        for l in le: txt(d, 540, y, l, BD_EN, WHITE, 800, "mm", a, tag="end"); y += lE
        y += 22; d.line([(440 * S, (y - 6) * S), (640 * S, (y - 6) * S)], fill=al(SKY, a), width=int(3 * S)); y += 28
        for l in lh: txt(d, 540, y, l, BD_HE, SKYL, 700, "mm", a, tag="end"); y += lH
        return
    en, he = T[key]; le = wrap(en, HL_EN, 900, 800); lh = wrap(he, HL_HE, 800, 800)
    hgt = len(le) * HL_EN * 1.18 + len(lh) * HL_HE * 1.25 + 30; y0 = 900 - hgt / 2
    rrect(im, (110, y0 - 70 + rise, 970, y0 + hgt + 70 + rise), 44, al(CARD, 0.96 * a), al(SKY, 0.9 * a), 3)
    d = ImageDraw.Draw(im); y = y0 + HL_EN * 0.59 + rise
    for l in le:
        if key == "cta" and "MAP" in l:   # keyword in sky blue
            f = font(HL_EN, 900); w1 = f.getlength("Comment ") / S; w2 = f.getlength("MAP") / S; x0 = 540 - (w1 + w2) / 2
            txt(d, x0, y, "Comment ", HL_EN, WHITE, 900, "lm", a, tag="end"); txt(d, x0 + w1, y, "MAP", HL_EN, SKY, 900, "lm", a, tag="end")
        else: txt(d, 540, y, l, HL_EN, WHITE, 900, "mm", a, tag="end")
        y += HL_EN * 1.18
    y += 30
    for l in lh: txt(d, 540, y, l, HL_HE, SKYL, 800, "mm", a, tag="end"); y += HL_HE * 1.25

CAM_END = {}     # camera each beat ends on (the next beat flies from it), see prime()
def frame(t):
    im = bg(); k, key, lt = beat_of(t); dur = BEATS[k][1]
    prev_end = CAM_END.get(k - 1, WORLD)
    if key in ("hook", "merc", "stretch"):
        cam = WORLD
        hl = {}
        ha = 1.0 if key == "hook" else (1 - ramp(lt, 0.0, 0.8) if key == "merc" else 0)
        if ha > 0.01: hl = {"Greenland": {"fill": al(SKY, 0.85 * ha + 0.0), "edge": al(WHITE, ha), "ew": 2}, "Africa": {"fill": TARGET, "edge": al(WHITE, 0.9 * ha), "ew": 2}}
        base_map(im, cam, 0, hl, grid=ramp(lt, 0.2, 1.0) if key == "stretch" else 0)
        d = ImageDraw.Draw(im)
        if key == "hook":
            label(d, cam, (-41, 74), "Greenland", 1.0, 0, 0, -10); label(d, cam, (19, 6), "Africa", 1.0, 0, 0, 0)
            headline(im, "hook", 1.0 if lt < dur - 0.3 else 1 - ramp(lt, dur - 0.3, dur))
        elif key == "merc":
            headline(im, "merc", win(lt, 0.0, dur)); chip(im, "projection", win(lt, 0.6, dur))
        else:
            tissot(im, cam, 2.2, lt, win(lt, 0.0, dur, 0.3, 0.4)); lat_labels(d, cam, win(lt, 0.4, dur))
            headline(im, "stretch", win(lt, 0.0, dur)); ta = win(lt, 2.4, dur)
            txt(d, 540, 1318, T["tissot"][0], BD_EN - 6, WHITE, 700, "mm", ta, tag="body"); txt(d, 540, 1360, T["tissot"][1], BD_HE - 6, SKYL, 700, "mm", ta, tag="body")
            chip(im, "equator", win(lt, 0.6, 3.6)); chip(im, "latitude", win(lt, 3.6, 6.6)); chip(im, "distortion", win(lt, 6.6, dur))
    elif key in DRAGS: cam = drag_scene(im, key, lt, prev_end)
    elif key == "il": cam = il_scene(im, lt, prev_end)
    elif key == "ee": cam = ee_scene(im, lt, prev_end)
    else:
        cam = WORLD_EE; base_map(im, cam, 1.0, {})
        ov = Image.new("RGBA", im.size, al(hx("#0E1E3A"), 0.72 * ramp(t, START[10], START[10] + 0.5))); im.alpha_composite(ov)
        end_card(im, key, lt, dur)
    return im

# precompute end cameras so frames can be rendered out of order (parts / snaps)
def prime():
    for k in range(len(BEATS)):
        CAM_END[k] = None
    for k in range(len(BEATS)):
        key = BEATS[k][0]; prev = CAM_END.get(k - 1) or WORLD
        if key in ("hook", "merc", "stretch"): CAM_END[k] = WORLD
        elif key in DRAGS: CAM_END[k] = CAMS[key]
        elif key == "il": CAM_END[k] = IL_CLOSE
        elif key == "ee": CAM_END[k] = WORLD_EE
        else: CAM_END[k] = WORLD_EE
prime()

if __name__ == "__main__":
    os.makedirs(f"{HERE}/qa", exist_ok=True)
    if A.snaps:
        for s_ in A.snaps.split(","):
            t = float(s_); QA.clear(); im = frame(t).reduce(S).convert("RGB"); im.save(f"{HERE}/qa/snap_{t:05.2f}.png")
            json.dump(QA, open(f"{HERE}/qa/snap_{t:05.2f}.json", "w"))
        print("snaps -> qa/"); sys.exit()
    tag = "vo" if A.vo else "mus"; os.makedirs(f"{HERE}/parts", exist_ok=True)
    if A.mux:
        parts = sorted(p for p in os.listdir(f"{HERE}/parts") if p.startswith(f"{tag}_part") and p.endswith(".mp4"))
        open(f"{HERE}/parts/{tag}_list.txt", "w").write("".join(f"file '{HERE}/parts/{p}'\n" for p in parts))
        sil = f"{HERE}/parts/{tag}_silent.mp4"
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", f"{HERE}/parts/{tag}_list.txt", "-c", "copy", sil], check=True)
        mus = f"{HERE}/music/true_size_{tag}_music.wav"
        hits = ",".join(f"{START[i] + x:.2f}" for i, x in ((3, 7.4), (4, 5.4), (5, 5.4), (6, 5.4), (7, 5.4), (8, 5.5)))
        subprocess.run(["nice", "-n", "15", "python3", f"{HERE}/music/tune.py", mus, f"{T_END:.2f}", "atlas", hits], check=True)
        aud = mus
        if A.vo:
            aud = f"{HERE}/music/true_size_vo_mix.wav"
            subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", A.vo, "-i", mus, "-filter_complex",
                            "[1:a]volume=0.32[m];[0:a]apad[v];[v][m]amix=inputs=2:duration=longest:normalize=0[o]", "-map", "[o]", "-t", f"{T_END:.2f}", aud], check=True)
        out = f"{HERE}/true_size_{tag}.mp4"
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", sil, "-i", aud, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                        "-t", f"{T_END:.2f}", "-movflags", "+faststart", out], check=True)
        print("final", out, f"{T_END:.2f}s"); sys.exit()
    f0, f1 = (int(x) for x in A.frames.split(":")) if A.frames else (0, N)
    f1 = min(f1, N); outp = f"{HERE}/parts/{tag}_part{int(A.part or 0):02d}.mp4"
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
                           "-i", "-", "-c:v", "libx264", "-preset", "fast", "-threads", "1", "-x264-params", "rc-lookahead=8:sync-lookahead=0:bframes=2", "-crf", "18", "-pix_fmt", "yuv420p", outp], stdin=subprocess.PIPE)
    for f in range(f0, f1):
        QA.clear(); im = frame(f / FPS).reduce(S).convert("RGB"); ff.stdin.write(im.tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("part", outp, f0, f1, "of", N)
