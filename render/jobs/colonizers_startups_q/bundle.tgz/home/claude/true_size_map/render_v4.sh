#!/bin/bash
# v4 chunked render: 300-frame parts, two workers (one per core), each part retried until it completes
cd /home/claude/true_size_map; mkdir -p parts_v4
N=$(python3 -c "import json;print(int(round(json.load(open('vo4/segs_v4.json'))['t_end']*30)))")
work(){ for i in $(seq $1 2 20); do a=$((i*300)); [ $a -ge $N ] && break; b=$(((i+1)*300)); ok=parts_v4/v4_part$(printf %02d $i).ok
  n=0; until [ -f $ok ] || [ $n -ge 3 ]; do n=$((n+1)); nice -n 15 python3 -W ignore engine_truesize_v4.py --frames $a:$b --part $i > parts_v4/log_$i.txt 2>&1 && touch $ok || sleep 15; done
  echo "part $i done $(date +%T)"; done; }
work 0 & P0=$!; work 1 & P1=$!; wait $P0 $P1; echo ALLDONE
