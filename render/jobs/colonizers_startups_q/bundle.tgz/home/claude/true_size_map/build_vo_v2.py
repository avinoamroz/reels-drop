"""True size v2 narration: reuse the Oct 20 take (vo/clean/noam.wav), deeper voice (rubberband pitch 0.9715, formants kept,
bass +2 dB at 135 Hz), atempo 1.1, cut into sub-line pieces (split points from silencedetect -36 dB) and re-spaced so the drags
get room; the old 7-minute + "Comment MAP" lines are replaced by lines 15 and 17 of /home/claude/growth/tts_v4.txt, taken from
/home/claude/growth/vo/vo.wav (already pitched + 1.1x, same voice), loudness matched.
out: vo/vo_v2.wav (48 kHz mono) + vo/segs_v2.json (pieces with times, cards with times) + subs_v2.txt / subs_segs_v2.json"""
import json, subprocess, os, numpy as np, soundfile as sf
HERE = os.path.dirname(os.path.abspath(__file__)); SR = 48000; TEMPO = 1.1
TMP = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"; os.makedirs(TMP, exist_ok=True)
fast = f"{TMP}/ts_fast.wav"
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-i", f"{HERE}/vo/clean/noam.wav", "-af",
                f"rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135,atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", fast], check=True)
X, sr = sf.read(fast); assert sr == SR
G, sr2 = sf.read("/home/claude/growth/vo/vo.wav"); assert sr2 == SR
if G.ndim > 1: G = G.mean(1)
# (id, source, a, b) source "ts": times in the original clean take (divided by TEMPO); "gr": times in growth/vo/vo.wav
# subtitle text: numbers as digits
P = [
 ("hook", "ts", 0.13, 2.05, "Greenland is lying to you."),
 ("merc", "ts", 2.76, 4.67, "This is the Mercator projection."),
 ("merc2", "ts", 9.09, 11.74, "And it is still the map most of us grew up with."),
 ("st1", "ts", 12.87, 17.16, "To keep shapes right, it stretches land the farther it is from the equator."),
 ("st2", "ts", 17.57, 20.09, "These circles are all the same size on the globe."),
 ("st3", "ts", 20.55, 24.73, "That stretch is called distortion, and it grows with latitude."),
 ("glA", "ts", 26.01, 27.98, "Greenland looks as big as Africa."),
 ("glD", "ts", 28.48, 30.73, "Now let's drag it to the equator, to scale."),
 ("glB", "ts", 31.27, 33.29, "Africa is about 14 times bigger."),
 ("auA", "ts", 34.63, 36.37, "Australia looks smaller than Greenland."),
 ("auB", "ts", 36.71, 39.61, "In reality, Australia is about 3.5 times bigger."),
 ("ruA", "ts", 40.93, 42.44, "Russia looks bigger than Africa."),
 ("ruD", "ts", 43.05, 43.67, "Drag it down,"),
 ("ruB", "ts", 44.13, 46.03, "and Africa is almost twice its size."),
 ("akA", "ts", 47.30, 49.00, "Alaska looks as big as Brazil."),
 ("akB", "ts", 49.48, 51.21, "Brazil is almost 5 times bigger."),
 ("euA", "ts", 52.84, 54.55, "Europe looks bigger than South America."),
 ("euB", "ts", 55.21, 58.43, "South America is about 1.7 times the size of Europe."),
 ("ilA", "ts", 59.84, 60.39, "And Israel?"),
 ("ilD", "ts", 61.26, 62.78, "Drag New Jersey over, to scale."),
 ("ilB", "ts", 64.21, 65.38, "They are about the same size."),
 ("eeA", "ts", 66.88, 68.26, "Mercator keeps the shapes."),
 ("eeB", "ts", 68.96, 73.16, "An equal area projection, like Equal Earth, keeps the sizes."),
 ("q", "ts", 75.35, 76.60, "Which country surprised you?"),
 ("seven", "gr", 64.718, 70.739, "Try this. Record yourself for 7 minutes a day, in English. What you tried, what you got wrong, what you learned."),
 ("cta", "gr", 76.326, 78.396, "Comment SPEAKER, and I'll send you the guide."),
]
# silence after each piece (s, output time); drags live in the long ones
GAP = {"hook": 0.5, "merc": 0.35, "merc2": 0.5, "st1": 0.5, "st2": 0.6, "st3": 0.45, "glA": 0.35, "glD": 1.1, "glB": 0.6, "auA": 1.35, "auB": 0.45,
       "ruA": 0.4, "ruD": 1.4, "ruB": 0.6, "akA": 1.35, "akB": 0.6, "euA": 1.35, "euB": 0.45, "ilA": 0.4, "ilD": 1.4, "ilB": 0.6,
       "eeA": 0.5, "eeB": 0.45, "q": 0.6, "seven": 0.5, "cta": 0.8}
# cards: (piece where the card starts, English words on it); a card stays until the next card starts
CARDS = [("hook", 5), ("merc", 6), ("st1", 4), ("st2", 5), ("st3", 4), ("glA", 3), ("glB", 5), ("auA", 4), ("auB", 5), ("ruA", 4), ("ruB", 5),
         ("akA", 5), ("akB", 5), ("euA", 5), ("euB", 6), ("ilA", 4), ("ilB", 6), ("eeA", 3), ("eeB", 4), ("q", 4), ("seven", 10), ("cta", 2)]
ids = [p[0] for p in P]
def clip(src, a, b):
    if src == "ts": a0, b0 = (a - 0.05) / TEMPO, (b + 0.12) / TEMPO; s = X[int(a0 * SR):int(b0 * SR)].copy(); lead = 0.05 / TEMPO
    else: a0, b0 = a - 0.05, b + 0.12; s = G[int(a0 * SR):int(b0 * SR)].copy(); lead = 0.05
    f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f); return s, lead
clips = [clip(p[1], p[2], p[3]) for p in P]
def rms_db(s):
    v = s[np.abs(s) > 0.01]; return 20 * np.log10(np.sqrt(np.mean(v ** 2)) + 1e-9)
ts_db = np.median([rms_db(c[0]) for c, p in zip(clips, P) if p[1] == "ts"])
for i, p in enumerate(P):
    if p[1] == "gr":
        g = 10 ** ((ts_db - rms_db(clips[i][0])) / 20); clips[i] = (clips[i][0] * g, clips[i][1]); print("growth clip", p[0], "gain", round(20 * np.log10(g), 2), "dB")
LEAD = 0.12
def layout():
    st = []; t = LEAD
    for i, p in enumerate(P):
        d = (p[3] - p[2]) / (TEMPO if p[1] == "ts" else 1); st.append([t, t + d]); t += d + GAP[p[0]]
    return st
# pad gaps until every card meets max(3, words / 3 + 1) s (card from its piece start - 0.15 to the next card's start - 0.15)
for _ in range(50):
    seg = layout(); ok = True
    for k, (pid, w) in enumerate(CARDS):
        i = ids.index(pid); s0 = 0 if k == 0 else seg[i][0] - 0.15
        if k + 1 < len(CARDS): e0 = seg[ids.index(CARDS[k + 1][0])][0] - 0.15; last = ids.index(CARDS[k + 1][0]) - 1
        else: e0 = seg[-1][1] + GAP["cta"]; last = len(P) - 1
        need = max(3.0, w / 3 + 1) + 0.05
        if e0 - s0 < need: GAP[ids[last]] += need - (e0 - s0); ok = False
    if ok: break
seg = layout(); T_END = seg[-1][1] + GAP["cta"]
y = np.zeros(int((T_END + 1) * SR))
for (s, lead), (a, b) in zip(clips, seg):
    i = int((a - lead) * SR); y[i:i + len(s)] += s
y = y[:int(T_END * SR)]
sf.write(f"{HERE}/vo/vo_v2.wav", y.astype(np.float32), SR, subtype="FLOAT")
seg = [[round(a, 3), round(b, 3)] for a, b in seg]
json.dump({"pieces": {p[0]: s for p, s in zip(P, seg)}, "order": ids, "gaps": {k: round(v, 3) for k, v in GAP.items()}, "t_end": round(T_END, 3),
           "cards": [c[0] for c in CARDS], "tempo": TEMPO, "pitch": "rubberband pitch=0.9715 formant=preserved, bass g=2 f=135",
           "src": "vo/clean/noam.wav (lines 1 to 11) + growth/vo/vo.wav lines 15, 17"}, open(f"{HERE}/vo/segs_v2.json", "w"), indent=1)
open(f"{HERE}/subs_v2.txt", "w").write("\n".join(p[4] for p in P) + "\n")
json.dump({"segs": seg}, open(f"{HERE}/subs_segs_v2.json", "w"))
os.remove(fast)
print("T_END", round(T_END, 2)); [print(f"{p[0]:6s} {a:6.2f} {b:6.2f}  gap {GAP[p[0]]:.2f}") for p, (a, b) in zip(P, seg)]
