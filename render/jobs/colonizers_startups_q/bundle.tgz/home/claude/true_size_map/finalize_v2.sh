#!/bin/bash
# join v2 parts, add the -14 LUFS mix, burn in subtitles (cities make_subs.py, SUB_BOTTOM 1600), make the <16 MB final + web copy, QA sheet
set -e; cd /home/claude/true_size_map
nice -n 15 python3 -W ignore engine_truesize_v2.py --mux  # copy of cities/subs/make_subs.py, decimals kept whole
ffmpeg -nostdin -v error -y -i parts_v2/v2_silent.mp4 -i music/true_size_v2_mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest -movflags +faststart parts_v2/v2_nosub.mp4
rm -f parts_v2/v2_silent.mp4
SUB_BOTTOM=1600 nice -n 15 python3 /home/claude/true_size_map/subs/make_subs_v2.py parts_v2/v2_nosub.mp4 subs_v2.txt subs_segs_v2.json parts_v2/v2_subs.mp4
rm -f parts_v2/v2_nosub.mp4
SZ=$(stat -c %s parts_v2/v2_subs.mp4)
if [ $SZ -lt 16000000 ]; then mv parts_v2/v2_subs.mp4 true_size_v2.mp4
else nice -n 15 ffmpeg -nostdin -v error -y -i parts_v2/v2_subs.mp4 -c:v libx264 -preset medium -crf 23 -pix_fmt yuv420p -c:a copy -movflags +faststart true_size_v2.mp4; rm -f parts_v2/v2_subs.mp4; fi
nice -n 15 ffmpeg -nostdin -v error -y -i true_size_v2.mp4 -c:v libx264 -preset medium -crf 27 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart true_size_v2_web.mp4
mkdir -p qa/v2/final; rm -f qa/v2/final/*.png
for t in 0.03 4 10 13.5 18.5 21 26.5 30 33 36 39.5 42 46 49 52.5 55 58.3 61.5 65.5 68.3 73 79.5; do
  ffmpeg -nostdin -v error -y -ss $t -i true_size_v2.mp4 -frames:v 1 qa/v2/final/f_$(printf %05.2f $t).png; done
python3 qa_sheet_v2.py qa/sheet_v2.png qa/v2/final/f_*.png
ls -la true_size_v2.mp4 true_size_v2_web.mp4 qa/sheet_v2.png
