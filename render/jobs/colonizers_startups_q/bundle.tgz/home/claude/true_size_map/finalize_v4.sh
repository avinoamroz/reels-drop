#!/bin/bash
# v4: music bed (tune.py atlas, hits at the v3 rule: result pieces - 0.15 s), v3 balance mix at -14 LUFS (music/mix_v4.py),
# join v4 parts, burn in subtitles (cities make_subs.py, SUB_BOTTOM 1600), final + web copy, QA sheet.
# Intermediates are deleted as soon as the next step has used them (disk is tight).
set -e; cd /home/claude/true_size_map
T=$(python3 -c "import json;print(json.load(open('vo4/segs_v4.json'))['t_end'])")
H=$(python3 -c "import json;P=json.load(open('vo4/segs_v4.json'))['pieces'];print(','.join(str(round(P[k][0]-0.15,2)) for k in ('glB','auB','ruB','akB','euB','ilB','eeB','dom1')))")
echo "t_end $T hits $H"
python3 music/tune.py music/true_size_v4_music.wav $T atlas $H
python3 music/mix_v4.py vo4/vo_v4.wav music/true_size_v4_music.wav music/true_size_v4_mix.wav 0.4064   # v3 ratio 0.456 x 10^(-1/20): vo_v4 is 1.0 LU quieter than vo_v3 (-24.0 vs -23.0 LUFS), so the music sits at the same level under the voice
nice -n 15 python3 -W ignore engine_truesize_v4.py --mux
rm -f parts_v4/v4_part*.mp4
ffmpeg -nostdin -v error -y -i parts_v4/v4_silent.mp4 -i music/true_size_v4_mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest parts_v4/v4_nosub.mp4
rm -f parts_v4/v4_silent.mp4
SUB_BOTTOM=1600 nice -n 15 python3 /home/claude/cities/subs/make_subs.py parts_v4/v4_nosub.mp4 subs_v4.txt subs_segs_v4.json parts_v4/v4_subs.mp4
rm -f parts_v4/v4_nosub.mp4
SZ=$(stat -c %s parts_v4/v4_subs.mp4)
if [ $SZ -lt 16000000 ]; then mv parts_v4/v4_subs.mp4 true_size_v4.mp4
else nice -n 15 ffmpeg -nostdin -v error -y -i parts_v4/v4_subs.mp4 -c:v libx264 -preset medium -crf 23 -pix_fmt yuv420p -c:a copy -movflags +faststart true_size_v4.mp4; rm -f parts_v4/v4_subs.mp4; fi
nice -n 15 ffmpeg -nostdin -v error -y -i true_size_v4.mp4 -c:v libx264 -preset medium -crf 27 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart true_size_v4_web.mp4
mkdir -p qa/v4/final; rm -f qa/v4/final/*.png
for t in 0.00 1.5 6 10 14 18 21.5 25 28.5 32 35 38 42 45 48.5 51 55 58 61.5 65 68.5 71.5 74.5 77 80 82.5; do
  ffmpeg -nostdin -v error -y -ss $t -i true_size_v4.mp4 -frames:v 1 qa/v4/final/f_$(printf %05.2f $t).png; done
python3 qa_sheet_v2.py qa/sheet_v4.png qa/v4/final/f_*.png
ls -la true_size_v4.mp4 true_size_v4_web.mp4 qa/sheet_v4.png
