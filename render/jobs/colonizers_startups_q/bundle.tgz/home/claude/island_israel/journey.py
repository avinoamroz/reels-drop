"""Israel's Journey, Episode 1 and 2: final narrated versions.
Visuals come from island_p1 / island_p2 (the drafts), re-timed to the voice with a piecewise-linear time warp
(voice time -> draft visual time) anchored on the ASR line starts. Subtitles are drawn at voice time.
usage: python3 journey.py 1|2 [--frames t1,t2] [--render]"""
import sys, os, json, math, subprocess
import numpy as np, cairo
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
EP = int(sys.argv[1]); sys.argv = [sys.argv[0]] + sys.argv[2:]
if EP == 1: import island_p1 as V
else: import island_p2 as V
import journey_audio as A
import kit as K
SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
W, H, FPS, SR = 1080, 1920, 30, 48000
VO = f"{HERE}/vo/vo_ep{EP}.wav"
ASR = json.load(open(f"{HERE}/vo/asr_ep{EP}.json"))
SEG = [list(s) for s in ASR["segs"]]
# line spans: ASR groups, with merged chunks split at the measured word gaps (see vo/asr_ep*.json chunks)
if EP == 1:
    SEG[6] = [12.328, 13.95]; SEG[7] = [14.23, 17.523]
    DISP = [None, "Israel's Journey, episode 1.", "Cut every land border.", "About 860 kilometers.", "And fill it with 15 kilometers of sea.",
            "Army: no tank can drive in.", "Every war becomes navy and air force.", "In my view, the water stops tanks, not rockets.",
            "15 kilometers is nothing for a missile.", "Vacations: every city is close to a beach.", "A ferry from Eilat to Haifa.",
            "Commerce: plot twist.", "About 98% of our trade already comes by sea.", "Travel: you already can't drive out of Israel for a weekend.",
            "Ben Gurion is our bridge.", "So, honestly?", None, "And peace?", "In my view, water doesn't make peace.", "Neighbors do.",
            "Cyprus is an island, and it's been divided since 1974.", None, None]
    TAIL = 2.0
    L = lambda i: SEG[i - 1][0]
    ANCH = [(0, 0), (L(3) - 0.1, 3.0), (L(4), 4.4), (L(5), 6.0), (L(6), 8.0), (L(7), 10.2), (L(8), 12.6), (L(9), 15.4), (L(10), 17.0),
            (L(11), 20.8), (L(12), 24.0), (L(13), 25.4), (L(14), 30.0), (L(15), 33.4), (L(16), 36.0), (L(17), 37.3), (L(18), 40.0),
            (L(20), 42.8), (L(21), 43.8), (L(22), 47.0), (L(23), 48.4)]
else:
    SEG[4] = [6.271, 7.70]; SEG[5] = [7.89, 9.603]; SEG[6] = [9.901, 11.455]; SEG[7] = [11.722, 12.8]; SEG[8] = [13.0, 14.3]
    SEG[11] = [16.882, 17.94]; SEG[12] = [18.17, 20.076]; SEG[16] = [24.144, 25.399]; SEG[17] = [25.789, 26.44]; SEG[18] = [26.62, 27.092]
    DISP = ["Israel's Journey, episode 2.", None, None, "Step one: dig.", "Step two: engines.", "Step three: full speed ahead.",
            "First try: the Suez Canal.", "200 meters wide.", "We're over 100 kilometers.", "We don't fit.", "Fine. West it is.",
            "Across the Mediterranean.", "Past Cyprus, Crete, and Malta.", "Then Gibraltar.", "14 kilometers.", "Sorry, Spain.",
            "And then: the ocean.", "No neighbors.", "Total quiet.", "Peace lasted three days.", "Then we started arguing about who's steering.", None, None]
    TAIL = 2.2
    L = lambda i: SEG[i - 1][0]
    ANCH = [(0, 0), (L(4) - 0.1, 3.0), (L(5), 6.0), (L(6), 9.0), (L(7), 11.6), (10.9, 12.9), (L(8), 13.6), (L(9), 14.6), (L(10), 16.3),
            (L(11), 18.0), (L(12), 18.9), (L(13), 19.6), (SEG[12][1], 22.2), (L(14), 23.3), (L(15), 24.6), (L(16), 25.6), (23.35, 27.2),
            (24.6, 30.3), (24.9, 31.0), (L(18), 33.8), (L(19), 38.2), (L(21), 45.0), (L(22), 48.0)]
VO_LEN = A.load(VO).shape[0] / SR
MUTES = [] if EP == 1 else [(SEG[18][0] - 0.25, SEG[18][1] + 0.45)]
T_END = round(SEG[-1][1] + TAIL, 2)
ANCH.append((T_END, V.T_END))
AN = np.array(ANCH, float); assert np.all(np.diff(AN[:, 0]) > 0) and np.all(np.diff(AN[:, 1]) > 0), AN
def warp(t): return float(np.interp(t, AN[:, 0], AN[:, 1]))
def unwarp(t_old): return float(np.interp(t_old, AN[:, 1], AN[:, 0]))

# subtitles at voice time
V.SUBSURF = []
SUBS = []
for i, txt in enumerate(DISP):
    if not txt: continue
    a, b = SEG[i]; cs = K.subchunks(txt); n = len(txt); pos = 0
    for cc in cs:
        p0 = txt.find(cc, pos); p1 = p0 + len(cc); pos = p1
        SUBS.append([a + (b - a) * p0 / n, a + (b - a) * p1 / n + 0.12, cc])
for x, y in zip(SUBS, SUBS[1:]):
    if y[0] - x[1] < 0.45: x[1] = y[0]
SUBSURF = [(a, b, *V.sub_surf(s)) for a, b, s in SUBS]

def draw(c, t):
    V.draw(c, warp(t))
    for a, b, ss, x, y in SUBSURF:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()

# ------------------------------------------------------------------ audio events (draft-visual times mapped to voice time)
def events():
    E = []
    if EP == 1:
        u = unwarp
        E += [(u(4.3), A.water_rush(2.8), 0), (u(6.6), A.waves(T_END - u(6.6), soft=0.6), -9, True), (u(8.6), A.tank_stop(2.2), -1),
              (u(10.35), A.jet_whoosh(2.0), 0), (u(24.15), A.ship_horn(1.8), -2), (u(30.55), A.plane_takeoff(3.0), -1)]
    else:
        u = unwarp; d_sail = u(31.0) - u(9.2)
        E += [(u(3.3), A.digging(u(6.0) - u(3.3)), 0), (u(6.25), A.engine_start(2.2), 0),
              (u(9.2), A.prop_hum(d_sail), -9, True), (u(12.85), A.scrape(1.6), 0), (u(14.5), A.scrape(1.0), -4),
              (u(24.62), A.boing(1.0), 2), (u(27.3), A.scrape(1.0), -7),
              (u(31.0), A.waves(T_END - u(31.0), soft=0.5), -10, True), (u(40.0), A.crowd_bicker(u(48.2) - u(40.0) + 0.4), -3, True)]
        busy = [tuple(x) for x in SEG]
        for t0, t1, s_, city, side in V.SPEECH:
            tp = u(t0)
            for a_, b_ in busy:                       # never pop on top of a word: move it to the end of that phrase
                if a_ - 0.05 <= tp <= b_ + 0.25: tp = b_ + 0.28
            E.append((tp, A.bubble_pop(), -9))
    return E

def render(out):
    tmp_wav = f"{SCR}/journey_ep{EP}_mix.wav"
    vo = A.load(VO); rep = A.mix(vo, T_END, events(), tmp_wav, mutes=MUTES)
    N = int(round(T_END * FPS)); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    tmp = out.replace(".mp4", "._tmp.mp4")
    cmd = ["nice", "-n", "10", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
           "-i", tmp_wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", tmp]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for fi in range(N):
        t = fi / FPS; c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_rgba(0, 0, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
        draw(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi % 300 == 0: print("ep", EP, "frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0; os.replace(tmp, out); os.remove(tmp_wav)
    return rep

def timing(rep):
    d = V.timing(); d["video"] = f"journey_ep{EP}.mp4"; d["duration_s"] = T_END; d["silent"] = False
    d["series"] = f"Israel's Journey, Episode {EP}"
    d["voice"] = {"file": f"vo/vo_ep{EP}.wav", "chain": "rubberband pitch 0.9715 formant preserved, bass g2 f135, clean_vo, atempo 1.1, 0.3 s lead",
                  "length_s": round(VO_LEN, 2), "asr": f"vo/asr_ep{EP}.json (sherpa whisper turbo)",
                  "lines": [{"start": a, "end": b, "text": l} for (a, b), l in zip(SEG, [x["line"] for x in ASR["check"]])]}
    d["time_warp_voice_to_draft"] = [[round(a, 3), round(b, 3)] for a, b in ANCH]
    def conv(x):
        if isinstance(x, (int, float)): return round(unwarp(x), 2)
        if isinstance(x, list): return [conv(y) for y in x]
        if isinstance(x, dict): return {k: conv(v) for k, v in x.items()}
        return x
    d["beats"] = [{"name": b["name"], "start": round(unwarp(b["start"]), 2), "end": round(unwarp(b["end"]), 2)} for b in d["beats"]]
    ev = d["on_screen"].get("events", {}); keep = {"distance_counter_final_km", "bonk_hits"}
    d["on_screen"]["events"] = {k: (v if k in keep else conv(v)) for k, v in ev.items()}
    for key in ("header_chips", "lines", "speech_bubbles", "sources"):
        if key in d["on_screen"]: d["on_screen"][key] = [dict(x, start=round(unwarp(x["start"]), 2), end=round(unwarp(x["end"]), 2)) for x in d["on_screen"][key]]
    d["subtitles"] = [{"start": round(a, 2), "end": round(b, 2), "text": s} for a, b, s in SUBS]
    d["subtitles_note"] = "No subtitle where the same words are on screen as a card (hook, island card, end card)."
    d["audio"] = {"music": "original procedural bed (journey_audio.music), ducked under the voice", "sfx_at_s": rep["sfx_at"],
                  "mix": "loudnorm I -14 LUFS, TP -1.5, 48 kHz", "pre_norm_I": rep["input_I"]}
    d["qa_sheet_times"] = QA_T
    return d

QA_T = ([0.0, 6.8, 12.6, 21.5, 27.4, 31.0, 35.8, 43.0] if EP == 1 else [0.0, 5.2, 8.6, 13.2, 19.0, 22.3, 28.4, 33.5])
if __name__ == "__main__":
    print("EP", EP, "voice", round(VO_LEN, 2), "T_END", T_END)
    if "--frames" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--frames") + 1].split(",")]
        surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H)
        for t in ts:
            c = cairo.Context(surf); c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_rgba(0, 0, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
            draw(c, t); V.to_pil(surf).save(f"{SCR}/j{EP}_{t:05.1f}.png")
        print("ok"); sys.exit()
    if "--remix" in sys.argv:
        out = f"{HERE}/journey_ep{EP}.mp4"; tmp_wav = f"{SCR}/journey_ep{EP}_mix.wav"; rep = A.mix(A.load(VO), T_END, events(), tmp_wav, mutes=MUTES)
        tmp = out.replace(".mp4", "._tmp.mp4")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", out, "-i", tmp_wav, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                            "-ar", "48000", "-shortest", "-movflags", "+faststart", tmp]); assert r.returncode == 0
        os.replace(tmp, out); os.remove(tmp_wav)
        json.dump(timing(rep), open(f"{HERE}/timing_ep{EP}.json", "w"), indent=1, ensure_ascii=False); print("remixed", out)
    if "--render" in sys.argv:
        out = f"{HERE}/journey_ep{EP}.mp4"; rep = render(out)
        json.dump(timing(rep), open(f"{HERE}/timing_ep{EP}.json", "w"), indent=1, ensure_ascii=False)
        subprocess.run([sys.executable, f"{HERE}/tools/make_sheet.py", out, f"{HERE}/qa_sheet_ep{EP}.png", ",".join(str(x) for x in QA_T)], check=True)
        print("done", out)
