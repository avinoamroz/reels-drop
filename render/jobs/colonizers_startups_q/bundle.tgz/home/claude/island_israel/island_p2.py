"""Island Israel, Part 2: we leave the Middle East. Silent visual draft, 1080x1920 @30, frames streamed into ffmpeg.
Same island, colours and map plane as Part 1 (island_common). Wider map: Natural Earth 1:10m land, equirectangular
(standard parallel 31.5 N), island drawn at true km scale everywhere.
python3 island_p2.py --frames 0,5,... | --render"""
import sys, os, math, json, subprocess, random
import numpy as np, cairo
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import island_common as I
from island_common import Cam, ll2km, tokm, fill_rings, stroke_lines, rings_of, lines_of, draw_island
import kit as K
from kit import ease, ramp, lerp, eob, pop, rr, circ, line, box, St
from island_p1 import (series_tag, T, HE, CH, fade, card, overlay, sub_surf, ic, poly, xbadge, down_arrow, umbrella, N255, B255, W255,
                       NAVY, BLUE, RED, WHITE, W, H, FPS, BG, land_edge, ring_edge)
from shapely.geometry import box as sbox, Point, LineString
from shapely.ops import unary_union
from shapely import affinity

T_END = 51.0
SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
AMBER = I.hx("#F2B134"); YELLOW = I.hx("#FFD54A"); SUNC = I.hx("#F6A35B"); GREY = I.GREYLAND

# ------------------------------------------------------------------ world land (two levels of detail)
BOX = sbox(-30, 5, 50, 62)
WORLD = {n: g.intersection(BOX) for n, g in I.C.items() if g.intersects(BOX) and n not in ("Israel", "Palestine")}
SPAIN_N = ("Spain", "Gibraltar")
def lod(tol, region=None, names=None, exclude=()):
    gs = [g if region is None else g.intersection(region) for n, g in WORLD.items() if n not in exclude and (names is None or n in names)]
    g = unary_union([x for x in gs if not x.is_empty]).buffer(0)
    return rings_of(tokm(g).simplify(tol))
REG_E = sbox(26, 24, 42, 40); REG_W = sbox(-26, 30, 6, 42)
L_COARSE = lod(2.5)
L_EAST = lod(0.4, REG_E)
L_WEST = lod(0.5, REG_W, exclude=SPAIN_N); L_SPAIN = lod(0.5, REG_W, names=SPAIN_N)
HOLE = rings_of(I.BUF[-1])          # where the island used to be: an Israel-shaped bay
SUEZ = np.array([ll2km(*p) for p in [(32.31, 31.27), (32.30, 30.95), (32.34, 30.70), (32.30, 30.45), (32.36, 30.25), (32.55, 30.0), (32.55, 29.95)]])

# ------------------------------------------------------------------ island motion
LX = np.asarray(I.LAND.exterior.coords)
TIP = LX[np.argmax(LX[:, 1])]                    # northern tip (Hermon)
STERN = np.array(ll2km(34.95, 29.50))            # Eilat tip: engines go here
def center_for(tip_world, rot):
    """island centre (km) that puts the local northern tip on tip_world at screen rotation rot"""
    v = TIP - np.array(I.CEN); a = -rot
    vr = np.array([v[0] * math.cos(a) - v[1] * math.sin(a), v[0] * math.sin(a) + v[1] * math.cos(a)])
    return np.array(tip_world) - vr
def local_to_world(p, cen, rot, kx=1.0, ky=1.0, ax=0.0, ay=0.0):
    v = np.array(p) - np.array(I.CEN); v = np.array([ax + (v[0] - ax) * kx, ay + (v[1] - ay) * ky]); a = -rot
    return np.array(cen) + np.array([v[0] * math.cos(a) - v[1] * math.sin(a), v[0] * math.sin(a) + v[1] * math.cos(a)])

HOME = np.array(I.CEN)
ROT_SUEZ = -math.radians(135)
C_SUEZ = center_for(ll2km(32.33, 31.36), ROT_SUEZ)
ROT_W = -math.pi / 2
# Gibraltar: strait centre line ~35.96 N. Slide the island west along that line until it touches Spain or Morocco.
GIB_TIP_LAT = 35.965
SPAIN_K = tokm(unary_union([WORLD[n] for n in SPAIN_N]).intersection(REG_W))
AFRICA_K = tokm(unary_union([WORLD[n] for n in ("Morocco", "Algeria") if n in WORLD]).intersection(REG_W))
def island_poly_world(cen, rot, kx=1, ky=1, ax=0, ay=0):
    from shapely.geometry import Polygon
    return Polygon([local_to_world(p, cen, rot, kx, ky, ax, ay) for p in LX[::3]])
GIB_LAT = 35.92; APP_LAT = 36.02
def find_bonk():
    lon = 0.5
    while lon > -6.0:
        cen = np.array(ll2km(lon, APP_LAT)); P = island_poly_world(cen, ROT_W)
        if P.intersection(SPAIN_K).area > 3.0: return lon, cen, P
        lon -= 0.01
    return lon, cen, P
BONK_LON, C_BONK, _PB = find_bonk()
CONTACT = np.asarray(_PB.intersection(SPAIN_K.buffer(0.5)).centroid.coords[0]) if _PB.intersects(SPAIN_K) else np.asarray(_PB.intersection(AFRICA_K).centroid.coords[0])
HIT_SPAIN = _PB.intersects(SPAIN_K)
C_PAST = np.array(ll2km(-8.2, GIB_LAT))       # tip well out into the Atlantic, squeezed
C_ATL = np.array(ll2km(-15.0, 37.4))
# Med route for the island centre (west-facing), via south of Cyprus, south of Crete, Malta and the Sicily channel
ROUTE_LL = [(33.0, 33.25), (29.0, 33.7), (25.2, 34.15), (20.0, 34.9), (15.2, 35.75), (11.6, 37.45), (7.0, 37.75), (2.5, 37.2), (-1.0, 36.4)]
ROUTE = np.array([C_SUEZ + np.array([60.0, 70.0])] + [center_for(ll2km(lo + 0.0, la), ROT_W) * 0 + np.array(ll2km(lo, la)) for lo, la in ROUTE_LL] + [C_BONK + np.array([25.0, 0.0])])
def km2ll(x, y): return x / I.KX + I.LON0, y / I.KY + I.LAT0
def hav(a, b):
    (lo1, la1), (lo2, la2) = km2ll(*a), km2ll(*b); p1, p2 = math.radians(la1), math.radians(la2)
    dl = math.radians(lo2 - lo1); dp = p2 - p1; h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))
TRIP_PTS = np.vstack([HOME, C_SUEZ, ROUTE, C_BONK])
TRIP_KM = sum(hav(a, b) for a, b in zip(TRIP_PTS, TRIP_PTS[1:]))
ROUTE_CUM = np.r_[0, np.cumsum([hav(a, b) for a, b in zip(ROUTE, ROUTE[1:])])]
KM_BEFORE_ROUTE = hav(HOME, C_SUEZ) + hav(C_SUEZ, ROUTE[0])

def wobble(t, t0, amp=1.0, f=5.0, damp=2.5):
    if t < t0: return 0.0
    u = t - t0; return amp * math.sin(2 * math.pi * f * u) * math.exp(-damp * u)
def island_state(t):
    """centre (km), rotation, squash kx (local x), anchor ax"""
    kx = 1.0
    if t < 9.3: cen = HOME; rot = 0.0
    elif t < 12.9:
        u = ease((t - 9.3) / 3.6); cen = HOME + (C_SUEZ - HOME) * u; rot = lerp(0.0, ROT_SUEZ, ease((t - 9.6) / 2.6))
        if t > 12.75: cen = C_SUEZ
    elif t < 18.2:
        cen = C_SUEZ.copy(); rot = ROT_SUEZ
        jig = wobble(t, 12.9, 6.0, 3.0, 1.6) + (2.5 * math.sin(t * 13) if 14.5 < t < 16.2 else 0)   # stuck: shove, shove
        cen = cen + np.array([-0.7, -0.7]) * jig; rot += math.radians(wobble(t, 12.9, 2.5, 3.0, 1.6))
    elif t < 19.2:
        u = ease((t - 18.2) / 1.0); cen = C_SUEZ + (ROUTE[0] - C_SUEZ) * u; rot = lerp(ROT_SUEZ, ROT_W, u)
    elif t < 24.4:
        u = (t - 19.2) / 5.2; u = 0.5 * ease(u) + 0.5 * u; p, _ = I.polyline_at(ROUTE, u); cen = p; rot = ROT_W
    elif t < 27.2:
        cen = C_BONK + np.array([25.0 * (1 - ease((t - 24.4) / 0.25)), 0.0]); rot = ROT_W
        if t > 24.65: cen = C_BONK + np.array([10.0 * eob(min(1, (t - 24.65) / 0.5), 2.5) * math.exp(-2 * (t - 24.65)), 0])   # recoil
        rot += math.radians(wobble(t, 24.65, 4.0, 2.2, 1.8))
    elif t < 31.0:
        sq = ease((t - 27.2) / 0.7) * (1 - ease((t - 30.3) / 0.5)); kx = lerp(1.0, 0.075, sq)
        u = ease((t - 27.9) / 2.3); cen = C_BONK + (C_PAST - C_BONK) * u; rot = ROT_W + math.radians(4 * math.sin(t * 9) * sq)
        if t > 30.3: kx = 1.0 + 0.15 * wobble(t, 30.3, 1.0, 3.0, 3.0) * (1 if t > 30.8 else ease((t - 30.3) / 0.5))
    elif t < 33.8:
        u = ease((t - 31.0) / 2.8); cen = C_PAST + (C_ATL - C_PAST) * u; rot = lerp(ROT_W, 0.0, u)
    else:
        cen = C_ATL; rot = 0.0
        if t > 45.0: rot = math.radians(14 * math.sin((t - 45.0) * 2.4) * ramp(t, 45.0, 45.6))  # who is steering
    bobv = math.sin(2 * math.pi * t / 3.4) * (1.0 if (t < 9.3 or t > 33.5) else 0.4)
    return np.asarray(cen, float), rot, kx, bobv

class ICam(Cam):
    def __init__(s, ox, oy, sc, rot, kx=1.0, ax=0.0):
        super().__init__(ox, oy, sc, rot); s.kx, s.ax = kx, ax
    def pts(s, a):
        x = a[:, 0] - s.cx; x = s.ax + (x - s.ax) * s.kx; y = -(a[:, 1] - s.cy); cr, sr = math.cos(s.rot), math.sin(s.rot)
        return np.stack([s.ox + s.s * (cr * x - sr * y), s.oy + s.s * (sr * x + cr * y)], 1)

# ------------------------------------------------------------------ camera
def logl(a, b, u): return math.exp(lerp(math.log(a), math.log(b), u))
MED_C = np.array(ll2km(15.0, 37.0)); SUEZ_C = np.array(ll2km(33.5, 32.25)); GIB_C = np.array(ll2km(-3.3, 36.0))
KEYS = [  # (t, scale, centre, oy)
    (0.0, 1.42, HOME, 1110), (3.0, 1.47, HOME, 1110), (3.9, 1.85, HOME, 865), (9.4, 1.85, HOME, 865), (12.4, 0.78, SUEZ_C, 905),
    (18.0, 0.78, SUEZ_C, 905), (19.3, 0.255, MED_C, 905), (23.2, 0.255, MED_C, 905), (24.4, 1.25, GIB_C, 905), (27.6, 1.25, GIB_C, 905)]
def cam_world(t, cen):
    if t >= 27.6:
        # follow the island out into the Atlantic
        u = ease((t - 27.9) / 3.0); c0 = GIB_C + (np.array(ll2km(-7.0, 36.0)) - GIB_C) * u
        v = ease((t - 31.0) / 2.8); cc = c0 + (C_ATL - c0) * v; s = logl(1.25, 1.3, v)
        return Cam(540, 905, s, 0, cc[0], cc[1])
    for (t0, s0, c0, o0), (t1, s1, c1, o1) in zip(KEYS, KEYS[1:]):
        if t0 <= t < t1:
            u = ease((t - t0) / (t1 - t0)); s = logl(s0, s1, u)
            # keep zooms feeling natural: centre moves in step with the log scale
            cu = (math.log(s) - math.log(s0)) / (math.log(s1) - math.log(s0)) if abs(s1 - s0) > 1e-6 else u
            cc = c0 + (c1 - c0) * cu; return Cam(540, lerp(o0, o1, u), s, 0, cc[0], cc[1])
    return Cam(540, 905, 1.45, 0, GIB_C[0], GIB_C[1])
def mask_top(t): return lerp(735, 455, ramp(t, 3.0, 3.9))

# ------------------------------------------------------------------ icons
def excavator(c, arm=0.0):
    box(c, -46, 12, 80, 20, 10, NAVY)
    for k in range(4): circ(c, -34 + k * 19, 22, 5, I.hx("#6B7684"))
    box(c, -40, -14, 62, 26, 6, AMBER); box(c, -34, -36, 26, 24, 5, AMBER); box(c, -30, -32, 18, 14, 3, I.hx("#DDEBF7"))
    c.save(); c.translate(18, -6); c.rotate(-0.5 + 0.35 * arm)
    box(c, 0, -5, 52, 10, 5, I.hx("#D99A22")); c.translate(52, 0); c.rotate(1.2 - 0.6 * arm)
    box(c, 0, -4, 38, 8, 4, I.hx("#D99A22")); c.translate(38, 0)
    poly(c, [(-4, -6), (14, -2), (10, 16), (-6, 10)], NAVY); c.restore()
def sparks(c, t, n=7, seed=1):
    rnd = random.Random(int(t * 12) + seed)
    for k in range(n):
        a = rnd.uniform(0, 2 * math.pi); r0 = rnd.uniform(6, 14); r1 = r0 + rnd.uniform(14, 30)
        line(c, [(r0 * math.cos(a), r0 * math.sin(a)), (r1 * math.cos(a), r1 * math.sin(a))], YELLOW if k % 2 else AMBER, 4)
def engine(c):
    box(c, -26, -30, 52, 56, 10, NAVY); box(c, -18, -22, 36, 8, 3, I.hx("#8C99A8")); box(c, -18, -8, 36, 8, 3, I.hx("#8C99A8"))
    box(c, -10, 26, 20, 16, 4, I.hx("#4B5A6B"))
def prop(c, ang):
    for k in range(3):
        a = ang + k * 2 * math.pi / 3; c.save(); c.rotate(a); c.scale(1, 0.38); circ(c, 22, 0, 22, I.hx("#8C99A8")); c.restore()
    circ(c, 0, 0, 8, NAVY)
def star(c, r=90, n=9):
    c.new_path()
    for k in range(2 * n):
        rr_ = r if k % 2 == 0 else r * 0.62; a = math.pi * k / n - math.pi / 2; c.line_to(rr_ * math.cos(a), rr_ * math.sin(a))
    c.close_path(); K.sa(c, YELLOW); c.fill_preserve(); K.sa(c, NAVY); c.set_line_width(5); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
def deckchair(c):
    line(c, [(-30, 30), (14, -30)], NAVY, 5); line(c, [(30, 30), (-8, -6)], NAVY, 5)
    poly(c, [(-20, 14), (14, -30), (26, -24), (-6, 18)], BLUE); line(c, [(-12, 6), (20, -27)], WHITE, 4)
def wheel(c, ang):
    c.new_path(); c.arc(0, 0, 28, 0, 2 * math.pi); K.sa(c, NAVY); c.set_line_width(7); c.stroke()
    for k in range(6):
        a = ang + k * math.pi / 3; line(c, [(0, 0), (40 * math.cos(a), 40 * math.sin(a))], NAVY, 6)
    circ(c, 0, 0, 8, NAVY)
def bubble(c, s, x, y, ax, ay, a=1.0, sc=1.0, col=WHITE, fg=N255):
    if a <= 0.01 or sc <= 0.01: return
    f = K.font(40, 900); tw = f.getlength(s); bw, bh = tw + 48, 76
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y); St.a = a
    K.sa(c, (0.05, 0.1, 0.25), 0.14); rr(c, x - bw / 2, y - bh / 2 + 6, bw, bh, 26); c.fill()
    c.new_path(); c.move_to(x - 14, y + (bh / 2 - 2) * (1 if ay > y else -1)); c.line_to(ax, ay); c.line_to(x + 14, y + (bh / 2 - 2) * (1 if ay > y else -1))
    c.close_path(); K.sa(c, col); c.fill()
    K.sa(c, col); rr(c, x - bw / 2, y - bh / 2, bw, bh, 26); c.fill(); St.a = 1.0
    c.restore(); T(c, s, 40, x, y + 1, col=fg, a=a, sc=sc)

# ------------------------------------------------------------------ text tracks
HEAD = [(3.0, 6.0, "Step 1", NAVY), (6.0, 9.0, "Step 2", NAVY), (9.0, 13.0, "Step 3", NAVY), (13.0, 18.0, "Suez Canal", NAVY),
        (18.0, 24.4, "Mediterranean", NAVY), (24.4, 32.0, "Gibraltar: 14 km", NAVY), (32.0, 38.0, "The Atlantic", BLUE)]
LINES = [(3.0, 6.0, "*Dig.*"), (6.0, 9.0, "*Engines.*"), (9.0, 10.8, "Full speed ahead."), (13.0, 18.0, "Suez? We don't *fit*."),
         (18.0, 19.4, "West it is."), (25.2, 32.0, "Sorry, *Spain*."), (32.0, 38.0, "No neighbors. *Quiet.*"),
         (40.0, 45.0, "Peace lasted *three* days."), (45.0, 48.0, "Who's *steering*?!")]
SUBS = [(3.2, 5.6, "Step one: dig."), (6.0, 8.8, "Step two: engines."), (9.2, 12.8, "Step three: full speed ahead."),
        (13.2, 17.8, "Suez? We don't fit."), (18.2, 20.8, "West it is."), (20.8, 24.2, "Across the Mediterranean."),
        (24.6, 27.5, "Gibraltar: 14 km."), (27.5, 31.8, "Sorry, Spain."), (32.2, 34.6, "And then: the ocean."), (34.6, 37.8, "No neighbors. Quiet."),
        (38.2, 44.8, "Peace lasted three days."), (45.0, 46.4, "Then we started arguing"), (46.4, 47.8, "about who's steering.")]
SUBSURF = [(a, b, *sub_surf(s)) for a, b, s in SUBS]

# ------------------------------------------------------------------ fixed things
BRIDGES = []
for lat, side in ((32.9, 1), (31.4, 1), (30.4, -1)):
    lx, ly = land_edge(lat, side); rx, _ = ring_edge(lat, side); BRIDGES.append(((lx, ly), (rx + side * 2, ly), side))
BR_T = [3.5, 4.3, 5.1]
ENG_L = [STERN + np.array([-16.0, -10.0]), STERN + np.array([16.0, -10.0])]
CITY = {"tlv": ll2km(34.78, 32.08), "jlm": ll2km(35.21, 31.78), "hfa": ll2km(34.99, 32.79), "bsh": ll2km(34.79, 31.25), "eil": ll2km(34.95, 29.6)}
LABELS = [("Cyprus", 33.2, 35.55, 19.6), ("Crete", 24.9, 35.75, 20.9), ("Malta", 14.4, 36.4, 22.0)]
SPEECH = [  # (t0, t1, text, city, side)
    (38.4, 40.0, "Ahh. Quiet.", "tlv", -1),
    (40.0, 45.0, "Where do I park?!", "tlv", -1), (40.6, 45.0, "That's MY spot!", "hfa", 1),
    (41.7, 45.0, "Elections AGAIN?!", "jlm", 1),
    (45.0, 48.0, "I'm steering!", "bsh", -1), (45.5, 48.0, "No, ME!", "eil", 1), (46.0, 48.0, "Says who?!", "jlm", 1)]

def draw(c, t):
    c.set_source_surface(BG, 0, 0); c.paint()
    cen, rot, kx, bobv = island_state(t); world = cam_world(t, cen); s = world.s
    g = ramp(t, 9.6, 11.0)           # neighbours come back as a plain grey outline
    c.push_group()
    K.sa(c, BLUE); c.rectangle(0, 0, W, H); c.fill()
    if s > 0.6:
        rings = L_EAST if world.cx > ll2km(15, 0)[0] else L_WEST + L_SPAIN
    else: rings = L_COARSE
    sp_w = 0.0
    if 24.5 < t < 28.5 and HIT_SPAIN: sp_w = wobble(t, 24.65, 0.035, 3.2, 1.4)
    def land(rr_):
        c.new_path(); c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD); I.path_rings(c, rr_, world)
        c.set_source_surface(BG, 0, 0); c.fill_preserve(); I.sa(c, GREY, g); c.fill_preserve(); I.sa(c, I.GREYEDGE, g); c.set_line_width(1.2); c.stroke()
    if rings is L_WEST + L_SPAIN or (s > 0.6 and world.cx <= ll2km(15, 0)[0]):
        land(L_WEST)
        cp = world.pt(*CONTACT); c.save(); c.translate(*cp); c.scale(1 + sp_w, 1 - sp_w * 0.7); c.translate(-cp[0], -cp[1]); land(L_SPAIN); c.restore()
    else: land(rings)
    # the Israel-shaped bay left behind, and the Suez Canal
    fill_rings(c, HOLE, world, BLUE)
    stroke_lines(c, [SUEZ], world, BLUE, max(2.0, 0.6 * s))
    # southern seas stay hidden like Part 1 until the map comes back
    if g < 1:
        y30 = world.pt(0, ll2km(35, 30.6)[1])[1]
        c.save(); c.rectangle(0, y30, W, H); c.clip(); c.set_source_surface(BG, 0, 0); c.paint_with_alpha(1 - g); c.restore()
        # neighbours ghost on top of the blue in the south, as in Part 1 (land only)
    # sunset tint over the ocean
    sun = ramp(t, 32.5, 35.0)
    if sun > 0:
        gr = cairo.LinearGradient(0, 450, 0, 1450); gr.add_color_stop_rgba(0, 1.0, 0.72, 0.45, 0.22 * sun); gr.add_color_stop_rgba(0.45, 1.0, 0.75, 0.6, 0.06 * sun); gr.add_color_stop_rgba(1, 1, 1, 1, 0)
        c.set_source(gr); c.paint()
    # route line
    if 18.2 < t < 24.6:
        u = (min(t, 24.4) - 19.2) / 5.2; u = max(0, 0.5 * ease(u) + 0.5 * u)
        d = np.r_[0, np.cumsum(np.hypot(*np.diff(ROUTE, axis=0).T))]; n = np.searchsorted(d, u * d[-1])
        P = np.vstack([C_SUEZ, ROUTE[:max(1, n)], I.polyline_at(ROUTE, u)[0]]); al = 1 - ramp(t, 23.4, 24.2)
        c.set_dash([10, 10]); stroke_lines(c, [P], world, WHITE, 4, 0.9 * al); c.set_dash([])
    pat = c.pop_group()
    yt = mask_top(t); m = cairo.LinearGradient(0, 0, 0, H)
    m.add_color_stop_rgba(0, 0, 0, 0, 0); m.add_color_stop_rgba(max(0, yt - 40) / H, 0, 0, 0, 0); m.add_color_stop_rgba((yt + 70) / H, 0, 0, 0, 1)
    m.add_color_stop_rgba(1410 / H, 0, 0, 0, 1); m.add_color_stop_rgba(1490 / H, 0, 0, 0, 0); m.add_color_stop_rgba(1, 0, 0, 0, 0)
    c.set_source(pat); c.mask(m)
    # sun
    if sun > 0:
        rg = cairo.RadialGradient(900, 560, 10, 900, 560, 160); rg.add_color_stop_rgba(0, 1, 0.78, 0.45, 0.9 * sun); rg.add_color_stop_rgba(0.45, 1, 0.7, 0.4, 0.55 * sun); rg.add_color_stop_rgba(1, 1, 0.7, 0.4, 0)
        c.set_source(rg); c.arc(900, 560, 160, 0, 2 * math.pi); c.fill()
    # --- island + its machinery
    ix, iy = world.pt(*cen); bob_px = 6 * bobv if s > 1 else 0
    ax = 0.0
    isl = ICam(ix, iy + bob_px, s, rot, kx, ax)
    # wake
    if 9.8 < t < 33.8:
        pts = []
        for k in range(16):
            tt = t - k * 0.09
            if tt < 9.8: break
            cc, rr2, kk, _ = island_state(tt); wc = cam_world(t, cc); ixx, iyy = wc.pt(*cc)
            pts.append(ICam(ixx, iyy, wc.s, rr2, kk, ax).pt(*STERN))
        if len(pts) > 2 and not (12.9 < t < 18.2) and not (24.6 < t < 27.9):
            for k in range(len(pts) - 1):
                line(c, [pts[k], pts[k + 1]], WHITE, max(3, 14 * s) * (1 - k / len(pts)), 0.55 * (1 - k / len(pts)))
    draw_island(c, isl, t, flood=1.0)
    # rock bridges (the last land edges) and diggers
    for i, ((p0, p1, side), tb) in enumerate(zip(BRIDGES, BR_T)):
        if t < tb + 0.9 and t < 9:
            al = 1 - ramp(t, tb + 0.5, tb + 0.9)
            a0 = isl.pt(*p0); a1 = isl.pt(*p1); line(c, [a0, a1], I.hx("#9AA3AE"), 16, al); line(c, [a0, a1], I.hx("#B9C0CA"), 8, al)
            if tb < t < tb + 0.8: ic(c, lambda cc: sparks(cc, t, 8, i), (a0[0] + a1[0]) / 2, a0[1], 1.0)
        ea = fade(t, 3.1 + 0.25 * i, 6.2, 0.3)
        if ea > 0:
            q = isl.pt(p1[0] + side * 26, p1[1]); arm = 0.5 + 0.5 * math.sin(t * 9 + i)
            ic(c, lambda cc: excavator(cc, arm), q[0], q[1] - 6, 0.7, a=ea, flip=(side > 0))
    # engines
    for i, e in enumerate(ENG_L):
        a_, sc = pop(t, 6.3 + 0.5 * i, 0.4)
        if sc <= 0: continue
        q = isl.pt(*e); ss = max(0.25, min(1.0, s / 1.85)) * 1.1
        ic(c, engine, q[0], q[1], ss * sc, a=a_, rot=rot)
        spin = (t - 9.0) * 26 if 9.0 < t < 34.5 else ((34.5 - 9) * 26 + (t - 34.5) * 26 * max(0, 1 - (t - 34.5) / 1.5) if t >= 34.5 else 0)
        if t > 45: spin += (t - 45) * 30
        pq = isl.pt(e[0], e[1] - 30 / max(s, 0.3)); ic(c, lambda cc: prop(cc, spin), pq[0], pq[1] + 0 * ss, ss * 1.1 * sc, a=a_, rot=rot)
        if 6.3 + 0.5 * i < t < 6.9 + 0.5 * i: ic(c, lambda cc: sparks(cc, t, 8, 5 + i), q[0], q[1], 1.0)
    # speed counter chip near the island
    if 10.8 <= t < 13.2:
        kn = 2 + int(round(10 * ramp(t, 10.8, 11.8))); T(c, f"Speed: {kn} knots", 72, 540, 400, a=fade(t, 10.8, 13.2, 0.25))
    # Suez labels
    if 13.0 <= t < 18.3:
        al = fade(t, 13.3, 18.2); p = world.ll(32.4, 30.55)
        CH(c, "Canal: 200 m", 44, p[0] - 140, p[1] + 40, NAVY, a=al)
        q = isl.pt(*I.CEN); CH(c, "Israel: 100+ km", 44, q[0] + 120, q[1] - 190, I.hx("#8F6E28"), a=fade(t, 14.0, 18.2))
        a2, s2 = pop(t, 13.0, 0.35)
        tp = isl.pt(*TIP)
        if t < 14.2: ic(c, star, tp[0] - 10, tp[1] + 10, 0.45 * s2, a=a2 * (1 - ramp(t, 13.8, 14.2)))
    # Med labels + distance
    if 18.0 <= t < 24.6:
        for nm, lo, la, t0 in LABELS:
            p = world.ll(lo, la); CH(c, nm, 40, p[0], p[1] - 34, NAVY, a=ramp(t, t0, t0 + 0.3) * (1 - ramp(t, 23.3, 23.8)))
        u = (min(t, 24.4) - 19.2) / 5.2; u = max(0, min(1, 0.5 * ease(u) + 0.5 * u)) if t > 19.2 else 0
        km = KM_BEFORE_ROUTE + u * ROUTE_CUM[-1] + (hav(ROUTE[-1], C_BONK) if t >= 24.4 else 0)
        al = fade(t, 19.4, 24.6, 0.25)
        T(c, f"Distance: {int(round(km / 10) * 10):,} km", 72, 540, 400, a=al)
    # Gibraltar bonk
    if 24.6 <= t < 27.6:
        a_, sc = pop(t, 24.65, 0.3, 0.2, 2.5); cp = world.pt(*CONTACT)
        al = a_ * (1 - ramp(t, 26.9, 27.4))
        ic(c, star, cp[0] + 20, cp[1] - 80, 1.55 * sc, a=al)
        T(c, "BOING!", 50, cp[0] + 20, cp[1] - 78, a=al, sc=sc)
        p = world.ll(-6.0, 37.15); CH(c, "Spain", 40, p[0], p[1], NAVY, a=fade(t, 24.6, 31.0))
    if 24.6 <= t < 31.0:
        p = world.ll(-5.6, 35.15); CH(c, "Morocco", 40, p[0], p[1] + 30, NAVY, a=fade(t, 24.6, 31.0))
    # Atlantic: deck chair + umbrella, then the arguing
    ca, cs = pop(t, 33.9, 0.45)
    if cs > 0 and t < 48.4:
        q = isl.pt(*CITY["tlv"]); ic(c, deckchair, q[0] + 30, q[1] + 6, 0.75 * cs, a=ca)
        q = isl.pt(*CITY["bsh"]); ic(c, umbrella, q[0] + 26, q[1] - 10, 0.8 * cs, a=ca)
    if 33.8 <= t < 48.4:
        day = 1 if t < 40.0 else (2 if t < 41.7 else (3 if t < 45.0 else 4))
        t0 = {1: 38.2, 2: 40.0, 3: 41.7, 4: 45.0}[day]
        if t >= 38.2:
            _, sc = pop(t, t0, 0.35); CH(c, f"Day {day}", 64, 540, 300, NAVY if day < 4 else RED, sc=sc, a=1 - ramp(t, 47.9, 48.3))
        for t0_, t1_, s_, city, side in SPEECH:
            a_, sc = pop(t, t0_, 0.35)
            if sc > 0 and t < t1_:
                q = isl.pt(*CITY[city]); bx = q[0] + side * 230; by = q[1] - 70
                bx = min(max(bx, 70 + K.font(40).getlength(s_) / 2 + 24), 1010 - K.font(40).getlength(s_) / 2 - 24)
                bubble(c, s_, bx, by, q[0], q[1] - 6, a=a_ * (1 - ramp(t, t1_ - 0.2, t1_)), sc=sc)
        if t > 45.0:
            q = isl.pt(*STERN); ic(c, lambda cc: wheel(cc, (t - 45) * 5 * math.sin(t * 3)), q[0], q[1] + 60, 0.9, a=ramp(t, 45.0, 45.3) * (1 - ramp(t, 47.9, 48.3)))
    hook(c, t); cta(c, t)
    for a_, b_, s_, col in HEAD:
        al = fade(t, a_, b_, 0.25)
        if al > 0: CH(c, s_, 56, 540, 300, col, a=al)
    for a_, b_, s_ in LINES:
        al = fade(t, a_, b_, 0.25)
        if al > 0: T(c, s_, 72, 540, 400, a=al)
    for a, b, ss, x, y in SUBSURF:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()

def hook(c, t):
    a = 1 - ramp(t, 3.0, 3.5); dy = -60 * ramp(t, 3.0, 3.5)
    if a <= 0: return
    series_tag(c, 2, dy, a)
    T(c, "We're already an island.", 64, 540, 445 + dy, a=a, w=800)
    T(c, "So let's *leave*.", 124, 540, 555 + dy, a=a)
    HE(c, "אז בואו נעזוב.", 540, 670 + dy, a=a, sz=64, col=B255)
def cta(c, t):
    a = ramp(t, 48.0, 48.4)
    if a <= 0: return
    overlay(c, a); al = ramp(t, 48.2, 48.6)
    T(c, "Where should we", 100, 540, 560, a=al); T(c, "*park* Israel?", 112, 540, 690, a=al)
    a1, s1 = pop(t, 48.5, 0.45)
    if s1 > 0:
        c.save(); c.translate(540, 835 + 8 * math.sin(t * 5)); c.scale(s1, s1); circ(c, 0, 0, 56, BLUE, a=a1); St.a = a1; c.scale(1.4, 1.4); down_arrow(c); St.a = 1.0; c.restore()
    a2, s2 = pop(t, 48.8, 0.45)
    T(c, "Comment and I'll make", 72, 540, 975, a=a2, sc=s2)
    if s2 > 0: CH(c, "Episode 3", 72, 540, 1080, NAVY, a=a2, sc=s2)
    a3 = ramp(t, 49.1, 49.5)
    HE(c, "איפה להחנות את ישראל?", 540, 1205, a=a3, sz=58); HE(c, "כתבו בתגובות ואעשה את פרק 3", 540, 1275, a=a3, sz=58)

def to_pil(surf):
    from PIL import Image
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data()); return Image.fromarray(a[:, :, [2, 1, 0]].copy())
QA_T = [0.0, 4.4, 7.5, 15.5, 21.5, 25.2, 29.0, 46.5]
def timing():
    beats = [("hook", 0, 3), ("dig", 3, 6), ("engines", 6, 9), ("full_speed", 9, 13), ("suez_stuck", 13, 18), ("mediterranean", 18, 24.4),
             ("gibraltar", 24.4, 32), ("atlantic", 32, 38), ("days", 38, 45), ("steering", 45, 48), ("cta", 48, T_END)]
    return {"video": "island_p2_draft.mp4", "fps": FPS, "size": [W, H], "duration_s": T_END, "silent": True,
            "beats": [{"name": n, "start": a, "end": b} for n, a, b in beats],
            "subtitles": [{"start": a, "end": b, "text": s} for a, b, s in SUBS],
            "subtitles_note": "Hook and CTA are on screen as cards, so no duplicate subtitle there.",
            "on_screen": {"header_chips": [{"start": a, "end": b, "text": s} for a, b, s, _ in HEAD],
                          "lines": [{"start": a, "end": b, "text": s.replace("*", "")} for a, b, s in LINES],
                          "speech_bubbles": [{"start": a, "end": b, "text": s} for a, b, s, _, _ in SPEECH],
                          "events": {"bridges_cut": BR_T, "engines_bolt_on": [6.3, 6.8], "sail": 9.3, "speed_counter_0_to_12_knots": [10.8, 11.8],
                                     "suez_stuck": [12.9, 18.2], "turn_west": [18.2, 19.2], "med_crossing": [19.2, 24.4],
                                     "distance_counter_final_km": int(round(TRIP_KM / 10) * 10),
                                     "gibraltar_bonk": 24.65, "bonk_hits": "Spain" if HIT_SPAIN else "Morocco", "squeeze": [27.2, 30.3],
                                     "pop_back": 30.3, "atlantic_arrive": 33.8, "day_counter": {"Day 1": 38.2, "Day 2": 40.0, "Day 3": 41.7, "Day 4": 45.0},
                                     "who_steers_spin": 45.0, "cta": 48.0}},
            "qa_sheet_times": QA_T}
if __name__ == "__main__":
    print("bonk lon", round(BONK_LON, 2), "hits Spain", HIT_SPAIN, "trip km", round(TRIP_KM))
    if "--frames" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--frames") + 1].split(",")]
        surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H)
        for t in ts:
            c = cairo.Context(surf); draw(c, t); to_pil(surf).save(f"{SCR}/p2_{t:05.1f}.png")
        print("ok"); sys.exit()
    out = f"{HERE}/island_p2_draft.mp4"; tmp = f"{HERE}/_tmp_island_p2.mp4"
    N = int(round(T_END * FPS)); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    cmd = ["nice", "-n", "10", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
           "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "64k", "-shortest", "-movflags", "+faststart", tmp]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for fi in range(N):
        t = fi / FPS; c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_rgba(0, 0, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
        draw(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi % 300 == 0: print("frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0; os.replace(tmp, out)
    json.dump(timing(), open(f"{HERE}/timing_p2.json", "w"), indent=1, ensure_ascii=False)
    subprocess.run([sys.executable, f"{HERE}/tools/make_sheet.py", out, f"{HERE}/qa_sheet_p2.png", ",".join(str(x) for x in QA_T)], check=True)
    print("done", out)
