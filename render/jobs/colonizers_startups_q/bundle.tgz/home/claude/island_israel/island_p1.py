"""What if Israel were an island? Part 1, silent visual draft. 1080x1920 @30, frames streamed into ffmpeg.
python3 island_p1.py --frames 0,5.5,...   -> preview PNGs in the scratchpad
python3 island_p1.py --render             -> island_draft.mp4 + qa_sheet.png + timing.json"""
import sys, os, math, json, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import island_common as I
from island_common import Cam, ll2km, tokm, fill_rings, stroke_lines, rings_of, lines_of, draw_island, sa as isa
import kit as K
from kit import ease, ramp, lerp, eob, pop, tx, chip, rr, circ, line, box, St
from shapely.geometry import box as sbox, LineString, Point
from shapely.ops import unary_union

W, H, FPS = 1080, 1920, 30
T_END = 50.5
SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
N255 = (22, 50, 96, 255); B255 = (42, 136, 212, 255); W255 = (255, 255, 255, 255); G255 = (184, 146, 63, 255)
NAVY = I.NAVYC; BLUE = I.WATER; RED = I.hx("#D64545"); SLATE = I.hx("#56606D"); WHITE = (1, 1, 1, 1); GOLDC = I.GOLDL
SUB_BOTTOM = 1490

# ------------------------------------------------------------------ geometry for the wider view
VIEW = sbox(27.5, 24.5, 41.5, 38.5)
OTHERS = {n: g for n, g in I.C.items() if g.intersects(VIEW) and n not in ("Israel", "Palestine")}
ALL_LAND_LL = unary_union(list(I.C[n] for n in OTHERS) + [I.LAND_LL]).buffer(0)
SEA0 = VIEW.difference(ALL_LAND_LL)
SEA = tokm(SEA0.intersection(sbox(27.5, 30.6, 41.5, 38.5))).simplify(0.3)
SEA_S = tokm(SEA0.intersection(sbox(27.5, 24.5, 41.5, 30.6))).simplify(0.3)
NEIGH_N = ["Lebanon", "Syria", "Jordan", "Egypt", "Saudi Arabia", "Iraq"]
NEIGH = [rings_of(tokm(OTHERS[n].intersection(VIEW)).simplify(0.3)) for n in NEIGH_N if n in OTHERS]
STAY_N = ["Turkey", "Cyprus", "N. Cyprus", "Cyprus U.N. Buffer Zone", "Akrotiri", "Dhekelia"]
CYP = tokm(unary_union([OTHERS[n] for n in STAY_N[1:] if n in OTHERS]).buffer(0)).simplify(0.25)
TURK = tokm(OTHERS["Turkey"].intersection(VIEW)).simplify(0.4)
R_SEA = rings_of(SEA); R_SEA_S = rings_of(SEA_S); R_CYP = rings_of(CYP); R_TURK = rings_of(TURK)
from shapely.ops import linemerge
_south = unary_union([OTHERS[n] for n in ("Cyprus", "Cyprus U.N. Buffer Zone", "Dhekelia") if n in OTHERS]).buffer(0.02)
_sp = OTHERS["N. Cyprus"].boundary.intersection(_south)
_sp = linemerge([g for g in getattr(_sp, "geoms", [_sp]) if g.geom_type == "LineString"])
SPLIT = sorted(lines_of(tokm(_sp).simplify(0.3)), key=lambda a: -np.hypot(*np.diff(a, axis=0).T).sum())
SPLIT_LINE = SPLIT[0] if SPLIT else None
if SPLIT_LINE is not None and SPLIT_LINE[0, 0] > SPLIT_LINE[-1, 0]: SPLIT_LINE = SPLIT_LINE[::-1]
NB_BORDERS = [lines_of(tokm(OTHERS[n].boundary.intersection(VIEW)).simplify(0.3)) for n in NEIGH_N if n in OTHERS]

def ring_edge(lat, side):
    """x (km) of the ring's outer edge (side=+1 east, -1 west) at a latitude"""
    y = ll2km(35, lat)[1]; g = I.BUF[-1].intersection(LineString([(-400, y), (400, y)]))
    xs = [p[0] for p in (np.asarray(g.coords) if not hasattr(g, "geoms") else np.vstack([np.asarray(q.coords) for q in g.geoms]))]
    return (max(xs) if side > 0 else min(xs)), y
def land_edge(lat, side):
    y = ll2km(35, lat)[1]; g = I.LAND.intersection(LineString([(-400, y), (400, y)]))
    xs = [p[0] for p in (np.asarray(g.coords) if not hasattr(g, "geoms") else np.vstack([np.asarray(q.coords) for q in g.geoms]))]
    return (max(xs) if side > 0 else min(xs)), y

# ------------------------------------------------------------------ camera
def bob(t):
    u = ramp(t, 6.8, 8.2); return u * 6 * math.sin(2 * math.pi * t / 3.4), u * 0.006 * math.sin(2 * math.pi * t / 4.1 + 1)
PEACE_C = ll2km(34.45, 32.75)
def cam_base(t):
    s, oy, cx, cy = 1.42, 1110, I.CEN[0], I.CEN[1]
    u = ramp(t, 3.0, 3.9); s = lerp(1.42 + 0.05 * min(t, 3) / 3, 1.85, u); oy = lerp(1110, 905, u)
    v = ramp(t, 40.2, 41.8)
    s = lerp(s, 1.12, v); oy = lerp(oy, 930, v); cx = lerp(cx, PEACE_C[0], v); cy = lerp(cy, PEACE_C[1], v)
    return s, oy, cx, cy
def cams(t):
    s, oy, cx, cy = cam_base(t); dy, rot = bob(t)
    world = Cam(540, oy, s, 0, cx, cy)
    # island cam: same mapping plus bob around the island centre
    ix, iy = world.pt(*I.CEN)
    isl = Cam(ix, iy + dy, s, rot, I.CEN[0], I.CEN[1])
    return world, isl
def mask_top(t): return lerp(715, 455, ramp(t, 3.0, 3.9))

# ------------------------------------------------------------------ icons (drawn around 0,0, ~120 units wide)
def poly(c, pts, col, a=1.0):
    c.new_path(); c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.close_path(); K.sa(c, col, a); c.fill()
def tank(c):
    box(c, -54, 6, 108, 26, 13, I.hx("#2F3742"))
    for k in range(5): circ(c, -40 + k * 20, 19, 7, I.hx("#6B7684"))
    poly(c, [(-52, 8), (52, 8), (44, -6), (-46, -6)], I.hx("#56606D"))
    box(c, -24, -26, 46, 22, 9, I.hx("#6A7482"))
    box(c, -76, -20, 54, 7, 3, I.hx("#4A535F"))
def warship(c):
    poly(c, [(-66, 0), (70, 0), (54, 18), (-56, 18)], I.hx("#4B5A6B"))
    box(c, -30, -16, 44, 17, 3, I.hx("#8C99A8")); box(c, -16, -30, 18, 15, 3, I.hx("#A3AEBB"))
    line(c, [(-7, -30), (-7, -46)], I.hx("#4B5A6B"), 3); box(c, 30, -8, 16, 9, 2, I.hx("#8C99A8"))
    line(c, [(44, -4), (62, -9)], I.hx("#4B5A6B"), 4)
def cargo(c):
    poly(c, [(-68, 0), (72, 0), (58, 20), (-58, 20)], I.hx("#163260"))
    cols = ["#2A88D4", "#B8923F", "#E9ECF1", "#2A88D4", "#B8923F", "#E9ECF1"]
    for k in range(6): box(c, -40 + k * 16, -14, 14, 13, 1.5, I.hx(cols[k])); box(c, -40 + k * 16, -28, 14, 13, 1.5, I.hx(cols[(k + 2) % 6]))
    box(c, 52, -30, 16, 30, 2, WHITE); box(c, 55, -26, 10, 5, 1, I.hx("#163260"))
def jet(c):
    poly(c, [(60, 0), (40, -6), (-40, -6), (-52, -3), (-52, 3), (-40, 6), (40, 6)], NAVY)
    poly(c, [(18, -5), (-18, -46), (-30, -46), (-12, -5)], NAVY); poly(c, [(18, 5), (-18, 46), (-30, 46), (-12, 5)], NAVY)
    poly(c, [(-36, -5), (-50, -20), (-56, -20), (-48, -4)], NAVY); poly(c, [(-36, 5), (-50, 20), (-56, 20), (-48, 4)], NAVY)
def airliner(c):
    box(c, -58, -7, 120, 14, 7, NAVY)
    poly(c, [(12, -6), (-14, -58), (-26, -58), (-8, -6)], NAVY); poly(c, [(12, 6), (-14, 58), (-26, 58), (-8, 6)], NAVY)
    poly(c, [(-44, -5), (-56, -24), (-62, -24), (-56, -5)], NAVY); poly(c, [(-44, 5), (-56, 24), (-62, 24), (-56, 5)], NAVY)
def umbrella(c):
    c.save(); c.scale(1, 0.35); circ(c, 4, 80, 22, NAVY, 0.18); c.restore()
    line(c, [(0, -26), (6, 28)], NAVY, 4)
    n = 6
    for k in range(n):
        a0 = math.pi + k * math.pi / n; a1 = a0 + math.pi / n
        c.new_path(); c.move_to(0, -26); c.arc(0, -26, 36, a0, a1); c.close_path()
        K.sa(c, BLUE if k % 2 == 0 else WHITE); c.fill()
    c.new_path(); c.arc(0, -26, 36, math.pi, 2 * math.pi); K.sa(c, NAVY); c.set_line_width(2.5); c.stroke()
def ferry(c):
    poly(c, [(-70, 0), (72, 0), (60, 22), (-60, 22)], WHITE)
    box(c, -70, 8, 142, 6, 2, BLUE)
    box(c, -46, -18, 96, 18, 4, WHITE); box(c, -30, -32, 60, 14, 4, WHITE)
    for k in range(7): box(c, -40 + k * 13, -13, 8, 7, 1.5, NAVY)
    box(c, 6, -48, 14, 16, 2, BLUE); box(c, 6, -50, 14, 5, 1, NAVY)
    c.new_path(); c.move_to(-70, 0); c.line_to(72, 0); c.line_to(60, 22); c.line_to(-60, 22); c.close_path()
    K.sa(c, NAVY); c.set_line_width(2.5); c.stroke()
def car(c):
    box(c, -50, -10, 100, 26, 10, BLUE)
    poly(c, [(-28, -10), (-16, -30), (18, -30), (32, -10)], BLUE)
    poly(c, [(-22, -12), (-13, -26), (-2, -26), (-2, -12)], I.hx("#DDEBF7")); poly(c, [(3, -12), (3, -26), (15, -26), (25, -12)], I.hx("#DDEBF7"))
    circ(c, -28, 17, 11, NAVY); circ(c, 28, 17, 11, NAVY); circ(c, -28, 17, 4, WHITE); circ(c, 28, 17, 4, WHITE)
def barrier(c):
    box(c, -6, -40, 12, 70, 3, NAVY)
    for k in range(6): box(c, 6 + k * 16, -36, 16, 10, 0, RED if k % 2 == 0 else WHITE)
    c.new_path(); c.rectangle(6, -36, 96, 10); K.sa(c, NAVY); c.set_line_width(2); c.stroke()
def pin(c):
    c.new_path(); c.move_to(0, 30); c.curve_to(-8, 12, -26, -4, -26, -22); c.arc(0, -22, 26, math.pi, 2 * math.pi)
    c.curve_to(26, -4, 8, 12, 0, 30); c.close_path(); K.sa(c, NAVY); c.fill(); circ(c, 0, -22, 10, WHITE)
def rocket(c):
    poly(c, [(-10, -26), (-10, 22), (10, 22), (10, -26), (0, -42)], I.hx("#4B5A6B"))
    poly(c, [(-10, 8), (-20, 26), (-10, 22)], NAVY); poly(c, [(10, 8), (20, 26), (10, 22)], NAVY)
    poly(c, [(-6, 22), (0, 40), (6, 22)], I.hx("#F2A33A"))
def xbadge(c):
    circ(c, 0, 0, 22, RED, stroke=WHITE, sw=4); line(c, [(-8, -8), (8, 8)], WHITE, 5); line(c, [(8, -8), (-8, 8)], WHITE, 5)
def down_arrow(c):
    line(c, [(0, -26), (0, 22)], WHITE, 9); line(c, [(-17, 6), (0, 24), (17, 6)], WHITE, 9)
def ic(c, fn, x, y, s, a=1.0, rot=0.0, flip=False):
    if a <= 0.01 or s <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(-s if flip else s, s); old = St.a; St.a = a
    fn(c); St.a = old; c.restore()

# ------------------------------------------------------------------ text helpers
def T(c, s, sz, x, y, col=N255, a=1.0, sc=1.0, w=900, hl=B255):
    if a <= 0.01: return
    St.a = 1.0; tx(c, s, sz, x, y, w, col, a, sc, hl=hl, shadow=False, maxw=940)
def HE(c, s, x, y, a=1.0, sz=64, col=N255):
    if a <= 0.01: return
    St.a = 1.0; tx(c, s, sz, x, y, 700, col, a, 1.0, shadow=False, maxw=940)
def CH(c, s, sz, x, y, bg, fg=W255, a=1.0, sc=1.0):
    if a <= 0.01: return
    St.a = 1.0; chip(c, s, sz, x, y, bg, fg, a, sc)
def fade(t, a, b, d=0.3): return ramp(t, a, a + d) * (1 - ramp(t, b - d, b))
def card(c, x, y, w, h, a, r=40):
    if a <= 0.01: return
    K.sa(c, (0.05, 0.1, 0.25), 0.10 * a); rr(c, x - w / 2, y - h / 2 + 12, w, h, r); c.fill()
    K.sa(c, WHITE, 0.96 * a); rr(c, x - w / 2, y - h / 2, w, h, r); c.fill()
def source(c, t, s, a, b):
    T(c, s, 38, 540, 1530, col=(22, 50, 96, 255), a=0.8 * fade(t, a, b), w=700)

# header / line track (top zone)
HEAD = [  # (t0, t1, chip text, chip colour)
    (8.0, 12.6, "Army", NAVY), (12.6, 17.0, "In my view", BLUE), (17.0, 24.0, "Vacations", NAVY), (24.0, 30.0, "Commerce", NAVY),
    (30.0, 36.0, "Travel", NAVY), (40.0, 47.0, "In my view", BLUE)]
LINES = [
    (8.0, 10.2, "No tank can drive in."), (10.2, 12.6, "Every war: *navy* and *air force*."), (12.6, 17.0, "Water stops tanks. Not rockets."),
    (17.0, 20.7, "Every city near a *beach*."), (20.7, 24.0, "A ferry: *Eilat* to *Haifa*."), (24.0, 30.0, "Plot twist."),
    (30.0, 33.4, "No weekend drive abroad."), (33.4, 36.0, "*Ben Gurion* is our bridge."),
    (40.0, 42.8, "Water doesn't make peace."), (42.8, 47.0, "*Neighbors* do.")]

SUBS = [(3.2, 4.6, "Cut every land border."), (4.6, 6.0, "About 860 kilometers."), (6.0, 8.0, "Fill it with 15 kilometers of sea."),
        (8.2, 10.2, "Army: no tank can drive in."), (10.2, 12.6, "Every war becomes navy and air force."),
        (12.6, 14.6, "In my view, the water stops tanks,"), (14.6, 15.4, "not rockets."), (15.4, 17.0, "15 km is nothing for a missile."),
        (17.2, 20.6, "Vacations: every city is near a beach."), (20.8, 24.0, "A ferry from Eilat to Haifa."),
        (24.2, 25.6, "Commerce: plot twist."), (25.6, 27.6, "About 98% of our trade"), (27.6, 30.0, "already comes by sea."),
        (30.2, 31.9, "Travel: you already can't drive"), (31.9, 33.6, "out of Israel for a weekend."), (33.6, 36.0, "Ben Gurion is our bridge."),
        (36.1, 37.4, "So, honestly?"),
        (40.2, 41.4, "Peace: in my view,"), (41.4, 42.8, "water doesn't make peace."), (42.8, 43.8, "Neighbors do."),
        (43.8, 45.0, "Cyprus is an island,"), (45.0, 47.0, "and it's been divided since 1974.")]
SF = ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54)
def sub_surf(txt):
    assert not any(d in txt for d in K.DASHES), txt
    words = txt.split(); lines = []; cur = ''
    for x in words:
        tr = (cur + ' ' + x).strip()
        if SF.getlength(tr) <= 920: cur = tr
        else: lines.append(cur); cur = x
    lines.append(cur); lh = 66; Wd = int(max(SF.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
    im = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(8, 16, 40, 205))
    for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=SF, fill=(255, 255, 255), anchor='mm')
    return K.pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd
SUBSURF = [(a, b, *sub_surf(s)) for a, b, s in SUBS]

# ------------------------------------------------------------------ fixed positions (km)
E_STOPS = []
for lat, side in ((31.9, 1), (32.95, 1), (30.45, -1)):
    x, y = ring_edge(lat, side); E_STOPS.append((x + side * 32, y, side))
UMB = []
for lat in (33.05, 32.55, 32.05, 31.55, 31.05, 30.55, 30.05):
    x, y = land_edge(lat, 1); UMB.append((x - 3.5, y))
for lat in (30.25, 30.9):
    x, y = land_edge(lat, -1); UMB.append((x + 3.0, y))
EILAT = ll2km(34.95, 29.53); HAIFA = ll2km(34.95, 32.83)
FERRY = I.arc_between(I.MID, EILAT, HAIFA, west=True)
if np.hypot(*(FERRY[0] - np.array(EILAT))) > np.hypot(*(FERRY[-1] - np.array(EILAT))): FERRY = FERRY[::-1]
JLM = ll2km(35.21, 31.78); BGN = ll2km(34.887, 32.005)
PORTS = [ll2km(34.98, 32.82), ll2km(34.62, 31.81), ll2km(34.52, 31.67)]
CAR_LAT = 31.87; CX_EDGE, CY_EDGE = ring_edge(CAR_LAT, 1)

# ------------------------------------------------------------------ the frame
BG = I.bg_surface()
LBL = [("Lebanon", 36.05, 33.6), ("Syria", 36.9, 32.9), ("Jordan", 36.55, 30.9), ("Egypt", 33.4, 30.2), ("Mediterranean", 33.75, 32.35)]
def draw(c, t):
    c.set_source_surface(BG, 0, 0); c.paint()
    world, isl = cams(t); s = world.s
    # --- background map group (masked at top/bottom)
    c.push_group()
    na = 1 - ramp(t, 3.6, 4.7)
    fill_rings(c, R_SEA, world, BLUE); fill_rings(c, R_SEA_S, world, BLUE, na)
    for rr_ in NEIGH: fill_rings(c, rr_, world, I.GREYLAND, na)
    for bl in NB_BORDERS: stroke_lines(c, bl, world, WHITE, 2.0, na * 0.9)
    fill_rings(c, R_TURK, world, I.GREYLAND); fill_rings(c, R_CYP, world, I.GREYLAND, 1, edge=I.GREYEDGE, ew=1.2)
    if SPLIT_LINE is not None:
        u = ramp(t, 42.4, 43.4)
        if u > 0:
            n = max(2, int(len(SPLIT_LINE) * u)); stroke_lines(c, [SPLIT_LINE[:n]], world, RED, 7)
    pat = c.pop_group()
    yt = mask_top(t); m = cairo.LinearGradient(0, 0, 0, H)
    m.add_color_stop_rgba(0, 0, 0, 0, 0); m.add_color_stop_rgba(max(0, yt - 40) / H, 0, 0, 0, 0); m.add_color_stop_rgba((yt + 70) / H, 0, 0, 0, 1)
    m.add_color_stop_rgba(1410 / H, 0, 0, 0, 1); m.add_color_stop_rgba(1490 / H, 0, 0, 0, 0); m.add_color_stop_rgba(1, 0, 0, 0, 0)
    c.set_source(pat); c.mask(m)
    for nm, lo, la in LBL:
        x, y = world.ll(lo, la); al = (na if nm != "Mediterranean" else 1 - ramp(t, 3.0, 3.6))
        if y > yt + 40: T(c, nm, 40, x, y, col=(255, 255, 255, 255) if nm == "Mediterranean" else (70, 82, 102, 255), a=al * 0.95, w=700)
    # --- island
    flood = ease((t - 4.4) / 2.4) if t > 4.4 else 0.0
    draw_island(c, isl, t, flood=flood)
    # --- 15 km bracket
    a15 = fade(t, 6.5, 8.6)
    if a15 > 0:
        lx, ly = land_edge(31.0, 1); rx, _ = ring_edge(31.0, 1)
        p0 = isl.pt(lx, ly); p1 = isl.pt(rx, ly)
        line(c, [(p0[0], p0[1]), (p1[0], p1[1])], NAVY, 3, a15); line(c, [(p0[0], p0[1] - 12), (p0[0], p0[1] + 12)], NAVY, 3, a15)
        line(c, [(p1[0], p1[1] - 12), (p1[0], p1[1] + 12)], NAVY, 3, a15)
        CH(c, "15 km of sea", 42, p1[0] + 150, p1[1], NAVY, a=a15)
    hook(c, t); flood_beat(c, t); army(c, t, world, isl); vacations(c, t, isl); commerce(c, t, world, isl); travel(c, t, world, isl)
    twist(c, t); peace(c, t, world); cta(c, t)
    # header chips + lines
    for a_, b_, s_, col in HEAD:
        al = fade(t, a_, b_, 0.25)
        if al > 0: CH(c, s_, 56, 540, 300, col, a=al)
    for a_, b_, s_ in LINES:
        al = fade(t, a_, b_, 0.25)
        if al > 0: T(c, s_, 72, 540, 400, a=al)
    for a, b, ss, x, y in SUBSURF:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()

def hook(c, t):
    a = 1 - ramp(t, 3.0, 3.5); dy = -60 * ramp(t, 3.0, 3.5)
    if a <= 0: return
    series_tag(c, 1, dy, a)
    T(c, "What if Israel", 124, 540, 450 + dy, a=a); T(c, "were an *island*?", 124, 540, 585 + dy, a=a)
    HE(c, "מה אם ישראל הייתה אי?", 540, 695 + dy, a=a, sz=66, col=B255)
def series_tag(c, ep, dy, a):
    CH(c, f"ISRAEL'S JOURNEY | EPISODE {ep}", 40, 540, 282 + dy, GOLDC, a=a)
    HE(c, f"המסע של ישראל | פרק {ep}", 540, 345 + dy, a=a, sz=44, col=(110, 86, 36, 255))
def flood_beat(c, t):
    a = fade(t, 3.5, 8.0)
    if a <= 0: return
    u = ease((t - 4.4) / 2.4) if t > 4.4 else 0.0; km = int(round(860 * (1 - u)))
    T(c, "Land borders", 50, 540, 285, a=a, w=800)
    done = u >= 0.999; p = pop(t, 6.8, 0.4)[1] if done else 1.0
    T(c, f"{km} km", 112, 540, 385, col=B255 if done else N255, a=a, sc=p if done else 1.0)
    source(c, t, "Source: CIA World Factbook", 3.6, 8.0)
def army(c, t, world, isl):
    if not (8.0 <= t < 17.3): return
    A = 1 - ramp(t, 16.8, 17.2)
    for i, (x, y, side) in enumerate(E_STOPS):
        t0 = 8.3 + i * 0.35; u = ramp(t, t0, t0 + 1.6)
        sx, sy = world.pt(x, y); start = sx + side * 560
        px = lerp(start, sx, eob(min(1, max(0, (t - t0) / 1.6)), 0.6)) if t > t0 else start
        ic(c, tank, px, sy, 0.8, a=A * ramp(t, t0, t0 + 0.2), flip=(side < 0))
        a_, sc = pop(t, t0 + 1.7, 0.35)
        if sc > 0: ic(c, xbadge, px, sy - 50, 1.0 * sc, a=A * a_)
    # warships in the real Mediterranean
    for i, (lo, la) in enumerate(((33.55, 32.45), (33.75, 31.75))):
        x, y = world.ll(lo, la); a_, sc = pop(t, 10.2 + i * 0.25)
        ic(c, warship, x, y + 4 * math.sin(t * 2 + i), 0.95 * sc, a=A * a_)
    # jets crossing
    for i in range(2):
        t0 = 10.4 + i * 0.3; u = (t - t0) / 2.2
        if 0 <= u <= 1:
            x0, y0 = 120 - i * 60, 1250 - i * 40; x1, y1 = 1150, 520 - i * 40
            x = lerp(x0, x1, u); y = lerp(y0, y1, u); ang = math.atan2(y1 - y0, x1 - x0)
            line(c, [(lerp(x0, x1, max(0, u - 0.25)), lerp(y0, y1, max(0, u - 0.25))), (x, y)], NAVY, 3, 0.25 * A)
            ic(c, jet, x, y, 0.55, a=A, rot=ang)
    # rocket arcs over the water
    t0 = 13.8; u = ramp(t, t0, t0 + 1.4)
    if t > t0:
        ex, ey = land_edge(31.25, 1); x1, y1 = isl.pt(ex - 25, ey); x0, y0 = 1010, 1150
        pts = [(lerp(x0, x1, k / 40), lerp(y0, y1, k / 40) - 150 * math.sin(math.pi * k / 40)) for k in range(41)]
        n = max(2, int(40 * u) + 1); c.set_dash([6, 10]); line(c, pts[:n], RED, 4, 0.8 * A); c.set_dash([])
        k = n - 1; k2 = max(0, k - 1); ang = math.atan2(pts[k][1] - pts[k2][1], pts[k][0] - pts[k2][0]) + math.pi / 2
        if u < 1: ic(c, rocket, pts[k][0], pts[k][1], 0.75, a=A, rot=ang)
        else:
            r = 10 + 40 * ramp(t, t0 + 1.4, t0 + 2.0); circ(c, x1, y1, r, RED, a=A * (1 - ramp(t, t0 + 1.4, t0 + 2.2)) * 0.5)
    if t > 15.4:
        CH(c, "15 km: seconds for a missile", 40, 540, 1215, RED, a=A * ramp(t, 15.4, 15.7))
def vacations(c, t, isl):
    if not (17.0 <= t < 24.4): return
    A = 1 - ramp(t, 23.9, 24.3)
    for i, (x, y) in enumerate(UMB):
        a_, sc = pop(t, 17.3 + 0.2 * i); px, py = isl.pt(x, y); ic(c, umbrella, px, py - 16, 0.74 * sc, a=A * a_)
    a_, sc = pop(t, 18.9); px, py = isl.pt(*JLM)
    if sc > 0:
        ic(c, pin, px, py - 22, 0.8 * sc, a=A * a_)
        line(c, [(px + 14, py - 40), (770, 640)], NAVY, 3, A * a_)
        card(c, 860, 640, 270, 140, A * a_, r=24)
        T(c, "Jerusalem", 46, 860, 610, a=A * a_); T(c, "sea view", 42, 860, 668, col=B255, a=A * a_, w=800)
    if t > 20.8:
        u = ease((t - 20.8) / 3.0); n = max(2, int(len(FERRY) * u))
        P = isl.pts(FERRY[:n]); c.set_dash([8, 9]); line(c, [tuple(q) for q in P], WHITE, 4, A); c.set_dash([])
        p, hd = I.polyline_at(FERRY, u); q = isl.pt(*p); dx = math.cos(hd)
        ic(c, ferry, q[0], q[1] - 8, 0.5, a=A, flip=(dx < 0))
        a2 = ramp(t, 21.0, 21.3)
        e = isl.pt(*EILAT); h = isl.pt(*HAIFA)
        CH(c, "Eilat", 40, e[0] + 120, e[1] + 4, NAVY, a=A * a2); CH(c, "Haifa", 40, h[0] - 150, h[1], NAVY, a=A * a2)
def commerce(c, t, world, isl):
    if not (24.0 <= t < 30.4): return
    A = 1 - ramp(t, 29.9, 30.3)
    for i, pt in enumerate(PORTS):
        tx_, ty_ = isl.pt(pt[0] - 12, pt[1]); t0 = 24.0 + 0.3 * i; u = ease((t - t0) / 2.6)
        x = lerp(-120, tx_ - 40, u); y = ty_ + 3 * math.sin(t * 2 + i)
        ic(c, cargo, x, y, 0.62, a=A * ramp(t, t0, t0 + 0.2))
    a_, sc = pop(t, 25.4, 0.5, 0.6, 1.4)
    if sc > 0:
        c.save(); c.translate(540, 860); c.scale(sc, sc); c.translate(-540, -860)
        card(c, 540, 860, 820, 520, A * a_)
        T(c, "98%", 210, 540, 735, col=B255, a=A * a_)
        T(c, "of our trade already", 66, 540, 880, a=A * a_); T(c, "comes by *sea*", 66, 540, 960, a=A * a_)
        HE(c, "98% מהסחר שלנו מגיע בים", 540, 1050, a=A * a_, sz=56, col=(70, 82, 102, 255))
        c.restore()
    source(c, t, "Source: Czech Embassy Tel Aviv", 24.2, 30.0)
def travel(c, t, world, isl):
    if not (30.0 <= t < 36.4): return
    A = 1 - ramp(t, 35.9, 36.3)
    b = isl.pt(*BGN); a_, sc = pop(t, 30.1)
    circ(c, b[0], b[1], 9 * sc, NAVY, a=A * a_, stroke=WHITE, sw=3)
    CH(c, "Ben Gurion", 40, b[0] - 190, b[1] + 70, NAVY, a=A * a_)
    for t0 in (30.6, 33.5):
        u = (t - t0) / 2.4
        if 0 <= u <= 1:
            x1, y1 = -140, b[1] - 420; ue = u * u * (3 - 2 * u) * 0.4 + u * 0.6
            x = lerp(b[0], x1, ue); y = lerp(b[1], y1, ue)
            c.set_dash([10, 10]); line(c, [b, (x, y)], NAVY, 3, 0.45 * A); c.set_dash([])
            ic(c, airliner, x, y, 0.5 + 0.25 * u, a=A, rot=math.atan2(y1 - b[1], x1 - b[0]))
    gx, gy = world.pt(CX_EDGE, CY_EDGE); a2, s2 = pop(t, 30.9)
    ic(c, barrier, gx + 14, gy + 10, 0.8 * s2, a=A * a2)
    u = ramp(t, 31.0, 32.2); shake = 3 * math.sin(t * 40) * (1 if 32.2 < t < 33.0 else 0)
    cxp = lerp(1180, gx + 140, u) + shake
    ic(c, car, cxp, gy + 4, 0.95, a=A * ramp(t, 31.0, 31.2), flip=False)
    a3, s3 = pop(t, 32.3)
    if s3 > 0: ic(c, xbadge, cxp, gy - 56, 0.9 * s3, a=A * a3)
def overlay(c, a):
    if a <= 0: return
    K.sa(c, (0.957, 0.961, 0.969), 0.78 * a); c.rectangle(0, 0, W, H); c.fill()
def twist(c, t):
    a = fade(t, 36.6, 40.4, 0.4)
    if a <= 0: return
    overlay(c, a); _, sc = pop(t, 37.3, 0.5, 0.7, 1.3)
    al = a * ramp(t, 37.2, 37.5)
    T(c, "We already live", 104, 540, 820, a=al, sc=sc); T(c, "on an *island*.", 104, 540, 950, a=al, sc=sc)
    HE(c, "אנחנו כבר חיים על אי.", 540, 1080, a=al, sz=66, col=B255)
def peace(c, t, world):
    if not (40.0 <= t < 47.4): return
    A = 1 - ramp(t, 47.0, 47.4)
    cy_ = world.ll(33.25, 35.1)
    CH(c, "Cyprus", 44, cy_[0] - 250, cy_[1] + 20, NAVY, a=A * ramp(t, 41.9, 42.2))
    CH(c, "Divided since 1974", 44, 330, cy_[1] + 150, RED, a=A * ramp(t, 43.9, 44.2))
def cta(c, t):
    a = ramp(t, 47.0, 47.4)
    if a <= 0: return
    overlay(c, a); al = ramp(t, 47.2, 47.6)
    T(c, "Would you move to", 92, 540, 640, a=al); T(c, "*Island Israel*?", 112, 540, 770, a=al)
    _, sc = pop(t, 47.6, 0.45)
    if sc > 0:
        St.a = 1.0; chip(c, "Comment ISLAND", 76, 540, 950, BLUE, W255, al, sc, icon_fn=down_arrow)
    HE(c, "הייתם עוברים לאי ישראל?", 540, 1100, a=ramp(t, 47.8, 48.2), sz=64)
    a2, s2 = pop(t, 48.4, 0.45)
    if s2 > 0: CH(c, "Episode 2 on my profile", 56, 540, 1270, NAVY, a=a2, sc=s2)

# ------------------------------------------------------------------ outputs
def frame_surface(t):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); draw(c, t); return surf
def to_pil(surf):
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data()); return Image.fromarray(a[:, :, [2, 1, 0]].copy())
QA_T = [0.0, 6.9, 11.6, 22.4, 26.8, 32.6, 38.5, 44.6]
def timing():
    beats = [("hook", 0.0, 3.0), ("flood", 3.0, 8.0), ("army", 8.0, 17.0), ("vacations", 17.0, 24.0), ("commerce", 24.0, 30.0),
             ("travel", 30.0, 36.0), ("twist", 36.0, 40.0), ("peace", 40.0, 47.0), ("cta", 47.0, T_END)]
    return {"video": "island_draft.mp4", "fps": FPS, "size": [W, H], "duration_s": T_END, "silent": True,
            "beats": [{"name": n, "start": a, "end": b} for n, a, b in beats],
            "subtitles": [{"start": a, "end": b, "text": s} for a, b, s in SUBS],
            "subtitles_note": "Hook, twist card line and CTA are on screen as cards, so no duplicate subtitle there.",
            "on_screen": {"header_chips": [{"start": a, "end": b, "text": s} for a, b, s, _ in HEAD],
                          "lines": [{"start": a, "end": b, "text": s.replace("*", "")} for a, b, s in LINES],
                          "events": {"neighbours_fade": [3.6, 4.7], "flood": [4.4, 6.8], "counter_860_to_0": [4.4, 6.8], "bob_from": 6.8,
                                     "tanks": [8.3, 17.0], "ships_jets": [10.2, 12.6], "rocket": [13.8, 15.2], "umbrellas": [17.3, 19.1],
                                     "jerusalem_pin": 18.9, "ferry": [20.8, 23.8], "cargo_ships": [24.0, 30.0], "stat_98": 25.4,
                                     "plane_ben_gurion": [[30.6, 33.0], [33.5, 35.9]], "car_stuck": [31.0, 36.0], "island_card": 37.3,
                                     "pull_back_cyprus": [40.2, 41.8], "cyprus_split_line": [42.4, 43.4], "cta": 47.0, "part2_chip": 48.4},
                          "sources": [{"start": 3.6, "end": 8.0, "text": "Source: CIA World Factbook"},
                                      {"start": 24.2, "end": 30.0, "text": "Source: Czech Embassy Tel Aviv"}]},
            "qa_sheet_times": QA_T}
if __name__ == "__main__":
    if "--frames" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--frames") + 1].split(",")]
        for t in ts: to_pil(frame_surface(t)).save(f"{SCR}/p1_{t:05.1f}.png")
        print("ok"); sys.exit()
    out = f"{HERE}/island_draft.mp4"; tmp = f"{HERE}/_tmp_island_draft.mp4"
    N = int(round(T_END * FPS)); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    cmd = ["nice", "-n", "10", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
           "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "64k", "-shortest", "-movflags", "+faststart", tmp]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); thumbs = []; qset = {int(round(x * FPS)): x for x in QA_T}
    for fi in range(N):
        t = fi / FPS; c.set_operator(cairo.OPERATOR_SOURCE); c.set_source_rgba(0, 0, 0, 0); c.paint(); c.set_operator(cairo.OPERATOR_OVER)
        draw(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi in qset: thumbs.append((qset[fi], to_pil(surf)))
        if fi % 300 == 0: print("frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0; os.replace(tmp, out)
    subprocess.run([sys.executable, f"{HERE}/tools/make_sheet.py", out, f"{HERE}/qa_sheet.png", ",".join(str(x) for x in QA_T)], check=True)
    json.dump(timing(), open(f"{HERE}/timing.json", "w"), indent=1, ensure_ascii=False)
    print("done", out)
