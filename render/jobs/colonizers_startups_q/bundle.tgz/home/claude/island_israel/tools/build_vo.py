"""House VO chain (reelkit/kit.py Reel.build_vo minus the chunk re-spacing): rubberband pitch 0.9715 formant kept,
bass g2 f135, clean_vo, atempo 1.1, 0.3 s lead. usage: build_vo.py RAW.wav OUT.wav (48 kHz mono float)"""
import sys, subprocess, numpy as np, wave
sys.path.insert(0, "/home/claude/vo_new"); from clean_vo import clean
SR = 48000
def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-500:]; return r.stdout
raw, out = sys.argv[1:3]
x = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", raw, "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135", "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
x = clean(x, SR).astype(np.float32)
x = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", "atempo=1.1", "-f", "f32le", "pipe:1"], x.tobytes()), np.float32)
y = np.concatenate([np.zeros(int(0.3 * SR), np.float32), x])
run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-c:a", "pcm_f32le", out], y.tobytes())
print(out, round(len(y) / SR, 2), "s")
