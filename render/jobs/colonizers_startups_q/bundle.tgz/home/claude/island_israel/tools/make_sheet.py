"""QA contact sheet from an mp4: python3 make_sheet.py VIDEO OUT.png t1,t2,... (phone size 390 px wide, no palette quantising)"""
import sys, subprocess, io
from PIL import Image, ImageDraw, ImageFont
v, out, ts = sys.argv[1], sys.argv[2], [float(x) for x in sys.argv[3].split(",")]
tw, th = 390, 693; cols = 4; rows = -(-len(ts) // cols)
S = Image.new("RGB", (cols * (tw + 10) + 10, rows * (th + 52) + 10), (20, 20, 28)); d = ImageDraw.Draw(S)
F = ImageFont.truetype("/home/claude/vid/fonts/Heebo-700.ttf", 36)
for k, t in enumerate(ts):
    png = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.3f}", "-i", v, "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True).stdout
    im = Image.open(io.BytesIO(png)).convert("RGB").resize((tw, th), Image.LANCZOS)
    x = 10 + (k % cols) * (tw + 10); y = 10 + (k // cols) * (th + 52); S.paste(im, (x, y)); d.text((x + 4, y + th + 4), f"{t:.2f}s", font=F, fill=(255, 255, 255))
S.save(out, optimize=True); print(out)
