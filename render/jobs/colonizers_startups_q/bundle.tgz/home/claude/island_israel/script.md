# What if Israel were an island? (draft v1)

Account: @noamroz__ (trial). Voice: Cartesia clone A. About 50 s. Opinions are marked "In my view".

Facts (verified):
- Israel's land borders total 1,068 km (CIA World Factbook via indexmundi). For the whole land from the river to the sea, the outer borders are about 860 km: Egypt 208 + Gaza/Egypt 13 + Jordan 327 + West Bank/Jordan 148 + Lebanon 81 + Syria 83.
- About 98% of Israel's foreign trade goes by sea (Czech Embassy Tel Aviv, mzv.gov.cz).
- Taiwan Strait: about 130 km at its narrowest. Cyprus: an island, divided since 1974.

0.0 HOOK (map: the whole land in gold, the neighbours fade, water pours in all around)
"What if Israel were an island?"

3 s (a 15 km ring of blue fills; a counter shows the land borders dropping to 0 km)
"Cut every land border. About 860 kilometers. Fill it with 15 kilometers of sea."

8 s ARMY (tank icons stop at the water's edge; ships and jets stay)
"Army: no tank can drive in. Every war becomes navy and air force. In my view, the water stops tanks, not rockets. 15 km is nothing for a missile."

17 s VACATIONS (beach umbrellas pop up all along the new coast; a "Jerusalem: sea view" pin)
"Vacations: every city is near a beach. A ferry from Eilat to Haifa."

24 s COMMERCE (ship icons; the 98% stat)
"Commerce: plot twist. About 98% of our trade already comes by sea."

30 s TRAVEL (a plane leaving Ben Gurion; a car stuck at a border)
"Travel: you already can't drive out of Israel for a weekend. Ben Gurion is our bridge."

36 s TWIST (the island reveal: "We already live on an island.")
"So, honestly? We already live on an island."

40 s PEACE (Cyprus on the map, split line)
"Peace: in my view, water doesn't make peace. Neighbors do. Cyprus is an island, and it's been divided since 1974."

47 s CTA
"Would you move to Island Israel? Comment ISLAND 👇"

Sources on screen: CIA World Factbook; Czech Embassy Tel Aviv (trade by sea).
