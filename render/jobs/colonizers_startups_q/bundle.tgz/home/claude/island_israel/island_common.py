"""Island Israel shared geometry + drawing (Part 1 and Part 2).
Geometry: Natural Earth 1:10m (world-atlas, via /home/claude/true_size_map/geo.py) Israel + Palestine (incl. Golan, West Bank, Gaza),
lakes from ne_10m_lakes. Local equirectangular km plane centred 35.0 E 31.5 N (scale error < 1% over the land).
Camera: screen = O + s * R(rot) @ (x_km, -y_km)."""
import sys, math, json
import numpy as np, cairo
sys.path.insert(0, "/home/claude/true_size_map"); sys.path.insert(0, "/home/claude/reelkit")
import geo
from shapely.geometry import box as sbox, shape, Polygon, MultiPolygon, LineString, MultiLineString
from shapely.ops import unary_union, transform as stransform

LON0, LAT0 = 35.0, 31.5
KX = 111.32 * math.cos(math.radians(LAT0)); KY = 110.57
def ll2km(lon, lat): return (lon - LON0) * KX, (lat - LAT0) * KY
def tokm(g): return stransform(lambda x, y, z=None: ll2km(np.asarray(x), np.asarray(y)), g)

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
GOLDL = hx("#B8923F"); GOLD_EDGE = hx("#8F6E28"); GLINE = (46 / 255, 204 / 255, 113 / 255, 1)
WATER = hx("#2A88D4"); WATER_D = hx("#1F74BA"); NAVYC = hx("#163260"); GREYLAND = hx("#C3C9D2"); GREYEDGE = hx("#AEB5C0")
BG0 = hx("#F4F5F7"); BG1 = hx("#D9DDE3"); FOAM = (1, 1, 1, 1)

C = geo.COUNTRIES
ISR, PAL = C["Israel"], C["Palestine"]
LAND_LL = unary_union([ISR, PAL]).buffer(0)
LAND = tokm(LAND_LL).simplify(0.2)
LAND = max(LAND.geoms, key=lambda p: p.area) if hasattr(LAND, "geoms") else LAND   # drop specks
LAND = Polygon(LAND.exterior)                                                         # fill tiny slivers between polygons
GREEN = tokm(PAL.boundary.intersection(ISR.buffer(0.004))).simplify(0.15)
_lk = json.load(open("/home/claude/goals_scorecard/geodata/ne_10m_lakes.geojson"))
LAKES = [tokm(shape(f["geometry"])).simplify(0.15) for f in _lk["features"]
         if f["properties"].get("name") in ("Sea of Galilee", "Dead Sea") and shape(f["geometry"]).intersects(sbox(35, 30.5, 36, 33.2))]
minx, miny, maxx, maxy = LAND.bounds
CEN = ((minx + maxx) / 2, (miny + maxy) / 2)
RING_KM = 15.0
NSTEP = 48
BUF = [LAND.buffer(RING_KM * (k / (NSTEP - 1)), 24).simplify(0.2) for k in range(NSTEP)]
WAVE_LINES = [LAND.buffer(d, 24).exterior.simplify(0.2) for d in (4.5, 9.5)]
MID = LAND.buffer(7.5, 24).exterior.simplify(0.2)

def rings_of(g):
    out = []
    for p in (g.geoms if hasattr(g, "geoms") else [g]):
        if p.is_empty or not hasattr(p, "exterior"): continue
        out.append(np.asarray(p.exterior.coords)); out += [np.asarray(r.coords) for r in p.interiors]
    return out
def lines_of(g):
    if g.is_empty: return []
    if hasattr(g, "geoms"): return [np.asarray(x.coords) for x in g.geoms if hasattr(x, "coords") and len(x.coords) > 1]
    return [np.asarray(g.coords)]

R_LAND = rings_of(LAND); R_LAKES = [r for l in LAKES for r in rings_of(l)]
R_BUF = [rings_of(b) for b in BUF]; R_GREEN = lines_of(GREEN); R_WAVES = [np.asarray(w.coords) for w in WAVE_LINES]

class Cam:
    def __init__(s, ox, oy, sc, rot=0.0, cx=CEN[0], cy=CEN[1]):
        s.ox, s.oy, s.s, s.rot, s.cx, s.cy = ox, oy, sc, rot, cx, cy
    def pts(s, a):
        x = a[:, 0] - s.cx; y = -(a[:, 1] - s.cy); cr, sr = math.cos(s.rot), math.sin(s.rot)
        return np.stack([s.ox + s.s * (cr * x - sr * y), s.oy + s.s * (sr * x + cr * y)], 1)
    def pt(s, x, y): return tuple(s.pts(np.array([[x, y]], float))[0])
    def ll(s, lon, lat): return s.pt(*ll2km(lon, lat))

def sa(c, col, a=1.0): c.set_source_rgba(col[0], col[1], col[2], (col[3] if len(col) > 3 else 1) * a)
def path_rings(c, rings, cam):
    for r in rings:
        p = cam.pts(r); c.move_to(*p[0])
        for q in p[1:]: c.line_to(q[0], q[1])
        c.close_path()
def fill_rings(c, rings, cam, col, a=1.0, edge=None, ew=1.5):
    if a <= 0.005: return
    c.new_path(); c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD); path_rings(c, rings, cam); sa(c, col, a)
    if edge: c.fill_preserve(); sa(c, edge, a); c.set_line_width(ew); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
    else: c.fill()
def stroke_lines(c, lines, cam, col, w, a=1.0, dash=None, closed=False, off=0.0):
    if a <= 0.005: return
    c.new_path()
    for r in lines:
        p = cam.pts(r); c.move_to(*p[0])
        for q in p[1:]: c.line_to(q[0], q[1])
        if closed: c.close_path()
    sa(c, col, a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.set_dash(dash or [], off); c.stroke(); c.set_dash([])

def draw_island(c, cam, t, flood=1.0, a=1.0, waves=1.0, ring_a=1.0):
    """gold land, lakes, Green Line, ring of sea grown to flood*15 km, soft moving waves"""
    if flood > 0.001:
        k = int(round(flood * (NSTEP - 1))); fill_rings(c, R_BUF[k], cam, WATER, a * ring_a)
        if flood > 0.98 and waves > 0.01:
            for i, w in enumerate(R_WAVES):
                ph = 0.5 + 0.5 * math.sin(t * 1.6 + i * 1.9)
                stroke_lines(c, [w], cam, FOAM, max(1.2, cam.s * 1.1), a * waves * ring_a * (0.18 + 0.22 * ph),
                             dash=[cam.s * 14, cam.s * 9], closed=True, off=-(t * 18 * (1 if i else -1)) * cam.s)
    fill_rings(c, R_LAND, cam, GOLDL, a, edge=GOLD_EDGE, ew=max(1.0, cam.s * 0.7))
    fill_rings(c, R_LAKES, cam, WATER, a)
    stroke_lines(c, R_GREEN, cam, GLINE, max(2.0, cam.s * 1.5), a)

def bg_surface(W=1080, H=1920):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, W * 0.35, H); g.add_color_stop_rgb(0, *BG0[:3]); g.add_color_stop_rgb(1, *BG1[:3])
    c.set_source(g); c.paint()
    rg = cairo.RadialGradient(W * 0.5, H * 0.42, 50, W * 0.5, H * 0.42, H * 0.7)
    rg.add_color_stop_rgba(0, 1, 1, 1, 0.55); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
    c.set_source(rg); c.paint(); return s

def arc_between(line, p_from, p_to, west=True):
    """sub-path of closed ring `line` between two points, choosing the arc on the west side"""
    from shapely.geometry import Point
    L = line.length; a = line.project(Point(p_from)); b = line.project(Point(p_to))
    def seg(u0, u1, n=220):
        us = np.linspace(u0, u1, n) % L; return np.array([line.interpolate(u).coords[0] for u in us])
    s1 = seg(a, b if b > a else b + L); s2 = seg(b, a if a > b else a + L)[::-1]
    m1, m2 = s1[:, 0].mean(), s2[:, 0].mean()
    return s1 if (m1 < m2) == west else s2

def polyline_at(P, u):
    """point + heading along polyline P at fraction u"""
    d = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]; L = d[-1]; s = min(max(u, 0), 1) * L
    i = min(np.searchsorted(d, s) - 1, len(P) - 2); i = max(i, 0); f = (s - d[i]) / max(1e-9, d[i + 1] - d[i])
    p = P[i] + f * (P[i + 1] - P[i]); v = P[i + 1] - P[i]; return p, math.atan2(-v[1], v[0])
