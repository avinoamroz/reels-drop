# Island Israel, Part 2: We leave the Middle East (draft v1)

Satire. Slapstick, it targets nobody. Self-deprecating Israeli humour at the end. About 50 s.

Facts: Suez Canal about 200 m wide at its narrow parts; Strait of Gibraltar about 14 km at its narrowest; the land from the river to the sea is about 470 km long and, at its widest, over 100 km.

0.0 HOOK (the island from Part 1, floating): "Part 2. We're already an island. So let's leave."
3 s (construction: diggers cut the last edges, sparks, then giant propellers and engines bolt onto the south coast): "Step one: dig. Step two: engines."
9 s (motor roar icon, wake behind the island, a counter "Speed: 12 knots"): "Step three: full speed ahead."
13 s (the island tries Suez, stuck: "Suez Canal: 200 m. Israel: 100+ km."): "Suez? We don't fit."
18 s (it turns west across the Mediterranean, past Cyprus, Crete, Malta, with a route line and a distance counter)
"West it is. Across the Mediterranean."
24 s (Gibraltar: 14 km gap; the island bonks Spain, Spain wobbles, a cartoon "boing" star, Morocco on the other side; the island squeezes through sideways): "Gibraltar: 14 km. Sorry, Spain."
32 s (the open Atlantic, calm, a deck chair, sunset): "And then: the ocean. No neighbors. Quiet."
38 s (a day counter "Day 1... Day 2... Day 3": Israelis start arguing in little speech bubbles, about parking, about politics, about whose turn it is to steer): "Peace lasted three days."
45 s: "Then we started arguing about who's steering."
48 s CTA: "Where should we park Israel? Comment PARK 👇"
