import sys,subprocess,numpy as np
src=sys.argv[1]
for t in [float(x) for x in sys.argv[2].split(",")]:
    raw=subprocess.run(["ffmpeg","-v","error","-ss",f"{t:.2f}","-i",src,"-frames:v","1","-f","rawvideo","-pix_fmt","rgb24","-"],capture_output=True).stdout
    a=np.frombuffer(raw,np.uint8).reshape(1920,1080,3).astype(int)
    bg=np.median(a[:,:40],axis=1)  # left strip per row
    d=np.abs(a-bg[:,None,:]).sum(2)>90
    rows=np.where(d[:,60:1020].sum(1)>3)[0]
    # group into bands
    bands=[];s=None;p=None
    for r in rows:
        if s is None: s=p=r
        elif r-p>12: bands.append((s,p)); s=p=r
        else: p=r
    if s is not None: bands.append((s,p))
    print(t, [b for b in bands if b[1]-b[0]>4])
