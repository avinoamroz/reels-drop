import sys, json, os
sys.path.insert(0, "/home/claude/reelkit"); os.chdir(os.path.dirname(os.path.abspath(sys.argv[1])))
import render as RD
R = RD.Reel(RD.load_spec(sys.argv[1]), json.load(open(sys.argv[2])))
RD.preview(R, [float(x) for x in sys.argv[3].split(",")], sys.argv[4])
