"""mkcards6.py: Launch Map writes for fix batch 6 -> batch/writes_<n>.json. Old card fields come from a fresh read (LM dir),
versions from LM listing (batch/versions.json), preview asset ids from batch/assets.json."""
import json, re, sys
F = "/home/claude/fix6"; LM = sys.argv[1]; NOW = "2026-11-01T15:30:00Z"; RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
A = json.load(open(f"{F}/batch/assets.json")); VER = json.load(open(f"{F}/batch/versions.json"))
MAPN = "Natural Earth maps, whole land of Israel in gold with the Green Line in green, km scale bars, compass, labels 36 px and up, everything else frame for frame the version you watched (overlay), audio untouched."
D = {
 "gaza_2005_v4": ("gaza_2005_v3", "maps with cities and arrows", None,
  "v4 per Noam 1 Nov [0:11] 'map': four map panels under the cards, each on screen as it is said. 0:05 Gaza 2005: the Strip in red, Gush Katif pinned, an arrow '8,000 moved out' into Israel. 0:14 HAMAS: 'HAMAS rules Gaza from 2007' chip, then rocket arrows from Gaza to Sderot, Ashkelon and Beersheba. 0:24 Rafah: the crossing ringed on the Egypt border, 'Egypt controls Rafah'. 0:30 land for peace: rocket arrows from Gaza to Tel Aviv and Jerusalem. Israel, Egypt, Gaza and the Mediterranean labelled. " + MAPN + " Frame 0 and the 'So remember where it started' loop unchanged. 37.0 s.",
  2000, "facts behind the accusation family (persecution 1,767, israel_syria 1,691 live) plus maps for retention; ~2k, at the floor"),
 "persecution_hook2_v4": ("persecution_hook2_v3", "maps for each country", None,
  "v4 per Noam 1 Nov [0:11] 'add maps': a map for every place the narration names. 0:05 1933: Germany in red, an arrow across the Atlantic 'many flee to the US'. 0:11 patents: a big Atlantic map, 'Jewish chemists arrive', the US in green, 'US patents: +31%'. 0:15 Germany with Berlin, chip '18% of math professors dismissed'. 0:22 Russia: the Nazi-occupied west ringed, 'Nazi-occupied, 1941 to 1944'. 0:29 Italy in green with Rome and Venice. " + MAPN + " 41.9 s.",
  1900, "parent family persecution did 1,767 views live; maps help hold attention but the topic is economics: just under the 2,000 floor, flagged"),
 "s3000_stones_v4": ("s3000_stones_v3", "map and find spot for each stone", None,
  "v4 per Noam 1 Nov [0:24] 'map, location': each find gets its find spot on a map as it is named. 0:04 Merneptah Stele: Thebes, Egypt ringed, arrow 'It names Israel' to the land of Israel. 0:10 Tel Dan ringed in the far north ('Tel Dan: House of David'), 0:15 Jerusalem ('Siloam tunnel'), 0:20 Jerusalem ('Ketef Hinnom'), 0:28 Judea ringed ('Judea: the revolt's coins'). The map shows the whole land with the find spots, so you see the north to south spread. " + MAPN + " Caption lists the find spots. 39.1 s.",
  2500, "3,000 years family (s3000 76.8k) with a find-spot map on every beat; this cut is the stones angle, so honest ~2.5k"),
 "shell_lottery_v4": ("shell_lottery_v3", "city map plus real 1909 photos", None,
  "v4 per Noam 1 Nov [0:15] 'map with cities and photos': 0:09 the real lottery photo, Avraham Soskin, 11 April 1909 (Wikimedia Commons, public domain), Ken Burns, credit 36 px. 0:15 a map of the whole land with Tel Aviv (1909) and Jerusalem pinned, so viewers see where it is. 0:21 Rothschild Boulevard in the 1920s, Tel Aviv's first avenue (Israel Parker, CC BY-SA 4.0). 0:29 a close map: Ahuzat Bayit 1909 next to Jaffa, then Tel Aviv today circled in blue. Credits on screen and in the caption. " + MAPN + " 40.2 s.",
  2000, "origin story with the real 1909 photo, maps and a number; account median ~1.8k, photos lift it to ~2k"),
 "slavery_last_v4": ("slavery_last_v3", "world map by year", None,
  "v4 per Noam 1 Nov [0:27] 'map': a world map under the cards that colours each country as its year is said: Britain 1833 and France 1848 (blue), the US 1865 and Brazil 1888 (blue), Saudi Arabia and Yemen 1962 and Oman 1970 (orange), Mauritania 1981 (red). Each group's year label hands over to the next, the colours stay, so by 0:27 you see the whole timeline at once. Natural Earth, km scale. Rest frame for frame v3, audio untouched. 37.7 s.",
  1900, "history-number family, account median ~1.8k; the map adds a visual payoff but no identity angle: just under the 2,000 floor, flagged"),
 "syria_pov_v4": ("syria_pov_v3", "clear arrows, cities, borders", None,
  "v4 per Noam 1 Nov [0:37] 'show the movement and clear arrows, people don't know the area': the old unlabelled maps are replaced. 0:04 the region: Syria, Lebanon, Jordan, Israel, Mediterranean labelled, Damascus, Beirut, Tel Aviv, Jerusalem pinned; red arrow 'Rebels take Damascus' from Idlib, grey arrow 'Syrian army leaves' off the border. 0:11 the 1974 UN buffer zone drawn in blue on the Golan, Mount Hermon and Quneitra. 0:23 green arrows 'Israel moves in' into the zone and up to Mount Hermon, red rings on the strikes near Damascus. 0:29 since then: rocket arrow into the Golan, Sweida ringed ('Sweida: Druze city'). Compass on every map. " + MAPN + " 39.3 s.",
  1900, "israel_syria did 1,691 live; arrows make the POV clear, still a niche geopolitics topic: just under the 2,000 floor, flagged"),
 "startups20_v5": ("startups20_v4", "world coverage map per startup", "startups20",
  "v5 per Noam 1 Nov [0:24] 'map of the world and coverage': a world map strip at the bottom of every startup, with the text block moved up to make room. Arcs fly from Israel to where it is used, and a chip gives the sourced coverage: Wix 260 million users worldwide; DiskOnKey '2000: IBM sells it in the US' (US lit); Check Point 100,000+ organizations; Moovit '112 countries, 3,500 cities' (moovit.com, 2026); ICQ 'Biggest in Russian-speaking countries' (Russia, Ukraine, Belarus, Kazakhstan lit); Waze 140 million drivers a month; Insightec 'Approved: Europe 2012, China 2013, US 2016' (those lit); PillCam 'From Yokneam, Israel, to the world'; OrCam 'From Jerusalem to the world'; Mobileye 'In 230 million cars'. Where no country list is published I show arcs, not invented countries. Natural Earth, audio untouched, hook and 'And those were just the first...' loop unchanged. 39.7 s.",
  2200, "list format with real visuals, 40 s, now with a world map per item; ~2.2k"),
 "startups20_p2_v5": ("startups20_p2_v4", "world coverage map per startup", "startups20_p2",
  "v5 per Noam 1 Nov [0:40] 'show on the bottom a map of the world and the coverage of each startup': a world map strip at the bottom of every startup, text block moved up. Chips from sourced figures: Fiverr 160 countries; monday.com 245,000 customers; Viber 190+ countries; Zebra Medical 'used in hospitals abroad'; Mazor '2018: bought by Medtronic (US)' (US lit); SolarEdge 4 million+ systems; Watergen 'even in Uzbekistan' (Uzbekistan lit); ReWalk 'US and Germany' (both lit); IDE '400 plants in 40 countries' (The Next Web, July 2017; US, Chile, China, India lit as named examples); Netafim 'Farmers in 110 countries'. Arcs from Israel where no country list is published. Audio untouched, loop unchanged. 52.5 s.",
  1900, "Part 2 of a list, usually a bit under Part 1; just under the 2,000 floor, flagged"),
 "colonization_wrong_v4": ("colonization_wrong_v3", "hook 'We suck at colonization', circular end", "colonization_wrong",
  "v4 per Noam 1 Nov [0:02]: (1) hook is now 'We suck at colonization.' on screen at frame 0 and voiced as one new Cartesia line (same voice, level matched); (2) the end is the new lead-in 'We can show you how to build companies, but...' over the same cover as frame 0, so the loop reads 'We can show you how to build companies, but... we suck at colonization.' The old 'If this is colonization' tail and the 'Beg to differ' line are gone. Everything between is v3 (maps, ledger, lessons, critics), re-timed to the new hook. Whisper: both new lines read back exactly. 60.6 s.",
  3000, "colonization satire family (colonize3 did 4,020 live) with a sharper self-mocking hook and a true loop; ~3k"),
 "holocaust_humor_v5": ("holocaust_humor_v4", "cold open on the first joke", None,
  "v5 per Noam 1 Nov [0:00] 'start with a joke': opens cold on joke 1, so the joke is the hook: frame 0 shows the teacher, Moyshe and 'what would you like to be if you were Hitler's son?', voiced from 0:00 ('A teacher asks...'), punchline 'An orphan.' at 0:05. Then 'In the Warsaw ghetto, Jews told jokes', Frankl, jokes 2 to 4, the survivor quote and the close, same takes as v4 (the 'Joke one, from the ghetto's secret archive' intro is cut, the source stays on screen). The ending 'Because even in the darkest place on earth...' now loops straight into the joke. 48.9 s (was 52.5).",
  2200, "dark-humor joke as the frame 0 hook is far more shareable than a statement; new idea, account median ~1.8k, ~2.2k"),
 "maps_p2_hook2_v4": ("maps_p2_hook2_v3", "new hook: guess the city", None,
  "v4 per Noam [0:06] 'change hook': frame 0 is now 'Guess the city with 5 dogs' (6 words), voiced 'Guess the Israeli city with only five registered dogs.' Why it's different and stronger than '5 dogs. In a whole city?': it is a challenge, so people guess in the comments and stay to the reveal (Modi'in Illit at 0:27), and 'registered' keeps it accurate. The 'So next time someone tells you every Israeli has a dog...' loop now completes into the challenge. Rest unchanged. 32.4 s.",
  1200, "maps_p2 (its parent) did 780 live while silly_maps did 10.7k; a guess hook should beat 780 but honest ~1.2k: under the floor, flagged"),
 "river_sea_loop_rmk1": ("river_sea_loop", "remake: how far is it, 61 km", None,
  "Remake (Noam: remake). New hook, script, visuals, structure, 14.6 s loop. Frame 0: 'FROM THE RIVER TO THE SEA / How far is it?' over a full-bleed map of the whole land (gold, West Bank and Gaza in the second shade, Green Line green), the Jordan River lit blue, 'THE RIVER' and 'THE SEA' labels. Reveal: a ruler draws from the coast to the river at the narrowest point with a counter to 61 km, then 'Less than 1.5 marathons' (1 marathon = 42.2 km). Twist: 'Israel's waist, before 1967', a green ruler coast to Green Line, 15 km. Lead-in 'So next time you hear them chant it...' cross-fades into frame 0 so the loop reads as one sentence. Widths measured on the Natural Earth borders (lat 32.6: 60.9 km; lat 32.2: 15.6 km), stated on screen. Cartesia voice, burned-in subtitles. Whisper: all lines correct.",
  4000, "map + counter family (cities 5.9k, silly_maps 10.7k, true_size 1.8k live) on the most searched phrase about Israel, a 14 s loop that pulls replays and a sendable number; honest ~4k, at the new build floor"),
 "x_express10_en_v5_rmk1": ("x_express10_en_v5", "remake: one clean journey, same narration", None,
  "Remake (Noam [0:31] 'nice narration, messy process. Remake'). Same narration you liked, kept word for word; the visuals are rebuilt from scratch as one clean sequence: navy brand background, a 5-step journey track at the top (2016, Speaker, ExpressX, Mission, 10 years) that lights up step by step, and one idea per card, the second idea replacing the first on its spoken word: 10 years then 2,200 English Speakers; How did we get here then It started in a kitchen; 31.10.2016, Sokolov 2; Not an English student then An English Speaker; 51 ExpressX nights then Coaches, a community; Not here for English then English, a spoken language in Israel; 10 years of English Express, Tuesday 3 November 2026, Save the date. No deck screenshots, no faces. 'And that's how one kitchen became:' cross-fades into '10 years'. 38.1 s.",
  600, "Express median ~430; a clean anniversary invite, time-bound to 3 Nov; honest ~600, under the Express 1,000 floor and the 4,000 aim: flagged"),
}
def build(ids, n):
    writes = []
    for nid in ids:
        old, short, appr_from, note, pv, why = D[nid]; od = json.load(open(f"{LM}/{old}.json"))
        rmk = nid.endswith("_rmk1")
        title = re.sub(r"\s*\((?:v\d+|ending fix)[^)]*\)", "", od["title"]).strip() if rmk else od["title"]
        tag = "remake" if rmk else "v" + re.search(r"_v(\d+)$", nid).group(1)
        c = {"account": od.get("account"), "status": "check", "parent": old, "kind": "remake" if rmk else "variant", "lang": od.get("lang", "en"),
             "title": f"{title} ({tag}: {short})", "note": note,
             "preview": f"/_blob/{A[nid]}", "previewAsset": A[nid], "previewRaw": f"{RAW}render/out/{nid}_540.mp4",
             "src": f"{RAW}{nid}.mp4", "link": f"{RAW}{nid}.mp4", "payload": nid, "addedAt": NOW, "editedAt": NOW,
             "dayLabel": "To review", "time": "TBD", "slotted": False, "predViews": pv, "predWhy": why}
        if appr_from and not rmk:
            c.update(status="approved", approvedBy="noam", approvedVia=f"carried over from {appr_from}", approvedAt=NOW)
        for k in ("collab", "collaborators"):
            if k in od: c[k] = od[k]
        assert not re.search("[–—]", json.dumps(c, ensure_ascii=False)), nid
        json.dump(c, open(f"{F}/batch/{nid}.json", "w"), ensure_ascii=False)
        writes.append({"op": "set", "collection": "reels", "doc_id": nid, "file_path": f"{F}/batch/{nid}.json"})
        writes.append({"op": "update", "collection": "reels", "doc_id": old, "if_version": VER[old],
                       "data": {"status": "replaced", "replacedBy": nid, "editedAt": NOW}})
        writes.append({"op": "set", "collection": "captions", "doc_id": nid, "file_path": f"{F}/batch/cap_{nid}.json"})
    json.dump(writes, open(f"{F}/batch/writes_{n}.json", "w"), ensure_ascii=False); print(n, len(writes))
if __name__ == "__main__":
    ids = sys.argv[3].split(","); build(ids, sys.argv[2])
