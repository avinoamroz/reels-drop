#!/usr/bin/env python3
"""mkcfg.py: overlay configs for fix batch 6 (maps with arrows, city labels, borders, compass; shell lottery photos;
startups world-coverage strip). Times come from each reel's word timings. Writes /home/claude/fix6/cfg/<newid>.json"""
import json, os, re
F = "/home/claude/fix6"; EJ = "/home/claude/endings_1101/jobs"; RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
os.makedirs(f"{F}/cfg", exist_ok=True)
R = [70, 1180, 1010, 1450]          # standard panel under the cards, above the source label
CR = "Map: Natural Earth"
def words(old):
    return json.load(open(f"{EJ}/{old}/timing_cache.json"))["words"]
def wt(Wd, w, k=0, after=0.0):
    hits = [x["t0"] for x in Wd if re.sub(r"[^\w']", "", x["w"]).lower() == w.lower() and x["t0"] >= after]
    return round(hits[k], 2)
def base(old, new):
    return {"src": f"/home/claude/fix6/src/{old}.mp4", "src_url": f"{RAW}{old}.mp4", "out": f"/home/claude/fix6/out/{new}.mp4"}
def mp(t0, t1, rect, view, **k):
    d = {"kind": "map", "t0": t0, "t1": t1, "rect": rect, "view": view, "credit": CR, "compass": True, "zoom": 1.04}; d.update(k); return d
def lab(lon, lat, en, at, **k): d = dict(lon=lon, lat=lat, en=en, at=at); d.update(k); return d
def pin(lon, lat, en, at, side="r", **k): d = dict(lon=lon, lat=lat, en=en, at=at, side=side, sz=k.pop("sz", 38)); d.update(k); return d
def arr(a, b, at, en=None, **k): d = dict(a=a, b=b, at=at); d.update(k); (d.__setitem__("en", en) if en else None); return d
CFG = {}

# ---------------------------------------------------------------- gaza_2005 (Noam [0:11] "map")
W = words("gaza_2005_v3"); c = base("gaza_2005_v3", "gaza_2005_v4")
GZ = [33.3, 30.85, 35.95, 32.25]
c["inserts"] = [
 mp(5.2, 14.0, R, GZ, fit="contain", hl=[{"iso": "PS", "part": "gaza", "at": 5.4, "color": "#D63A4A"}],
    chip="Gaza, 2005: 21 settlements", chip_at=5.4,
    pins=[pin(34.29, 31.33, "Gush Katif", wt(W, "settlements"), "l", color="#D63A4A", sz=36)],
    arrows=[arr([34.40, 31.42], [34.85, 31.62], wt(W, "eight"), "8,000 moved out", color="#163261", bend=0.25, lab_off=[170, 0])],
    labels=[lab(35.15, 31.2, "ISRAEL", 5.4, sz=38), lab(34.0, 30.92, "EGYPT", 5.4, sz=38)]),
 mp(14.15, 23.9, [70, 950, 1010, 1450], [33.6, 30.95, 35.6, 32.2], fit="contain",
    hl=[{"iso": "PS", "part": "gaza", "at": 14.4, "color": "#D63A4A"}],
    chip="HAMAS rules Gaza from 2007", chip_at=wt(W, "2007"),
    pins=[pin(34.60, 31.52, "Sderot", wt(W, "rockets"), "r", color="#163261"),
          pin(34.57, 31.67, "Ashkelon", wt(W, "rockets") + 0.2, "r", color="#163261"),
          pin(34.79, 31.25, "Beersheba", wt(W, "rockets") + 0.4, "r", color="#163261")] ,
    arrows=[arr([34.40, 31.45], [34.60, 31.53], wt(W, "rockets"), color="#D63A4A", bend=0.3),
            arr([34.38, 31.42], [34.57, 31.66], wt(W, "rockets") + 0.2, color="#D63A4A", bend=-0.25),
            arr([34.33, 31.33], [34.78, 31.26], wt(W, "rockets") + 0.4, "rockets", color="#D63A4A", bend=0.15, lab_off=[0, 44])],
    labels=[lab(35.15, 31.0, "ISRAEL", 14.4), lab(33.85, 31.25, "EGYPT", 14.4), lab(33.95, 31.95, "Mediterranean Sea", 14.4, kind="sea", sz=38),
            lab(34.25, 31.47, "GAZA", 14.4, sz=36)]),
 mp(24.2, 30.4, R, GZ, fit="contain",
    rings=[dict(lon=34.245, lat=31.25, at=wt(W, "Rafah"), color="#D63A4A")],
    hl=[{"iso": "PS", "part": "gaza", "at": 24.4, "color": "#D63A4A"}],
    chip="Egypt controls Rafah", chip_at=wt(W, "controls"),
    pins=[pin(34.245, 31.25, "Rafah crossing", wt(W, "Rafah"), "l", color="#D63A4A", sz=36)],
    labels=[lab(35.15, 31.2, "ISRAEL", 24.4, sz=38), lab(34.0, 30.92, "EGYPT", wt(W, "Egypt"), sz=38)]),
 mp(30.45, 34.0, [70, 1095, 1010, 1450], [33.6, 31.0, 35.9, 32.3], fit="contain",
    hl=[{"iso": "PS", "part": "gaza", "at": 30.6, "color": "#D63A4A"}],
    pins=[pin(34.78, 32.07, "Tel Aviv", wt(W, "rockets", after=30), "r", color="#163261"),
          pin(35.21, 31.78, "Jerusalem", wt(W, "rockets", after=30) + 0.2, "r", color="#163261")],
    arrows=[arr([34.45, 31.52], [34.78, 32.05], wt(W, "rockets", after=30), color="#D63A4A", bend=-0.2),
            arr([34.45, 31.48], [35.19, 31.77], wt(W, "rockets", after=30) + 0.2, "rockets", color="#D63A4A", bend=0.2, lab_off=[0, 40])],
    labels=[lab(33.95, 31.85, "Mediterranean Sea", 30.6, kind="sea", sz=36), lab(34.22, 31.42, "GAZA", 30.6, sz=36)]),
]
CFG["gaza_2005_v4"] = c

# ---------------------------------------------------------------- persecution_hook2 (Noam [0:11] "add maps")
W = words("persecution_hook2_v3"); c = base("persecution_hook2_v3", "persecution_hook2_v4")
ATL = [-100, 20, 32, 62]
c["inserts"] = [
 mp(5.55, 10.9, R, ATL, fit="contain", hl=[{"iso": "DE", "at": 5.8, "color": "#D63A4A"}],
    arrows=[arr([10.0, 51.0], [-74.0, 40.7], wt(W, "flee"), "1933: many flee to the US", color="#163261", bend=-0.22, lab_off=[0, 10])],
    labels=[lab(16, 56.5, "GERMANY", 5.8, sz=36), lab(-98, 40, "USA", 5.8), lab(-40, 35, "Atlantic Ocean", 5.8, kind="sea", sz=38)]),
 mp(11.15, 15.6, [70, 640, 1010, 1440], ATL, fit="contain",
    hl=[{"iso": "DE", "at": 11.3, "color": "#D63A4A"}, {"iso": "US", "at": wt(W, "patents"), "color": "#1E9E62"}],
    arrows=[arr([10.0, 51.0], [-74.0, 40.7], 11.3, "Jewish chemists arrive", color="#163261", bend=-0.22, lab_off=[120, -50])],
    pins=[pin(-95, 37, "US patents: +31%", wt(W, "jump"), "d", color="#1E9E62", sz=40)],
    labels=[lab(16, 56.5, "GERMANY", 11.3, sz=36), lab(-40, 32, "Atlantic Ocean", 11.3, kind="sea", sz=38)]),
 mp(15.65, wt(W, "Their") - 0.1, R, [3, 46.5, 20, 55.5], fit="contain", hl=[{"iso": "DE", "at": 15.9, "color": "#D63A4A"}],
    pins=[pin(13.40, 52.52, "Berlin", 15.9, "r", color="#163261", until=wt(W, "eighteen") - 0.1)],
    labels=[lab(10.3, 50.6, "GERMANY", 15.9)],
    chip="18% of math professors dismissed", chip_at=wt(W, "eighteen")),
 mp(22.15, 29.3, R, [0, 44, 80, 62], fit="contain",
    hl=[{"circle": [34.0, 54.0, 520], "at": wt(W, "Holocaust"), "color": "#D63A4A"}],
    labels=[lab(52, 58.5, "RUSSIA", 22.4), lab(10.5, 51, "GERMANY", 22.4, sz=36), lab(34.0, 54.0, "Nazi-occupied, 1941 to 1944", wt(W, "Holocaust") + 0.2, sz=36)]),
 mp(29.6, 34.3, R, [5, 36, 20, 47.5], fit="contain", hl=[{"iso": "IT", "at": wt(W, "Italy"), "color": "#1E9E62"}],
    pins=[pin(12.50, 41.90, "Rome", wt(W, "banks"), "r", color="#163261"), pin(12.33, 45.44, "Venice", wt(W, "banks") + 0.2, "r", color="#163261")],
    labels=[lab(15.5, 37.2, "ITALY", wt(W, "Italy")), lab(16.5, 44.0, "Adriatic", 29.8, kind="sea", sz=36)]),
]
CFG["persecution_hook2_v4"] = c

# ---------------------------------------------------------------- s3000_stones (Noam [0:24] "map, location")
W = words("s3000_stones_v3"); c = base("s3000_stones_v3", "s3000_stones_v4")
IL_WIDE = [27.5, 29.35, 43.0, 33.55]
t_dan, t_jer, t_scr, t_coin = wt(W, "Tel"), wt(W, "Under"), wt(W, "Two"), wt(W, "coins")
c["inserts"] = [
 mp(4.4, 10.15, R, [14, 23.5, 56, 34.5], fit="contain",
    rings=[dict(lon=32.64, lat=25.70, at=4.8, color="#D63A4A")],
    pins=[pin(32.64, 25.70, "Found: Thebes, Egypt", 4.8, "u", color="#D63A4A")],
    arrows=[arr([32.9, 26.2], [34.9, 31.6], wt(W, "Israel", after=8), "It names Israel", color="#163261", bend=-0.25, lab_off=[150, 0])],
    labels=[lab(25.5, 33.2, "Mediterranean Sea", 4.6, kind="sea", sz=36)]),
 mp(10.35, 33.45, R, IL_WIDE, fit="contain", zoom=1.03,
    rings=[dict(lon=35.652, lat=33.248, at=t_dan, until=t_jer - 0.3, color="#D63A4A"),
           dict(lon=35.236, lat=31.773, at=t_jer, until=t_coin - 0.3, color="#D63A4A")],
    pins=[pin(35.652, 33.248, "Tel Dan: House of David", t_dan, "d", until=t_jer - 0.3, color="#D63A4A"),
          pin(35.236, 31.773, "Jerusalem: Siloam tunnel", t_jer, "d", until=t_scr - 0.2, color="#D63A4A"),
          pin(35.229, 31.768, "Jerusalem: Ketef Hinnom", t_scr, "d", until=t_coin - 0.3, color="#D63A4A")],
    hl=[{"circle": [35.15, 31.55, 32], "at": t_coin, "color": "#D63A4A"}],
    labels=[lab(39.2, 31.55, "Judea: the revolt's coins", t_coin + 0.1, sz=38), lab(39.0, 33.1, "SYRIA", 10.6, sz=36)]),
]
CFG["s3000_stones_v4"] = c

# ---------------------------------------------------------------- shell_lottery (Noam [0:15] "map with cities and photos")
W = words("shell_lottery_v3"); c = base("shell_lottery_v3", "shell_lottery_v4")
t_who, t_white, t_call, t_today, t_story = wt(W, "Who"), wt(W, "white"), wt(W, "call"), wt(W, "Today"), wt(W, "That's")
c["inserts"] = [
 {"kind": "photo", "t0": t_who - 0.1, "t1": t_white - 0.12, "rect": [70, 1130, 1010, 1455], "src": f"{F}/photos/lottery.jpg",
  "credit": "Photo: Avraham Soskin, 11 April 1909 (public domain)", "caption": "The lottery, 11 April 1909", "zoom": [1.0, 1.08]},
 mp(t_white - 0.1, t_call - 0.1, R, [30.5, 29.4, 39.5, 33.4], fit="contain",
    pins=[pin(34.77, 32.07, "Tel Aviv, 1909", t_white + 0.1, "l", color="#D63A4A"),
          pin(35.21, 31.78, "Jerusalem", t_white + 0.9, "r", color="#163261")],
    labels=[lab(37.5, 30.6, "JORDAN", t_white, sz=36), lab(32.6, 30.0, "EGYPT", t_white, sz=36)]),
 {"kind": "photo", "t0": t_call - 0.1, "t1": t_today - 0.12, "rect": [70, 1180, 1010, 1455], "src": f"{F}/photos/rothschild.jpg",
  "credit": "Rothschild Blvd, 1920s. Israel Parker, CC BY-SA 4.0", "caption": "Tel Aviv's first avenue", "zoom": [1.0, 1.07]},
 mp(t_today - 0.1, t_story - 0.1, [70, 1090, 1010, 1455], [34.55, 31.95, 35.0, 32.16],
    pins=[pin(34.77, 32.065, "Ahuzat Bayit, 1909", t_today + 0.2, "r", color="#D63A4A"), pin(34.752, 32.053, "Jaffa", t_today + 0.5, "l", color="#163261")],
    hl=[{"circle": [34.79, 32.08, 6.5], "at": t_today + 0.8, "color": "#45A4DD"}],
    chip="Blue: Tel Aviv today", chip_at=t_today + 0.8, labels=[lab(34.63, 32.10, "Mediterranean Sea", t_today, kind="sea", sz=36)]),
]
CFG["shell_lottery_v4"] = c

# ---------------------------------------------------------------- slavery_last (Noam [0:27] "map")
W = words("slavery_last_v3"); c = base("slavery_last_v3", "slavery_last_v4")
t_br, t_fr, t_us, t_bz, t_sa, t_om, t_mr, t_cr, t_mod = (wt(W, "Britain"), wt(W, "France"), wt(W, "United"), wt(W, "Brazil"),
    wt(W, "Saudi"), wt(W, "Oman"), wt(W, "Mauritania"), wt(W, "crime"), wt(W, "modern"))
WORLD = [-125, -38, 75, 62]
def yr(iso, at, col): return {"iso": iso, "at": at, "color": col}
c["inserts"] = [
 mp(4.05, 30.0, R, WORLD, fit="contain", zoom=1.02, compass=False,
    hl=[yr("GB", t_br, "#45A4DD"), yr("FR", t_fr, "#45A4DD"), yr("US", t_us, "#45A4DD"), yr("BR", t_bz, "#45A4DD"),
        yr("SA", t_sa, "#F5A623"), yr("YE", t_sa + 0.4, "#F5A623"), yr("OM", t_om, "#F5A623"), yr("MR", t_mr, "#D63A4A")],
    pins=[pin(-2.0, 53.5, "Britain 1833", t_br, "l", color="#45A4DD", sz=36, until=t_us - 0.2), pin(2.5, 46.5, "France 1848", t_fr, "r", color="#45A4DD", sz=36, until=t_us - 0.2),
          pin(-98, 39, "US 1865", t_us, "r", color="#45A4DD", sz=36, until=t_sa - 0.2), pin(-52, -11, "Brazil 1888", t_bz, "r", color="#45A4DD", sz=36, until=t_sa - 0.2),
          pin(44.5, 24, "Saudi Arabia, Yemen 1962", t_sa, "l", color="#F5A623", sz=36, until=t_mr - 0.2), pin(57, 21, "Oman 1970", t_om, "d", color="#F5A623", sz=36, until=t_mr - 0.2),
          pin(-10.5, 20.3, "Mauritania 1981", t_mr, "l", color="#D63A4A", sz=40)],
    labels=[lab(-40, 10, "Atlantic", 4.3, kind="sea", sz=36)]),
]
CFG["slavery_last_v4"] = c

# ---------------------------------------------------------------- syria_pov (Noam [0:37] "show the movement, clear arrows, people don't know the area")
W = words("syria_pov_v3"); c = base("syria_pov_v3", "syria_pov_v4")
MAPR = [56, 440, 1024, 1440]      # covers the old unlabelled map panels
SY = [33.2, 30.9, 39.8, 36.6]
t_assad, t_reb, t_troops = wt(W, "Assad"), wt(W, "Rebels"), wt(W, "troops")
t_moved, t_herm, t_struck = wt(W, "moved"), wt(W, "Hermon"), wt(W, "struck")
t_rock, t_swe, t_druze = wt(W, "rockets"), wt(W, "Sweida"), wt(W, "Druze")
CITIES = [pin(36.29, 33.51, "Damascus", 4.6, "r", color="#163261"), pin(34.78, 32.08, "Tel Aviv", 4.6, "l", color="#163261"),
          pin(35.21, 31.78, "Jerusalem", 4.6, "l", color="#163261"), pin(35.50, 33.89, "Beirut", 4.6, "l", color="#163261")]
COUNTRIES = [lab(38.3, 35.3, "SYRIA", 4.6, sz=44), lab(36.0, 31.25, "JORDAN", 4.6, sz=40), lab(35.85, 34.35, "LEBANON", 4.6, sz=36),
             lab(34.75, 31.45, "ISRAEL", 4.6, sz=40), lab(34.3, 34.7, "Mediterranean", 4.6, kind="sea", sz=36)]
c["inserts"] = [
 mp(4.3, 11.0, MAPR, SY, fit="contain", zoom=1.03,
    pins=CITIES + [pin(36.63, 35.93, "Idlib", t_reb - 0.3, "r", color="#D63A4A")],
    arrows=[arr([36.63, 35.85], [36.30, 33.62], t_reb, "Rebels take Damascus", color="#D63A4A", bend=0.12, lab_off=[150, -40]),
            arr([35.95, 33.05], [36.22, 33.45], t_troops, "Syrian army leaves", color="#7A8597", bend=-0.3, lab_off=[200, 30])],
    labels=COUNTRIES),
 mp(11.3, 15.25, [70, 1180, 1010, 1450], [34.6, 32.65, 36.6, 33.6], fit="contain", zoom=1.03, chip="Blue: UN buffer zone, 1974", chip_at=11.8,
    lines=[{"pts": [[35.83, 33.40], [35.87, 33.28], [35.90, 33.15], [35.93, 33.00], [35.88, 32.80]], "at": 11.5, "color": "#45A4DD", "w": 12, "dur": 1.0}],
    pins=[pin(35.86, 33.42, "Mount Hermon", 11.6, "d", color="#163261"), pin(35.83, 33.13, "Quneitra", 12.0, "l", color="#163261")],
    labels=[lab(35.0, 32.95, "ISRAEL", 11.5, sz=38), lab(36.45, 33.0, "SYRIA", 11.5, sz=38), lab(35.62, 32.85, "Golan", 11.5, sz=36)]),
 mp(22.95, 29.5, MAPR, [34.5, 32.3, 37.0, 34.0], fit="contain", zoom=1.03,
    lines=[{"pts": [[35.83, 33.40], [35.87, 33.28], [35.90, 33.15], [35.93, 33.00], [35.88, 32.80]], "at": 23.1, "color": "#45A4DD", "w": 12}],
    pins=[pin(36.29, 33.51, "Damascus", 23.1, "r", color="#163261"), pin(35.86, 33.42, "Mount Hermon", t_herm, "l", color="#D63A4A"),
          pin(35.83, 33.13, "Quneitra", 23.3, "l", color="#163261")],
    arrows=[arr([35.55, 33.05], [35.87, 33.12], t_moved, "Israel moves in", color="#1E9E62", bend=0.2, lab_off=[-60, 60]),
            arr([35.60, 33.20], [35.84, 33.38], t_herm - 0.2, color="#1E9E62", bend=-0.2)],
    rings=[dict(lon=36.30, lat=33.42, at=t_struck, color="#D63A4A"), dict(lon=36.55, lat=33.80, at=t_struck + 0.3, color="#D63A4A")],
    labels=[lab(35.25, 32.75, "ISRAEL", 23.1, sz=40), lab(36.6, 32.75, "SYRIA", 23.1, sz=40), lab(35.6, 33.85, "LEBANON", 23.1, sz=36),
            lab(36.45, 33.15, "strikes on weapons", t_struck + 0.2, sz=36), lab(36.25, 32.48, "JORDAN", 23.1, sz=36)]),
 mp(t_rock - 0.3, 36.45, [70, 935, 1010, 1450], [34.7, 32.2, 37.3, 33.75], zoom=1.03,
    pins=[pin(35.69, 32.99, "Golan", t_rock, "l", color="#163261"), pin(36.57, 32.71, "Sweida: Druze city", t_swe, "l", color="#D63A4A"),
          pin(36.29, 33.51, "Damascus", t_rock, "r", color="#163261")],
    arrows=[arr([36.10, 33.25], [35.75, 33.02], t_rock, "rockets", color="#D63A4A", bend=0.2, lab_off=[60, -40])],
    rings=[dict(lon=36.57, lat=32.71, at=t_swe, color="#D63A4A")],
    labels=[lab(35.2, 32.55, "ISRAEL", t_rock, sz=40), lab(36.8, 33.2, "SYRIA", t_rock, sz=40), lab(36.0, 32.3, "JORDAN", t_rock, sz=36)] ),
]
c["inserts"].append({"kind": "patch", "t0": 22.95, "t1": 29.5, "rect": [0, 840, 58, 935], "dx": 1020})
CFG["syria_pov_v4"] = c

for k, v in CFG.items():
    json.dump(v, open(f"{F}/cfg/{k}.json", "w"), indent=1); print(k, len(v["inserts"]), "inserts")

# ---------------------------------------------------------------- startups20 Part 1 and 2 (Noam: world map at the bottom, each startup's coverage)
IL = [35.0, 31.6]
HUB = {"ny": [-74, 40.7], "sp": [-46.6, -23.5], "lon": [-0.1, 51.5], "mos": [37.6, 55.8], "del": [77.2, 28.6], "bj": [116.4, 39.9],
       "syd": [151.2, -33.9], "lag": [3.4, 6.5], "mex": [-99.1, 19.4], "jkt": [106.8, -6.2]}
EU = ["DE", "FR", "IT", "ES", "GB", "PL", "NL", "BE", "AT", "SE", "PT", "CZ", "GR", "RO", "IE", "DK", "FI", "HU"]
WV = [-170, -56, 190, 78]
PANEL = [70, 1240, 1010, 1595]
def world(t0, t1, chip, hubs="all", hl=(), pins=(), col="#45A4DD"):
    hs = list(HUB) if hubs == "all" else hubs
    return mp(t0, t1, PANEL, WV, fit="contain", zoom=1.0, compass=False, chip=chip, chip_at=t0 + 0.25,
              arrows=[arr(IL, HUB[h], t0 + 0.35 + 0.1 * i, color=col, bend=0.15 if i % 2 else -0.15) for i, h in enumerate(hs)],
              hl=[{"iso": x, "at": t0 + 0.3, "color": col} for x in hl], pins=list(pins),
              rings=[dict(lon=IL[0], lat=IL[1], at=t0 + 0.2, color="#C9A44C")], fin=0.25, fout=0.2)
def s20(old, new, P, items, shift):
    c = base(old, new); ins = [{"kind": "shiftf", "t0": shift[0], "t1": shift[1], "band": [975, 1560], "dy": -350, "feather": 150}]
    for k, it in enumerate(items):
        if it is None: continue
        t0 = P[k + 1][0] + 0.18; t1 = min(P[k + 2][0] + 0.12, shift[1] - 0.45) if k + 2 < len(P) else shift[1] - 0.45
        ins.append(world(t0 + 0.05, t1 - 0.05, **it))
    c["inserts"] = ins; return c
def lines(p):
    W = json.load(open(f"/home/claude/fix5/tts/f5_{p}_words.json")); L = [l for l in open(f"/home/claude/fix5/tts/{p}.txt").read().splitlines() if l.strip()]
    k = 0; out = []
    for l in L:
        n = len(l.split()); out.append((W[k]["start"] + 0.3, W[k + n - 1]["end"] + 0.3)); k += n
    return out
P1 = lines("s20p1")
WW = "all"
I1 = [dict(chip="260 million users, worldwide"),
      dict(chip="2000: IBM sells it in the US", hubs=["ny"], hl=["US"]),
      dict(chip="100,000+ organizations, worldwide"),
      dict(chip="112 countries, 3,500 cities (Moovit, 2026)"),
      dict(chip="Biggest in Russian-speaking countries", hubs=["mos", "ny", "lon", "sp"], hl=["RU", "UA", "BY", "KZ"]),
      dict(chip="140 million drivers a month, worldwide"),
      dict(chip="Approved: Europe 2012, China 2013, US 2016", hubs=["lon", "bj", "ny"], hl=EU + ["CN", "US"]),
      dict(chip="From Yokneam, Israel, to the world"),
      dict(chip="From Jerusalem to the world"),
      dict(chip="In 230 million cars, worldwide"),
      dict(chip="In 230 million cars, worldwide")]
CFG["startups20_v5"] = s20("startups20_v4", "startups20_v5", P1, I1, (P1[1][0] + 0.05, P1[12][0] - 0.05))
P2 = lines("s20p2")
I2 = [dict(chip="Freelancers in 160 countries"),
      dict(chip="245,000 customers, worldwide"),
      dict(chip="190+ countries"),
      dict(chip="Israeli AI, used in hospitals abroad", hubs=["ny", "lon", "del", "bj"]),
      dict(chip="2018: bought by Medtronic (US)", hubs=["ny"], hl=["US"]),
      dict(chip="4 million+ systems, worldwide"),
      dict(chip="Water from air, even in Uzbekistan", hubs=["mos"], hl=["UZ"], pins=[pin(64.5, 41.4, "Uzbekistan", 0, "r", color="#45A4DD", sz=36)]),
      dict(chip="Walking again: US and Germany", hubs=["ny", "lon"], hl=["US", "DE"]),
      dict(chip="400 plants in 40 countries", hubs=["ny", "sp", "bj", "del"], hl=["US", "CL", "CN", "IN"]),
      dict(chip="Farmers in 110 countries"),
      dict(chip="Farmers in 110 countries")]
c2 = s20("startups20_p2_v4", "startups20_p2_v5", P2, I2, (P2[1][0] + 0.05, P2[12][0] - 0.05))
for d in c2["inserts"]:
    for p in d.get("pins", []): p["at"] = d["t0"] + 0.4
CFG["startups20_p2_v5"] = c2
for k in ("startups20_v5", "startups20_p2_v5"):
    json.dump(CFG[k], open(f"{F}/cfg/{k}.json", "w"), indent=1); print(k, len(CFG[k]["inserts"]))
