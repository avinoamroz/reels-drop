"""scenes_stick.py (1 Nov, Noam on holocaust_humor_v2 [0:18] "stick figures to catch the eye of the viewer... make it
engaging"): big animated stick figures that act out each ghetto / camp joke, under the joke text. House colour code:
blue = the one speaking / acting, orange = the one listening (passive), red = new (not used for people here).

  {"type": "stick", "line": N, "setup": "text", "punch": "*punchline*", "he": "small Hebrew line", "author": "Joke 1: ...",
   "prop": "emoji", "scene": "class" | "talk" | "together", "marks": {"p": "punch phrase"}, "source": "..."}

The setup text lands on the scene start, the figures talk (speaker's arm moves, listener nods); on mark p the punchline
pops in blue and both figures laugh (shoulders shake, heads tip back, smile). "together": two figures side by side,
the blue one's arm around the orange one's shoulders, a candle between their feet (the survivor line).
Also loads the scenes_x loop patches (circular ending) through looplib."""
import sys, math
sys.path.append("/home/claude/fix6/lib")
import looplib; looplib.wrap(globals())
import render as RD
from render import P, T, PP, fade_in, block, block_h, source, draw_emoji, col
from kit import ease, St, sa

BLUE = (0x2A / 255, 0x88 / 255, 0xD4 / 255, 1.0); ORANGE = (0xF2 / 255, 0x8C / 255, 0x28 / 255, 1.0)

def _line(c, pts, w, color):
    sa(c, color, St.a); c.set_line_width(w); c.set_line_cap(1); c.set_line_join(1)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()

def figure(c, x, yf, h, color, t, mode, face=1, ph=0.0, hug_to=None):
    """stick figure standing at (x, yf), height h, facing `face` (+1 right, -1 left)."""
    lw = h * 0.045; hr = h * 0.115
    bob = 0.0; tilt = 0.0
    if mode == "laugh":
        bob = -abs(math.sin(t * 11 + ph)) * h * 0.035; tilt = -0.18
    elif mode in ("talk", "listen"):
        bob = math.sin(t * 2.4 + ph) * h * 0.006
    hip = (x, yf - h * 0.45 + bob); neck = (x + face * h * 0.015, yf - h * 0.80 + bob)
    head = (neck[0] + face * h * 0.02 + math.sin(tilt) * hr * 0.6, neck[1] - hr * 1.05)
    # legs
    step = math.sin(t * 2.0 + ph) * h * 0.01
    _line(c, [(hip[0] - h * 0.11 + step, yf), hip, (hip[0] + h * 0.11 - step, yf)], lw, color)
    # body
    _line(c, [hip, neck], lw, color)
    sh = (neck[0], neck[1] + h * 0.05)
    if mode == "talk":           # front arm gestures, back arm relaxed
        a = 0.6 + 0.45 * math.sin(t * 5.5 + ph)
        el = (sh[0] + face * h * 0.17, sh[1] + h * 0.10); hd = (el[0] + face * h * 0.14 * math.cos(a), el[1] - h * 0.14 * math.sin(a))
        _line(c, [sh, el, hd], lw, color)
        _line(c, [sh, (sh[0] - face * h * 0.08, sh[1] + h * 0.17), (sh[0] - face * h * 0.06, sh[1] + h * 0.32)], lw, color)
    elif mode == "laugh":        # hands on the belly
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.14, sh[1] + h * 0.14), (x + s_ * h * 0.03, hip[1] - h * 0.10)], lw, color)
    elif mode == "hug" and hug_to is not None:   # arm across to the other figure's far shoulder
        tx, ty = hug_to
        _line(c, [sh, ((sh[0] + tx) / 2, ty - h * 0.03), (tx + face * h * 0.06, ty + h * 0.02)], lw, color)
        _line(c, [sh, (sh[0] - face * h * 0.08, sh[1] + h * 0.17), (sh[0] - face * h * 0.06, sh[1] + h * 0.32)], lw, color)
    else:                        # listening / standing
        for s_ in (1, -1):
            _line(c, [sh, (sh[0] + s_ * h * 0.09, sh[1] + h * 0.17), (sh[0] + s_ * h * 0.07, sh[1] + h * 0.33)], lw, color)
    # head
    sa(c, color, St.a); c.set_line_width(lw); c.new_sub_path(); c.arc(head[0], head[1], hr, 0, 2 * math.pi); c.stroke()
    # face: eyes + mouth (smile when laughing, small line otherwise; nod when listening)
    nod = math.sin(t * 3.2 + ph) * hr * 0.08 if mode == "listen" else 0
    ex = head[0] + face * hr * 0.30; ey = head[1] - hr * 0.15 + nod
    sa(c, color, St.a)
    for dx in (-hr * 0.22, hr * 0.22):
        c.new_sub_path(); c.arc(ex + dx, ey, hr * 0.09, 0, 2 * math.pi); c.fill()
    c.set_line_width(lw * 0.7)
    if mode == "laugh":
        c.new_sub_path(); c.arc(ex, head[1] + hr * 0.18, hr * 0.38, 0.15 * math.pi, 0.85 * math.pi); c.stroke()
    else:
        c.move_to(ex - hr * 0.2, head[1] + hr * 0.38 + nod); c.line_to(ex + hr * 0.2, head[1] + hr * 0.38 + nod); c.stroke()
    return sh

def chalkboard(c, x, y, w, h, a):
    old = St.a; St.a *= a
    sa(c, (0.16, 0.25, 0.22, 1.0), St.a); c.rectangle(x, y, w, h); c.fill()
    sa(c, (0.55, 0.42, 0.25, 1.0), St.a); c.set_line_width(14); c.rectangle(x, y, w, h); c.stroke()
    T(c, "1 + 1 = 2", 64, x + w / 2, y + h / 2, (0.93, 0.93, 0.90, 1.0), 1.0, 1.0, 700)
    St.a = old

def sc_stick(c, t, S):
    t0 = S["t0"]; tp = S["times"].get("p", t0 + 2.5)
    # text block, top
    y = 330
    a, s = PP(t, t0 + 0.05, S)
    if S.get("author"): T(c, S["author"], 44, 540, y, P["gold_text"], a, s, 800, maxw=940); y += 70
    sa_, ss_ = PP(t, S["times"].get("s", t0 + 0.05) - 0.1, S)   # 1 Nov fix 5: the joke lands when it is told, not at the scene start
    if t0 < 0.05: a, s, sa_, ss_ = 1.0, 1.0, 1.0, 1.0   # fix 6: cold open, the joke is the hook, fully on screen at frame 0
    hs = block_h(S["setup"], 68, 800, 960, 3)
    block(c, S["setup"], 68, 540, y + hs / 2, P["navy"], sa_, ss_, 800, hl=P["blue"], maxw=960, max_lines=3); y += hs + 34
    pa, ps = PP(t, tp - 0.05, S, bounce=2.4)
    hp = block_h(S["punch"], 84, 900, 960, 2)
    if pa > 0.01: block(c, S["punch"], 84, 540, y + hp / 2, P["blue"], pa, ps, 900, hl=P["blue"], maxw=960, max_lines=2)
    y += hp + 20
    if S.get("he") and pa > 0.01: T(c, S["he"], 56, 540, y + 30, P["blue"], pa, 1.0, 700, maxw=940)
    # stage, bottom: figures edge to edge
    fa = fade_in(t, t0 + 0.1, S, 0.35); old = St.a; St.a *= fa
    yf = 1420; h = 440; kind = S.get("scene", "talk"); laugh = t >= tp
    sa(c, P["navy"], 0.12 * St.a); c.rectangle(40, yf + 6, 1000, 8); c.fill()
    if kind == "class":
        chalkboard(c, 330, yf - h - 60, 420, 240, 1.0)
        figure(c, 250, yf, h, BLUE, t, "laugh" if laugh else "talk", 1, 0.0)
        figure(c, 820, yf, h * 0.78, ORANGE, t, "laugh" if laugh else "listen", -1, 1.3)
    elif kind == "together":
        sh = figure(c, 600, yf, h * 0.95, ORANGE, t, "listen", -1, 1.1)
        figure(c, 420, yf, h, BLUE, t, "hug", 1, 0.0, hug_to=(sh[0] + 30, sh[1]))
    else:
        figure(c, 270, yf, h, BLUE, t, "laugh" if laugh else "talk", 1, 0.0)
        figure(c, 810, yf, h, ORANGE, t, "laugh" if laugh else "listen", -1, 1.3)
    if S.get("prop"):
        pr_a, pr_s = PP(t, t0 + 0.4, S, bounce=2.0)
        px = 540 if kind != "together" else 760
        draw_emoji(c, S["prop"], px, yf - 90 + 8 * math.sin(t * 2.2), 150, pr_a, pr_s)
    if laugh and kind != "together":   # small laugh marks over the heads
        la = fade_in(t, tp, S, 0.2)
        # 1 Nov fix 5: in the classroom the teacher's "ha" sat on the chalkboard frame; it now goes left of his head
        for k, (hx, hy) in enumerate((((270 if kind != "class" else 90), yf - h - 40), (810, yf - (h if kind != "class" else h * 0.78) - 40))):
            T(c, "ha", 52, hx + 70 + 6 * math.sin(t * 9 + k), hy - 10 * abs(math.sin(t * 6 + k)), P["gold_text"], la, 1.0, 800)
    St.a = old
    source(c, t, S)
