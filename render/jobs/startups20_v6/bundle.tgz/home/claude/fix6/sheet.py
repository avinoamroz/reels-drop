import sys,subprocess
from PIL import Image,ImageDraw
src,out=sys.argv[1],sys.argv[2]; ts=[float(x) for x in sys.argv[3].split(",")]
ims=[]
for t in ts:
    raw=subprocess.run(["ffmpeg","-v","error","-ss",f"{t:.2f}","-i",src,"-frames:v","1","-vf","scale=270:480","-f","rawvideo","-pix_fmt","rgb24","-"],capture_output=True).stdout
    im=Image.frombytes("RGB",(270,480),raw); ImageDraw.Draw(im).text((4,4),f"{t:.1f}",fill=(255,0,0)); ims.append(im)
cols=min(8,len(ims)); rows=(len(ims)+cols-1)//cols
S=Image.new("RGB",(cols*274,rows*484),"white")
for i,im in enumerate(ims): S.paste(im,((i%cols)*274,(i//cols)*484))
S.save(out)
