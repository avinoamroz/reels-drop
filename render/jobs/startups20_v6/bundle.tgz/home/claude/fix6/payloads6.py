"""payloads6.py: posting payloads for Launch Map fix batch 6 -> /home/claude/posting/queue/gh/<id>.json + /home/claude/fix6/batch/cap_<id>.json"""
import json, re, sys, os
sys.path.insert(0, "/home/claude/reelkit")
from strip_opinion import clean_all
Q = "/home/claude/posting/queue/gh"; RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"; B = "/home/claude/fix6/batch"
os.makedirs(B, exist_ok=True)
MAPS = "Maps: Natural Earth (public domain)."
def before_tags(cap, add):
    m = re.search(r"\n\n(#[^\n]+)\s*$", cap)
    return cap[:m.start()] + "\n\n" + add + cap[m.start():] if m else cap.rstrip() + "\n\n" + add
def rep(cap, a, b):
    assert a in cap, a[:60]; return cap.replace(a, b)
RIVER = """From the river to the sea. How far is it? 🌊

🔴 At the narrowest point, from the Jordan River to the Mediterranean: about 61 km. Less than a marathon and a half (1 marathon = 42.2 km).
🟢 Israel's waist before 1967, from the coast to the Green Line: about 15 km.

So next time you hear them chant it...

מהנהר ועד הים? בנקודה הצרה ביותר, כ-61 ק"מ. פחות ממרתון וחצי. והמותניים של ישראל לפני 1967, מהחוף ועד הקו הירוק: כ-15 ק"מ.

Send this to someone who still chants it.

Widths measured on Natural Earth borders (public domain): latitude 32.6 for the river to the sea, latitude 32.2 for the coast to the Green Line.

#Israel #Geography #Maps #MiddleEast #ישראל"""
E = {
 "gaza_2005_v4": ("gaza_2005_v3", lambda c: before_tags(c, MAPS)),
 "persecution_hook2_v4": ("persecution_hook2_v3", lambda c: before_tags(c, MAPS)),
 "s3000_stones_v4": ("s3000_stones_v3", lambda c: before_tags(c, "Where they were found: Thebes, Egypt (Merneptah Stele); Tel Dan (Tel Dan Stele); Jerusalem (Siloam inscription, Ketef Hinnom scrolls); Judea (Bar Kokhba revolt coins). " + MAPS)),
 "shell_lottery_v4": ("shell_lottery_v3", lambda c: before_tags(c, "Photos (Wikimedia Commons): the lottery, 11 April 1909, Avraham Soskin (public domain); Rothschild Boulevard, 1920s, Israel Parker (CC BY-SA 4.0). " + MAPS)),
 "slavery_last_v4": ("slavery_last_v3", lambda c: before_tags(c, MAPS)),
 "syria_pov_v4": ("syria_pov_v3", lambda c: c),
 "startups20_v5": ("startups20_v4", lambda c: before_tags(c, "World maps: Natural Earth (public domain). Coverage: Moovit.com (3,500 cities in 112 countries, 2026); IBM sold DiskOnKey in the US in 2000 (Wikipedia, M-Systems); Insightec approvals as above.")),
 "startups20_p2_v5": ("startups20_p2_v4", lambda c: before_tags(c, "World maps: Natural Earth (public domain). Coverage: IDE, 400 plants in 40 countries (The Next Web, July 2017); Medtronic bought Mazor (20 Sep 2018); ReWalk in the US and Germany (MassDevice, Feb 2018); Watergen in Uzbekistan (Water Online).")),
 "colonization_wrong_v4": ("colonization_wrong_v3", lambda c: rep(rep(rep(c, "Colonization done wrong. 📕", "We suck at colonization. 📕"),
      "Maybe they have different intentions, and you just don't understand them.", "Maybe they have different intentions, and you just don't understand them.\n\nWe can show you how to build companies, but..."),
      "קולוניזציה, עשינו את זה לא נכון.", "אנחנו גרועים בקולוניזציה.")),
 "holocaust_humor_v5": ("holocaust_humor_v4", lambda c: rep(c, "In the Warsaw ghetto, Jews told jokes. Historians wrote them down. 🕯️",
      "A teacher asks: \"Moyshe, what would you like to be if you were Hitler's son?\" \"An orphan.\" 🕯️\n\nIn the Warsaw ghetto, Jews told jokes. Historians wrote them down.")),
 "maps_p2_hook2_v4": ("maps_p2_hook2_v3", lambda c: rep(c, "5 dogs. In a whole Israeli city? 🐕", "Guess the Israeli city with only 5 registered dogs. 🐕")),
 "river_sea_loop_rmk1": ("river_sea_loop", lambda c: RIVER),
 "x_express10_en_v5_rmk1": ("x_express10_en_v5", lambda c: c),
}
only = sys.argv[1:]
for nid, (old, f) in E.items():
    if only and nid not in only: continue
    d = json.load(open(f"{Q}/{old}.json")); b = json.loads(d["body"]); cap = f(b["caption"])
    c = clean_all(cap).replace(" 👇", "").replace("👇", "")
    c = re.sub(r"\n{3,}", "\n\n", c).strip()
    assert not re.search("[–—]", c) and "In my view" not in c and "To be fair" not in c and "לדעתי" not in c and "Islam" not in c, nid
    assert len(c) < 2200, (nid, len(c))
    b["caption"] = c; b["video_url"] = RAW + nid + ".mp4"; b["is_ai_generated"] = True; b["media_type"] = "REELS"
    b["trial_params"] = {"graduation_strategy": "SS_PERFORMANCE"}; b.setdefault("share_to_feed", True)
    d["tag"] = nid + "-gh"; d["body"] = json.dumps(b, ensure_ascii=False)
    json.dump(d, open(f"{Q}/{nid}.json", "w"), ensure_ascii=False)
    json.dump({"caption": c, "video": RAW + nid + ".mp4", "payload": nid}, open(f"{B}/cap_{nid}.json", "w"), ensure_ascii=False)
    print(nid, d["account"], len(c))
