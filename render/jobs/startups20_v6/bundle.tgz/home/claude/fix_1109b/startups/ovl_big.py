"""ovl_big.py cfg [--preview t,..]: ovl6 (fix6) with a bigger coverage chip (54 px), for startups20_v6."""
import sys, json, os; sys.path.insert(0, "/home/claude/fix6")
import ovl5 as O
_p = O.pill_at
def pill_at(c, txt, sz, *a, **k): return _p(c, txt, max(sz, 54), *a, **k)
O.pill_at = pill_at
import ovl6
a = sys.argv[1:]
if len(a) > 2 and a[1] == "--preview": O.main(a[0], [float(x) for x in a[2].split(",")])
else: O.main(a[0])
