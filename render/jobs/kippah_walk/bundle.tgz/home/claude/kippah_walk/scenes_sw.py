"""kippah_walk scenes (2 Nov 2026, copied from she_walks_alone; man with a kippah, NY/London/Berlin/Paris/Amsterdam/Tel Aviv, source label under the checklist so it never touches his feet). Base: daily_1101 house scenes (circular loop fade, bar-cut music, _wtext, _label).
One scene type, sc_walk: a night street with a flat skyline of the city (landmark silhouettes, no religious buildings),
and on top a checklist (chips) that fills live, or a card (notperfect, reveal, end), or the hook text.
Drawn ON TOP of every scene by the Reel.draw wrapper (so it never blinks in cross-fades and the loop is seamless):
the pavement, street lamps and the same man walking (walk cycle and scroll speeds are fitted to T_END, so the last
frame equals frame 0), then the source label of the current scene, then the subtitles."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))
import random
GOLD = kit.hx("#FFCD50"); NAVY = kit.hx("#163261"); NIGHT = kit.hx("#0B1426"); SKY = kit.hx("#45A4DD")
GREEN = kit.hx("#34C77B"); RED = kit.hx("#F0525A"); AMBER = kit.hx("#FFB224"); WHITE = (1.0, 1.0, 1.0)
GY = 1392                      # ground line
WH = 340                       # man height
_wtext.__defaults__ = (WHITE, GOLD, 1000, 3, 1.0, 1.0, False)
RD.SUB_Y = 1530
_G = {"T": None}

def _fit(T, period, want):
    """speed so that the pattern repeats exactly over T (seamless loop)"""
    n = max(1, round(T * want / period)); return n * period / T

# ------------------------------------------------------------------ skylines (pre-rendered strips)
TW = 2160; _SK = {}
BLD = kit.hx("#0C1838"); BLD2 = kit.hx("#122452"); RIM = kit.hx("#2A4C8F")
def _win(c, x, y0, w, h, rnd, cols=None, a=0.55):
    cols = cols or max(1, int(w // 26)); rows = int(h // 34)
    cw = w / cols
    for i in range(cols):
        for j in range(rows):
            if rnd.random() < 0.42:
                sa(c, GOLD, a * rnd.uniform(0.35, 1.0)); c.rectangle(x + i * cw + cw * 0.28, y0 + 20 + j * 34, cw * 0.44, 14); c.fill()
def _bld(c, x, w, h, rnd, col=BLD, win=True, roof=None):
    sa(c, col); c.rectangle(x, GY - h, w, h + 2); c.fill()
    if roof == "pitch":
        c.move_to(x - 4, GY - h); c.line_to(x + w / 2, GY - h - w * 0.35); c.line_to(x + w + 4, GY - h); c.close_path(); sa(c, col); c.fill()
    if roof == "cren":
        for k in range(int(w // 22)):
            if k % 2 == 0: c.rectangle(x + k * 22, GY - h - 14, 14, 16); sa(c, col); c.fill()
    if win and h > 60: _win(c, x + 6, GY - h, w - 12, h - 40, rnd)
def _palm(c, x, h, col=BLD):
    sa(c, col); c.set_line_width(12); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.move_to(x, GY); c.curve_to(x + 10, GY - h * 0.5, x - 6, GY - h * 0.8, x + 8, GY - h); c.stroke()
    tx, ty = x + 8, GY - h; c.set_line_width(9)
    for ang in (-2.6, -2.0, -1.2, -0.5, 0.2, 0.8):
        ex, ey = tx + 95 * math.cos(ang), ty + 95 * math.sin(ang) * 0.6 + 30
        c.move_to(tx, ty); c.curve_to(tx + 40 * math.cos(ang), ty - 30, ex - 10, ey - 30, ex, ey); c.stroke()
def _mount(c, pts, col, snow=False):
    c.move_to(0, GY); [c.line_to(x, y) for x, y in pts]; c.line_to(TW, GY); c.close_path(); sa(c, col); c.fill()
    if snow:
        for (x0, y0), (x1, y1), (x2, y2) in zip(pts, pts[1:], pts[2:]):
            if y1 < y0 and y1 < y2 and y1 < GY - 330:
                c.move_to(x1, y1); c.line_to(x1 - (x1 - x0) * 0.25, y1 + (y0 - y1) * 0.25); c.line_to(x1 + (x2 - x1) * 0.25, y1 + (y2 - y1) * 0.25)
                c.close_path(); sa(c, (0.85, 0.9, 1.0), 0.75); c.fill()
def _filler(c, rnd, x0, x1, hmin=90, hmax=260, col=BLD, roof=None):
    x = x0
    while x < x1:
        w = rnd.randint(70, 150); _bld(c, x, w, rnd.randint(hmin, hmax), rnd, col=col, roof=roof); x += w + rnd.randint(4, 30)

def _city(c, key):
    rnd = random.Random(hash(key) % 1000)
    if key == "london":
        _filler(c, rnd, 0, TW, 120, 300, BLD2)
        # Big Ben (Elizabeth Tower)
        x = 300; sa(c, BLD); c.rectangle(x, GY - 560, 90, 560); c.fill()
        c.rectangle(x - 8, GY - 640, 106, 90); c.fill()
        c.move_to(x - 8, GY - 640); c.line_to(x + 45, GY - 790); c.line_to(x + 98, GY - 640); c.close_path(); c.fill()
        circ(c, x + 45, GY - 595, 34, kit.hx("#F6E7B0"), 0.9); sa(c, BLD); c.set_line_width(4)
        c.move_to(x + 45, GY - 595); c.line_to(x + 45, GY - 618); c.move_to(x + 45, GY - 595); c.line_to(x + 62, GY - 590); c.stroke()
        _filler(c, rnd, 420, 760, 120, 200, BLD, roof="pitch")
        # London Eye
        cx, cy, r = 1000, GY - 330, 250; c.set_line_width(7); sa(c, RIM); c.arc(cx, cy, r, 0, 2 * math.pi); c.stroke()
        c.set_line_width(2.5)
        for k in range(16):
            a = k * math.pi / 8; c.move_to(cx, cy); c.line_to(cx + r * math.cos(a), cy + r * math.sin(a)); c.stroke()
            circ(c, cx + r * math.cos(a), cy + r * math.sin(a), 11, SKY, 0.8)
        sa(c, BLD); c.set_line_width(10); c.move_to(cx, cy); c.line_to(cx - 120, GY); c.move_to(cx, cy); c.line_to(cx + 120, GY); c.stroke()
        # the Shard
        x = 1600; c.move_to(x, GY); c.line_to(x + 95, GY - 760); c.line_to(x + 200, GY); c.close_path(); sa(c, BLD); c.fill()
        sa(c, SKY, 0.35); c.set_line_width(3); c.move_to(x + 95, GY - 760); c.line_to(x + 140, GY); c.stroke()
        # red phone box
        sa(c, kit.hx("#D6333C")); rr(c, 1350, GY - 150, 60, 150, 8); c.fill(); sa(c, GOLD, 0.6); c.rectangle(1362, GY - 120, 36, 60); c.fill()
    elif key == "telaviv":
        _filler(c, rnd, 0, TW, 160, 330, BLD2)
        # Azrieli towers: round, triangle, square
        sa(c, BLD); rr(c, 380, GY - 620, 120, 620, 55); c.fill(); _win(c, 392, GY - 600, 96, 560, rnd)
        c.move_to(560, GY); c.line_to(560, GY - 580); c.line_to(690, GY - 560); c.line_to(690, GY); c.close_path(); c.fill(); _win(c, 572, GY - 550, 106, 520, rnd)
        c.rectangle(750, GY - 540, 120, 540); c.fill(); _win(c, 762, GY - 520, 96, 480, rnd)
        # white Bauhaus blocks with rounded balconies
        for x, w, h in ((1000, 260, 230), (1320, 220, 190), (1640, 280, 250)):
            sa(c, kit.hx("#1E3260")); rr(c, x, GY - h, w, h + 4, 18); c.fill()
            for j in range(int(h // 56)):
                sa(c, kit.hx("#E9EEF6"), 0.55); rr(c, x - 10, GY - h + 30 + j * 56, w + 20, 14, 7); c.fill()
        for x in (950, 1270, 1590, 1950): _palm(c, x, 260)
    elif key == "newyork":
        _filler(c, rnd, 0, TW, 200, 420, BLD2)
        # Empire State Building: stepped setbacks, mast
        x = 420; sa(c, BLD)
        for w, h in ((240, 520), (180, 640), (120, 720), (70, 780)):
            c.rectangle(x - w / 2, GY - h, w, h); c.fill()
        c.rectangle(x - 6, GY - 900, 12, 130); c.fill(); _win(c, x - 110, GY - 500, 220, 480, rnd)
        circ(c, x, GY - 790, 9, kit.hx("#FF5A5F"), 0.9)
        # One World Trade Center: tapered faces
        x = 1080; c.move_to(x - 110, GY); c.line_to(x - 110, GY - 260); c.line_to(x - 55, GY - 820); c.line_to(x + 55, GY - 820)
        c.line_to(x + 110, GY - 260); c.line_to(x + 110, GY); c.close_path(); sa(c, BLD); c.fill()
        sa(c, SKY, 0.35); c.set_line_width(3); c.move_to(x - 110, GY - 260); c.line_to(x + 55, GY - 820); c.move_to(x + 110, GY - 260); c.line_to(x - 55, GY - 820); c.stroke()
        sa(c, BLD); c.rectangle(x - 4, GY - 960, 8, 140); c.fill()
        # Brooklyn Bridge: two gothic towers and cables
        for bx in (1550, 1950):
            sa(c, kit.hx("#1A2C5C")); c.rectangle(bx - 45, GY - 470, 90, 470); c.fill()
            for ox in (-22, 22):
                c.move_to(bx + ox - 12, GY - 300); c.line_to(bx + ox - 12, GY - 400); c.arc(bx + ox, GY - 400, 12, math.pi, 2 * math.pi); c.line_to(bx + ox + 12, GY - 300); c.close_path(); sa(c, NIGHT); c.fill()
        sa(c, RIM); c.set_line_width(4)
        c.move_to(1400, GY - 140); c.curve_to(1470, GY - 300, 1500, GY - 440, 1550, GY - 460); c.curve_to(1700, GY - 200, 1800, GY - 200, 1950, GY - 460)
        c.curve_to(2000, GY - 440, 2060, GY - 300, 2140, GY - 140); c.stroke()
        sa(c, BLD); c.rectangle(1380, GY - 150, 780, 22); c.fill()
        # water tank and a yellow cab
        sa(c, BLD); c.rectangle(720, GY - 470, 50, 55); c.fill(); c.move_to(715, GY - 470); c.line_to(745, GY - 500); c.line_to(775, GY - 470); c.fill()
        sa(c, kit.hx("#F6C343")); rr(c, 1250, GY - 70, 170, 52, 14); c.fill(); rr(c, 1290, GY - 104, 90, 40, 10); c.fill()
        circ(c, 1285, GY - 16, 16, kit.hx("#0A1226")); circ(c, 1385, GY - 16, 16, kit.hx("#0A1226"))
    elif key == "berlin":
        _filler(c, rnd, 0, TW, 120, 260, BLD2)
        # Fernsehturm: shaft, sphere, antenna
        x = 1350; sa(c, BLD); c.move_to(x - 34, GY); c.line_to(x - 14, GY - 640); c.line_to(x + 14, GY - 640); c.line_to(x + 34, GY); c.close_path(); c.fill()
        circ(c, x, GY - 690, 70, kit.hx("#1E3466")); sa(c, BLD); c.rectangle(x - 7, GY - 930, 14, 190); c.fill()
        sa(c, kit.hx("#FF5A5F"), 0.85); c.rectangle(x - 7, GY - 900, 14, 22); c.fill()
        for k in range(7): circ(c, x - 48 + k * 16, GY - 690, 4, GOLD, 0.8)
        # Brandenburg Gate: columns, entablature, attic with the quadriga block
        x0 = 280; w = 560; sa(c, kit.hx("#1E3466"))
        c.rectangle(x0, GY - 330, w, 44); c.fill(); c.rectangle(x0 + 150, GY - 395, w - 300, 65); c.fill()
        c.move_to(x0 + 230, GY - 395); c.line_to(x0 + 250, GY - 455); c.line_to(x0 + 310, GY - 455); c.line_to(x0 + 330, GY - 395); c.close_path(); c.fill()
        for k in range(6): c.rectangle(x0 + 14 + k * (w - 56) / 5, GY - 286, 28, 286); c.fill()
        sa(c, GOLD, 0.25); c.rectangle(x0, GY - 290, w, 4); c.fill()
    elif key == "paris":
        # Haussmann blocks with mansard roofs
        x = 0
        while x < TW:
            w = rnd.randint(160, 240); h = rnd.randint(200, 260)
            sa(c, BLD2); c.rectangle(x, GY - h, w, h + 2); c.fill()
            c.move_to(x, GY - h); c.line_to(x + 16, GY - h - 60); c.line_to(x + w - 16, GY - h - 60); c.line_to(x + w, GY - h); c.close_path(); sa(c, kit.hx("#0E1C44")); c.fill()
            for j in range(3):
                sa(c, GOLD, 0.4); c.rectangle(x + 10, GY - h + 40 + j * 64, w - 20, 4); c.fill()
            _win(c, x + 6, GY - h, w - 12, h - 30, rnd); x += w + 6
        # Eiffel Tower: curved legs, two platforms, lattice
        x = 720; sa(c, BLD)
        c.move_to(x - 230, GY); c.curve_to(x - 150, GY - 220, x - 70, GY - 520, x - 18, GY - 860); c.line_to(x + 18, GY - 860)
        c.curve_to(x + 70, GY - 520, x + 150, GY - 220, x + 230, GY); c.line_to(x + 150, GY)
        c.curve_to(x + 110, GY - 160, x + 40, GY - 210, x, GY - 210); c.curve_to(x - 40, GY - 210, x - 110, GY - 160, x - 150, GY); c.close_path(); c.fill()
        c.rectangle(x - 140, GY - 300, 280, 18); c.fill(); c.rectangle(x - 80, GY - 560, 160, 14); c.fill(); c.rectangle(x - 4, GY - 960, 8, 110); c.fill()
        sa(c, GOLD, 0.35); c.set_line_width(2)
        for k in range(1, 9):
            yy = GY - 300 - k * 62; hw = 30 + (860 - (300 + k * 62)) * 0.0
            c.move_to(x - 120 + k * 11, yy); c.line_to(x + 120 - k * 11, yy + 62); c.move_to(x + 120 - k * 11, yy); c.line_to(x - 120 + k * 11, yy + 62); c.stroke()
        circ(c, x, GY - 960, 7, GOLD, 0.9)
        # Arc de Triomphe
        x = 1600; c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD)
        c.rectangle(x - 190, GY - 420, 380, 420)
        c.move_to(x - 70, GY); c.line_to(x - 70, GY - 230); c.arc(x, GY - 230, 70, math.pi, 2 * math.pi); c.line_to(x + 70, GY); c.close_path()
        sa(c, kit.hx("#1E3466")); c.fill(); c.set_fill_rule(cairo.FILL_RULE_WINDING)
        sa(c, kit.hx("#1E3466")); c.rectangle(x - 205, GY - 450, 410, 34); c.fill()
    elif key == "amsterdam":
        # narrow canal houses with step, bell and neck gables, a bridge over the canal
        cols = [kit.hx(h) for h in ("#1C2F63", "#2A2E5C", "#223A6E", "#2E2A55", "#1A3560", "#33305E")]
        x = 0; k = 0
        while x < TW:
            w = rnd.randint(110, 150); h = rnd.randint(330, 450); col = cols[k % len(cols)]; k += 1
            sa(c, col); c.rectangle(x, GY - h, w, h + 2); c.fill()
            g = k % 3
            if g == 0:     # step gable
                for s_ in range(3): c.rectangle(x + s_ * w / 7, GY - h - (s_ + 1) * 28, w - 2 * s_ * w / 7, 30); c.fill()
            elif g == 1:   # bell gable
                c.move_to(x + 10, GY - h); c.curve_to(x + 10, GY - h - 70, x + w / 2 - 20, GY - h - 40, x + w / 2, GY - h - 95)
                c.curve_to(x + w / 2 + 20, GY - h - 40, x + w - 10, GY - h - 70, x + w - 10, GY - h); c.close_path(); c.fill()
            else:          # neck gable
                c.rectangle(x + w * 0.25, GY - h - 80, w * 0.5, 82); c.fill()
                c.move_to(x + w * 0.25, GY - h - 80); c.line_to(x + w / 2, GY - h - 110); c.line_to(x + w * 0.75, GY - h - 80); c.close_path(); c.fill()
            sa(c, kit.hx("#E9EEF6"), 0.6); c.rectangle(x + w / 2 - 3, GY - h - 60, 6, 18); c.fill()   # hoist beam
            for j in range(int((h - 60) // 70)):
                for i in range(2):
                    wx = x + w * (0.22 + 0.36 * i); wy = GY - h + 30 + j * 70
                    sa(c, kit.hx("#E9EEF6"), 0.7); c.set_line_width(3); c.rectangle(wx, wy, w * 0.2, 40); c.stroke()
                    if rnd.random() < 0.5: sa(c, GOLD, 0.6); c.rectangle(wx + 2, wy + 2, w * 0.2 - 4, 36); c.fill()
            x += w + 2
        # canal bridge with arches and a bike rail
        sa(c, kit.hx("#0E1C44")); c.set_fill_rule(cairo.FILL_RULE_EVEN_ODD); c.rectangle(700, GY - 120, 760, 120)
        for bx in (870, 1080, 1290):
            c.move_to(bx - 70, GY); c.arc(bx, GY, 70, math.pi, 2 * math.pi); c.close_path()
        c.fill(); c.set_fill_rule(cairo.FILL_RULE_WINDING)
        for k2 in range(14): circ(c, 720 + k2 * 55, GY - 126, 5, GOLD, 0.8)
        sa(c, kit.hx("#9FB4D6"), 0.8); c.set_line_width(5)
        bx, by = 1100, GY - 150
        for ox in (0, 70): c.arc(bx + ox, by, 22, 0, 2 * math.pi); c.stroke()
        c.move_to(bx, by); c.line_to(bx + 28, by - 32); c.line_to(bx + 70, by); c.move_to(bx + 28, by - 32); c.line_to(bx + 56, by - 32); c.line_to(bx + 35, by); c.stroke()
    else:   # neutral street for the hook and the cards
        _filler(c, rnd, 0, TW, 110, 330, BLD2)
        _filler(c, rnd, 60, TW, 80, 200, BLD)

def _strip(key):
    if key not in _SK:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, TW, H); c = cairo.Context(s); keep = St.a; St.a = 1.0
        _city(c, key); St.a = keep; s.flush(); _SK[key] = s
    return _SK[key]

def _sky(c, t):
    g = cairo.LinearGradient(0, 0, 0, GY); g.add_color_stop_rgb(0, *NIGHT[:3]); g.add_color_stop_rgb(0.7, *NAVY[:3]); g.add_color_stop_rgb(1, 0.15, 0.26, 0.55)
    c.new_path(); c.set_source(g); c.paint_with_alpha(St.a)
    rnd = random.Random(7)
    for k in range(70):
        x, y = rnd.uniform(0, W), rnd.uniform(0, 900); tw = 0.5 + 0.5 * math.sin(t * rnd.uniform(1, 3) + k)
        circ(c, x, y, rnd.uniform(1.2, 2.6), WHITE, (0.25 + 0.45 * tw))
    circ(c, 930, 215, 60, kit.hx("#F6EBC8"), 0.18); circ(c, 930, 215, 44, kit.hx("#F6EBC8"), 0.9)   # full moon

def _skyline(c, t, key):
    s = _strip(key); T = _G["T"] or 60.0; v = _fit(T, TW, 34.0); off = (t * v) % TW
    for k in (0, 1):
        c.set_source_surface(s, -off + k * TW, 0); c.paint_with_alpha(St.a)

# ------------------------------------------------------------------ chips
def _icon(c, x, y, st, u, a):
    r = 40
    if st == "pend" or u <= 0.01:
        sa(c, WHITE, 0.35 * a); c.set_line_width(4); c.arc(x, y, r, 0, 2 * math.pi); c.stroke(); return
    s = kit.pop(0.0, 0.0)[1] if False else 1.0
    colr = {"y": GREEN, "n": RED, "p": AMBER}[st]
    sc_ = 0.4 + 0.6 * kit.eob(min(1.0, u)) if u < 1 else 1.0
    c.save(); c.translate(x, y); c.scale(sc_, sc_)
    circ(c, 0, 0, r, colr, a); sa(c, WHITE, a); c.set_line_width(9); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    if st == "y": c.move_to(-17, 1); c.line_to(-5, 14); c.line_to(18, -13); c.stroke()
    elif st == "n": c.move_to(-14, -14); c.line_to(14, 14); c.move_to(14, -14); c.line_to(-14, 14); c.stroke()
    else: c.move_to(-16, 0); c.line_to(16, 0); c.stroke()
    c.restore()

def _chip_times(S, n):
    ts = [S["times"].get(f"c{j}", S["t0"] + 0.6 + 0.5 * j) for j in range(n)]
    order = sorted(range(n), key=lambda j: ts[j])
    for a_, b_ in zip(order, order[1:]):
        if ts[b_] < ts[a_] + 0.22: ts[b_] = ts[a_] + 0.22
    return ts

def _chips(c, t, S, y0, rh=170, gap=16):
    chips = S["chips"]; ts = _chip_times(S, len(chips))
    for j, ch in enumerate(chips):
        ya = y0 + j * (rh + gap); a = RD.fade_in(t, S["t0"] + 0.1 + 0.08 * j, S, 0.3)
        if a <= 0.01: continue
        u = (t - ts[j]) / 0.4 if t >= ts[j] else 0.0
        on = t >= ts[j]; st = ch["st"]
        edge = {"y": GREEN, "n": RED, "p": AMBER, "pct": GOLD, "num": GOLD}.get(st, GOLD) if on else (0.35, 0.45, 0.65)
        sa(c, INK, 0.80 * a); rr(c, 40, ya, 1000, rh, 32); c.fill()
        sa(c, edge, 0.9 * a); c.set_line_width(4); rr(c, 40, ya, 1000, rh, 32); c.stroke()
        cy = ya + rh / 2
        if st in ("pct", "num"):
            kit.tx(c, ch["en"], 54, 76, cy - 26, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=660, anchor="l")
            if ch.get("note"):
                kit.tx(c, ch["note"], 40, 76, cy + 34, w=700, col=RD.c255((0.80, 0.86, 0.96)), a=a, shadow=False, maxw=600, anchor="l")
            if on:
                e = ease(min(1.0, (t - ts[j]) / (0.9 if st == "pct" else 1.3)))
                if st == "pct": txt = f"{ch['pct'] * e:.0f}%"
                else: txt = f"{ch['val'] * e:,.0f}"
                kit.tx(c, txt, 92, 1010, cy, w=900, col=RD.c255(GOLD), a=a, shadow=False, maxw=270, anchor="r")
            continue
        _icon(c, 110, cy, st if on else "pend", u, a)
        if ch.get("note") and on:
            kit.tx(c, ch["en"], 58, 172, cy - 24, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=840, anchor="l")
            kit.tx(c, ch["note"], 42, 172, cy + 36, w=700, col=RD.c255(AMBER if st == "p" else (0.80, 0.86, 0.96)), a=a * ramp(t, ts[j], ts[j] + 0.3), shadow=False, maxw=840, anchor="l")
        else:
            kit.tx(c, ch["en"], 58, 172, cy, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=840, anchor="l")

# ------------------------------------------------------------------ the scene
def sc_walk(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); _sky(c, t); _skyline(c, t, S.get("city", "none"))
    card = S.get("card")
    if hook:
        _wtext(c, S["en"], 140, 640, a=1.0, sc=1.0 + 0.012 * math.sin(t * 2.2), max_lines=3); return
    if card == "intro":
        a1, s1 = PP(t, t0 + 0.05, S); _wtext(c, S["en"], 120, 620, a=a1, sc=s1, max_lines=2); return
    if card == "end":
        a1, s1 = PP(t, t0 + 0.1, S); _wtext(c, S["en"], 130, 620, a=a1 * (1 - ramp(t, (S["t1"] or t0 + 4) - 0.9, (S["t1"] or t0 + 4) - 0.45)), sc=s1, max_lines=2); return
    if card == "notperfect":
        a1, s1 = PP(t, t0 + 0.05, S); _wtext(c, S["title"], 120, 420, a=a1, sc=s1, max_lines=1)
        kit.tx(c, "Israel", 60, 540, 540, w=800, col=RD.c255(SKY), a=a1, shadow=True, maxw=1000)
        _chips(c, t, S, 620); return
    if card == "reveal":
        ta = S["times"].get("r0", t0 + 0.4); tb = S["times"].get("r1", t0 + 1.4)
        for (tk, cap, big, small, y, colr) in ((ta, "WHERE HE NEVER HIDES", "Tel Aviv", "kippah on, every street", 470, GREEN),
                                                (tb, "WHERE HE RUNS FOR SHELTER", "Also Tel Aviv", "Iranian missiles, June 2025", 790, RED)):
            a2, s2 = PP(t, tk, S, s0=0.6, bounce=1.4)
            if a2 <= 0.01: continue
            sa(c, INK, 0.80 * a2); rr(c, 40, y - 125, 1000, 270, 34); c.fill()
            sa(c, colr, 0.9 * a2); c.set_line_width(4); rr(c, 40, y - 125, 1000, 270, 34); c.stroke()
            kit.tx(c, cap, 50, 540, y - 72, w=900, col=RD.c255(SKY), a=a2, shadow=False, maxw=940)
            _wtext(c, big, 110, y + 18, color=GOLD, a=a2, sc=s2, max_lines=1, maxw=940)
            kit.tx(c, small, 46, 540, y + 102, w=700, col=RD.c255((0.85, 0.9, 1.0)), a=a2, shadow=False, maxw=940)
        return
    # a city: name, country, the live checklist
    a1, s1 = PP(t, t0 + 0.05, S)
    _wtext(c, S["name"], 120, 350, a=a1, sc=s1, max_lines=1)
    kit.tx(c, S["sub"], 52, 540, 440, w=800, col=RD.c255(SKY), a=a1, shadow=True, maxw=1000)
    _chips(c, t, S, 492)

# ------------------------------------------------------------------ top layer: street, lamps, the man, source, subtitles
def _limb(c, pts, w, colr, a):
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; sa(c, colr, a); c.set_line_width(w); c.stroke()

def man(c, x, gy, h, ph, a=1.0):
    """flat illustration man with a kippah, walking right; ph in radians (one stride = 2 pi)"""
    SKIN = kit.hx("#EBC9AE"); JKT = SKY; JKT2 = kit.hx("#2F86BF"); LEG = kit.hx("#D3DCEA"); LEG2 = kit.hx("#A9B8CF"); HAIR = kit.hx("#2E211C")
    SHOE = kit.hx("#1C2B4A")
    bob = abs(math.sin(ph)) * h * 0.012
    hip = (x, gy - h * 0.50 - bob); sh = (x + h * 0.02, gy - h * 0.80 - bob); hd = (x + h * 0.035, gy - h * 0.905 - bob)
    th, sn = h * 0.255, h * 0.255
    def leg(phase, colr, w):
        s = math.sin(phase); a_th = 0.42 * s; kne = 0.55 * max(0.0, -math.cos(phase)) + 0.08
        kx, ky = hip[0] + th * math.sin(a_th), hip[1] + th * math.cos(a_th)
        a_sn = a_th - kne; fx, fy = kx + sn * math.sin(a_sn), ky + sn * math.cos(a_sn)
        fy = min(fy, gy - 5)
        _limb(c, [hip, (kx, ky), (fx, fy)], w, colr, a)
        _limb(c, [(fx - 6, fy + 2), (fx + h * 0.065, fy + 2)], w * 0.85, SHOE, a)
    def arm(phase, colr, w):
        s = math.sin(phase); a_u = -0.38 * s; ex, ey = sh[0] + h * 0.15 * math.sin(a_u), sh[1] + h * 0.15 * math.cos(a_u)
        a_f = a_u + 0.35 + 0.2 * max(0, s); hx_, hy_ = ex + h * 0.14 * math.sin(a_f), ey + h * 0.14 * math.cos(a_f)
        _limb(c, [sh, (ex, ey)], w * 1.3, colr, a); _limb(c, [(ex, ey), (hx_, hy_)], w * 1.2, colr, a)
        circ(c, hx_ + (hx_ - ex) * 0.12, hy_ + (hy_ - ey) * 0.12, w * 0.55, SKIN, a)
    leg(ph + math.pi, LEG2, h * 0.065); arm(ph, JKT2, h * 0.045)
    leg(ph, LEG, h * 0.07)
    # jacket: straight cut, shoulders to the hip
    c.move_to(sh[0] - h * 0.085, sh[1] - h * 0.005); c.line_to(sh[0] + h * 0.085, sh[1] - h * 0.005)
    c.line_to(hip[0] + h * 0.095, hip[1] + h * 0.05); c.line_to(hip[0] - h * 0.095, hip[1] + h * 0.05); c.close_path(); sa(c, JKT, a); c.fill()
    sa(c, kit.hx("#E9EEF6"), a); c.move_to(sh[0] + h * 0.02, sh[1] - h * 0.005); c.line_to(sh[0] + h * 0.055, sh[1] + h * 0.07); c.line_to(sh[0] + h * 0.075, sh[1] - h * 0.005); c.close_path(); c.fill()   # shirt collar
    # neck, head, short hair, ear, kippah
    _limb(c, [(sh[0] + h * 0.01, sh[1]), (hd[0] - h * 0.005, hd[1] + h * 0.04)], h * 0.045, SKIN, a)
    circ(c, hd[0], hd[1], h * 0.06, SKIN, a)
    c.move_to(hd[0] - h * 0.063, hd[1] + h * 0.02); c.arc(hd[0], hd[1], h * 0.064, math.pi * 0.92, math.pi * 1.78)
    c.curve_to(hd[0] + h * 0.01, hd[1] - h * 0.045, hd[0] - h * 0.03, hd[1] - h * 0.02, hd[0] - h * 0.035, hd[1] + h * 0.03); c.close_path(); sa(c, HAIR, a); c.fill()
    circ(c, hd[0] - h * 0.012, hd[1] + h * 0.008, h * 0.013, kit.hx("#DDB497"), a)
    kx0, ky0 = hd[0] - h * 0.012, hd[1] - h * 0.058
    c.save(); c.translate(kx0, ky0); c.rotate(-0.12); c.scale(1.0, 0.42)
    c.arc(0, 0, h * 0.05, math.pi, 2 * math.pi); c.close_path(); c.restore(); sa(c, WHITE, a); c.fill()
    c.save(); c.translate(kx0, ky0); c.rotate(-0.12); sa(c, SKY, a); c.set_line_width(h * 0.009)
    c.move_to(-h * 0.047, -h * 0.004); c.line_to(h * 0.047, -h * 0.004); c.stroke(); c.restore()
    arm(ph + math.pi, JKT, h * 0.05)

def _street(c, t):
    T = _G["T"] or 60.0
    g = cairo.LinearGradient(0, GY, 0, H); g.add_color_stop_rgb(0, 0.10, 0.16, 0.30); g.add_color_stop_rgb(0.25, 0.05, 0.09, 0.18); g.add_color_stop_rgb(1, 0.02, 0.04, 0.09)
    c.rectangle(0, GY, W, H - GY); c.set_source(g); c.fill()
    sa(c, (0.55, 0.65, 0.85), 0.5); c.rectangle(0, GY, W, 3); c.fill()
    v = _fit(T, 540, 150.0); off = (t * v) % 540
    for k in range(-1, 4):
        x = k * 540 - off + 270
        # paving joints
        sa(c, (1, 1, 1), 0.06); c.rectangle(x - 270, GY + 10, 2, 50); c.fill()
        # lamp: pole, arm, warm glow
        sa(c, kit.hx("#0A1226")); c.rectangle(x - 6, GY - 360, 12, 360); c.fill(); c.rectangle(x - 6, GY - 360, 60, 10); c.fill()
        lx, ly = x + 50, GY - 345
        rg = cairo.RadialGradient(lx, ly, 0, lx, ly, 260); rg.add_color_stop_rgba(0, 1, 0.85, 0.5, 0.30); rg.add_color_stop_rgba(1, 1, 0.85, 0.5, 0)
        c.set_source(rg); c.arc(lx, ly, 260, 0, 2 * math.pi); c.fill()
        circ(c, lx, ly, 14, kit.hx("#FFE6A8"), 1.0)
        c.save(); c.translate(lx, GY + 20); c.scale(1.0, 0.18); rg = cairo.RadialGradient(0, 0, 0, 0, 0, 200)
        rg.add_color_stop_rgba(0, 1, 0.85, 0.5, 0.22); rg.add_color_stop_rgba(1, 1, 0.85, 0.5, 0); c.set_source(rg); c.arc(0, 0, 200, 0, 2 * math.pi); c.fill(); c.restore()

def _cur(self, t):
    i = 0
    for k, S in enumerate(self.scenes):
        if t >= S["t0"] - 0.01: i = k
    return i

_subs_draw = RD.draw_subs; RD.draw_subs = lambda c, t, items: None
_draw_prev = RD.Reel.draw
def _draw_top(self, c, t):
    _G["T"] = self.T_END
    _draw_prev(self, c, t)
    keep = St.a; St.a = 1.0
    _street(c, t)
    per = 1.08; n = max(1, round(self.T_END / per)); ph = 2 * math.pi * n * (t / self.T_END)
    c.save(); sa(c, (0, 0, 0), 0.35); c.translate(540, GY + 6); c.scale(1.0, 0.12); c.arc(0, 0, 110, 0, 2 * math.pi); c.fill(); c.restore()
    man(c, 520, GY, WH, ph)
    i = _cur(self, t); S = self.scenes[i]
    if S.get("source"):
        a = ramp(t, S["t0"] + 0.3, S["t0"] + 0.7) * (1 - ramp(t, (S["t1"] or self.T_END) - 0.25, (S["t1"] or self.T_END)))
        if a > 0.01: _label(c, S["source"], S.get("label_y", 905), a)
    _subs_draw(c, t, self.subs)
    St.a = keep
RD.Reel.draw = _draw_top
