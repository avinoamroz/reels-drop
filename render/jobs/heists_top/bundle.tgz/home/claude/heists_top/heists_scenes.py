"""heists_top scenes (2 Nov 2026): world-map countdown of the biggest heists in 2026 dollars.
Brand (brandbook): night #0B1426, navy #163261 / #1E3F78, sky #45A4DD, gold #FFCD50 numbers, Heebo.
Layout: rank + place at the top (y 300 to 420), world map y 470 to 1000 with a moving camera and gold pins,
a vault door that spins and swings open at y 1215, the gold counter racing up across it, source at y 1428, subs y 1530.
Circular: the last 0.5 s cross-fade into frame 0; the music bed is cut on whole bars."""
import math
import numpy as np
import cairo
import render as RD
import kit
from render import T, block, block_h, pill, geo, clean
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, FPS

C = {k: kit.hx(v) for k, v in dict(night="#0B1426", night2="#101C36", navy="#163261", navy2="#1E3F78", sky="#45A4DD", gold="#FFCD50",
                                     ink="#F4F6FA", mute="#9AA7BE", green="#3FBF7F", red="#E5484D", amber="#F5A524", line="#24324D",
                                     land="#1B2C52", border="#2C4270").items()}
MY0, MY1 = 460, 945; MCY = (MY0 + MY1) / 2
VY = 1212; VR = 158
RD.SUB_Y = 1540; RD.SOURCE_Y = 1462; RD.CONTENT_BOTTOM = 1420
_subs = getattr(RD, "_subs_orig", RD.sub_surfs); RD._subs_orig = _subs
RD.sub_surfs = lambda pieces, sz=54, maxw=1000: _subs(pieces, sz, maxw)

# ------------------------------------------------------------------ world map base (equirectangular, 2400 px wide)
LON0, LON1, LAT0, LAT1 = -180.0, 180.0, -58.0, 80.0
BK = 2400 / (LON1 - LON0); BW, BH = 2400, int((LAT1 - LAT0) * BK)
def bxy(lon, lat): return ((lon - LON0) * BK, (LAT1 - lat) * BK)
_M = {}
def base():
    if "s" in _M: return _M["s"]
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, BW, BH); c = cairo.Context(s)
    keep = St.a; St.a = 1.0
    G = geo()
    for k, v in G.items():
        g = v["g"].simplify(0.08)
        ps = [g] if g.geom_type == "Polygon" else [p for p in getattr(g, "geoms", []) if p.geom_type == "Polygon"]
        for p in ps:
            pts = [bxy(x, y) for x, y in p.exterior.coords]
            c.move_to(*pts[0])
            for q in pts[1:]: c.line_to(*q)
            c.close_path()
        sa(c, C["gold"] if k in ("IL", "PS") else C["land"]); c.fill_preserve(); sa(c, C["border"]); c.set_line_width(1.4); c.stroke()
    St.a = keep; _M["s"] = s; return s

# ------------------------------------------------------------------ heists (filled from the spec), camera
HZ = []          # dicts: key, lonlat or None, t (pin time), rank
CAM = []         # (t, lon, lat, zoom)
def _setup(reel):
    HZ.clear(); CAM.clear(); CAM.append((0.0, 20.0, 22.0, 1.0))
    for S in reel.scenes:
        if S["type"] == "entry":
            tv = S["times"].get("v", S["t0"] + 1.0)
            HZ.append(dict(key=S["key"], ll=S.get("ll"), t=S["t0"] + 0.35, rank=S.get("rank", ""), tv=tv))
            if S.get("ll"): CAM.append((S["t0"], S["ll"][0], S["ll"][1], S.get("zoom", 2.3)))
            else: CAM.append((S["t0"], 20.0, 22.0, 1.0))
        else: CAM.append((S["t0"], 20.0, 22.0, S.get("zoom", 1.0)))
_init = getattr(RD.Reel, "_init_orig", RD.Reel.__init__); RD.Reel._init_orig = _init
def _init_hz(self, spec, tim):
    _init(self, spec, tim); _setup(self)
RD.Reel.__init__ = _init_hz

def cam(t):
    cur = CAM[0]; prev = CAM[0]
    for k, c_ in enumerate(CAM):
        if c_[0] <= t: prev = CAM[k - 1] if k else c_; cur = c_
    u = ease((t - cur[0]) / 0.9)
    lon = lerp(prev[1], cur[1], u); lat = lerp(prev[2], cur[2], u); z = math.exp(lerp(math.log(prev[3]), math.log(cur[3]), u))
    return lon, lat, z * (1 + 0.025 * math.sin(t * 0.6))
def to_screen(lon, lat, t):
    cl, ct, z = cam(t); s = (1080 / BW) * z
    bx, by = bxy(lon, lat); cx, cy = bxy(cl, ct)
    return 540 + (bx - cx) * s, MCY + (by - cy) * s, s

def background(c, t):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *C["night"][:3]); g.add_color_stop_rgb(1, *C["night2"][:3])
    c.set_source(g); c.paint()
    # map panel
    c.save(); rr(c, 0, MY0, 1080, MY1 - MY0, 0); c.clip()
    cl, ct, z = cam(t); s = (1080 / BW) * z; cx, cy = bxy(cl, ct)
    c.save(); c.translate(540, MCY); c.scale(s, s); c.translate(-cx, -cy)
    c.set_source_surface(base(), 0, 0); c.get_source().set_filter(cairo.FILTER_GOOD); c.paint()
    c.restore()
    # pins
    act = None
    for h in HZ:
        if t >= h["t"] - 0.01: act = h
    for h in HZ:
        if not h["ll"] or t < h["t"]: continue
        x, y, _ = to_screen(h["ll"][0], h["ll"][1], t); u = ease((t - h["t"]) / 0.35)
        on = h is act
        if on:
            for k in range(3):
                ph = ((t - h["t"]) * 0.8 + k / 3) % 1.0
                c.new_sub_path(); c.arc(x, y, 18 + 90 * ph, 0, 2 * math.pi); sa(c, C["gold"], 0.55 * (1 - ph)); c.set_line_width(5); c.stroke()
        r = (22 if on else 12) * (0.4 + 0.6 * kit.eob(min(1, (t - h["t"]) / 0.35)))
        circ(c, x, y, r + 5, C["night"], u); circ(c, x, y, r, C["gold"], u)
        if not on and h["rank"]:
            T(c, h["rank"], 40, x, y - 42, C["gold"], u, 1.0, 900, maxw=120)
    c.restore()
    # thin frame lines
    sa(c, C["line"]); c.rectangle(0, MY0, 1080, 3); c.fill(); c.rectangle(0, MY1 - 3, 1080, 3); c.fill()
RD.background = background

# ------------------------------------------------------------------ circular: last 0.5 s fade into frame 0
_draw = getattr(RD.Reel, "_draw_orig", RD.Reel.draw); RD.Reel._draw_orig = _draw
def _draw_loop(self, c, t):
    if getattr(self, "_hz_ok", None) is not True: _setup(self); self._hz_ok = True
    L = float(self.spec.get("loop_fade", 0.5))
    if t < self.T_END - L - 1e-6: return _draw(self, c, t)
    if not hasattr(self, "_f0"):
        s0 = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); _draw(self, cairo.Context(s0), 0.0); s0.flush(); self._f0 = s0
    _draw(self, c, t)
    u = min(1.0, max(0.0, (t - (self.T_END - L)) / max(1e-3, L - 1.0 / FPS)))
    c.set_source_surface(self._f0, 0, 0); c.paint_with_alpha(ease(u))
RD.Reel.draw = _draw_loop

try:
    import mix as MX
    BPM = {"playful": 112, "journey": 100, "doc_piano": 86, "cinematic": 84}
    _bed = getattr(MX, "_bed_orig", MX.bed); MX._bed_orig = _bed
    def bed_loop(name, dur, end_at=None):
        if name not in BPM: return _bed(name, dur, end_at)
        bar = 240.0 / BPM[name]; nb = max(4, int(round(dur / bar))); L = nb * bar; off = 2 * bar
        raw = _bed(name, off + L + 4.0, off + L + 4.0)
        seg = raw[:, int(round(off * MX.SR)):int(round((off + L) * MX.SR))]
        n = int(dur * MX.SR); x = np.linspace(0, seg.shape[1] - 1, n)
        out = np.vstack([np.interp(x, np.arange(seg.shape[1]), ch) for ch in seg])
        f = int(0.012 * MX.SR); out[:, :f] *= np.linspace(0, 1, f); out[:, -f:] *= np.linspace(1, 0, f)
        return out / (np.abs(out).max() + 1e-12)
    MX.bed = bed_loop
except Exception as e:
    print("bed_loop not installed:", e)

# ------------------------------------------------------------------ helpers
def money(v):
    if v >= 1e9: return f"${v / 1e9:.1f}B"
    return f"${v / 1e6:,.0f}M"
def src(c, t, S):
    s = S.get("source")
    if not s: return
    a = 1.0 if S.get("hook") else ramp(t, S["t0"] + 0.5, S["t0"] + 0.8)
    T(c, s, 38, 540, RD.SOURCE_Y, C["mute"], a, 1.0, 700, maxw=1010, src=True)
def stamp(c, t, t0, s, colr, x=540, y=VY - VR - 10, rot=-0.06):
    if t < t0: return
    u = min(1.0, (t - t0) / 0.28); sc = lerp(1.7, 1.0, kit.eob(u)); a = min(1.0, u * 1.6)
    c.save(); c.translate(x, y); c.rotate(rot); c.translate(-x, -y)
    pill(c, s, 56, x, y, C["night"], colr, a, sc, outline=colr)
    c.restore()

def vault(c, t, t_open, v_from, v_to, lab_t0, big=1.0, t_land=None):
    """vault door spins (t_open-0.6..t_open), swings open (t_open..t_open+0.4); counter races v_from -> v_to across it"""
    x, y = 540, VY
    op = ramp(t, t_open, t_open + 0.4)
    if op > 0.01:   # light from inside
        rg = cairo.RadialGradient(x, y, 10, x, y, VR * 1.9 * big)
        rg.add_color_stop_rgba(0, *C["gold"][:3], 0.55 * op * St.a); rg.add_color_stop_rgba(1, *C["gold"][:3], 0)
        c.set_source(rg); c.arc(x, y, VR * 1.9 * big, 0, 2 * math.pi); c.fill()
        circ(c, x, y, VR, C["night"], 0.9 * op, stroke=C["gold"], sw=6)
    if op < 0.99:   # the door
        spin = -2.4 * ramp(t, t_open - 0.6, t_open)
        c.save(); c.translate(x - VR, y); c.scale(max(0.02, 1 - op), 1.0); c.translate(-(x - VR), -y)
        circ(c, x, y, VR, C["navy2"], 1.0, stroke=C["sky"], sw=8)
        circ(c, x, y, VR * 0.72, C["navy"], 1.0, stroke=C["border"], sw=5)
        for k in range(12):   # bolts
            an = k * math.pi / 6; circ(c, x + math.cos(an) * VR * 0.86, y + math.sin(an) * VR * 0.86, 9, C["sky"], 1.0)
        c.save(); c.translate(x, y); c.rotate(spin)
        sa(c, C["ink"]); c.set_line_width(16); c.set_line_cap(cairo.LINE_CAP_ROUND)
        for k in range(3):
            an = k * 2 * math.pi / 3; c.move_to(0, 0); c.line_to(math.cos(an) * VR * 0.55, math.sin(an) * VR * 0.55); c.stroke()
        circ(c, 0, 0, 26, C["gold"], 1.0)
        c.restore(); c.restore()
    if t >= t_open:
        u = ease((t - t_open) / max(1.0, (t_land or t_open + 1.0) - t_open))
        lg = math.log(max(v_from, 1e6)); v = math.exp(lerp(lg, math.log(v_to), u)) if v_from > 0 else v_to * u
        a = min(1.0, (t - t_open) / 0.15); sc = (0.75 + 0.25 * kit.eob(min(1, (t - t_open) / 0.4))) * big
        T(c, money(v), 180, x + 4, y + 8, C["night"], 0.8 * a, sc, 900, maxw=1000)
        T(c, money(v), 180, x, y, C["gold"], a, sc, 900, maxw=1000)
    if lab_t0 is not None and t >= lab_t0:
        T(c, "in 2026 dollars", 44, x, y + VR + 52 if big <= 1.0 else y + VR + 70, C["ink"], ramp(t, lab_t0, lab_t0 + 0.3), 1.0, 700, maxw=900)

def header(c, t, S):
    a = 1.0 if S.get("hook") else ramp(t, S["t0"], S["t0"] + 0.25); dy = 0 if S.get("hook") else 30 * (1 - a)
    rk = S.get("rank", ""); pl = S.get("place", "")
    if rk:
        T(c, rk, 120, 540, 300 + dy, C["gold"], a, 1.0, 900, maxw=1000)
        T(c, pl, 84, 540, 405 + dy, C["ink"], a, 1.0, 900, maxw=1010)
    else:
        T(c, pl, 92, 540, 330 + dy, C["ink"], a, 1.0, 900, maxw=1010)

# ------------------------------------------------------------------ scenes
def sc_hook(c, t, S):
    # frame 0: the number and the claim; motion: map pulses + a running clock by 1.5 s
    T(c, "Binance, 29 Oct 2026", 52, 540, 330, C["sky"], 1.0, 1.0, 800, maxw=1000)
    x, y, _ = to_screen(103.8, 1.35, t)
    for k in range(4):   # world-wide red pulses (Binance has no single HQ)
        ph = (t * 0.5 + k / 4) % 1.0; xx, yy, _ = to_screen([-74, 0, 55, 114][k], [40.7, 51.5, 25.2, 22.3][k], t)
        c.new_sub_path(); c.arc(xx, yy, 14 + 120 * ph, 0, 2 * math.pi); sa(c, C["red"], 0.6 * (1 - ph)); c.set_line_width(6); c.stroke()
        circ(c, xx, yy, 13, C["red"], 1.0)
    br = 1 + 0.015 * math.sin(t * 2.4)
    T(c, "$6.3 BILLION", 186, 540 + 4, 1170 + 8, C["night"], 0.8, br, 900, maxw=1010)
    T(c, "$6.3 BILLION", 186, 540, 1170, C["gold"], 1.0, br, 900, maxw=1010)
    T(c, "stolen in 20 minutes", 100, 540, 1330, C["ink"], 1.0, 1.0, 900, maxw=1010)
    m = min(20.0, max(0.0, t - 0.2) * 12); mm = int(m); ss = int((m - mm) * 60)
    pill(c, f"{mm:02d}:{ss:02d}", 52, 540, 1050, C["red"], C["ink"], 1.0, 1.0)
    src(c, t, S)

def sc_info(c, t, S):
    tm = S["times"]
    for k, it in enumerate(S["items"]):
        t0 = tm.get(f"i{k}", S["t0"] + 0.2 + 0.8 * k)
        if t < t0 - 0.05: continue
        a, s = kit.pop(t, t0, 0.4, 0.4, 1.4)
        y = it.get("y", 1150 + 150 * k)
        if it.get("pill"): pill(c, it["en"], it.get("size", 70), 540, y, C[it.get("bg", "gold")], C["night"], a, s)
        else: block(c, it["en"], it.get("size", 110), 540, y, C[it.get("color", "ink")], a, s, 900, hl=C["gold"], maxw=1010, max_lines=2)
    if S.get("place"): header(c, t, S)
    if S.get("pulse"):
        for k in range(4):
            ph = (t * 0.5 + k / 4) % 1.0; xx, yy, _ = to_screen([-74, 0, 55, 114][k], [40.7, 51.5, 25.2, 22.3][k], t)
            c.new_sub_path(); c.arc(xx, yy, 14 + 120 * ph, 0, 2 * math.pi); sa(c, C["red"], 0.6 * (1 - ph)); c.set_line_width(6); c.stroke()
            circ(c, xx, yy, 13, C["red"], 1.0)
    src(c, t, S)

def sc_entry(c, t, S):
    header(c, t, S); tm = S["times"]
    a = ramp(t, S["t0"] + 0.1, S["t0"] + 0.35)
    if S.get("what"): T(c, S["what"], 64, 540, MY1 + 52, C["sky"], a, 1.0, 800, maxw=1000)
    T(c, "in 2026 dollars", 40, 540, VY + VR + 26, C["ink"], a, 1.0, 700, maxw=600)
    if S.get("online"):   # no city: a ring of network nodes over the map
        cx, cy, R = 540, MCY, 170
        for k in range(7):
            an = k * 2 * math.pi / 7 + t * 0.3; x1, y1 = cx + R * math.cos(an), cy + R * 0.7 * math.sin(an)
            an2 = (k + 3) * 2 * math.pi / 7 + t * 0.3; x2, y2 = cx + R * math.cos(an2), cy + R * 0.7 * math.sin(an2)
            sa(c, C["sky"], 0.6 * a); c.set_line_width(4); c.move_to(x1, y1); c.line_to(x2, y2); c.stroke()
        for k in range(7):
            an = k * 2 * math.pi / 7 + t * 0.3; circ(c, cx + R * math.cos(an), cy + R * 0.7 * math.sin(an), 16, C["gold"], a)
        T(c, "online", 64, cx, cy, C["ink"], a, 1.0, 800, maxw=400)
    tv = tm.get("v", S["t0"] + 1.0)
    vault(c, t, S["t0"] + 0.75, S.get("from", 0), S["value"], None, S.get("big", 1.0), t_land=tv + 0.35)
    if S.get("stamp"):
        stamp(c, t, tm.get("st", tv + 0.5), S["stamp"], C[S.get("stamp_color", "red")], y=VY + 112, rot=-0.07)
    if S.get("note"):
        tn = tm.get("note", tv + 1.6)
        if t >= tn: pill(c, S["note"], 64, 540, MY1 + 55, C["navy2"], C["ink"], *kit.pop(t, tn, 0.4, 0.4, 1.4), outline=C["gold"])
    src(c, t, S)

def sc_outro(c, t, S):
    tm = S["times"]
    for k, it in enumerate(S["items"]):
        t0 = tm.get(f"i{k}", S["t0"] + 0.2 + 0.7 * k)
        if t < t0 - 0.05: continue
        a, s = kit.pop(t, t0, 0.35, 0.5, 1.4)
        T(c, it["en"], it.get("size", 130), 540, 1080 + 150 * k, C[it.get("color", "ink")], a, s, 900, maxw=1010)
