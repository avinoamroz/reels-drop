"""crime_punish engine (copy of mena_variants/engine.py + AGEROW number cells, BADGES, configurable END_Q): the lib_mena_rights_v4 (muslims_freest_v4) layout, generalised.
Criteria rows on the left, country flags as columns in groups, Israel revealed as a mystery card,
scoreboard, a stat card, circular lead-in ending, burned-in subtitles.
python3 engine.py --reel DIR [--frames t1,t2,...] [--out path.mp4]
(or env REEL_DIR when imported by mix_step.py). DIR holds cfg.py, timing.json, flags/, mix.m4a."""
import json, os, re, sys, subprocess, math, importlib.util
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ARGS = sys.argv[1:] if __name__ == "__main__" else []
D = ARGS[ARGS.index("--reel") + 1] if "--reel" in ARGS else os.environ["REEL_DIR"]
D = D.rstrip("/")
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"
NAVY, NAVY2, PANEL, BLUE, GOLD, SILVER, WHITE = "#163260", "#0C1E3E", "#1D3E73", "#2A88D4", "#D2AA53", "#C9D1DC", "#FFFFFF"
GREEN, RED, AMBER, DRED, GREY, YELLOW = "#2FB36B", "#E0453A", "#F2B33D", "#A3142A", "#6B7A90", "#FFD54A"
_fc = {}
def F(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def hexa(c, a=255):
    c = c.lstrip("#"); return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), int(max(0, min(255, a))))
def ease(x): x = min(1, max(0, x)); return 1 - (1 - x) ** 3
def back(x):
    x = min(1, max(0, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def clamp(x): return min(1, max(0, x))

# ------------------------------------------------------------------ timing
T = json.load(open(f"{D}/timing.json")); LINES = T["lines"]; VO_END = LINES[-1]["t1"]
END = round(VO_END + 0.35, 2)
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]) == norm(word)]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]

spec = importlib.util.spec_from_file_location("cfg", f"{D}/cfg.py"); cfgm = importlib.util.module_from_spec(spec); spec.loader.exec_module(cfgm)
C = cfgm.build(wt, lt, LINES)
CC, TAB, LABELS, NS = C["CC"], C["TAB"], C["LABELS"], C["NSCORED"]
NUMROW = C.get("NUMROW")            # optional: dict country -> text, shown as the last row, unscored
NR = len(LABELS)
SCORE = {c: sum(v == "V" for v in r[:NS]) for c, r in TAB.items()}
assert SCORE == C["EXPECT"], SCORE
NAMES = {"Saudi Arabia": ("Saudi", "Arabia")}

# ------------------------------------------------------------------ layout
X0 = 60
CX0, CW = 400, 130
TITLE_Y = 196
FLAG_Y, FLAGW = 262, 118
NAME_Y = 372
RY0 = 452; RH = C.get("RH", 128)
SC_Y = RY0 + RH * NR + 8
SRC_Y = SC_Y + 102
SUB_BOTTOM = 1610
def cx(j): return CX0 + CW * j + CW // 2
def ry(i): return RY0 + RH * i

def load_flag(code, w):
    im = Image.open(f"{D}/flags/{code}.png").convert("RGBA"); h = round(im.height * w / im.width)
    return im.resize((w, h), Image.LANCZOS)
FLAG = {c: load_flag(k, FLAGW) for c, k in CC.items()}
FLAG_SB = {c: load_flag(k, 104) for c, k in CC.items()}
def qcard(w):
    h = round(w * 0.74); S = 4; im = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w * S - 1, h * S - 1), 14 * S, fill=hexa(GOLD)); im = im.resize((w, h), Image.LANCZOS); d = ImageDraw.Draw(im)
    d.text((w / 2, h / 2 + 2), "?", font=F(int(h * 0.8), 900), fill=hexa(NAVY), anchor="mm"); return im
QCARD = qcard(FLAGW)

_icon = {}
def icon(kind, scale=1.0):
    q = round(scale * 20) / 20; key = (kind, q)
    if key in _icon: return _icon[key]
    S = 4; R = 46; sz = int(150 * q) + 4
    im = Image.new("RGBA", (sz * S, sz * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = sz * S / 2; r = R * q * S
    if kind == "D":
        bw, bh = 62 * q * S, 32 * q * S
        d.rounded_rectangle((c - bw, c - bh, c + bw, c + bh), 12 * q * S, fill=hexa(DRED), outline=hexa("#FF6B6B"), width=max(1, int(3 * q * S)))
        im = im.resize((sz, sz), Image.LANCZOS); d = ImageDraw.Draw(im)
        if q > 0.3: d.text((sz / 2, sz / 2 + 1), "DEATH", font=F(max(8, int(36 * q)), 900), fill=hexa(WHITE), anchor="mm")
        _icon[key] = im; return im
    col = {"V": GREEN, "X": RED, "~": AMBER, "?": GREY}[kind]
    d.ellipse((c - r, c - r, c + r, c + r), fill=hexa(col))
    lw = max(1, int(9 * q * S))
    if kind == "V": d.line([(c - 0.42 * r, c + 0.02 * r), (c - 0.12 * r, c + 0.33 * r), (c + 0.45 * r, c - 0.33 * r)], fill=hexa(WHITE), width=lw, joint="curve")
    elif kind == "X":
        k = 0.34 * r; d.line([(c - k, c - k), (c + k, c + k)], fill=hexa(WHITE), width=lw); d.line([(c - k, c + k), (c + k, c - k)], fill=hexa(WHITE), width=lw)
    elif kind == "~":
        d.rounded_rectangle((c - 0.42 * r, c - 0.09 * r, c + 0.42 * r, c + 0.09 * r), 0.09 * r, fill=hexa(WHITE))
    im = im.resize((sz, sz), Image.LANCZOS)
    if kind == "?" and q > 0.3:
        ImageDraw.Draw(im).text((sz / 2, sz / 2 + 2), "?", font=F(max(8, int(62 * q)), 900), fill=hexa(WHITE), anchor="mm")
    _icon[key] = im; return im

def disc(kind, q):
    key = ("disc", kind, round(q * 20) / 20)
    if key in _icon: return _icon[key]
    S = 4; sz = int(150 * q) + 4; r = 46 * q * S; c = sz * S / 2
    im = Image.new("RGBA", (sz * S, sz * S), (0, 0, 0, 0)); ImageDraw.Draw(im).ellipse((c - r, c - r, c + r, c + r), fill=hexa(GREEN if kind == "V" else RED))
    im = im.resize((sz, sz), Image.LANCZOS); _icon[key] = im; return im
def paste_c(base, im, x, y, alpha=1.0):
    if alpha <= 0.01: return
    if alpha < 0.999:
        im = im.copy(); a = im.getchannel("A").point(lambda v: int(v * alpha)); im.putalpha(a)
    pos = (int(round(x - im.width / 2)), int(round(y - im.height / 2)))
    if base.mode == "RGBA": base.alpha_composite(im, pos)
    else: base.paste(im, pos, im)
def lay(base, L): base.paste(L, (0, 0), L)
class _AD:
    """ImageDraw wrapper: Pillow 12.3 draws text opaque whatever the fill alpha, so text with alpha < 255 is drawn on a
    small layer and composited with that alpha. Everything else goes straight to ImageDraw (shapes blend correctly)."""
    def __init__(self, base): self.base = base; self.d = ImageDraw.Draw(base, "RGBA")
    def __getattr__(self, k): return getattr(self.d, k)
    def text(self, xy, txt, font=None, fill=None, anchor=None, **kw):
        al = fill[3] if (isinstance(fill, tuple) and len(fill) == 4) else 255
        if al >= 255: return self.d.text(xy, txt, font=font, fill=fill, anchor=anchor, **kw)
        if al <= 1: return
        x0, y0, x1, y1 = [int(v) for v in self.d.textbbox(xy, txt, font=font, anchor=anchor)]
        x0 -= 2; y0 -= 2; x1 += 2; y1 += 2
        if x1 <= x0 or y1 <= y0: return
        L = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0))
        ImageDraw.Draw(L).text((xy[0] - x0, xy[1] - y0), txt, font=font, fill=fill[:3] + (255,), anchor=anchor, **kw)
        L.putalpha(L.getchannel("A").point(lambda v: v * al // 255))
        if self.base.mode == "RGBA": self.base.alpha_composite(L, (x0, y0))
        else: self.base.paste(L, (x0, y0), L)
def DR(base): return _AD(base)

def make_bg():
    y = np.linspace(0, 1, H)[:, None]; x = np.linspace(-1, 1, W)[None, :]
    a, b = np.array(hexa(NAVY)[:3], float), np.array(hexa(NAVY2)[:3], float)
    t = np.clip(0.25 + 0.75 * y + 0.12 * x ** 2, 0, 1)[..., None]
    return Image.fromarray((a * (1 - t) + b * t).astype(np.uint8), "RGB")
BG = make_bg()

def table_skeleton():
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i in range(NR):
        if i % 2 == 0: d.rectangle((X0 - 10, ry(i), 1020, ry(i) + RH - 1), fill=hexa("#FFFFFF", 14))
    if NUMROW: d.line((X0 - 10, ry(NR - 1) - 1, 1020, ry(NR - 1) - 1), fill=hexa(SILVER, 90), width=2)
    d.line((CX0 - 6, FLAG_Y - 10, CX0 - 6, SC_Y + 84), fill=hexa(SILVER, 70), width=2)
    d.line((X0 - 10, SC_Y - 2, 1020, SC_Y - 2), fill=hexa(GOLD, 160), width=3)
    return im
SKEL = table_skeleton()

def draw_labels(base, lit):
    d = DR(base); sz = C.get("LABEL_SZ", 56); gap = C.get("LABEL_GAP", 30)
    for i, (a, b) in enumerate(LABELS):
        k = lit[i]
        if k > 0: d.rectangle((X0 - 10, ry(i) + 10, X0 - 4, ry(i) + RH - 10), fill=hexa(GOLD, int(255 * k)))
        col = hexa(YELLOW if (NUMROW and i == NR - 1) else WHITE, int(110 + 145 * k)); y = ry(i) + RH / 2
        d.text((X0 + 6, y - gap), a, font=F(sz, 800), fill=col, anchor="lm")
        d.text((X0 + 6, y + gap), b, font=F(sz, 800), fill=col, anchor="lm")
    d.text((X0 + 6, SC_Y + 42), f"Score /{NS}", font=F(60, 900), fill=hexa(GOLD), anchor="lm")

def draw_sources(base, a=1.0, lines=None):
    d = DR(base); c = hexa(SILVER, int(235 * a))
    for n, s in enumerate(lines or C["SRC"]):
        d.text((X0, SRC_Y + 16 + 44 * n), s, font=F(36, 700), fill=c, anchor="lm")

def draw_title(base, txt, a=1.0, y=TITLE_Y, sz=60, col=GOLD):
    DR(base).text((X0, y), txt, font=F(sz, 900), fill=hexa(col, int(255 * a)), anchor="lm")

G = C["G"]; ORDER = C["ORDER"]
SLIDE = 0.4
T_TABLE = lt(1) - 0.25
T_ISR = C["T_ISR"]; T_SB = C["T_SB"]; T_STAT = C["T_STAT"]; T_Q = C["T_Q"]
MYST = C.get("MYSTERY", {"Israel": T_ISR})   # country -> reveal time

def group_layer(g, t):
    Lr = Image.new("RGBA", (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(Lr)
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L); st = g.get("stagger", 0.13)
    for j, c in enumerate(g["cols"]):
        x = cx(j); tf = g["fill"][c]; active = tf - 0.3 <= t <= tf + 2.6 and tf > 0
        if c == "Israel" or active:
            hl = clamp((t - (tf - 0.3)) / 0.25) if c != "Israel" else clamp((t - T_ISR) / 0.3)
            if c != "Israel": hl *= clamp((tf + 2.6 - t) / 0.4)
            if hl > 0:
                col = hexa(GOLD, int(255 * hl)) if c == "Israel" else hexa(BLUE, int(200 * hl))
                fillc = hexa(GOLD, int(34 * hl)) if c == "Israel" else hexa(BLUE, int(40 * hl))
                dr.rounded_rectangle((x - CW / 2 + 4, FLAG_Y - 14, x + CW / 2 - 4, SC_Y + 82), 18, fill=fillc, outline=col, width=4)
        tm = MYST.get(c) if c in g.get("mystery", []) else None
        if tm is not None and t < tm:
            paste_c(L, QCARD, x, FLAG_Y + 44 + 4 * math.sin(t * 6 + j))
            d.text((x, NAME_Y + 16), "?", font=F(40, 900), fill=hexa(GOLD), anchor="mm")
        else:
            fl = FLAG[c]
            if tm is not None:
                k = clamp((t - tm) / 0.3); s = max(0.05, abs(math.cos(math.pi * (1 - k) / 2)))
                fl = fl.resize((max(2, int(fl.width * s)), fl.height), Image.LANCZOS) if k < 1 else fl
            paste_c(L, fl, x, FLAG_Y + 44)
            nm = NAMES.get(c); ncol = hexa(GOLD) if c == "Israel" else hexa(WHITE)
            if nm:
                d.text((x, NAME_Y + 2), nm[0], font=F(36, 800), fill=ncol, anchor="mm"); d.text((x, NAME_Y + 38), nm[1], font=F(36, 800), fill=ncol, anchor="mm")
            else: d.text((x, NAME_Y + 16), c, font=F(36, 800), fill=ncol, anchor="mm")
        for i, v in enumerate(TAB[c]):
            t0 = tf + st * i; k = (t - t0) / 0.28
            if tf < 0: k = 1
            if k <= 0: continue
            s = back(k)
            for (pc, pi, pt) in g.get("pulse", []):
                if pc == c and pi == i and pt - 0.05 < t < pt + 0.75: s *= 1 + 0.28 * math.sin(math.pi * clamp((t - pt + 0.05) / 0.8))
            if C.get("AGEROW") is not None and i == C["AGEROW"]:
                q = max(0.05, s * C.get("ICON", 1.0)); paste_c(L, disc("V" if v == "V" else "X", q), x, ry(i) + RH / 2)
                if q > 0.3: d.text((x, ry(i) + RH / 2 + 2), C["AGES"][c], font=F(int(50 * q), 900), fill=hexa(WHITE), anchor="mm")
            elif NUMROW and i == NR - 1:
                d.text((x, ry(i) + RH / 2), NUMROW[c], font=F(int(50 * max(0.2, s)), 900), fill=hexa(YELLOW), anchor="mm")
            else:
                paste_c(L, icon(v, max(0.05, s * C.get("ICON", 1.0))), x, ry(i) + RH / 2)
        ts = g["score"][c]; k = 1 if ts < 0 else (t - ts) / 0.3
        if k > 0:
            fz = int(58 * max(0.2, back(k)))
            d.text((x, SC_Y + 42), f"{SCORE[c]}/{NS}", font=F(fz, 900), fill=hexa(GOLD if c == "Israel" else WHITE), anchor="mm")
    Lr.alpha_composite(L); return Lr

def table_phase(base, t):
    a = clamp((t - T_TABLE) / 0.35)
    if a <= 0: return
    paste_c(base, SKEL, W / 2, H / 2, a)
    lit = [0.0] * NR; tA = G[ORDER[0]]["t_in"]
    for i, rt in enumerate(C["ROWT"]):
        on = clamp((t - rt + 0.1) / 0.25)
        lit[i] = on * (1.0 if t < tA else 0.55)
        if rt - 0.1 < t < rt + 1.3:
            k = clamp((t - rt + 0.1) / 0.2) * clamp((rt + 1.3 - t) / 0.3)
            DR(base).rectangle((X0 - 10, ry(i), 1020, ry(i) + RH - 1), fill=hexa(BLUE, int(70 * k)))
    if t >= tA: lit = [max(l, 0.85) for l in lit]
    draw_labels(base, lit)
    if t < tA + SLIDE:          # flag carousel before the first group
        k_out = clamp((t - tA) / SLIDE)
        car = Image.new("RGBA", (W, H), (0, 0, 0, 0)); seq = [c for c in CC if c != "Israel"] + ["?"]
        step = 150; off = (t * 70) % (step * len(seq))
        for n in range(-1, len(seq) * 2):
            c = seq[n % len(seq)]; x = CX0 + 60 + n * step - off
            if -200 < x < W + 200: paste_c(car, QCARD if c == "?" else FLAG[c], x, FLAG_Y + 44)
        ImageDraw.Draw(car).text((710, NAME_Y + 16), "11 countries", font=F(40, 800), fill=hexa(SILVER), anchor="mm")
        mask = Image.new("L", (W, H), 0); ImageDraw.Draw(mask).rectangle((CX0, 0, 1020, H), fill=255)
        car.putalpha(Image.fromarray((np.array(car.getchannel("A"), float) * np.array(mask, float) / 255 * (1 - k_out) * a).astype(np.uint8)))
        lay(base, car)
    for n, gk in enumerate(ORDER):
        g = G[gk]; t_in = g["t_in"]; t_out = G[ORDER[n + 1]]["t_in"] if n + 1 < len(ORDER) else 1e9
        if t < t_in or t > t_out + SLIDE: continue
        dx = 0
        if t < t_in + SLIDE: dx = (1 - ease((t - t_in) / SLIDE)) * 700
        if t > t_out: dx = -ease((t - t_out) / SLIDE) * 700
        L = group_layer(g, t)
        if dx:
            L2 = Image.new("RGBA", (W, H), (0, 0, 0, 0)); L2.alpha_composite(L, (int(dx), 0)); L = L2
        al = np.array(L.getchannel("A")); al[:, :CX0 - 4] = 0; L.putalpha(Image.fromarray(al))
        lay(base, L)
    draw_sources(base, a)
    badges(base, t)

BADGE_Y = C.get("BADGE_Y", 1350)
def badges(base, t):
    for (b0, b1, title, src) in C.get("BADGES", []):
        if not (b0 - 0.05 < t < b1 + 0.3): continue
        k = ease((t - b0) / 0.3) * clamp((b1 + 0.3 - t) / 0.3)
        d = DR(base); y = BADGE_Y + (1 - k) * 40; tf = F(50, 900); sf = F(36, 700)
        w = max(tf.getlength(title), sf.getlength(src)) + 64; x0 = 540 - w / 2
        d.rounded_rectangle((x0, y, x0 + w, y + 132), 26, fill=hexa(DRED, int(245 * k)), outline=hexa("#FF6B6B", int(255 * k)), width=4)
        d.text((540, y + 46), title, font=tf, fill=hexa(WHITE, int(255 * k)), anchor="mm")
        d.text((540, y + 100), src, font=sf, fill=hexa("#FFD9D9", int(255 * k)), anchor="mm")

def sort_key(c): return (-SCORE[c], -C.get("TIEBREAK", {}).get(c, 0), list(TAB).index(c))
SB_ORDER = sorted(TAB, key=sort_key)
def scoreboard(base, t):
    a = clamp((t - T_SB) / 0.3) * (1 - clamp((t - T_STAT) / 0.3))
    if a <= 0: return
    d = DR(base)
    d.rectangle((0, 0, W, H), fill=hexa(NAVY2, int(255 * a)))
    d.text((X0, 200), C["SB_TITLE"], font=F(72, 900), fill=hexa(GOLD, int(255 * a)), anchor="lm")
    y0, rh = 270, 96
    if C.get("SB_COL"): d.text((1010, 200), C["SB_COL"], font=F(40, 800), fill=hexa(YELLOW, int(255 * a)), anchor="rm")
    for n, c in enumerate(SB_ORDER):
        k = ease((t - T_SB - 0.07 * n) / 0.35) * a
        if k <= 0: continue
        y = y0 + rh * n + rh / 2; xo = (1 - k) * 120
        hi = C.get("SB_HI", {}).get(c)
        if c == "Israel" or hi is not None:
            p = clamp((t - (hi if hi is not None else T_SB + 0.6)) / 0.3)
            col = GOLD if c == "Israel" else BLUE
            d.rounded_rectangle((X0 - 14 + xo, y - rh / 2 + 6, 1020 + xo, y + rh / 2 - 6), 18, fill=hexa(col, int((30 + 60 * p) * k)), outline=hexa(col, int(255 * k * (0.4 + 0.6 * p))), width=4)
        paste_c(base, FLAG_SB[c], X0 + 56 + xo, y, k)
        d.text((X0 + 128 + xo, y), c, font=F(52, 800), fill=hexa(GOLD if c == "Israel" else WHITE, int(255 * k)), anchor="lm")
        px0 = 545 if not C.get("SB_COL") else 515
        for p_ in range(NS):
            px = px0 + p_ * 38 + xo; on = p_ < SCORE[c]
            d.ellipse((px - 13, y - 13, px + 13, y + 13), fill=hexa(GOLD if (on and c == "Israel") else (GREEN if on else "#FFFFFF"), int((255 if on else 40) * k)))
        sx = 880 if C.get("SB_COL") else 990
        d.text((sx + xo, y), str(SCORE[c]), font=F(58, 900), fill=hexa(GOLD if c == "Israel" else WHITE, int(255 * k)), anchor="rm")
        if C.get("SB_COL"):
            d.text((1010 + xo, y), NUMROW[c], font=F(44, 900), fill=hexa(YELLOW, int(255 * k)), anchor="rm")
    for n_, s in enumerate(C["SB_SRC"]):
        d.text((X0, 1350 + 44 * n_), s, font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")

HOOK = C["HOOK"]
def text_lines(base, lines, a, y0, sz):
    d = DR(base); y = y0
    for ln in lines:
        x = X0
        for s_, c in [(ln[i], ln[i + 1]) for i in range(0, len(ln), 2)]:
            d.text((x, y), s_, font=F(sz, 900), fill=hexa(c, int(255 * a)), anchor="ls"); x += F(sz, 900).getlength(s_)
        y += int(sz * 1.12)

def carousel(base, t_off, a):
    seq = [c for c in CC if c != "Israel"] + ["?"]; step = 180; off = t_off % (step * len(seq))
    for n in range(-1, len(seq) * 2):
        c = seq[n % len(seq)]; x = 40 + n * step - off
        if -200 < x < W + 200: paste_c(base, QCARD if c == "?" else FLAG[c], x, 1040, a)

def hook_phase(base, t):
    if t >= T_TABLE + 0.4: return
    a = 1 - clamp((t - T_TABLE) / 0.35)
    text_lines(base, HOOK, a, 500, 116 + 3 * ease(t / 2.6))
    carousel(base, t * 160 + 60, a)
    DR(base).text((X0, 1210), C["COUNT_LINE"], font=F(58, 800), fill=hexa(SILVER, int(255 * a * clamp((t - lt(1) + 0.1) / 0.25))), anchor="lm")

def title_phase(base, t):
    a = clamp((t - T_TABLE) / 0.35) * (1 - clamp((t - T_SB) / 0.3))
    if a > 0: draw_title(base, C["TITLE"], a)

END_Q = C.get("END_Q", [("So…", WHITE), ("next time", WHITE), ("people ask ", WHITE, "you?", GOLD)])
def question_phase(base, t):
    a = clamp((t - T_Q) / 0.3)
    if a <= 0: return
    base.paste(Image.blend(base, BG, a))
    text_lines(base, END_Q, a, 500, 116)
    carousel(base, 60 - (END - t) * 160, a)     # phase-locked: last frame scrolls straight into frame 0

def frame(t):
    base = BG.copy()
    hook_phase(base, t)
    if t >= T_TABLE: table_phase(base, t); title_phase(base, t)
    scoreboard(base, t)
    if T_STAT - 0.4 <= t < T_Q + 0.5: C["stat_card"](base, t, globals())
    question_phase(base, t)
    subs(base, t)
    return base

# ------------------------------------------------------------------ subtitles (burned in; hook and lead-in are already on screen as big type)
SUBF = F(54, 800)
SUB_ITEMS = []
for li, chunks in C["SUBS"].items():
    ws = LINES[li]["words"]; i = 0
    assert sum(n for n, _ in chunks) == len(ws), (li, sum(n for n, _ in chunks), len(ws))
    for n, txt in chunks:
        SUB_ITEMS.append((ws[i]["t0"] - 0.05, ws[i + n - 1]["t1"] + 0.12, txt)); i += n
for k in range(len(SUB_ITEMS) - 1):     # no overlap, close tiny gaps
    a0, a1, tx = SUB_ITEMS[k]; b0 = SUB_ITEMS[k + 1][0]
    SUB_ITEMS[k] = (a0, b0 if b0 - a1 < 0.25 else min(a1, b0), tx)
def wrap(txt, font, maxw):
    out, cur = [], ""
    for w_ in txt.split():
        tst = (cur + " " + w_).strip()
        if font.getlength(tst) <= maxw: cur = tst
        else: out.append(cur); cur = w_
    out.append(cur); return out
def subs(base, t):
    for a0, a1, txt in SUB_ITEMS:
        if a0 <= t < a1:
            ls = wrap(txt, SUBF, 900); lh = 66; bh = lh * len(ls) + 26
            wmax = max(SUBF.getlength(l) for l in ls) + 52
            d = DR(base); y0 = SUB_BOTTOM - bh
            d.rounded_rectangle((540 - wmax / 2, y0, 540 + wmax / 2, SUB_BOTTOM), 22, fill=(8, 16, 34, 205))
            for n, l in enumerate(ls): d.text((540, y0 + 13 + lh * n + lh / 2), l, font=SUBF, fill=hexa(WHITE), anchor="mm")
            return

if __name__ == "__main__":
    if "--frames" in ARGS:
        fr = ARGS[ARGS.index("--frames") + 1]; out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"
        os.makedirs(out, exist_ok=True)
        for s in fr.split(","): frame(float(s)).save(f"{out}/f_{float(s):06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
