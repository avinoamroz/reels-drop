"""crime_punish: Where in the Middle East would you rather get arrested? (sibling of lib_mena_rights_v4; sources in research.json)"""
WHITE, GOLD, NAVY2, SILVER, YELLOW, PANEL, SKY = "#FFFFFF", "#D2AA53", "#0C1E3E", "#C9D1DC", "#FFD54A", "#1D3E73", "#45A4DD"


def build(wt, lt, LINES):
    CC = {"Israel": "il", "Turkey": "tr", "Lebanon": "lb", "Jordan": "jo", "Egypt": "eg", "Iraq": "iq", "Saudi Arabia": "sa", "Iran": "ir",
          "UAE": "ae", "Qatar": "qa", "Yemen": "ye"}
    # rows (V = good): no amputation for theft in law | no flogging in law (GIEACPC) | no death penalty for drugs (HRI 2025)
    #                  | does not execute child offenders (law and documented practice) | no criminal liability under 12 (CRIN, national law)
    TAB = {
        "Israel":       ["V", "V", "V", "V", "V"],
        "Turkey":       ["V", "V", "V", "V", "V"],
        "Lebanon":      ["V", "V", "V", "V", "X"],
        "Jordan":       ["V", "V", "X", "V", "V"],
        "Egypt":        ["V", "V", "X", "V", "V"],
        "Iraq":         ["V", "V", "X", "V", "X"],
        "Saudi Arabia": ["X", "X", "X", "X", "X"],
        "Iran":         ["X", "X", "X", "X", "X"],
        "UAE":          ["~", "X", "X", "V", "X"],
        "Qatar":        ["X", "X", "X", "V", "X"],
        "Yemen":        ["X", "X", "X", "X", "X"],
    }
    AGES = {"Israel": "12", "Turkey": "12", "Lebanon": "7", "Jordan": "12", "Egypt": "12", "Iraq": "9", "Saudi Arabia": "7", "Iran": "9",
            "UAE": "11", "Qatar": "7", "Yemen": "7"}
    EXPECT = {"Israel": 5, "Turkey": 5, "Lebanon": 4, "Jordan": 4, "Egypt": 4, "Iraq": 3, "Saudi Arabia": 0, "Iran": 0, "UAE": 1, "Qatar": 1, "Yemen": 0}
    LABELS = [("No", "amputation"), ("No", "flogging"), ("No death", "for drugs"), ("No child", "executions"), ("No trial", "under 12")]
    G = {}
    G["A"] = dict(cols=["Lebanon", "Jordan", "Egypt", "Iraq"], t_in=lt(4) - 0.45,
                  fill={"Lebanon": wt(4, "Lebanon"), "Jordan": wt(5, "Jordan"), "Egypt": wt(5, "Egypt"), "Iraq": wt(6, "Iraq")},
                  score={"Lebanon": wt(4, "four"), "Jordan": wt(5, "four"), "Egypt": wt(5, "each"), "Iraq": wt(6, "three")},
                  pulse=[("Lebanon", 4, wt(4, "seven")), ("Jordan", 2, wt(5, "execute")), ("Egypt", 2, wt(5, "execute"))], stagger=0.1)
    G["B"] = dict(cols=["UAE", "Qatar", "Saudi Arabia"], t_in=lt(7) - 0.45,
                  fill={"UAE": wt(7, "UAE"), "Qatar": wt(7, "Qatar"), "Saudi Arabia": wt(8, "Saudi")},
                  score={"UAE": wt(7, "one"), "Qatar": wt(7, "each"), "Saudi Arabia": wt(8, "zero")},
                  pulse=[("UAE", 1, wt(7, "flogging")), ("Qatar", 1, wt(7, "flogging")), ("Saudi Arabia", 3, wt(8, "sixteen"))], stagger=0.1)
    G["C"] = dict(cols=["Iran", "Yemen"], t_in=lt(9) - 0.45,
                  fill={"Iran": wt(9, "Iran"), "Yemen": wt(10, "Yemen")},
                  score={"Iran": wt(9, "zero"), "Yemen": wt(10, "zero")},
                  pulse=[("Iran", 0, wt(9, "fingers"))], stagger=0.1)
    T_TR, T_ISR = wt(12, "Turkey"), wt(13, "Israel")
    G["D"] = dict(cols=["Turkey", "Israel", "Lebanon", "Jordan"], t_in=lt(11) - 0.3,
                  fill={"Turkey": T_TR + 0.25, "Israel": T_ISR + 0.25, "Lebanon": -9, "Jordan": -9},
                  score={"Turkey": wt(12, "Five"), "Israel": wt(13, "Five"), "Lebanon": -9, "Jordan": -9}, mystery=["Turkey", "Israel"], stagger=0.09)
    ROWT = [wt(2, "amputation"), wt(2, "flogging"), wt(2, "death"), wt(3, "executing"), wt(3, "trial")]
    BADGES = [
        (wt(4, "But"), lt(5) - 0.2, "Lebanon: liable from age 7", "Law 422 of 2002, art. 3"),
        (wt(5, "Both"), lt(6) - 0.2, "Egypt, Jordan: death for drugs", "Harm Reduction International, 2025"),
        (wt(7, "Both"), lt(8) - 0.2, "UAE, Qatar: flogging is legal", "End Corporal Punishment, country reports"),
        (wt(8, "It"), lt(9) - 0.2, "Executed for crimes at 16, 17", "Saudi Arabia, Aug 2025. Amnesty"),
        (wt(9, "It"), lt(10) - 0.15, "4 fingers cut off for theft", "Iran, July 2025. HRW, KHRN"),
        (wt(10, "Yemen"), lt(11) - 0.1, "15 child offenders executed", "Yemen, 2007 to 2013. HRW"),
    ]

    def ch(li, *parts):          # parts: (spoken words, subtitle text)
        return [(len(sp.split()), tx) for sp, tx in parts]
    SUBS = {
        1: ch(1, ("Five questions. Eleven countries.", "5 questions. 11 countries.")),
        2: ch(2, ("No amputation for theft?", "No amputation for theft?"), ("No flogging? No death for drugs?", "No flogging? No death for drugs?")),
        3: ch(3, ("No executing child offenders?", "No executing child offenders?"), ("No trial under twelve?", "No trial under 12?")),
        4: ch(4, ("Lebanon, four out of five.", "Lebanon, 4 out of 5."), ("But a child of seven can be charged.", "But a child of 7 can be charged.")),
        5: ch(5, ("Jordan and Egypt, four each.", "Jordan and Egypt, 4 each."), ("Both can execute for drugs.", "Both can execute for drugs.")),
        6: ch(6, ("Iraq, three.", "Iraq, 3.")),
        7: ch(7, ("The UAE and Qatar, one each.", "The UAE and Qatar, 1 each."), ("Both still allow flogging.", "Both still allow flogging.")),
        8: ch(8, ("Saudi Arabia, zero.", "Saudi Arabia, 0."), ("It executed a man for crimes", "It executed a man for crimes"), ("at sixteen and seventeen.", "at 16 and 17.")),
        9: ch(9, ("Iran, zero.", "Iran, 0."), ("It cut four fingers off three men,", "It cut 4 fingers off 3 men,"), ("for theft.", "for theft.")),
        10: ch(10, ("Yemen, zero.", "Yemen, 0.")),
        11: ch(11, ("Two countries left.", "Two countries left.")),
        12: ch(12, ("Turkey. Five out of five.", "Turkey. 5 out of 5.")),
        13: ch(13, ("And Israel. Five out of five.", "And Israel. 5 out of 5.")),
        14: ch(14, ("The only two with a clean sheet.", "The only two with a clean sheet.")),
        15: ch(15, ("In Israel, kids face youth courts,", "In Israel, kids face youth courts,"), ("and no one under twenty-one", "and no one under 21"),
               ("is jailed without a probation report.", "is jailed without a probation report.")),
        16: ch(16, ("Not perfect either.", "Not perfect either."), ("UNICEF called ill-treatment", "UNICEF called ill-treatment"),
               ("of Palestinian kids", "of Palestinian kids"), ("in Israeli military detention systematic.", "in Israeli military detention systematic.")),
        17: ch(17, ("And this year, Israel passed", "And this year, Israel passed"), ("a death penalty for deadly terror attacks.", "a death penalty for deadly terror attacks.")),
    }
    T_FAIR = lt(16) - 0.15; T_F2 = lt(17) - 0.12
    t_yc, t_21, t_pr = wt(15, "youth"), wt(15, "twenty-one"), wt(15, "probation")

    def wrap(txt, font, maxw):
        out, cur = [], ""
        for w_ in txt.split():
            tst = (cur + " " + w_).strip()
            if font.getlength(tst) <= maxw: cur = tst
            else: out.append(cur); cur = w_
        out.append(cur); return out

    def stat_card(base, t, E):
        F, hexa, DR, clamp, ease, back, paste_c = E["F"], E["hexa"], E["DR"], E["clamp"], E["ease"], E["back"], E["paste_c"]
        T0, TQ = E["T_STAT"], E["T_Q"]
        a = clamp((t - T0) / 0.3) * (1 - clamp((t - TQ) / 0.3))
        if a <= 0: return
        d = DR(base); d.rectangle((0, 0, 1080, 1920), fill=hexa(NAVY2, int(255 * a)))
        # phase 1: Israel's youth justice (rehabilitation answer)
        a1 = a * (1 - clamp((t - T_FAIR) / 0.3))
        if a1 > 0:
            d.text((60, 330), "A second", font=F(116, 900), fill=hexa(WHITE, int(255 * a1)), anchor="ls")
            d.text((60, 455), "chance", font=F(116, 900), fill=hexa(GOLD, int(255 * a1)), anchor="ls")
            paste_c(base, E["FLAG"]["Israel"], 930, 360, a1)
            def row(y, big, txt, k, col):
                if k <= 0: return
                al = int(255 * a1 * clamp(k * 2)); xo = (1 - ease(k)) * 60
                d.text((60 + xo, y), big, font=F(int(120 * max(0.4, back(k))), 900), fill=hexa(col, al), anchor="ls")
                yy = y + 70
                for ln in wrap(txt, F(64, 800), 940):
                    d.text((60 + xo, yy), ln, font=F(64, 800), fill=hexa(WHITE, al), anchor="ls"); yy += 76
            row(650, "1971", "Youth courts, by law", clamp((t - t_yc + 0.1) / 0.35), SKY)
            row(960, "Under 21?", "No prison without a probation report", clamp((t - t_21 + 0.1) / 0.35), YELLOW)
            d.text((60, 1330), "Israel Youth Law 1971; Penal Law s. 38;", font=F(36, 700), fill=hexa(SILVER, int(230 * a1)), anchor="lm")
            d.text((60, 1374), "Israel Probation Service. Age of liability: 12.", font=F(36, 700), fill=hexa(SILVER, int(230 * a1)), anchor="lm")
        # phase 2: Not perfect either (same card as lib_mena_rights_v4)
        a2 = a * clamp((t - T_FAIR) / 0.3)
        if a2 > 0:
            X0 = 60; y0 = 520 - 30 * (1 - ease((t - T_FAIR) / 0.35))
            d.rounded_rectangle((X0 - 14, y0, 1020, y0 + 860), 28, fill=hexa(PANEL, int(250 * a2)), outline=hexa(GOLD, int(255 * a2)), width=4)
            d.text((X0 + 26, y0 + 70), "Not perfect either:", font=F(72, 900), fill=hexa(GOLD, int(255 * a2)), anchor="lm")
            BF, LH = F(64, 800), 78
            def ph(t0, t1): return clamp((t - t0) / 0.25) * (clamp((t1 - t) / 0.2) if t1 else 1) * a2
            def para(txt, y, al, col=WHITE, font=BF, lh=LH):
                for ln in wrap(txt, font, 900):
                    d.text((X0 + 26, y), ln, font=font, fill=hexa(col, int(255 * al)), anchor="lm"); y += lh
                return y
            b1 = ph(T_FAIR + 0.25, T_F2)
            if b1 > 0:
                y = para("UNICEF: ill-treatment of Palestinian kids in Israeli military detention is systematic.", y0 + 175, b1)
                para("About 700 children aged 12 to 17 are arrested each year.", y + 24, b1, SILVER, F(52, 700), 64)
                d.text((X0 + 26, y0 + 800), "Source: UNICEF, March 2013 report", font=F(36, 700), fill=hexa(SILVER, int(235 * b1)), anchor="lm")
            b2 = ph(T_F2, None)
            if b2 > 0:
                y = para("March 2026: Israel passed a death penalty for deadly terror attacks.", y0 + 175, b2)
                para("Challenged in the High Court. No one executed under it so far.", y + 24, b2, SILVER, F(52, 700), 64)
                d.text((X0 + 26, y0 + 800), "Source: Knesset, 30 March 2026", font=F(36, 700), fill=hexa(SILVER, int(235 * b2)), anchor="lm")

    return dict(CC=CC, TAB=TAB, AGES=AGES, AGEROW=4, EXPECT=EXPECT, LABELS=LABELS, NSCORED=5, RH=140, LABEL_SZ=52, LABEL_GAP=27, ICON=0.95,
                G=G, ORDER=["A", "B", "C", "D"], ROWT=ROWT, MYSTERY={"Turkey": T_TR, "Israel": T_ISR}, BADGES=BADGES, BADGE_Y=1352,
                T_ISR=T_ISR, T_SB=wt(13, "five", nth=1, end=True) + 0.3, T_STAT=lt(15) - 0.2, T_Q=lt(18) - 0.2,
                HOOK=[("Where would", WHITE), ("you rather get", WHITE), ("arrested?", GOLD)],
                END_Q=[("So…", WHITE), ("if you ever", WHITE), ("mess ", WHITE, "up?", GOLD)],
                COUNT_LINE="11 Middle East countries", TITLE="Best place to get arrested?",
                SRC=["GIEACPC, HRI 2025, Amnesty, HRW, CRIN,", "national laws. Amber = partly, no point."],
                SB_TITLE="Score out of 5", SB_HI={"Israel": wt(14, "two"), "Turkey": wt(14, "two")},
                SB_SRC=["Score = full yes answers. Sources in caption."],
                SUBS=SUBS, stat_card=stat_card)
