"""christians_freedom: Where are Christians safest in the Middle East? (variant of lib_mena_rights_v4)"""
WHITE, GOLD, NAVY2, SILVER, YELLOW, GREEN = "#FFFFFF", "#D2AA53", "#0C1E3E", "#C9D1DC", "#FFD54A", "#2FB36B"

def build(wt, lt, LINES):
    CC = {"Israel": "il", "Turkey": "tr", "Lebanon": "lb", "Jordan": "jo", "Egypt": "eg", "Iraq": "iq", "Saudi Arabia": "sa", "Iran": "ir",
          "UAE": "ae", "Qatar": "qa", "Yemen": "ye"}
    # rows: off Open Doors WWL 2026 top 50 | free to worship (Freedom House 2026 D2: 3-4 V, 2 ~, 0-1 X; Saudi FH 2025)
    #       | can leave majority religion (as lib_mena_rights_v4; D = death penalty in law) | a Christian can be head of state
    #       | Christians growing (Pew 2010 to 2020; Iraq: IHCHR since 2003; ? = no reliable data)
    TAB = {
        "Israel":       ["V", "V", "V", "V", "V"],
        "Turkey":       ["X", "~", "V", "V", "X"],
        "Lebanon":      ["V", "V", "V", "V", "X"],
        "Jordan":       ["X", "~", "~", "X", "V"],
        "Egypt":        ["X", "X", "~", "V", "V"],
        "Iraq":         ["X", "X", "~", "V", "X"],
        "Saudi Arabia": ["X", "X", "D", "X", "V"],
        "Iran":         ["X", "X", "D", "X", "?"],
        "UAE":          ["V", "~", "D", "X", "V"],
        "Qatar":        ["X", "~", "D", "X", "V"],
        "Yemen":        ["X", "X", "D", "X", "?"],
    }
    EXPECT = {"Israel": 5, "Turkey": 2, "Lebanon": 4, "Jordan": 1, "Egypt": 2, "Iraq": 1, "Saudi Arabia": 1, "Iran": 0, "UAE": 2, "Qatar": 1, "Yemen": 0}
    LABELS = [("Off the", "watch list"), ("Free to", "worship"), ("Can leave", "majority faith"), ("Christian", "head of state"), ("Christians", "growing")]
    G = {}
    G["A"] = dict(cols=["Lebanon", "Turkey", "Egypt", "Jordan"], t_in=lt(4) - 0.45,
                  fill={"Lebanon": wt(4, "Lebanon"), "Turkey": wt(5, "Turkey"), "Egypt": wt(6, "Egypt"), "Jordan": wt(6, "Jordan")},
                  score={"Lebanon": wt(4, "Four"), "Turkey": wt(5, "two"), "Egypt": wt(6, "two"), "Jordan": wt(6, "one")},
                  pulse=[("Lebanon", 4, wt(4, "shrinking")), ("Turkey", 1, wt(5, "church"))])
    G["B"] = dict(cols=["Iraq", "Saudi Arabia", "Iran"], t_in=lt(7) - 0.45,
                  fill={"Iraq": wt(7, "Iraq"), "Saudi Arabia": wt(8, "Saudi"), "Iran": wt(8, "Iran")},
                  score={"Iraq": wt(7, "one"), "Saudi Arabia": wt(8, "one"), "Iran": wt(8, "zero")},
                  pulse=[("Iraq", 4, wt(7, "Now")), ("Saudi Arabia", 2, wt(8, "death")), ("Iran", 2, wt(8, "death"))])
    G["C"] = dict(cols=["UAE", "Qatar", "Yemen"], t_in=lt(9) - 0.45,
                  fill={"UAE": wt(9, "UAE"), "Qatar": wt(9, "Qatar"), "Yemen": wt(9, "Yemen")},
                  score={"UAE": wt(9, "two"), "Qatar": wt(9, "one"), "Yemen": wt(9, "zero")},
                  pulse=[("UAE", 4, wt(9, "migrant")), ("Qatar", 4, wt(9, "migrant"))])
    T_ISR = wt(11, "Israel")
    G["D"] = dict(cols=["Israel", "Lebanon", "Turkey", "Egypt"], t_in=lt(10) - 0.3,
                  fill={"Israel": T_ISR + 0.25, "Lebanon": -9, "Turkey": -9, "Egypt": -9},
                  score={"Israel": wt(11, "Five"), "Lebanon": -9, "Turkey": -9, "Egypt": -9}, mystery=["Israel"], stagger=0.11)
    ROWT = [wt(2, "off"), wt(2, "free"), wt(2, "leave"), wt(3, "head"), wt(3, "growing")]
    SUBS = {
        1: [(4, "5 questions. 11 countries.")],
        2: [(7, "Is it off the persecution top 50?"), (5, "Are people free to worship?"), (6, "Can you leave the majority religion?")],
        3: [(7, "Can a Christian be head of state?"), (3, "Are Christians growing?")],
        4: [(5, "Lebanon. 4 out of 5."), (5, "But its Christians are shrinking.")],
        5: [(2, "Turkey, 2."), (8, "Its first new church in a hundred years"), (4, "opened in 2023.")],
        6: [(4, "Egypt, 2. Jordan, 1.")],
        7: [(2, "Iraq, 1."), (6, "1.5 million Christians"), (4, "before 2003."), (6, "Now, about 250,000.")],
        8: [(5, "Saudi Arabia, 1. Iran, 0."), (7, "Leaving the religion there can mean death.")],
        9: [(5, "The UAE, 2. Qatar, 1."), (6, "Their Christians are mostly migrant workers."), (2, "Yemen, 0.")],
        10: [(3, "One country left.")],
        11: [(5, "Israel. 5 out of 5.")],
        12: [(7, "The only full score on the board.")],
        13: [(3, "In 1949,"), (6, "34,000 Christians lived in Israel."), (7, "Today, about 185,000.")],
    }
    t_a, t_b = wt(13, "nineteen"), wt(13, "Today")
    t_b1 = wt(13, "thousand", nth=1, end=True)

    def stat_card(base, t, E):
        F, hexa, DR, clamp, ease, back, paste_c = E["F"], E["hexa"], E["DR"], E["clamp"], E["ease"], E["back"], E["paste_c"]
        T0, TQ = E["T_STAT"], E["T_Q"]
        a = clamp((t - T0) / 0.3) * (1 - clamp((t - TQ) / 0.3))
        if a <= 0: return
        d = DR(base); d.rectangle((0, 0, 1080, 1920), fill=hexa(NAVY2, int(255 * a)))
        d.text((60, 300), "Christians", font=F(110, 900), fill=hexa(WHITE, int(255 * a)), anchor="ls")
        d.text((60, 420), "in Israel", font=F(110, 900), fill=hexa(GOLD, int(255 * a)), anchor="ls")
        paste_c(base, E["FLAG"]["Israel"], 940, 330, a)
        X0, BW = 60, 940
        def bar(y, year, val, k, txt):
            if k <= 0: return
            d.text((X0, y), year, font=F(72, 900), fill=hexa(SILVER, int(255 * a * min(1, k * 3))), anchor="ls")
            w = BW * val / 185000 * ease(k)
            d.rounded_rectangle((X0, y + 30, X0 + max(24, w), y + 150), 26, fill=hexa(GOLD if year != "1949" else "#45A4DD", int(255 * a)))
            d.text((X0 + max(24, w) - 20 if w > 520 else X0 + max(24, w) + 24, y + 92), txt, font=F(96, 900),
                   fill=hexa("#0C1E3E" if w > 520 else WHITE, int(255 * a)), anchor="rm" if w > 520 else "lm")
        k1 = clamp((t - t_a + 0.1) / 0.6)
        bar(650, "1949", 34000, k1, "34,000")
        k2 = clamp((t - t_b + 0.1) / 1.6)
        v = 34000 + (185000 - 34000) * ease(k2)
        bar(960, "2025", v, clamp((t - t_b + 0.1) / 0.3) if k2 > 0 else 0, f"{int(round(v / 1000.0)) * 1000:,}" if k2 < 1 else "185,000")
        if t > t_b1 - 0.4:
            k3 = clamp((t - t_b1 + 0.4) / 0.35)
            d.text((60, 1300), "More than 5x", font=F(96, 900), fill=hexa("#FFD54A", int(255 * a * k3)), anchor="ls")
        d.text((60, 1400), "Source: Israel CBS (1949; Dec 2025, about 185,000)", font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")

    return dict(CC=CC, TAB=TAB, EXPECT=EXPECT, LABELS=LABELS, NSCORED=5, RH=160, LABEL_SZ=52, G=G, ORDER=["A", "B", "C", "D"], ROWT=ROWT,
                T_ISR=T_ISR, T_SB=wt(11, "five", nth=1, end=True) + 0.3, T_STAT=lt(13) - 0.2, T_Q=lt(14) - 0.2,
                HOOK=[("Where are", WHITE), ("Christians", GOLD), ("safest in the", WHITE), ("Middle East?", WHITE)],
                COUNT_LINE="5 questions. 11 countries.", TITLE="Where are Christians safest?",
                SRC=["Open Doors WWL 2026 top 50, Freedom House", "2026, Pew, constitutions. Amber or ? = no point."],
                SB_TITLE="Score out of 5", SB_SRC=["Score = full yes answers. Sources in caption."],
                SUBS=SUBS, stat_card=stat_card)
