"""philistines_short scenes (6 Nov 2026): the parent philistines_1102_v2 scenes (map, year counter, FACT CHECK chip) plus
- "icon" on any stage / photo / dzmap scene: an emoji picture for hard words (icon_xy, icon_px, icon_at mark)
- sc_split: two-row verdict card (Philistines vs Palestinians), row b revealed at mark "b"
- FACT CHECK chip takes a string ("FACT CHECK", "VERDICT") instead of n/4."""
exec(compile(open("/home/claude/philistines_1102_v2/scenes_pf.py").read(), "/home/claude/philistines_1102_v2/scenes_pf.py", "exec"))

def _icon(c, t, S):
    e = S.get("icon")
    if not e: return
    tk = S["times"].get(S.get("icon_at", ""), S["t0"] + 0.1)
    if S.get("hook"): tk = -1
    a, s = PP(t, tk, S, s0=0.5, bounce=1.5)
    x, y = S.get("icon_xy", (540, 1180))
    draw_emoji(c, e, x, y, S.get("icon_px", 230), a=a, sc=s)

for _n in ("stage", "photo", "dzmap"):
    def _mk(f):
        def g(c, t, S): f(c, t, S); _icon(c, t, S)
        return g
    globals()["sc_" + _n] = _mk(globals()["sc_" + _n])

def sc_split(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S)
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); _wtext(c, S["title"], 100, TOP + 60, a=a1, sc=s1, max_lines=1)
    rows = S["rows"]
    for k, r in enumerate(rows):
        tk = S["times"].get("b", t0 + 0.8) if k else t0 + 0.15
        a, s = PP(t, tk, S, s0=0.7, bounce=1.3)
        if a <= 0.01: continue
        y = 640 + 380 * k
        c.save(); c.translate(540, y); c.scale(s, s); c.translate(-540, -y)
        sa(c, INK, 0.70 * a); rr(c, 40, y - 165, 1000, 330, 40); c.fill()
        sa(c, kit.hx(r.get("color", "#45A4DD")), 0.95 * a); c.set_line_width(5); rr(c, 40, y - 165, 1000, 330, 40); c.stroke()
        draw_emoji(c, r["icon"], 175, y, 170, a=a)
        kit.tx(c, r["name"], 84, 620, y - 62, w=900, col=RD.c255(YEL), a=a, shadow=False, maxw=740)
        kit.tx(c, r["what"], 66, 620, y + 52, w=800, col=RD.c255(WHITE), a=a, shadow=False, maxw=740)
        c.restore()
    if S.get("verdict"):
        tk = S["times"].get("v", t0 + 1.2); a, s = PP(t, tk, S, s0=0.6, bounce=1.4)
        _wtext(c, S["verdict"], 96, 1330, a=a, sc=s, max_lines=1)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1418, la)

def _draw_top(self, c, t):
    _draw_top0(self, c, t)
    sc = self.scenes; i = _cur_scene(self, t); S = sc[i]
    keep = St.a; St.a = 1.0
    v = S.get("fc"); pv = sc[i - 1].get("fc") if i else None
    if v is not None: af = 1.0 if pv is not None else ramp(t, S["t0"], S["t0"] + 0.35)
    elif pv is not None: af = 1.0 - ramp(t, S["t0"], S["t0"] + 0.35); v = pv
    else: af = 0.0
    pop = kit.pop(t, S["t0"], 0.45, 0.6, 1.6)[1] if (v != pv and pv is not None and t >= S["t0"]) else 1.0
    y1 = S.get("yr"); y0 = sc[i - 1].get("yr", y1) if i else y1
    ry = S.get("yr_roll", 0.6)
    u = 1.0 if i == 0 else ease(min(1.0, max(0.0, (t - S["t0"]) / ry)))
    yv = y0 + (y1 - y0) * u if (y1 is not None and y0 is not None) else y1
    xy = lerp(540, 285, ease(af)); xf = lerp(1080 + 300, 790, ease(af))
    if yv is not None:
        s_ = _yfmt(yv); f = kit.font(58, 900); tw = max(f.getlength("8888 BCE"), f.getlength(s_))
        sa(c, INK, 0.78); rr(c, xy - tw / 2 - 34, 262 - 42, tw + 68, 84, 42); c.fill()
        sa(c, YEL, 0.95); c.set_line_width(3); rr(c, xy - tw / 2 - 34, 262 - 42, tw + 68, 84, 42); c.stroke()
        kit.tx(c, s_, 58, xy, 262, w=900, col=RD.c255(YEL), a=1.0, shadow=False, maxw=1000)
    if af > 0.01 and v is not None:
        s_ = str(v); f = kit.font(44, 900); tw = f.getlength(s_)
        c.save(); c.translate(xf, 262); c.scale(pop, pop); c.translate(-xf, -262)
        sa(c, INK, 0.78 * af); rr(c, xf - tw / 2 - 30, 262 - 42, tw + 60, 84, 42); c.fill()
        sa(c, SKY, 0.95 * af); c.set_line_width(3); rr(c, xf - tw / 2 - 30, 262 - 42, tw + 60, 84, 42); c.stroke()
        kit.tx(c, s_, 44, xf, 262, w=900, col=RD.c255(WHITE), a=af, shadow=False, maxw=1000)
        c.restore()
    St.a = keep
RD.Reel.draw = _draw_top
