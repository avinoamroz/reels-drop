exec(open("/home/claude/vid/cfg_pop.py").read())
SNAPDIR="/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/pop_snaps"
T_TOTAL=45.0; T_DATA=43.6; T_ENDC=44.2
TAG="pop_race_rehook"; OUT_EN="/home/claude/bangers_1102/pop_race_rehook/out/pop_race_rehook.mp4"; MUSIC="/home/claude/bangers_1102/pop_race_rehook/audio.m4a"
ROWS_EN=5
TL_EN=[(-1200,0),(0,13),(1800,25),(1948,32),(2026,40)]
HOOK_EN=["3,000 years.","Who never left?"]   # rehook 2 Nov (only the hook changes)
SUB_EN="From the Jordan to the sea"
SHORT_EN={"Greco-Roman pagans":"Roman-era pagans"}
COUNTER_EN="Total"
REVEAL_EN=(30.0,35.6,["Jews never left.","Lowest point: about 7,000"])
END_EN=["That's who lived","here for..."]
SRC_EN="Sources: scholarly estimates, censuses, CBS, PCBS"
MAP["legend_en"]="= 2,000 people"
SHARE_LINE_EN=["Send this to whoever","says \u201ccolonizers\u201d"]
T_SHARE=39.6
