"""mix2.py SILENT_MP4 OUT_MP4: place the three chained Hebrew VO parts at their offsets (timing.json), reelkit 'skip' bed ducked under the voice,
-14 LUFS / -1.5 dBTP (reelkit mix), video copied."""
import sys, json, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import mix as M
D = "/home/claude/fixes_1101/ex"; vid, out = sys.argv[1:3]; SR = M.SR
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", vid], capture_output=True, text=True).stdout)
off = json.load(open(f"{D}/timing.json"))["off"]; v = np.zeros(int(dur * SR) + SR)
for k, o in off.items():
    x, sr = sf.read(f"{D}/vo_{k}_chain.wav"); assert sr == SR
    i = int(o * SR); v[i:i + len(x)] += x[:len(v) - i]
mus = M.bed("skip", dur); wav = out + ".mix.wav"
M.mix(v[:int(dur * SR)], dur, mus, [], wav, music_db=-17.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", vid, "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                "-t", f"{dur:.3f}", "-movflags", "+faststart", out], check=True)
print("wrote", out)
