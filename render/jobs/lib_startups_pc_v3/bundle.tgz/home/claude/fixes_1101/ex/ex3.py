"""Who runs Express explainer v3 (1 Nov: English narration, Hebrew screen text, loop ending; copy of explain/v2/ex2.py)
v2 notes: Who runs Express explainer v2 (1080x1920, 30 fps): Hebrew voice-over (Cartesia, Noam's voice), real community sessions
from the past two weeks (Google Calendar, 13 to 22 Oct 2026, topics only, no names or faces), 7-minute fluency CTA.
Hook text on screen at frame 0, motion from frame 0 (slow push + animated underline).
usage: python3 ex2.py [--qa 0,1.5,14,22,30,38]   (full run writes /home/claude/explain/v2/ex2_silent.mp4)"""
import sys, json, math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont
D = "/home/claude/fixes_1101/ex"; W, H, FPS = 1080, 1920, 30; CX = 540
QA = [float(x) for x in sys.argv[sys.argv.index("--qa") + 1].split(",")] if "--qa" in sys.argv else None
FD = "/home/claude/vid/fonts"
def font(w, s): return ImageFont.truetype(f"{FD}/Heebo-{w}.ttf", int(s), layout_engine=ImageFont.Layout.RAQM)
NAVY = (14, 30, 58); BLUE = (39, 73, 211); SKY = (89, 165, 223); PALE = (201, 214, 238); GOLD = (255, 209, 102); WHITE = (255, 255, 255)
TJ = json.load(open(f"{D}/timing.json")); TOTAL = TJ["total"]
def wt(part, word, k=0):
    hits = [x["t"] for x in TJ["words"][part] if x["w"].strip(".,:?") == word]; return hits[k]
# background: navy to blue gradient with a slow drifting glow
yy = np.linspace(0, 1, H)[:, None, None]; BASE = np.array(NAVY, np.float32) * (1 - yy) + np.array(BLUE, np.float32) * yy * 0.85 + np.array(NAVY, np.float32) * yy * 0.15
XX, YY = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
def bg(t):
    gx = CX + 260 * math.sin(t * 0.35); gy = 700 + 300 * math.cos(t * 0.27)
    g = np.exp(-((XX - gx) ** 2 + (YY - gy) ** 2) / (2 * 380.0 ** 2))[..., None]
    x = BASE + g * np.array([40, 70, 120], np.float32) * 0.55
    return Image.fromarray(np.clip(x, 0, 255).astype(np.uint8))
LOGO = Image.open("/home/claude/explain/logo.png").convert("RGBA").resize((170, 170), Image.LANCZOS)
def ease(u): u = max(0.0, min(1.0, u)); return 1 - (1 - u) ** 3
def ap(t, t0, dur=0.35): return ease((t - t0) / dur)
class L:
    def __init__(s, t, im, d): s.t, s.im, s.d = t, im, d
    def text(s, y, txt, w, sz, col, t0=None, rise=40, maxw=960):
        a = 1.0 if t0 is None else ap(s.t, t0)
        if a <= 0: return
        f = font(w, sz)
        while s.d.textlength(txt, font=f, direction="rtl") > maxw and sz > 36: sz -= 2; f = font(w, sz)
        lay = Image.new("RGBA", (W, int(sz * 1.8)), (0, 0, 0, 0)); ImageDraw.Draw(lay).text((CX, lay.height // 2), txt, font=f, fill=col + (int(255 * a),), anchor="mm", direction="rtl" if any("֐" <= c <= "׿" for c in txt) else None)
        s.im.alpha_composite(lay, (0, int(y - lay.height / 2 + rise * (1 - a))))
    def bar(s, y, w, col, t0, dur=0.6):
        a = ap(s.t, t0, dur)
        if a > 0: s.d.rounded_rectangle((CX - w * a / 2, y - 5, CX + w * a / 2, y + 5), 5, fill=col + (255,))
    def row(s, y, date, kind, topic, en, t0):
        a = ap(s.t, t0, 0.4)
        if a <= 0: return
        dx = int(60 * (1 - a)); lay = Image.new("RGBA", (W, 220), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        d.rounded_rectangle((70, 8, 1010, 212), 26, fill=(255, 255, 255, int(34 * a)), outline=SKY + (int(200 * a),), width=3)
        d.rounded_rectangle((812, 30, 990, 90), 18, fill=SKY + (int(255 * a),))
        d.text((901, 60), date, font=font(800, 40), fill=NAVY + (int(255 * a),), anchor="mm")
        d.text((790, 60), kind, font=font(700, 38), fill=GOLD + (int(255 * a),), anchor="rm", direction="rtl" if any("֐" <= c <= "׿" for c in kind) else None)
        f = font(800, 46); sz = 46
        while d.textlength(topic, font=f, direction="rtl") > 900 and sz > 36: sz -= 2; f = font(800, sz)
        d.text((990, 125), topic, font=f, fill=WHITE + (int(255 * a),), anchor="rm", direction="rtl")
        d.text((990, 182), en, font=font(400, 36), fill=PALE + (int(230 * a),), anchor="rm")
        s.im.alpha_composite(lay, (-dx, int(y - 110)))
T_A2 = wt("a", "Our"); T_A3 = wt("a", "Not"); T_A4 = wt("a", "Every"); T_B = wt("b", "Just"); T_C = wt("c", "So"); T_C2 = wt("c", "That's")
T_C3 = wt("c", "Gradually"); T_CTA = wt("c", "Want"); T_D = wt("d", "So")
EX = [("13.10", "English Buddies", "המתמטיקה של הטניס", "The math of tennis", wt("b", "talk")),
      ("15.10", "Train of Thought", "יחסים במשפחה דרך השירים של אנקנטו", "Family, through Encanto songs", wt("b", "conversation")),
      ("15.10", "ראיון", "איזון בחיים", "Life alignment", wt("b", "interview")),
      ("22.10", "הרצאה", "שנה בסייבר ובבינה מלאכותית בישראל", "12 months of cyber and AI", wt("b", "review"))]
def frame(t):
    z = 1.0 + 0.03 * t / TOTAL
    im = bg(t).convert("RGBA"); d = ImageDraw.Draw(im); s = L(t, im, d)
    if t < T_A4 - 0.15:                                         # hook: on screen at frame 0
        s.text(700, "מי מוביל את המפגשים", 900, 92 * (1 + 0.01 * math.sin(t * 3)), SKY)
        s.text(820, "באקספרס?", 900, 104 * (1 + 0.01 * math.sin(t * 3)), SKY)
        s.bar(910, 420, GOLD, 0.0, 1.2)
        s.text(540, "רוב האנשים לא יודעים את זה, אבל...", 700, 50, PALE)
        s.text(1110, "המתאמנים שלנו.", 900, 120, WHITE, T_A2 - 0.1)
        s.text(1280, "לא מרצים. לא מורים.", 700, 62, PALE, T_A3 - 0.1)
        s.text(1370, "אנשים כמוכם.", 800, 70, GOLD, wt("a", "People") - 0.1)
    elif t < T_B - 0.15:
        s.text(820, "כל מתאמן מתרגל באנגלית", 800, 76, WHITE, T_A4 - 0.15)
        s.text(920, "בדיוק את מה שהוא", 800, 76, WHITE, T_A4)
        s.text(1035, "צריך בעבודה.", 900, 96, SKY, wt("a", "need") - 0.15)
        s.bar(1130, 360, GOLD, wt("a", "work") - 0.1)
    elif t < T_C - 0.15:
        s.text(420, "רק בשבועיים האחרונים", 900, 74, WHITE, T_B - 0.15, rise=20)
        s.text(505, "מפגשים שהובילו מתאמנים, למתאמנים", 700, 44, PALE, T_B + 0.2, rise=20)
        for i, (dt, k, tp, en, t0) in enumerate(EX): s.row(670 + i * 240, dt, k, tp, en, t0 - 0.15)
    elif t < T_CTA - 0.15:
        s.text(740, "אז איזו פגישה", 900, 104, SKY, T_C - 0.15)
        s.text(870, "אתם דוחים?", 900, 104, SKY, wt("c", "are") - 0.15)
        s.text(1060, "את זה בדיוק תתרגלו אצלנו.", 800, 64, WHITE, T_C2 - 0.15)
        s.text(1150, "באנגלית.", 800, 64, GOLD, wt("c", "English") - 0.15)
        s.text(1300, "בהדרגה. ממקום בטוח.", 900, 76, WHITE, T_C3 - 0.15)
    elif t < T_D - 0.15:
        s.text(600, "רוצים שטף?", 900, 120, GOLD, T_CTA - 0.15)
        s.text(780, "דברו עם עצמכם באנגלית", 800, 66, WHITE, wt("c", "Talk") - 0.15)
        s.text(870, "7 דקות, בוואטסאפ.", 800, 66, WHITE, wt("c", "seven") - 0.15)
        s.text(1000, "ואז הסבירו את אותו רעיון", 800, 66, SKY, wt("c", "Then") - 0.15)
        s.text(1090, "לחבר.", 800, 66, SKY, wt("c", "friend") - 0.2)
        a = ap(t, wt("c", "friend") + 0.2, 0.5)
        if a > 0:
            lg = LOGO.copy(); lg.putalpha(lg.getchannel("A").point(lambda v: int(v * a))); im.alpha_composite(lg, (CX - 85, 1200))
            s.text(1440, "Your best, In English.", 800, 54, WHITE, wt("c", "friend") + 0.3)
    else:   # 1 Nov: loop lead-in, Hebrew on screen ("So next time someone asks you...")
        s.text(820, "אז בפעם הבאה", 900, 104, SKY, T_D - 0.15)
        s.text(950, "שמישהו ישאל אתכם...", 900, 104, SKY, wt("d", "someone") - 0.15)
    if z != 1.0:
        cw, ch = W / z, H / z; im = im.resize((W, H), Image.BILINEAR, box=((W - cw) / 2, (H - ch) / 2, (W + cw) / 2, (H + ch) / 2))
    return im.convert("RGB")
if QA is not None:
    for q in QA: frame(q).save(f"{D}/qa_{q:05.1f}.png")
    sys.exit()
ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                       "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", f"{D}/ex2_silent.mp4"], stdin=subprocess.PIPE)
NF = int(round(TOTAL * FPS)); LX = int(0.5 * FPS); F0 = frame(0.0)
for f in range(NF):
    im = frame(f / FPS)
    if f >= NF - LX: im = Image.blend(im, F0, ease((f - (NF - LX) + 1) / LX))
    ff.stdin.write(im.tobytes())
ff.stdin.close(); ff.wait(); print("done", f"{D}/ex2_silent.mp4")
