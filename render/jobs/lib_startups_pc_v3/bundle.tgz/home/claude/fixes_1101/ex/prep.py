"""lib_explain v2 (1 Nov): English narration (Cartesia SSE takes ex_a..ex_d) through the house voice chain, laid out like the
Hebrew v2 (timing.json: off + final word times), so ex3.py keeps the Hebrew screen text on the English words."""
import sys, json
sys.path.insert(0, "/home/claude/reelkit")
import numpy as np, soundfile as sf
import voice
from clean_vo import clean as clean_vo
D = "/home/claude/fixes_1101/ex"; T = "/home/claude/fixes_1101/tts"
voice.TEMPO = 1.0; off = {}; words = {}; t = 0.3; GAPS = {"a": 0.55, "b": 0.55, "c": 1.4, "d": 0.0}
for k in "abcd":
    pre = f"{T}/ex_{k}"; W = json.load(open(pre + "_words.json"))
    dry = voice.chain_dry(pre + ".wav"); cl = clean_vo(dry, voice.SR)
    y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); vo = voice.post(y)
    kk = (len(vo) / voice.SR - voice.LEAD) / (len(dry) / voice.SR)
    # drop the chain's lead so the part starts at its offset
    lead = voice.LEAD; vo = vo[int(lead * voice.SR):]
    sf.write(f"{D}/vo_{k}_chain.wav", vo, voice.SR)
    off[k] = round(t, 3); words[k] = [dict(w=w["word"], t=round(t + w["start"] * kk, 3), t1=round(t + w["end"] * kk, 3)) for w in W]
    t += len(vo) / voice.SR + GAPS[k]
json.dump(dict(off=off, words=words, total=round(t + 0.7, 3)), open(f"{D}/timing.json", "w"), ensure_ascii=False, indent=0)
print("total", round(t + 0.7, 2), off, voice.SR)
