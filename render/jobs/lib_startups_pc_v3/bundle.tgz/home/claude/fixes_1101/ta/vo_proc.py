"""House voice chain on a Cartesia SSE take, split into pieces with word times.
usage: vo_proc.py name tempo piece:w0:w1 [piece:w0:w1 ...]   (w0, w1 = word indexes, inclusive)
in: vo/raw_<name>.wav + vo/raw_<name>_words.json ; out: vo/<name>_<piece>.wav (48 kHz mono float) + vo/<name>_<piece>_words.json
times in a piece start at 0 = 0.03 s before its first word."""
import sys, json, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/vo_new"); from clean_vo import clean
D = "/home/claude/fixes_1101/ta/vo_op"; SR = 48000
name, tempo = sys.argv[1], float(sys.argv[2])
W = json.load(open(f"{D}/raw_{name}_words.json"))
x = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", f"{D}/raw_{name}.wav", "-af",
    f"rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135", "-ar", str(SR), "-ac", "1", "-f", "f32le", "-"],
    capture_output=True, check=True).stdout, np.float32).astype(np.float64)
y = clean(x, SR)
for spec in sys.argv[3:]:
    p, a, b = spec.split(":"); a, b = int(a), int(b)
    t0 = max(0, W[a]["start"] - 0.03); t1 = min(len(y) / SR, W[b]["end"] + 0.14)
    seg = y[int(t0 * SR):int(t1 * SR)].copy()
    f = int(0.01 * SR); seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
    tmp = f"{D}/_t.wav"; sf.write(tmp, seg.astype(np.float32), SR, subtype="FLOAT")
    out = f"{D}/{name}_{p}.wav"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-af", f"atempo={tempo}", "-ar", str(SR), "-c:a", "pcm_f32le", out], check=True)
    ws = [{"word": w["word"], "start": round((w["start"] - t0) / tempo, 3), "end": round((w["end"] - t0) / tempo, 3)} for w in W[a:b + 1]]
    json.dump(ws, open(f"{D}/{name}_{p}_words.json", "w"), indent=0)
    print(out, round(sf.info(out).duration, 3), "s", " ".join(f"{w['word']}@{w['start']:.2f}" for w in ws))
