"""send.py [ids]: GitHub render batch for the 1 Nov Launch Map fixes. Render only; voices, TTS and mixes are local."""
import sys; sys.path.insert(0, "/home/claude/reelkit")
import cloud_render as C
F = "/home/claude/fixes_1101"; R = "/home/claude/reelkit"; FB = "/home/claude/fixes_1027b"; JS = "/home/claude/jews_survive"
X = "/home/claude/express_1031_cta/scenes_x.py"
MEDIA = (".wav", ".mp3", ".mp4", ".png", ".jpg", ".m4a", ".m4v")
APT = "apt-get install -y -qq libcairo2-dev pkg-config > /dev/null && pip install -q pycairo soundfile && "
RK = [R + f for f in ("/voice.py", "/render.py", "/mix.py", "/qa.py", "/asr.py", "/clean_vo.py", "/kit.py", "/sfx2.py", "/sfx", "/make_reel_sse.py")]
LOOP = [F + "/looplib.py", X]
def stage(rid, d, stage_py, rkdir, scenes, extra_cmd="", out=None, add=()):
    files = [f"{d}/spec.json", f"{d}/out/timing.json", f"{d}/out/mix.wav"]
    keep = set(files) | set(add) | {scenes}
    ent = [stage_py, f"{rkdir}/rk/render.py", f"{rkdir}/rk/kit.py", f"{rkdir}/rk/clean_vo.py", scenes] + LOOP
    return keep, [], {"id": rid, "cmd": APT + f"python3 {stage_py} render {d}/spec.json {d}/out/timing.json {d}/out/mix.wav {d}/{rid}_render.mp4" + extra_cmd,
            "out": out or f"{d}/{rid}_render.mp4", "entry": ent, "add": files + list(add) + RK}
def sse(rid, d, pre="vo", scenes=None, extra=()):
    keep = {f"{d}/spec.json", f"{d}/{pre}.wav", f"{d}/{pre}_words.json"} | set(extra)
    tts = f"{d}/vo/tts.txt" if pre == "vo/vo" else f"{d}/tts.txt"; keep.add(tts)
    ent = [R + "/make_reel_sse.py"] + ([scenes] if scenes else []) + LOOP
    return keep, [], {"id": rid, "cmd": f"cd {d} && python3 {R}/make_reel_sse.py spec.json {pre} out", "out": f"{d}/out/reel.mp4",
            "entry": ent, "add": RK + sorted(keep)}
JW = f"{F}/jw"; TA = f"{F}/ta"; EX = f"{F}/ex"; EM = f"{F}/em"
JOBS = [
 stage("colonizer_speed_v3", f"{F}/cs", FB + "/rk_stage.py", FB, F + "/loop_only.py"),
 sse("hebrew_revival_v3", f"{F}/hr", scenes=F + "/scenes_daily_loop.py"),
 stage("jews_survive_v3", f"{F}/js", JS + "/rk_stage.py", JS, f"{F}/js/js_scenes_loop.py", add=[f"{F}/js/js_scenes.py"]),
 stage("lib_startups_pc_v3", f"{F}/su", FB + "/rk_stage.py", FB, f"{F}/su/pro_loop.py", add=[FB + "/pro_scenes.py"]),
 sse("meat_per_km_v2", f"{F}/meat", scenes=f"{F}/meat/meat_loop.py", extra=["/home/claude/meat_per_km/meat_scenes.py"]),
 sse("this_life_v2", f"{F}/tl", pre="vo/vo", scenes=f"{F}/tl/tl_loop.py", extra=["/home/claude/this_life/scenes_tl.py"]),
 sse("maps_p2_hook2_v2", f"{F}/dogs", pre="vo/vo", scenes=f"{F}/dogs/daily_loop.py", extra=["/home/claude/daily_1028/scenes_daily.py"]),
 sse("x_could_en_v3", f"{F}/x_could_en_v3", scenes=F + "/scenes_pair.py"),
 sse("x_zoom_en_v4", f"{F}/x_zoom_en_v4", scenes=F + "/scenes_pair.py"),
 sse("x_express10_en_v4", f"{F}/x_express10_en_v4", scenes=X),
 ({f"{TA}/spec.json", f"{TA}/out/timing.json", f"{TA}/out/mix.wav", f"{TA}/cfg.json", f"{TA}/audio.wav", f"{TA}/build_ta.py",
   f"{TA}/vo_op/ta_hook_words.json"}, [],
  {"id": "terror_awards_v3",
   "cmd": APT + f"python3 {FB}/rk_stage.py render {TA}/spec.json {TA}/out/timing.json {TA}/out/mix.wav {TA}/body.mp4 && python3 {TA}/build_ta.py {TA}/cfg.json",
   "out": f"{TA}/terror_awards_v3.mp4", "entry": [FB + "/rk_stage.py", FB + "/rk/render.py", FB + "/rk/kit.py", FB + "/rk/clean_vo.py", f"{TA}/build_ta.py"],
   "add": [f"{TA}/spec.json", f"{TA}/out/timing.json", f"{TA}/out/mix.wav", f"{TA}/cfg.json", f"{TA}/audio.wav", f"{TA}/vo_op/ta_hook_words.json"] + RK}),
 ({f"{EX}/ex3.py", f"{EX}/mix3.py", f"{EX}/timing.json", "/home/claude/explain/logo.png"} | {f"{EX}/vo_{k}_chain.wav" for k in "abcd"}, [],
  {"id": "lib_explain_v2", "cmd": f"cd {EX} && python3 ex3.py && python3 mix3.py {EX}/ex2_silent.mp4 {EX}/lib_explain_v2.mp4", "out": f"{EX}/lib_explain_v2.mp4",
   "entry": [f"{EX}/ex3.py", f"{EX}/mix3.py"], "add": [f"{EX}/timing.json", "/home/claude/explain/logo.png"] + [f"{EX}/vo_{k}_chain.wav" for k in "abcd"] + RK}),
 ({f"{EM}/render.py", f"{EM}/beats.py", f"{EM}/music.py", f"{EM}/narration.txt", f"{EM}/align.py"}, [],
  {"id": "lib_express_method_v2", "cmd": APT + f"cd {EM} && python3 render.py --out {EM}/lib_express_method_v2.mp4", "out": f"{EM}/lib_express_method_v2.mp4",
   "entry": [f"{EM}/render.py", f"{EM}/beats.py", f"{EM}/music.py"], "add": [f"{EM}/narration.txt"]}),
 ({f"{JW}/world_fs.py", f"{JW}/cfg_jw_fs.py", "/home/claude/vid/topo.py", "/home/claude/vid/final/jews_world_v3.mp4", "/home/claude/geo/package/land-110m.json",
   f"{JW}/bluemarble_5400.jpg", "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"}, [JW + "/flags/"],
  {"id": "lib_vid_jews_world_v3", "cmd": f"pip install -q matplotlib numpy && python3 {JW}/world_fs.py {JW}/cfg_jw_fs.py && ffmpeg -v error -y -i {JW}/jews_world_fs_silent.mp4 -i /home/claude/vid/final/jews_world_v3.mp4 -map 0:v -map 1:a -t 40.8 -af afade=out:st=40.0:d=0.8 -c:v copy -c:a aac -b:a 192k -ar 48000 -movflags +faststart {JW}/jews_world_fs.mp4",
   "out": f"{JW}/jews_world_fs.mp4", "entry": [f"{JW}/world_fs.py", "/home/claude/vid/topo.py"],
   "add": [f"{JW}/cfg_jw_fs.py", "/home/claude/geo/package/land-110m.json", "/home/claude/vid/final/jews_world_v3.mp4", "/usr/share/fonts/opentype/inter", f"{JW}/flags",
           f"{JW}/bluemarble_5400.jpg", "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"]}),
]
only = sys.argv[1:]
JOBS = [j for j in JOBS if not only or j[2]["id"] in only]
it = iter(JOBS); _c = C.collect
def coll(e, a):
    keep, pref, j = next(it); out = []
    for f in _c(e, a):
        if f == R + "/tts.py" or ("/out/" in f and f not in keep): continue
        if f.startswith(F + "/") and f.lower().endswith(MEDIA) and not (f in keep or f.startswith(tuple(pref))): continue
        if f.startswith(F + "/tts/") or f.startswith(F + "/qa"): continue
        if f.startswith("/home/claude/vid/") and f not in keep and not f.startswith("/home/claude/vid/fonts/"): continue
        if f.lower().endswith(MEDIA) and not (f in keep or f.startswith(tuple(pref)) or f.startswith(f"{R}/sfx/") or "/sfx_src/" in f or f.startswith(F + "/")):
            continue
        out.append(f)
    print(j["id"], len(out), "files"); return out
C.collect = coll
C.send([j for _, _, j in JOBS])
