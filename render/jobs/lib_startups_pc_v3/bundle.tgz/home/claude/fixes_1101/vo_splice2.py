"""vo_splice2.py (1 Nov copy of reelkit/vo_splice.py: insert "before": N+1 appends a clip after the last line).
vo_splice.py: edit a finished narration (vo.wav + vo_words.json + tts.txt, one words entry per script word) without re-voicing.
  python3 vo_splice.py SRC_DIR DST_DIR edits.json
edits.json: list of ops, applied to the ORIGINAL line numbering (1-based):
  {"op":"cut","line":L,"from":i,"to":j,"text":"new line text"}   remove words i..j-1 (0-based) of line L; text = the line after the cut
  {"op":"drop","line":L}                                           remove the whole line L
  {"op":"insert","before":L,"wav":PATH,"words":PATH,"text":"..."} insert a Cartesia clip as a new line before line L
Cuts run from the start of the first removed word to the start of the next kept word, each snapped to the quietest 10 ms within 60 ms.
Writes DST_DIR/vo.wav, vo_words.json, tts.txt."""
import json, os, sys, wave
import numpy as np

def rd(p):
    w = wave.open(p); sr = w.getframerate(); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32); return a, sr

def snap(a, sr, t, win=0.06):
    h = int(0.01 * sr); c = int(t * sr); best, bt = None, t
    for s in range(max(0, c - int(win * sr)), min(len(a) - h, c + int(win * sr)), h // 2):
        e = float(np.mean(a[s:s + h] ** 2))
        if best is None or e < best: best, bt = e, (s + h / 2) / sr
    return bt

def main(src, dst, edits):
    a, sr = rd(f"{src}/vo.wav"); W = json.load(open(f"{src}/vo_words.json"))
    lines = [l for l in open(f"{src}/tts.txt").read().splitlines() if l.strip()]
    # tag words with line/index
    k = 0; per = []
    for li, l in enumerate(lines):
        n = len(l.split()); per.append(list(range(k, k + n))); k += n
    assert k == len(W), (k, len(W))
    # build segments: list of (line_key, audio, words(rel), text)
    segs = []
    for li, l in enumerate(lines):
        idx = per[li]
        t0 = W[idx[0]]["start"]; t1 = W[per[li + 1][0]]["start"] if li + 1 < len(lines) else len(a) / sr
        # line span: from midpoint of the gap before the line to the midpoint of the gap after
        prev_end = W[idx[0] - 1]["end"] if idx[0] > 0 else 0.0
        s = 0.0 if li == 0 else (prev_end + t0) / 2
        nxt_start = W[per[li + 1][0]]["start"] if li + 1 < len(lines) else None
        e = (W[idx[-1]]["end"] + nxt_start) / 2 if nxt_start is not None else len(a) / sr
        segs.append(dict(line=li + 1, s=s, e=e, words=[dict(W[i]) for i in idx], text=l, cuts=[]))
    ops = edits
    for op in ops:
        if op["op"] == "cut":
            g = segs[op["line"] - 1]; ws = g["words"]; i, j = op["from"], op["to"]
            c0 = snap(a, sr, ws[i]["start"] - 0.02) if i > 0 else g["s"]
            c1 = snap(a, sr, ws[j]["start"] - 0.03) if j < len(ws) else g["e"]
            if i == 0:  # keep the natural lead-in silence of the line
                c0 = max(g["s"], ws[0]["start"] - 0.03); c0 = snap(a, sr, c0)
            g["cuts"].append((c0, c1)); g["drop_idx"] = set(range(i, j)) | g.get("drop_idx", set()); g["text"] = op["text"]
        elif op["op"] == "drop":
            segs[op["line"] - 1]["dropped"] = True
    out, words, t = [], [], 0.0
    ins = {op["before"]: op for op in ops if op["op"] == "insert"}
    new_lines = []
    def fade(x):
        f = min(len(x) // 2, int(0.006 * sr))
        if f: x[:f] *= np.linspace(0, 1, f); x[-f:] *= np.linspace(1, 0, f)
        return x
    END = {"line": len(segs) + 1, "dropped": True}
    for g in segs + [END]:
        if g["line"] in ins:
            op = ins[g["line"]]; b, sr2 = rd(op["wav"]); assert sr2 == sr
            cw = json.load(open(op["words"])); tw = op["text"].split(); assert len(cw) == len(tw), (len(cw), len(tw), "clip words vs text")
            lead = max(0.0, cw[0]["start"] - 0.08); tail = min(len(b) / sr, cw[-1]["end"] + 0.12)
            pre = np.zeros(int(0.30 * sr), np.float32)
            seg = fade(b[int(lead * sr):int(tail * sr)].copy())
            out += [pre, seg]; t0 = t + len(pre) / sr
            for x, w in zip(cw, tw): words.append(dict(word=w, start=round(t0 + x["start"] - lead, 4), end=round(t0 + x["end"] - lead, 4)))
            t = t0 + len(seg) / sr; new_lines.append(op["text"])
        if g.get("dropped"): continue
        # keep pieces of [s,e] minus cuts
        keep, cur = [], g["s"]
        for c0, c1 in sorted(g["cuts"]): keep.append((cur, c0)); cur = c1
        keep.append((cur, g["e"]))
        def mp(x):
            acc = 0.0
            for k0, k1 in keep:
                if x <= k1: return t + acc + max(0.0, x - k0)
                acc += k1 - k0
            return t + acc
        drop = g.get("drop_idx", set()); tw = g["text"].split(); kept = [w for n, w in enumerate(g["words"]) if n not in drop]
        assert len(kept) == len(tw), (g["line"], len(kept), len(tw))
        for w, txt in zip(kept, tw): words.append(dict(word=txt, start=round(mp(w["start"]), 4), end=round(mp(w["end"]), 4)))
        for k0, k1 in keep:
            if k1 > k0: out.append(fade(a[int(k0 * sr):int(k1 * sr)].copy()))
        t += sum(k1 - k0 for k0, k1 in keep if k1 > k0); new_lines.append(g["text"])
    y = np.concatenate(out).clip(-32768, 32767).astype(np.int16)
    os.makedirs(dst, exist_ok=True)
    with wave.open(f"{dst}/vo.wav", "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(y.tobytes())
    json.dump(words, open(f"{dst}/vo_words.json", "w"), ensure_ascii=False, indent=0)
    open(f"{dst}/tts.txt", "w").write("\n".join(new_lines) + "\n")
    print(dst, f"{len(a)/sr:.2f}s -> {len(y)/sr:.2f}s, {len(words)} words, {len(new_lines)} lines")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], json.load(open(sys.argv[3])))
