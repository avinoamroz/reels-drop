"""splice.py cfg.json: build a new vo.wav + vo_words.json (one entry per script word) + tts.txt from an old joined
narration (Cartesia SSE, raw) and new SSE takes. cfg: {old_wav, old_words, old_tts, out_dir, items:[...]}
item {"old": k} keeps old line k (1-based) untouched; {"old": k, "drop": n, "text": t} keeps it minus its first n words;
{"tts": name, "text": t} takes /home/claude/fixes_1101/tts/<name>.wav (script text t, mapped by character position)."""
import json, os, re, sys, wave
import numpy as np
SR = 44100; GAP = 0.32; MAXG = 0.42; PAD0, PAD1 = 0.05, 0.12
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def rd(p):
    w = wave.open(p); assert w.getframerate() == SR
    return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32)
cfg = json.load(open(sys.argv[1])); os.makedirs(cfg["out_dir"], exist_ok=True); GAP = cfg.get("gap", GAP)
OA = rd(cfg["old_wav"]); OW = json.load(open(cfg["old_words"]))
OL = [l.strip() for l in open(cfg["old_tts"]) if l.strip()]
assert sum(len(l.split()) for l in OL) == len(OW), (sum(len(l.split()) for l in OL), len(OW))
spans, i = [], 0
for l in OL: n = len(l.split()); spans.append((i, i + n)); i += n
def fade(seg):
    f = min(len(seg) // 2, int(0.008 * SR))
    if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
    return seg
chunks, words, lines, t = [], [], [], 0.0
prev_old = None
for it in cfg["items"]:
    if "old" in it:
        k = it["old"] - 1; a, b = spans[k]; drop = it.get("drop", 0); ws = OW[a + drop:b]
        text = it.get("text", OL[k]); assert len(text.split()) == len(ws), (text, len(ws))
        if it.get("replace"):
            # rebuild this line: old audio with some words swapped for native clips (tts/<clip>.wav, trimmed to speech)
            prev_old = None
            if chunks: chunks.append(np.zeros(int(GAP * SR), np.float32)); t += GAP
            sw = text.split(); pieces = []; cur = ws[0]["start"] - 0.05; wt = []
            for (i0, i1, clip) in it["replace"]:
                a0 = ws[i0]["start"] - 0.015; pieces.append(("old", cur, a0, list(range(len(wt), i0))))
                wt += [None] * (i0 - len(wt))
                C = rd(f"/home/claude/fixes_1101/tts/{clip}.wav"); env = np.array([np.sqrt(np.mean(C[q:q + 441] ** 2)) for q in range(0, len(C) - 441, 441)])
                on = np.where(env > env.max() * 0.03)[0]; c0 = max(0, on[0] - 3) * 441; c1 = min(len(C), (on[-1] + 4) * 441)
                if clip in it.get("cut_tail", {}): c1 = min(c1, int(it["cut_tail"][clip] * SR))
                pieces.append(("clip", C[c0:c1].copy(), list(range(i0, i1 + 1)))); wt += [None] * (i1 + 1 - i0)
                cur = ws[i1]["end"] + 0.01
            pieces.append(("old", cur, ws[-1]["end"] + 0.12, list(range(len(wt), len(ws)))))
            for p in pieces:
                if p[0] == "old":
                    _, s0, s1, idx = p; seg = fade(OA[int(s0 * SR):int(s1 * SR)].copy())
                    for q in idx: words.append(dict(word=sw[q], start=round(t + ws[q]["start"] - s0, 4), end=round(t + ws[q]["end"] - s0, 4)))
                else:
                    _, seg, idx = p; seg = fade(seg); d = len(seg) / SR; L = [max(1, len(norm(sw[q]))) for q in idx]; tot = sum(L); acc = 0
                    for q, l_ in zip(idx, L): words.append(dict(word=sw[q], start=round(t + 0.03 + (d - 0.06) * acc / tot, 4), end=round(t + 0.03 + (d - 0.06) * (acc + l_) / tot, 4))); acc += l_
                chunks.append(seg); t += len(seg) / SR
            lines.append(text); continue
        st = ws[0]["start"]; en = ws[-1]["end"]
        lo = OW[a - 1]["end"] if a > 0 else 0.0; hi = OW[b]["start"] if b < len(OW) else len(OA) / SR
        s0 = max((lo + st) / 2, st - 0.25) if not drop else st - 0.04
        s1 = min((en + hi) / 2, en + 0.25)
        contiguous = prev_old == k - 1 and not drop
        if chunks and not contiguous: chunks.append(np.zeros(int(GAP * SR), np.float32)); t += GAP
        mg = cfg.get("maxg_old"); keep = [(s0, s1)]
        if mg:
            keep, cur = [], s0
            for j in range(len(ws) - 1):
                g0, g1 = ws[j]["end"], ws[j + 1]["start"]
                if g1 - g0 > mg: ex = g1 - g0 - mg; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
            keep.append((cur, s1))
        def mpo(x):
            acc = 0.0
            for k0, k1 in keep:
                if x <= k1: return t + acc + max(0, x - k0)
                acc += k1 - k0
            return t + acc
        for w_, sw in zip(ws, text.split()): words.append(dict(word=sw, start=round(mpo(w_["start"]), 4), end=round(mpo(w_["end"]), 4)))
        for k0, k1 in keep:
            seg = fade(OA[int(k0 * SR):int(k1 * SR)].copy()); chunks.append(seg); t += len(seg) / SR; prev_old = k if not it.get("text") else None
    else:
        prev_old = None
        A = rd(f"/home/claude/fixes_1101/tts/{it['tts']}.wav"); W = json.load(open(f"/home/claude/fixes_1101/tts/{it['tts']}_words.json"))
        cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
        tot = sum(len(c[0]) for c in cw); pos = 0; sp = []
        for c in cw: sp.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
        def t_at(f):
            for f0, f1, s, e in sp:
                if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
            return sp[-1][3]
        sw = it["text"].split(); sn = [norm(x) for x in sw]; stot = sum(max(1, len(x)) for x in sn); pos = 0; mine = []
        for x, n_ in zip(sw, sn):
            L = max(1, len(n_)); f0, f1 = pos / stot, (pos + L) / stot; pos += L
            mine.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
        s0 = max(0, W[0]["start"] - PAD0); e1 = min(len(A) / SR, W[-1]["end"] + PAD1)
        cuts = []
        for j in range(len(W) - 1):
            g0, g1 = W[j]["end"], W[j + 1]["start"]
            if g1 - g0 > MAXG: ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; cuts.append((m - ex / 2, m + ex / 2))
        keep, cur = [], s0
        for c0, c1 in cuts: keep.append((cur, c0)); cur = c1
        keep.append((cur, e1))
        if chunks: chunks.append(np.zeros(int(GAP * SR), np.float32)); t += GAP
        def mp(x):
            acc = 0.0
            for k0, k1 in keep:
                if x <= k1: return t + acc + max(0, x - k0)
                acc += k1 - k0
            return t + acc
        for x, a_, b_ in mine: words.append(dict(word=x, start=round(mp(a_), 4), end=round(mp(max(b_, a_ + 0.04)), 4)))
        for k0, k1 in keep:
            seg = fade(A[int(k0 * SR):int(k1 * SR)].copy()); chunks.append(seg); t += len(seg) / SR
        text = it["text"]
    lines.append(text)
y = np.concatenate(chunks).clip(-32768, 32767).astype(np.int16)
o = cfg["out_dir"]
with wave.open(f"{o}/vo.wav", "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(y.tobytes())
json.dump(words, open(f"{o}/vo_words.json", "w"), ensure_ascii=False, indent=0)
open(f"{o}/tts.txt", "w").write("\n".join(lines) + "\n")
print(o, round(len(y) / SR, 2), "s,", len(words), "words,", len(lines), "lines")
