"""scenes_pair.py (1 Nov, Noam on x_could_en_v2 / x_zoom_en_v3): "show the sentences you shouldn't say first on top, then
the corrections, and match it to the sound". Loads every scene from /home/claude/express_1031_cta/scenes_x.py (speaker
end card, loop cross-fade, looping bed) and adds:

  {"type": "pair", "line": N, "neg": "Give me the file", "neg_he": "optional small Hebrew line",
   "pos": ["Could you *send me* the file?", "optional second correction"], "marks": {"n": phrase, "p0": phrase, "p1": phrase}}

The wrong sentence (red card, red cross, struck through) sits on top and lands when it is spoken (mark n, default the
scene start); each correction (green card, green tick) lands under it on its own spoken words (marks p0, p1)."""
import importlib.util, math
_p = "/home/claude/express_1031_cta/scenes_x.py"
_s = importlib.util.spec_from_file_location("scenes_x", _p); _m = importlib.util.module_from_spec(_s); _s.loader.exec_module(_m)
for _k, _v in vars(_m).items():
    if _k.startswith("sc_"): globals()[_k] = _v
import render as RD
from render import P, T, PP, fade_in, source, block, block_h, shadow_box, pill
from kit import ease, St, sa
_mark = _m._mark

def sc_pair(c, t, S):
    t0 = S["t0"]; tn = S["times"].get("n", t0 + 0.05); pos = S["pos"] if isinstance(S["pos"], list) else [S["pos"]]
    tps = [S["times"].get(f"p{k}", tn + 1.4 + 1.2 * k) for k in range(len(pos))]
    # top: label + wrong sentence
    y = 380
    a, s = PP(t, tn - 0.1, S); pill(c, "Don't say", 58, 540, y + 40, P["red"], P["white"], a, s)
    y += 120
    if S.get("pre") and t < tn:   # optional lead-in line shown big until the wrong sentence is spoken
        pa, ps = PP(t, t0 + 0.05, S); block(c, S["pre"], 110, 540, 860, P["navy"], pa * (1 - fade_in(t, tn - 0.25, S, 0.2)), ps, 900, hl=P["blue"], maxw=920, max_lines=2)
    neg = S["neg"]; he = S.get("neg_he")
    hn = block_h(neg, 92, 800, 780, 2); bh = hn + (100 if he else 0) + 90
    if t >= tn - 0.12:
        u = ease((t - tn + 0.12) / 0.35); old = St.a; St.a *= fade_in(t, tn - 0.12, S, 0.2)
        c.save(); c.translate(0, -60 * (1 - u))
        shadow_box(c, 70, y, 940, bh, 44, P["card"], stroke=P["red"], sw=5, sh=8)
        yc = y + 45 + hn / 2
        _mark(c, 130, yc, 30, False)
        block(c, neg, 92, 580, yc, P["red"], 1.0, 1.0, 800, maxw=780, max_lines=2)
        # strike through once the correction starts
        if t >= tps[0] - 0.05:
            k = ease((t - tps[0] + 0.05) / 0.3); from render import wrap
            z, ls = RD.wrap(neg, 92, 800, 780, 2)
            for j, l in enumerate(ls):
                lw = min(780, RD.font(z, 800).getlength(l.replace("*", ""))) if hasattr(RD, "font") else 700
                yl = yc - z * 1.14 * len(ls) / 2 + z * 1.14 * (j + 0.5)
                sa(c, P["red"], 0.85 * St.a); c.set_line_width(7); c.move_to(580 - lw / 2, yl + 4); c.line_to(580 - lw / 2 + lw * k, yl + 4); c.stroke()
        if he: T(c, he, 60, 580, y + 45 + hn + 55, P["gold_text"], 1.0, 1.0, 700, maxw=820)
        c.restore(); St.a = old
    y += bh + 110
    # chevron between
    ca = fade_in(t, tps[0] - 0.1, S, 0.2)
    if ca > 0.01:
        sa(c, P["green"], ca * St.a); c.set_line_width(12); c.set_line_cap(1); c.set_line_join(1)
        c.move_to(500, y - 30); c.line_to(540, y + 10); c.line_to(580, y - 30); c.stroke()
    y += 50
    # bottom: corrections
    a, s = PP(t, tps[0] - 0.1, S); pill(c, "Say", 58, 540, y + 40, P["green"], P["white"], a, s)
    y += 120
    for k, (p, tp) in enumerate(zip(pos, tps)):
        hp = block_h(p, 86, 800, 780, 2); ph = hp + 90
        if t >= tp - 0.1:
            pa, ps = PP(t, tp - 0.1, S, bounce=2.2); old = St.a; St.a *= pa
            c.save(); c.translate(540, y + ph / 2); c.scale(ps, ps); c.translate(-540, -(y + ph / 2))
            shadow_box(c, 70, y, 940, ph, 44, P["card"], stroke=P["green"], sw=5, sh=8)
            _mark(c, 130, y + ph / 2, 30, True)
            block(c, p, 86, 580, y + ph / 2, P["green"], 1.0, 1.0, 800, hl=P["blue"], maxw=780, max_lines=2)
            c.restore(); St.a = old
        y += ph + 44
    source(c, t, S)
