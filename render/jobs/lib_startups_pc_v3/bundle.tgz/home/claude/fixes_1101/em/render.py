#!/usr/bin/env python3
"""The English Express method as a drive: parking lot, neighborhood, city, highway.
Vertical reel renderer for @expressenglishcom (collab @noamroz__). Same CLI as /home/claude/israel_tech/render.py.

  python3 render.py                       music-only v1, timing estimated from narration.txt word counts
  python3 render.py --vo DIR              re-time to per-line clips DIR/<key>.wav (keys in beats.py)
  python3 render.py --vo noam.wav         re-time to ONE narration file, split at its longest pauses
  python3 render.py --vo noam.wav --cues cues.json [--gap 0.4]
                                          split by align.py (ASR) cues; --gap re-lays the lines with that break
  python3 render.py --frames 0.5,3,10     save check/f_<t>.png and print the timeline, no encode
  --out FILE                              output path (default express_method_v1.mp4, or express_method_vo.mp4 with --vo)

Script lives in narration.txt (one line per beat) + beats.py (captions, bubbles). The world is drawn with cairo
(antialiased vectors, one zooming top down map); all text is Pillow with RAQM, Hebrew with direction="rtl"
(same approach as names/render.py and israel_tech/render.py). No logos, no photos, no car brands.
"""
import sys, os, math, json, argparse, subprocess, re, time
import numpy as np, soundfile as sf, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from beats import BEATS, KEYS, STAGES, BUBBLES_P, CONVOS_N, MEETING_C, PITCH_H, HOOK_TRUCKS

ap = argparse.ArgumentParser()
ap.add_argument("--vo", default=None)
ap.add_argument("--out", default=None)
ap.add_argument("--frames", default=None)
ap.add_argument("--cues", default=None)
ap.add_argument("--gap", type=float, default=None)
ap.add_argument("--wps", type=float, default=3.0, help="words per second for the estimated (no voice) timing")
A = ap.parse_args()

W, H, FPS, SR = 1080, 1920, 30, 44100
CX, CY = W / 2, H / 2
FD = "/home/claude/quran/fonts/"
_FC = {}
def F(w, s):
    k = (w, int(s))
    if k not in _FC: _FC[k] = ImageFont.truetype(FD + f"Heebo-{w}.ttf", int(s), layout_engine=ImageFont.Layout.RAQM)
    return _FC[k]
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def cf(c): return tuple(v / 255 for v in c)
# English Express navy brand (brand book: navy #163260, sky #59A5DF; red only for the wrong way)
NAVY0, NAVY1 = hx("#070F22"), hx("#0E1D3D")
WHITE, MUTED, DIM = hx("#F5F7FA"), hx("#93A4C0"), hx("#56688A")
PANEL, PANEL2 = hx("#16264A"), hx("#22355F")
SKY, SKYHI = hx("#59A5DF"), hx("#8CC8F2")
RED, AMBER = hx("#E0335F"), hx("#F5B942")
GROUND, LOT, ROAD = hx("#0A1631"), hx("#132650"), hx("#192C57")
CAR_COLS = [hx("#DCE4F0"), hx("#93A4C0"), hx("#3F5A93"), hx("#B9C7DD"), hx("#6E86B5")]

def clamp(x): return max(0.0, min(1.0, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def smooth(x): x = clamp(x); return x * x * (3 - 2 * x)
def lerp(a, b, u): return a + (b - a) * u
def is_he(s): return any("֐" <= c <= "׿" for c in s)

NARR = [l.strip() for l in open(os.path.join(HERE, "narration.txt"), encoding="utf8") if l.strip()]
assert len(NARR) == len(KEYS), (len(NARR), len(KEYS))
BY = {b["key"]: b for b in BEATS}

# ------------------------------------------------------------------ timeline (from israel_tech/render.py)
LEAD, GAP, TAIL, HOOK_MAX = 0.10, 0.45, 0.8, 1.0
def load_audio(p):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)
def spoken_units(line):
    n = 0.0
    for w in line.split():
        d = re.sub(r"[^\d]", "", w)
        n += 1 if not d else (1 if int(d) < 20 else 1.6)
        if w.startswith("@"): n += 3
    return n + 0.35 * len(re.findall(r"[.?!,]", line))
def split_single(x):
    hop = int(0.02 * SR); n = len(x) // hop
    rms = np.sqrt(np.mean(x[:n * hop].reshape(n, hop) ** 2, 1) + 1e-12)
    sil = 20 * np.log10(rms / (rms.max() + 1e-12)) < -38
    runs = []; i = 0
    while i < n:
        if sil[i]:
            j = i
            while j < n and sil[j]: j += 1
            runs.append((i, j)); i = j
        else: i += 1
    first = int(np.argmax(~sil)); last = n - int(np.argmax(~sil[::-1]))
    inner = [(a, b) for a, b in runs if a > first and b < last]
    need = len(KEYS) - 1
    if len(inner) < need: sys.exit(f"only {len(inner)} pauses found in the voice file, need {need}")
    cut = sorted(sorted(inner, key=lambda r: r[1] - r[0], reverse=True)[:need])
    edges = [first] + [v for a, b in cut for v in (a, b)] + [last]
    return [(edges[2 * k] * hop / SR, edges[2 * k + 1] * hop / SR) for k in range(len(KEYS))]

VOICE = None
if A.vo and os.path.isdir(A.vo):
    segs, t = [], 0.05
    for k in KEYS:
        p = os.path.join(A.vo, f"{k}.wav")
        if not os.path.exists(p): sys.exit(f"missing voice clip {p}")
        x = load_audio(p); segs.append(dict(key=k, v0=t, v1=t + len(x) / SR, x=x)); t += len(x) / SR + (A.gap if A.gap is not None else GAP)
    TT = segs[-1]["v1"] + TAIL
    VOICE = np.zeros(int((TT + 0.3) * SR))
    for s in segs: i = int(s["v0"] * SR); VOICE[i:i + len(s["x"])] += s["x"]
elif A.vo:
    x = load_audio(A.vo)
    if A.cues:
        C_ = {c["key"]: c for c in json.load(open(A.cues))}; spans = [(C_[k]["v0"], C_[k]["v1"]) for k in KEYS]
    else:
        spans = split_single(x)
    if A.gap is None:
        off = 0.05 - spans[0][0]
        segs = [dict(key=k, v0=a + off, v1=b + off) for k, (a, b) in zip(KEYS, spans)]
        TT = segs[-1]["v1"] + TAIL
        VOICE = np.zeros(int((TT + 0.3) * SR)); src = x[max(0, int(-off * SR)):]
        i0 = max(0, int(off * SR)); L = min(len(src), len(VOICE) - i0); VOICE[i0:i0 + L] = src[:L]
    else:
        segs, t, clips = [], 0.05, []
        for k, (a, b) in zip(KEYS, spans):
            c = x[int(max(0, a - 0.04) * SR):int((b + 0.08) * SR)].copy(); f = int(0.02 * SR)
            c[:f] *= np.linspace(0, 1, f); c[-f:] *= np.linspace(1, 0, f)
            segs.append(dict(key=k, v0=t + 0.04, v1=t + 0.04 + (b - a))); clips.append((t, c)); t += len(c) / SR + A.gap
        TT = segs[-1]["v1"] + TAIL
        VOICE = np.zeros(int((TT + 0.3) * SR))
        for t0, c in clips: i = int(t0 * SR); VOICE[i:i + len(c)] += c[:len(VOICE) - i]
else:
    segs, t = [], 0.05
    for k, line in zip(KEYS, NARR):
        d = spoken_units(line) / A.wps + 0.2
        segs.append(dict(key=k, v0=t, v1=t + d)); t += d + GAP
    TT = segs[-1]["v1"] + TAIL
SEG = {s["key"]: s for s in segs}

BSTART = {k: (0.0 if i == 0 else SEG[k]["v0"] - LEAD) for i, k in enumerate(KEYS)}
BEND = {k: (BSTART[KEYS[i + 1]] if i + 1 < len(KEYS) else TT) for i, k in enumerate(KEYS)}
def beat_at(t):
    for k in reversed(KEYS):
        if BSTART[k] <= t: return k
    return KEYS[0]
SC0, SC1 = {}, {}                                   # scene start / end
for k in KEYS:
    sc = BY[k]["scene"]; SC0.setdefault(sc, BSTART[k]); SC1[sc] = BEND[k]
NF = int(round(TT * FPS))
TR = 1.6                                            # zoom out at the start of N, C, H
XF = 0.35                                           # crossfade between non zoom scenes

# ------------------------------------------------------------------ text sprites (Pillow, RAQM)
_TC = {}
def timg(s, w, size, col):
    k = (s, w, int(size), col)
    if k in _TC: return _TC[k]
    f = F(w, size); kw = dict(direction="rtl", language="he") if is_he(s) else {}
    dd = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    tw = int(dd.textlength(s, font=f, **kw)) + 40; th = int(f.size * 1.6)
    im = Image.new("RGBA", (tw, th), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((tw / 2, th / 2), s, font=f, fill=col + (255,), anchor="mm", **kw)
    _TC[k] = im; return im
def tw_(s, w, size): return timg(s, w, size, WHITE).width - 40
def fitsize(s, w, size, maxw):
    while tw_(s, w, size) > maxw and size > 18: size -= 2
    return size
_RC = {}
def put(dst, im, cx, cy, alpha=1.0, scale=1.0, rot=0):
    if alpha <= 0.01: return
    if rot:
        k = (id(im), rot)
        if k not in _RC: _RC[k] = im.rotate(rot, expand=True, resample=Image.BICUBIC)
        im = _RC[k]
    if abs(scale - 1) > 0.004:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.BICUBIC)
    if alpha < 0.99:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im = im.copy(); im.putalpha(a)
    dst.paste(im, (int(round(cx - im.width / 2)), int(round(cy - im.height / 2))), im)
TXT = []                                            # queued text, pasted after the cairo pass
def qt(s, w, size, col, cx, cy, alpha=1.0, maxw=960, align="c", scale=1.0, rot=0):
    if alpha <= 0.01 or not s: return
    size = fitsize(s, w, size, maxw); im = timg(s, w, size, col)
    if align == "l": cx = cx + (im.width - 40) / 2 * scale
    if align == "r": cx = cx - (im.width - 40) / 2 * scale
    TXT.append((im, cx, cy, alpha, scale, rot))
def wrap(s, w, size, maxw):
    if tw_(s, w, size) <= maxw: return [s]
    ws = s.split(); best = None
    for k in range(1, len(ws)):
        a, b = " ".join(ws[:k]), " ".join(ws[k:]); m = max(tw_(a, w, size), tw_(b, w, size))
        if best is None or m < best[0]: best = (m, a, b)
    return [best[1], best[2]]

# ------------------------------------------------------------------ cairo helpers
def rgba(ctx, c, a=1.0): ctx.set_source_rgba(*cf(c), a)
def rrect(ctx, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    ctx.new_sub_path(); ctx.arc(x + w - r, y + r, r, -math.pi / 2, 0); ctx.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    ctx.arc(x + r, y + h - r, r, math.pi / 2, math.pi); ctx.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); ctx.close_path()
def fill_rr(ctx, x, y, w, h, r, c, a=1.0): rrect(ctx, x, y, w, h, r); rgba(ctx, c, a); ctx.fill()
def glow(ctx, x, y, r, c, a):
    g = cairo.RadialGradient(x, y, 0, x, y, r); g.add_color_stop_rgba(0, *cf(c), a); g.add_color_stop_rgba(1, *cf(c), 0)
    ctx.set_source(g); ctx.arc(x, y, r, 0, 2 * math.pi); ctx.fill()

def car(ctx, x, y, ang, col, L, Wd, alpha=1.0, hero=False, blink=None, hazard=False, t=0.0):
    """top down car, nose along +x before rotation; ang = heading (radians)"""
    if alpha <= 0.01: return
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang)
    if alpha < 0.99: ctx.push_group()
    if hero:
        g = cairo.LinearGradient(L * 0.45, 0, L * 2.4, 0)        # headlight beams
        g.add_color_stop_rgba(0, *cf(SKYHI), 0.30); g.add_color_stop_rgba(1, *cf(SKYHI), 0)
        ctx.set_source(g); ctx.move_to(L * 0.45, -Wd * 0.35); ctx.line_to(L * 2.4, -Wd * 1.25); ctx.line_to(L * 2.4, Wd * 1.25); ctx.line_to(L * 0.45, Wd * 0.35); ctx.close_path(); ctx.fill()
        glow(ctx, 0, 0, L * 1.05, SKY, 0.35)
    fill_rr(ctx, -L / 2 + L * 0.05, -Wd / 2 + Wd * 0.14, L, Wd, Wd * 0.32, (0, 0, 0), 0.35)
    fill_rr(ctx, -L / 2, -Wd / 2, L, Wd, Wd * 0.34, col)
    shade = tuple(int(v * 0.55) for v in col)
    fill_rr(ctx, -L * 0.20, -Wd * 0.36, L * 0.38, Wd * 0.72, Wd * 0.18, tuple(min(255, int(v * 1.08 + 10)) for v in col))
    ctx.move_to(L * 0.30, -Wd * 0.40); ctx.line_to(L * 0.30, Wd * 0.40); ctx.line_to(L * 0.16, Wd * 0.34); ctx.line_to(L * 0.16, -Wd * 0.34); ctx.close_path()
    rgba(ctx, NAVY0, 0.85); ctx.fill()
    ctx.move_to(-L * 0.36, -Wd * 0.36); ctx.line_to(-L * 0.36, Wd * 0.36); ctx.line_to(-L * 0.24, Wd * 0.32); ctx.line_to(-L * 0.24, -Wd * 0.32); ctx.close_path()
    rgba(ctx, NAVY0, 0.75); ctx.fill()
    for sy in (-1, 1):
        fill_rr(ctx, L * 0.40, sy * Wd * 0.30 - Wd * 0.09, L * 0.08, Wd * 0.18, 2, WHITE, 0.95)
        fill_rr(ctx, -L * 0.49, sy * Wd * 0.30 - Wd * 0.08, L * 0.06, Wd * 0.16, 2, RED, 0.9)
    on = (t * 1.5) % 1 < 0.5
    if on and (hazard or blink is not None):
        sides = (-1, 1) if hazard else (blink,)
        for sy in sides:
            for sx in (L * 0.44, -L * 0.44):
                glow(ctx, sx, sy * Wd * 0.46, Wd * (0.9 if hazard else 0.6), AMBER, 0.85)
                ctx.arc(sx, sy * Wd * 0.44, Wd * 0.10, 0, 2 * math.pi); rgba(ctx, AMBER); ctx.fill()
    _ = shade
    if alpha < 0.99: ctx.pop_group_to_source(); ctx.paint_with_alpha(alpha)
    ctx.restore()

_CS = {}
def csprite(ctx, s, w, size, col, cx, cy, rot=0, alpha=1.0):
    """Pillow text sprite painted through cairo (for text that belongs to the world, under the UI)"""
    k = (s, w, size, col, rot)
    if k not in _CS:
        im = timg(s, w, size, col)
        if rot: im = im.rotate(rot, expand=True, resample=Image.BICUBIC)
        a = np.array(im).astype(np.float32); al = a[..., 3:4] / 255.0
        pm = np.dstack([a[..., 2:3] * al, a[..., 1:2] * al, a[..., 0:1] * al, a[..., 3:4]]).astype(np.uint8)
        pm = np.ascontiguousarray(pm); st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, im.width)
        buf = np.zeros((im.height, st // 4, 4), np.uint8); buf[:, :im.width] = pm
        _CS[k] = (cairo.ImageSurface.create_for_data(memoryview(buf), cairo.FORMAT_ARGB32, im.width, im.height, st), buf)
    sf_, _ = _CS[k]
    ctx.set_source_surface(sf_, cx - sf_.get_width() / 2, cy - sf_.get_height() / 2); ctx.paint_with_alpha(alpha)

def truck(ctx, x, y, ang, L, Wd, alpha=1.0):
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang)
    fill_rr(ctx, -L / 2 + 10, -Wd / 2 + 14, L, Wd, 14, (0, 0, 0), 0.4)
    cab = L * 0.17
    fill_rr(ctx, L / 2 - cab, -Wd * 0.46, cab, Wd * 0.92, Wd * 0.16, hx("#3F5A93"))
    fill_rr(ctx, L / 2 - cab * 0.42, -Wd * 0.40, cab * 0.18, Wd * 0.80, 4, NAVY0, 0.85)
    fill_rr(ctx, -L / 2, -Wd / 2, L - cab - L * 0.02, Wd, 10, hx("#C9D4E6"))
    for k in range(1, 9):
        xx = -L / 2 + k * (L - cab) / 9.4; ctx.move_to(xx, -Wd / 2 + 6); ctx.line_to(xx, Wd / 2 - 6)
    rgba(ctx, hx("#A9B7CF"), 0.8); ctx.set_line_width(3); ctx.stroke()
    ctx.restore()

class Loop:
    """clockwise rounded rect loop (screen coords, y down), sampled by arc length"""
    def __init__(self, a, b, r, cx=0.0, cy=0.0, n=3000):
        pts = []
        def arc(ox, oy, a0, a1):
            for th in np.linspace(a0, a1, 40): pts.append((ox + r * math.cos(th), oy + r * math.sin(th)))
        def seg(p, q):
            for u in np.linspace(0, 1, 60)[:-1]: pts.append((lerp(p[0], q[0], u), lerp(p[1], q[1], u)))
        seg((-a + r, -b), (a - r, -b)); arc(a - r, -b + r, -math.pi / 2, 0)
        seg((a, -b + r), (a, b - r)); arc(a - r, b - r, 0, math.pi / 2)
        seg((a - r, b), (-a + r, b)); arc(-a + r, b - r, math.pi / 2, math.pi)
        seg((-a, b - r), (-a, -b + r)); arc(-a + r, -b + r, math.pi, 1.5 * math.pi)
        P = np.array(pts) + [cx, cy]; P = np.vstack([P, P[:1]])
        d = np.hypot(*np.diff(P, axis=0).T); self.P = P; self.c = np.concatenate([[0], np.cumsum(d)]); self.L = self.c[-1]
    def at(self, s):
        s = s % self.L; i = int(np.searchsorted(self.c, s) - 1); i = max(0, min(i, len(self.P) - 2))
        u = (s - self.c[i]) / max(1e-9, self.c[i + 1] - self.c[i]); p, q = self.P[i], self.P[i + 1]
        return lerp(p[0], q[0], u), lerp(p[1], q[1], u), math.atan2(q[1] - p[1], q[0] - p[0])

# ------------------------------------------------------------------ the world: four nested stages
# each stage is designed in its own coords where the full screen is x +-540, y +-960 at scale 1.
# the next stage holds the previous one as an inset (scaled 1/K) around INSET[stage]; zooming out = scaling.
K = dict(N=2.6, C=3.0, H=2.5)
INSET = dict(N=(0.0, 0.0), C=(0.0, 0.0), H=(-300.0, 0.0))
SS = 2                                              # static layers at 2x
STAT = {}
def mk_static(fn):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W * SS, H * SS); c = cairo.Context(s)
    c.scale(SS, SS); c.translate(CX, CY); fn(c); s.flush(); return s
def paint_static(ctx, name):
    ctx.save(); ctx.translate(-CX, -CY); ctx.scale(1 / SS, 1 / SS); ctx.set_source_surface(STAT[name], 0, 0)
    ctx.get_source().set_filter(cairo.FILTER_GOOD); ctx.paint(); ctx.restore()
def inset(ctx, stage, fn):
    """run fn() inside the inset of `stage` (coords of the previous stage), clipped to its screen"""
    ctx.save(); ctx.translate(*INSET[stage]); ctx.scale(1 / K[stage], 1 / K[stage])
    ctx.rectangle(-CX, -CY, W, H); ctx.clip(); fn(); ctx.restore()

rng = np.random.default_rng(11)
def ground(ctx, x0=-CX, y0=-CY, w=W, h=H):
    rgba(ctx, GROUND); ctx.rectangle(x0, y0, w, h); ctx.fill()

# --- P: the parking lot
LOT_A, LOT_B = 360, 430
def P_static(c):
    ground(c)
    fill_rr(c, -LOT_A - 14, -LOT_B - 14, 2 * LOT_A + 28, 2 * LOT_B + 28, 46, hx("#0F1F43"))
    fill_rr(c, -LOT_A, -LOT_B, 2 * LOT_A, 2 * LOT_B, 36, LOT)
    rrect(c, -LOT_A, -LOT_B, 2 * LOT_A, 2 * LOT_B, 36); rgba(c, WHITE, 0.18); c.set_line_width(3); c.stroke()
    c.set_line_width(4); rgba(c, WHITE, 0.42)
    for y in np.arange(-LOT_B + 70, LOT_B - 40, 84):
        for sx in (-1, 1):
            c.move_to(sx * LOT_A, y); c.line_to(sx * (LOT_A - 135), y)
    for x in np.arange(-LOT_A + 120, LOT_A - 100, 80):
        c.move_to(x, -LOT_B); c.line_to(x, -LOT_B + 120)
    c.stroke()
    for x in np.arange(-LOT_A + 120, LOT_A - 100, 80):         # bottom row with an entrance gap
        if abs(x) < 90: continue
        c.move_to(x, LOT_B); c.line_to(x, LOT_B - 120)
    c.stroke()
    c.set_line_width(5); rgba(c, WHITE, 0.10)                   # faint painted arrows
    for (x, y, a) in [(0, -300, 0), (0, 300, math.pi), (-205, 0, -math.pi / 2), (205, 0, math.pi / 2)]:
        c.save(); c.translate(x, y); c.rotate(a); c.move_to(-28, 12); c.line_to(0, -14); c.line_to(28, 12); c.stroke(); c.restore()
PATH_P = Loop(150, 220, 150)
V_P = 95.0

# --- N: the neighborhood
RW_N = 100
RX_N, RY_N = 258, 419
def road_v(c, x, y0, y1, w): rgba(c, ROAD); c.rectangle(x - w / 2, y0, w, y1 - y0); c.fill()
def road_h(c, y, x0, x1, w): rgba(c, ROAD); c.rectangle(x0, y - w / 2, x1 - x0, w); c.fill()
def dashes_v(c, x, y0, y1, skip, a=0.35, lw=3, per=46):
    c.set_line_width(lw); rgba(c, WHITE, a)
    for y in np.arange(y0, y1, per):
        if any(abs(y + per / 4 - s) < 70 for s in skip): continue
        c.move_to(x, y); c.line_to(x, y + per / 2)
    c.stroke()
def dashes_h(c, y, x0, x1, skip, a=0.35, lw=3, per=46):
    c.set_line_width(lw); rgba(c, WHITE, a)
    for x in np.arange(x0, x1, per):
        if any(abs(x + per / 4 - s) < 70 for s in skip): continue
        c.move_to(x, y); c.line_to(x + per / 2, y)
    c.stroke()
def house(c, x, y, w, h, rot):
    c.save(); c.translate(x, y); c.rotate(rot)
    fill_rr(c, -w / 2 + 5, -h / 2 + 7, w, h, 6, (0, 0, 0), 0.35)
    fill_rr(c, -w / 2, -h / 2, w, h, 6, hx("#263C6B"))
    c.move_to(-w / 2, -h / 2); c.line_to(0, 0); c.line_to(w / 2, -h / 2); c.close_path(); rgba(c, hx("#2F4A80")); c.fill()
    c.move_to(-w / 2, h / 2); c.line_to(0, 0); c.line_to(w / 2, h / 2); c.close_path(); rgba(c, hx("#1E3260")); c.fill()
    c.move_to(-w / 2 + 4, 0); c.line_to(w / 2 - 4, 0); rgba(c, hx("#3B5A96"), 0.6); c.set_line_width(2); c.stroke()
    c.restore()
def tree(c, x, y, r):
    c.arc(x + 3, y + 5, r, 0, 2 * math.pi); rgba(c, (0, 0, 0), 0.3); c.fill()
    c.arc(x, y, r, 0, 2 * math.pi); rgba(c, hx("#173E66")); c.fill()
    c.arc(x - r * 0.3, y - r * 0.3, r * 0.5, 0, 2 * math.pi); rgba(c, hx("#22548A"), 0.7); c.fill()
def N_static(c):
    ground(c); r = np.random.default_rng(5)
    ix, iy = CX / K["N"], CY / K["N"]
    for x in (-RX_N, RX_N): road_v(c, x, -CY, CY, RW_N)
    for y in (-RY_N, RY_N, -900, 900): road_h(c, y, -CX, CX, RW_N)
    rgba(c, WHITE, 0.08); c.set_line_width(2)
    for x in (-RX_N, RX_N):
        for e in (-1, 1): c.move_to(x + e * RW_N / 2, -CY); c.line_to(x + e * RW_N / 2, CY)
    for y in (-RY_N, RY_N, -900, 900):
        for e in (-1, 1): c.move_to(-CX, y + e * RW_N / 2); c.line_to(CX, y + e * RW_N / 2)
    c.stroke()
    for x in (-RX_N, RX_N): dashes_v(c, x, -CY, CY, [-RY_N, RY_N, -900, 900])
    for y in (-RY_N, RY_N, -900, 900): dashes_h(c, y, -CX, CX, [-RX_N, RX_N])
    xs = [(-CX, -RX_N - RW_N / 2), (-RX_N + RW_N / 2, RX_N - RW_N / 2), (RX_N + RW_N / 2, CX)]
    ys = [(-850, -RY_N - RW_N / 2), (-RY_N + RW_N / 2, RY_N - RW_N / 2), (RY_N + RW_N / 2, 850)]
    for (x0, x1) in xs:
        for (y0, y1) in ys:
            if x0 < 0 < x1 and y0 < 0 < y1: continue         # the inset (parking lot) cell
            fill_rr(c, x0 + 12, y0 + 12, x1 - x0 - 24, y1 - y0 - 24, 18, hx("#0D1C3D"))
            for gx in np.arange(x0 + 70, x1 - 40, 120):
                for gy in np.arange(y0 + 70, y1 - 40, 125):
                    if r.random() < 0.82:
                        house(c, gx + r.uniform(-8, 8), gy + r.uniform(-6, 6), r.uniform(58, 72), r.uniform(50, 60), r.choice([0, math.pi / 2]))
                    else:
                        tree(c, gx, gy, r.uniform(16, 24))
                    if r.random() < 0.5: tree(c, gx + 52, gy + 50, r.uniform(9, 14))
    inset(c, "N", lambda: paint_static(c, "P"))
    rrect(c, -ix + 6, -iy + 6, 2 * ix - 12, 2 * iy - 12, 18); rgba(c, SKY, 0.0); c.stroke()
PATH_N = Loop(RX_N - 24, RY_N - 24, 70)            # you: inner (right hand) lane, clockwise
PATH_N_OUT = Loop(RX_N + 24, RY_N + 24, 118)
V_N = 165.0

# --- C: the city
RW_C = 80
RXS_C = [-820, -520, -220, 220, 520, 820]; RYS_C = [-1260, -960, -660, -360, 360, 660, 960, 1260]
def building(c, x, y, w, h, ht, r):
    sx, sy = ht * 0.10, ht * 0.16
    c.move_to(x, y + h); c.line_to(x + sx, y + h + sy); c.line_to(x + w + sx, y + h + sy); c.line_to(x + w + sx, y + sy); c.line_to(x + w, y); c.line_to(x + w, y + h); c.close_path()
    rgba(c, (0, 0, 0), 0.45); c.fill()
    fill_rr(c, x, y, w, h, 4, hx("#22386A"))
    fill_rr(c, x + 4, y + 4, w - 8, h - 8, 3, hx("#2A447D"))
    for wx in np.arange(x + 9, x + w - 9, 12):
        for wy in np.arange(y + 9, y + h - 9, 14):
            if r.random() < 0.33: rgba(c, SKYHI, r.uniform(0.25, 0.7)); c.rectangle(wx, wy, 5, 6); c.fill()
def C_static(c):
    ground(c); r = np.random.default_rng(9)
    for x in RXS_C: road_v(c, x, -CY, CY, RW_C)
    for y in RYS_C: road_h(c, y, -CX, CX, RW_C)
    for x in RXS_C: dashes_v(c, x, -CY, CY, RYS_C, a=0.3, per=40)
    for y in RYS_C: dashes_h(c, y, -CX, CX, RXS_C, a=0.3, per=40)
    rgba(c, WHITE, 0.22)                                    # crosswalks
    for x in RXS_C:
        for y in RYS_C:
            if abs(x) > 700 or abs(y) > 1100: continue
            for k in range(-3, 4):
                c.rectangle(x + k * 10 - 3, y - RW_C / 2 - 16, 6, 12); c.rectangle(x + k * 10 - 3, y + RW_C / 2 + 4, 6, 12)
    c.fill()
    xs = [-1100] + RXS_C + [1100]; ys = [-1500] + RYS_C + [1500]
    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            x0, x1 = xs[i] + RW_C / 2, xs[i + 1] - RW_C / 2; y0, y1 = ys[j] + RW_C / 2, ys[j + 1] - RW_C / 2
            if x1 < -CX - 50 or x0 > CX + 50 or y1 < -CY - 50 or y0 > CY + 50: continue
            if x0 < 0 < x1 and y0 < 0 < y1: continue        # the inset (neighborhood) cell
            fill_rr(c, x0 + 6, y0 + 6, x1 - x0 - 12, y1 - y0 - 12, 8, hx("#0E1E42"))
            nx, ny = (2 if x1 - x0 > 160 else 1), (2 if y1 - y0 > 160 else 1)
            cw, ch = (x1 - x0 - 24) / nx, (y1 - y0 - 24) / ny
            for a in range(nx):
                for b in range(ny):
                    bx, by = x0 + 12 + a * cw, y0 + 12 + b * ch
                    building(c, bx + 6, by + 6, cw - 12 - r.uniform(0, 18), ch - 12 - r.uniform(0, 18), r.uniform(60, 220), r)
    inset(c, "C", lambda: paint_static(c, "N"))
PATH_C = Loop(220 - 18, 360 - 18, 40)              # you, inner lane of the ring
PATH_C_OUT = Loop(220 + 18, 360 + 18, 76)
V_C = 120.0
CITY_CARS = []
for i in range(46):
    if i % 2:
        x = float(rng.choice(RXS_C[1:-1])); d = int(rng.choice([-1, 1]))
        if abs(x) == 220 and d == 1: d = -1
        CITY_CARS.append(dict(ax="v", c=x - d * 18 * (1 if x > 0 else 1), d=d, p0=rng.uniform(-1100, 1100), v=rng.uniform(95, 140), col=CAR_COLS[i % 5]))
    else:
        y = float(rng.choice(RYS_C[1:-1])); d = int(rng.choice([-1, 1]))
        CITY_CARS.append(dict(ax="h", c=y + d * 18, d=d, p0=rng.uniform(-700, 700), v=rng.uniform(95, 140), col=CAR_COLS[i % 5]))
for cc in CITY_CARS:                                    # keep ring roads clear of your lane
    if cc["ax"] == "v" and abs(cc["c"]) < 260: cc["c"] = (220 + 18) * (1 if cc["c"] > 0 else -1)
    if cc["ax"] == "h" and abs(abs(cc["c"]) - 360) < 30: cc["c"] = (360 + 18) * (1 if cc["c"] > 0 else -1)

# --- H: the highway
LANES_H = [30, 170, 310, 450]; HW0, HW1 = -40, 520
def H_static(c): pass

def build_statics():
    STAT["P"] = mk_static(P_static); STAT["N"] = mk_static(N_static); STAT["C"] = mk_static(C_static)

# ------------------------------------------------------------------ schedules (bubbles, convos, signals)
BUB = []          # dict(t0, t1, who, text, hero)
def addb(t0, t1, who, text): BUB.append(dict(t0=t0, t1=t1, who=who, text=text, hero=(who == "hero")))
p0 = SC0["P"]; pd = SC1["P"] - p0
addb(p0 + pd * 0.30, p0 + pd * 0.48, "hero", BUBBLES_P[0])
addb(p0 + pd * 0.72, p0 + pd * 0.95, "hero", BUBBLES_P[1])
n0 = SC0["N"] + TR + 0.2; n1 = SC1["N"] - 0.4
wts = [1.5, 1.4, 1.4, 1.0, 0.9, 0.85, 0.85]; tot = sum(wts); EV_N = []; tt_ = n0
for (lab, you, them), w_ in zip(CONVOS_N, wts):
    d = (n1 - n0) * w_ / tot; EV_N.append(dict(lab=lab, t0=tt_, t1=tt_ + d));
    addb(tt_ + d * 0.06, tt_ + d * 0.58, "hero", you); addb(tt_ + d * 0.46, tt_ + d * 0.98, "nb", them)
    EV_N[-1]["tc"] = tt_ + d * 0.46; tt_ += d
c0 = SC0["C"] + TR + 0.3; cd = SC1["C"] - 0.4 - c0; step = cd / (len(MEETING_C) + 0.6)
for i, (who, line) in enumerate(MEETING_C):
    addb(c0 + i * step, c0 + i * step + step * 1.55, "hero" if who == "you" else who, line)
h0 = SC0["H"]; hd = SC1["H"] - h0
HB0 = h0 + TR + 3.0; step = (SC1["H"] - 0.4 - HB0) / (len(PITCH_H) + 0.5)
for i, (who, line) in enumerate(PITCH_H):
    addb(HB0 + i * step, HB0 + i * step + step * 1.4, "hero" if who == "you" else "partner", line)
LANE_T0, LANE_T1 = h0 + TR + 0.9, h0 + TR + 1.9     # lane change with the signal on
SIGNALS = [(SC0["freeze"], SC1["freeze"], "hazard"), (SC0["N"] + TR, SC0["N"] + TR + 1.4, "blink"), (h0 + TR + 0.2, LANE_T1, "blink")]
def sig_on(t, kind):
    return any(a <= t < b and k == kind for a, b, k in SIGNALS)

def speed_at(t):
    """speedometer, km/h"""
    pts = [(0, 0), (SC0["P"], 0), (SC0["P"] + 1.0, 10), (SC0["N"] + 0.4, 10), (SC0["N"] + 1.6, 25), (SC0["C"] + 0.4, 25), (SC0["C"] + 1.6, 50),
           (SC0["H"] + 0.4, 50), (SC0["H"] + TR, 62), (SC0["H"] + TR + 4.5, 110), (TT, 110)]
    for (a, va), (b, vb) in zip(pts, pts[1:]):
        if a <= t <= b: return lerp(va, vb, smooth((t - a) / max(1e-6, b - a)))
    return 0
_hs = np.arange(0, hd + 2, 1 / FPS); _v = np.array([0 if s < TR * 0.85 else speed_at(h0 + s) * 8.5 for s in _hs])
H_SCROLL = np.concatenate([[0], np.cumsum(_v[:-1] / FPS)])
def h_scroll(ts): return float(np.interp(ts, _hs, H_SCROLL))
H_CARS = [dict(lane=l, y0=rng.uniform(-1400, 1400), k=k, col=CAR_COLS[i % 5], truck=(i % 4 == 0))
          for i, (l, k) in enumerate([(0, .72), (0, .80), (0, .66), (3, .85), (3, .76), (3, .90), (0, .58), (3, .70)])]

# ------------------------------------------------------------------ stage drawing (live)
ANCH = {}
def scr(ctx, x, y): return ctx.user_to_device(x, y)

def draw_P(ctx, t, hero_a, top):
    paint_static(ctx, "P"); ts = t - SC0["P"]
    ctx.set_line_width(3); rgba(ctx, SKY, 0.16); ctx.set_dash([6, 14])        # your tire track
    for i, (x, y) in enumerate(PATH_P.P[::6]):
        ctx.line_to(x, y) if i else ctx.move_to(x, y)
    ctx.close_path(); ctx.stroke(); ctx.set_dash([])
    s = 60 + ts * V_P; x, y, a = PATH_P.at(s)
    if top and t >= BSTART["park2"]:                                           # lift your head: look around
        el = t - BSTART["park2"] - 0.4
        for k in range(3):
            u = ((el * 0.5 + k / 3) % 1) if el > 0 else -1
            if u >= 0:
                ctx.arc(x, y, 60 + u * 520, 0, 2 * math.pi); rgba(ctx, SKY, 0.30 * (1 - u) * clamp(el / 0.8)); ctx.set_line_width(3); ctx.stroke()
    car(ctx, x, y, a, SKY, 96, 52, hero_a, hero=True, t=t)
    if top: ANCH["hero"] = scr(ctx, x, y) + (hero_a, 1.0)

def draw_N(ctx, t, hero_a, top, live_inset=None):
    paint_static(ctx, "N"); ts = t - SC0["N"]
    if live_inset: inset(ctx, "N", live_inset)
    s = 1500 + max(0, ts - TR * 0.55) * V_N; x, y, a = PATH_N.at(s)
    car(ctx, x, y, a, SKY, 60, 32, hero_a, hero=True, t=t, blink=(1 if sig_on(t, "blink") else None))
    if top: ANCH["hero"] = scr(ctx, x, y) + (hero_a, 1.0)
    for i, e in enumerate(EV_N):                                                # one driver at a time
        if not (e["t0"] - 0.1 <= t <= e["t1"] + 0.6): continue
        el = t - e["t0"]; d = e["t1"] - e["t0"]
        off = lerp(-170, 0, ease(el / 0.45)) + lerp(0, 330, smooth((el - d + 0.15) / 0.7))
        al = clamp(el / 0.3) * (1 - clamp((el - d) / 0.55))
        k = PATH_N_OUT.L / PATH_N.L; nx, ny, na = PATH_N_OUT.at((s + 6) * k + off)
        car(ctx, nx, ny, na, CAR_COLS[i % 5], 60, 32, al, t=t)
        if top: ANCH["nb"] = scr(ctx, nx, ny) + (al, 1.0); ANCH["nb_label"] = (e["lab"],) + scr(ctx, nx, ny) + (al,)
    # a few parked / passing cars for life
    for j, (sx, col) in enumerate([(900, CAR_COLS[3]), (2100, CAR_COLS[2])]):
        k = PATH_N_OUT.L / PATH_N.L; px, py, pa = PATH_N_OUT.at(-(ts * 120) * k + sx)
        car(ctx, px, py, pa + math.pi, col, 60, 32, 0.9, t=t)

def city_cars(ctx, t):
    for cc in CITY_CARS:
        p = ((cc["p0"] + cc["d"] * cc["v"] * t + 1100) % 2200) - 1100
        if cc["ax"] == "v": x, y, a = cc["c"], p, (math.pi / 2 if cc["d"] > 0 else -math.pi / 2)
        else: x, y, a = p * (0.66), cc["c"], (0 if cc["d"] > 0 else math.pi)
        if abs(x) < 200 and abs(y) < 340: continue
        car(ctx, x, y, a, cc["col"], 50, 27, 1.0, t=t)
    for i, x in enumerate(RXS_C[1:-1]):                                          # traffic lights
        for j, y in enumerate(RYS_C[2:-2]):
            ph = int((t / 2.6 + (i + j) * 0.5)) % 2
            bx, by = x + RW_C / 2 + 6, y - RW_C / 2 - 34
            fill_rr(ctx, bx, by, 16, 30, 5, NAVY0, 0.95)
            for q, col in enumerate([RED, hx("#38D39F")]):
                lit = (q == 0) == (ph == 0)
                if lit: glow(ctx, bx + 8, by + 8 + q * 14, 16, col, 0.6)
                ctx.arc(bx + 8, by + 8 + q * 14, 4.5, 0, 2 * math.pi); rgba(ctx, col, 1.0 if lit else 0.22); ctx.fill()

def draw_C(ctx, t, hero_a, top, live_inset=None):
    paint_static(ctx, "C")
    if live_inset: inset(ctx, "C", live_inset)
    city_cars(ctx, t); ts = t - SC0["C"]
    s = 300 + max(0, ts - TR * 0.55) * V_C; x, y, a = PATH_C.at(s)
    pr = 0.5 + 0.5 * math.sin(t * 5)
    ctx.arc(x, y, 46 + 8 * pr, 0, 2 * math.pi); rgba(ctx, SKY, 0.55 * hero_a); ctx.set_line_width(3); ctx.stroke()
    car(ctx, x, y, a, SKY, 56, 30, hero_a, hero=True, t=t)
    if top: ANCH["hero"] = scr(ctx, x, y) + (hero_a, 1.0)
    k = PATH_C_OUT.L / PATH_C.L; al = clamp((ts - TR) / 0.6)
    for lab, off in (("client", -70), ("team", 60)):                          # the meeting rides with you
        nx, ny, na = PATH_C_OUT.at((s + off) * k)
        car(ctx, nx, ny, na, CAR_COLS[0 if lab == "client" else 3], 50, 27, al * hero_a, t=t)
        if top: ANCH[lab] = scr(ctx, nx, ny) + (al * hero_a, 1.0); ANCH[lab + "_label"] = (lab,) + scr(ctx, nx, ny) + (al * hero_a,)

def draw_H(ctx, t, hero_a, top, cam, s_, live_inset=None):
    ts = t - SC0["H"]; sc = h_scroll(ts)
    x0, x1 = cam[0] - CX / s_ - 10, cam[0] + CX / s_ + 10; y0, y1 = cam[1] - CY / s_ - 10, cam[1] + CY / s_ + 10
    ground(ctx, x0, y0, x1 - x0, y1 - y0)
    hr = np.random.default_rng(1)
    TS = 420                                                                    # fields and blocks scrolling by
    for j in range(int(math.floor(y0 / TS)) - 1, int(math.ceil(y1 / TS)) + 1):
        r = np.random.default_rng(1000 + j)
        for side, (a0, a1) in enumerate([(-1100, -110), (590, 1300)]):
            for q in range(3):
                bx = r.uniform(a0, a1 - 160); by = j * TS + r.uniform(0, TS - 160); bw, bh = r.uniform(90, 200), r.uniform(80, 180)
                if side == 0 and by < 420 and by + bh > -420 and bx + bw > -560: continue
                fill_rr(ctx, bx, by, bw, bh, 10, hx("#0E1E42") if q else hx("#122650"))
    _ = hr
    if live_inset: inset(ctx, "H", live_inset)
    else: inset(ctx, "H", lambda: (paint_static(ctx, "C"), city_cars(ctx, t)))
    rgba(ctx, hx("#0C1A3A")); ctx.rectangle(HW0 - 24, y0, HW1 - HW0 + 48, y1 - y0); ctx.fill()
    rgba(ctx, ROAD); ctx.rectangle(HW0, y0, HW1 - HW0, y1 - y0); ctx.fill()
    rgba(ctx, WHITE, 0.55); ctx.set_line_width(4)
    for xx in (HW0 + 10, HW1 - 10): ctx.move_to(xx, y0); ctx.line_to(xx, y1)
    ctx.stroke()
    v = speed_at(t); blur = clamp((v - 60) / 50)
    per = 170; dl = 80 + blur * 70
    for xx in (100, 240, 380):
        for k in range(int(y0 // per) - 1, int(y1 // per) + 2):
            ctx.move_to(xx, k * per); ctx.line_to(xx, k * per + dl)
        rgba(ctx, WHITE, 0.5); ctx.set_line_width(5); ctx.stroke()
    if blur > 0:                                                                # speed streaks
        for q in range(14):
            r = np.random.default_rng(q); sx = r.uniform(HW0 + 20, HW1 - 20)
            yy = cam[1] + ((r.uniform(0, 2200) - sc * 1.6) % 2200) - 1100
            ctx.move_to(sx, yy); ctx.line_to(sx, yy + 120 + 200 * blur); rgba(ctx, SKYHI, 0.10 * blur); ctx.set_line_width(2); ctx.stroke()
    hy = -sc + 110                                                              # you
    lane_u = smooth((t - LANE_T0) / (LANE_T1 - LANE_T0)); hxp = lerp(LANES_H[1], LANES_H[2], lane_u)
    for cc in H_CARS:
        rel = ((cc["y0"] + (1 - cc["k"]) * sc + 1500) % 3000) - 1500
        if cc["truck"]: truck(ctx, LANES_H[cc["lane"]], hy + rel, -math.pi / 2, 230, 74)
        else: car(ctx, LANES_H[cc["lane"]], hy + rel, -math.pi / 2, cc["col"], 88, 46, 1.0, t=t)
    pt = t - (h0 + TR + 2.0)
    if pt > 0:                                                                  # the investor pulls up beside you
        rel = lerp(1000, 40, ease(pt / 1.8)) + 20 * math.sin(pt * 1.3)
        car(ctx, LANES_H[1], hy + rel, -math.pi / 2, CAR_COLS[0], 88, 46, 1.0, t=t)
        if top: ANCH["partner"] = scr(ctx, LANES_H[1], hy + rel) + (1.0, 1.0); ANCH["partner_label"] = ("investor",) + scr(ctx, LANES_H[1], hy + rel) + (1.0,)
    wob = math.sin(lane_u * math.pi) * 0.22
    car(ctx, hxp, hy, -math.pi / 2 + wob, SKY, 88, 46, hero_a, hero=True, t=t, blink=(1 if sig_on(t, "blink") else None))
    if top: ANCH["hero"] = scr(ctx, hxp, hy) + (hero_a, 1.0)

def stage_T(ctx, s, cam):
    ctx.translate(CX - cam[0] * s, CY - cam[1] * s); ctx.scale(s, s)

def world(ctx, t, sc):
    """sc in P/N/C/H: draws that stage, zooming out of the previous one during its first TR seconds"""
    ts = t - SC0[sc]
    if sc == "P":
        ctx.save(); stage_T(ctx, 1.0, (0, 0)); draw_P(ctx, t, 1.0, True); ctx.restore(); return
    u = smooth(ts / TR); prev = {"N": "P", "C": "N", "H": "C"}[sc]
    Kz = K[sc]; s = Kz ** (1 - u); c = INSET[sc]
    a_prev = 1 - smooth((u - 0.2) / 0.3); a_new = smooth((u - 0.55) / 0.35)
    top = u > 0.97
    if u < 1:
        live = {"P": lambda: draw_P(ctx, t, a_prev, False), "N": lambda: draw_N(ctx, t, a_prev, False),
                "C": lambda: draw_C(ctx, t, a_prev, False)}[prev]
    else: live = None
    ctx.save()
    if sc == "H":
        cam_end = (240.0, 0.0); cam = (lerp(c[0], cam_end[0], u), lerp(c[1], cam_end[1], u) - h_scroll(ts))
        stage_T(ctx, s, cam); draw_H(ctx, t, a_new, top, cam, s, live)
    else:
        cam = (lerp(c[0], 0, u), lerp(c[1], 0, u)); stage_T(ctx, s, cam)
        (draw_N if sc == "N" else draw_C)(ctx, t, a_new, top, live)
    ctx.restore()

# ------------------------------------------------------------------ hook / freeze: day one on a giant highway
HL = [220, 540, 860]
def hook_world(ctx, t, freeze):
    ground(ctx, 0, 0, W, H)
    rgba(ctx, ROAD); ctx.rectangle(60, -10, 960, H + 20); ctx.fill()
    rgba(ctx, WHITE, 0.6); ctx.set_line_width(8)
    for xx in (80, 1000): ctx.move_to(xx, 0); ctx.line_to(xx, H)
    ctx.stroke(); ctx.set_line_width(10)
    for xx in (380, 700):
        for y in range(-200, H + 200, 430): ctx.move_to(xx, y); ctx.line_to(xx, y + 230)
    ctx.stroke()
    jit = (math.sin(t * 41) * 1.6, math.cos(t * 37) * 1.4) if freeze else (0, 0)
    hxp, hyp = 540 + jit[0], 1060 + jit[1]
    drop = 1 - ease(t / 0.35) if not freeze else 0
    for q in range(10):                                                         # wind streaks
        r = np.random.default_rng(q); sx = r.choice([HL[0], HL[2]]) + r.uniform(-150, 150)
        yy = ((r.uniform(0, 2400) - t * 3200) % 2400) - 240
        ctx.move_to(sx, yy); ctx.line_to(sx, yy + 260); rgba(ctx, SKYHI, 0.12); ctx.set_line_width(3); ctx.stroke()
    sc_ = 1 + 0.8 * drop
    ctx.save(); ctx.translate(hxp, hyp); ctx.scale(sc_, sc_)
    car(ctx, 0, 0, -math.pi / 2, SKY, 70, 38, 1.0, hero=not freeze, hazard=freeze, t=t)
    ctx.restore()
    ANCH["hero"] = (hxp, hyp, 1.0, 1.0)
    for i, (lane, y0, v) in enumerate([(0, 900, 2600), (2, 2300, 2900), (0, 3300, 2600), (2, 4200, 2900)]):
        y = ((y0 - v * t) % 4400) - 900
        truck(ctx, HL[lane], y, -math.pi / 2, 760, 250)
        word = HOOK_TRUCKS[(i + int((t * v - y0 + 900) // 4400)) % len(HOOK_TRUCKS)]
        csprite(ctx, word, 900, fitsize(word, 900, 64, 560), NAVY0, HL[lane] - 22, y + 50, rot=90, alpha=0.85)

# ------------------------------------------------------------------ UI
def overlays(ctx, top=True, bottom=True):
    if top:
        g = cairo.LinearGradient(0, 0, 0, 420); g.add_color_stop_rgba(0, *cf(NAVY0), 0.92); g.add_color_stop_rgba(0.55, *cf(NAVY0), 0.6); g.add_color_stop_rgba(1, *cf(NAVY0), 0)
        ctx.set_source(g); ctx.rectangle(0, 0, W, 420); ctx.fill()
    if bottom:
        g = cairo.LinearGradient(0, 1200, 0, H); g.add_color_stop_rgba(0, *cf(NAVY0), 0); g.add_color_stop_rgba(0.35, *cf(NAVY0), 0.78); g.add_color_stop_rgba(1, *cf(NAVY0), 0.96)
        ctx.set_source(g); ctx.rectangle(0, 1200, W, H - 1200); ctx.fill()
    g = cairo.RadialGradient(CX, CY, 500, CX, CY, 1250); g.add_color_stop_rgba(0, 0, 0, 0, 0); g.add_color_stop_rgba(1, 0, 0, 0, 0.45)
    ctx.set_source(g); ctx.rectangle(0, 0, W, H); ctx.fill()

TRK_X = [282, 454, 626, 798]; TRK_Y = 176
def tracker(ctx, t, states):
    """states: per stage 'off' | 'on' | 'done' | 'wrong'"""
    for i in range(3):                                                         # chevrons P > N > C > H
        mx = (TRK_X[i] + TRK_X[i + 1]) / 2; lit = states[i + 1] in ("on", "done")
        ctx.move_to(mx - 7, TRK_Y - 11); ctx.line_to(mx + 5, TRK_Y); ctx.line_to(mx - 7, TRK_Y + 11)
        rgba(ctx, SKY if lit else DIM, 0.9 if lit else 0.6); ctx.set_line_width(4); ctx.set_line_cap(cairo.LINE_CAP_ROUND); ctx.stroke()
    for i, (x, (ab, en, he)) in enumerate(zip(TRK_X, STAGES)):
        st = states[i]
        if st == "on":
            glow(ctx, x, TRK_Y, 70, SKY, 0.55); ctx.arc(x, TRK_Y, 34, 0, 2 * math.pi); rgba(ctx, SKY); ctx.fill()
            qt(ab, 900, 38, NAVY0, x, TRK_Y - 2); qt(he, 700, 28, WHITE, x, TRK_Y + 62)
        elif st == "wrong":
            p = 0.5 + 0.5 * math.sin(t * 8)
            glow(ctx, x, TRK_Y, 70, RED, 0.35 + 0.3 * p); ctx.arc(x, TRK_Y, 34, 0, 2 * math.pi); rgba(ctx, RED); ctx.fill()
            qt(ab, 900, 38, WHITE, x, TRK_Y - 2); qt(he, 700, 28, hx("#F19AB0"), x, TRK_Y + 62)
        elif st == "done":
            ctx.arc(x, TRK_Y, 32, 0, 2 * math.pi); rgba(ctx, PANEL2); ctx.fill_preserve(); rgba(ctx, SKY); ctx.set_line_width(4); ctx.stroke()
            qt(ab, 900, 36, SKY, x, TRK_Y - 2); qt(he, 700, 28, MUTED, x, TRK_Y + 62)
        else:
            ctx.arc(x, TRK_Y, 32, 0, 2 * math.pi); rgba(ctx, PANEL, 0.9); ctx.fill_preserve(); rgba(ctx, DIM, 0.8); ctx.set_line_width(3); ctx.stroke()
            qt(ab, 900, 36, DIM, x, TRK_Y - 2); qt(he, 700, 28, DIM, x, TRK_Y + 62)

def speedo(ctx, t, v, auto, alpha=1.0, cx=932, cy=430, R=74):
    if alpha <= 0.01: return
    a0, a1 = math.radians(135), math.radians(405)
    fill_rr(ctx, cx - R - 18, cy - R - 18, 2 * R + 36, 2 * R + 64, 34, NAVY0, 0.72 * alpha)
    ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    ctx.arc(cx, cy, R, a0, a1); rgba(ctx, DIM, 0.5 * alpha); ctx.set_line_width(9); ctx.stroke()
    f = clamp(v / 130)
    if f > 0.004: ctx.arc(cx, cy, R, a0, a0 + (a1 - a0) * f); rgba(ctx, SKY, alpha); ctx.set_line_width(9); ctx.stroke()
    for k in range(14):
        aa = a0 + (a1 - a0) * k / 13; ctx.move_to(cx + math.cos(aa) * (R - 18), cy + math.sin(aa) * (R - 18)); ctx.line_to(cx + math.cos(aa) * (R - 12), cy + math.sin(aa) * (R - 12))
    rgba(ctx, MUTED, 0.6 * alpha); ctx.set_line_width(2); ctx.stroke()
    qt(f"{int(round(v))}", 900, 54, WHITE, cx, cy - 4, alpha); qt("km/h", 700, 20, MUTED, cx, cy + 34, alpha)
    if auto > 0.01:
        fill_rr(ctx, cx - 44, cy + R + 2, 88, 32, 16, SKY, auto * alpha); glow(ctx, cx, cy + R + 18, 60, SKY, 0.35 * auto * alpha)
        qt("AUTO", 900, 22, NAVY0, cx, cy + R + 17, auto * alpha)
    else:
        rrect(ctx, cx - 44, cy + R + 2, 88, 32, 16); rgba(ctx, DIM, 0.6 * alpha); ctx.set_line_width(2); ctx.stroke()
        qt("AUTO", 900, 22, DIM, cx, cy + R + 17, alpha)

def counter(ctx, t, alpha):
    n = sum(1 for e in EV_N if t >= e["tc"])
    if alpha <= 0.01: return
    cx, cy = 148, 430
    fill_rr(ctx, cx - 92, cy - 92, 184, 202, 34, NAVY0, 0.72 * alpha)
    last = max([e["tc"] for e in EV_N if t >= e["tc"]], default=-9); pop = 1 + 0.25 * (1 - ease((t - last) / 0.3))
    qt(str(n), 900, 92, SKY if n else DIM, cx, cy - 22, alpha, scale=pop)
    qt("conversations" if n != 1 else "conversation", 700, 22, WHITE, cx, cy + 38, alpha)
    qt("שיחות" if n != 1 else "שיחה", 700, 20, MUTED, cx, cy + 64, alpha)
    for k in range(7):
        x = cx - 60 + k * 20; ctx.arc(x, cy + 92, 5, 0, 2 * math.pi); rgba(ctx, SKY if k < n else DIM, alpha * (1 if k < n else 0.6)); ctx.fill()

def stage_tab(ctx, idx, alpha):
    if alpha <= 0.01: return
    ab, en, he = STAGES[idx]; lab = f"STAGE {idx + 1}  ·  {en}"
    w1 = tw_(lab, 900, 30); w2 = tw_(he, 700, 30); w = w1 + w2 + 150; x0 = CX - w / 2; y = 1356; h = 58
    ctx.move_to(x0 + 18, y); ctx.line_to(x0 + w, y); ctx.line_to(x0 + w - 18, y + h); ctx.line_to(x0, y + h); ctx.close_path()
    rgba(ctx, SKY, alpha); ctx.fill()
    qt(lab, 900, 30, NAVY0, x0 + 40, y + h / 2 - 1, alpha, align="l")
    sx_ = x0 + 40 + w1 + 35; ctx.move_to(sx_, y + 14); ctx.line_to(sx_ - 6, y + h - 14); rgba(ctx, NAVY0, 0.5 * alpha); ctx.set_line_width(2); ctx.stroke()
    qt(he, 700, 30, NAVY0, x0 + w - 40, y + h / 2 - 1, alpha, align="r")

def captions(ctx, t, key):
    caps = BY[key]["cap"]
    if not caps: return
    b0, b1 = BSTART[key], BEND[key]; d = b1 - b0
    ts = [(b0 + (c[0] if key == "hook" else c[0] * d)) for c in caps]
    if key == "hook": ts = [0.0, min(HOOK_MAX, b1)]
    for i, (st, c) in enumerate(zip(ts, caps)):
        en_ = ts[i + 1] if i + 1 < len(ts) else b1
        if not (st <= t < en_ + 0.2): continue
        a = (1.0 if (key == "hook" and i == 0) else ease((t - st) / 0.3)) * (1 - clamp((t - en_) / 0.2))
        dy = 0 if key == "hook" and i == 0 else 16 * (1 - ease((t - st) / 0.3))
        lines = wrap(c[1], 900, 64, 960)
        y = 1478 if len(lines) == 1 else 1450
        for j, ln in enumerate(lines): qt(ln, 900, 64, WHITE, CX, y + dy + j * 74, a)
        qt(c[2], 700, 40, MUTED, CX, y + dy + (len(lines) - 1) * 74 + 80, a)

def bubble(ctx, t, b, ax, ay, a0):
    el = t - b["t0"]; a = ease(el / 0.18) * (1 - clamp((t - b["t1"] + 0.2) / 0.2)) * a0
    if a <= 0.01: return
    lines = wrap(b["text"], 700, 36, 560); tw = max(tw_(l, 700, 36) for l in lines)
    bw, bh = tw + 56, 30 + 46 * len(lines)
    side = -1 if b["hero"] else 1
    bx = ax + side * (bw / 2 - 56) if b["who"] != "hero" or True else ax
    bx = max(30 + bw / 2, min(W - 30 - bw / 2, bx)); by = ay - 70 - bh / 2
    if by - bh / 2 < 300: by = ay + 70 + bh / 2; up = False
    else: up = True
    sc = 0.75 + 0.25 * ease(el / 0.22)
    ctx.save(); ctx.translate(ax, ay - 40 if up else ay + 40); ctx.scale(sc, sc); ctx.translate(-ax, -(ay - 40 if up else ay + 40))
    col = SKY if b["hero"] else WHITE
    ctx.push_group()
    rrect(ctx, bx - bw / 2 + 4, by - bh / 2 + 8, bw, bh, 26); rgba(ctx, (0, 0, 0), 0.35); ctx.fill()
    rrect(ctx, bx - bw / 2, by - bh / 2, bw, bh, 26); rgba(ctx, col); ctx.fill()
    ty = by + bh / 2 - 2 if up else by - bh / 2 + 2; tx = max(bx - bw / 2 + 30, min(bx + bw / 2 - 30, ax))
    ctx.move_to(tx - 14, ty); ctx.line_to(tx + 14, ty); ctx.line_to(ax, ay - 36 if up else ay + 36); ctx.close_path(); rgba(ctx, col); ctx.fill()
    ctx.pop_group_to_source(); ctx.paint_with_alpha(a); ctx.restore()
    pivot_y = ay - 40 if up else ay + 40
    for j, ln in enumerate(lines):
        ly = by - (len(lines) - 1) * 23 + j * 46
        qt(ln, 700, 36, NAVY0, ax + (bx - ax) * sc, pivot_y + (ly - pivot_y) * sc, a, scale=sc)

def label(ctx, name, x, y, a):
    if a <= 0.01: return
    w = tw_(name, 800, 24) + 30; y = y + 46
    fill_rr(ctx, x - w / 2, y - 18, w, 36, 18, NAVY0, 0.88 * a); rrect(ctx, x - w / 2, y - 18, w, 36, 18); rgba(ctx, SKY, a); ctx.set_line_width(2); ctx.stroke()
    qt(name, 800, 24, SKYHI, x, y - 1, a)

# ------------------------------------------------------------------ map + cta
NODES_Y = [1170, 960, 750, 540]; NODE_X = 330
def mini_icon(ctx, i, x, y, col, a):
    ctx.save(); ctx.translate(x, y); rgba(ctx, col, a); ctx.set_line_width(5); ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    if i == 0:
        rrect(ctx, -36, -30, 72, 60, 10); ctx.stroke()
        for k in range(3): ctx.move_to(-20 + k * 20, -30); ctx.line_to(-20 + k * 20, -8)
        ctx.stroke()
    elif i == 1:
        ctx.move_to(-30, -2); ctx.line_to(0, -30); ctx.line_to(30, -2); ctx.stroke(); ctx.rectangle(-22, -4, 44, 34); ctx.stroke()
    elif i == 2:
        for bx, bh in ((-34, 40), (-8, 64), (18, 50)): ctx.rectangle(bx, 32 - bh, 20, bh); ctx.stroke()
    else:
        ctx.move_to(-14, -32); ctx.line_to(-34, 32); ctx.move_to(14, -32); ctx.line_to(34, 32); ctx.stroke()
        for k in range(3): ctx.move_to(0, -28 + k * 22); ctx.line_to(0, -18 + k * 22)
        ctx.stroke()
    ctx.restore()
def map_scene(ctx, t):
    ground(ctx, 0, 0, W, H)
    for y in range(0, H, 80):
        ctx.move_to(0, y); ctx.line_to(W, y)
    for x in range(0, W, 80):
        ctx.move_to(x, 0); ctx.line_to(x, H)
    rgba(ctx, WHITE, 0.025); ctx.set_line_width(1); ctx.stroke()
    b0, d = BSTART["close"], BEND["close"] - BSTART["close"]; nt = [b0 + f * d for f in BY["close"]["names"]]
    a = ease((t - b0) / 0.5)
    qt("THE ENGLISH EXPRESS METHOD", 900, 34, SKY, CX, 300, a); qt("השיטה של אינגליש אקספרס", 700, 30, MUTED, CX, 350, a)
    rgba(ctx, ROAD, a); ctx.rectangle(NODE_X - 26, NODES_Y[3], 52, NODES_Y[0] - NODES_Y[3]); ctx.fill()
    prog = 0.0
    for i in range(4):
        if t >= nt[i]: prog = i + (min(1, ease((t - nt[i]) / 0.6)) if i < 3 and t >= nt[i] + 0 and i + 1 < 4 and t >= nt[i + 1] - 0.6 else 0)
    hy = NODES_Y[0]
    lit = [t >= x for x in nt]
    k = sum(lit) - 1
    if k >= 0:
        frac = 0 if k == 3 else clamp((t - nt[k]) / max(0.3, nt[min(3, k + 1)] - nt[k]))
        hy = lerp(NODES_Y[k], NODES_Y[min(3, k + 1)], smooth(frac) * 0.35) if k < 3 else NODES_Y[3]
    rgba(ctx, SKY, 0.85 * a); ctx.rectangle(NODE_X - 5, hy, 10, NODES_Y[0] - hy); ctx.fill()
    ctx.set_dash([18, 18]); rgba(ctx, WHITE, 0.35 * a); ctx.set_line_width(3); ctx.move_to(NODE_X, NODES_Y[3]); ctx.line_to(NODE_X, hy); ctx.stroke(); ctx.set_dash([])
    for i, y in enumerate(NODES_Y):
        on = lit[i]; ap = ease((t - b0 - 0.15 * i) / 0.4); pop = 1 + 0.12 * (1 - ease((t - nt[i]) / 0.35)) if on else 1
        ctx.save(); ctx.translate(NODE_X, y); ctx.scale(pop, pop)
        if on: glow(ctx, 0, 0, 150, SKY, 0.4 * ap)
        fill_rr(ctx, -78, -78, 156, 156, 36, SKY if on else PANEL, ap)
        if not on: rrect(ctx, -78, -78, 156, 156, 36); rgba(ctx, DIM, ap); ctx.set_line_width(3); ctx.stroke()
        ctx.restore()
        mini_icon(ctx, i, NODE_X, y, NAVY0 if on else MUTED, ap)
        ab, en, he = STAGES[i]
        qt(en, 900, 58, WHITE if on else DIM, NODE_X + 125, y - 22, ap, align="l", maxw=560)
        qt(he, 700, 40, SKY if on else DIM, NODE_X + 125, y + 36, ap, align="l", maxw=560)
    return nt

def cta_scene(ctx, t):
    ground(ctx, 0, 0, W, H)
    for y in range(0, H, 80):
        ctx.move_to(0, y); ctx.line_to(W, y)
    for x in range(0, W, 80):
        ctx.move_to(x, 0); ctx.line_to(x, H)
    rgba(ctx, WHITE, 0.025); ctx.set_line_width(1); ctx.stroke()
    el = t - BSTART["cta"]
    a = ease(el / 0.4); b = ease((el - 0.3) / 0.4)
    qt("Where are you", 900, 112, WHITE, CX, 470 + 20 * (1 - a), a); qt("today?", 900, 132, SKY, CX, 600 + 20 * (1 - a), a)
    qt("איפה אתם היום?", 700, 54, MUTED, CX, 720, b)
    hl = int(max(0, el - 1.6) / 0.55) % 4 if el > 1.6 else -1
    for i, (ab, en, he) in enumerate(STAGES):
        x = 300 if i % 2 == 0 else 780; y = 900 if i < 2 else 1080; ap = ease((el - 0.5 - i * 0.12) / 0.35)
        on = (i == hl)
        if on: glow(ctx, x, y, 260, SKY, 0.25 * ap)
        fill_rr(ctx, x - 222, y - 74, 444, 148, 32, PANEL2 if not on else SKY, ap)
        rrect(ctx, x - 222, y - 74, 444, 148, 32); rgba(ctx, SKY, ap); ctx.set_line_width(3); ctx.stroke()
        ctx.arc(x - 150, y, 40, 0, 2 * math.pi); rgba(ctx, NAVY0 if on else SKY, ap); ctx.fill()
        qt(ab, 900, 40, SKY if on else NAVY0, x - 150, y - 2, ap)
        qt(en, 900, 38, NAVY0 if on else WHITE, x - 92, y - 20, ap, align="l", maxw=300)
        qt(he, 700, 32, NAVY0 if on else MUTED, x - 92, y + 26, ap, align="l", maxw=300)
    c = ease((el - 1.0) / 0.4)
    qt("Still afraid of...", 900, 72, WHITE, CX, 1260, c); qt("עדיין מפחדים מ...", 700, 48, SKY, CX, 1345, c)

# ------------------------------------------------------------------ frame
SURF = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H)
def to_pil(surf):
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data())
    return Image.fromarray(a[..., [2, 1, 0]].copy(), "RGB")

def stage_states(t, sc):
    order = ["P", "N", "C", "H"]
    if sc in ("hook",): return ["off"] * 4
    if sc == "freeze": return ["off", "off", "off", "wrong"]
    i = order.index(sc); return ["done"] * i + ["on"] + ["off"] * (3 - i)

def render_scene(t, sc):
    """one scene to a PIL image (world + UI)"""
    global ANCH, TXT
    ANCH, TXT = {}, []
    ctx = cairo.Context(SURF); ctx.set_operator(cairo.OPERATOR_SOURCE); rgba(ctx, GROUND); ctx.paint(); ctx.set_operator(cairo.OPERATOR_OVER)
    key = beat_at(t)
    if sc in ("hook", "freeze"):
        hook_world(ctx, t, sc == "freeze")
    elif sc in ("P", "N", "C", "H"):
        world(ctx, t, sc)
    elif sc == "map":
        map_scene(ctx, t)
    else:
        cta_scene(ctx, t)
    ctx = cairo.Context(SURF)
    overlays(ctx, top=sc not in ("cta",), bottom=sc not in ("cta",))
    if sc not in ("map", "cta"):
        tracker(ctx, t, stage_states(t, sc))
    if sc in ("P", "N", "C", "H", "freeze", "hook"):
        hud_a = 1.0 if sc != "hook" else ease((t - 0.6) / 0.3)
        speedo(ctx, t, speed_at(t), clamp((speed_at(t) - 92) / 6) if sc == "H" else 0, hud_a)
    if sc == "N":
        counter(ctx, t, ease((t - SC0["N"] - TR) / 0.4))
    if sc in ("P", "N", "C", "H"):
        idx = "PNCH".index(sc); ts = t - SC0[sc]
        stage_tab(ctx, idx, ease((ts - (0 if sc == "P" else TR * 0.7)) / 0.35))
    if sc == "freeze" and "hero" in ANCH:
        ax, ay = ANCH["hero"][:2]
        bubble(ctx, t, dict(t0=SC0["freeze"] + 0.5, t1=SC1["freeze"] - 0.2, who="hero", text="Uh... um...", hero=True), ax, ay, 1.0)
    for lab in ("nb_label", "client_label", "team_label", "partner_label"):
        if lab in ANCH: n_, x, y, a = ANCH[lab]; label(ctx, n_, x, y, a)
    for b in BUB:
        if b["t0"] <= t <= b["t1"] and b["who"] in ANCH:
            ax, ay, a0 = ANCH[b["who"]][:3]; bubble(ctx, t, b, ax, ay, a0)
    captions(ctx, t, key)
    im = to_pil(SURF)
    for (sp, x, y, a, s, rot) in TXT: put(im, sp, x, y, a, s, rot)
    return im

SCENES = [BY[k]["scene"] for k in KEYS]
CUTS = []                                                                  # crossfade boundaries (no zoom)
for i in range(1, len(KEYS)):
    a_, b_ = SCENES[i - 1], SCENES[i]
    if a_ != b_ and not (b_ in ("N", "C", "H") and a_ in ("P", "N", "C")) and not (a_ == "hook" and b_ == "freeze"):
        CUTS.append((BSTART[KEYS[i]], a_, b_))
def frame(t):
    sc = BY[beat_at(t)]["scene"]
    for (ct, a_, b_) in CUTS:
        if ct - XF / 2 <= t < ct + XF / 2:
            u = smooth((t - (ct - XF / 2)) / XF)
            A_ = render_scene(min(t, ct - 0.001), a_); B_ = render_scene(max(t, ct), b_)
            return Image.blend(A_, B_, u)
    im = render_scene(t, sc)
    if t > TT - LOOPX:   # circular: the last 0.5 s cross-fades into frame 0 (the hook), so the replay is continuous
        im = Image.blend(im, render_scene(0.0, BY[KEYS[0]]["scene"]), smooth((t - (TT - LOOPX)) / LOOPX))
    return im
LOOPX = 0.5

# ------------------------------------------------------------------ audio: music + engine + signal + sfx
def movavg(x, w):
    """fast centered moving average (cumsum), same length as x"""
    w = max(1, int(w)); c = np.cumsum(np.concatenate([np.zeros(1), np.pad(x, (w // 2, w - 1 - w // 2), mode="edge")]))
    return (c[w:] - c[:-w]) / w
def build_audio(path):
    n = int((TT + 0.3) * SR); rng2 = np.random.default_rng(3)
    mp = os.path.join(HERE, "music_em.wav")
    if not os.path.exists(mp) or sf.info(mp).duration < TT + 0.5:
        subprocess.run(["nice", "-n", "15", "python3", os.path.join(HERE, "music.py"), "em", "bright", "0", "112", "7", str(round(TT + 1.5, 1))], check=True)
    mu = load_audio(mp)
    if len(mu) < n: mu = np.concatenate([mu, np.zeros(n - len(mu))])
    mu = mu[:n] / (np.sqrt(np.mean(mu[: int(20 * SR)] ** 2)) + 1e-9) * 10 ** (-21 / 20)
    gain = np.ones(n)
    if VOICE is not None:
        v = np.zeros(n); L = min(n, len(VOICE)); v[:L] = VOICE[:L]
        v = v / (np.sqrt(np.mean(v[np.abs(v) > 0.01] ** 2)) + 1e-9) * 10 ** (-16 / 20)
        hop = int(0.02 * SR); m = movavg(np.abs(v), hop) > 0.01
        m = movavg(m.astype(float), 0.3 * SR) > 0
        k = int(0.15 * SR); g = np.where(m, 10 ** (-12 / 20), 1.0)
        gain = movavg(g, 2 * k + 1)[:n]
    else:
        v = np.zeros(n)
    fi = int(0.2 * SR); gain[:fi] *= np.linspace(0, 1, fi)
    fo = int(2.2 * SR); gain[-fo:] *= np.linspace(1, 0, fo)
    out = mu * gain
    sfx = np.zeros(n); ts = np.arange(n) / SR
    def add(sig, at_s, g):
        i = int(at_s * SR); j = min(n, i + len(sig))
        if 0 <= i < n: sfx[i:j] += g * sig[:j - i]
    # engine: harmonic hum whose pitch follows the speedometer (idle rumble when frozen)
    fr_t = np.arange(0, TT + 0.3, 1 / FPS); spd = np.array([speed_at(x) for x in fr_t])
    scn = [BY[beat_at(x)]["scene"] for x in fr_t]
    lvl = np.array([{"hook": .9, "freeze": .8, "P": .55, "N": .6, "C": .6, "H": 1.0, "map": .0, "cta": .0}[s] for s in scn])
    sp = np.interp(ts, fr_t, spd); lv = movavg(np.interp(ts, fr_t, lvl), 0.3 * SR)
    f0 = 34 + sp * 0.75 + 2 * np.sin(2 * np.pi * 0.7 * ts); ph = 2 * np.pi * np.cumsum(f0) / SR
    eng = sum(np.sin(h * ph) / h ** 1.2 for h in range(1, 7)) * (1 + 0.25 * np.sin(ph * 0.5))
    eng = np.convolve(eng, np.ones(9) / 9, "same")
    sfx += eng * lv * 0.022
    # turn signal / hazards: tick on, tock off, at 1.5 Hz (same clock as the blinking lamps)
    tk = np.arange(int(0.03 * SR)) / SR
    tick = np.sin(2 * np.pi * 3100 * tk) * np.exp(-tk * 260) + 0.5 * np.sin(2 * np.pi * 1300 * tk) * np.exp(-tk * 180)
    tock = np.sin(2 * np.pi * 2300 * tk) * np.exp(-tk * 300) + 0.5 * np.sin(2 * np.pi * 900 * tk) * np.exp(-tk * 200)
    for a_, b_, kind in SIGNALS:
        k0 = math.ceil(a_ * 1.5 * 2)
        for q in range(k0, int(b_ * 1.5 * 2) + 1):
            at_ = q / 3.0; add(tick if q % 2 == 0 else tock, at_, 0.09 if kind == "hazard" else 0.07)
    # whoosh between scenes and truck pass bys
    tw = np.arange(int(0.45 * SR)) / SR; nz = rng2.standard_normal(len(tw)); y = np.zeros_like(nz); s1 = s2 = 0.0
    fc = 300 + 2600 * (tw / tw[-1]) ** 1.5
    for i in range(len(nz)):
        f = 2 * math.sin(math.pi * fc[i] / SR); s1 += f * (nz[i] - s1 - 0.6 * s2); s2 += f * s1; y[i] = s2
    whoosh = y / np.abs(y).max() * np.sin(np.pi * tw / tw[-1]) ** 2
    for k in KEYS[1:]:
        if BY[k]["scene"] != BY[KEYS[KEYS.index(k) - 1]]["scene"]: add(whoosh, BSTART[k] - 0.2, 0.06)
    tp = np.arange(int(0.6 * SR)) / SR; pb = rng2.standard_normal(len(tp)); pb = np.convolve(pb, np.ones(30) / 30, "same")
    passby = pb / np.abs(pb).max() * np.exp(-((tp - 0.25) / 0.12) ** 2)
    for (lane, y0, vv) in [(0, 900, 2600), (2, 2300, 2900), (0, 3300, 2600), (2, 4200, 2900)]:
        for m_ in range(0, 40):
            tpass = (y0 - 1060 + 900 + m_ * 4400) / vv
            if tpass > SC1["freeze"]: break
            if tpass > 0: add(passby, tpass - 0.25, 0.10)
    # soft horn when you freeze
    th = np.arange(int(0.42 * SR)) / SR; horn = sum(np.sign(np.sin(2 * np.pi * f * th)) * 0.3 for f in (392, 494)) * np.minimum(1, th / 0.02) * np.minimum(1, (th[-1] - th) / 0.05)
    horn = np.convolve(horn, np.ones(12) / 12, "same"); add(horn, SC0["freeze"] + 0.25, 0.05)
    # bubble pops, counter ticks, chime on the end card, stage lights on the map
    tq = np.arange(int(0.16 * SR)) / SR; popf = 700 + 600 * np.minimum(1, tq / 0.05); pop = np.sin(2 * np.pi * np.cumsum(popf) / SR) * np.exp(-tq * 26)
    for b in BUB: add(pop, b["t0"], 0.045)
    tc = np.arange(int(0.06 * SR)) / SR; ding = np.sin(2 * np.pi * 1760 * tc) * np.exp(-tc * 70)
    for e in EV_N: add(ding, e["tc"], 0.05)
    tb = np.arange(int(1.8 * SR)) / SR
    chime = sum(np.sin(2 * np.pi * f * tb) * np.exp(-tb * (2.5 + j)) for j, f in enumerate([880, 1318.5, 1760])) * np.minimum(1, tb / 0.005)
    b0, d = BSTART["close"], BEND["close"] - BSTART["close"]
    for j, f_ in enumerate(BY["close"]["names"]):
        tn = np.arange(int(0.5 * SR)) / SR; add(np.sin(2 * np.pi * [523.3, 659.3, 784, 1046.5][j] * tn) * np.exp(-tn * 7), b0 + f_ * d, 0.05)
    add(chime, BSTART["cta"] + 0.1, 0.04)
    sw = np.sin(np.pi * np.clip(np.arange(int(1.0 * SR)) / SR, 0, 1)) * np.sin(2 * np.pi * 61.7 * np.arange(int(1.0 * SR)) / SR)
    add(sw, 0.0, 0.10)
    mix = out + sfx + v
    mix = mix / max(1.0, np.abs(mix).max() / 0.95)
    sf.write(path, np.stack([mix, mix], 1).astype(np.float32), SR)

# ------------------------------------------------------------------ main
if __name__ == "__main__":
    print("total", round(TT, 2), "s;", [(k, round(BSTART[k], 2)) for k in KEYS])
    build_statics()
    if A.frames:
        os.makedirs(os.path.join(HERE, "check"), exist_ok=True)
        for s in A.frames.split(","):
            frame(float(s)).save(os.path.join(HERE, "check", f"f_{float(s):05.2f}.png"))
        sys.exit()
    out = os.path.abspath(A.out) if A.out else os.path.join(HERE, "express_method_vo.mp4" if A.vo else "express_method_v1.mp4")
    mixw = os.path.join(HERE, "mix.wav"); build_audio(mixw)
    json.dump(dict(total=TT, beats=[(k, round(BSTART[k], 3)) for k in KEYS], lines=[(s["key"], round(s["v0"], 3), round(s["v1"], 3)) for s in segs], voice=bool(A.vo)),
              open(os.path.join(HERE, "timeline.json"), "w"), indent=1)
    p = subprocess.Popen(["nice", "-n", "15", "ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-i", mixw, "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-maxrate", "1500k", "-bufsize", "3000k", "-pix_fmt", "yuv420p", "-threads", "2",
                          "-c:a", "aac", "-b:a", "160k", "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)
    t0 = time.time()
    for i in range(NF):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 300 == 0: print(i, NF, round(time.time() - t0), flush=True)
    p.stdin.close(); p.wait(); print("done", out, round(time.time() - t0), "s", round(os.path.getsize(out) / 1e6, 2), "MB")
