"""looplib.py (1 Nov): add the circular ending (scenes_x: last loop_xfade s cross-fade into frame 0, music bed folded so it
loops) to any scene module. In a wrapper module:  import looplib; looplib.wrap(globals(), "/abs/path/to/base_scenes.py")
exports the base module's sc_* scene types and applies the scenes_x loop patches (scenes_x's own scene types are not exported)."""
import importlib.util
X = "/home/claude/express_1031_cta/scenes_x.py"
def _load(p, name):
    s = importlib.util.spec_from_file_location(name, p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def wrap(g, base=None):
    _load(X, "scenes_x_loop")            # patches render.Reel.draw (loop_xfade) and mix.bed (looping bed)
    if base:
        m = _load(base, "base_scenes")
        for k, v in vars(m).items():
            if k.startswith("sc_"): g[k] = v
