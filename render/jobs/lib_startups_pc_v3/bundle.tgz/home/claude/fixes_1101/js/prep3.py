"""prep3 (1 Nov, Noam on jews_survive_v2 [0:19] 'issue with sound'): prep2 (holiday holds) with clean edits.
prep2 pasted HOLD s of digital silence at line end + 0.12 s, cutting through the tail of the voice (a hard edge, heard as a
drop-out / click in 0:12 to 0:25 where four holds sit close together). Here:
  - each hold is placed at the quietest 10 ms within 0.06 to 0.30 s after the line's last word, with 25 ms fades either side;
  - native Hebrew clips (spec "native": [[line, first_word, last_word], ...], 0-based word indexes in the line) are
    level-matched to the English words of the same line (RMS over the word spans, +-1.5 dB clamp ignored above 6 dB) with 30 ms ramps;
  - any isolated burst in a pause (10 ms RMS > -35 dBFS while the 200 ms around it is silent) is muted with 10 ms fades.
usage: prep3.py SPEC SSE_PREFIX OUT [--preview]"""
import os, sys, json
sys.path.insert(0, "/home/claude/reelkit")
import numpy as np
import voice, render as RD, mix as MX, make_reel_sse as MRS
spec_p, pre, out = sys.argv[1:4]; preview = "--preview" in sys.argv
os.makedirs(out, exist_ok=True)
spec = RD.load_spec(spec_p); sdir = os.path.dirname(os.path.abspath(spec_p))
lines = voice.read_script(os.path.join(sdir, spec["script"])); r = MRS.sse_process(voice, pre, lines, print)
vo, tim = voice.select(r["vo"], r["timing"], None, gap_max=spec.get("gap_max", 0.6), gap_new=spec.get("gap_new", 0.45))
HOLD = spec.get("hold", 0.85); SR = voice.SR
vo = np.asarray(vo, np.float64).copy()
def rms(x): return float(np.sqrt(np.mean(x ** 2)) + 1e-12)
def ramp_gain(y, a, b, g, f):
    i, j = int(a * SR), int(b * SR); n = int(f * SR); env = np.ones(len(y))
    env[i:j] = g
    if i - n > 0: env[i - n:i] = np.linspace(1, g, n)
    if j + n < len(y): env[j:j + n] = np.linspace(g, 1, n)
    return y * env
# 1. level match: every native clip (spec "native") and then every line, to the median line level (RMS over word spans,
#    clamp +-6 dB), ramps of 30 ms inside the pauses. A quiet line or a quiet native clip was part of the 0:12 to 0:30 problem.
def span_rms(ws): return rms(np.concatenate([vo[int(w["t0"] * SR):int(w["t1"] * SR)] for w in ws]))
lines_w = [[w for w in tim["words"] if w["line"] == i] for i in range(len(tim["lines"]))]
nat_idx = {(ln - 1, k) for ln, w0, w1 in spec.get("native", []) for k in range(w0, w1 + 1)}
eng_lv = [span_rms([w for k, w in enumerate(ws) if (i, k) not in nat_idx]) for i, ws in enumerate(lines_w) if any((i, k) not in nat_idx for k in range(len(ws)))]
ref = float(np.median(eng_lv))
for ln, w0, w1 in spec.get("native", []):
    nat = lines_w[ln - 1][w0:w1 + 1]; a, b = nat[0]["t0"] - 0.02, nat[-1]["t1"] + 0.04
    g = float(np.clip(ref / span_rms(nat), 10 ** (-6 / 20), 10 ** (6 / 20))); print(f"native line {ln} words {w0}-{w1}: {20*np.log10(g):+.1f} dB")
    vo = ramp_gain(vo, a, b, g, 0.03)
for i, ws in enumerate(lines_w):
    eng = [w for k, w in enumerate(ws) if (i, k) not in nat_idx]
    if not eng: continue
    g = float(np.clip(ref / span_rms(eng), 10 ** (-6 / 20), 10 ** (6 / 20)))
    if abs(20 * np.log10(g)) < 1.0: continue
    a, b = ws[0]["t0"] - 0.06, ws[-1]["t1"] + 0.10
    # keep native words at their own (already matched) level
    print(f"line {i + 1}: {20*np.log10(g):+.1f} dB"); vo = ramp_gain(vo, a, b, g, 0.03)
    for ln, w0, w1 in spec.get("native", []):
        if ln - 1 == i:
            nat = ws[w0:w1 + 1]; vo = ramp_gain(vo, nat[0]["t0"] - 0.02, nat[-1]["t1"] + 0.04, 1 / g, 0.03)
# 2. holds at the quietest point, with fades
def quietest(t_lo, t_hi):
    h = int(0.01 * SR); best, bt = None, t_lo
    for s in range(int(t_lo * SR), int(t_hi * SR) - h, h // 2):
        e = float(np.mean(vo[s:s + h] ** 2))
        if best is None or e < best: best, bt = e, (s + h / 2) / SR
    return bt
F = int(0.025 * SR)
for ln in sorted(spec.get("holds", []), reverse=True):
    L = tim["lines"][ln - 1]; nxt = tim["lines"][ln]["t0"] if ln < len(tim["lines"]) else L["t1"] + 0.4
    at = quietest(L["t1"] + 0.06, min(L["t1"] + 0.30, nxt - 0.05)); k = int(at * SR)
    a = vo[:k].copy(); b = vo[k:].copy()
    a[-F:] *= np.linspace(1, 0, F); b[:F] *= np.linspace(0, 1, F)
    vo = np.concatenate([a, np.zeros(int(HOLD * SR)), b])
    for w in tim["words"]:
        if w["t0"] >= at: w["t0"] = round(w["t0"] + HOLD, 3); w["t1"] = round(w["t1"] + HOLD, 3)
    for L2 in tim["lines"]:
        if L2["t0"] >= at: L2["t0"] = round(L2["t0"] + HOLD, 3); L2["t1"] = round(L2["t1"] + HOLD, 3)
    print(f"hold after line {ln} at {at:.3f}")
# 3. isolated bursts in pauses
spans = [(w["t0"] - 0.05, w["t1"] + 0.08) for w in tim["words"]]
def in_word(t): return any(a <= t <= b for a, b in spans)
h = int(0.01 * SR); n = len(vo) // h; e = np.sqrt(np.mean(vo[:n * h].reshape(n, h) ** 2, 1) + 1e-12); db = 20 * np.log10(e)
muted = 0
for i in range(n):
    t = (i + 0.5) * h / SR
    if db[i] > -35 and not in_word(t):
        lo, hi = max(0, i - 10), min(n, i + 11)
        if np.median(db[lo:hi]) < -50:
            s0, s1 = i * h, (i + 1) * h; g = np.ones(len(vo)); f = h
            g[s0:s1] = 0; g[max(0, s0 - f):s0] = np.linspace(1, 0, min(f, s0)); g[s1:s1 + f] = np.linspace(0, 1, len(g[s1:s1 + f])); vo = vo * g; muted += 1
print("bursts muted", muted)
tim["dur"] = round(len(vo) / SR, 3)
voice.write(out, vo, tim, r["report"])
R = RD.Reel(spec, tim); print("T_END", R.T_END, "warn", R.warn)
RD.preview(R, R.keytimes(), f"{out}/preview.png")
if not preview:
    last = R.scenes[-1]; end_at = R.T_END - 2.0
    bed = MX.bed(spec.get("music", "doc_piano"), R.T_END, end_at); ev = [(tt, k, 0.0) for tt, k in R.sfx_events()]
    MX.mix(vo, R.T_END, bed, ev, f"{out}/mix.wav", music_db=spec.get("music_db", -17.0), log=print)
