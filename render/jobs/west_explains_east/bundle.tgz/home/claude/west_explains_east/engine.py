"""west_explains_east: 4 Western plans for the Middle East, a live 0/4 scorecard, Churchill 1947, Freedom House 2026, circular end.
python3 engine.py [--frames t1,t2,..] [--qa DIR] [--out out.mp4]   (DIR = this folder; needs timing.json, photos/, mix.m4a)"""
import json, os, re, sys, math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont

D = "/home/claude/west_explains_east"
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"
NAVY, NAVY2, PANEL = "#163260", "#0C1E3E", "#1D3E73"
SKY, GOLD, YELLOW, WHITE, SILVER = "#45A4DD", "#D2AA53", "#FFD54A", "#FFFFFF", "#C9D1DC"
RED, GREEN, AMBER, LANDC, SEA, ISR = "#E0453A", "#2FB36B", "#F2B33D", "#2A4F86", "#0F2547", "#B8923F"
X0 = 70
_fc = {}
def F(sz, w=900):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def hexa(c, a=255):
    c = c.lstrip("#"); return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), int(max(0, min(255, a))))
def clamp(x): return min(1.0, max(0.0, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def back(x):
    x = clamp(x); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2

class _AD:
    """Pillow draws text opaque whatever the fill alpha, so translucent text goes through a small layer."""
    def __init__(self, base): self.base = base; self.d = ImageDraw.Draw(base, "RGBA")
    def __getattr__(self, k): return getattr(self.d, k)
    def text(self, xy, txt, font=None, fill=None, anchor=None, **kw):
        al = fill[3] if (isinstance(fill, tuple) and len(fill) == 4) else 255
        if al >= 255: return self.d.text(xy, txt, font=font, fill=fill, anchor=anchor, **kw)
        if al <= 1: return
        x0, y0, x1, y1 = [int(v) for v in self.d.textbbox(xy, txt, font=font, anchor=anchor)]
        x0 -= 2; y0 -= 2; x1 += 2; y1 += 2
        if x1 <= x0 or y1 <= y0: return
        L = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0))
        ImageDraw.Draw(L).text((xy[0] - x0, xy[1] - y0), txt, font=font, fill=fill[:3] + (255,), anchor=anchor, **kw)
        L.putalpha(L.getchannel("A").point(lambda v: v * al // 255))
        self.base.paste(L, (x0, y0), L)
def DR(b): return _AD(b)

# ---------------------------------------------------------------- timing
T = json.load(open(f"{D}/timing.json")); LINES = T["lines"]
END = round(LINES[-1]["t1"] + 0.35, 2)
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]) == norm(word)]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]

# ---------------------------------------------------------------- background
def make_bg():
    y = np.linspace(0, 1, H)[:, None]; x = np.linspace(-1, 1, W)[None, :]
    a, b = np.array(hexa(NAVY)[:3], float), np.array(hexa(NAVY2)[:3], float)
    t = np.clip(0.25 + 0.75 * y + 0.12 * x ** 2, 0, 1)[..., None]
    return Image.fromarray((a * (1 - t) + b * t).astype(np.uint8), "RGB")
BG = make_bg()

def wrap(txt, font, maxw):
    out, cur = [], ""
    for w_ in txt.split():
        tst = (cur + " " + w_).strip()
        if font.getlength(tst) <= maxw or not cur: cur = tst
        else: out.append(cur); cur = w_
    out.append(cur); return out

def rich(base, x, y, parts, sz, a=1.0, anchor="ls", w=900):
    """parts [(text, colour), ...] on one line; anchor ls = left baseline, ms = centred"""
    f = F(sz, w); tot = sum(f.getlength(s) for s, _ in parts)
    if anchor == "ms": x = x - tot / 2
    d = DR(base)
    for s, c in parts:
        d.text((x, y), s, font=f, fill=hexa(c, int(255 * a)), anchor="ls"); x += f.getlength(s)

def xmark(d, cx, cy, r, a, col=RED, ring=True):
    if ring: d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=hexa(col, int(255 * a)))
    k = r * 0.38; lw = max(3, int(r * 0.2))
    d.line([(cx - k, cy - k), (cx + k, cy + k)], fill=hexa(WHITE, int(255 * a)), width=lw)
    d.line([(cx - k, cy + k), (cx + k, cy - k)], fill=hexa(WHITE, int(255 * a)), width=lw)

# ---------------------------------------------------------------- photos (rounded panel, Ken Burns 1.0 to 1.08)
def load_photo(name): return Image.open(f"{D}/photos/{name}.jpg").convert("RGB")
PHOTO = {n: load_photo(n) for n in ("iraq", "kabul", "churchill")}
_mask = {}
def rmask(w, h, r):
    k = (w, h, r)
    if k not in _mask:
        S = 3; m = Image.new("L", (w * S, h * S), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * S - 1, h * S - 1), r * S, fill=255)
        _mask[k] = m.resize((w, h), Image.LANCZOS)
    return _mask[k]
def photo_panel(base, name, box, prog, a, fx=0.5, fy=0.5, grad=0.0):
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = PHOTO[name]
    z = 1.0 + 0.08 * clamp(prog)
    s = max(w / im.width, h / im.height) * 1.0
    cw, ch = w / (s * z), h / (s * z)
    cx = min(max(cw / 2, fx * im.width), im.width - cw / 2); cy = min(max(ch / 2, fy * im.height), im.height - ch / 2)
    fr = im.resize((w, h), Image.BILINEAR, box=(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2))
    if grad > 0:
        g = np.clip((np.linspace(0, 1, h) - 0.35) / 0.65, 0, 1)[:, None] * grad
        dark = Image.new("RGB", (w, h), hexa(NAVY2)[:3]); gm = Image.fromarray((np.repeat(g, w, 1) * 255).astype(np.uint8), "L")
        fr = Image.composite(dark, fr, gm)
    m = rmask(w, h, 34)
    if a < 0.999: m = m.point(lambda v: int(v * a))
    base.paste(fr, (x0, y0), m)

# ---------------------------------------------------------------- map (Natural Earth 1:50m, public domain)
GEO = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
LON0, LON1, LAT0, LAT1 = -86.0, 58.0, 12.0, 64.0
MBOX = (60, 470, 1020, 950)
KX = math.cos(math.radians(38))
def proj(lon, lat):
    x0, y0, x1, y1 = MBOX; sx = (x1 - x0) / ((LON1 - LON0) * KX); sy = (y1 - y0) / (LAT1 - LAT0); s = min(sx, sy)
    ox = x0 + ((x1 - x0) - (LON1 - LON0) * KX * s) / 2
    return ox + (lon - LON0) * KX * s, y1 - (lat - LAT0) * s
def make_map():
    x0, y0, x1, y1 = MBOX; S = 2
    im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((x0 * S, y0 * S, x1 * S, y1 * S), 34 * S, fill=hexa(SEA))
    for f in GEO["features"]:
        iso = f["properties"].get("ISO_A2"); g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        col = ISR if iso in ("IL", "PS") else LANDC
        for poly in polys:
            ring = poly[0]
            if all(p[0] < LON0 - 5 or p[0] > LON1 + 5 for p in ring[::5]): continue
            pts = [tuple(v * S for v in proj(p[0], p[1])) for p in ring]
            d.polygon(pts, fill=hexa(col), outline=hexa("#3E679F") if col == LANDC else None)
    im = im.resize((W, H), Image.LANCZOS)
    m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).rounded_rectangle(MBOX, 34, fill=255)
    a = np.array(im.getchannel("A"), float) * np.array(m, float) / 255; im.putalpha(Image.fromarray(a.astype(np.uint8)))
    return im
MAP = make_map()
CITY = {"Washington": (-77.04, 38.91), "London": (-0.13, 51.51), "Baghdad": (44.37, 33.32)}
def arc(p, q, k):
    (x0, y0), (x1, y1) = p, q; mx, my = (x0 + x1) / 2, (y0 + y1) / 2 - 0.18 * math.hypot(x1 - x0, y1 - y0)
    pts = []
    for i in range(41):
        u = k * i / 40; pts.append(((1 - u) ** 2 * x0 + 2 * (1 - u) * u * mx + u * u * x1, (1 - u) ** 2 * y0 + 2 * (1 - u) * u * my + u * u * y1))
    return pts
def draw_map(base, a, lines):
    """lines: [(city, progress, alpha)]"""
    lay = MAP if a >= 0.999 else Image.fromarray(np.dstack([np.array(MAP)[..., :3], (np.array(MAP)[..., 3] * a).astype(np.uint8)]), "RGBA")
    base.paste(lay, (0, 0), lay)
    d = DR(base); B = proj(*CITY["Baghdad"])
    for c, k, al in lines:
        if k <= 0: continue
        P = proj(*CITY[c]); pts = arc(P, B, k)
        d.line(pts, fill=hexa(YELLOW, int(255 * a * al)), width=7, joint="curve")
    for c in CITY:
        x, y = proj(*CITY[c]); r = 13
        d.ellipse((x - r, y - r, x + r, y + r), fill=hexa(WHITE, int(255 * a)), outline=hexa(NAVY2, int(255 * a)), width=4)
        an = "ls" if c != "Baghdad" else "rs"; dx = 22 if c != "Baghdad" else -22
        d.text((x + dx, y - 18), c, font=F(40, 800), fill=hexa(WHITE, int(255 * a)), anchor=an)

# ---------------------------------------------------------------- scenes
PLANS = ["Iraq", "Libya", "Afghanistan", "Gaza"]
T_MAP = lt(1) - 0.2
P_T = [lt(2) - 0.25, lt(4) - 0.2, lt(6) - 0.2, lt(8) - 0.2]
T_ZERO = lt(10) - 0.2
T_CH = lt(12) - 0.2
T_FH = lt(13) - 0.2
T_PARA = lt(14) - 0.2
T_ASK = lt(15) - 0.2
T_LOOP = lt(16) - 0.15
X_T = [wt(3, "Mosul"), wt(5, "four"), wt(7, "Kabul"), wt(9, "force")]
O_T = [wt(3, "Then") - 0.1, wt(5, "By") - 0.1, wt(7, "Thirtyeight") - 0.1, wt(9, "Hamas") - 0.1]

def score_strip(base, t, cur, a, y=330, r=36, labels=True, xs=None):
    d = DR(base); xs = xs or [225, 435, 645, 855]
    for j, nm in enumerate(PLANS):
        x = xs[j]; kx = clamp((t - X_T[j]) / 0.3)
        if kx > 0:
            s = back(kx); xmark(d, x, y, r * s, a)
        else:
            col = SKY if j == cur else "#FFFFFF"
            d.ellipse((x - r, y - r, x + r, y + r), fill=hexa("#FFFFFF", int(26 * a)), outline=hexa(col, int((255 if j == cur else 110) * a)), width=4)
            d.text((x, y + 2), "?", font=F(int(r * 1.2), 900), fill=hexa(col, int((255 if j == cur else 150) * a)), anchor="mm")
        if labels: d.text((x, y + r + 34), nm, font=F(36, 800), fill=hexa(WHITE if j == cur else SILVER, int(255 * a)), anchor="mm")

def hook(base, th, a=1.0):
    """frame-0 layout; th = time since loop start (0 at frame 0; negative while the ending crossfades in)"""
    sz = 112 + 3 * math.sin(2 * math.pi * th / 2.4)
    rich(base, 540, 640, [("4 ", YELLOW), ("Western plans.", WHITE)], sz, a, "ms")
    rich(base, 540, 800, [("How many ", WHITE), ("worked?", GOLD)], sz, a, "ms")
    k = ease((th - 0.15) / 0.9) if th > 0 else 0.0
    if k > 0:
        f = F(sz); w1 = f.getlength("How many worked?"); xl = 540 + w1 / 2 - f.getlength("worked?")
        DR(base).rounded_rectangle((xl, 830, xl + f.getlength("worked?") * k, 846), 8, fill=hexa(GOLD, int(255 * a)))
    d = DR(base)
    for j, nm in enumerate(PLANS):
        x = [190, 397, 683, 890][j]; y = 1120 + 14 * math.sin(2 * math.pi * th / 1.6 + j * 1.1); r = 70
        d.ellipse((x - r, y - r, x + r, y + r), fill=hexa("#FFFFFF", int(30 * a)), outline=hexa(SKY, int(255 * a)), width=6)
        d.text((x, y + 4), "?", font=F(92, 900), fill=hexa(SKY, int(255 * a)), anchor="mm")
        d.text((x, 1260), nm, font=F(40, 800), fill=hexa(WHITE, int(255 * a)), anchor="mm")

def sc_hook(base, t): hook(base, t)

def sc_map1(base, t):
    a = clamp((t - T_MAP) / 0.3)
    rich(base, 540, 400, [("The view from ", WHITE), ("far away", GOLD)], 84, a, "ms")
    tL, tW = wt(1, "London") - 0.1, wt(1, "Washington") - 0.1
    kL, kW = ease((t - tL) / 1.6), ease((t - tW) / 1.2)
    draw_map(base, a, [("London", kL, 1.0), ("Washington", kW, 1.0)])
    d = DR(base)
    rows = [("London to Baghdad", 4090, tL, 1.6, 1050), ("Washington to Baghdad", 9970, tW, 1.2, 1270)]
    for lab, v, t0, du, y in rows:
        k = clamp((t - t0) / 0.3)
        if k <= 0: continue
        d.text((X0, y), lab, font=F(56, 800), fill=hexa(WHITE, int(255 * k)), anchor="ls")
        n = int(round(v * ease((t - t0) / du) / 10) * 10) if t < t0 + du else v
        rich(base, X0, y + 125, [(f"{n:,}", YELLOW), (" km", WHITE)], 118, k)
    d.text((X0, 1475), "Great-circle distance, city centre to city centre.", font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="ls")

PL = [
    dict(n=1, place="Iraq, 2003", label="THE PROMISE", quote="“Your nation will soon be free.”", qsz=78,
         attr="George W. Bush to Iraqis, 10 Apr 2003", photo="iraq", fx=0.5, fy=0.45,
         out=["Sectarian war.", "Then ISIS took Mosul."], credit=["Mosul fell 10 Jun 2014.", "Photo: Firdos Square 2003, US DoD, public domain"]),
    dict(n=2, place="Libya, 2011", label="THE PROMISE", quote="“A Libya that belongs not to a dictator, but to its people.”", qsz=70,
         attr="Barack Obama, 28 Mar 2011", big="$400", bigsub=["a person, sold at auction"], credit=["CNN hidden camera report, Nov 2017"]),
    dict(n=3, place="Afghanistan, 20 years", label="A TALIBAN TAKEOVER?", quote="“Highly unlikely.”", qsz=110,
         attr="Joe Biden, 8 Jul 2021", photo="kabul", fx=0.5, fy=0.5,
         out=["38 days later:", "the Taliban took Kabul."], credit=["Kabul fell 15 Aug 2021.", "Photo: Sgt. Isaiah Campbell, USMC, public domain"]),
    dict(n=4, place="Gaza, 2006", label="THE PLAN", quote="Hold the elections.", qsz=96,
         attr="Bush administration, Jan 2006", big="74/132", bigsub=["seats to HAMAS.", "2007: Gaza taken by force."],
         credit=["Election: Palestinian CEC, 25 Jan 2006.", "Takeover of Gaza: 14 Jun 2007"]),
]

def sc_plan(base, t, i):
    P = PL[i]; t0 = P_T[i]; a = 1.0; d = DR(base)
    score_strip(base, t, i, a)
    kh = ease((t - t0) / 0.4); xo = (1 - kh) * 80
    d.text((X0 + xo, 500), f"PLAN {P['n']}", font=F(52, 900), fill=hexa(SKY, int(255 * kh)), anchor="ls")
    d.text((X0 + xo, 610), P["place"], font=F(96, 900), fill=hexa(WHITE, int(255 * kh)), anchor="ls")
    kq = ease((t - t0 - 0.35) / 0.4)
    d.text((X0, 700), P["label"], font=F(42, 800), fill=hexa(GOLD, int(255 * kq)), anchor="ls")
    f = F(P["qsz"], 900); ls = wrap(P["quote"], f, 940); lh = int(P["qsz"] * 1.12); y = 700 + lh
    for ln in ls:
        d.text((X0, y), ln, font=f, fill=hexa(WHITE, int(255 * kq)), anchor="ls"); y += lh
    d.text((X0, y - lh + 62), P["attr"], font=F(40, 700), fill=hexa(SILVER, int(240 * kq)), anchor="ls")
    yb = max(1010, y + 20)
    to = O_T[i]; ko = ease((t - to) / 0.35)
    box = (60, yb, 1020, 1420)
    if "photo" in P:
        kp = ease((t - t0 - 0.5) / 0.4)
        photo_panel(base, P["photo"], box, (t - t0) / max(1.0, X_T[i] + 1.5 - t0), kp, P["fx"], P["fy"], grad=0.9 * ko)
        if ko > 0:
            yy = box[3] - 40 - 84 * (len(P["out"]) - 1)
            for n_, s in enumerate(P["out"]):
                d.text((100, yy + 84 * n_), s, font=F(72, 900), fill=hexa(WHITE if n_ == 0 else YELLOW, int(255 * ko)), anchor="ls")
    else:
        kph = ease((t - t0 - 0.5) / 0.4) * (1 - ko)
        if kph > 0:
            d.rounded_rectangle(box, 34, fill=hexa(PANEL, int(235 * kph)))
            cyq = (box[1] + box[3]) / 2 - 50 + 10 * math.sin(t * 3)
            d.text((540, cyq), "?", font=F(220, 900), fill=hexa(SKY, int(255 * kph)), anchor="mm")
            d.text((540, cyq + 170), "What happened next?", font=F(64, 800), fill=hexa(WHITE, int(255 * kph)), anchor="mm")
        if ko > 0:
            d.rounded_rectangle(box, 34, fill=hexa(PANEL, int(235 * ko)))
            sb = back(clamp((t - to) / 0.4))
            cy = (box[1] + box[3]) / 2 - 40 * (len(P["bigsub"]) - 1) - 30
            d.text((540, cy), P["big"], font=F(int(190 * max(0.3, sb)), 900), fill=hexa(YELLOW, int(255 * ko)), anchor="mm")
            for n_, s in enumerate(P["bigsub"]):
                d.text((540, cy + 150 + 80 * n_), s, font=F(64, 800), fill=hexa(WHITE, int(255 * ko)), anchor="mm")
    kp = ease((t - t0 - 0.5) / 0.4)
    for n_, s in enumerate(P["credit"]):
        al = kp if ("photo" in P and n_ == len(P["credit"]) - 1) else ko
        d.text((X0, 1462 + 44 * n_), s, font=F(36, 700), fill=hexa(SILVER, int(235 * al)), anchor="ls")
    # red stamp when the plan fails
    kx = clamp((t - X_T[i]) / 0.3)
    if kx > 0:
        s = back(kx); xmark(d, 960, 478, 50 * s, 1.0)

def sc_zero(base, t):
    d = DR(base); t1 = lt(11) - 0.1
    kA = 1 - clamp((t - t1) / 0.35)
    if kA > 0:
        sb = back(clamp((t - T_ZERO) / 0.45))
        d.text((540, 820), "0/4", font=F(int(330 * max(0.3, sb)), 900), fill=hexa(YELLOW, int(255 * kA)), anchor="mm")
        d.text((540, 1040), "plans worked", font=F(80, 900), fill=hexa(WHITE, int(255 * kA)), anchor="mm")
        score_strip(base, t, -1, kA, y=1250, r=58, xs=[210, 420, 660, 870])
    kB = clamp((t - t1) / 0.35)
    if kB > 0:
        score_strip(base, t, -1, kB, y=330, r=36)
        d.text((X0, 560), "A vote alone", font=F(104, 900), fill=hexa(WHITE, int(255 * kB)), anchor="ls")
        d.text((X0, 680), "isn't democracy.", font=F(104, 900), fill=hexa(GOLD, int(255 * kB)), anchor="ls")
        for n_, (lab, w_) in enumerate([("Free courts", "courts"), ("Free press", "press")]):
            k = ease((t - wt(11, w_) + 0.25) / 0.3)
            if k <= 0: continue
            y = 850 + 140 * n_
            d.rounded_rectangle((X0, y - 60, 1010, y + 60), 30, fill=hexa("#FFFFFF", int(22 * k)))
            xmark(d, X0 + 70, y, 40 * back(k), k)
            d.text((X0 + 140, y + 4), lab + "?", font=F(76, 800), fill=hexa(WHITE, int(255 * k)), anchor="lm")
        k = ease((t - wt(11, "elect") + 0.1) / 0.35)
        if k > 0:
            d.text((X0, 1210), "The worst can win.", font=F(84, 900), fill=hexa(YELLOW, int(255 * k)), anchor="ls")
            d.text((X0, 1300), "Gaza, 2006: HAMAS", font=F(56, 800), fill=hexa(SKY, int(255 * k)), anchor="ls")

CHQ = [[("“…democracy is the ", WHITE), ("worst", YELLOW)], [("form of Government ", WHITE), ("except", YELLOW)], [("all those other forms", YELLOW), ("…”", WHITE)]]
def sc_churchill(base, t):
    d = DR(base)
    photo_panel(base, "churchill", (60, 280, 1020, 880), (t - T_CH) / 5.5, ease((t - T_CH) / 0.4), 0.42, 0.42)
    d.text((X0, 925), "Photo: Cecil Beaton, 1940, IWM, public domain", font=F(36, 700), fill=hexa(SILVER, 235), anchor="ls")
    k = ease((t - wt(12, "democracy") + 0.2) / 0.4)
    for n_, ln in enumerate(CHQ):
        rich(base, X0, 1040 + 92 * n_, ln, 76, k)
    ka = ease((t - wt(12, "except")) / 0.4)
    d.text((X0, 1330), "Winston Churchill, House of Commons", font=F(44, 800), fill=hexa(WHITE, int(255 * ka)), anchor="ls")
    d.text((X0, 1390), "11 Nov 1947. Hansard, vol. 444", font=F(40, 700), fill=hexa(SILVER, int(240 * ka)), anchor="ls")

FHROWS = [("Israel", "Free", 73), ("Lebanon", "Partly Free", 41), ("Jordan", "Partly Free", 34), ("Iraq", "Not Free", 31),
          ("West Bank", "Not Free", 22), ("Egypt", "Not Free", 18), ("Syria", "Not Free", 10), ("Gaza", "Not Free", 2)]
def sc_fh(base, t):
    d = DR(base); a = ease((t - T_FH) / 0.3)
    rich(base, X0, 380, [("Rated ", WHITE), ("Free", GOLD), ("?", WHITE)], 96, a)
    d.text((1010, 380), "score /100", font=F(40, 800), fill=hexa(SILVER, int(240 * a)), anchor="rs")
    tI = wt(13, "Israel") - 0.15; tR = wt(13, "regions") - 0.1
    for n_, (nm, st, sc) in enumerate(FHROWS):
        k = ease((t - (tI if n_ == 0 else tR + 0.09 * (n_ - 1))) / 0.3)
        if k <= 0: continue
        y = 490 + 108 * n_; xo = (1 - k) * 100; col = {"Free": GREEN, "Partly Free": AMBER, "Not Free": RED}[st]
        if n_ == 0:
            d.rounded_rectangle((50 + xo, y - 50, 1030 + xo, y + 50), 24, fill=hexa(GOLD, int(60 * k)), outline=hexa(GOLD, int(255 * k)), width=4)
        bw = 300 * sc / 73
        d.rounded_rectangle((560 + xo, y - 14, 560 + xo + bw, y + 14), 14, fill=hexa(col, int(255 * k)))
        d.text((X0 + xo, y + 2), nm, font=F(58, 900), fill=hexa(GOLD if n_ == 0 else WHITE, int(255 * k)), anchor="lm")
        d.text((548 + xo, y + 2), st, font=F(40, 800), fill=hexa(col, int(255 * k)), anchor="rm")
        d.text((1010 + xo, y + 2), str(sc), font=F(58, 900), fill=hexa(WHITE, int(255 * k)), anchor="rm")
    d.text((X0, 1360), "Freedom House, Freedom in the World 2026", font=F(36, 700), fill=hexa(SILVER, int(235 * a)), anchor="ls")

def parachute(d, x, y, s, a):
    cw = 120 * s
    d.pieslice((x - cw, y - cw * 0.8, x + cw, y + cw * 0.8), 180, 360, fill=hexa(WHITE, int(255 * a)))
    for dx in (-cw, -cw / 3, cw / 3, cw):
        d.line([(x + dx, y), (x, y + 95 * s)], fill=hexa(WHITE, int(220 * a)), width=max(2, int(4 * s)))
    bw = 92 * s
    d.rounded_rectangle((x - bw, y + 95 * s, x + bw, y + 145 * s), 8, fill=hexa(GOLD, int(255 * a)))
    d.text((x, y + 121 * s), "DEMOCRACY", font=F(max(10, int(27 * s)), 900), fill=hexa(NAVY2, int(255 * a)), anchor="mm")

def sc_para(base, t):
    d = DR(base); a = ease((t - T_PARA) / 0.3)
    rich(base, 540, 400, [("Democracy by ", WHITE), ("parachute?", GOLD)], 84, a, "ms")
    draw_map(base, a, [("London", 1, 0.35), ("Washington", 1, 0.35)])
    tp = wt(14, "parachute") - 0.3; k = ease((t - tp) / 1.6)
    if t > tp:
        P = proj(*CITY["Washington"]); B = proj(*CITY["Baghdad"]); pts = arc(P, B, max(0.02, k)); x, y = pts[-1]
        parachute(d, x, y - 150, 0.72, a)
    for n_, (s, w_, nth) in enumerate([("The people.", "people", 0), ("The clans.", "clans", 0), ("The history.", "history", 0)]):
        kk = ease((t - wt(14, w_, nth) + 0.15) / 0.3)
        if kk <= 0: continue
        y = 1100 + 125 * n_; xo = (1 - kk) * 80
        d.text((X0 + xo, y), s, font=F(100, 900), fill=hexa(YELLOW if n_ == 2 else WHITE, int(255 * kk)), anchor="ls")
    d.text((X0, 1475), "Washington to Baghdad: 9,970 km", font=F(36, 700), fill=hexa(SILVER, int(235 * a)), anchor="ls")

def sc_ask(base, t):
    d = DR(base); a = ease((t - T_ASK) / 0.35)
    d.text((540, 620), "Before the next plan…", font=F(76, 800), fill=hexa(SILVER, int(255 * a)), anchor="mm")
    k = ease((t - wt(15, "ask") + 0.2) / 0.4); sz = 132 + 4 * clamp((t - wt(15, "ask")) / 1.5)
    for n_, s in enumerate(["Ask the people", "who live here."]):
        d.text((540, 880 + 160 * n_), s, font=F(int(sz), 900), fill=hexa(GOLD if n_ else WHITE, int(255 * k)), anchor="mm")

SCENES = [(0, sc_hook), (T_MAP, sc_map1)] + [(P_T[i], (lambda i: lambda b, t: sc_plan(b, t, i))(i)) for i in range(4)] + \
         [(T_ZERO, sc_zero), (T_CH, sc_churchill), (T_FH, sc_fh), (T_PARA, sc_para), (T_ASK, sc_ask), (T_LOOP, None)]
XF = 0.3
def render_scene(k, t):
    b = BG.copy(); s0, fn = SCENES[k]
    if fn is None: hook(b, t - END)
    else: fn(b, t)
    return b
def frame(t):
    k = max(i for i, (s, _) in enumerate(SCENES) if s <= t)
    s0 = SCENES[k][0]; fade = END - T_LOOP if SCENES[k][1] is None else XF
    img = render_scene(k, t)
    if k > 0 and t < s0 + fade:
        prev = render_scene(k - 1, t); img = Image.blend(prev, img, ease((t - s0) / fade))
    subs(img, t)
    return img.convert("RGB")

# ---------------------------------------------------------------- subtitles (narration, burned in; hook line is already on screen)
SUBS = {
    1: [(3, "London to Baghdad,"), (3, "4,000 km."), (3, "Washington, 10,000.")],
    2: [(2, "Plan 1."), (4, "Iraq, 2003."), (6, "Your nation will soon be free.")],
    3: [(4, "Then a sectarian war,"), (4, "and ISIS took Mosul.")],
    4: [(2, "Plan 2."), (3, "Libya, 2011."), (4, "A Libya that belongs"), (4, "not to a dictator,"), (4, "but to its people.")],
    5: [(3, "By 2017,"), (8, "CNN filmed people sold for $400.")],
    6: [(2, "Plan 3."), (1, "Afghanistan."), (3, "A Taliban takeover?"), (4, "Highly unlikely, said Biden.")],
    7: [(3, "38 days later,"), (4, "the Taliban took Kabul.")],
    8: [(2, "Plan 4."), (1, "Gaza."), (5, "Washington said: hold the elections.")],
    9: [(2, "HAMAS won,"), (5, "then took Gaza by force.")],
    10: [(4, "0 out of 4.")],
    11: [(5, "A vote alone isn't democracy."), (7, "Without free courts and a free press,"), (5, "it can elect the worst.")],
    12: [(3, "Churchill said democracy"), (6, "is the worst form of Government,"), (5, "except all those other forms.")],
    13: [(3, "He was right."), (4, "Israel is the region's"), (4, "only country rated Free.")],
    14: [(6, "But you can't parachute it in"), (4, "without knowing the people,"), (4, "the clans, the history.")],
    15: [(4, "So before you tell"), (6, "the Middle East what to do,"), (6, "ask the people who live here.")],
    16: [(3, "And ask yourself:")],
}
SUB_BOTTOM = 1610; SUBF = F(54, 800)
SUB_ITEMS = []
for li, chunks in SUBS.items():
    ws = LINES[li]["words"]; i = 0
    assert sum(n for n, _ in chunks) == len(ws), (li, sum(n for n, _ in chunks), len(ws))
    for n, txt in chunks:
        SUB_ITEMS.append((ws[i]["t0"] - 0.05, ws[i + n - 1]["t1"] + 0.12, txt)); i += n
for k in range(len(SUB_ITEMS) - 1):
    a0, a1, tx = SUB_ITEMS[k]; b0 = SUB_ITEMS[k + 1][0]
    SUB_ITEMS[k] = (a0, b0 if b0 - a1 < 0.25 else min(a1, b0), tx)
def subs(base, t):
    for a0, a1, txt in SUB_ITEMS:
        if a0 <= t < a1:
            ls = wrap(txt, SUBF, 900); lh = 66; bh = lh * len(ls) + 26; wmax = max(SUBF.getlength(l) for l in ls) + 52
            d = DR(base); y0 = SUB_BOTTOM - bh
            d.rounded_rectangle((540 - wmax / 2, y0, 540 + wmax / 2, SUB_BOTTOM), 22, fill=(8, 16, 34, 215))
            for n, l in enumerate(ls): d.text((540, y0 + 13 + lh * n + lh / 2), l, font=SUBF, fill=hexa(WHITE), anchor="mm")
            return

if __name__ == "__main__":
    if "--frames" in ARGS:
        fr = ARGS[ARGS.index("--frames") + 1]; out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"
        os.makedirs(out, exist_ok=True)
        for s in fr.split(","): frame(float(s)).save(f"{out}/f_{float(s):06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS))
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        p.stdin.write(frame(i / FPS).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
