"""doc_piano bed (loop-clean) + SFX under vo_final.wav -> mix.m4a (-14 LUFS)"""
import sys, os, numpy as np, soundfile as sf, subprocess
sys.argv = ["engine"]; sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/west_explains_east")
import mix as MX
import engine as E
vo, sr = sf.read(f"{E.D}/vo_final.wav"); dur = E.END
m = MX._mod(*MX.BEDS["doc_piano"][:2]); n = int(dur * MX.SR); f = int(0.8 * MX.SR)
x = np.asarray(m.doc_music(dur + 4.5), np.float64)
if x.ndim == 1: x = np.vstack([x, x])
music = x[:, :n].copy()
music[:, :f] = x[:, :f] * np.sin(np.linspace(0, np.pi / 2, f)) + x[:, n:n + f] * np.cos(np.linspace(0, np.pi / 2, f))
music /= np.abs(music).max() + 1e-12
ev = [(s - 0.08, "whoosh", -1) for s, _ in E.SCENES[1:-1]]
ev += [(t + 0.05, "pop", -1) for t in E.X_T]
ev += [(E.T_ZERO + 0.1, "ding", 1)]
rep = MX.mix(vo, dur, music, ev, f"{E.D}/mix.wav", music_db=-19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{E.D}/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{E.D}/mix.m4a"], check=True)
os.remove(f"{E.D}/mix.wav"); print(rep)
