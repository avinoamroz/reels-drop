import json, sys, base64, re
d = json.load(open(sys.argv[1])); raw = d["content"]
try: txt = base64.b64decode(raw).decode()
except Exception: txt = raw
j = json.loads(txt); pages = j["query"]["pages"]; pages = list(pages.values()) if isinstance(pages, dict) else pages
for p in sorted(pages, key=lambda p: p.get("index", 0)):
    ii = (p.get("imageinfo") or [{}])[0]; em = ii.get("extmetadata", {})
    g = lambda k: re.sub("<[^>]+>", "", (em.get(k, {}).get("value", "") or ""))[:150].replace("\n", " ")
    print(f'{p["title"]} | {ii.get("width")}x{ii.get("height")} | {g("LicenseShortName")} | {g("Artist")} | {g("DateTimeOriginal")}')
    print("   ", ii.get("thumburl"), "|", g("ImageDescription")[:150])
