"""armies_map: "3,500 years. Who conquered this land?" (@noamroz__, English, 1 Nov 2026). Sibling of the 3,000 years hit.
Every main power that marched into or ruled this land, from Thutmose III at Megiddo to 1948, on one map: an arrow sweeps in
from each power's home, a year counter rolls, a "RULER n OF 15" counter and 15 pips fill (white = from abroad, gold = born here).
Reveal: 12 from abroad, 3 born here, all 3 Jewish; Jerusalem alone: at least 118 conflicts (Cline 2004). Fair line: every one
left a mark. Circular: the lead-in "So, next time someone asks you..." sits where the hook sits; the last 0.45 s cross-fade into frame 0.
No modern military detail: 1948 is shown at country level only.
Engine core (Blue Marble camera, Inter text rasters, map layers) from empires_israel/reel2.py.
usage: python3 reel.py [--snaps 0,3.1,...|last] | python3 reel.py --out work/silent.mp4"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
D = "/home/claude/fix_1103/armies_map"; FD = "/home/claude/series_more/safe_p2_v3/fonts"; HEB = "/root/.fonts/Heebo-ExtraBold.ttf"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing
WORDS = json.load(open(f"{D}/work/words.json"))["words"]; T_END = json.load(open(f"{D}/work/audio.json"))["T_END"]; LOOP = 0.45
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word, n=1):
    c = 0
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(word.lower()):
            c += 1
            if c == n: return i
    raise KeyError((li, word))
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def eout(u): u = min(1.0, max(0.0, u)); return 1 - (1 - u) ** 3
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
WHITE, GREY, GOLD, SKY, RED = "#FFFFFF", "#C4C4C9", "#F2C94C", "#45A4DD", "#FF453A"
ISR_GOLD, PSX_GOLD = "#E2BC63", "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)

# ------------------------------------------------------------------ text (2x masks, sub-pixel, scale + blur-in, dark halo)
FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium", r="Inter-Regular").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=980):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 600: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur, shadow=True):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 14; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = np.asarray(m, np.float32); lays = []
    if shadow:
        sh = np.asarray(m.filter(ImageFilter.GaussianBlur(7)), np.float32) * 0.85 * alpha
        l0 = Image.new("RGBA", (cw, ch), (0, 0, 0, 0)); l0.putalpha(Image.fromarray(sh.clip(0, 255).astype(np.uint8), "L")); lays.append(l0)
    l1 = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); l1.putalpha(Image.fromarray((a * alpha).clip(0, 255).astype(np.uint8), "L")); lays.append(l1)
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0:
        for lay in lays: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
T_IN, T_OUT = 0.28, 0.2
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.92 + 0.08 * u) * (1 + 0.03 * v), 8 * (1 - u) + 6 * v, 0
def text(canvas, t, s, y, size, t0, t1, fk="db", color=WHITE, inst=False, zoom=1.0, ain=T_IN, aout=T_OUT, cx=540, alpha=1.0, tab=False):
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, cx, y + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)
def rich(canvas, t, parts, y, size, t0, t1, fk="dsb", ain=T_IN, aout=T_OUT, inst=False):
    f = font(fk, size); ws = [f.getlength(p) for p, _ in parts]; x = 540 - sum(ws) / 2
    for (p, c), w_ in zip(parts, ws):
        text(canvas, t, p, y, size, t0, t1, fk=fk, color=c, ain=ain, aout=aout, cx=x + w_ / 2, inst=inst); x += w_

# ------------------------------------------------------------------ background: NASA Blue Marble (public domain), darkened
_bm = Image.open(f"{D}/photos/world.jpg").convert("RGB")
_bm = ImageEnhance.Color(_bm).enhance(0.62); _bm = ImageEnhance.Brightness(_bm).enhance(0.5); _bm = ImageEnhance.Contrast(_bm).enhance(1.12)
BM = _bm; IW, IH = BM.size
class Cam:
    def __init__(s, lon, lat, k, cy=900): s.lon, s.lat, s.k, s.cy = lon, lat, k, cy
    @property
    def cosf(s): return max(0.6, math.cos(math.radians(min(62, abs(s.lat)))))
def cam_lerp(a, b, u):
    return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.k), math.log(b.k), u)), lerp(a.cy, b.cy, u))
def camw(lon, lat, width_deg, cy=900):
    c = Cam(lon, lat, 1, cy); return Cam(lon, lat, W / (width_deg * c.cosf), cy)
def background(cam):
    kx = cam.k * cam.cosf; a = IW / 360 / kx; c = (cam.lon + 180) * IW / 360 - 540 * a
    e = IH / 180 / cam.k; f = (90 - cam.lat) * IH / 180 - cam.cy * e
    return BM.transform((W, H), Image.AFFINE, (a, 0, c, 0, e, f), Image.BILINEAR).convert("RGBA")
def ll2xy(cam, lon, lat): return 540 + (lon - cam.lon) * cam.k * cam.cosf, cam.cy - (lat - cam.lat) * cam.k

# ------------------------------------------------------------------ geography (Natural Earth 1:50m, public domain; via empires_israel/tools/geo_prep.py)
G = json.load(open(f"{D}/geo/geo.json"))
def rings_of(gj):
    polys = gj["coordinates"] if gj["type"] == "MultiPolygon" else ([gj["coordinates"]] if gj["type"] == "Polygon" else [])
    return [np.array(r, float) for p in polys for r in p]
LOCAL = {k: rings_of(v) for k, v in G["local"].items()}
ISR = rings_of(G["israel"]); PSX = rings_of(G["psx"])
from shapely.geometry import shape, mapping
ISR_ONLY = rings_of(json.loads(json.dumps(mapping(shape(G["israel"]).difference(shape(G["psx"]).buffer(0.002))))))
def path(c, cam, rings):
    kx = cam.k * cam.cosf; ky = cam.k
    for r in rings:
        xs = 540 + (r[:, 0] - cam.lon) * kx; ys = cam.cy - (r[:, 1] - cam.lat) * ky
        c.move_to(xs[0], ys[0])
        for x, y in zip(xs[1:], ys[1:]): c.line_to(x, y)
        c.close_path()
def solid(c, cam, rings, col, alpha, lw=0.0, scol=None):
    if alpha <= 0.004 or not rings: return
    v = hx(col) / 255; path(c, cam, rings); c.set_source_rgba(v[0], v[1], v[2], alpha); c.fill_preserve()
    if lw: s_ = hx(scol) / 255; c.set_source_rgba(s_[0], s_[1], s_[2], alpha); c.set_line_width(lw); c.stroke()
    else: c.new_path()

# ------------------------------------------------------------------ the 15 rulers
JER = (35.23, 31.78); MEG = (35.18, 32.585)
#     line, title, year, origin (lon, lat) or None (born here), origin label, target, colour, source
RUL = [
 (2, "EGYPT", -1457, (32.64, 25.70), "Thebes", MEG, "#F5A623", "Thutmose III's annals, Karnak. Low chronology"),
 (4, "KINGDOM OF ISRAEL", -1000, None, "", JER, GOLD, "Hebrew Bible, 2 Samuel 5. About 1000 BCE"),
 (5, "ASSYRIA", -722, (43.15, 36.36), "Nineveh", (35.19, 32.28), "#FF6B6B", "Fall of Samaria, 722 BCE"),
 (6, "BABYLON", -586, (44.42, 32.54), "Babylon", JER, "#FF9F43", "First Temple destroyed, 586 BCE"),
 (7, "PERSIA", -539, (52.89, 29.93), "Persepolis", JER, "#5AC8FA", "Cyrus takes Babylon, 539 BCE. Ezra 1"),
 (8, "ALEXANDER", -332, (22.52, 40.76), "Macedonia", (34.45, 31.50), "#64D2FF", "Sieges of Tyre and Gaza, 332 BCE"),
 (9, "THE MACCABEES", -140, None, "", JER, GOLD, "Hasmonean independence, about 140 BCE"),
 (10, "ROME", 70, (12.50, 41.90), "Rome", JER, "#FF453A", "Titus destroys the Second Temple, 70 CE"),
 (11, "BYZANTIUM", 330, (28.98, 41.01), "Constantinople", JER, "#BF5AF2", "Byzantine rule from about 330 CE"),
 (12, "ARAB CONQUEST", 636, (39.61, 24.47), "Medina", (35.95, 32.75), "#30D158", "Battle of the Yarmouk, 636 CE"),
 (13, "CRUSADERS", 1099, (3.08, 45.78), "Clermont", JER, "#E5E5EA", "First Crusade takes Jerusalem, 15 July 1099"),
 (14, "MAMLUKS", 1260, (31.24, 30.04), "Cairo", (35.42, 32.55), "#FFD60A", "Battle of Ain Jalut, Jezreel Valley, 1260"),
 (15, "OTTOMANS", 1516, (28.98, 41.01), "Istanbul", JER, "#FF375F", "Ottoman rule 1516 to 1917"),
 (16, "BRITAIN", 1917, (-0.13, 51.50), "London", JER, "#0A84FF", "Allenby: Jerusalem Dec 1917, Megiddo Sep 1918"),
 (17, "ISRAEL", 1948, None, "", JER, GOLD, "Independence declared 14 May 1948"),
]
R = []
for i, (li, title, yr, org, olab, tgt, col, src) in enumerate(RUL):
    t0 = S(li) - 0.12; t1 = (S(RUL[i + 1][0]) - 0.12) if i + 1 < len(RUL) else S(18) - 0.12
    if li == 2: t1 = S(4) - 0.12
    R.append(dict(n=i + 1, li=li, title=title, yr=yr, org=org, olab=olab, tgt=tgt, col=col, src=src, t0=t0, t1=t1))
T_MEG = S(1) - 0.12; T_ARM = S(3) - 0.12; T_REV = S(18) - 0.12; T_BORN = S(19) - 0.12; T_JER = S(20) - 0.12; T_MARK = S(21) - 0.12; T_END_L = S(22) - 0.12
T_BRIT_MEG = S(16, WI(16, "wins")) - 0.05
# 3 Nov (Noam): Armageddon / Har Megiddo is the hook at frame 0, then the 3,500 years question
T_ISRW = S(0, WI(0, "In")) - 0.05; T_H2 = S(0, WI(0, "Three")) - 0.12

# ------------------------------------------------------------------ cameras
C_WIDE = camw(35.6, JER[1], 34.0, 900)
C_ISR = camw(35.1, 31.85, 4.8, 900)
C_JER = camw(35.22, 31.78, 1.5, 900)
def camera(t):
    if t < T_MEG: z = 1 + 0.03 * seg(t, 0, T_MEG); return Cam(C_WIDE.lon, C_WIDE.lat, C_WIDE.k * z, C_WIDE.cy)
    w0 = Cam(C_WIDE.lon, C_WIDE.lat, C_WIDE.k * 1.03, C_WIDE.cy)
    if t < R[1]["t0"]: return cam_lerp(w0, C_ISR, seg(t, T_MEG, T_MEG + 1.3))
    if t < R[14]["t0"]:
        c = cam_lerp(C_ISR, C_WIDE, seg(t, R[1]["t0"], R[1]["t0"] + 1.1))
        c.k *= 1 + 0.04 * seg(t, R[1]["t0"] + 1.1, R[14]["t0"]); return c      # slow push while the race runs
    cw = Cam(C_WIDE.lon, C_WIDE.lat, C_WIDE.k * 1.04, C_WIDE.cy)
    if t < T_REV: return cam_lerp(cw, C_ISR, seg(t, R[14]["t0"], R[14]["t0"] + 1.0))
    if t < T_JER: return cam_lerp(C_ISR, C_WIDE, seg(t, T_REV, T_REV + 0.9))
    if t < T_MARK: return cam_lerp(C_WIDE, C_JER, seg(t, T_JER, T_JER + 1.0))
    return cam_lerp(C_JER, C_WIDE, seg(t, T_MARK, T_MARK + 1.2))

# ------------------------------------------------------------------ arrows
def bez(p0, p1, bend):
    mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2; dx, dy = p1[0] - p0[0], p1[1] - p0[1]; L_ = math.hypot(dx, dy) + 1e-6
    cxp, cyp = mx - dy / L_ * bend * L_, my + dx / L_ * bend * L_
    ts = np.linspace(0, 1, 60)[:, None]
    return (1 - ts) ** 2 * np.array(p0) + 2 * (1 - ts) * ts * np.array([cxp, cyp]) + ts ** 2 * np.array(p1)
def arrow(c, pts, prog, col, alpha, lw=10):
    if alpha <= 0.004 or prog <= 0.01: return
    n = max(2, int(len(pts) * prog)); p = pts[:n]
    v = hx(col) / 255
    c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    for wdt, cc, al in ((lw + 7, (0, 0, 0), 0.55), (lw, tuple(v), 1.0)):
        c.move_to(*p[0])
        for q in p[1:]: c.line_to(*q)
        c.set_source_rgba(*cc, al * alpha); c.set_line_width(wdt); c.stroke()
    tip = p[-1]; back = p[max(0, n - 6)]; ang = math.atan2(tip[1] - back[1], tip[0] - back[0]); hl = lw * 2.8
    for grow, cc, al in ((5, (0, 0, 0), 0.55), (0, tuple(v), 1.0)):
        h = hl + grow; c.move_to(tip[0] + math.cos(ang) * grow * 0.6, tip[1] + math.sin(ang) * grow * 0.6)
        c.line_to(tip[0] - h * math.cos(ang - 0.5), tip[1] - h * math.sin(ang - 0.5))
        c.line_to(tip[0] - h * math.cos(ang + 0.5), tip[1] - h * math.sin(ang + 0.5)); c.close_path()
        c.set_source_rgba(*cc, al * alpha); c.fill()
def ring(c, x, y, r, col, alpha, lw=6):
    if alpha <= 0.004: return
    v = hx(col) / 255; c.arc(x, y, r, 0, 2 * math.pi); c.set_source_rgba(*v, alpha); c.set_line_width(lw); c.stroke()
def dot(c, x, y, r, col, alpha):
    if alpha <= 0.004: return
    v = hx(col) / 255; c.arc(x, y, r + 3, 0, 2 * math.pi); c.set_source_rgba(0, 0, 0, 0.6 * alpha); c.fill()
    c.arc(x, y, r, 0, 2 * math.pi); c.set_source_rgba(*v, alpha); c.fill()

def map_layer(canvas, t, cam, labels):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); c.set_line_join(cairo.LINE_JOIN_ROUND)
    va = seg(cam.k, 70, 150)
    if va > 0:
        for k, rs in LOCAL.items(): solid(c, cam, rs, "#1D1E1A", 0.85 * va, 1.2, "#6A6B62")
    # the whole land: Israel gold, West Bank and Gaza a slightly different shade, Green Line green
    solid(c, cam, PSX, PSX_GOLD, 0.95); solid(c, cam, ISR_ONLY, ISR_GOLD, 0.95)
    path(c, cam, PSX); c.set_source_rgba(*GREEN, 1.0); c.set_line_width(min(5.0, 1.4 + cam.k / 90)); c.stroke()
    # arrows: each draws in, holds bright for its beat, then stays as a faint trail
    reveal = seg(t, T_REV + 0.2, T_REV + 0.6) * (1 - seg(t, T_BORN, T_BORN + 0.4))
    marks = seg(t, T_MARK, T_MARK + 0.8) * (1 - seg(t, T_END_L + 0.2, T_END_L + 1.0))
    for i, r in enumerate(R):
        tx, ty = ll2xy(cam, *r["tgt"])
        if r["org"] is None:
            # born here: gold pulse rings
            for k in range(2):
                u = (t - r["t0"] - 0.1 - 0.35 * k) / 1.1
                if 0 < u < 1: ring(c, tx, ty, 14 + 120 * eout(u), GOLD, 0.95 * (1 - u), 7)
            hold = seg(t, r["t0"], r["t0"] + 0.3) * (1 - seg(t, r["t1"], r["t1"] + 0.4))
            born = seg(t, T_BORN + 0.1, T_BORN + 0.5) * (1 - seg(t, T_JER, T_JER + 0.4))
            if born > 0:
                u = ((t - T_BORN - 0.1 - 0.25 * [1, 6, 14].index(i)) % 1.4) / 1.4
                ring(c, tx, ty, 14 + 90 * eout(u), GOLD, born * (1 - u), 6)
            dot(c, tx, ty, 9, GOLD, max(hold, born, 0.0))
            continue
        ox, oy = ll2xy(cam, *r["org"]); pts = bez((ox, oy), (tx, ty), 0.18 if i % 2 else -0.18)
        prog = eout((t - r["t0"] - 0.05) / 0.85)
        bright = 1 - seg(t, r["t1"], r["t1"] + 0.5)
        a = 0.95 * bright + 0.32 * (1 - bright)
        a = max(a, 0.95 * reveal, 0.6 * marks) if t > r["t0"] else a
        if bright < 0.5: a *= 1 - seg(cam.k, 60, 140)          # faint trails clear away when the camera dives in
        if t > r["t0"]: arrow(c, pts, prog, r["col"], a, 10 if bright > 0.5 else 8)
        if t > r["t0"]:
            dot(c, ox, oy, 8, r["col"], bright * 0.95)
            labels.append((r["olab"], ox, oy, bright * seg(t, r["t0"], r["t0"] + 0.3)))
    # hook shimmer: the foreign arrows flash in, one after another (motion by 1.5 s), and again on the loop
    for i, r in enumerate([r for r in R if r["org"]]):
        for base in (0.0,):
            a0 = base + 0.15 + 0.11 * i; u = t - a0
            if 0 < u < 1.4 and t < T_MEG:
                ox, oy = ll2xy(cam, *r["org"]); tx, ty = ll2xy(cam, *r["tgt"]); pts = bez((ox, oy), (tx, ty), 0.18 if i % 2 else -0.18)
                arrow(c, pts, eout(u / 0.6), r["col"], 0.55 * (1 - seg(u, 0.8, 1.4)), 7)
    # Megiddo marker (lines 1 to 3, and Britain's 1918 battle)
    mx, my = ll2xy(cam, *MEG)
    ma = max(seg(t, T_MEG + 0.6, T_MEG + 1.0) * (1 - seg(t, R[1]["t0"], R[1]["t0"] + 0.4)), 1 - seg(t, T_H2, T_H2 + 0.4))
    mb = seg(t, T_BRIT_MEG, T_BRIT_MEG + 0.3) * (1 - seg(t, R[14]["t0"] - 0.1, R[14]["t0"] + 0.3))
    if ma > 0 or mb > 0:
        dot(c, mx, my, 9, WHITE, max(ma, mb)); u = (t * 0.8) % 1; ring(c, mx, my, 12 + 60 * u, WHITE, max(ma, mb) * (1 - u), 4)
        labels.append(("Megiddo", mx, my, max(ma, mb)))
    if mb > 0:
        u = eout((t - T_BRIT_MEG) / 0.7); ox, oy = ll2xy(cam, *JER); arrow(c, bez((ox, oy), (mx, my), 0.25), u, "#0A84FF", mb, 8)
    # Jerusalem (payoff)
    ja = seg(t, T_JER + 0.5, T_JER + 0.9) * (1 - seg(t, T_MARK + 0.2, T_MARK + 0.8))
    if ja > 0:
        jx, jy = ll2xy(cam, *JER); dot(c, jx, jy, 12, WHITE, ja); u = (t * 0.7) % 1; ring(c, jx, jy, 16 + 80 * u, WHITE, ja * (1 - u), 5)
        labels.append(("Jerusalem", jx, jy, ja))
    surf.flush()
    a = np.ndarray((H, W, 4), np.uint8, surf.get_data()).copy()
    rgba = a[:, :, [2, 1, 0, 3]].astype(np.float32); al = rgba[:, :, 3:4] / 255.0
    col = np.where(al > 0, rgba[:, :, :3] / np.maximum(al, 1e-6), 0)
    canvas.alpha_composite(Image.fromarray(np.dstack([col, al * 255]).clip(0, 255).astype(np.uint8), "RGBA"))

def place_labels(canvas, t, labels):
    for s, x, y, a in labels:
        if a <= 0.01 or not s: continue
        off = x < 30 or x > W - 30 or y < 0 or y > H
        lab = ("from " + s) if off else s
        sz = 44; w_ = font("dsb", sz).getlength(lab)
        lx = min(max(x, 70 + w_ / 2), W - 70 - w_ / 2); ly = min(max(y - 42, 700), 1420) if off else y - 40
        if s in ("Megiddo", "Jerusalem"): ly = y - 52
        text(canvas, t, lab, ly, sz, -1, 1e9, fk="dsb", color=WHITE, alpha=a, cx=lx)

# vignette: darker top and bottom for the titles, subtitles and sources
_v = np.zeros((H, W), np.float32); yy = np.arange(H)[:, None]
_v += np.clip((760 - yy) / 760, 0, 1) ** 1.3 * 0.82 + np.clip((yy - 1380) / 540, 0, 1) ** 1.3 * 0.85
VIG = Image.fromarray(np.dstack([np.zeros((H, W, 3), np.uint8), (_v.clip(0, 1) * 255).astype(np.uint8)]), "RGBA")

# ------------------------------------------------------------------ photos (free licences, Ken Burns in a rounded panel, credit inside)
PH = {"megiddo": ("megiddo.jpg", 0.45, 0.55, "Tel Megiddo. Avram Graicer, CC BY-SA 3.0"),
      "lachish": ("lachish.jpg", 0.5, 0.45, "Lachish relief. O. S. M. Amin, CC BY-SA 4.0"),
      "titus": ("titus1.jpg", 0.5, 0.4, "Arch of Titus, Rome. Public domain"),
      "jezreel": ("jezreel.jpg", 0.5, 0.55, "Jezreel Valley. J. Freeman, CC BY-SA 2.5")}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
_grad = {}
def photo(canvas, t, k, t0, t1, box):
    a = seg(t, t0, t0 + 0.4) * (1 - seg(t, t1, t1 + 0.35))
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size; cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC).convert("RGBA")
    if (w, h) not in _grad:
        g = np.clip((np.arange(h) - (h - 120)) / 120, 0, 1)[:, None] * np.ones((1, w)); _grad[(w, h)] = Image.fromarray((g * 200).astype(np.uint8), "L")
    blk = Image.new("RGBA", (w, h), (0, 0, 0, 255)); blk.putalpha(_grad[(w, h)]); crop.alpha_composite(blk)
    d = ImageDraw.Draw(crop); f = font("r", 36); s = PH[k][3]
    assert f.getlength(s) <= w - 40, s
    d.text((w / 2, h - 34), s, font=f, fill=(225, 225, 230, 255), anchor="mm")
    m = rmask(w, h, 30); crop.putalpha(Image.fromarray((np.asarray(m, np.float32) * a).astype(np.uint8), "L"))
    sh = Image.new("RGBA", (w + 60, h + 60), (0, 0, 0, 0)); ImageDraw.Draw(sh).rounded_rectangle((30, 30, w + 30, h + 30), 30, fill=(0, 0, 0, int(150 * a)))
    canvas.alpha_composite(sh.filter(ImageFilter.GaussianBlur(14)), (x0 - 30, y0 - 22)); canvas.alpha_composite(crop, (x0, y0))
BOX_LOW = (90, 1010, 990, 1470)
PHOTOS = [("megiddo", T_MEG + 0.1, R[0]["t0"] + 1.6, BOX_LOW),
          ("lachish", R[2]["t0"] + 0.4, R[4]["t1"] - 0.2, BOX_LOW),
          ("titus", R[7]["t0"] + 0.5, R[8]["t1"] - 0.2, BOX_LOW),
          ("jezreel", R[11]["t0"] + 0.5, R[12]["t1"] - 0.2, BOX_LOW)]
for k, a_, b_, _ in PHOTOS: assert b_ - a_ >= 2.9, (k, b_ - a_)

# ------------------------------------------------------------------ subtitles (Heebo ExtraBold 54 px, white on a dark rounded box)
SUBF = ImageFont.truetype(HEB, 54)
REPL = [("Three and a half thousand", "3,500"), ("Nineteen forty eight", "1948"), ("a hundred and eighteen", "118"), ("four hundred", "400"),
        ("Fifteen", "15"), ("Twelve", "12"), ("Three", "3"), ("three", "3")]
SUBS = []; TOK = {}
for li in sorted(LW):           # display tokens: spoken number phrases become one token ("a hundred and eighteen" -> "118")
    src = LW[li]; out = []; i = 0
    while i < len(src):
        hit = None
        for a_, b_ in REPL:
            n_ = len(a_.split()); ph = " ".join(w["w"] for w in src[i:i + n_])
            if ph.rstrip(",.:?!") == a_ or ph == a_: hit = (n_, b_ + ph[len(a_):]); break
        if hit: out.append(dict(w=hit[1], t0=src[i]["t0"], t1=src[i + hit[0] - 1]["t1"])); i += hit[0]
        else: out.append(dict(src[i])); i += 1
    TOK[li] = out
for li in sorted(TOK):
    ws = TOK[li]; cur = []
    for i, w in enumerate(ws):
        cur.append(i)
        if (re.search(r"[,.:?!]$", w["w"]) and len(cur) >= 2) or i == len(ws) - 1:
            k_ = math.ceil(len(cur) / 6); n_ = len(cur)
            for j in range(k_): SUBS.append((li, cur[j * n_ // k_:(j + 1) * n_ // k_]))
            cur = []
CH = []
for k, (li, idx) in enumerate(SUBS):
    s = " ".join(TOK[li][i]["w"] for i in idx)
    s = s.strip().rstrip(",")
    a = TOK[li][idx[0]]["t0"] - 0.04; b = TOK[li][idx[-1]]["t1"] + 0.3
    if k + 1 < len(SUBS): nl, ni = SUBS[k + 1]; b = min(b, TOK[nl][ni[0]]["t0"] - 0.04)
    CH.append((a, b, s))
def subtitles(canvas, t):
    for a, b, s in CH:
        if a <= t < b:
            al = min(1, (t - a) / 0.08 + 1e-4, (b - t) / 0.08)
            words = s.split(); lines = [[]]
            for w_ in words:
                tr = " ".join(lines[-1] + [w_])
                if SUBF.getlength(tr) <= 900 or not lines[-1]: lines[-1].append(w_)
                else: lines.append([w_])
            lines = [" ".join(l) for l in lines]; lh = 70; tw = max(SUBF.getlength(l) for l in lines)
            y_bot = 1640; y0 = y_bot - lh * len(lines) - 18
            lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            d.rounded_rectangle((540 - tw / 2 - 26, y0, 540 + tw / 2 + 26, y_bot), 22, fill=(10, 14, 28, int(205 * al)))
            for i, l in enumerate(lines): d.text((540, y0 + 18 + lh * i + lh / 2 - 4), l, font=SUBF, fill=(255, 255, 255, int(255 * al)), anchor="mm")
            canvas.alpha_composite(lay)

# ------------------------------------------------------------------ sources (36 px, grey, above the subtitles)
SRCF = font("r", 36)
SRC0 = "Map: NASA Blue Marble, Natural Earth. Green Line: green"
SOURCES = [(0, ["Har Megiddo (Armageddon), Revelation 16:16"]), (T_H2, [SRC0]), (T_MEG, ["Battle of Megiddo: the first battle recorded in detail"])] + [(r["t0"], [r["src"]]) for r in R] + [
    (T_ARM, ["Har Megiddo, Revelation 16:16"]), (R[1]["t0"], [R[1]["src"]]),
    (T_REV, ["Main rulers only. Also Seleucids, Fatimids and more"]),
    (T_JER, ["Eric H. Cline, Jerusalem Besieged, 2004"]), (T_MARK, [SRC0])]
SOURCES.sort(key=lambda x: x[0])
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        if t0 - 0.01 <= t < t1 + 0.2:
            a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.25)) * (1 - seg(t, t1 - 0.05, t1 + 0.15))
            for j, l in enumerate(lines): text(canvas, t, l, 1500 + j * 44, 36, -1, 1e9, fk="r", color=GREY, alpha=a)

# ------------------------------------------------------------------ year counter and ruler counter
def year_at(t):
    prev = None
    for r in R:
        if t < r["t0"]: break
        prev = r
    if prev is None: return None
    i = R.index(prev); y0 = R[i - 1]["yr"] if i > 0 else -1457
    u = seg(t, prev["t0"], prev["t0"] + 0.55); return lerp(y0, prev["yr"], u)
def fmt_year(y):
    y = int(round(y))
    if y < 0: return f"{-y} BCE"
    if y < 1000: return f"{max(1, y)} CE"
    return f"{y}"
PIP_Y = 640
def pips(canvas, t, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, 80), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); n_on = sum(1 for r in R if t >= r["t0"] + 0.1)
    for i, r in enumerate(R):
        x = 540 + (i - 7) * 60; on = i < n_on; born = r["org"] is None
        if t >= T_REV: col = (242, 201, 76) if born else (255, 255, 255)
        else: col = (242, 201, 76) if born else (255, 255, 255)
        rr = 17 if (on and t < r["t0"] + 0.4 and t >= r["t0"]) else 14
        hi = born and T_BORN <= t
        if hi: rr = 18
        if on: d.ellipse((x - rr, 40 - rr, x + rr, 40 + rr), fill=col + (int(255 * alpha),), outline=(0, 0, 0, int(160 * alpha)), width=3)
        else: d.ellipse((x - 13, 27, x + 13, 53), outline=(255, 255, 255, int(150 * alpha)), width=3)
    canvas.alpha_composite(lay, (0, PIP_Y - 40))

# ------------------------------------------------------------------ frame
HOOK = ("3,500 YEARS.", "WHO CONQUERED", "THIS LAND?")
HOOKA = ("ARMAGEDDON", "IS A REAL PLACE.", "IN ISRAEL.")
HSA = min(fit(h, "db", 132) for h in HOOKA)
HS = min(fit(h, "db", 132) for h in HOOK); HY = (330, 330 + HS * 1.14, 330 + 2 * HS * 1.14)
ENDL = ("SO, NEXT TIME", "SOMEONE", "ASKS YOU...")
ES = HS
TITLE_Y, YEAR_Y, CNT_Y = 300, 425, 535
def frame_raw(t):
    cam = camera(t); im = background(cam); labels = []; map_layer(im, t, cam, labels); im.alpha_composite(VIG); place_labels(im, t, labels)
    for k, a_, b_, box in PHOTOS: photo(im, t, k, a_, b_, box)
    # hook (frame 0, said once) and the lead-in in the same place
    for j in range(3):
        text(im, t, HOOKA[j], HY[j], HSA, 0 if j < 2 else T_ISRW, T_H2 - 0.05, inst=j < 2, zoom=1 + 0.03 * seg(t, 0, T_H2), color=GOLD if j == 0 else WHITE)
        text(im, t, HOOK[j], HY[j], HS, T_H2 + 0.06 * j, T_MEG - 0.1, zoom=1 + 0.03 * seg(t, T_H2, T_MEG), color=GOLD if j == 0 else WHITE)
        text(im, t, ENDL[j], HY[j], ES, T_END_L + 0.08 * j, T_END, ain=0.35, color=GOLD if j == 0 else WHITE)
    # Megiddo intro and Armageddon
    text(im, t, "MEGIDDO", TITLE_Y, 120, T_MEG, R[0]["t0"] - 0.05)
    text(im, t, "ARMAGEDDON", TITLE_Y, fit("ARMAGEDDON", "db", 124), T_ARM, R[1]["t0"] - 0.1, color=GOLD)
    text(im, t, "from Har Megiddo, Mount Megiddo", YEAR_Y + 10, fit("from Har Megiddo, Mount Megiddo", "dsb", 64), T_ARM + 0.15, R[1]["t0"] - 0.1, fk="dsb")
    # the race: title, year, counter, pips
    race_a = seg(t, R[0]["t0"], R[0]["t0"] + 0.3) * (1 - seg(t, T_JER - 0.1, T_JER + 0.3))
    for i, r in enumerate(R):
        t0, t1 = r["t0"], r["t1"]
        if i == 0: t1 = T_ARM
        tt = r["title"]; text(im, t, tt, TITLE_Y, fit(tt, "db", 116), t0, t1 - 0.08, ain=0.2, color=GOLD if r["org"] is None else WHITE)
        text(im, t, f"RULER {r['n']} OF 15", CNT_Y, 46, t0 + 0.05, t1 - 0.08, fk="dsb", color=GREY, ain=0.2, tab=True)
    if not (T_ARM <= t < R[1]["t0"]):
        y = year_at(t)
        if y is not None and t < T_REV: text(im, t, fmt_year(y), YEAR_Y, 96, -1, T_REV - 0.12, fk="db", color=GOLD, tab=True, alpha=race_a)
    pips(im, t, race_a)
    # reveal
    text(im, t, "15 RULERS", TITLE_Y, 120, T_REV, T_JER - 0.1)
    rich(im, t, [("12", WHITE), (" marched in from abroad", GREY)], YEAR_Y, fit("12 marched in from abroad", "dsb", 68), T_REV + 0.35, T_JER - 0.1, fk="dsb")
    rich(im, t, [("3", GOLD), (" born here. All 3 Jewish.", GOLD)], CNT_Y, fit("3 born here. All 3 Jewish.", "dsb", 68), T_BORN, T_JER - 0.1, fk="dsb")
    # Jerusalem payoff
    tn = S(20, WI(20, "least")); v = lerp(0, 118, eout((t - tn) / 1.4)) if t > tn else 0
    text(im, t, "JERUSALEM ALONE", TITLE_Y, 104, T_JER, T_MARK - 0.1)
    text(im, t, f"{int(round(v))}", YEAR_Y + 60, 200, tn - 0.1, T_MARK - 0.1, color=GOLD, tab=True)
    text(im, t, "conflicts, at least", YEAR_Y + 205, 64, tn, T_MARK - 0.1, fk="dsb")
    # fair line
    text(im, t, "EVERY ONE OF THEM", TITLE_Y, fit("EVERY ONE OF THEM", "db", 110), T_MARK, T_END_L - 0.1)
    text(im, t, "LEFT A MARK", TITLE_Y + 125, 110, T_MARK + 0.25, T_END_L - 0.1, color=GOLD)
    sources(im, t); subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS)); return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in CH] + [l for _, v in SOURCES for l in v] + [r["title"] for r in R] + list(HOOK) + list(HOOKA) + list(ENDL) + [v[3] for v in PH.values()]
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam|follow", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 1000, ("source too wide", l, SRCF.getlength(l))
for _, _, s in CH: assert len(s.split()) <= 7, s
if os.environ.get("AM_SUBS"): print("\n".join(f"{a:6.2f} {b:6.2f} {s}" for a, b, s in CH)); sys.exit()
assert len(" ".join(HOOKA[:2]).split()) <= 6   # frame 0: "ARMAGEDDON IS A REAL PLACE."
N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
