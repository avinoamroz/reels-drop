"""armies_map voice: one Cartesia SSE clip (clips/p0.wav + _words.json) -> work/vo.wav (48 kHz, house chain) + work/words.json.
From israel_iran/tools/voice_build.py. Lines cut at the real pauses; internal pauses over MAXG squeezed; GAP after each line (reel pace)."""
import json, re, sys, wave, os
import numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice as V
D = "/home/claude/fix_1103/armies_map"; SR0 = 44100; TEMPO = float(os.environ.get("AM_TEMPO", "1.0")); V.TEMPO = TEMPO; LEAD = 0.12; V.LEAD = LEAD
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
GAP = {0: 0.50, 1: 0.18, 2: 0.25, 3: 0.50, 4: 0.30, 5: 0.15, 6: 0.15, 7: 0.15, 8: 0.15, 9: 0.25, 10: 0.20, 11: 0.15, 12: 0.15, 13: 0.15,
       14: 0.20, 15: 0.20, 16: 0.50, 17: 0.60, 18: 0.35, 19: 0.70, 20: 0.60, 21: 0.40}
MAXG = 0.30
SPOKEN = {}
def norm(s): return re.sub(r"[^\w]", "", s.lower())
def load(p):
    w = wave.open(p); return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
def map_words(script_words, W):
    cw = [(norm(x["word"]), x["start"], x["end"]) for x in W if norm(x["word"])]
    tot = sum(len(c[0]) for c in cw); pos = 0; spans = []
    for c in cw: spans.append((pos / tot, (pos + len(c[0])) / tot, c[1], c[2])); pos += len(c[0])
    def t_at(f):
        for f0, f1, s, e in spans:
            if f <= f1 + 1e-9: u = 0 if f1 == f0 else (f - f0) / (f1 - f0); return s + (e - s) * min(1, max(0, u))
        return spans[-1][3]
    sn = [norm(x) for x in script_words]; stot = sum(max(1, len(x)) for x in sn); pos = 0; out = []
    for x, n_ in zip(script_words, sn):
        Ln = max(1, len(n_)); f0, f1 = pos / stot, (pos + Ln) / stot; pos += Ln
        out.append((x, t_at(f0 + 1e-6), t_at(f1 - 1e-6)))
    return out
a = load(f"{D}/clips/p0.wav"); W = json.load(open(f"{D}/clips/p0_words.json"))
cw = [norm(x["word"]) for x in W]; sw = [norm(x) for l in L for x in l.split()]
if cw == sw:   # exact word match: use Cartesia's own word times
    it = iter(W); LINES = {li: [(x, (w := next(it))["start"], w["end"]) for x in l.split()] for li, l in enumerate(L)}
else:
    print("word mismatch, char mapping", len(cw), len(sw))
    sw_ = []; own = []
    for li, l in enumerate(L):
        for x in l.split(): sw_.append(x); own.append(li)
    mw = map_words(sw_, W); LINES = {li: [m for m, o in zip(mw, own) if o == li] for li in range(len(L))}
chunks = []; words = []; t = 0.0
for li in range(len(L)):
    ws = LINES[li]
    s0 = max(0, ws[0][1] - 0.06); e0 = min(len(a) / SR0, ws[-1][2] + (0.40 if li == len(L) - 1 else 0.10))
    if li + 1 < len(L): e0 = min(e0, max(ws[-1][2] + 0.02, LINES[li + 1][0][1] - 0.07))
    keep = []; cur = s0
    for i in range(len(ws) - 1):
        g0, g1 = ws[i][2], ws[i + 1][1]
        if g1 - g0 > MAXG: ex = g1 - g0 - MAXG; m = (g0 + g1) / 2; keep.append((cur, m - ex / 2)); cur = m + ex / 2
    keep.append((cur, e0))
    def mp(x):
        acc = 0.0
        for k0, k1 in keep:
            if x <= k1: return t + acc + max(0, x - k0)
            acc += k1 - k0
        return t + acc
    for w_, a_, b_ in ws: words.append(dict(li=li, w=w_, p0=mp(a_), p1=mp(max(b_, a_ + 0.04))))
    for k0, k1 in keep:
        seg = a[int(k0 * SR0):int(k1 * SR0)].copy(); f = min(len(seg) // 2, int(0.008 * SR0))
        if f: seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        chunks.append(seg); t += len(seg) / SR0
    if li in GAP: chunks.append(np.zeros(int(GAP[li] * SR0), np.float32)); t += GAP[li]
raw = np.concatenate(chunks); sf.write(f"{D}/work/raw.wav", raw, SR0)
dry = V.chain_dry(f"{D}/work/raw.wav"); cl = V.clean_vo(dry, V.SR); y, sp = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
vo = V.post(y); vo = vo / (np.abs(vo).max() + 1e-9) * 0.89
sf.write(f"{D}/work/vo.wav", vo.astype(np.float32), V.SR)
for w in words: w["t0"] = round(LEAD + w.pop("p0") / TEMPO, 3); w["t1"] = round(LEAD + w.pop("p1") / TEMPO, 3)
json.dump(dict(words=words, dur=round(len(vo) / V.SR, 3)), open(f"{D}/work/words.json", "w"), indent=0, ensure_ascii=False)
os.remove(f"{D}/work/raw.wav")
print("vo", round(len(vo) / V.SR, 2), "s")
for li in range(len(L)):
    ws = [w for w in words if w["li"] == li]; print(li, ws[0]["t0"], ws[-1]["t1"], L[li])
