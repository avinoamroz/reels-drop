import json, numpy as np
def land_polys(path="/home/claude/geo/package/land-110m.json"):
    t=json.load(open(path)); sc,tr=t["transform"]["scale"],t["transform"]["translate"]
    arcs=[]
    for a in t["arcs"]:
        x=y=0; pts=[]
        for dx,dy in a: x+=dx; y+=dy; pts.append((x*sc[0]+tr[0], y*sc[1]+tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i>=0 else arcs[~i][::-1]
    polys=[]
    for g in t["objects"]["land"]["geometries"]:
        rings = g["arcs"] if g["type"]=="Polygon" else [r for p in g["arcs"] for r in p]
        for ring in rings:
            pts=[]
            for i in ring: pts.extend(arc(i))
            polys.append(np.array(pts))
    return polys
