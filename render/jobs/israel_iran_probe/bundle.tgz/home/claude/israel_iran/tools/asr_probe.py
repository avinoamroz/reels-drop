"""cloud ASR probe: black video + work/mix.m4a (first 14 s) -> israel_iran_probe.mp4 (deleted after the check)"""
import subprocess
D = "/home/claude/israel_iran"
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=540x960:r=30", "-i", f"{D}/work/mix.m4a",
                "-map", "0:v", "-map", "1:a", "-t", "14", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "copy", f"{D}/israel_iran_probe.mp4"], check=True)
