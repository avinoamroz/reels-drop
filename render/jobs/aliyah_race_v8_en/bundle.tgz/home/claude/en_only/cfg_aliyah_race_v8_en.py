exec(open("/home/claude/vid/cfg_aliyah.py").read())
SNAPDIR="/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/en_only/snaps"
T_TOTAL=45.0; T_DATA=43.6; T_ENDC=44.2
TAG="aliyah_race_v8_en"; OUT_EN="/home/claude/en_only/out/aliyah_race_v8_en.mp4"; MUSIC="/home/claude/vid/music/p_t08.wav"
ROWS_EN=5
TL_EN=[(1890,0),(1948,14),(1952,19),(1989,27),(2000,32),(2026,40)]
HOOK_EN=["Where did your","family come from?"]
SUB_EN="Immigrants to Israel, by origin"
SHORT_EN={}
COUNTER_EN="Jews in Israel"
REVEAL_EN=(30.0,35.6,["Since 1989, over 1M","from the former USSR"])
END_EN=["Now you.","Tell me..."]
SRC_EN="Approximate. Sources: CBS, Jewish Agency"
