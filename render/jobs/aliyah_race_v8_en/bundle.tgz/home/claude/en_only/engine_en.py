"""English-only, big-text bar race (with optional Israel dot/circle map) for @noamroz__.
Reads an original /home/claude/vid/cfg_*.py (data, events, map) through a small en_only cfg that adds
the English hook, reveal, end line and short sources. Hebrew fields of the original cfg are never drawn.
usage: python3 engine_en.py CFG.py [--snaps 0,10,30]   (snaps: PNG stills into SNAPDIR, no video)
Layout keeps the IG safe zone: content x 64..900 (right 180 clear), y <= 1540 (bottom 380 clear).
"""
import sys, os, math, runpy, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from matplotlib.path import Path

ap = argparse.ArgumentParser(); ap.add_argument("cfg"); ap.add_argument("--snaps"); A = ap.parse_args()
C = runpy.run_path(A.cfg)
W, H, FPS, S = 1080, 1920, 30, 2
X0, X1 = 64, 900; CX = (X0 + X1) / 2; YMAX = 1540
T_TOTAL = C.get("T_TOTAL", 45.0); T_DATA = C.get("T_DATA", 43.6); T_ENDC = C.get("T_ENDC", 44.2)
FONTD = "/home/claude/vid/fonts"
def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY_T, NAVY_B = hx("#0E1E3A"), hx("#163260"); BLUE = hx("#2A88D4"); BLUE_L = hx("#59A5DF")
GOLD = hx("#B8923F"); GOLD2 = hx("#E6C77E"); SILVER = hx("#D9DDE3"); SILVER2 = hx("#A9B6CB"); WHITE = hx("#FFFFFF")
GREEN = hx("#1E9E62")
_fc = {}
def font(sz, w=800):
    k = (int(sz * S), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTD}/Heebo-{w}.ttf", k[0])
    return _fc[k]
DASHES = ("–", "—", "‒", "―")
def clean(s):
    for d in DASHES: s = s.replace(d, ",")
    assert not any("֐" <= ch <= "׿" for ch in s), "Hebrew in English-only text: " + s
    return s
def tw(s, sz, w=800): return font(sz, w).getlength(s) / S
def fit(s, sz, maxw, w=800, mn=None):
    mn = mn or sz * 0.9
    while tw(s, sz, w) > maxw and sz > mn: sz -= 1
    return sz
def txt(d, x, y, s, sz, col, w=800, anchor="la", alpha=1.0):
    c = col[:3] + (int(col[3] * alpha),)
    d.text((x * S, y * S), clean(s), font=font(sz, w), fill=c, anchor=anchor)
def wrap(s, sz, maxw, w=800):
    words, lines, cur = s.split(), [], ""
    for wd in words:
        t = (cur + " " + wd).strip()
        if tw(t, sz, w) <= maxw or not cur: cur = t
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines

# ------------------------------------------------------------------ data
G = C["G"]; names = list(G); ROWS = C.get("ROWS_EN", 5); MIN = C.get("MIN", 1)
SHORT = C.get("SHORT_EN", {})
TL0 = list(C.get("TL_EN", C["TL"])); k_ = T_DATA / TL0[-1][1]
TL = [(y, t * k_) for y, t in TL0]; ty = [t for _, t in TL]; yy = [y for y, _ in TL]
ANCIENT = yy[0] < 0
def val(pts, y):
    if y < pts[0][0]: return 0.0
    if y > pts[-1][0]: return float(pts[-1][1])
    return float(np.interp(y, [p[0] for p in pts], [p[1] for p in pts]))
def fmt_n(v):
    if v < 1000: return f"{int(round(v)):,}"
    return f"{v / 1e6:.2f}M" if v >= 1e6 else f"{int(round(v, -3 if v >= 10000 else -2)):,}"
def fmt_big(v): return f"{int(round(v, -3 if v >= 10000 else 0)):,}"
FLAGS = {}
def flag(code, h):
    k = (code, h)
    if k not in FLAGS:
        f = Image.open(f"/home/claude/vid/flags/{code}.png").convert("RGBA"); w = int(h * S * f.width / f.height)
        f = f.resize((w, int(h * S)), Image.LANCZOS); m = Image.new("L", f.size, 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, f.width - 1, f.height - 1], int(5 * S), fill=255); f.putalpha(m); FLAGS[k] = f
    return FLAGS[k]
FLC = C.get("FLAGS", {})

# ------------------------------------------------------------------ layout
MAP = C.get("MAP"); SHARE = C.get("SHARE_EN")
Y_HOOK = 140; HOOK_FS = C.get("HOOK_FS", 100); HOOK_LH = HOOK_FS * 1.06
Y_SUB = Y_HOOK + 2 * HOOK_LH + 14; SUB_FS = 56
Y_BARS = Y_SUB + 82; ROW_H = C.get("ROW_H", 140); LAB_FS = 60; VAL_FS = 58; BAR_T = 46
BX1 = 600 if MAP else X1
Y_SHARE = Y_BARS + ROWS * ROW_H + 10
Y_YEAR = Y_SHARE + (176 if SHARE else 0) + 4
Y_EV = Y_YEAR + 166; EV_FS = 60
Y_SRC = 1504; SRC_FS = 36
if MAP:
    M = MAP; lo0, lo1 = M["xlim"]; la0, la1 = M["ylim"]; COSF = math.cos(math.radians(31.5))
    MX0, MX1, MY0, MY1 = 612, X1, Y_BARS - 10, Y_YEAR - 10
    sc = min((MX1 - MX0) / ((lo1 - lo0) * COSF), (MY1 - MY0) / (la1 - la0))
    mcx, mcy = (MX0 + MX1) / 2, (MY0 + MY1) / 2; clo, cla = (lo0 + lo1) / 2, (la0 + la1) / 2
    def proj(lo, la): return (mcx + (lo - clo) * COSF * sc, mcy - (la - cla) * sc)
    OUTL = [proj(*p) for p in M["outline"]]

# dots (same seeds and sampling as the original engine, so the map tells the same story)
DOTS = None
if MAP and MAP.get("mode") == "dots":
    poly = Path(np.array(MAP["outline"])); DOT = MAP["dot"]; DOTS = {}
    for gi, n in enumerate(names):
        if n not in MAP["coords"]: continue
        P = int(max(p[1] for p in G[n][2]) / DOT) + 3; arrs = []
        for ki, (yr, lo, la, sx, sy) in enumerate(MAP["coords"][n]):
            rng = np.random.default_rng(gi * 100 + ki); pts = []
            while len(pts) < P:
                q = rng.normal([lo, la], [sx, sy], size=(P * 3, 2)); q = q[poly.contains_points(q)]; pts.extend(q.tolist())
            arrs.append(np.array(pts[:P]))
        DOTS[n] = ([kk[0] for kk in MAP["coords"][n]], arrs)
    PERM = {}

# ------------------------------------------------------------------ static background
r = np.linspace(0, 1, H * S)[:, None, None]
BG = Image.fromarray(((np.array(NAVY_T)[None, None, :] * (1 - r) + np.array(NAVY_B)[None, None, :] * r) * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
yy_g, xx_g = np.mgrid[0:H // 4, 0:W // 4]
def glow(t):
    gx = 0.5 + 0.18 * math.sin(t * 0.35); gy = 0.42 + 0.08 * math.cos(t * 0.27)
    dd = np.sqrt((xx_g / (W / 4) - gx) ** 2 + ((yy_g / (H / 4) - gy) * 1.6) ** 2)
    a = np.clip(1 - dd / 0.55, 0, 1) ** 2 * 38
    g = np.zeros((H // 4, W // 4, 4), np.uint8); g[..., 0] = 42; g[..., 1] = 136; g[..., 2] = 212; g[..., 3] = a.astype(np.uint8)
    return Image.fromarray(g, "RGBA").resize((W * S, H * S), Image.BILINEAR)
MAPBASE = None
def mapbase():
    global MAPBASE
    if MAPBASE is None:
        im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        pts = [(x * S, y * S) for x, y in OUTL]
        d.polygon(pts, fill=hx("#B8923F", 62)); d.line(pts + [pts[0]], fill=GOLD2[:3] + (230,), width=int(3.5 * S), joint="curve")
        for dl in MAP.get("dashed", []):
            q = [proj(*p) for p in dl]
            for (xa, ya), (xb, yb) in zip(q[:-1], q[1:]):
                L = math.hypot(xb - xa, yb - ya); n = max(1, int(L / 12))
                for i in range(0, n, 2):
                    u0, u1 = i / n, min(1, (i + 1) / n)
                    d.line([((xa + (xb - xa) * u0) * S, (ya + (yb - ya) * u0) * S), ((xa + (xb - xa) * u1) * S, (ya + (yb - ya) * u1) * S)], fill=GREEN, width=int(3 * S))
        MAPBASE = im
    return MAPBASE

# ------------------------------------------------------------------ frames
N = int(round(T_TOTAL * FPS)); pos = {n: None for n in names}; alpha_r = {n: 0.0 for n in names}
SNAPS = [float(x) for x in A.snaps.split(",")] if A.snaps else None
SNAPF = {int(round(s * FPS)): s for s in SNAPS} if SNAPS else {}
OUTV = C["OUT_EN"].replace(".mp4", "_silent.mp4")
ff = None
if not SNAPS:
    os.makedirs(os.path.dirname(OUTV), exist_ok=True)
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", OUTV], stdin=subprocess.PIPE)
HOOK = C["HOOK_EN"]; REV = C["REVEAL_EN"]; END = C["END_EN"]
EVENTS = C["EVENTS"]; COUNTER = C.get("COUNTER")
xmax_s = None
for f in range(N):
    t = f / FPS; year = float(np.interp(min(t, T_DATA), ty, yy))
    vals = {n: val(G[n][2], year) for n in names}
    alive = [n for n in names if vals[n] >= MIN]
    ranked = sorted(alive, key=lambda n: -vals[n])[:ROWS]
    for i, n in enumerate(sorted(names, key=lambda n: -vals[n])):
        pos[n] = i if pos[n] is None else pos[n] + (i - pos[n]) * 0.22
        alpha_r[n] += ((1.0 if n in ranked else 0.0) - alpha_r[n]) * 0.2
    mx = max([vals[n] for n in ranked] + [C.get("FLOOR", 1)])
    xmax_s = mx if xmax_s is None else xmax_s + (mx - xmax_s) * 0.12
    if SNAPS and f not in SNAPF: continue
    im = BG.copy(); im.alpha_composite(glow(t)); d = ImageDraw.Draw(im)
    # hook (stays on as the title: motion comes from the race underneath from frame 0)
    for i, (s, col) in enumerate(zip(HOOK, (GOLD2, WHITE))):
        sz = fit(s, HOOK_FS, X1 - X0, 900, 90); txt(d, CX, Y_HOOK + i * HOOK_LH, s, sz, col, 900, "ma")
    # gold underline sweep under the hook in the first 1.2 s
    u = min(1, t / 1.2); u = u * u * (3 - 2 * u); ul = 300 * u
    d.rounded_rectangle([(CX - ul) * S, (Y_SUB - 10) * S, (CX + ul) * S, (Y_SUB - 4) * S], 3 * S, fill=GOLD)
    sub = C["SUB_EN"]; txt(d, CX, Y_SUB + 4, sub, fit(sub, SUB_FS, X1 - X0, 700, 50), SILVER2, 700, "ma")
    # bars
    bw_max = (BX1 - X0) - (215 if MAP else 255)
    for n in sorted(names, key=lambda n: -pos[n]):
        a = alpha_r[n]
        if a < 0.03 or pos[n] > ROWS - 0.5 + 0.5: continue
        if pos[n] > ROWS - 0.45: continue
        v = vals[n]; c = hx(G[n][1]); y0 = Y_BARS + pos[n] * ROW_H
        lx = X0
        if n in FLC:
            fl = flag(FLC[n], 44); im.alpha_composite(fl, (int(X0 * S), int((y0 + 12) * S))); lx = X0 + fl.width / S + 16; d = ImageDraw.Draw(im)
        lab = SHORT.get(n, n); txt(d, lx, y0 + 34, lab, fit(lab, LAB_FS, BX1 - lx, 800, 56), c, 800, "lm", a)
        L = max(6, bw_max * v / max(xmax_s, 1e-9))
        yb = y0 + 66
        d.rounded_rectangle([X0 * S, yb * S, (X0 + L) * S, (yb + BAR_T) * S], int(10 * S), fill=c[:3] + (int(235 * a),))
        txt(d, X0 + L + 16, yb + BAR_T / 2 + 2, fmt_n(v), VAL_FS, WHITE, 800, "lm", a)
    # map
    if MAP:
        im.alpha_composite(mapbase()); d = ImageDraw.Draw(im, "RGBA")
        if DOTS is not None:
            allp, allc = [], []
            for n in names:
                if n not in DOTS: continue
                v = vals[n]; cnt = 0 if v < MIN else max(1, int(round(v / MAP["dot"])))
                if cnt == 0: continue
                yrs, arrs = DOTS[n]
                if year <= yrs[0] or len(yrs) == 1: Ap = arrs[0]
                elif year >= yrs[-1]: Ap = arrs[-1]
                else:
                    j = max(i for i in range(len(yrs)) if yrs[i] <= year); fr = (year - yrs[j]) / (yrs[j + 1] - yrs[j]); Ap = arrs[j] * (1 - fr) + arrs[j + 1] * fr
                Ap = Ap[:cnt]; allp.append(Ap); allc += [G[n][1]] * len(Ap)
            if allp:
                P_ = np.vstack(allp); order = np.random.default_rng(1).permutation(len(P_)); rr = 3.0 * S
                cols = [hx(allc[i], 235) for i in order]
                for (lo, la), cc in zip(P_[order], cols):
                    x, y = proj(lo, la); d.ellipse([x * S - rr, y * S - rr, x * S + rr, y * S + rr], fill=cc)
            leg = MAP.get("legend_en", "= 2,000 people"); lr = 11
            d.ellipse([(MX0 + 6) * S, (MY1 - 30 - lr) * S, (MX0 + 6 + 2 * lr) * S, (MY1 - 30 + lr) * S], fill=SILVER)
            txt(d, MX0 + 6 + 2 * lr + 10, MY1 - 30, leg, 40, SILVER2, 700, "lm")
        else:
            top = max([vals[n] for n in names] + [1])
            for n in sorted(names, key=lambda n: -vals[n]):
                v = vals[n]
                if v < MIN or n not in MAP["coords"]: continue
                lo, la = MAP["coords"][n]; x, y = proj(lo, la); rr = 48 * math.sqrt(v / top) * S
                c = hx(G[n][1]); d.ellipse([x * S - rr, y * S - rr, x * S + rr, y * S + rr], fill=c[:3] + (190,), outline=(255, 255, 255, 200), width=int(2 * S))
        d = ImageDraw.Draw(im)
    # year + counter
    yv = int(round(year)) if year > 2000 else int(round(year)); ys = str(abs(yv))
    txt(d, X0 - 4, Y_YEAR - 14, ys, 150, WHITE, 900, "la")
    if ANCIENT:
        txt(d, X0 + tw(ys, 150, 900) + 14, Y_YEAR + 116, "BCE" if yv < 0 else "CE", 64, GOLD2, 900, "ls")
    if COUNTER:
        cv = sum(vals.values()) if C.get("COUNTER_SUM") else val(COUNTER[2], year)
        txt(d, X1, Y_YEAR + 6, C["COUNTER_EN"], 56, SILVER2, 700, "ra")
        txt(d, X1, Y_YEAR + 62, fmt_big(cv), 76, BLUE_L, 900, "ra")
    # share panel (Nobel)
    if SHARE:
        for i, (lab, kp, col) in enumerate(SHARE):
            sv = val(kp, year); yy2 = Y_SHARE + i * 86
            d.rounded_rectangle([X0 * S, yy2 * S, X1 * S, (yy2 + 82) * S], int(18 * S), fill=(8, 19, 38, 170), outline=hx(col)[:3] + (200,), width=int(2 * S))
            txt(d, X0 + 22, yy2 + 41, lab, 56, SILVER, 800, "lm")
            txt(d, X1 - 22, yy2 + 41, (f"{sv * 100:.1f}%" if sv < 0.1 else f"{sv * 100:.0f}%"), 72, hx(col), 900, "rm")
    # event or reveal
    ra = 0.0
    if REV[0] <= t <= REV[1]: ra = min(1, (t - REV[0]) / 0.25, (REV[1] - t) / 0.25)
    ev = [e for e in EVENTS if e[0] <= year + 1e-6]
    if ev and ra < 1:
        lines = wrap(clean(ev[-1][1]), EV_FS, X1 - X0, 800)
        if len(lines) > 2: lines = wrap(clean(ev[-1][1]), 56, X1 - X0, 800)[:2]
        for i, l in enumerate(lines[:2]): txt(d, CX, Y_EV + i * 68, l, EV_FS if len(lines) <= 2 else 56, GOLD2, 800, "ma", 1 - ra)
    if ra > 0:
        sc_ = 0.92 + 0.08 * min(1, (t - REV[0]) / 0.3)
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        bx0, by0, bx1, by1 = X0 - 8, Y_EV - 4, X1 + 8, Y_EV + 170
        ld.rounded_rectangle([bx0 * S, by0 * S, bx1 * S, by1 * S], int(26 * S), fill=(10, 22, 46, int(240 * ra)), outline=GOLD2[:3] + (int(255 * ra),), width=int(4 * S))
        for i, (s, col) in enumerate(zip(REV[2], (WHITE, GOLD2))):
            sz = fit(s, 74 * sc_, X1 - X0 - 40, 900, 70); txt(ld, CX, Y_EV + 2 + i * 76, s, sz, col, 900, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    # sources
    src = C["SRC_EN"]; txt(d, CX, Y_SRC, src, fit(src, SRC_FS, X1 - X0, 400, 34), SILVER2, 400, "ma")
    # end card (< 1 s), loops into the hook
    if t >= T_ENDC:
        a = min(1, (t - T_ENDC) / 0.15)
        lay = Image.new("RGBA", im.size, (7, 15, 32, int(235 * a))); ld = ImageDraw.Draw(lay)
        for i, s in enumerate(END):
            sz = fit(s, 96, X1 - X0, 900, 80); txt(ld, CX, 760 + i * 112, s, sz, WHITE if i == 0 else GOLD2, 900, "ma", a)
        im.alpha_composite(lay)
    out = im.reduce(S).convert("RGB")
    if SNAPS:
        os.makedirs(C["SNAPDIR"], exist_ok=True); out.save(f"{C['SNAPDIR']}/{C['TAG']}_{SNAPF[f]:05.2f}.png"); continue
    ff.stdin.write(out.tobytes())
if SNAPS: print("snaps ->", C["SNAPDIR"]); sys.exit()
ff.stdin.close(); ff.wait()
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", OUTV, "-i", C["MUSIC"], "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                "-c:a", "aac", "-b:a", "192k", "-af", f"afade=t=out:st={T_TOTAL - 0.6:.2f}:d=0.6", "-t", f"{T_TOTAL:.2f}", C["OUT_EN"]], check=True)
os.remove(OUTV); print("final", C["OUT_EN"])
