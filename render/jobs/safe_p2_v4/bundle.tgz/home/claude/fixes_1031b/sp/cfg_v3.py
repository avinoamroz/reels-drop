# safe_p2_v3: "Where can Jews walk safely? Where did they go?" Jews in Arab countries (and Iran), 1948 vs today.
# v3 for Noam's 31 Oct notes: (1) the hook question is said once, at frame 0; the last line is now the lead-in
# "So... next time someone asks you?" which completes only with the hook on the loop; (2) full Apple keynote redesign
# (engine_v3.py): dark stage, one glow, Inter only, one idea per screen, hero numbers that roll, gold as the single accent.
# Narration, facts and sources as v2 (facts: ../facts.md).
import json, os
from PIL import ImageFont
D = "/home/claude/fixes_1031b/sp"
TAG = "safe_p2_v4"; OUT = f"{D}/work/silent.mp4"; FINAL = f"{D}/safe_p2_v4.mp4"; SNAPDIR = f"{D}/work/snaps"; VO = f"{D}/work/vo.wav"
FONTDIR = f"{D}/fonts"
WORDS = json.load(open(f"{D}/work/words.json"))["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i): return LW[li][i]["t0"]
def E(li, i): return LW[li][i]["t1"]
def LS(li): return LW[li][0]["t0"]
def LE(li): return LW[li][-1]["t1"]
VO_END = LE(21); T_END = round(VO_END + 0.45, 2)
TURN = S(15, 0)
HITS = [LS(17) - 0.05]

# ---------------------------------------------------------------- look
BG = "#060608"; GLOW_COL = "#E8C77E"; GLOW_XY = (540, 850); GLOW_R = 620
GLOW_KEYS = [(0, 0.07), (LS(17) - 0.4, 0.07), (LS(17) + 0.8, 0.14), (LS(19) - 0.4, 0.14), (LS(19) + 0.5, 0.07), (999, 0.07)]
WHITE, GREY, GOLD = "#F5F5F7", "#A1A1A6", "#E8C77E"
T_IN, T_OUT = 0.55, 0.32
HERO_Y = 850; NUM_FS = 260; NUM_TRACK = -0.05; NUM_MAX = 420
SUB_FS = 54; SUB_Y = 1600; SUB_COL = "#FFFFFF"; SUB_ALPHA = 0.94
SRC_FS = 40; SRC_Y = 1772; SRC_LH = 50; SRC_COL = "#8E8E93"
_F = lambda k, s: ImageFont.truetype(f"{FONTDIR}/{k}.otf", s)
def cap(k, s): return -_F(k, s).getbbox("H", anchor="ls")[1]
def width(k, s, txt): return _F(k, s).getlength(txt)
def numw(txt, s=NUM_FS):
    f = _F("InterDisplay-Bold", s); dw = sorted(f.getlength(d) for d in "0123456789")[5]
    return sum(dw if c.isdigit() else f.getlength(c) for c in txt) + NUM_TRACK * s * (len(txt) - 1)
def grow_to(txt): return min(NUM_MAX / NUM_FS, 960 / numw(txt))
assert numw("850,000") <= 990, numw("850,000")
NUMCAP = cap("InterDisplay-Bold", NUM_FS); HERO_BASE = HERO_Y + NUMCAP / 2      # baseline of a word set at number size

# two-line statement (hook, end, "Where did they go?"): one size for both lines, fit to 960
def pair(a, b, t_in, t_out, size, k="db", inst=False, cy=HERO_Y, gap=1.13, **kw):
    sz = size
    while max(width("InterDisplay-Bold", sz, a), width("InterDisplay-Bold", sz, b)) > 960: sz -= 2
    c = cap("InterDisplay-Bold", sz); lh = sz * gap; y1 = cy - lh / 2 + c / 2; y2 = cy + lh / 2 + c / 2
    return [dict(k="text", s=a, font=k, size=sz, y=y1, t_in=t_in, t_out=t_out, color=WHITE, inst=inst, **kw),
            dict(k="text", s=b, font=k, size=sz, y=y2, t_in=t_in + (0 if inst else 0.12), t_out=t_out, color=WHITE, inst=inst, **kw)]
def num(id_, t_in, t_out, keys, col=(), grow=(), **kw):
    return dict(k="num", id=id_, font="db", size=NUM_FS, track=NUM_TRACK, y=HERO_Y, t_in=t_in, t_out=t_out, keys=list(keys), color=WHITE,
                col=list(col), grow=list(grow), **kw)
def lab(s, nid, t_in, t_out, side="below", color=GREY, size=68, k="l", gap=None):
    g = gap if gap is not None else (112 if side == "below" else 62)
    return dict(k="text", s=s, font=k, size=size, attach=(side, nid, g), y=0, t_in=t_in, t_out=t_out, color=color)
def word(s, y, t_in, t_out, size, k="db", color=WHITE, **kw):
    return dict(k="text", s=s, font=k, size=size, y=y, t_in=t_in, t_out=t_out, color=color, **kw)

I = []
# hook, frame 0: fully on screen, a slow push-in while it is read
X0 = LS(1) - 0.25
I += pair("Where can Jews", "walk safely?", 0, X0, 132, inst=True, cy=HERO_Y - 10, zoom=[(0, X0, 1.0, 1.035)])
I.append(word("Arab countries. 1948 vs today.", HERO_Y + 232, 0, X0, 60, k="l", color=GREY, inst=True, zoom=[(0, X0, 1.0, 1.035)]))

# 1948 total: "1948" first, then the count rolls up on "about eight hundred and fifty thousand"
X1 = LS(2) - 0.15
I.append(num("n1948", LS(1) - 0.05, S(1, 6) - 0.1, [(0, 0, 1948, 1948)], fmt="{}"))
I.append(num("n1", S(1, 6) - 0.05, X1, [(S(1, 6), E(1, 11), 0, 850000)]))
I.append(lab("Jews in Arab countries, 1948", "n1", S(1, 3), X1))

def country(nid, li0, li1, v0, v1, then, today, kicker, t_out, final_txt):
    s1 = grow_to(final_txt); a, b = S(li1, 1), E(li1, len(LW[li1]) - 1)
    out = [num(nid, LS(li0) - 0.05, t_out, [(a, b, v0, v1)], col=[(a, b, WHITE, GOLD)], grow=[(a, b, 1.0, s1)]),
           lab(then, nid, LS(li0) + 0.05, S(li1, 0) - 0.05), lab(today, nid, S(li1, 0), t_out)]
    if kicker: out.append(lab(kicker, nid, S(li1, 1) - 0.02, t_out, side="above", size=64))
    return out
I += country("mor", 2, 3, 265000, 2000, "Morocco, 1948", "Morocco, today", "About", LS(4) - 0.12, "2,000")

# Algeria, Tunisia, Libya: names on their words, then "Almost all gone." in gold while the names dim
X4 = LS(5) - 0.12; dimw = [(S(4, 4), S(4, 4) + 0.5, 0.28)]
for i, (nm, wi) in enumerate((("Algeria", 0), ("Tunisia", 1), ("Libya", 3))):
    I.append(word(nm, 660 + i * 150 + 50, S(4, wi) - 0.03, X4, 116, k="dm", dim=dimw))
I.append(word("Almost all gone.", 1200, S(4, 4) - 0.03, X4, 92, k="dsb", color=GOLD))

I += country("egy", 5, 6, 75000, 100, "Egypt, 1948", "Egypt, today", "About", LS(7) - 0.12, "100")
I += country("irq", 7, 8, 135000, 4, "Iraq, 1948", "Iraq, today", "Just", LS(9) - 0.12, "4")
I += country("yem", 9, 10, 63000, 0, "Yemen, 1948", "Yemen, today", None, LS(11) - 0.12, "0")

# Iran: the word first ("Iran is not an Arab country"), then its numbers
X12 = LS(13) - 0.12; a12, b12 = S(12, 1), E(12, 3)
I.append(word("Iran", HERO_BASE, LS(11) - 0.05, S(11, 6) - 0.1, NUM_FS))
I.append(num("irn", S(11, 6) - 0.05, X12, [(a12, b12, 100000, 9000)], col=[(a12, b12, WHITE, GOLD)], grow=[(a12, b12, 1.0, grow_to("9,000"))]))
I.append(lab("Not an Arab country", "irn", S(11, 1), S(11, 6) - 0.1))
I.append(lab("Iran, 1948", "irn", S(11, 6), S(12, 0) - 0.05))
I.append(lab("Iran, today", "irn", S(12, 0), X12))
I.append(lab("About", "irn", S(12, 1) - 0.02, X12, side="above", size=64))

# v4: the Jews who remain (Iran): closed communities, no open support for Israel (said once, word for word on screen)
X13 = LS(14) - 0.12; M13 = S(13, 7)
I.append(word("Those who stay", HERO_Y - 300, LS(13) - 0.05, X13, 64, k="l", color=GREY))
I += pair("live in closed", "communities.", LS(13) + 0.2, M13 - 0.1, 140)
I += pair("They can't openly", "support Israel.", M13 - 0.05, X13, 140)
for _it in I[-4:]: _it["color"] = WHITE
I[-1]["color"] = GOLD
# where did they go
I += pair("Where did", "they go?", LS(14) - 0.05, LS(15) - 0.12, 150)
X14 = LS(16) - 0.12
I.append(num("isr", LS(15) - 0.05, X14, [(S(15, 2), E(15, 4), 0, 600000)]))
I.append(lab("More than", "isr", LS(15), X14, side="above", size=64))
I.append(lab("rebuilt their lives in Israel", "isr", S(15, 5) - 0.05, X14))
X15 = LS(17) - 0.15
I.append(word("Others went to", 690, LS(16) - 0.05, X15, 64, k="l", color=GREY))
I.append(word("France", 880, S(16, 3) - 0.05, X15, 150))
_am = 150
while width("InterDisplay-Bold", _am, "the Americas") > 940: _am -= 2
I.append(word("the Americas", 1050, S(16, 5) - 0.05, X15, _am))

# the reveal (about 70% in): its own moment, slower build, the glow lifts
X17 = LS(19) - 0.15; a17, b17 = S(18, 0), E(18, 5)
I.append(num("rev", LS(17) - 0.08, X17, [(a17, b17, 850000, 4000)], col=[(a17, b17, WHITE, GOLD)], grow=[(a17, b17, 1.0, grow_to("4,000"))], ain=0.8))
I.append(lab("Jews in Arab countries, 1948", "rev", LS(17) + 0.15, a17 - 0.05))
I.append(lab("Jews in Arab countries today", "rev", a17, X17))
I.append(lab("Fewer than", "rev", b17 - 0.25, X17, side="above", size=64))

# to be fair
X18 = LS(20) - 0.12
I.append(word("To be fair,", 690, LS(19) - 0.05, X18, 88, k="dsb"))
I.append(word("the reasons differed.", 800, S(19, 3) - 0.05, X18, 88, k="dsb"))
for j, (s, wi) in enumerate((("Some were expelled.", 6), ("Some fled violence.", 9), ("Some chose Zionism.", 12))):
    I.append(word(s, 970 + j * 96, S(19, wi) - 0.05, X18, 66, k="dl", color="#C7C7CC"))

# the loss
X19 = LS(21) - 0.15
I.append(num("yrs", LS(20) - 0.05, X19, [(0, 0, 2000, 2000)]))
I.append(lab("Communities", "yrs", LS(20), X19, side="above", size=64))
I.append(lab("years old", "yrs", S(20, 3), X19))
I.append(lab("Almost gone.", "yrs", S(20, 7) - 0.05, X19, gap=232, color=GOLD, size=84, k="dsb"))

# the lead-in: same type, size and place as the hook, so the loop reads "...next time someone asks you? / Where can Jews walk safely?"
I += pair("So… next time", "someone asks you?", LS(21) - 0.05, T_END - 0.26, 132, cy=HERO_Y - 10, aout=0.48)
ITEMS = I

# ---------------------------------------------------------------- sources (small grey label, source and year)
SRC0 = ["Jews in Arab countries, 1948 and today:", "DellaPergola, AJYB 2023; Jewish Virtual Library"]
SOURCES = [(0, SRC0),
           (LS(2), ["Morocco today: 2,100", "DellaPergola, AJYB 2023"]),
           (LS(4), ["Today: Algeria under 200, Tunisia about 1,000,", "Libya 0. DellaPergola, AJYB 2023"]),
           (LS(5), ["Egypt: DellaPergola, AJYB 2023"]),
           (LS(7), ["Iraq: DellaPergola, AJYB 2023; Ynet 2021"]),
           (LS(9), ["Yemen, incl. Aden: DellaPergola, AJYB 2023"]),
           (LS(11), ["Iran 1948: estimates 100,000 to 150,000", "Today: 9,826 (2016 census), about 9,100 (2023)"]),
           (LS(13), ["Iran: Jews pressed to denounce Israel.", "Iran International 2023; Jerusalem Post 2024"]),
           (LS(14), ["Israel CBS, immigrants by country of birth (via JVL)"]),
           (LS(17), ["Arab countries, sum by country: 856,000 (1948)", "DellaPergola, AJYB 2023; JVL 2018. Rounded."]),
           (LS(19), ["Historians still debate the mix."]),
           (LS(20), ["Arab countries and Iran, 1948 vs today"]),
           (LS(21), SRC0)]

# ---------------------------------------------------------------- subtitles: (line, first spoken word index, display text); <= 7 words
CH = [(1, 0, "In 1948, Arab countries had"), (1, 6, "about 850,000 Jews."), (2, 0, "Morocco had 265,000."), (3, 0, "Today? About two thousand."),
      (4, 0, "Algeria, Tunisia and Libya."), (4, 4, "Almost all gone."), (5, 0, "Egypt had 75,000."), (6, 0, "Today? About a hundred."),
      (7, 0, "Iraq had 135,000."), (8, 0, "Today? Just four."), (9, 0, "Yemen had 63,000."), (10, 0, "Today? None."),
      (11, 0, "Iran is not an Arab country."), (11, 6, "It had about 100,000."), (12, 0, "Today? About 9,000."),
      (14, 0, "So where did they go?"), (15, 0, "More than 600,000 rebuilt"), (15, 5, "their lives in Israel."),
      (16, 0, "Others went to France"), (16, 4, "and the Americas."), (17, 0, "In Arab countries: 850,000."), (18, 0, "Down to fewer than 4,000."),
      (19, 0, "To be fair,"), (19, 3, "the reasons differed."), (19, 6, "Some were expelled."), (19, 9, "Some fled violence."),
      (19, 12, "Some chose Zionism."), (20, 0, "But communities 2,000 years old"), (20, 6, "are almost gone.")]
# lines 0, 13 and 21 have no subtitle: the hero text on screen is the same words, word for word
SUBS = []
for k, (li, wi, s) in enumerate(CH):
    a = S(li, wi) - 0.04
    nxt = CH[k + 1] if k + 1 < len(CH) else None
    endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
    b = E(li, endw) + 0.45
    if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.06)
    SUBS.append((a, b, s))
    assert len(s.split()) <= 7, s

# ---------------------------------------------------------------- guards: no dashes, no Part X, sizes
import re
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [it["s"] for it in ITEMS if "s" in it] + [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v]
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"part\s*\d", s, re.I) for s in _txt), "no Part X"
assert all(it["size"] >= 36 for it in ITEMS) and SRC_FS >= 36
_sf = ImageFont.truetype(f"{FONTDIR}/Inter-Regular.otf", SRC_FS)
for _, v in SOURCES:
    for l in v: assert _sf.getlength(l) <= 980, ("source too wide", l)
