"""local step: loopable music bed + one soft hit at the reveal under work/vo.wav -> work/mix.m4a (-14 LUFS, <= -1.5 dBTP).
Loop: the bed runs at a tempo that fits a whole number of bars into T_END, is generated one bar longer, and the overflow
(next downbeat and reverb tail) is folded onto the start over the bed's 0.6 s fade-in, so the last sample flows into the first."""
import sys, os, runpy, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
D = "/home/claude/fixes_1031b/sp"; CFG = f"{D}/cfg_v3.py"
import audio_v4 as AU, rk
C = runpy.run_path(CFG); dur = C["T_END"]; SR = AU.SR
bars = round(dur / (4 * 60 / 86)); bpm = 4 * 60 * bars / dur; bar = 4 * 60 / bpm
raw = AU.doc_music(dur + bar, bpm=bpm, flip_at=C["TURN"] - 0.3, end_ring=0.01)
n = int(round(dur * SR)); xf = int(0.6 * SR)
bed = raw[:, :n].copy(); tail = raw[:, n:n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
print("bpm", round(bpm, 2), "bars", bars, "seam step", float(np.abs(bed[:, 0] - bed[:, -1]).max()))
vo, sr = sf.read(C["VO"]); assert sr == SR
ev = [(h, AU.soft_hit(), -4.0) for h in C["HITS"]]
mix_wav = f"{D}/work/mix.wav"; rep = AU.mix(vo, dur, ev, mix_wav, music_db=-19.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mix_wav); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mix_wav)
json.dump(dict(T_END=dur, bpm=bpm, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", J["final_I"], J["final_TP"])
