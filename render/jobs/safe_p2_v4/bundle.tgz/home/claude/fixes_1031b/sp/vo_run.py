"""house voice chain + ASR restore (v5lib.process) at atempo 1.08 -> work/vo.wav, work/words.json"""
import sys; sys.path.insert(0, "/home/claude/rehook"); import v5lib
v5lib.TEMPO = 1.08
D = "/home/claude/fixes_1031b/sp"
lines = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
v5lib.process(f"{D}/safe_p2_v4_vo.wav", lines, f"{D}/work", log=lambda s: print(s, flush=True))
