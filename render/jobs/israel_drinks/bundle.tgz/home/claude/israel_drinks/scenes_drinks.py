"""Bespoke reelkit scenes for israel_drinks (30 Oct 2026): filling glasses hook, glass race, Olympic pools.
IG safe zones kept clear: content inside x 60..920 (centre 490), nothing below y 1540. Subtitles moved up to y 1470
and narrowed (the house subs sit at y 1660, inside the bottom 380 px)."""
import math, random
import cairo
from PIL import Image, ImageDraw, ImageFont
import render as RD
from render import P, T, pill, PP, fade_in, col, draw_emoji
from kit import ease, ramp, lerp, St, sa, rr, circ, box, font, W, H, pil2cairo

CX = 490; XL, XR = 60, 920
SUB_Y = 1470

# ------------------------------------------------------------------ subtitles inside the safe zone
def sub_surfs(pieces, sz=46, maxw=780):
    F = ImageFont.truetype(RD.SUB_FONT, sz); out = []
    for t0, t1, d in pieces:
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 24
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=RD.P255["navy"][:3] + (232,), outline=RD.P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 12 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        out.append((t0, t1, pil2cairo(im), int(CX - Wd / 2), int(SUB_Y - Hd / 2), d, Hd))
    return out
RD.sub_surfs = sub_surfs

def src_line(c, s, a, y=1385):
    if s and a > 0.01: T(c, s, 34, CX, y, P["grey"], a, 1.0, 700, maxw=840, src=True)

# ------------------------------------------------------------------ drinks
LIQ = dict(cola="#3A1E12", beer="#E8A825", coffee="#5A3A22", water="#2A88D4", spirits="#C67C22", wine="#8E1B3A",
           milk="#FFFFFF", tea="#B8652A", soda="#3A1E12")
def hx(h): return RD.kit.hx(h)

def glass(c, x, y, w, h, level, kind, t, seed=0):
    """tall tumbler centred at x, top y; level 0..1 of the inside; wave surface, bubbles, pour stream"""
    tw, bw = w, w * 0.8                                 # top width, bottom width
    def outline():
        c.new_path(); c.move_to(x - tw / 2, y); c.line_to(x - bw / 2, y + h - 18)
        c.curve_to(x - bw / 2, y + h, x - bw / 2 + 10, y + h, x - bw / 2 + 24, y + h)
        c.line_to(x + bw / 2 - 24, y + h); c.curve_to(x + bw / 2 - 10, y + h, x + bw / 2, y + h, x + bw / 2, y + h - 18)
        c.line_to(x + tw / 2, y); c.close_path()
    # glass body
    outline(); sa(c, P["white"], 0.55); c.fill()
    c.save(); outline(); c.clip()
    ly = y + h - (h - 12) * level
    lc = hx(LIQ[kind])
    # pour stream
    sx = x + 6 * math.sin(t * 3 + seed)
    sa(c, lc, 0.95); rr(c, sx - 9, y - 200, 18, ly - (y - 200) + 10, 9); c.fill()
    # liquid with wave
    c.new_path(); c.move_to(x - tw, y + h + 5)
    for k in range(0, 41):
        xx = x - tw / 2 + tw * k / 40
        c.line_to(xx, ly + 7 * math.sin(xx / 26 + t * 5 + seed) + 4 * math.sin(xx / 11 - t * 7))
    c.line_to(x + tw, y + h + 5); c.close_path()
    if kind == "coffee":
        g = cairo.LinearGradient(0, ly, 0, y + h); g.add_color_stop_rgb(0, *hx("#C89B6D")[:3]); g.add_color_stop_rgb(0.28, *hx("#8A5A35")[:3]); g.add_color_stop_rgb(1, *lc[:3])
        c.set_source(g)
    else: sa(c, lc, 1.0)
    c.fill()
    if kind == "beer":   # foam head
        for k in range(9):
            fx = x - tw / 2 + 12 + (tw - 24) * k / 8
            circ(c, fx, ly - 4 + 3 * math.sin(t * 4 + k), 22 + 4 * math.sin(k * 1.7), P["white"], 0.97)
    R = random.Random(seed)
    for k in range(14 if kind in ("cola", "beer", "soda") else 6):   # bubbles
        bx = x - bw / 2 + 20 + R.random() * (bw - 40); sp = 60 + 60 * R.random(); ph = R.random() * 10
        by = y + h - ((t * sp + ph * 40) % max(1, (y + h - ly)))
        if by > ly + 14: circ(c, bx, by, 4 + 3 * R.random(), P["white"], 0.55)
    c.restore()
    # rim and outline
    outline(); sa(c, P["navy"], 0.9); c.set_line_width(7); c.stroke()
    sa(c, P["white"], 0.6); c.set_line_width(6); c.move_to(x - tw / 2 + 22, y + 30); c.line_to(x - bw / 2 + 24, y + h - 40); c.stroke()

def sc_drinks_hook(c, t, S):
    """hook / loop end: big question + three glasses already filling at frame 0"""
    t0 = S["t0"]; a, s = PP(t, t0 + 0.02, S)
    y = 330
    for k, ln in enumerate(S["en"]):
        T(c, ln, S.get("size", 96), CX, y + k * 108, P["navy"], a, s, 900, hl=P["blue"], maxw=840)
    gy = 690; gh = 470; gw = 220
    xs = [CX - 290, CX, CX + 290]
    for k, (kind, lab) in enumerate(zip(("cola", "beer", "coffee"), S["labels"])):
        tt = t - t0 if not S.get("hook") else t
        lev = 0.30 + 0.58 * ease(min(1.0, (tt + 0.6 * k) / 5.0)) + 0.015 * math.sin(t * 2 + k)
        c.save(); c.translate(xs[k], gy + gh); bob = 1 + 0.015 * math.sin(t * 3 + k); c.scale(bob, bob); c.translate(-xs[k], -(gy + gh))
        glass(c, xs[k], gy, gw, gh, lev, kind, t, seed=k * 3 + 1); c.restore()
        tk = S["times"].get(f"l{k}", t0 + 0.3 + 0.5 * k)
        if S.get("hook") or S.get("all_on"):   # hook: every label is on screen at frame 0, and bumps when it is spoken
            a2 = 1.0 if S.get("hook") else fade_in(t, t0 + 0.1, S); u = (t - tk) / 0.35
            s2 = 1 + 0.16 * math.sin(math.pi * u) if 0 <= u <= 1 else 1.0
        else: a2, s2 = PP(t, tk, S, bounce=2.6)
        hot = 0 <= t - tk <= 0.8
        T(c, lab, 64, xs[k], gy + gh + 70, P["blue"] if hot else P["navy"], a2, s2, 900, maxw=270)
    if S.get("tag"):
        a3, s3 = PP(t, S["times"].get("tag", t0 + 1.0), S)
        pill(c, S["tag"], 46, CX, 1370, P["gold"], P["white"], a3, s3, w=900)

# ------------------------------------------------------------------ the race
def _fmt(v): return f"{v:,.0f}" if v >= 10 else (f"{v:.0f}")

def sc_glass_race(c, t, S):
    """rows = drinks, smallest first; each a horizontal glass tube that fills on its word; biggest on top.
    Row k appears at S['times']['d<k>']; the last row (number one) has a mystery '?' phase from mark 'q'.
    Scale: max of shown values x 1.1 (eased), so the number one dwarfs the rest."""
    t0 = S["t0"]; rows = S["rows"]; n = len(rows); tm = S["times"]
    a, s = PP(t, t0 + 0.05, S)
    T(c, S["title"], 60, CX, 262, P["navy"], a, s, 900, hl=P["blue"], maxw=850)
    top, rh = 330, 114; LX, TX0, TX1 = 66, 445, 905
    ts = [tm.get(f"d{k}", t0 + 0.5 + 2.5 * k) for k in range(n)]
    tq = tm.get("q", ts[-1] - 1.0)
    vis = [k for k in range(n) if t >= ts[k] - 0.1]
    mystery = t >= tq - 0.1 and t < ts[-1] - 0.1
    # values fill in over 0.9 s
    cur = {k: rows[k]["value"] * ease((t - ts[k]) / 0.9) for k in vis}
    target = max([rows[k]["value"] for k in vis] + [1]) * 1.12
    if "_vm" not in S: S["_vm"] = target; S["_rk"] = {}
    S["_vm"] += (target - S["_vm"]) * 0.10
    vm = S["_vm"]
    order = sorted(vis, key=lambda k: -rows[k]["value"])
    if mystery: order = [n - 1] + order
    for r_, k in enumerate(order):
        S["_rk"][k] = S["_rk"].get(k, float(r_)) + (r_ - S["_rk"].get(k, float(r_))) * 0.22
    for k in order:
        row = rows[k]; yy = top + rh * S["_rk"][k] + rh / 2
        is_q = (k == n - 1 and mystery)
        ta = ts[k] if not is_q else tq
        al, sc_ = PP(t, ta, S, bounce=2.2)
        if al <= 0.01: continue
        old = St.a; St.a *= al
        c.save(); c.translate(LX + 30, yy); c.scale(sc_, sc_); c.translate(-(LX + 30), -yy)
        win = (k == n - 1 and not is_q)
        # tube
        th = 84; tx0 = TX0; tw_ = TX1 - TX0
        box(c, tx0, yy - th / 2, tw_, th, th / 2, P["bg1"], 0.9, stroke=P["gold"] if win else P["silver"], sw=6 if win else 4)
        if is_q:
            pu = 0.5 + 0.5 * math.sin(t * 8)
            draw_emoji(c, "❓", LX + 32, yy, 62)
            T(c, "Number 1?", 56, LX + 72, yy, P["navy"], 1, 1, 900, anchor="l", maxw=296)
            T(c, "?", 64, tx0 + tw_ / 2, yy + 2, P["gold_text"], 0.6 + 0.4 * pu, 1, 900)
        else:
            v = cur[k]; fw = max(th, tw_ * min(1.0, v / vm)) if v > 0 else 0
            lc = hx(LIQ[row["kind"]])
            if fw > 0:
                c.save(); rr(c, tx0, yy - th / 2, tw_, th, th / 2); c.clip()
                c.new_path(); c.move_to(tx0 - 5, yy - th / 2 - 5)
                ex = tx0 + fw
                for j in range(0, 21):
                    yy2 = yy - th / 2 + th * j / 20
                    c.line_to(ex + 6 * math.sin(yy2 / 9 + t * 6 + k), yy2)
                c.line_to(tx0 - 5, yy + th / 2 + 5); c.close_path(); sa(c, lc, 1.0); c.fill()

                R = random.Random(k)
                for j in range(5):   # bubbles drifting along the tube
                    bx = tx0 + ((t * (40 + 30 * R.random()) + R.random() * 400) % max(1, fw))
                    circ(c, bx, yy - th / 2 + 18 + R.random() * (th - 36), 4 + 2 * R.random(), P["white"], 0.45 if row["kind"] != "milk" else 0.0)
                c.restore()
            draw_emoji(c, row["icon"], LX + 32, yy, 62)
            T(c, row["label"], 56, LX + 72, yy, P["navy"], 1, 1, 900, anchor="l", maxw=296)
            lab = f"{_fmt(v)} L"
            dark = row["kind"] not in ("milk",)
            if font(56, 900).getlength(lab) + 50 < fw:
                T(c, lab, 56, tx0 + fw - 26, yy + 2, P["white"] if dark else P["navy"], 1, 1, 900, anchor="r", maxw=400)
            else:
                T(c, lab, 56, tx0 + fw + 16, yy + 2, P["navy"], 1, 1, 900, anchor="l", maxw=400)
            if win:
                a4, s4 = PP(t, ts[k] + 0.5, S, bounce=2.6)
                pill(c, "#1", 44, tx0 - 2, yy - th / 2 - 4, P["gold"], P["white"], a4, s4, w=900)
        c.restore(); St.a = old
    # callout + source of the newest drink
    if S.get("callout") and "callout" in tm:
        a5, s5 = PP(t, tm["callout"], S, bounce=2.4)
        pill(c, S["callout"], 56, CX, 1312, P["navy"], P["white"], a5, s5, outline=P["gold"], w=900)
    newest = max(vis, key=lambda k: ts[k]) if vis else None
    src = S.get("source")
    if mystery: src = S.get("q_source", src)
    elif newest is not None and rows[newest].get("source"): src = rows[newest]["source"]
    src_line(c, src, fade_in(t, t0 + 0.5, S))

# ------------------------------------------------------------------ total + Olympic pools
def pool(c, x, y, w, h, lev, t, k):
    box(c, x, y, w, h, 14, P["white"], 0.75, stroke=P["navy"], sw=5)
    c.save(); rr(c, x + 5, y + 5, w - 10, h - 10, 10); c.clip()
    ly = y + h - 5 - (h - 10) * lev
    c.new_path(); c.move_to(x, y + h)
    for j in range(0, 21):
        xx = x + w * j / 20; c.line_to(xx, ly + 4 * math.sin(xx / 12 + t * 5 + k))
    c.line_to(x + w, y + h); c.close_path(); sa(c, P["blue"]); c.fill()
    for j in range(1, 5):   # lane ropes
        lx = y + h * j / 5
        sa(c, P["white"], 0.55 if lev > 0.1 else 0); c.set_line_width(3); c.set_dash([10, 8]); c.move_to(x + 8, lx); c.line_to(x + w - 8, lx); c.stroke(); c.set_dash([])
    c.restore()

def sc_pools(c, t, S):
    t0 = S["t0"]; tm = S["times"]
    a, s = PP(t, t0 + 0.05, S)
    T(c, "All together", 60, CX, 300, P["navy"], a, s, 900, maxw=840)
    tn = tm.get("num", t0 + 0.6)
    v = 25 * ease((t - tn) / 1.2) if t >= tn else 0.0
    a2, s2 = PP(t, tn, S, bounce=2.2)
    T(c, f"{v:,.0f} million", 120, CX, 445, P["gold_text"], a2, s2, 900, maxw=840)
    T(c, "liters a day", 64, CX, 560, P["navy"], a2, s2, 900, maxw=840)
    tp = tm.get("pools", t0 + 3.0)
    a3, s3 = PP(t, tp - 0.3, S, bounce=2.2)
    T(c, "= 10 Olympic pools", 72, CX, 690, P["blue"], a3, s3, 900, maxw=840)
    pw, ph, gx, gy = 150, 100, 22, 30
    x0 = CX - (5 * pw + 4 * gx) / 2; y0 = 780
    for k in range(10):
        tk = tp + 0.12 * k
        if t < tk - 0.1: continue
        al = ramp(t, tk - 0.1, tk + 0.15); old = St.a; St.a *= al
        r_, q = divmod(k, 5); lev = 0.12 + 0.85 * ease((t - tk) / 1.4)
        pool(c, x0 + q * (pw + gx), y0 + r_ * (ph + gy), pw, ph, lev, t, k)
        St.a = old
    a4, s4 = PP(t, tm.get("every", tp + 1.6), S, bounce=2.4)
    pill(c, "Every single day", 56, CX, 1095, P["gold"], P["white"], a4, s4, w=900)
    T(c, "Olympic pool = 2.5 million liters", 40, CX, 1200, P["grey"], a3, 1, 700, maxw=840)
    src_line(c, S.get("source"), fade_in(t, t0 + 0.8, S), y=1340)
