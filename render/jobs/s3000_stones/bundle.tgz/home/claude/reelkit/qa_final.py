"""Final QA on a rendered reel: duration, size, loudness, resolution, dashes in captions/scripts, qa.json issues."""
import sys, subprocess, json, os, re
D = sys.argv[1]; n = os.path.basename(D.rstrip("/"))
for f in (f"{D}/{n}.mp4", f"{D}/{n}_web.mp4"):
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=width,height,r_frame_rate,sample_rate,codec_type",
                                    "-of", "json", f], capture_output=True, text=True).stdout)
    lo = subprocess.run(["ffmpeg", "-nostats", "-i", f, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    I = re.findall(r"I:\s+(-?[\d.]+) LUFS", lo)[-1]; TP = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", lo)[-1]
    v = [s for s in pr["streams"] if s["codec_type"] == "video"][0]; a = [s for s in pr["streams"] if s["codec_type"] == "audio"][0]
    print(os.path.basename(f), f"{float(pr['format']['duration']):.2f}s", f"{os.path.getsize(f) / 1e6:.2f}MB", f"{v['width']}x{v['height']}", v["r_frame_rate"], a["sample_rate"], "I", I, "TP", TP)
bad = [ch for p in (f"{D}/caption.txt", "/home/claude/reelkit/kit.py", "/home/claude/reelkit/draw.py", f"/home/claude/reelkit/{n}.py") if os.path.exists(p)
       for ch in open(p).read() if ch in "".join(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))]
print("dashes found:", len(bad))
q = json.load(open(f"{D}/qa/qa.json")); print("min text px", q["min_size"], "issues", q["issues"])
print("max words/card", max(v["words"] for v in q["cards"].values()), "min card s", min(v["dur"] for v in q["cards"].values()))
