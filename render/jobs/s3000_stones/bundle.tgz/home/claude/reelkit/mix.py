"""reelkit mix: voice + music bed ducked under the voice + optional SFX, mastered to -14 LUFS / -1.5 dBTP, 48 kHz.
Final video audio is AAC 192k 48 kHz (render.py muxes the wav this writes). web() makes the 540x960 preview (< 8 MB).

Music beds: all are the original procedural beds already made for earlier reels (no third-party music), generated to the
exact reel length, imported read-only from their reel folders (see BEDS). Any wav can be used too: "file:/path/to.wav"
(looped with a 1 s crossfade). SFX: Kenney CC0 glass ding + pluck (reelkit/sfx, from silly_maps/sfx_src) and the
synthesised whoosh from reelkit/sfx2.py."""
import os, sys, re, json, subprocess, importlib.util
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
SR = 48000

def _mod(name, path):
    d = os.path.dirname(path)
    if d not in sys.path: sys.path.insert(0, d)
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
# name: (module name, file, call(m, dur, end_at), description)
BEDS = {
    "guinness":   ("guinness_audio", "/home/claude/guinness_il/guinness_audio.py", lambda m, d, e: m.music(d), "bright pop, D major 112 BPM, pluck arpeggio + glock (Guinness IL v2)"),
    "shabbat":    ("shabbat_audio", "/home/claude/shabbat_record/shabbat_audio.py", lambda m, d, e: m.music(d), "warm celebratory pop, same family as guinness, softer end fade (Shabbat record)"),
    "journey":    ("journey_audio", "/home/claude/island_israel/journey_audio.py", lambda m, d, e: m.music(d), "light adventurous documentary, D 100 BPM, strings + celesta (Israel's Journey)"),
    "doc_piano":  ("audio_v4", "/home/claude/safety_v4/audio_v4.py", lambda m, d, e: m.doc_music(d), "serious documentary piano bed, 86 BPM (Where can a Jew walk safely, safety_v4)"),
    "playful":    ("sfx2", "/home/claude/reelkit/sfx2.py", lambda m, d, e: m.music_playful(d, e), "playful marimba + pizzicato, F 112 BPM, resolves on the end card (Emails story)"),
    "roadtrip":   ("sfx2", "/home/claude/reelkit/sfx2.py", lambda m, d, e: m.music_roadtrip(d, e), "upbeat road-trip groove, 104 BPM (US trip)"),
    "cinematic":  ("sfx2", "/home/claude/reelkit/sfx2.py", lambda m, d, e: m.music_cinematic(d, e, d * 0.6), "cinematic swell, 84 BPM, lift at 60 % (Israel trail)"),
    "bounce":     ("kit", "/home/claude/reelkit/kit.py", lambda m, d, e: m.music(d, "bounce"), "bouncy marimba, C 118 BPM (kit.py colourful series)"),
    "skip":       ("kit", "/home/claude/reelkit/kit.py", lambda m, d, e: m.music(d, "skip"), "skipping bells, 104 BPM (kit.py)"),
    "warm":       ("kit", "/home/claude/reelkit/kit.py", lambda m, d, e: m.music(d, "warm"), "warm pluck, 96 BPM (kit.py)"),
}
def load(path, ch=1):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", str(ch), "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).astype(np.float64); return x if ch == 1 else x.reshape(-1, ch).T
def bed(name, dur, end_at=None):
    """(2, n) float, peak normalised"""
    n = int(dur * SR)
    if not name: return np.zeros((2, n))
    if name.startswith("file:"):
        x = load(name[5:], 2); out = np.zeros((2, n)); L = x.shape[1]; f = min(SR, L // 4); fin = np.linspace(0, 1, f)
        i = 0; first = True
        while i < n:   # loop with a 1 s equal-gain crossfade
            seg = x.copy()
            if not first: seg[:, :f] *= fin
            seg[:, -f:] *= fin[::-1]; k = min(L, n - i); out[:, i:i + k] += seg[:, :k]; i += L - f; first = False
        fo = min(n, int(1.5 * SR)); out[:, -fo:] *= np.linspace(1, 0, fo)
    else:
        mn, path, call, _ = BEDS[name]; m = _mod(mn, path)
        out = np.asarray(call(m, dur, end_at if end_at else dur - 2.0), np.float64)
        if out.ndim == 1: out = np.vstack([out, out])
        out = out[:, :n]
        if out.shape[1] < n: out = np.pad(out, ((0, 0), (0, n - out.shape[1])))
    return out / (np.abs(out).max() + 1e-12)

# ------------------------------------------------------------------ SFX
_sfx = {}
def sfx(kind):
    if kind not in _sfx:
        if kind == "ding": x = load(f"{HERE}/sfx/glass_001.wav")
        elif kind == "pop":
            x = load(f"{HERE}/sfx/pluck_001.wav")
        elif kind == "whoosh":
            import sfx2; x = sfx2.whoosh(0.5)
        else: raise KeyError(kind)
        _sfx[kind] = x / (np.abs(x).max() + 1e-12)
    return _sfx[kind]
SFX_DB = {"whoosh": -9.0, "pop": -6.0, "ding": -3.0}       # relative to the sfx_db base

# ------------------------------------------------------------------ mix
def act_rms(x):
    n = int(0.05 * SR); m = len(x) // n
    e = np.sqrt((x[:m * n].reshape(m, n) ** 2).mean(1)); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
def speech_env(v):
    """0..1 speech presence: 10 ms RMS over a -40 dB gate, held 250 ms, 60 ms attack / 350 ms release (vosubs.py)"""
    hop = int(0.01 * SR); n = len(v) // hop; L = 20 * np.log10(np.sqrt((v[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9)
    on = (L > L.max() - 40).astype(float); on = np.convolve(on, np.ones(25), "same") > 0
    e = np.zeros(n); acc = 0.0
    for i in range(n):
        tgt = 1.0 if on[i] else 0.0; k = 0.01 / (0.06 if tgt > acc else 0.35); acc += (tgt - acc) * min(1, k * 3); e[i] = acc
    return np.interp(np.arange(len(v)), np.arange(n) * hop + hop / 2, e)
def mix(vo, dur, music, events, out_wav, music_db=-17.0, duck_db=7.0, sfx_db=-12.0, lufs=-14.0, tp=-1.5, tp_margin=0.7, log=print):
    """vo mono 48 kHz; music (2, n) or None; events [(t, kind_or_array, extra_db)].
    Music sits music_db under the voice's active RMS and ducks a further duck_db under speech. SFX sit sfx_db (+extra)
    under the voice and dip 4 dB under speech. Loudness: gain to `lufs`, 4x-oversampled limiter at tp - tp_margin
    (headroom for the AAC encode), re-measured and corrected twice (narrate.py method). Writes 24-bit wav."""
    n = int(round(dur * SR)); v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]
    vr = act_rms(v); sp = speech_env(v)
    m = np.zeros((2, n))
    if music is not None and np.abs(music).max() > 0:
        m[:, :min(n, music.shape[1])] = music[:, :n]
        m = m * (vr * 10 ** (music_db / 20) / act_rms(m.mean(0))) * 10 ** ((-duck_db * sp) / 20)
    S = np.zeros((2, n)); placed = []
    for t0, x, xdb in events:
        if isinstance(x, str): xdb += SFX_DB.get(x, 0); x = sfx(x)
        x = np.atleast_2d(x); x = np.vstack([x, x]) if x.shape[0] == 1 else x
        g = vr * 10 ** ((sfx_db + xdb) / 20) / (act_rms(x.mean(0)) + 1e-12); i = int(t0 * SR); j = min(n, i + x.shape[1])
        if j > i >= 0: S[:, i:j] += x[:, :j - i] * g; placed.append(round(t0, 2))
    S *= 10 ** (-4 * sp / 20)
    y = np.stack([v, v]) + m + S; raw = y.T.astype(np.float32).tobytes()
    def meas(af):
        e = subprocess.run(["ffmpeg", "-nostats", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af + ",ebur128=peak=true",
                            "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
        return float(re.findall(r"I:\s+(-?[\d.]+) LUFS", e)[-1]), float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", e)[-1])
    lim = 10 ** ((tp - tp_margin) / 20)
    chain = lambda g: f"volume={g:.2f}dB,aresample=192000,alimiter=limit={lim:.4f}:attack=0.5:release=40:level=false,aresample=48000"
    I0, _ = meas("anull"); g = lufs - I0
    for _ in range(2):
        I1, P1 = meas(chain(g)); g += lufs - I1
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", chain(g), "-ar", "48000",
                        "-c:a", "pcm_s24le", out_wav], input=raw, capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-400:]
    log(f"[mix] input {I0:.1f} LUFS, gain {g:+.1f} dB, {len(placed)} SFX -> {out_wav}")
    return dict(input_I=I0, gain_db=round(g, 2), sfx_at=placed, music_db=music_db, duck_db=duck_db, sfx_db=sfx_db)

def web(out_mp4, web_mp4, max_mb=8.0):
    """540x960 web preview under max_mb. The audio is copied: a second AAC encode (96k) pushed true peak over -1.5 dBTP"""
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out_mp4], capture_output=True, text=True).stdout)
    kb = int(min(1400, (max_mb * 8000 * 0.85) / dur - 200))
    for _ in range(3):
        subprocess.run(["nice", "-n", "10", "ffmpeg", "-v", "error", "-y", "-i", out_mp4, "-vf", "scale=540:960:flags=lanczos", "-c:v", "libx264",
                        "-preset", "fast", "-crf", "24", "-maxrate", f"{kb}k", "-bufsize", f"{2 * kb}k", "-pix_fmt", "yuv420p",
                        "-c:a", "copy", "-movflags", "+faststart", web_mp4], check=True)
        if os.path.getsize(web_mp4) / 1e6 < max_mb: break
        kb = int(kb * 0.7)
    return round(os.path.getsize(web_mp4) / 1e6, 2)

if __name__ == "__main__":
    for k, v in BEDS.items(): print(f"{k:11s} {v[3]}")
