"""Clean narration clips: rumble / plosive thumps, breaths and huffs between words.

  nice -n 15 python3 clean_vo.py IN_DIR OUT_DIR [--report]

Per clip (sample rate and length are kept exactly, so timelines do not move):
  1. 4th order high-pass at 90 Hz (removes sub-bass wind / mic-blast energy).
  2. De-plosive: the 90-250 Hz band is turned down (max 9 dB) only where it is 15 dB or more
     above the 250 Hz-4 kHz band (a pop / thump), fast attack, 40 ms release.
  3. Breath / huff attenuation: unvoiced, mid-centred noise segments of 70 ms or more
     (not /s/ or /sh/, which are high-centred) are ducked 18 dB with 15 ms ramps.
     The 40 ms right before a voiced onset is kept so /h/ and onsets stay natural.
  4. Light gap clean-up: anything 45 dB under the clip's speech level is ducked another 10 dB.
"""
import sys, os, glob, json, numpy as np, soundfile as sf
PLOS_DB = float(os.environ.get("PLOS_DB", 15))
from scipy.signal import butter, sosfiltfilt

def analyse(x, sr):
    hop = int(0.01 * sr); win = int(0.03 * sr); n = max(1, (len(x) - win) // hop + 1)
    idx = np.arange(win)[None, :] + hop * np.arange(n)[:, None]
    F = x[idx] * np.hanning(win)
    L = 10 * np.log10((F ** 2).mean(1) + 1e-12)
    # harmonicity on 80-1000 Hz band (robust to aspiration noise)
    vb = sosfiltfilt(butter(4, [80, 1000], "bp", fs=sr, output="sos"), x)[idx] * np.hanning(win)
    S = np.abs(np.fft.rfft(vb, 2 * win)) ** 2
    ac = np.fft.irfft(S)[:, :win]; ac /= ac[:, :1] + 1e-12
    h = ac[:, int(sr / 400):int(sr / 70)].max(1)
    P = np.abs(np.fft.rfft(F)) ** 2; fr = np.fft.rfftfreq(win, 1 / sr)
    mid = P[:, (fr > 300) & (fr < 2500)].sum(1) + 1e-12
    hi = P[:, (fr > 2500) & (fr < min(7000, sr / 2 - 100))].sum(1) + 1e-12
    hm = 10 * np.log10(hi / mid)
    return hop, win, n, L, h, hm

def clean(x, sr, rep=None):
    x = x.astype(np.float64)
    # 1. high-pass 90 Hz, 4th order
    x = sosfiltfilt(butter(4, 90, "hp", fs=sr, output="sos"), x)
    # 2. de-plosive on the 90-250 Hz band
    lp = sosfiltfilt(butter(4, 250, "lp", fs=sr, output="sos"), x); rest = x - lp
    mb = sosfiltfilt(butter(2, [250, 4000], "bp", fs=sr, output="sos"), x)
    w = int(0.005 * sr)
    env = lambda s: np.sqrt(np.convolve(s ** 2, np.ones(w) / w, "same") + 1e-12)
    over = 20 * np.log10(env(lp) / env(mb))          # dB the low band sits above the mid band
    lvl = 20 * np.log10(env(x)); spk = np.percentile(lvl, 95)
    red = np.clip(over - PLOS_DB, 0, 9) * (lvl > spk - 35)   # only real thumps: low band far above the mid band
    # attack fast, release 40 ms
    a_r = np.exp(-1 / (0.04 * sr)); g = np.empty_like(red); acc = 0.0
    for i in range(0, len(red), 32):
        tgt = red[i:i + 32].max()
        acc = tgt if tgt > acc else acc * a_r ** 32 + tgt * (1 - a_r ** 32)
        g[i:i + 32] = acc
    x = rest + lp * 10 ** (-g / 20)
    plosive_db = float(g.max()); plosive_ms = float((g > 3).sum() / sr * 1000)
    # 3. breaths
    hop, win, n, L, h, hm = analyse(x, sr)
    ref = np.percentile(L, 95)
    voiced = (h > 0.55) & (L > ref - 30)
    cand = (h < 0.45) & (L > ref - 50) & (L < ref - 4) & (hm < -3) & ~voiced
    for d in (1, 2):   # bridge 1-2 frame holes inside a noisy run
        hole = ~cand & np.r_[cand[d:], [False] * d] & np.r_[[False] * d, cand[:-d]] & ~voiced
        cand = cand | hole
    gain_db = np.zeros(n); breaths = []
    i = 0
    while i < n:
        if cand[i]:
            j = i
            while j < n and cand[j]: j += 1
            a, b = i, j
            # keep the 40 ms right before a voiced onset (aspirated onsets, /h/)
            if b < n and voiced[b:min(n, b + 3)].any(): b = max(a, b - 4)
            # a breath / huff touches silence on at least one side (phrase edge) or runs long;
            # consonants (/f/, /k/, /t/ bursts) sit between voiced sounds and are left alone
            near_sil = (L[max(0, a - 8):a] < ref - 35).any() or (L[j:min(n, j + 8)] < ref - 35).any() or a == 0 or j >= n
            ln = (b - a) * hop / sr
            if (ln >= 0.07 and near_sil) or ln >= 0.16:
                gain_db[a:b] = -18; breaths.append((round(a * hop / sr, 2), round((b - a) * hop / sr, 2), round(float(L[a:b].mean() - ref), 1)))
            i = j
        else: i += 1
    # 4. deep gaps
    gain_db = np.minimum(gain_db, np.where(L < ref - 45, -10, 0))
    # frame gains -> samples, 15 ms ramps
    t = np.arange(n) * hop + win // 2
    gs = np.interp(np.arange(len(x)), t, gain_db)
    r = int(0.015 * sr); k = np.hanning(2 * r + 1); k /= k.sum()
    gs = np.convolve(np.pad(gs, (r, r), mode="edge"), k, "valid")
    y = x * 10 ** (gs / 20)
    if rep is not None: rep.update(breaths=breaths, plosive_max_db=round(plosive_db, 1), plosive_ms=round(plosive_ms))
    return y

if __name__ == "__main__":
    ind, outd = sys.argv[1], sys.argv[2]; os.makedirs(outd, exist_ok=True)
    allrep = {}
    for f in sorted(glob.glob(os.path.join(ind, "*.wav"))):
        x, sr = sf.read(f); x = x.mean(1) if x.ndim > 1 else x
        rep = {}; y = clean(x, sr, rep)
        assert len(y) == len(x)
        sf.write(os.path.join(outd, os.path.basename(f)), y.astype(np.float32), sr, subtype="FLOAT")
        allrep[os.path.basename(f)] = rep
        if "--report" in sys.argv: print(os.path.basename(f), rep)
    json.dump(allrep, open(os.path.join(outd, "clean_report.json"), "w"), indent=1)
    nb = sum(len(r["breaths"]) for r in allrep.values())
    print(f"{len(allrep)} clips cleaned, {nb} breath/huff segments ducked, worst plosive cut {max(r['plosive_max_db'] for r in allrep.values())} dB")
