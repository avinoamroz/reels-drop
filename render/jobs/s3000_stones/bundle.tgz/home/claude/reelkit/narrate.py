"""Narrate a silent reel draft: house VO chain, ASR word timing, time-warped visuals, burned-in subs, music + SFX mix.
Used by emails_story/emails_v2.py, us_trip/us_trip_v2.py, israel_trail/build/trail_v2.py.

VO: kit.Reel chain (rubberband pitch 0.9715 formant preserved, bass g2 f135, clean_vo, atempo 1.1, 0.3 s lead), rebuilt from
ASR chunks (vo/asr.json from /home/claude/vo_v4/asr_segs.py on vo_raw.wav): pauses inside a line capped at 0.35 s, pauses
between lines capped at LGAP, plus optional extra room before chosen lines (for a visual or an SFX to land in silence).
Visuals: the silent draft's frame function is called at warp(t), a monotone piecewise-linear map from new time to draft
time anchored on narration words, so every beat starts with its line. Old subtitles are switched off and new ones are
drawn from the word timing. Frames stream straight into ffmpeg together with the finished mix (no frame dumps)."""
import os, sys, re, json, math, subprocess, shutil, time
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont
from scipy.signal import butter, sosfilt, lfilter
sys.path.insert(0, "/home/claude/reelkit")
import kit
from kit import SR, TEMPO, LEAD, GAPCAP, DASHES, W, H, FPS, SUB_BOTTOM, pil2cairo, subclean, subchunks, clean_vo, run

SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/vb"
os.makedirs(SCR, exist_ok=True)
kit.KEEP.update({"ROAD", "TRAIL", "LA", "RV"})

class VO:
    def __init__(s, folder, nums=(), lgap=0.5, extra=None, tail=1.8):
        s.D = folder; s.nums = nums; s.lgap = lgap; s.extra = extra or {}; s.tail = tail
        s.lines = [l.strip() for l in open(f"{folder}/tts.txt") if l.strip()]
        J = json.load(open(f"{folder}/vo/asr.json")); s.SEG = J["segs"]; s.CH = J["chunks"]
        assert len(s.SEG) == len(s.lines), (len(s.SEG), len(s.lines))
        s.clean = [subclean(l.replace("...", ""), nums) for l in s.lines]
        for c_ in s.clean: assert not any(d in c_ for d in DASHES), c_
        s.line_of = [next(i for i, (a, b) in enumerate(s.SEG) if ch[0] >= a - 0.02 and ch[1] <= b + 0.02) for ch in s.CH]
    def build(s):
        raw = run(["ffmpeg", "-v", "error", "-i", f"{s.D}/vo_raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                   "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"])
        x = np.frombuffer(raw, np.float32).astype(np.float64); x = clean_vo(x, SR).astype(np.float32)
        x = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                               "-f", "f32le", "pipe:1"], x.tobytes()), np.float32).astype(np.float64)
        CH = s.CH; n = len(CH); s.cmap = []; pieces = []; prev_en = None
        for k, (a, b, _) in enumerate(CH):
            pb = CH[k - 1][1] if k else a - 0.3; na = CH[k + 1][0] if k < n - 1 else b + 0.6
            a0 = max(a - 0.06, (pb + a) / 2) if k else max(0, a - 0.06); b0 = min(b + 0.14, (b + na) / 2)
            seg = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR)
            seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
            if k == 0: st = LEAD
            else:
                nat = (a - CH[k - 1][1]) / TEMPO; new_line = s.line_of[k] != s.line_of[k - 1]
                st = prev_en + (min(s.lgap, nat) + s.extra.get(s.line_of[k], 0.0) if new_line else min(GAPCAP, nat)) + s.extra.get(("c", k), 0.0)
            en = st + (b - a) / TEMPO; prev_en = en
            pieces.append((st - (a - a0) / TEMPO, seg)); s.cmap.append((st, en))
        s.last_word = prev_en; s.T_END = prev_en + s.tail
        y = np.zeros(int(s.T_END * SR) + SR)
        for t0, seg in pieces: i = int(t0 * SR); y[i:i + len(seg)] += seg
        s.vo = y[:int(s.T_END * SR)]
        s.lmap = []
        for i, (la, lb) in enumerate(s.SEG):
            ks = [k for k, cc in enumerate(CH) if s.line_of[k] == i]
            L = [max(1, len(CH[k][2])) for k in ks]; tot = sum(L); pts = []; acc = 0
            for k, l in zip(ks, L):
                pts.append((acc / tot, s.cmap[k][0])); acc += l; pts.append((acc / tot, s.cmap[k][1]))
            s.lmap.append(pts)
        s.lspan = [(p[0][1], p[-1][1]) for p in s.lmap]
        print(os.path.basename(s.D), "VO", round(s.T_END, 2), "s; lines", [(round(a, 2), round(b, 2)) for a, b in s.lspan], flush=True)
        return s
    ft = kit.Reel.ft
    at = kit.Reel.at
    def chunk(s, text):
        """index of the ASR chunk whose text starts with text"""
        return next(k for k, c_ in enumerate(s.CH) if c_[2].lower().startswith(text.lower()))
    def speech_mask(s, pad=0.06):
        """list of (t0, t1) where a word is being spoken (chunk spans)"""
        return [(a - pad, b + pad) for a, b in s.cmap]
    def subs(s, fill=(8, 16, 40, 200), maxw=920):
        items = []
        for i, l in enumerate(s.clean):
            cs = chunks7(l); L = len(l); pos = 0
            for cc in cs:
                p0 = l.find(cc, pos); p1 = p0 + len(cc); pos = p1
                items.append([s.ft(i, p0 / L), s.ft(i, p1 / L), cc])
        for a, b in zip(items, items[1:]):
            if b[0] - a[1] < 0.45: a[1] = b[0]
        items[-1][1] = s.T_END + 1
        F = ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54); out = []
        for a, b, cc in items:
            assert not any(d in cc for d in DASHES)
            w = cc.split(); lines = []; cur = ''
            for x in w:
                tr = (cur + ' ' + x).strip()
                if F.getlength(tr) <= maxw: cur = tr
                else: lines.append(cur); cur = x
            lines.append(cur); lh = 66; Wd = int(max(F.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
            im = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=fill)
            for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor='mm')
            out.append((a, b, pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd, cc))
        s.sub_items = out; return out

def chunks7(s, n=7):
    """kit.subchunks, but a sentence longer than n words is split at a comma when there is one near the middle"""
    sents = re.findall(r'(?:[^.?!]|(?<=\d)\.(?=\d))+[.?!]?', s); res = []
    for se in sents:
        w = se.split()
        if not w: continue
        if len(w) > n:
            cut = [i + 1 for i, x in enumerate(w[:-1]) if x[-1] in ",:" and 3 <= i + 1 <= len(w) - 3]
            if cut:
                k = min(cut, key=lambda i: abs(i - len(w) / 2)); parts = [" ".join(w[:k]), " ".join(w[k:])]
            elif len(w) <= 9: parts = [" ".join(w)]
            else: parts = subchunks(se, n)
        else: parts = [" ".join(w)]
        for p_ in parts:
            if res and len(p_.split()) <= 2 and len(res[-1].split()) + len(p_.split()) <= n: res[-1] += " " + p_
            else: res.append(p_)
    return res

# ------------------------------------------------------------------ time warp
class Warp:
    def __init__(s, pairs):
        """pairs: (new_t, old_t), both increasing"""
        P = sorted(pairs); s.n = np.array([p[0] for p in P]); s.o = np.array([p[1] for p in P])
        assert np.all(np.diff(s.n) > 0) and np.all(np.diff(s.o) >= 0), list(zip(s.n.round(2), s.o.round(2)))
        s.slopes = np.diff(s.o) / np.diff(s.n)
    def __call__(s, t):
        if t <= s.n[0]: return s.o[0] + (t - s.n[0])
        if t >= s.n[-1]: return s.o[-1] + (t - s.n[-1]) * 0.0
        return float(np.interp(t, s.n, s.o))
    def inv(s, to):
        return float(np.interp(to, s.o, s.n))
    def report(s):
        return [(round(a, 2), round(b, 2), round(k, 2)) for a, b, k in zip(s.n[:-1], s.o[:-1], s.slopes)]

# ------------------------------------------------------------------ audio helpers
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], "bp", fs=SR, output="sos"), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, "lp", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "hp", fs=SR, output="sos"), x)
def norm(x, peak=1.0): return x / (np.abs(x).max() + 1e-12) * peak
def tt(d): return np.arange(int(d * SR)) / SR
def load(path, ch=1):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", str(ch), "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).astype(np.float64); return x if ch == 1 else x.reshape(-1, ch).T
def act_rms(x):
    n = int(0.05 * SR); e = np.array([np.sqrt((x[i:i + n] ** 2).mean()) for i in range(0, len(x) - n, n)]); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
def speech_env(v):
    e2 = lfilter([1], [1, -0.9995], v ** 2) * 0.0005; envv = np.sqrt(np.maximum(e2, 0)); envv = np.convolve(envv, np.ones(4800) / 4800, "same")
    return np.clip(envv / (np.percentile(envv[envv > 0], 75) + 1e-9), 0, 1)

def mix(vo, dur, music, events, out_wav, music_db=-17.0, sfx_db=-12.0, duck_db=7.0, bed_duck_db=10.0, tp=-2.6):
    """vo mono; music stereo (2, n) normalised; events: (t0, array mono/stereo, extra_db, is_bed).
    Music sits music_db under the voice (active RMS) and ducks a further duck_db under speech. One-shot SFX sit sfx_db+extra
    under the voice; beds dip bed_duck_db more under speech. Two-pass loudnorm to -14 LUFS, TP -1.5, 48 kHz, 24-bit wav."""
    n = int(dur * SR); v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]
    vr = act_rms(v); sp = speech_env(v)
    m = np.zeros((2, n)); m[:, :min(n, music.shape[1])] = music[:, :n]
    m = m * (vr * 10 ** (music_db / 20) / act_rms(m.mean(0))) * 10 ** ((-duck_db * sp) / 20)
    S = np.zeros((2, n)); rep = []; bed_duck = 10 ** ((-bed_duck_db * sp) / 20)
    for t0, x, xdb, bed in events:
        x = np.atleast_2d(x); x = np.vstack([x, x]) if x.shape[0] == 1 else x
        g = vr * 10 ** ((sfx_db + xdb) / 20) / (act_rms(x.mean(0)) + 1e-12); i = int(t0 * SR); j = min(n, i + x.shape[1])
        if j > i:
            seg = x[:, :j - i] * g
            if bed: seg = seg * bed_duck[i:j]
            S[:, i:j] += seg; rep.append(round(t0, 2))
    y = np.stack([v, v]) + m + S
    raw = y.T.astype(np.float32).tobytes()
    # loudness: gain to -14 LUFS, then a 4x-oversampled peak limiter (true-peak safe), re-measured and corrected twice
    def meas_I(af):
        e = subprocess.run(["ffmpeg", "-nostats", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af + ",ebur128=peak=true",
                            "-f", "null", "-"], input=raw, capture_output=True, text=False).stderr.decode()
        return float(re.findall(r"I:\s+(-?[\d.]+) LUFS", e)[-1]), float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", e)[-1])
    lim = 10 ** (tp / 20)
    chain = lambda g: f"volume={g:.2f}dB,aresample=192000,alimiter=limit={lim:.4f}:attack=0.5:release=40:level=false,aresample=48000"
    I0, _ = meas_I("anull"); g = -14.0 - I0
    for _ in range(2):
        I1, _ = meas_I(chain(g)); g += -14.0 - I1
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", chain(g), "-ar", "48000",
                        "-c:a", "pcm_s24le", out_wav], input=raw, capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-400:]
    J = {"input_i": I0, "gain_db": round(g, 2)}
    # stems for the SFX-vs-voice check
    return {"input_I": J["input_i"], "sfx_at": rep, "vo_rms": vr, "sfx_stem": S, "music_stem": m}

def remux(mp4, wav):
    """swap the audio of a rendered mp4 for a new mix (video stream copied)"""
    tmp = mp4[:-4] + "_tmp.mp4"
    run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
         "-ar", "48000", "-shortest", "-movflags", "+faststart", tmp]); os.replace(tmp, mp4)
def sfx_under_voice_report(vo, S, mask):
    """dB of the SFX stem relative to the voice, over speech and over the key-word windows"""
    n = min(len(vo), S.shape[1]); s = S.mean(0)[:n]; v = vo[:n]; out = []
    for a, b, lab in mask:
        i, j = int(a * SR), int(b * SR)
        if j <= i: continue
        vr = np.sqrt((v[i:j] ** 2).mean()) + 1e-12; sr_ = np.sqrt((s[i:j] ** 2).mean()) + 1e-12
        out.append((lab, round(20 * np.log10(sr_ / vr), 1)))
    return out

# ------------------------------------------------------------------ render + checks
def wait_disk(mb=150):
    while shutil.disk_usage("/").free / 1e6 < mb:
        print("waiting for disk", round(shutil.disk_usage("/").free / 1e6), "MB", flush=True); time.sleep(30)
def sheet_of(thumbs, path, tw=390):
    th = int(tw * 16 / 9); cols = 4; rows = -(-len(thumbs) // cols)
    sheet = Image.new("RGB", (cols * (tw + 10) + 10, rows * (th + 52) + 10), (20, 20, 28)); d = ImageDraw.Draw(sheet)
    for k, (t_, im) in enumerate(thumbs):
        x = 10 + (k % cols) * (tw + 10); y = 10 + (k // cols) * (th + 52); sheet.paste(im.resize((tw, th), Image.LANCZOS), (x, y))
        d.text((x + 4, y + th + 4), f"{t_:.2f}s", font=kit.font(36, 700), fill=(255, 255, 255))
    sheet.quantize(256, method=Image.Quantize.MEDIANCUT).save(path, optimize=True)
def surf2pil(surf):
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data()); return Image.fromarray(a[:, :, [2, 1, 0]].copy())
def draw_subs(c, t, subs):
    for a, b, ss, x, y, _ in subs:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()
def render(frame_fn, T_END, wav, out_mp4, thumbs_at, sheet_png, name, crf=20, maxrate="2.5M"):
    """frame_fn(c, t_new) draws the full frame. Writes out_mp4 (+ AAC 192k from wav) and the QA sheet."""
    os.nice(5); wait_disk(200)
    N = int(math.ceil(T_END * FPS)); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "pipe:0", "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", str(crf),
           "-maxrate", maxrate, "-bufsize", "5M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
           "-t", f"{N / FPS:.3f}", "-movflags", "+faststart", out_mp4]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); thumbs = []; tset = {int(round(x * FPS)): x for x in thumbs_at}
    for fi in range(N):
        t = fi / FPS; frame_fn(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi in tset: thumbs.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 300 == 0: print(name, "frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0
    sheet_of(thumbs, sheet_png)
def web(out_mp4, web_mp4):
    wait_disk(80)
    run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", out_mp4, "-c:v", "libx264", "-preset", "medium", "-crf", "26", "-maxrate", "1.1M",
         "-bufsize", "2.2M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "48000", "-movflags", "+faststart", web_mp4])
def preview(frame_fn, times, path):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); th = []
    for t in times: frame_fn(c, t); th.append((t, surf2pil(surf)))
    sheet_of(th, path)

def loud(f):
    lo = subprocess.run(["ffmpeg", "-nostats", "-i", f, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", lo)[-1]); TP = float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", lo)[-1])
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,sample_rate,width,height",
                                    "-of", "json", f], capture_output=True, text=True).stdout)
    a = [s for s in pr["streams"] if s["codec_type"] == "audio"][0]
    return dict(file=os.path.basename(f), dur=round(float(pr["format"]["duration"]), 2), I=I, TP=TP, sr=a["sample_rate"], mb=round(os.path.getsize(f) / 1e6, 2))

_asr = None
def asr_check(media, vo, pad=0.25):
    """re-run the whisper on the FINAL mix, one window per script line (line span +- pad); word F1 vs the script line"""
    global _asr
    import sherpa_onnx
    from collections import Counter
    sys.argv_bak = sys.argv
    Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
    if _asr is None:
        _asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx",
                                                          tokens=Wd + "turbo-tokens.txt", language="en", task="transcribe", num_threads=2)
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", media, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    from num2words import num2words
    def spell(s):
        def one(m):
            t_ = m.group(0).replace(",", "")
            try:
                v = float(t_); iv = int(v)
                return num2words(iv, to="year") if v == iv and 1900 <= iv <= 2099 else num2words(v if v != iv else iv)
            except Exception: return t_
        return re.sub(r"\d[\d,]*(\.\d+)?", one, s)
    def toks(s): return re.findall(r"[a-z']+", spell(s).lower().replace("-", " ").replace(" and ", " "))
    out = []
    for i, (a, b) in enumerate(vo.lspan):
        def tr(a_, b_):
            seg = x[int(max(0, a_) * 16000):int(b_ * 16000)]
            st = _asr.create_stream(); st.accept_waveform(16000, np.concatenate([np.zeros(3200, np.float32), seg, np.zeros(6400, np.float32)])); _asr.decode_stream(st)
            return st.result.text.strip()
        def score(h):
            A, B = toks(h), toks(vo.lines[i]); return sum((Counter(A) & Counter(B)).values()) / max(1, len(B))
        h = tr(a - 0.15, b + 0.4); rec = score(h)          # whole line window
        if rec < 0.9:                                        # whisper sometimes truncates or loops on a long window: try chunk by chunk
            ks = [k for k in range(len(vo.CH)) if vo.line_of[k] == i]
            h2 = " ".join(tr(vo.cmap[k][0] - 0.12, vo.cmap[k][1] + 0.35) for k in ks)
            if score(h2) > rec: h, rec = h2, score(h2)
        out.append(dict(line=vo.lines[i], heard=h, recall=round(rec, 2)))
    return out
