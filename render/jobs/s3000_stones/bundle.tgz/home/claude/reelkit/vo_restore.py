"""House VO chain with the clean_vo soft-ending fix, for narrate.VO.
clean_vo sometimes ducks soft word endings (it reads them as breaths). VOR.build() runs the normal narrate chain, but the
clean_vo step is wrapped: inside every ASR speech chunk, wherever the cleaned signal sits 4 dB or more under the dry chain
(rubberband + bass, high-passed at 90 Hz like clean_vo, zero phase, so sample aligned) while the dry signal is real speech
(within 40 dB of the speech level), it crossfades back to the dry signal (15 ms ramps). Then the processed voice is run
through the local whisper (sherpa turbo, en) chunk by chunk and line by line; any chunk that lost words against the raw
take's transcript is restored in full from the dry chain and the VO is rebuilt. Report in s.restore_report."""
import re, sys, os, gc, json, numpy as np, subprocess
from collections import Counter
from scipy.signal import butter, sosfiltfilt
sys.path.insert(0, "/home/claude/reelkit")
import narrate as N
from kit import SR, TEMPO

_orig_clean = N.clean_vo
_asr = None
_lock = None
def lock():
    """join the machine-wide cooperative whisper lock used by reelkit/asr.py (one whisper at a time)"""
    global _lock
    if _lock is None:
        import fcntl
        _lock = open(os.environ.get("RK_ASR_LOCK", "/tmp/claude-0/asr.lock"), "a+")
        try: fcntl.flock(_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("another whisper holds the lock, waiting", flush=True); fcntl.flock(_lock, fcntl.LOCK_EX)
def unlock():
    global _lock
    if _lock is not None: _lock.close(); _lock = None
def asr():
    global _asr
    if _asr is None:
        lock(); wait_mem(2.2)
        import sherpa_onnx
        Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
        _asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx",
                                                          tokens=Wd + "turbo-tokens.txt", language="en", task="transcribe", num_threads=1)
    return _asr
def transcribe(x16, a, b):
    seg = x16[int(max(0, a) * 16000):int(b * 16000)]
    st = asr().create_stream(); st.accept_waveform(16000, np.concatenate([np.zeros(3200, np.float32), seg.astype(np.float32), np.zeros(6400, np.float32)]))
    asr().decode_stream(st); return st.result.text.strip()
def spell(s):
    from num2words import num2words
    def one(m):
        t_ = m.group(0).replace(",", "")
        try:
            v = float(t_); iv = int(v)
            return num2words(iv, to="year") if v == iv and 1900 <= iv <= 2099 else num2words(v if v != iv else iv)
        except Exception: return t_
    return re.sub(r"\d[\d,]*(\.\d+)?", one, s)
def toks(s): return re.findall(r"[a-z']+", spell(s).lower().replace("-", " ").replace(" and ", " "))
def missing(ref, hyp):
    c = Counter(toks(ref)) - Counter(toks(hyp)); return sorted(c.elements())
def to16(x):
    r = subprocess.run(["ffmpeg", "-v", "error", "-f", "f64le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-ar", "16000", "-f", "f32le", "pipe:1"],
                       input=x.astype(np.float64).tobytes(), capture_output=True)
    return np.frombuffer(r.stdout, np.float32)

def wait_mem(need_gb=1.9, max_wait=1800):
    """wait until the shared bash cgroup has room for a whisper model (other jobs run whisper too):
    free = limit - total_rss (page cache is reclaimable), room needed for 3 checks in a row"""
    import time, glob
    ds = glob.glob("/sys/fs/cgroup/memory/process_api/*/claude-code-bash")
    if not ds: return
    t0 = time.time(); ok = 0
    while time.time() - t0 < max_wait:
        try:
            lim = int(open(f"{ds[0]}/memory.limit_in_bytes").read())
            rss = int(re.search(r"^total_rss (\d+)", open(f"{ds[0]}/memory.stat").read(), re.M).group(1))
        except (OSError, AttributeError): return
        free = (lim - rss) / 1e9; ok = ok + 1 if free >= need_gb else 0
        if ok >= 3: return
        if ok == 0: print(f"waiting for memory, {free:.2f} GB free", flush=True)
        time.sleep(4 if ok else 10)

class VOR(N.VO):
    def _clean_fixed(s, x, sr):
        c = _orig_clean(x, sr); d = sosfiltfilt(butter(4, 90, "hp", fs=sr, output="sos"), x)
        hop = int(0.01 * sr); n = len(c) // hop
        lev = lambda y: 10 * np.log10((y[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
        Lc, Ld = lev(c), lev(d); ref = np.percentile(Ld, 95)
        inch = np.zeros(n, bool)
        for a, b, _ in s.CH: inch[max(0, int((a - 0.05) * 100)):min(n, int((b + 0.08) * 100))] = True
        m = inch & (Ld - Lc > 4) & (Ld > ref - 40)
        m = np.convolve(m.astype(float), np.ones(5), "same") > 0
        for k in s.force:                                  # whole chunks that ASR said lost words
            a, b, _ = s.CH[k]; m[max(0, int((a - 0.04) * 100)):min(n, int((b + 0.12) * 100))] = True
        spans = []; i = 0
        while i < n:
            if m[i]:
                j = i
                while j < n and m[j]: j += 1
                spans.append((i / 100, j / 100)); i = j
            else: i += 1
        w = np.zeros(len(c)); r = int(0.015 * sr)
        for a, b in spans:
            ia, ib = int(a * sr), int(b * sr); w[ia:ib] = 1
            lo = max(0, ia - r); w[lo:ia] = np.maximum(w[lo:ia], np.linspace(0, 1, ia - lo))
            hi = min(len(w), ib + r); w[ib:hi] = np.maximum(w[ib:hi], np.linspace(1, 0, hi - ib))
        s.spans = spans
        return c * (1 - w) + d * w
    def build(s, check=True):
        global _asr
        cache = f"{s.D}/vo/restore.json"
        if check and os.path.exists(cache) and not os.environ.get("VO_REDO"):   # restore already checked: reuse it, no ASR in this process
            J = json.load(open(cache)); s.force = set(J["forced"]); s.restore_report = J["report"]
            N.clean_vo = s._clean_fixed
            try: N.VO.build(s)
            finally: N.clean_vo = _orig_clean
            return s
        s.force = set(getattr(s, "force", set())); rep = []
        part = f"{s.D}/vo/restore_partial.json"
        if os.path.exists(part): s.force |= set(json.load(open(part))["forced"])   # resume after an OOM kill
        for it in range(3):
            _asr = None; gc.collect()                      # no whisper in memory while the VO is rebuilt
            N.clean_vo = s._clean_fixed
            try: N.VO.build(s)
            finally: N.clean_vo = _orig_clean
            if not check: break
            x16 = to16(s.vo); tmp = f"{s.D}/vo/_asr_pass"; x16.tofile(tmp + ".f32")
            spans = [(a - 0.12, b + 0.3) for a, b in s.cmap] + [(a - 0.15, b + 0.4) for a, b in s.lspan]
            json.dump(dict(wav16=tmp + ".f32", spans=spans), open(tmp + "_in.json", "w"))
            del x16; gc.collect()
            for attempt in range(6):                       # whisper runs in its own process; retry if the box OOM-kills it
                r_ = subprocess.run([sys.executable, "/home/claude/reelkit/vo_asr_pass.py", tmp + "_in.json", tmp + "_out.json"])
                if r_.returncode == 0: break
                print("ASR pass process failed", r_.returncode, "retrying", flush=True)
            assert r_.returncode == 0
            T_ = json.load(open(tmp + "_out.json"))["texts"]
            for f_ in (".f32", "_in.json", "_out.json"): os.remove(tmp + f_)
            nc = len(s.cmap); bad = []; lines = []
            for k in range(nc):
                ms = missing(s.CH[k][2], T_[k])
                if ms: bad.append((k, s.CH[k][2], T_[k], ms))
            for i in range(len(s.lspan)):
                h = T_[nc + i]; lines.append(dict(line=s.lines[i], heard=h, missing=missing(s.lines[i], h)))
            rep.append(dict(iter=it, restored_spans=len(s.spans), restored_s=round(sum(b - a for a, b in s.spans), 2),
                            forced=sorted(s.force), chunk_losses=[dict(k=k, raw=r_, heard=h, missing=ms) for k, r_, h, ms in bad],
                            line_check=[l for l in lines if l["missing"]]))
            print("VO restore pass", it, "spans", len(s.spans), "chunk losses", [(k, ms) for k, _, _, ms in bad], flush=True)
            json.dump(dict(forced=sorted(s.force | {k for k, *_ in bad}), report=rep), open(part, "w"), ensure_ascii=False)
            new = {k for k, *_ in bad} - s.force
            if not new: break
            s.force |= new
        s.restore_report = rep; _asr = None; gc.collect(); unlock()
        if check:
            json.dump(dict(forced=sorted(s.force), report=rep), open(cache, "w"), indent=1, ensure_ascii=False)
            os.path.exists(part) and os.remove(part)
        return s
