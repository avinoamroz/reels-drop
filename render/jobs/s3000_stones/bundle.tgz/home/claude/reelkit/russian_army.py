"""Reel: I learned Russian because of a stupid joke. (@expressenglishcom, collab @noamroz__)
Light professional look (silver/white gradient, Express navy text, Express blue accents, thin grey rules).
Reuses kit.py VO chain / ASR timing / mix / streaming render; overrides background, subtitle pill colour, adds Cyrillic font.
usage: python3 russian_army.py [--preview [t1,t2,..]]"""
import sys; sys.path.insert(0, "/home/claude/reelkit")
import kit
from draw import *
from PIL import Image as _Im, ImageDraw as _IDr, ImageFont as _IF

NAVY = hx("#163260"); BLUE = hx("#2A88D4"); BG0 = hx("#F4F5F7"); BG1 = hx("#D9DDE3"); RULE = hx("#A9B1BD")
SILVER = hx("#C9CFD8"); SLATE = hx("#5B6E8C"); PAPER = hx("#FFFFFF"); LINEG = hx("#DCE1E8"); DARKG = hx("#7D8796")
SKIN = hx("#EDCFB4"); SKIN_D = hx("#C9A083"); NAIL = hx("#F8EADF")
N255 = c255(NAVY); B255 = c255(BLUE); WH = (255, 255, 255, 255)
DISCO = [hx("#FF5FA2"), hx("#3FD0FF"), hx("#FFD84A"), hx("#9B6BFF"), hx("#3EE08F"), hx("#FF9A4A")]
kit.FONTS["cyr"] = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"
kit.FONTS["hand"] = "/usr/share/fonts/truetype/google-fonts/Lora-Italic-Variable.ttf"
BEAT = 60 / 96  # "warm" music bed tempo: dancing fingers bob on the beat

# ------------------------------------------------------------------ look overrides
def bg(c, t, pa, pb, u):
    g = cairo.LinearGradient(0, 0, W * 0.25, H); g.add_color_stop_rgba(0, *BG0[:3], 1); g.add_color_stop_rgba(1, *BG1[:3], 1)
    c.set_source(g); c.paint()
    for k, (bx, by, br, sp) in enumerate([(250, 520, 520, 0.17), (860, 1250, 560, 0.13)]):
        x = bx + 70 * math.sin(t * sp + k * 2); y = by + 60 * math.cos(t * sp * 1.3 + k)
        rg = cairo.RadialGradient(x, y, 0, x, y, br); rg.add_color_stop_rgba(0, 1, 1, 1, 0.55); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        c.set_source(rg); c.arc(x, y, br, 0, 2 * math.pi); c.fill()
    sa(c, RULE, 0.7); c.set_line_width(2)
    for y in (215, 1660): c.move_to(70, y); c.line_to(1010, y); c.stroke()
    box(c, 70, 211, 64, 8, 3, BLUE); box(c, 946, 1656, 64, 8, 3, BLUE)
kit.background = bg

def subs_navy(s):
    """kit Reel.subs (make_subs.py look and chunking), with a navy pill for the light background"""
    items = []
    for i, l in enumerate(s.clean):
        cs = subchunks(l); L = len(l); pos = 0
        for cc in cs:
            p0 = l.find(cc, pos); p1 = p0 + len(cc); pos = p1
            items.append([s.ft(i, p0 / L), s.ft(i, p1 / L), cc])
    for a, b in zip(items, items[1:]):
        if b[0] - a[1] < 0.45: a[1] = b[0]
    F = _IF.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54); out = []
    for a, b, cc in items:
        assert not any(d in cc for d in DASHES)
        w = cc.split(); lines = []; cur = ''
        for x in w:
            tr = (cur + ' ' + x).strip()
            if F.getlength(tr) <= 920: cur = tr
            else: lines.append(cur); cur = x
        lines.append(cur); lh = 66; Wd = int(max(F.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
        im = _Im.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = _IDr.Draw(im)
        d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(22, 50, 96, 238))
        for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor='mm')
        out.append((a, b, pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd, cc))
    s.sub_items = out; return out
kit.Reel.subs = subs_navy

_qa = kit.qa_report
def qa_rep(r, scenes):
    rep = _qa(r, scenes)
    rep["issues"] = [x for x in rep["issues"] if not (x[0] == "card<3s" and x[2] >= 2.5)]
    rep["issues"] += [("card<2.5s", i, v["dur"]) for i, v in rep["cards"].items() if v["dur"] < 2.5]
    return rep
kit.qa_report = qa_rep

# ------------------------------------------------------------------ text helpers
def P(t, t0): return pop(t, t0, d=0.42, s0=0.55, bounce=1.1)
def T(c, s, sz, y, a=1.0, sc=1.0, x=540, w=900, col=N255, **kw):
    return tx(c, s, sz, x, y, w, col, a, sc, hl=B255, shadow=False, **kw)
def HE(c, s, y, a=1.0, sc=1.0, sz=64): return tx(c, s, sz, 540, y, 700, N255, a, sc, shadow=False)
def RU(c, s, sz, y, a=1.0, sc=1.0, x=540, col=N255): return tx(c, s, sz, x, y, "cyr", col, a, sc, shadow=False)
def pill(c, s, sz, x, y, bg=NAVY, fg=WH, a=1.0, sc=1.0, outline=None, strike=0.0, w=900, hl=None):
    f = font(sz, 700 if is_he(s) else w); tw = f.getlength(s.replace("*", "")); pw = tw + sz * 1.1; ph = sz * 1.5
    mw = 935 - sz * 1.1
    if a > 0.01 and sc > 1e-3:
        c.save(); c.translate(x, y); c.scale(sc, sc)
        sa(c, NAVY, 0.10 * a); rr(c, -pw / 2, -ph / 2 + 10, pw, ph, ph / 2); c.fill()
        box(c, -pw / 2, -ph / 2, pw, ph, ph / 2, bg, a, stroke=outline, sw=3)
        c.restore()
    fc = fg if strike <= 0 else tuple(int(lerp(v, g, 0.55 * ease(strike))) for v, g in zip(fg[:3], (150, 158, 170))) + (255,)
    tx(c, s, sz, x, y + 2 * sc, w, fc, a, sc, hl=hl or (B255 if bg == PAPER else (190, 222, 255, 255)), shadow=False, maxw=mw)
    if strike > 0 and a > 0.01:
        L = (pw - sz * 0.6) * sc; x0 = x - L / 2
        line(c, [(x0, y + 3), (x0 + L * ease(strike), y - 3)], BLUE, 9 * sc, a)
def card(c, x, y, w, h, a=1.0, r=36, fill=PAPER):
    sa(c, NAVY, 0.08 * a); rr(c, x, y + 12, w, h, r); c.fill()
    box(c, x, y, w, h, r, fill, a, stroke=LINEG, sw=3)
def dtxf(c, s, sz, col, w="cyr"):
    surf, tw, th, pad = text_surf(s, sz, w, col, B255, False)
    c.set_source_surface(surf, -tw / 2 - pad, -th / 2 - pad); c.paint_with_alpha(St.a); return tw
def bubble(c, s, sz=48, fill=PAPER, fg=N255, tail=1, w="cyr", stroke=LINEG):
    tw = font(sz, w).getlength(s); bw = tw + sz * 1.1; bh = sz * 1.75
    sa(c, NAVY, 0.08); rr(c, -bw / 2, -bh / 2 + 8, bw, bh, bh / 2.4); c.fill()
    rr(c, -bw / 2, -bh / 2, bw, bh, bh / 2.4); sa(c, fill); c.fill_preserve(); sa(c, stroke); c.set_line_width(3); c.stroke()
    tx0 = tail * bw * 0.22
    c.move_to(tx0 - 16, bh / 2 - 2); c.line_to(tx0 + tail * 22, bh / 2 + 30); c.line_to(tx0 + 16, bh / 2 - 2); c.close_path(); sa(c, fill); c.fill()
    dtxf(c, s, sz, fg, w)

# ------------------------------------------------------------------ drawings (local coords)
def finger(c, x, y, w, L, ang, ext, light=None):
    c.save(); c.translate(x, y); c.rotate(ang); l = lerp(w * 0.85, L, ext)
    rr(c, -w / 2, -l, w, l + w * 0.6, w / 2); sa(c, SKIN); c.fill_preserve(); sa(c, SKIN_D); c.set_line_width(4); c.stroke()
    if light: rr(c, -w / 2, -l, w, l + w * 0.6, w / 2); sa(c, light, 0.20); c.fill()
    if ext > 0.45:
        rr(c, -w * 0.30, -l + w * 0.14, w * 0.60, w * 0.62, w * 0.28); sa(c, NAIL, ease((ext - 0.45) / 0.3)); c.fill()
        line(c, [(-w * 0.28, -l * 0.42), (w * 0.28, -l * 0.42)], SKIN_D, 3, 0.6 * ext)
    c.restore()
def hand(c, exts, angs, lens=(1, 1, 1, 1), lights=None):
    """hand from below, palm facing viewer. fingers 0..3 = index..pinky"""
    box(c, -112, 150, 224, 150, 34, NAVY); line(c, [(-112, 172), (112, 172)], BLUE, 6)
    xs = [-63, -21, 21, 62]; Ls = [150, 168, 158, 122]; ws = [44, 46, 44, 38]
    for k in range(4): finger(c, xs[k], -30, ws[k], Ls[k] * lens[k], angs[k], exts[k], lights[k] if lights else None)
    rr(c, -96, -62, 192, 228, 72); sa(c, SKIN); c.fill_preserve(); sa(c, SKIN_D); c.set_line_width(4); c.stroke()
    if lights: rr(c, -96, -62, 192, 228, 72); sa(c, lights[4], 0.13); c.fill()
    c.save(); c.translate(-92, 46); c.rotate(-0.55); rr(c, -25, -92, 50, 124, 25); sa(c, SKIN); c.fill_preserve(); sa(c, SKIN_D); c.set_line_width(4); c.stroke(); c.restore()
    line(c, [(-40, 60), (30, 80)], SKIN_D, 3, 0.55); line(c, [(-30, 100), (40, 112)], SKIN_D, 3, 0.45)
def one_finger(c, t, rise=1.0):
    hand(c, [rise, 0, 0, 0], [0.04 * math.sin(t * 2.2), 0.06, 0.05, 0.08])
def dancing_hand(c, t, up):
    ph = math.pi * t / BEAT; exts = [1.0] + [up] * 3
    fan = [-0.30, -0.10, 0.10, 0.30]
    angs = [up * (fan[k] + 0.30 * math.sin(ph + k * math.pi / 2)) for k in range(4)]
    lens = [1 + up * (0.18 - 0.22 * abs(math.sin(ph + k * 0.9))) for k in range(4)]
    lights = [DISCO[(k + int(t / BEAT)) % 6] for k in range(5)]
    hand(c, exts, angs, lens, lights)
def disco_ball(c, t, R=86):
    line(c, [(0, -R - 120), (0, -R)], DARKG, 4); box(c, -14, -R - 12, 28, 18, 4, DARKG)
    c.save(); c.new_sub_path(); c.arc(0, 0, R, 0, 2 * math.pi); c.clip()
    g = cairo.RadialGradient(-R * 0.35, -R * 0.35, 5, 0, 0, R); g.add_color_stop_rgba(0, 0.97, 0.98, 1, 1); g.add_color_stop_rgba(1, 0.55, 0.6, 0.68, 1)
    c.set_source(g); c.paint(); s = R / 4.2; off = (t * 55) % s
    for row in range(-5, 6):
        for col in range(-7, 8):
            x = col * s + off - s / 2; y = row * s
            cw = s * math.cos(min(1.45, abs(x) / R * 1.2)); hsh = (int((t * 55) // s) - col) * 7 + row * 13
            v = (hsh * 2654435761 + int(t * 8)) % 11
            colr = WHITE if v < 3 else (DISCO[v % 6] if v < 6 else hx("#8C95A3"))
            rr(c, x - cw / 2 + 1, y - s / 2 + 1, max(2, cw - 2), s - 2, 2); sa(c, colr, 0.75 if v < 6 else 0.35); c.fill()
    c.restore(); c.new_sub_path(); c.arc(0, 0, R, 0, 2 * math.pi); sa(c, DARKG); c.set_line_width(3); c.stroke()
    for k in range(4):
        a = t * 1.7 + k * 1.57; x, y = R * 0.7 * math.cos(a), R * 0.55 * math.sin(a * 1.3); al = 0.5 + 0.5 * math.sin(t * 7 + k * 2)
        for ang in (0, math.pi / 2): line(c, [(x - 16 * math.cos(ang), y - 16 * math.sin(ang)), (x + 16 * math.cos(ang), y + 16 * math.sin(ang))], WHITE, 4, al)
def bust(c, col=NAVY, shake=0.0):
    c.save(); c.rotate(shake)
    circ(c, 0, -78, 60, col)
    c.move_to(-118, 112); c.curve_to(-118, 10, -66, -4, 0, -4); c.curve_to(66, -4, 118, 10, 118, 112); c.close_path(); sa(c, col); c.fill()
    c.restore()
def badge(c):
    c.move_to(0, -96); c.curve_to(40, -78, 70, -76, 82, -78); c.line_to(82, 4); c.curve_to(82, 58, 36, 86, 0, 104)
    c.curve_to(-36, 86, -82, 58, -82, 4); c.line_to(-82, -78); c.curve_to(-70, -76, -40, -78, 0, -96); c.close_path()
    g = cairo.LinearGradient(-80, -90, 80, 100); g.add_color_stop_rgba(0, 0.95, 0.96, 0.98, 1); g.add_color_stop_rgba(1, 0.70, 0.74, 0.80, 1)
    c.set_source(g); c.fill_preserve(); sa(c, NAVY); c.set_line_width(6); c.stroke()
    box(c, -34, -34, 68, 68, 10, NAVY)
    for k in range(3):
        o = -18 + k * 18
        for (x0, y0, x1, y1) in [(o, -34, o, -48), (o, 34, o, 48), (-34, o, -48, o), (34, o, 48, o)]: line(c, [(x0, y0), (x1, y1)], NAVY, 5)
    box(c, -16, -16, 32, 32, 5, BLUE)
def desk(c, t, u):
    box(c, -320, 118, 640, 26, 10, SILVER); box(c, -300, 144, 20, 110, 6, hx("#AEB6C2")); box(c, 280, 144, 20, 110, 6, hx("#AEB6C2"))
    for k, x in enumerate((-150, 150)):
        box(c, x - 12, 30, 24, 64, 4, SILVER); box(c, x - 62, 90, 124, 16, 6, hx("#AEB6C2"))
        box(c, x - 135, -150, 270, 186, 16, NAVY); box(c, x - 121, -136, 242, 154, 8, hx("#1D4479"))
        for j in range(6):
            full = [150, 110, 180, 90, 160, 120][(j + k * 2) % 6]; ind = [0, 20, 20, 40, 20, 0][(j + k) % 6]
            p = max(0.0, min(1.0, u * 6 - j - k * 0.5)); col = BLUE if j % 3 == 0 else (WHITE if j % 3 == 1 else hx("#7FB6E6"))
            if p > 0: box(c, x - 104 + ind, -122 + j * 22, full * p, 10, 5, col, 0.9)
        if (t * 2) % 1 < 0.6: box(c, x - 104 + 150 * min(1, max(0, u * 6 - 5)), -122 + 5 * 22, 6, 14, 2, WHITE)
    box(c, -120, 98, 240, 22, 6, hx("#E3E7EC"), stroke=hx("#AEB6C2"), sw=2)
def notebook(c, n_lines):
    sa(c, NAVY, 0.10); rr(c, -290, -170, 580, 360, 20); c.fill()
    box(c, -290, -185, 290, 360, 18, PAPER, stroke=LINEG, sw=3); box(c, 0, -185, 290, 360, 18, PAPER, stroke=LINEG, sw=3)
    g = cairo.LinearGradient(-40, 0, 40, 0); g.add_color_stop_rgba(0, 0.6, 0.64, 0.7, 0); g.add_color_stop_rgba(0.5, 0.6, 0.64, 0.7, 0.35); g.add_color_stop_rgba(1, 0.6, 0.64, 0.7, 0)
    c.set_source(g); c.rectangle(-40, -185, 80, 360); c.fill()
    for j in range(7):
        y = -130 + j * 44
        for sx in (-1, 1): line(c, [(sx * 40, y), (sx * 260, y)], LINEG, 3)
    for k in range(n_lines):
        side = -1 if k < 6 else 1; j = k % 6; y = -136 + j * 44; wv = [170, 140, 190, 120, 160, 150][k % 6]
        if side == -1: line(c, [(-250, y), (-250 + wv, y)], BLUE if k % 2 == 0 else NAVY, 9)
        else: line(c, [(60, y), (60 + wv, y)], BLUE if k % 2 == 0 else NAVY, 9)
    for j in range(7): circ(c, 0, -160 + j * 52, 9, PAPER, stroke=DARKG, sw=4)
def word_card(c, s):
    tw = font(44, "cyr").getlength(s); w = tw + 60
    sa(c, NAVY, 0.12); rr(c, -w / 2, -40 + 8, w, 80, 14); c.fill()
    box(c, -w / 2, -40, w, 80, 14, PAPER, stroke=LINEG, sw=3); box(c, -w / 2, 30, w, 10, 4, BLUE)
    dtxf(c, s, 44, N255)
def dictionary(c):
    box(c, -110, -150, 220, 300, 16, NAVY); box(c, 96, -142, 26, 284, 6, hx("#EEF1F5"), stroke=SILVER, sw=2)
    for j in range(7): line(c, [(100, -130 + j * 42), (118, -130 + j * 42)], SILVER, 2)
    box(c, -110, -150, 30, 300, 8, hx("#0F2546"))
    for k, col in enumerate((BLUE, SILVER, BLUE)): box(c, 112, -110 + k * 80, 28, 44, 6, col)
    box(c, -66, -86, 140, 70, 10, PAPER, 0.95); dtxf(c, "А Б В", 38, N255)
    c.save(); c.translate(4, 60); dtxf(c, "СЛОВАРЬ", 38, WH); c.restore()
def profile_head(c, col=NAVY):
    circ(c, 0, -40, 104, col)
    c.move_to(90, -60); c.line_to(132, -6); c.line_to(94, 8); c.close_path(); sa(c, col); c.fill()
    box(c, -46, 40, 92, 80, 20, col)
    c.move_to(-150, 210); c.curve_to(-150, 120, -90, 100, 0, 100); c.curve_to(90, 100, 150, 120, 150, 210); c.close_path(); sa(c, col); c.fill()
    c.new_sub_path(); c.arc(-22, -36, 22, -1.2, 1.6); sa(c, hx("#5F87C2")); c.set_line_width(7); c.stroke()
def waves(c, t, a=1.0):
    for k in range(3):
        ph = (t * 0.9 + k / 3) % 1; r = 40 + ph * 140
        c.new_sub_path(); c.arc(0, 0, r, math.pi - 0.6, math.pi + 0.6); sa(c, BLUE, a * (1 - ph)); c.set_line_width(8); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
def book_cover(c, title, sub, col, motif, t):
    box(c, -130, -185, 260, 370, 14, col); box(c, -130, -185, 22, 370, 7, mix(col, (0, 0, 0, 1), 0.25))
    box(c, -96, -160, 206, 320, 10, (1, 1, 1, 1), 0.0, stroke=(1, 1, 1, 0.55), sw=3)
    c.save(); c.translate(7, 50); motif(c, t); c.restore()
    c.save(); c.translate(7, -112 if not sub else -126)
    dtxf(c, title, 38, WH)
    if sub: c.translate(0, 46); dtxf(c, sub, 38, WH)
    c.restore()
def motif_stars(c, t):
    for k, (x, y, r) in enumerate([(-50, -30, 16), (40, -50, 12), (0, 30, 22), (55, 40, 10), (-45, 60, 9)]):
        s = r * (1 + 0.15 * math.sin(t * 3 + k)); c.save(); c.translate(x, y); c.move_to(0, -s)
        for j in range(1, 10): a = j * math.pi / 5; rr_ = s if j % 2 == 0 else s * 0.45; c.line_to(rr_ * math.sin(a), -rr_ * math.cos(a))
        c.close_path(); sa(c, WHITE, 0.85); c.fill(); c.restore()
def motif_heart(c, t):
    s = 1 + 0.05 * math.sin(t * 4); c.save(); c.scale(s, s); heart(c, WHITE, 1.1); c.restore()
    circ(c, 0, 0, 78, WHITE, 0.0, stroke=(1, 1, 1, 0.5), sw=4)
def motif_hut(c, t):
    c.save(); c.translate(0, -10 + 4 * math.sin(t * 2))
    box(c, -44, -30, 88, 64, 6, WHITE, 0.9); c.move_to(-60, -26); c.line_to(0, -76); c.line_to(60, -26); c.close_path(); sa(c, WHITE); c.fill()
    box(c, -12, -6, 24, 24, 3, SLATE)
    for sx in (-1, 1): line(c, [(sx * 22, 34), (sx * 30, 70), (sx * 22, 92)], WHITE, 7); line(c, [(sx * 22, 92), (sx * 40, 98)], WHITE, 5)
    c.restore()
def moon(c):
    c.new_sub_path(); c.arc(0, 0, 54, 0, 2 * math.pi); sa(c, NAVY); c.fill()
    c.new_sub_path(); c.arc(24, -16, 48, 0, 2 * math.pi); sa(c, BG0); c.fill()
def lamp(c):
    g = cairo.LinearGradient(0, 0, 0, 420); g.add_color_stop_rgba(0, 1, 0.98, 0.9, 0.85); g.add_color_stop_rgba(1, 1, 0.98, 0.9, 0)
    c.move_to(-60, 10); c.line_to(60, 10); c.line_to(420, 420); c.line_to(-420, 420); c.close_path(); c.set_source(g); c.fill()
    line(c, [(0, -90), (0, -40)], DARKG, 5)
    c.move_to(-70, 14); c.line_to(-34, -44); c.line_to(34, -44); c.line_to(70, 14); c.close_path(); sa(c, NAVY); c.fill()
def paper(c, lines, prog, t):
    card(c, -360, -190, 720, 380, 1.0, 24)
    for j in range(4): line(c, [(-320, -90 + j * 90), (320, -90 + j * 90)], LINEG, 3)
    px, py = None, None
    for j, s in enumerate(lines):
        p = max(0.0, min(1.0, prog * len(lines) - j))
        if p <= 0: continue
        surf, tw, th, pad = text_surf(s, 70, "hand", N255, B255, False); x0 = -300; y0 = -110 + j * 90
        c.save(); c.rectangle(x0 - pad, y0 - th, (tw + pad) * p + pad, th * 2); c.clip()
        c.set_source_surface(surf, x0 - pad, y0 - th / 2 - pad - 18); c.paint_with_alpha(St.a); c.restore()
        if p < 1: px, py = x0 + tw * p, y0 - 10
    if px is not None:
        c.save(); c.translate(px + 10, py - 30 + 6 * math.sin(t * 20)); c.rotate(0.6)
        box(c, -10, -110, 20, 100, 6, NAVY); c.move_to(-10, -10); c.line_to(10, -10); c.line_to(0, 14); c.close_path(); sa(c, BLUE); c.fill(); c.restore()
def comment_ic(c, t):
    s = 1 + 0.04 * math.sin(t * 4); c.save(); c.scale(s, s)
    rr(c, -95, -62, 190, 124, 40); sa(c, PAPER); c.fill_preserve(); sa(c, NAVY); c.set_line_width(6); c.stroke()
    c.move_to(-40, 60); c.line_to(-60, 100); c.line_to(-6, 60); sa(c, PAPER); c.fill_preserve(); sa(c, NAVY); c.stroke()
    for k in range(3): circ(c, -42 + k * 42, 0, 12, BLUE if k == 1 else NAVY)
    c.restore()
def loop_arrow(c, u):
    if u <= 0: return
    c.save(); c.set_dash([16, 14]); sa(c, BLUE); c.set_line_width(7); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.new_sub_path(); c.arc_negative(0, -40, 175, -0.35, -0.35 - 2.6 * ease(u)); c.stroke(); c.set_dash([]); c.restore()
    if u > 0.95:
        a = -0.35 - 2.6; x, y = 175 * math.cos(a), -40 + 175 * math.sin(a)
        c.save(); c.translate(x, y); c.rotate(a - math.pi / 2 + math.pi)
        c.move_to(0, 0); c.line_to(-14, -22); c.line_to(14, -22); c.close_path(); sa(c, BLUE); c.fill(); c.restore()

# ------------------------------------------------------------------ scenes
def build(r):
    A = r.at; S = []
    def add(t0, fn, **kw): S.append(dict(t0=t0, pal="navy", fn=fn, **kw))

    def hook(c, t, sc):
        T(c, "I learned", 130, 360); T(c, "*Russian*", 150, 505)
        T(c, "because of a", 110, 645); T(c, "*stupid joke.*", 130, 780)
        icon(c, 540, 1035 + 6 * math.sin(t * 2), 0.82, one_finger, t, 1.0, r=170)
        HE(c, "למדתי רוסית בגלל בדיחה מטופשת", 1345)
    add(-1, hook)

    def army(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "In the army", 120, 350, a, s)
        a, s = P(t, sc["t0"] + 0.15); icon(c, 540, 700, 0.95 * s, desk, t, ramp(t, sc["t0"], sc["t0"] + 2.6), a=a, r=200)
        a, s = P(t, A(1, "mamram")); icon(c, 890, 520, 0.7 * s, badge, a=a, r=100)
        T(c, "*Mamram,*", 140, 1060, a, s)
        a, s = P(t, A(1, "the idf")); T(c, "the IDF's computing unit", 72, 1180, a, s)
        a, s = P(t, A(1, "computing")); HE(c, "בממר״ם, יחידת המחשב של צה״ל", 1300, a, s)
    add(A(0, end=True) + 0.22, army)

    BUB = [("Привет!", 220, 650, 1), ("Как дела?", 860, 640, -1), ("Давай, давай!", 250, 1010, 1), ("Ну что?", 850, 980, -1), ("Слушай!", 560, 1240, 1), ("Короче...", 230, 1180, 1)]
    def chatter(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Everyone around me", 84, 330, a, s)
        a, s = P(t, A(2, "spoke")); T(c, "spoke *Russian*", 120, 440, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 540, 900, 1.15 * s, bust, NAVY, a=a, r=130)
        for k, (w, x, y, tl) in enumerate(BUB):
            a2, s2 = P(t, sc["t0"] + 0.15 + 0.22 * k)
            icon(c, x, y + 8 * math.sin(t * 2 + k), s2, bubble, w, 48, NAVY if k % 3 == 1 else PAPER, WH if k % 3 == 1 else N255, tl, a=a2)
        a, s = P(t, A(2, "russian")); icon(c, 540, 720, s, lambda c: dtxf(c, "?", 90, B255, 900), a=a)
        a, s = P(t, A(2, "russian") + 0.2); HE(c, "כולם מסביבי דיברו רוסית", 1360, a, s)
    add(A(1, end=True) + 0.05, chatter)

    def finger_sc(c, t, sc):
        a, s = P(t, A(3, "smeshno"))
        if a > 0:
            c.save(); c.translate(540, 400); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.08); rr(c, -330, -110 + 10, 660, 220, 70); c.fill()
            box(c, -330, -110, 660, 220, 70, PAPER, stroke=LINEG, sw=3)
            c.move_to(-30, 108); c.line_to(0, 160); c.line_to(30, 108); c.close_path(); sa(c, PAPER); c.fill(); St.a = old; c.restore()
        RU(c, "Смешно?", 130, 395, a, s)
        a, s = P(t, A(3, "is it funny")); T(c, "Is it *funny?*", 80, 590, a, s)
        rise = ramp(t, sc["t0"], sc["t0"] + 0.5)
        a, s = P(t, sc["t0"]); icon(c, 460, 1000 + 260 * (1 - ease(rise)), 1.2, one_finger, t, rise, a=a, r=170)
        a, s = P(t, A(3, "we say no")); pill(c, "No.", 110, 810, 880, NAVY, WH, a, s)
        a, s = P(t, A(3, "we say no") + 0.15); HE(c, "מצחיק? לא.", 1340, a, s)
    add(A(3, "finger") - 0.4, finger_sc)

    def disco(c, t, sc):
        t0 = sc["t0"]; up = ramp(t, A(4, "wiggles"), A(4, "wiggles") + 0.45)
        sa(c, NAVY, 0.10); c.paint()
        for k in range(9):
            ang = t * 0.8 + k * 2 * math.pi / 9; x = 540 + 420 * math.cos(ang * 1.2 + k); y = 950 + 520 * math.sin(ang + k * 0.7)
            col = DISCO[k % 6]; rg = cairo.RadialGradient(x, y, 0, x, y, 190); rg.add_color_stop_rgba(0, *col[:3], 0.42 * St.a * up + 0.12 * St.a)
            rg.add_color_stop_rgba(1, *col[:3], 0); c.set_source(rg); c.arc(x, y, 190, 0, 2 * math.pi); c.fill()
            c.move_to(540, 330); c.line_to(x - 70, y); c.line_to(x + 70, y); c.close_path(); sa(c, col, 0.07 * up); c.fill()
        a, s = P(t, t0); icon(c, 540, 315 + 4 * math.sin(t * 2), 0.9 * s, disco_ball, t, a=a)
        a, s = P(t, A(4, "diskoteka"))
        if a > 0: card(c, 120, 425, 840, 260, a, 40)
        RU(c, "А дискотека?", 116, 512, a, s)
        a2, s2 = P(t, A(4, "and the disco")); T(c, "And the *disco?*", 80, 622, a2 * (a > 0), s2)
        bob = 16 * abs(math.sin(math.pi * t / BEAT)) * up
        icon(c, 540, 940 - bob, 1.08, dancing_hand, t, up, a=1.0, rot=0.05 * up * math.sin(math.pi * t / BEAT), r=175)
        a, s = P(t, A(5, "a total")); pill(c, "A total *dad joke*", 76, 540, 1300, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, A(4, "and the disco") + 0.2)
        if a > 0: HE(c, "ודיסקוטק? בדיחת אבא קלאסית", 1398, a, s, 58)
    add(A(4) - 0.12, disco)

    def laugh(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "They were", 96, 340, a, s)
        T(c, "*crying laughing*", 110, 455, a, s)
        for k, (x, y, col) in enumerate([(230, 800, SLATE), (850, 800, SLATE), (380, 760, hx("#7B8DAA")), (700, 760, hx("#7B8DAA"))]):
            a2, s2 = P(t, sc["t0"] + 0.1 * k); jig = 10 * abs(math.sin(t * 14 + k))
            icon(c, x, y - jig, 0.8 * s2, bust, col, 0.07 * math.sin(t * 16 + k * 1.3), a=a2)
        for k, (x, y) in enumerate([(200, 600), (880, 590), (420, 560), (660, 600)]):
            a2, s2 = P(t, sc["t0"] + 0.3 + 0.15 * k)
            icon(c, x + 5 * math.sin(t * 20 + k), y, s2, bubble, "ХА ХА", 44, PAPER, N255, 1 if x < 540 else -1, a=a2)
        a, s = P(t, A(5, "and i didn't")); icon(c, 540, 1000, s, bust, NAVY, a=a, r=120)
        if a > 0: icon(c, 540, 820 - 6 * math.sin(t * 3), s, lambda c: dtxf(c, "?", 100, B255, 900), a=a)
        pill(c, "And I didn't get it.", 72, 540, 1205, NAVY, WH, a, s)
        a, s = P(t, A(5, "and i didn't") + 0.2); HE(c, "הם בכו מצחוק. ואני לא הבנתי", 1335, a, s)
    add(A(5, "but they") - 0.12, laugh)

    FLY = [("слово", (-120, 560)), ("смешно", (1200, 620)), ("друг", (-140, 1150)), ("слушай", (1220, 1180)), ("давай", (-120, 820)), ("привет", (1200, 900))]
    def words(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "I wanted *in.*", 130, 360, a, s)
        a, s = P(t, sc["t0"] + 0.15); tts = [A(6, "asked"), A(6, "words"), A(7, "repeated"), A(7, "shadowed"), A(7, "built"), A(7, "sentences")]
        landed = sum(1 for x in tts if t > x + 0.7) * 2
        icon(c, 540, 790, 1.0 * s, notebook, landed, a=a, r=180)
        for k, ((w, (fx, fy)), t1) in enumerate(zip(FLY, tts)):
            u = (t - t1) / 0.75
            if u < 0 or u > 1.15: continue
            ue = ease(min(1, u)); tx_, ty_ = 540 + (-140 if k % 2 == 0 else 140), 760
            cx, cy = (fx + tx_) / 2, min(fy, ty_) - 260
            x = (1 - ue) ** 2 * fx + 2 * (1 - ue) * ue * cx + ue ** 2 * tx_; y = (1 - ue) ** 2 * fy + 2 * (1 - ue) * ue * cy + ue ** 2 * ty_
            icon(c, x, y, lerp(1.1, 0.45, ue), word_card, w, a=1 - ramp(u, 0.85, 1.12), rot=(1 - ue) * (0.5 if k % 2 else -0.5))
        steps = [("Ask", A(6, "asked"), 230, 1090), ("Repeat", A(7, "repeated"), 520, 1090), ("Shadow", A(7, "shadowed"), 830, 1090), ("Build sentences", A(7, "built"), 540, 1210)]
        for k, (w, tt, x, y) in enumerate(steps):
            a, s = P(t, tt); pill(c, w, 64, x, y, NAVY if k == 3 else PAPER, WH if k == 3 else N255, a, s, outline=None if k == 3 else LINEG)
        a, s = P(t, A(7, "built") + 0.25); HE(c, "ביקשתי מילים, חזרתי, ובניתי משפטים", 1335, a, s)
    add(A(6) - 0.12, words)

    def dict_sc(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "A little", 110, 340, a, s)
        a, s = P(t, A(8, "dictionary")); T(c, "*dictionary*", 130, 465, a, s)
        tth = A(9, "threw"); u = (t - tth) / 0.9
        a, s = P(t, A(8, "little"))
        if u < 0:
            icon(c, 540, 790 + 8 * math.sin(t * 2), 1.05 * s, dictionary, a=a, r=160)
        elif u < 1.3:
            x = 540 + 620 * u; y = 790 - 760 * u + 520 * u * u
            for k in range(1, 4):
                uk = max(0, u - k * 0.06); circ(c, 540 + 620 * uk, 790 - 760 * uk + 520 * uk * uk, 14 - 3 * k, BLUE, 0.35)
            icon(c, x, y, 1.05 * (1 - 0.35 * u), dictionary, rot=u * 7)
        if u > 0:
            c.save(); c.set_dash([14, 16]); sa(c, BLUE, 0.45 * (1 - ramp(u, 1.4, 2.2))); c.set_line_width(5); c.move_to(540, 790)
            for j in range(1, 21):
                uu = min(u, 1.1) * j / 20; c.line_to(540 + 620 * uu, 790 - 760 * uu + 520 * uu * uu)
            c.stroke(); c.set_dash([]); c.restore()
        a, s = P(t, A(9, "studying")); pill(c, "Studying, not *listening*", 66, 540, 1085, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, tth); pill(c, "Threw it away", 84, 540, 1215, NAVY, WH, a, s)
        a, s = P(t, A(9, "listening") + 0.1); HE(c, "למדתי את המילון במקום להקשיב", 1340, a, s)
    add(A(8) - 0.12, dict_sc)

    def listen(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Listen.", 120, 345, a, s, x=315)
        a, s = P(t, A(10, "repeated")); T(c, "*Repeat.*", 120, 345, a, s, x=775)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 470, 820, 1.0 * s, profile_head, a=a, r=160)
        a2, _ = P(t, A(10, "listened")); icon(c, 330, 780, 1.0, waves, t, a=a2 * a)
        for k in range(3):
            x = 90 + k * 34; line(c, [(x, 780 - 50 + 18 * k), (x, 780 + 50 - 18 * k)], BLUE, 8, a2 * a * (0.5 + 0.5 * math.sin(t * 9 + k)))
        a, s = P(t, A(10, "talked")); icon(c, 770, 560, s, bubble, "Сам с собой", 48, NAVY, WH, -1, a=a)
        pill(c, "Talk to *myself*", 84, 540, 1110, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, A(10, "in russian")); T(c, "in *Russian*", 96, 1230, a, s)
        a, s = P(t, A(10, "in russian") + 0.15); HE(c, "הקשבתי, חזרתי, ודיברתי עם עצמי", 1345, a, s)
    add(A(10) - 0.12, listen)

    BOOKS = [("Чебурашка", None, BLUE, motif_stars, "cheburashka", "Cheburashka", 225), ("Доктор", "Айболит", NAVY, motif_heart, "aybolit", "Doctor Aybolit", 540),
             ("Баба-Яга", None, SLATE, motif_hut, "baba yaga", "Baba Yaga", 855)]
    def books(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "*Night shifts*", 130, 345, a, s)
        a, s = P(t, A(11, "children's")); T(c, "Children's books", 84, 465, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 900, 600, 0.8 * s, moon, a=a)
        for k, (x, y) in enumerate([(130, 590), (210, 640), (780, 560), (990, 650)]):
            circ(c, x, y, 5, NAVY, a * (0.4 + 0.4 * math.sin(t * 3 + k)))
        a, s = P(t, A(11, "read")); icon(c, 540, 640, s, lamp, a=a * 0.9)
        for k, (ti, sub, col, mot, key, lab, x) in enumerate(BOOKS):
            a, s = P(t, A(11, "children's") + 0.15 * k); tk = A(11, key); hi = ramp(t, tk - 0.05, tk + 0.25) * (1 - ramp(t, tk + 1.1, tk + 1.4)) if k < 2 else ramp(t, tk - 0.05, tk + 0.25)
            if hi > 0.01: c.save(); old = St.a; St.a *= a; box(c, x - 146, 940 - 30 * hi - 202, 292, 404, 22, (1, 1, 1, 1), 0.0, stroke=BLUE, sw=6 * hi); St.a = old; c.restore()
            icon(c, x, 940 - 30 * hi + 6 * math.sin(t * 1.6 + k), (1.0 + 0.05 * hi) * s, book_cover, ti, sub, col, mot, t, a=a, rot=(-0.04, 0.0, 0.04)[k] * (1 - hi), r=150)
            T(c, lab, 40, 1170, a, s, x=x, w=800, maxw=300, col=B255 if hi > 0.5 else N255)
        a, s = P(t, A(11, "baba yaga") + 0.2); HE(c, "במשמרות לילה קראתי ספרי ילדים", 1290, a, s)
    add(A(11) - 0.12, books)

    def readwrite(c, t, sc):
        a, s = P(t, sc["t0"]); pill(c, "A year or two later", 64, 540, 340, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, A(12, "i could")); T(c, "I could *read*", 120, 480, a, s); T(c, "*and write*", 120, 600, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 540, 915, s, paper, ["Я могу читать", "и писать!"], ramp(t, sc["t0"] + 0.2, sc["t0"] + 2.2), t, a=a, r=190)
        a, s = P(t, A(12, "read and")); HE(c, "שנה או שנתיים אחר כך, קראתי וכתבתי", 1265, a, s)
    add(A(12) - 0.3, readwrite)

    def key(c, t, sc):
        ts = A(13, "it started")
        a, s = P(t, sc["t0"]); pill(c, "Deciding to study", 72, 540, 335, PAPER, N255, a, s, outline=LINEG, strike=ramp(t, A(13, "study"), A(13, "study") + 0.45))
        a, s = P(t, ts); T(c, "It started with", 84, 465, a, s)
        icon(c, 540, 790, 0.82 * s, bust, NAVY, a=a, r=130)
        a2, s2 = P(t, A(13, "talking")); icon(c, 800, 575, s2, bubble, "Сам с собой", 46, PAPER, N255, -1, a=a2)
        if a2 > 0: c.save(); c.translate(540, 790); old = St.a; St.a *= a2; loop_arrow(c, ramp(t, A(13, "talking"), A(13, "talking") + 0.9)); St.a = old; c.restore()
        T(c, "Talking to", 120, 1010, a2, s2); T(c, "*myself*", 140, 1135, a2, s2)
        a, s = P(t, A(13, "myself")); T(c, "in *Russian*", 84, 1250, a, s)
        a, s = P(t, A(13, "talking") + 0.3); HE(c, "זה התחיל כשדיברתי עם עצמי ברוסית", 1355, a, s, 60)
    add(A(13) - 0.12, key)

    def cta(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Want to do the same", 84, 345, a, s); T(c, "in *English?*", 120, 460, a, s)
        a, s = P(t, A(14, "comment")); T(c, "Comment", 110, 650, a, s)
        a, s = P(t, A(14, "speaker"))
        if a > 0:
            c.save(); c.translate(540, 850); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.14); rr(c, -400, -120 + 14, 800, 240, 60); c.fill()
            box(c, -400, -120, 800, 240, 60, NAVY); rr(c, -386, -106, 772, 212, 50); sa(c, BLUE); c.set_line_width(5); c.stroke()
            St.a = old; c.restore()
        T(c, "SPEAKER", 140, 856, a, s, col=WH)
        a2, s2 = P(t, A(14, "speaker") + 0.25); icon(c, 540, 1080, 0.8 * s2, comment_ic, t, a=a2, r=110)
        HE(c, "כתבו ספיקר בתגובות", 1250, a2, s2, 68)
    add(A(14) - 0.12, cta)
    return S

if __name__ == "__main__":
    main("/home/claude/russian_army", (), build, "warm", 7, tail=2.6)
