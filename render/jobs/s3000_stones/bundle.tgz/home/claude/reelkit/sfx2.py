"""Procedural SFX and music beds for the narrated v2 reels (emails_story, us_trip, israel_trail). All float64, 48 kHz.
Synthesised here (no samples): whoosh, meow, gravel footsteps, birds, wind, waves, soft crowd murmur, road rumble, jet pass,
three original music beds. Sample based (CC0, Kenney, copied into each reel's sfx_src): keyboard clicks (UI Audio), glass ding
(Interface Sounds), car engine loop (Starter Kit Racing)."""
import numpy as np
from scipy.signal import fftconvolve
from narrate import SR, bp, lp, hp, norm, tt, load

rng = np.random.default_rng(23)
def env(n, a, r):
    t = np.arange(n) / SR; d = n / SR; return np.minimum(1, t / max(a, 1e-4)) * np.minimum(1, np.maximum(0, d - t) / max(r, 1e-4))
def room(x, t60=0.5, mix=0.2, seed=3):
    r = np.random.default_rng(seed); n = int(t60 * SR); ir = r.standard_normal(n) * np.exp(-6.9 * np.arange(n) / n)
    ir = lp(ir, 5000); ir /= np.sqrt((ir ** 2).sum()); y = fftconvolve(x, ir)[:len(x)]; return x * (1 - mix) + y * mix
def saw(ph): return 2 * ((ph / (2 * np.pi)) % 1.0) - 1
def sweep(nz, fc, lo=150, hi=6000, nb=10, q=0.35):
    cs = np.geomspace(lo, hi, nb); y = np.zeros(len(nz)); wsum = np.zeros(len(nz)) + 1e-9
    for c in cs:
        w = np.exp(-(np.log(np.maximum(fc, 1) / c) / q) ** 2); y += w * bp(nz, c / 1.35, min(c * 1.35, SR / 2 - 100)); wsum += w
    return y / np.sqrt(wsum)
def place(n, events):
    """sum (t0, mono array, gain) into a mono buffer of n samples"""
    out = np.zeros(n)
    for t0, x, g in events:
        i = int(t0 * SR); j = min(n, i + len(x))
        if 0 <= i < n and j > i: out[i:j] += g * x[:j - i]
    return out

# ------------------------------------------------------------------ one-shots
def whoosh(d=0.55, up=True):
    """airy swish: band sweep of noise, quick swell, slight stereo travel"""
    t = tt(d); u = t / d; nz = rng.standard_normal(len(t))
    fc = (700 + 3800 * u ** 1.2) if up else (4200 - 3400 * u)
    y = sweep(nz, fc, 400, 7000, 9, 0.3); amp = np.sin(np.pi * np.minimum(1, u)) ** 1.6
    x = norm(y * amp); pan = np.clip(-0.5 + u, -0.5, 0.5)
    return np.stack([x * (1 - pan), x * (1 + pan)]) / 1.5
def meow(f0=720, d=0.55):
    """tiny kitten 'mew': rising then falling harmonic source through formants that glide i > a > u"""
    t = tt(d); u = t / d
    f = f0 * (1 + 0.35 * np.sin(np.pi * np.minimum(1, u * 1.25)) - 0.25 * u ** 2) * (1 + 0.01 * np.sin(2 * np.pi * 6 * t))
    ph = 2 * np.pi * np.cumsum(f) / SR; src = sum(np.sin(k * ph) * (0.75 ** k) for k in range(1, 16))
    src += 0.06 * rng.standard_normal(len(t))
    F1 = 900 + 500 * np.sin(np.pi * np.minimum(1, u * 1.1)) - 300 * u; F2 = 2300 - 900 * u
    y = sweep(src, F1, 500, 2200, 8, 0.25) + 0.6 * sweep(src, F2, 1200, 3800, 8, 0.25)
    e = np.minimum(1, t / 0.05) * np.exp(-((u - 0.35) / 0.45) ** 2 * 2.2)
    return norm(room(y * e, 0.25, 0.12))
_ken_clicks = None
def key_clicks(folder):
    global _ken_clicks
    if _ken_clicks is None: _ken_clicks = [norm(load(f"{folder}/sfx_src/click{k}.wav")) for k in range(1, 6)]
    return _ken_clicks
def typing(n, times, folder, gain=1.0):
    """soft keyboard: one Kenney click per typed character (random click, pitch and level), low-passed so it stays soft"""
    cl = key_clicks(folder); ev = []
    for k, t0 in enumerate(times):
        c = cl[rng.integers(0, 5)]; rate = rng.uniform(0.85, 1.15)
        c = np.interp(np.arange(0, len(c) - 1, rate), np.arange(len(c)), c)
        ev.append((t0 + rng.uniform(-0.012, 0.012), c, gain * rng.uniform(0.55, 1.0)))
    x = place(n, ev); return lp(hp(x, 300), 6500)
def ding(folder): return norm(load(f"{folder}/sfx_src/glass_001.wav"))
def jet_pass(d=1.8):
    t = tt(d); u = t / d; nz = rng.standard_normal(len(t))
    fc = 500 + 2600 * np.exp(-((u - 0.45) / 0.2) ** 2); y = sweep(nz, fc, 300, 5000)
    amp = np.exp(-((u - 0.45) / 0.24) ** 2); rumble = lp(nz, 220) * amp
    whine = 0.05 * np.sin(2 * np.pi * np.cumsum(2400 - 500 * u) / SR) * amp
    x = norm(y * amp) + 0.5 * norm(rumble) + whine; pan = np.clip((u - 0.1) * 1.4 - 0.7, -0.8, 0.8)
    return np.stack([x * (1 - pan), x * (1 + pan)]) / 1.6

# ------------------------------------------------------------------ car
def engine_loop(folder, d, rate_curve=None):
    """Kenney racing engine loop, looped seamlessly (crossfaded), resampled by rate_curve(u) (1 = original pitch)"""
    x = load(f"{folder}/sfx_src/kenney_racing_engine.ogg"); L = len(x); xf = int(0.25 * SR)
    loop = x[:L - xf].copy(); loop[:xf] = loop[:xf] * np.linspace(0, 1, xf) + x[L - xf:] * np.linspace(1, 0, xf)
    n = int(d * SR); u = np.arange(n) / max(1, n - 1); r = rate_curve(u) if rate_curve else np.ones(n)
    pos = np.cumsum(r) % len(loop); return np.interp(pos, np.arange(len(loop)), loop)
def road_bed(folder, d, seed=4):
    """engine hum (Kenney loop pitched down, low-passed) + road rumble + tyre hiss, slow swells"""
    r = np.random.default_rng(seed); t = tt(d); n = len(t)
    eng = lp(engine_loop(folder, d, lambda u: 0.62 + 0.03 * np.sin(2 * np.pi * u * d / 5.0)), 900)
    br = np.cumsum(r.standard_normal(n)); br = hp(br, 25); br /= np.abs(br).max() + 1e-9
    rumble = lp(br, 160); hiss = bp(r.standard_normal(n), 1200, 5000) * 0.25
    sw = 0.85 + 0.15 * np.sin(2 * np.pi * t / 3.7)
    x = norm(eng) * 0.8 + norm(rumble) * 0.7 + norm(hiss) * 0.25
    return norm(x * sw * env(n, 0.5, 0.7))
def rev(folder, d=2.2):
    """convertible rev: blip, blip, then a pull away (Kenney loop resampled along a rev curve, plus exhaust burble)"""
    def curve(u):
        b1 = np.exp(-((u - 0.12) / 0.06) ** 2); b2 = np.exp(-((u - 0.32) / 0.07) ** 2)
        pull = np.clip((u - 0.45) / 0.55, 0, 1)
        return 0.7 + 0.75 * b1 + 0.9 * b2 + 0.9 * pull ** 0.7 - 0.25 * pull ** 3
    x = engine_loop(folder, d, curve); t = tt(d); u = t / d
    burble = lp(rng.standard_normal(len(t)), 300) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 34 * t))) * 0.35
    y = lp(x, 3500) + burble * (1 - u)
    e = np.minimum(1, t / 0.03) * np.minimum(1, (d - t) / 0.6)
    return norm(room(y * e, 0.35, 0.12))

# ------------------------------------------------------------------ trail
def gravel_steps(times, n, seed=9):
    """footsteps on gravel: each step is a short low thud plus a dense crunch of tiny grains (heel then toe)"""
    r = np.random.default_rng(seed); out = np.zeros(n)
    for t0 in times:
        for part, (off, dur, g) in enumerate(((0.0, 0.12, 1.0), (0.07, 0.16, 0.8))):
            m = int(dur * SR); w = np.arange(m) / SR; i = int((t0 + off) * SR)
            if i < 0 or i + m >= n: continue
            grains = np.zeros(m)
            for j in r.integers(0, m - 240, int(dur * 900)):
                L_ = r.integers(40, 220); grains[j:j + L_] += r.uniform(-1, 1) * np.exp(-np.arange(L_) / (L_ / 4))
            crunch = bp(grains, 1200, 7000) * np.exp(-w * 18) * (1 - np.exp(-w * 400))
            thud = np.sin(2 * np.pi * 85 * w) * np.exp(-w * 45) * (0.8 if part == 0 else 0.3)
            out[i:i + m] += g * r.uniform(0.75, 1.0) * (crunch * 1.2 + thud * 0.5)
    return lp(out, 9000)
def step_times(t0, t1, every=0.52, jitter=0.03, seed=2):
    r = np.random.default_rng(seed); out = []; t = t0
    while t < t1: out.append(t + r.uniform(-jitter, jitter)); t += every
    return out
def birds(d, density=1.6, seed=31):
    """light birdsong: chirps (fast FM sweeps) and short trills, spread in stereo"""
    r = np.random.default_rng(seed); n = int(d * SR); L = np.zeros(n); R = np.zeros(n); k = r.uniform(0.1, 0.5)
    while k < d - 0.5:
        sp = r.integers(0, 3); f0 = [3200, 4200, 2600][sp]; pan = r.uniform(-0.7, 0.7)
        notes = r.integers(2, 6) if sp != 2 else r.integers(5, 10); st = k
        for q in range(notes):
            m = int(r.uniform(0.04, 0.09) * SR); w = np.arange(m) / SR; u = w / w[-1]
            f = f0 * (1 + r.uniform(0.15, 0.45) * np.sin(np.pi * u) * r.choice([-1, 1])) + 400 * u
            s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * u) ** 1.5
            i = int(st * SR)
            if i + m < n: L[i:i + m] += s * (1 - pan); R[i:i + m] += s * (1 + pan)
            st += m / SR + r.uniform(0.02, 0.07)
        k = st + r.exponential(1 / density)
    x = np.stack([L, R]); x *= env(n, 0.6, 0.8); return x / (np.abs(x).max() + 1e-9)
def wind(d, seed=5):
    r = np.random.default_rng(seed); t = tt(d); nz = r.standard_normal(len(t))
    g = 0.5 + 0.5 * np.sin(2 * np.pi * t / 3.1 + 1) * np.sin(2 * np.pi * t / 1.7)
    fc = 350 + 500 * (0.5 + 0.5 * np.sin(2 * np.pi * t / 2.3)) + 300 * g
    y = sweep(nz, fc, 200, 1800, 8, 0.3); howl = 0.15 * np.sin(2 * np.pi * np.cumsum(fc * 1.3) / SR) * g
    x = norm(y * (0.35 + 0.65 * g) + howl) * env(len(t), 0.7, 0.9); xr = np.roll(x, int(0.013 * SR))
    return np.stack([x, xr])
def waves(d, seed=6):
    r = np.random.default_rng(seed); t = tt(d); nz = r.standard_normal(len(t)); b = np.cumsum(nz); b = hp(b, 30); b /= np.abs(b).max()
    sw = 0.25 + 0.75 * (0.5 - 0.5 * np.cos(2 * np.pi * (t / 4.0 + 0.1))) ** 2
    x = lp(b, 500) * sw + 0.45 * bp(nz, 1200, 4500) * sw ** 2
    x = norm(x * env(len(t), 0.8, 1.0)); return np.stack([x, np.roll(x, int(0.02 * SR))])
def crowd_soft(d, voices=10, seed=100):
    """distant soft murmur of a crowd (synthetic babble, no words), low-passed, with a faint open-air reverb"""
    t = tt(d); out = np.zeros(len(t))
    VOW = [(730, 1090), (530, 1840), (270, 2290), (570, 840), (440, 1020), (300, 870)]
    for v in range(voices):
        r = np.random.default_rng(seed + v); f0 = r.uniform(95, 220)
        cont = f0 * (1 + 0.12 * np.sin(2 * np.pi * r.uniform(0.2, 0.6) * t + r.uniform(0, 6)))
        src = saw(2 * np.pi * np.cumsum(cont) / SR); syl = np.zeros(len(t)); k = r.uniform(0, 0.6)
        while k < d:
            m = int(r.uniform(0.1, 0.25) * SR); i = int(k * SR)
            if i + m < len(t): syl[i:i + m] += np.hanning(m)
            k += r.uniform(0.15, 0.35) + (r.uniform(0.3, 0.9) if r.random() < 0.18 else 0)
        k_ = np.arange(len(t)) // int(0.18 * SR); idx = r.integers(0, len(VOW), k_.max() + 2)
        F1 = lp(np.array([VOW[i][0] for i in idx])[k_].astype(float), 30, 1)
        y = sweep(src, np.maximum(F1, 220), 220, 1000, 6, 0.3)
        out += norm(y * syl) * (0.5 + 0.5 * r.random())
    out = lp(out, 2200) * env(len(t), 0.8, 1.0)
    return norm(room(out, 1.2, 0.35))

# ------------------------------------------------------------------ music
def hz(m): return 440 * 2 ** ((m - 69) / 12)
def ks(f, d=0.8, bright=0.5, seed=0):
    """Karplus-Strong string"""
    r = np.random.default_rng(seed); N = max(2, int(SR / f)); n = int(d * SR)
    buf = r.uniform(-1, 1, N); out = np.zeros(n); a = 0.25 + 0.5 * bright * 0.5
    for i in range(n):
        v = buf[i % N]; out[i] = v; buf[i % N] = 0.996 * (a * v + (1 - a) * buf[(i + 1) % N])
    t = np.arange(n) / SR; return out * np.minimum(1, t / 0.002)
_ks = {}
def ksc(m, d=0.8, bright=0.5):
    k = (m, d, bright)
    if k not in _ks: _ks[k] = ks(hz(m), d, bright, seed=m)
    return _ks[k]
class Bus:
    def __init__(s, dur): s.n = int(dur * SR); s.L = np.zeros(s.n); s.R = np.zeros(s.n)
    def put(s, sig, st, g, pan=0.0):
        i = int(st * SR)
        if i >= s.n or i < 0: return
        j = min(s.n, i + len(sig)); s.L[i:j] += g * (1 - pan) * sig[:j - i]; s.R[i:j] += g * (1 + pan) * sig[:j - i]
    def out(s, fade_in=0.3, fade_out=1.8, rev=(0.9, 0.18)):
        x = np.stack([room(s.L, rev[0], rev[1], 1), room(s.R, rev[0], rev[1], 2)]); n = s.n; i = np.arange(n)
        x *= np.minimum(1, i / (fade_in * SR)) * np.minimum(1, (n - i) / (fade_out * SR)); return x / (np.abs(x).max() + 1e-9)
def kick(g=1.0):
    t3 = tt(0.3); f = 100 * np.exp(-t3 * 18) + 48; return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t3 * 13) * g
def shaker():
    m = int(0.05 * SR); return hp(rng.standard_normal(m), 6000) * np.exp(-np.arange(m) / SR * 75)
def brush():
    m = int(0.16 * SR); return bp(rng.standard_normal(m), 1500, 6000) * np.exp(-np.arange(m) / SR * 24)

def music_playful(dur, end_at, bpm=112):
    """emails: light marimba + pizzicato bounce in F, F Dm Bb C, soft kick and shaker; resolves on the end card"""
    B = Bus(dur); beat = 60 / bpm; bar = 4 * beat; prog = [(41, [65, 69, 72]), (38, [62, 65, 69]), (34, [62, 65, 70]), (36, [64, 67, 72])]
    def marimba(m, d=0.5):
        t = tt(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 40)) * np.exp(-t * 8) * np.minimum(1, t / 0.002)
    mel = [77, None, 76, 77, 79, None, 77, None, 74, None, 72, 74, 76, None, None, None]
    for b in range(int(dur / bar) + 1):
        st = b * bar; root, ch = prog[b % 4]
        if st >= end_at:
            for k, m in enumerate([29, 41] + [65, 69, 72, 77]): B.put(marimba(m, 1.6) if m > 50 else ksc(m, 1.6, 0.4), st + 0.02 * k, 0.4 if m > 50 else 0.6)
            break
        for off, mm in ((0, root), (1.5, root + 7), (2, root + 12), (3, root + 7)): B.put(ksc(mm - 12 if mm > 45 else mm, 0.5, 0.35), st + off * beat, 0.55)
        pat = [0, 1, 2, 1, 2, 1, 0, 2]
        for q in range(8): B.put(marimba(ch[pat[q]] + 12 * (q % 4 == 3), 0.45), st + q * beat / 2, 0.16 if q % 2 else 0.2, pan=0.3 * (1 if q % 2 else -1))
        if b >= 2:
            ph = mel[(b % 2) * 8:(b % 2) * 8 + 8]
            for q, m in enumerate(ph):
                if m: B.put(ksc(m, 0.4, 0.7), st + q * beat / 2, 0.16, pan=-0.2)
        if b >= 1:
            for q in (0, 2): B.put(kick(), st + q * beat, 0.35)
            for q in range(8): B.put(shaker(), st + q * beat / 2, 0.05 if q % 2 else 0.035, 0.35)
    return B.out(0.2, 0.6, (0.6, 0.15))

def music_roadtrip(dur, end_at, bpm=104, lift_at=None):
    """us_trip: warm, upbeat road-trip bed in G: strummed steel-string (Karplus-Strong) G D Em C, bass, kick/brush backbeat,
    tambourine 8ths, a whistle-like lead from bar 5 and a lift for the Alfa finale; resolves on G at the end card"""
    B = Bus(dur); beat = 60 / bpm; bar = 4 * beat
    prog = [(43, [55, 59, 62, 67, 71, 79]), (38, [50, 57, 62, 66, 69, 74]), (40, [52, 59, 64, 67, 71, 76]), (36, [48, 55, 60, 64, 67, 72])]
    strum = [(0, 1, 1.0), (1, 1, 0.7), (1.5, -1, 0.55), (2.5, -1, 0.6), (3, 1, 0.75), (3.5, -1, 0.55)]   # D, D, U, U, D, U
    lead = [79, None, 78, 79, 81, None, 79, 76, 74, None, 76, None, 79, None, None, None]
    def whistle(m, d):
        t = tt(d); f = hz(m) * (1 + 0.006 * np.sin(2 * np.pi * 5.5 * t) * np.minimum(1, t / 0.2))
        s = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.08 * np.sin(4 * np.pi * np.cumsum(f) / SR)
        return (s + 0.04 * bp(rng.standard_normal(len(t)), 1500, 5000)) * env(len(t), 0.04, 0.12)
    for b in range(int(dur / bar) + 1):
        st = b * bar; root, ch = prog[b % 4]; lift = lift_at is not None and st >= lift_at
        if st >= end_at:
            for k, m in enumerate([31, 43] + prog[0][1]): B.put(ksc(m, 2.4, 0.5), st + 0.025 * k, 0.5 if m < 50 else 0.28)
            break
        for off, dirn, v in strum:
            notes = ch if dirn > 0 else ch[::-1][:4]
            for k, m in enumerate(notes): B.put(ksc(m, 0.7, 0.55), st + off * beat + 0.012 * k, 0.11 * v * (1.15 if lift else 1), pan=0.25)
        for off, mm in ((0, root - 12), (2, root - 12 + 7), (2.5, root - 12 + 12)): B.put(ksc(mm + 12, 0.6, 0.3) * 0.5 + ksc(mm + 24, 0.6, 0.2) * 0.2, st + off * beat, 0.9)
        if b >= 1:
            for q in (0, 2): B.put(kick(), st + q * beat, 0.42)
            if lift: B.put(kick(0.7), st + 2.5 * beat, 0.3)
            for q in (1, 3): B.put(brush(), st + q * beat, 0.22)
            for q in range(8): B.put(shaker(), st + q * beat / 2, 0.06 if q % 2 else 0.04, -0.35)
        if b >= 4:
            ph = lead[(b % 2) * 8:(b % 2) * 8 + 8]
            for q, m in enumerate(ph):
                if m: B.put(whistle(m + (12 if lift else 0) * 0, beat * 0.9), st + q * beat / 2, 0.07, pan=-0.15)
    return B.out(0.3, 0.8, (0.8, 0.16))

def music_cinematic(dur, end_at, lift_at, bpm=84):
    """israel_trail: inspiring, light cinematic bed in D: warm string pad, piano-like arpeggio, low string pulse, soft
    timpani swells on section changes, a lift with fuller drums and a high string line for the last day; resolves on D"""
    B = Bus(dur); beat = 60 / bpm; bar = 4 * beat
    prog = [(38, [62, 66, 69, 74]), (35, [62, 66, 71, 74]), (31, [62, 67, 71, 74]), (33, [61, 64, 69, 73])]   # D Bm G A
    def piano(m, d=1.4):
        t = tt(d); f = hz(m); return (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(4 * np.pi * f * t) * np.exp(-t * 3) + 0.12 * np.sin(6 * np.pi * f * t) * np.exp(-t * 6)) * np.exp(-t * 2.6) * np.minimum(1, t / 0.003)
    def pad(ch, d, bright=1400):
        t = tt(d); x = sum(sum(saw(2 * np.pi * hz(m) * (1 + dt) * t + rng.uniform(0, 6)) for dt in (-0.005, 0.0, 0.005)) for m in ch)
        return lp(x, bright, 2) * np.minimum(1, t / 0.8) * np.minimum(1, (d - t) / 0.8)
    def timp(g=1.0):
        t = tt(1.6); f = 73 * (1 + 0.04 * np.exp(-t * 6)); x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 2.2)
        return (x + 0.2 * lp(rng.standard_normal(len(t)), 300) * np.exp(-t * 10)) * g
    hi = [81, 78, 76, 74, 76, 78, 81, 83]
    for b in range(int(dur / bar) + 1):
        st = b * bar; root, ch = prog[b % 4]; lift = st >= lift_at
        if st >= end_at:
            B.put(pad([50, 57, 62, 66, 69, 74], 4.0, 2000), st, 0.03)
            for k, m in enumerate([38, 50, 62, 66, 69, 74, 78]): B.put(piano(m, 3.0), st + 0.05 * k, 0.22)
            B.put(timp(0.6), st, 0.5)
            break
        B.put(pad([m - 12 for m in ch] + ch[:2], bar + 0.8, 1800 if lift else 1200), st, 0.020 if b else 0.012)
        for q in range(8):
            m = (ch + [ch[1] + 12])[[0, 1, 2, 3, 4, 3, 2, 1][q]]
            B.put(piano(m + 12, 1.2), st + q * beat / 2, 0.09 if q % 2 else 0.12, pan=0.25 * (1 if q % 2 else -1))
        t_ = tt(beat * 0.9)
        for q in range(4 if b >= 1 else 0):
            s = lp(saw(2 * np.pi * hz(root) * t_) + 0.5 * saw(2 * np.pi * hz(root + 12) * t_), 600) * env(len(t_), 0.02, 0.2)
            B.put(s, st + q * beat, 0.08 if not lift else 0.11)
        if b % 4 == 0 and b: B.put(timp(0.8), st, 0.5)
        if lift:
            for off, g in ((0, 0.45), (1.5, 0.2), (2, 0.35), (3.5, 0.18)): B.put(kick(1.0), st + off * beat, g)
            for q in range(8): B.put(shaker(), st + q * beat / 2, 0.035, 0.3)
            for q, m in enumerate(hi[(b % 2) * 4:(b % 2) * 4 + 4]):
                B.put(pad([m], beat * 1.05, 2600), st + q * beat, 0.05, pan=-0.2)
    return B.out(1.0, 1.2, (1.6, 0.26))
