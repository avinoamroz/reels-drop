"""Reel: English is not math. (@expressenglishcom, collab @noamroz__)  usage: python3 not_math.py [--preview [t,..]]"""
import sys; sys.path.insert(0, "/home/claude/reelkit")
from draw import *

def speaker_pill(c, t, t0, y):
    a, s = pop(t, t0)
    if a > 0:
        pw = font(130, 900).getlength("SPEAKER") + 110; c.save(); c.translate(540, y); c.scale(s, s)
        box(c, -pw / 2, -95, pw, 190, 95, INK, a, stroke=YEL, sw=8); c.restore()
    tx(c, "SPEAKER", 130, 540, y + 3, a=a, sc=s, col=Y255, shadow=False)

def build(r):
    A = r.at; S = []
    def add(t0, pal, fn): S.append(dict(t0=t0, pal=pal, fn=fn))
    def hook(c, t, sc):
        tx(c, "English is", 130, 540, 380); tx(c, "*NOT* math", 150, 540, 525)
        icon(c, 540, 830, 1.0, chalkboard, t, ramp(t, A(0, "not math"), A(0, "not math") + 0.6), r=170)
        a, s = pop(t, A(0, "physics")); icon(c, 860, 700, 0.9 * s, atom, t, a=a)
        if a > 0: stamp(c, t, A(0, "physics") + 0.25, 860, 700, 0.75)
        chip(c, "Not physics either", 72, 540, 1115, PURPLE, a=a, sc=s)
        he(c, "אנגלית זה לא מתמטיקה", 540, 1255)
    add(-1, "coral", hook)
    def taught(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "How we were", 120, 540, 380, a=a, sc=s)
        a, s = pop(t, A(1, "taught")); tx(c, "*taught* it", 120, 540, 505, a=a, sc=s)
        for k, (w, col, ph) in enumerate([("Rules", SKYC, "rules"), ("Formulas", PURPLE, "formulas"), ("Analyze first", ORANGE, "analyze")]):
            a, s = pop(t, A(1, ph)); c.save(); chip(c, w, 84, 540 + (k - 1) * 60, 720 + 140 * k, col, a=a, sc=s); c.restore()
        a, s = pop(t, A(1, "analyze") + 0.4); he(c, "ככה לימדו אותנו: חוקים ונוסחאות", 540, 1180, a=a, sc=s)
    add(A(1) - 0.12, "teal", taught)
    def split(c, t, sc):
        a, s = pop(t, sc["t0"], s0=0.6)
        if a > 0:
            box(c, 90, 290, 900, 520, 50, hx("#1C7FDB"), a * 0.9, stroke=WHITE, sw=5)
            icon(c, 860, 420, 0.7 * s, gear, 60, 9, t * 1.5, WHITE, a=a * 0.8)
        tx(c, "Math", 110, 540, 400, a=a, sc=s)
        a, s = pop(t, A(2, "understand")); tx(c, "Understand,", 84, 540, 560, a=a, sc=s)
        a, s = pop(t, A(2, "solve")); tx(c, "then *solve*", 84, 540, 670, a=a, sc=s)
        a, s = pop(t, A(2, "in english"), s0=0.6)
        if a > 0:
            box(c, 90, 860, 900, 520, 50, ORANGE, a * 0.95, stroke=WHITE, sw=5)
            icon(c, 830, 990, 0.65 * s, person, PINK, 0.3, 1.0, a=a)
        tx(c, "English", 110, 540, 970, a=a, sc=s)
        a, s = pop(t, A(2, "behave")); tx(c, "You *behave*", 110, 540, 1130, a=a, sc=s)
        a, s = pop(t, A(2, "behave") + 0.3); he(c, "באנגלית צריך להתנהג", 540, 1290, a=a, sc=s)
    add(A(2) - 0.12, "blue", split)
    def art(c, t, sc):
        for k, (w, col) in enumerate([("Fluency", PINK), ("Connection", SKYC), ("Confidence", GOLD)]):
            a, s = pop(t, A(3, w)); chip(c, w, 76, 540, 350 + 112 * k, col, a=a, sc=s)
        a, s = pop(t, A(3, "not science")); chip(c, "Not science.", 64, 540, 700, NAVY, a=a, sc=s, outline=WHITE, strike=ramp(t, A(3, "science"), A(3, "science") + 0.4))
        a, s = pop(t, A(3, "closer")); icon(c, 470, 920, 1.25 * s, palette, t, a=a, r=140); icon(c, 690, 880, 1.0 * s, brush, t, a=a)
        tx(c, "Closer to *art*", 120, 540, 1140, a=a, sc=s)
        a, s = pop(t, A(3, "art")); he(c, "זה קרוב יותר לאמנות", 540, 1290, a=a, sc=s)
    add(A(3) - 0.12, "magenta", art)
    def stuck(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 650, 1.45 * s, head_gears, t, a=a, r=150)
        a, s = pop(t, A(4, "checking")); chip(c, "Checking every tense", 64, 540, 330, SKYC, a=a, sc=s)
        a, s = pop(t, A(4, "stuck")); tx(c, "Stuck in", 116, 540, 945, a=a, sc=s); tx(c, "your *head*", 116, 540, 1065, a=a, sc=s)
        a, s = pop(t, A(4, "scared")); chip(c, "Scared of every mistake", 64, 540, 1195, RED, a=a, sc=s)
        a, s = pop(t, A(4, "mistake")); he(c, "תקועים בראש, בודקים כל מילה", 540, 1320, a=a, sc=s)
    add(A(4, "while") - 0.15, "violet", stuck)
    def connect(c, t, sc):
        br = ramp(t, A(5, "analyzing"), A(5, "analyzing") + 0.4)
        a, s = pop(t, sc["t0"]); icon(c, 540, 770, 1.5 * s, two_people, t, 1 - br, br, a=a, r=160)
        tx(c, "Hard to *connect*", 112, 540, 390, a=a, sc=s)
        a, s = pop(t, A(5, "analyzing")); chip(c, "while analyzing yourself", 72, 540, 1110, RED, a=a, sc=s)
        a, s = pop(t, A(5, "yourself")); he(c, "קשה להתחבר כשמנתחים את עצמכם", 540, 1250, a=a, sc=s)
    add(A(5) - 0.12, "red", connect)
    def tool(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "Use your *mind*", 120, 540, 380, a=a, sc=s)
        a, s = pop(t, A(6, "tool")); icon(c, 540, 660, 1.4 * s, toolbox, a=a, r=130); icon(c, 690, 560, 0.7 * s, check_badge, a=a)
        chip(c, "As a *tool*", 84, 540, 900, GREEN, a=a, sc=s)
        a, s = pop(t, A(6, "not as")); chip(c, "Not the goal", 72, 540, 1065, NAVY, a=a, sc=s, outline=WHITE, icon_fn=target, strike=ramp(t, A(6, "goal"), A(6, "goal") + 0.4))
        a, s = pop(t, A(6, "goal")); he(c, "המוח הוא כלי, לא המטרה", 540, 1230, a=a, sc=s)
    add(A(6) - 0.12, "green", tool)
    def product(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "The *product*", 120, 540, 360, a=a, sc=s)
        a, s = pop(t, A(7, "perfect")); chip(c, "Not perfect sentences", 64, 540, 495, NAVY, a=a, sc=s, outline=WHITE, strike=ramp(t, A(7, "grades"), A(7, "grades") + 0.4))
        rows = [("Conversations", bubbles2, SKYC), ("Friendships", handshake, GOLD), ("Connection", heart, PINK)]
        for k, (w, fn, col) in enumerate(rows):
            y = 690 + 175 * k; a, s = pop(t, A(7, w))
            if a <= 0: continue
            circ(c, 220, y, 78 * s, col, a, stroke=WHITE, sw=6); icon(c, 220, y + (12 if fn is heart else 0), (0.62 if fn is not heart else 0.95) * s, fn, *((WHITE,) if fn is heart else ()), a=a)
            tx(c, w, 80, 330, y, a=a, anchor="l")
        a, s = pop(t, A(7, "connection")); he(c, "שיחות. חברויות. חיבור.", 540, 1240, a=a, sc=s)
    add(A(7) - 0.12, "sunset", product)
    def seven(c, t, sc):
        u = ramp(t, sc["t0"], sc["t0"] + 3.5); a, s = pop(t, sc["t0"])
        icon(c, 540, 560, s, clock_ring, t, u, a=a, r=170)
        tx(c, "7", 190, 540, 535, a=a, sc=s, col=Y255); tx(c, "min", 64, 540, 650, a=a, sc=s)
        a, s = pop(t, A(8, "talk")); tx(c, "Talk about what", 96, 540, 850, a=a, sc=s); tx(c, "you *care* about", 96, 540, 960, a=a, sc=s)
        a, s = pop(t, A(8, "just say")); chip(c, "Just say it", 76, 540, 1100, PINK, a=a, sc=s, icon_fn=rec_dot)
        a, s = pop(t, A(8, "care")); he(c, "7 דקות ביום, באנגלית, על מה שחשוב", 540, 1250, a=a, sc=s)
    add(A(8) + 0.5, "blue", seven)
    def cta(c, t, sc):
        a, s = pop(t, sc["t0"]); chip(c, "Want to learn more?", 72, 540, 350, SKYC, a=a, sc=s)
        a, s = pop(t, A(9, "comment")); icon(c, 540, 570, 1.1 * s, comment_icon, t, a=a, r=120)
        tx(c, "Comment", 120, 540, 790, a=a, sc=s)
        speaker_pill(c, t, A(9, "speaker"), 955)
        a, s = pop(t, A(9, "send")); tx(c, "and get the guide", 76, 540, 1115, a=a, sc=s)
        a, s = pop(t, A(9, "speaker") + 0.3); he(c, "כתבו ספיקר", 540, 1245, a=a, sc=s, sz=72)
    add(A(9) - 0.12, "violet", cta)
    return S

if __name__ == "__main__":
    main("/home/claude/not_math", (("seven minutes", "7 minutes"),), build, "skip", 5, tail=2.6)
