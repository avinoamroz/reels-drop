"""ASR check of a finished reel in a small process: python3 asr_final.py timing_v2.json
Reads rep["_check"] (media, lines, lspan, cmap, line_of, CH) written by the v2 script, waits for memory (other jobs run
whisper too), transcribes each script line's window of the final mix (whole line, then chunk by chunk if recall < 0.9),
lists missing / extra words per line, writes rep["asr"] and drops rep["_check"]."""
import sys, json, numpy as np, subprocess
sys.path.insert(0, "/home/claude/reelkit")
import vo_restore as R
from collections import Counter
p = sys.argv[1]; rep = json.load(open(p)); C = rep["_check"]
R.asr()   # takes the shared whisper lock, then waits for memory
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", C["media"], "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
out = []
for i, (a, b) in enumerate(C["lspan"]):
    ref = R.toks(C["lines"][i])
    def sc(h): return sum((Counter(R.toks(h)) & Counter(ref)).values()) / max(1, len(ref))
    h = R.transcribe(x, a - 0.15, b + 0.4); r = sc(h)
    if r < 0.9:
        ks = [k for k in range(len(C["CH"])) if C["line_of"][k] == i]
        h2 = " ".join(R.transcribe(x, C["cmap"][k][0] - 0.12, C["cmap"][k][1] + 0.35) for k in ks)
        if sc(h2) > r: h, r = h2, sc(h2)
    miss = R.missing(C["lines"][i], h); extra = sorted((Counter(R.toks(h)) - Counter(ref)).elements())
    out.append(dict(line=C["lines"][i], heard=h, recall=round(r, 2), missing=miss, extra=extra))
rep["asr"] = out; del rep["_check"]
json.dump(rep, open(p, "w"), indent=1, ensure_ascii=False)
print(json.dumps(rep["loud"]))
for o in out:
    if o["missing"] or o["extra"]: print("MISMATCH", o["recall"], "|", o["line"], "| heard:", o["heard"], "| missing", o["missing"], "extra", o["extra"])
print("lines", len(out), "mismatched", sum(1 for o in out if o["missing"] or o["extra"]))
