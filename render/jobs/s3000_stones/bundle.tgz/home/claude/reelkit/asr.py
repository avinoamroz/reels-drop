"""Local ASR + script alignment for reelkit (sherpa-onnx whisper turbo int8, English).

Pipeline (align_voice):
  1. speech chunks: silence detection (-38 dB, 0.22 s pauses), same settings as /home/claude/vo_v4/asr_segs.py.
  2. windows: consecutive chunks are grouped into ASR windows of about 11 to 16 s, always cut at a pause
     (30 s windows ran out of memory on this box; tiny windows pay the fixed whisper cost many times).
  3. each window is transcribed once. Its words are spread over the window's speech chunks with a small DP
     (word chars vs chunk duration, punctuation preferred at a pause), then timed inside a chunk by char fraction.
  4. the ASR words are aligned to the script words with an edit-distance DP (numbers spelled out with num2words on both
     sides), so every script word gets a start/end; unmatched script words are interpolated between their neighbours.
Output: dict(words=[{w, line, t0, t1, matched}], lines=[{i, text, t0, t1, recall, missing}], chunks, windows)."""
import math, os, re, sys, time, json, hashlib, subprocess
import numpy as np
from collections import Counter

WD = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
_asr = None

def wait_mem(need_gb=1.7, max_wait=900):
    """wait until the shared cgroup has room for the whisper model (other renders run whisper too).
    free = limit - total_rss (page cache is reclaimable); needs the room for 3 checks in a row (another job may be loading)"""
    import glob
    ds = glob.glob("/sys/fs/cgroup/memory/process_api/*/claude-code-bash")
    if not ds: return
    t0 = time.time(); ok = 0
    while time.time() - t0 < max_wait:
        try:
            lim = int(open(f"{ds[0]}/memory.limit_in_bytes").read())
            rss = int(re.search(r"^total_rss (\d+)", open(f"{ds[0]}/memory.stat").read(), re.M).group(1))
        except (OSError, AttributeError): return
        free = (lim - rss) / 1e9
        ok = ok + 1 if free >= need_gb else 0
        if ok >= 3: return
        if ok == 0: print(f"[asr] waiting for memory, {free:.2f} GB free", flush=True)
        time.sleep(4 if ok else 10)

LOCK = os.environ.get("RK_ASR_LOCK", "/tmp/claude-0/asr.lock")   # flock: reelkit whisper jobs serialise
_lock_fd = None
def _take_lock(log=print):
    """machine-wide cooperative lock: one reelkit whisper at a time (held until this process exits or release())"""
    global _lock_fd
    if _lock_fd is not None: return
    import fcntl
    _lock_fd = open(LOCK, "a+")
    try: fcntl.flock(_lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log("[asr] another reelkit whisper is running, waiting for the lock"); fcntl.flock(_lock_fd, fcntl.LOCK_EX)
def model(threads=2):
    global _asr
    if _asr is None:
        _take_lock(); wait_mem()
        import sherpa_onnx
        _asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=WD + "turbo-encoder.int8.onnx", decoder=WD + "turbo-decoder.int8.onnx",
                                                          tokens=WD + "turbo-tokens.txt", language="en", task="transcribe", num_threads=threads)
    return _asr
def release():
    global _asr, _lock_fd
    _asr = None; import gc; gc.collect()
    if _lock_fd is not None: _lock_fd.close(); _lock_fd = None

def to16(x, sr):
    """mono float array at sr -> float32 at 16 kHz"""
    r = subprocess.run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(sr), "-ac", "1", "-i", "pipe:0", "-ar", "16000", "-f", "f32le", "pipe:1"],
                       input=np.asarray(x, np.float32).tobytes(), capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-300:]
    return np.frombuffer(r.stdout, np.float32)
def load16(path):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.float32)
def transcribe(x16, a, b):
    seg = x16[int(max(0, a) * 16000):int(max(0, b) * 16000)]
    st = model().create_stream()
    st.accept_waveform(16000, np.concatenate([np.zeros(3200, np.float32), seg.astype(np.float32), np.zeros(6400, np.float32)]))
    model().decode_stream(st); return st.result.text.strip()

# ------------------------------------------------------------------ tokens
def spell(s):
    """digits -> words, the way the TTS script spells them (years read as years)"""
    from num2words import num2words
    def one(m):
        t_ = m.group(0).replace(",", "")
        try:
            v = float(t_); iv = int(v)
            return num2words(iv, to="year") if v == iv and 1900 <= iv <= 2099 else num2words(v if v != iv else iv)
        except Exception: return t_
    s = re.sub(r"(\d)%", r"\1 percent", s)
    return re.sub(r"\d[\d,]*(\.\d+)?", one, s)
def toks(s): return re.findall(r"[a-z0-9']+", spell(s).lower().replace("-", " ").replace("’", "'"))
def missing(ref, hyp):
    c = Counter(toks(ref)) - Counter(toks(hyp)); return sorted(c.elements())

# ------------------------------------------------------------------ chunks and windows
def speech_chunks(x16, noise_db=-38, min_sil=0.22):
    r = subprocess.run(["ffmpeg", "-nostdin", "-f", "f32le", "-ar", "16000", "-ac", "1", "-i", "pipe:0", "-af",
                        f"silencedetect=noise={noise_db}dB:d={min_sil}", "-f", "null", "-"], input=x16.tobytes(), capture_output=True).stderr.decode()
    st = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", r)]; en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r)]
    dur = len(x16) / 16000
    b = [0.0] + [v for p in zip(st, en) for v in p] + [dur]
    if len(st) > len(en): b = b[:-1]
    return [(max(0.0, b[2 * i]), b[2 * i + 1]) for i in range(len(b) // 2) if b[2 * i + 1] - b[2 * i] > 0.12]
def split_long(ch, hi=16.0):
    """no chunk longer than hi s (whisper only takes 30 s; a pause-free chunk would otherwise become one huge window)"""
    out = []
    for a, b in ch:
        n = max(1, math.ceil((b - a) / hi)); out += [(a + (b - a) * k / n, a + (b - a) * (k + 1) / n) for k in range(n)]
    return out
def make_windows(ch, lo=11.0, hi=16.0):
    """group chunk indices into windows of lo..hi s, cut at the longest pause available"""
    out = []; i = 0; n = len(ch)
    while i < n:
        j = i; best = None
        while j + 1 < n and ch[j + 1][1] - ch[i][0] <= hi:
            j += 1
            if ch[j][1] - ch[i][0] >= lo and j + 1 < n:
                gap = ch[j + 1][0] - ch[j][1]
                if best is None or gap >= best[1] - 1e-6: best = (j, gap)
        if j + 1 < n and best is not None: j = best[0]
        if j + 1 == n - 1 and ch[n - 1][1] - ch[i][0] <= hi * 1.15: j = n - 1   # do not leave a tiny tail window
        out.append(list(range(i, j + 1))); i = j + 1
    return out

def spread_words(words, spans):
    """DP: split the window's words into len(spans) consecutive groups (char length ~ span duration, punctuation at pauses).
    returns [(word, t0, t1)]"""
    m = len(spans); n = len(words)
    if n == 0: return []
    L = [len(spell(w)) + 1 for w in words]; cum = np.concatenate([[0], np.cumsum(L)])   # spoken length: '135,000' is long
    D = sum(b - a for a, b in spans); rate = D / cum[-1]
    INF = 1e18; best = np.full((m + 1, n + 1), INF); bk = np.zeros((m + 1, n + 1), int); best[0][0] = 0
    for j in range(1, m + 1):
        d = spans[j - 1][1] - spans[j - 1][0]
        for e in range(0, n + 1):
            for s_ in range(0, e + 1):
                if best[j - 1][s_] >= INF: continue
                if e == s_: cost = 4.0 * d + 0.2                        # empty chunk (noise / breath): cheap only if short
                else:
                    exp = (cum[e] - cum[s_]) * rate; cost = np.log((exp + 0.05) / (d + 0.05)) ** 2
                    if j < m and not re.search(r"[.,?!:;]$", words[e - 1]): cost += 0.25
                v = best[j - 1][s_] + cost
                if v < best[j][e]: best[j][e] = v; bk[j][e] = s_
    cuts = [n]; e = n
    for j in range(m, 0, -1): e = bk[j][e]; cuts.append(e)
    cuts = cuts[::-1]; out = []
    for j in range(m):
        g = list(range(cuts[j], cuts[j + 1]))
        if not g: continue
        a, b = spans[j]; tot = sum(L[k] for k in g); acc = 0
        for k in g:
            out.append((words[k], a + (b - a) * acc / tot, a + (b - a) * (acc + L[k] - 1) / tot)); acc += L[k]
    return out

def asr_words(x16, ch, win, log=print, prev=None, redo=None):
    """transcribe each window; returns ([(word, t0, t1)], window records). prev/redo: reuse prev window records except redo"""
    words = []; texts = []
    for k, w in enumerate(win):
        a, b = ch[w[0]][0], ch[w[-1]][1]
        if prev is not None and (redo is None or k not in redo):
            rec = prev[k]
        else:
            tx = transcribe(x16, a - 0.15, b + 0.3); log(f"[asr] {a:6.2f} to {b:6.2f}  {tx}")
            rec = dict(t0=round(a, 3), t1=round(b, 3), text=tx, chunks=w, words=[list(x) for x in spread_words(tx.split(), [ch[q] for q in w])])
        texts.append(rec); words += [tuple(x) for x in rec["words"]]
    return words, texts

# ------------------------------------------------------------------ script alignment
def script_words(lines):
    """[(line_index, display_word, [tokens])]"""
    out = []
    for i, l in enumerate(lines):
        for w in re.sub(r"\[[^\]]*\]", "", l).split():
            out.append((i, w, toks(w)))
    return out
SAME = {frozenset(p) for p in (("a", "one"), ("ok", "okay"), ("percent", "per"), ("mr", "mister"))}
def _sim(a, b):
    if a == b or frozenset((a, b)) in SAME: return 0.0
    import difflib
    r = difflib.SequenceMatcher(None, a, b).ratio(); return 0.45 if r >= 0.75 else 1.0
def align(lines, aw):
    """edit-distance DP between script tokens and ASR tokens. aw = [(word, t0, t1)] from asr_words"""
    sw = script_words(lines)
    S = [(wi, t) for wi, (_, _, ts) in enumerate(sw) for t in ts]                 # script tokens -> owning display word
    A = []
    for w, a, b in aw:
        ts = toks(w)
        if not ts: continue
        L = [len(t) for t in ts]; tot = sum(L); acc = 0
        for t, l in zip(ts, L):
            A.append((t, a + (b - a) * acc / tot, a + (b - a) * (acc + l) / tot)); acc += l
    n, m = len(S), len(A); GAP = 0.8
    D = np.zeros((n + 1, m + 1)); D[:, 0] = np.arange(n + 1) * GAP; D[0, :] = np.arange(m + 1) * GAP
    P = np.zeros((n + 1, m + 1), np.int8)
    for i in range(1, n + 1):
        si = S[i - 1][1]
        for j in range(1, m + 1):
            c0 = D[i - 1, j - 1] + _sim(si, A[j - 1][0]); c1 = D[i - 1, j] + GAP; c2 = D[i, j - 1] + GAP
            if c0 <= c1 and c0 <= c2: D[i, j] = c0; P[i, j] = 0
            elif c1 <= c2: D[i, j] = c1; P[i, j] = 1
            else: D[i, j] = c2; P[i, j] = 2
    i, j = n, m; pair = [None] * n; exact = [False] * n
    while i > 0 and j > 0:
        if P[i, j] == 0: pair[i - 1] = j - 1; exact[i - 1] = _sim(S[i - 1][1], A[j - 1][0]) == 0.0; i -= 1; j -= 1
        elif P[i, j] == 1: i -= 1
        else: j -= 1
    tt = [None] * n
    for k in range(n):
        if pair[k] is not None: tt[k] = [A[pair[k]][1], A[pair[k]][2]]
    # interpolate unmatched tokens between neighbours
    k = 0
    while k < n:
        if tt[k] is None:
            e = k
            while e < n and tt[e] is None: e += 1
            lo = tt[k - 1][1] if k > 0 else (tt[e][0] - 0.3 * (e - k) if e < n else 0.0)
            hi = tt[e][0] if e < n else lo + 0.3 * (e - k)
            for q in range(k, e):
                u0 = (q - k) / (e - k); u1 = (q - k + 1) / (e - k); tt[q] = [lo + (hi - lo) * u0, lo + (hi - lo) * u1]
            k = e
        else: k += 1
    words = []
    for wi, (li, w, ts) in enumerate(sw):
        ks = [k for k, (o, _) in enumerate(S) if o == wi]
        if ks: t0, t1 = tt[ks[0]][0], tt[ks[-1]][1]; ok = all(exact[k] for k in ks)
        else:
            t0 = t1 = words[-1]["t1"] if words else 0.0; ok = True
        words.append(dict(w=w, line=li, t0=round(t0, 3), t1=round(max(t1, t0 + 0.04), 3), matched=ok))
    for a, b in zip(words, words[1:]):                                            # keep monotone
        if b["t0"] < a["t0"]: b["t0"] = a["t0"]
        if b["t1"] < b["t0"] + 0.04: b["t1"] = round(b["t0"] + 0.04, 3)
    heard = " ".join(w for w, _, _ in aw)
    out_lines = []
    for i, l in enumerate(lines):
        ws = [w for w in words if w["line"] == i]
        ntok = sum(len(sw[k][2]) for k in range(len(sw)) if sw[k][0] == i)
        hit = sum(1 for k, (o, _) in enumerate(S) if sw[o][0] == i and exact[k])
        miss = [S[k][1] for k in range(n) if sw[S[k][0]][0] == i and not exact[k]]
        out_lines.append(dict(i=i, text=l, t0=ws[0]["t0"], t1=ws[-1]["t1"], recall=round(hit / max(1, ntok), 3), missing=miss))
    return dict(words=words, lines=out_lines, heard=heard)

def align_voice(x, sr, lines, cache_dir=None, log=print, prev=None, redo=None):
    """full pipeline on a processed voice array; cached by audio hash + script.
    prev (an earlier result on a near-identical voice) + redo (window indexes): only those windows are transcribed again"""
    key = hashlib.sha1(np.asarray(x, np.float32).tobytes() + "\n".join(lines).encode()).hexdigest()[:16]
    cp = os.path.join(cache_dir, f"asr_{key}.json") if cache_dir else None
    if cp and os.path.exists(cp): log(f"[asr] cache hit {cp}"); return json.load(open(cp))
    x16 = to16(x, sr)
    if prev is not None: ch = [tuple(c) for c in prev["chunks"]]; win = [w["chunks"] for w in prev["windows"]]
    else: ch = speech_chunks(x16); win = make_windows(ch)
    log(f"[asr] {len(ch)} speech chunks, {len(win)} windows: " + ", ".join(f"{ch[w[-1]][1] - ch[w[0]][0]:.1f}s" for w in win))
    aw, texts = asr_words(x16, ch, win, log, prev["windows"] if prev is not None else None, redo)
    res = align(lines, aw); res.update(chunks=[[round(a, 3), round(b, 3)] for a, b in ch], windows=texts,
                                       method="sherpa whisper turbo int8, 11-16 s windows cut at pauses, word DP to script")
    if cp: os.makedirs(cache_dir, exist_ok=True); json.dump(res, open(cp, "w"), indent=1, ensure_ascii=False)
    return res

def check_audio(x16, lines, spans=None, log=print):
    """QA: re-run the same windowed ASR on a finished audio (16 kHz) and diff each script line against what was heard.
    spans (optional, expected (t0, t1) per line) are used to report timing drift."""
    ch = speech_chunks(x16)
    if spans and (not ch or max(b - a for a, b in ch) > 16.0):
        # a finished mix has music under the pauses, so silencedetect finds one long chunk (whisper drops audio past 30 s):
        # use the known line spans as chunks instead
        ch = [(max(0.0, a - 0.05), b + 0.05) for a, b in spans]
    ch = split_long(ch); win = make_windows(ch)
    aw, texts = asr_words(x16, ch, win, log)
    res = align(lines, aw); out = []
    for L in res["lines"]:
        a, b = L["t0"], L["t1"]
        heard = " ".join(w for w, s, e in aw if a - 0.25 <= (s + e) / 2 <= b + 0.25)
        ex = sorted((Counter(toks(heard)) - Counter(toks(L["text"]))).elements())
        d = dict(line=L["text"], heard=heard, recall=L["recall"], missing=L["missing"], extra=ex, t0=a, t1=b)
        if spans: d["drift_s"] = round(a - spans[L["i"]][0], 2)
        out.append(d)
    return out, texts

# ------------------------------------------------------------------ OOM-safe execution
def isolated(fn_name, *args, retries=12, log=print, **kw):
    """run asr.<fn_name>(*args, **kw) in a child process. The whisper model is the biggest thing in the shared memory cgroup,
    so when several jobs load it at once the OOM killer takes it: the child is then retried after a memory wait,
    and the parent (holding the reel state) survives."""
    import pickle, tempfile
    d = tempfile.mkdtemp(prefix="rk_asr_", dir=os.environ.get("RK_TMP") or None); ji, jo = f"{d}/in.pkl", f"{d}/out.pkl"
    pickle.dump((fn_name, args, kw), open(ji, "wb"))
    try:
        for k in range(retries):
            r = subprocess.run([sys.executable, os.path.abspath(__file__), "--job", ji, jo])
            if r.returncode == 0: return pickle.load(open(jo, "rb"))
            log(f"[asr] child exited {r.returncode} (killed for memory?), retry {k + 1}/{retries}")
            time.sleep(min(90, 20 + 15 * k))
        raise RuntimeError("ASR child kept failing")
    finally:
        for f in (ji, jo):
            if os.path.exists(f): os.remove(f)
        os.rmdir(d)

if __name__ == "__main__" and len(sys.argv) == 4 and sys.argv[1] == "--job":
    import pickle
    fn, args, kw = pickle.load(open(sys.argv[2], "rb"))
    _take_lock()                    # the whole job holds the machine-wide lock; released when this child exits
    res = globals()[fn](*args, **kw)
    pickle.dump(res, open(sys.argv[3], "wb"))
