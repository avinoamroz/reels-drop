"""Simple friendly illustrations drawn in code (no faces of real people, no logos). Each draws around (0,0) in a ~200 px box."""
import math, cairo
from kit import *

def dtx(c, s, sz, col=W255, w=900):
    """decorative text inside an icon (local coords, not logged)"""
    surf, tw, th, pad = text_surf(s, sz, w, col, Y255, False)
    c.set_source_surface(surf, -tw / 2 - pad, -th / 2 - pad); c.paint_with_alpha(St.a)

def check_badge(c, col=GREEN):
    circ(c, 0, 0, 60, col, stroke=WHITE, sw=8); line(c, [(-26, 2), (-6, 24), (30, -22)], WHITE, 14)
def x_stamp(c, col=RED):
    c.save(); c.rotate(-0.18)
    c.new_sub_path(); c.arc(0, 0, 92, 0, 2 * math.pi); sa(c, col, 0.18); c.fill_preserve(); sa(c, col); c.set_line_width(12); c.stroke()
    line(c, [(-48, -48), (48, 48)], col, 26); line(c, [(48, -48), (-48, 48)], col, 26); c.restore()
def stamp(c, t, t0, x, y, s=1.0, col=RED):
    """red X stamp that slams in at t0"""
    if t < t0: return
    u = ease((t - t0) / 0.22); sc = s * lerp(1.9, 1.0, u); a = ramp(t, t0, t0 + 0.1)
    icon(c, x, y, sc, x_stamp, col, a=a)
    if t - t0 < 0.5:  # impact ring
        k = (t - t0) / 0.5; c.new_sub_path(); c.arc(x, y, 100 * s * (1 + k * 0.8), 0, 2 * math.pi); sa(c, col, 0.5 * (1 - k)); c.set_line_width(6); c.stroke()

def person(c, col=SKYC, arm=0.0, wave=0.0, smile=True, head=CREAM):
    """rounded cartoon person, ~240 tall, feet at y=120"""
    box(c, -55, -10, 110, 130, 50, col)                          # body
    line(c, [(-48, 10), (-80, 60 - 60 * arm)], col, 26)          # left arm
    a2 = wave * math.sin(CUR["t"] * 9) * 0.35
    line(c, [(48, 10), (48 + 40 * math.cos(-1.1 - arm * 1.2 + a2), 10 + 55 * math.sin(-1.1 - arm * 1.2 + a2) + 50 * (1 - arm))], col, 26)
    circ(c, 0, -62, 46, head)
    circ(c, -15, -66, 6, INK); circ(c, 15, -66, 6, INK)
    if smile:
        c.new_sub_path(); c.arc(0, -56, 16, 0.2, math.pi - 0.2); sa(c, INK); c.set_line_width(5); c.stroke()
    else: line(c, [(-12, -46), (12, -46)], INK, 5)

def speech(c, w=180, h=120, col=WHITE, tail=1):
    rr(c, -w / 2, -h / 2, w, h, 36); sa(c, col); c.fill()
    c.move_to(tail * 10 - 20, h / 2 - 4); c.line_to(tail * 40 - 10, h / 2 + 36); c.line_to(tail * 40 + 12, h / 2 - 4); c.close_path(); c.fill()
def heart(c, col=PINK, s=1.0):
    c.save(); c.scale(s, s); c.move_to(0, 30)
    c.curve_to(-70, -20, -35, -75, 0, -38); c.curve_to(35, -75, 70, -20, 0, 30); c.close_path(); sa(c, col); c.fill(); c.restore()

# ---------------------------------------------------------- wouldnt_do
def flashcards(c):
    for k, (rot, col) in enumerate([(-0.28, SKYC), (0.22, GOLD), (-0.04, PINK)]):
        c.save(); c.rotate(rot); c.translate((k - 1) * 12, (k - 1) * -10)
        box(c, -95, -62, 190, 124, 18, WHITE, stroke=col, sw=10)
        for j in range(3): line(c, [(-60, -26 + j * 26), (60 - 30 * (j == 2), -26 + j * 26)], col, 9, 0.8)
        c.restore()
def grammar_book(c):
    box(c, -80, -100, 160, 200, 14, PURPLE); box(c, -80, -100, 24, 200, 8, hx("#5B35C9"))
    box(c, 70, -92, 16, 184, 4, WHITE)
    box(c, -40, -60, 100, 50, 10, WHITE, 0.9); dtx(c, "ABC", 34, (90, 60, 200, 255))
    c.save(); c.translate(10, -35); c.restore()
    for j in range(3): line(c, [(-36, 20 + j * 22), (56, 20 + j * 22)], WHITE, 7, 0.55)
    c.move_to(30, 100); c.line_to(30, 130); c.line_to(42, 120); c.line_to(54, 130); c.line_to(54, 100); sa(c, RED); c.fill()
def yawn_face(c, open_):
    circ(c, 0, 0, 70, YEL)
    for sx in (-1, 1):
        c.new_sub_path(); c.arc(sx * 24, -14, 13, 0.15, math.pi - 0.15); sa(c, INK); c.set_line_width(6); c.stroke()
    c.save(); c.translate(0, 30); c.scale(1, 0.6 + 0.6 * open_); circ(c, 0, 0, 20, hx("#7A2E2E")); c.restore()
    circ(c, -54, 34, 13, hx("#FFB0C0"), 0.6); circ(c, 54, 34, 13, hx("#FFB0C0"), 0.6)
def boring_book(c, t):
    box(c, -100, -120, 200, 240, 16, hx("#8A9BB8")); box(c, -100, -120, 26, 240, 8, hx("#6B7C99"))
    box(c, 90, -112, 14, 224, 4, WHITE)
    op = 0.5 + 0.5 * math.sin(t * 2.4)
    c.save(); c.translate(12, -10); c.scale(0.95, 0.95); yawn_face(c, op); c.restore()
    for k in range(3):
        ph = (t * 0.6 + k / 3) % 1; c.save(); c.translate(90 + 50 * ph, -110 - 90 * ph); sa(c, WHITE, 1 - ph)
        dtx(c, "z", int(40 + 16 * k), W255); c.restore()
def test_sheet(c, t):
    box(c, -95, -125, 190, 250, 14, WHITE, stroke=hx("#C9D3E6"), sw=4)
    box(c, -70, -100, 110, 18, 6, hx("#C9D3E6"))
    for j in range(4):
        y = -50 + j * 44; box(c, -70, y - 13, 26, 26, 5, WHITE, stroke=INK, sw=4)
        line(c, [(-30, y), (65, y)], hx("#AEB9CF"), 8)
    line(c, [(-66, -50), (-58, -40), (-46, -60)], GREEN, 6); line(c, [(-66, -6 - 6), (-50, 6)], RED, 6); line(c, [(-50, -12), (-66, 6)], RED, 6)
    # little stopwatch
    c.save(); c.translate(80, -110); circ(c, 0, 0, 38, ORANGE, stroke=WHITE, sw=6)
    a = t * 4; line(c, [(0, 0), (24 * math.sin(a), -24 * math.cos(a))], WHITE, 6); box(c, -8, -50, 16, 12, 3, WHITE); c.restore()
def invite(c, t):
    c.save(); c.rotate(-0.08)
    box(c, -150, -105, 300, 210, 22, WHITE, stroke=GOLD, sw=10)
    for k, col in enumerate([PINK, SKYC, YEL, GREEN, PURPLE, ORANGE]):
        x = -120 + k * 48; circ(c, x, -76, 9, col); circ(c, -x * 0.9, 80, 8, col)
    dtx(c, "PARTY!", 64, (230, 60, 120, 255)); c.restore()
def balloon(c, col, deflate=0.0, t=0.0, ph=0.0):
    s = 1 - 0.45 * deflate; sway = math.sin(t * 1.6 + ph) * 0.08 + deflate * 0.5
    c.save(); c.rotate(sway)
    c.save(); c.translate(0, -60 + 40 * deflate); c.scale(s * 0.85, s * (1 - 0.15 * deflate))
    circ(c, 0, 0, 62, col); c.new_sub_path(); c.arc(-20, -22, 14, 0, 2 * math.pi); sa(c, WHITE, 0.45); c.fill(); c.restore()
    by = -60 + 40 * deflate + 62 * s * (1 - 0.15 * deflate) * 0.85
    c.move_to(-8, by + 10); c.line_to(8, by + 10); c.line_to(0, by - 2); c.close_path(); sa(c, col); c.fill()
    c.move_to(0, by + 10); c.curve_to(14, by + 50, -14, by + 80, 6, 140); sa(c, WHITE, 0.8); c.set_line_width(3); c.stroke(); c.restore()
def dance_floor(c, t):
    cols = [PINK, SKYC, YEL, PURPLE, GREEN, ORANGE]
    for r in range(4):
        y0 = -10 + r * 34; y1 = y0 + 34; w0 = 300 + r * 70; w1 = w0 + 70
        for k in range(6):
            x0a = -w0 / 2 + k * w0 / 6; x1a = x0a + w0 / 6; x0b = -w1 / 2 + k * w1 / 6; x1b = x0b + w1 / 6
            on = (k + r + int(t * 3)) % 3 == 0
            c.move_to(x0a, y0); c.line_to(x1a, y0); c.line_to(x1b, y1); c.line_to(x0b, y1); c.close_path()
            sa(c, cols[(k + r) % 6], 0.95 if on else 0.45); c.fill()
    line(c, [(0, -190), (0, -130)], WHITE, 4, 0.7)
    circ(c, 0, -95, 40, hx("#D8E2F0"))
    for k in range(10):
        a = k * 0.63 + t; line(c, [(0, -95), (math.cos(a) * 52, -95 + math.sin(a) * 52)], WHITE, 3, 0.5)
    for k in range(5):
        a = t * 1.3 + k * 1.26; x = math.cos(a) * 110; y = -95 + math.sin(a) * 40
        circ(c, x, y, 5, WHITE, 0.6 + 0.4 * math.sin(t * 5 + k))
def desk_student(c, t):
    box(c, -110, 40, 220, 26, 8, hx("#C68B4E")); line(c, [(-90, 66), (-90, 130)], hx("#8A5A2E"), 12); line(c, [(90, 66), (90, 130)], hx("#8A5A2E"), 12)
    c.save(); c.translate(0, -40); c.scale(0.8, 0.8); person(c, RED, arm=1.0, smile=False); c.restore()
    box(c, -40, 26, 80, 16, 4, WHITE)
def speaker_fig(c, t, a=1.0):
    c.save(); c.scale(0.8, 0.8); person(c, GREEN, arm=0.3, wave=1.0); c.restore()
    for k in range(3):
        r = 40 + k * 24 + 8 * math.sin(t * 4 + k)
        c.new_sub_path(); c.arc(30, -50, r, -0.7, 0.3); sa(c, WHITE, 0.7 - k * 0.18); c.set_line_width(7); c.stroke()
def coffee(c, t):
    box(c, -60, -40, 120, 110, 24, WHITE); c.new_sub_path(); c.arc(70, 15, 28, -1.4, 1.4); sa(c, WHITE); c.set_line_width(14); c.stroke()
    box(c, -60, -20, 120, 30, 4, hx("#B5651D"), 0.9)
    for k in range(3):
        x = -30 + k * 30; ph = t * 2 + k
        c.move_to(x, -55); c.curve_to(x + 14 * math.sin(ph), -80, x - 14 * math.sin(ph), -100, x, -125); sa(c, WHITE, 0.6); c.set_line_width(7); c.stroke()
def qbubble(c):
    speech(c, 170, 130, WHITE); dtx(c, "?", 96, (39, 73, 211, 255))
def story_bubble(c):
    speech(c, 190, 130, WHITE, -1)
    for k, w in enumerate((120, 90, 110)): line(c, [(-w / 2, -30 + k * 30), (w / 2, -30 + k * 30)], hx("#E0475B"), 12)
def wrench(c):
    c.save(); c.rotate(0.7); box(c, -13, -30, 26, 140, 13, WHITE)
    c.new_sub_path(); c.arc(0, -60, 34, -math.pi / 2 + 0.75, 3 * math.pi / 2 - 0.75); sa(c, WHITE); c.set_line_width(24); c.stroke(); c.restore()
def comment_icon(c, t):
    s = 1 + 0.05 * math.sin(t * 5)
    c.save(); c.scale(s, s); speech(c, 220, 160, WHITE)
    for k in range(3): circ(c, -50 + k * 50, 0, 14, SKYC if k != 1 else GOLD)
    c.restore()
def rec_dot(c):
    t = CUR["t"]
    circ(c, 0, 0, 22, RED, 0.6 + 0.4 * (math.sin(t * 6) > 0))
def clock_ring(c, t, u):
    circ(c, 0, 0, 170, (1, 1, 1, 1), 0.12)
    c.new_sub_path(); c.arc(0, 0, 160, 0, 2 * math.pi); sa(c, WHITE, 0.25); c.set_line_width(24); c.stroke()
    c.new_sub_path(); c.arc(0, 0, 160, -math.pi / 2, -math.pi / 2 + 2 * math.pi * u); sa(c, YEL); c.set_line_width(24); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
def math_chip_ic(c):
    dtx(c, "÷", 120, W255)

# ---------------------------------------------------------- not_math
def chalkboard(c, t, cross=0.0):
    box(c, -300, -170, 600, 340, 24, hx("#7A4A22")); box(c, -280, -150, 560, 300, 14, hx("#1F4B3A"))
    for (x, y, s, sz) in [(-120, -80, "a²+b²=c²", 54), (110, -10, "f(x) = 3x", 50), (-130, 60, "E = mc²", 54), (140, 90, "x = 2y", 46)]:
        c.save(); c.translate(x, y); dtx(c, s, sz, (235, 240, 230, 230), 700); c.restore()
    if cross > 0:
        line(c, [(-250, -120), (-250 + 500 * ease(cross), -120 + 240 * ease(cross))], RED, 18)
        if cross > 0.5: line(c, [(250, -120), (250 - 500 * ease(cross * 2 - 1), -120 + 240 * ease(cross * 2 - 1))], RED, 18)
def atom(c, t):
    for k in range(3):
        c.save(); c.rotate(k * math.pi / 3); c.scale(1, 0.38)
        c.new_sub_path(); c.arc(0, 0, 95, 0, 2 * math.pi); c.restore(); sa(c, CYAN); c.set_line_width(7); c.stroke()
        a = t * 3 + k * 2.1; x, y = 95 * math.cos(a), 95 * 0.38 * math.sin(a); ca, sn = math.cos(k * math.pi / 3), math.sin(k * math.pi / 3)
        circ(c, x * ca - y * sn, x * sn + y * ca, 12, YEL)
    circ(c, 0, 0, 22, PINK)
def gear(c, r, teeth, rot, col):
    c.save(); c.rotate(rot); c.new_path()
    for k in range(teeth * 2):
        a0 = k * math.pi / teeth; rr_ = r if k % 2 == 0 else r * 0.78
        c.arc(0, 0, rr_, a0, a0 + math.pi / teeth)
    c.close_path(); sa(c, col); c.fill(); circ(c, 0, 0, r * 0.32, INK, 0.9); c.restore()
def head_gears(c, t):
    c.move_to(-90, 130); c.curve_to(-140, 40, -130, -130, 10, -140); c.curve_to(120, -140, 140, -40, 110, 10)
    c.line_to(140, 50); c.line_to(105, 60); c.curve_to(110, 110, 60, 110, 40, 130); c.close_path(); sa(c, WHITE, 0.95); c.fill()
    gear(c, 46, 9, t * 2.5, ORANGE); c.save(); c.translate(-58, -50); gear(c, 34, 7, -t * 3.3, PURPLE); c.restore()
    c.save(); c.translate(46, -70); gear(c, 28, 6, -t * 3.8 + 0.3, SKYC); c.restore()
def palette(c, t):
    c.move_to(-130, 20); c.curve_to(-140, -110, 90, -140, 130, -40); c.curve_to(160, 40, 60, 40, 60, 80); c.curve_to(60, 130, -110, 130, -130, 20)
    c.close_path(); sa(c, hx("#F3D9A4")); c.fill(); circ(c, -20, 60, 22, INK, 0.5)
    for k, (x, y, col) in enumerate([(-80, -30, RED), (-30, -80, YEL), (30, -85, GREEN), (85, -45, SKYC), (-90, 40, PURPLE)]):
        circ(c, x, y, 24 + 3 * math.sin(t * 3 + k), col)
def brush(c, t):
    c.save(); c.rotate(0.6); box(c, -10, -20, 20, 150, 8, hx("#C68B4E")); box(c, -14, -50, 28, 34, 5, hx("#B8C2D0"))
    c.move_to(-14, -50); c.curve_to(-14, -90, 0, -110, 0, -110); c.curve_to(0, -110, 14, -90, 14, -50); sa(c, PINK); c.fill(); c.restore()
def toolbox(c):
    box(c, -110, -30, 220, 120, 16, RED); box(c, -110, -30, 220, 34, 10, hx("#C81E45"))
    c.new_sub_path(); c.arc(0, -30, 46, math.pi, 0); sa(c, INK); c.set_line_width(14); c.stroke()
    box(c, -20, 12, 40, 22, 5, YEL)
def target(c):
    for k, col in enumerate([WHITE, RED, WHITE, RED]): circ(c, 0, 0, 80 - k * 20, col)
def handshake(c):
    c.save(); c.rotate(-0.15)
    box(c, -130, -22, 120, 44, 22, GOLD); box(c, 10, -22, 120, 44, 22, SKYC)
    box(c, -40, -30, 80, 60, 26, CREAM); line(c, [(-14, -28), (-14, 28)], hx("#E2C9A0"), 4); line(c, [(8, -28), (8, 28)], hx("#E2C9A0"), 4)
    c.restore()
def bubbles2(c):
    c.save(); c.translate(-30, -15); speech(c, 140, 95, SKYC); c.restore()
    c.save(); c.translate(40, 30); speech(c, 140, 95, WHITE, -1); c.restore()
def grade_paper(c):
    box(c, -80, -100, 160, 200, 12, WHITE); dtx(c, "A+", 70, (224, 71, 91, 255))
    line(c, [(-50, 50), (50, 50)], hx("#AEB9CF"), 8); line(c, [(-50, 74), (30, 74)], hx("#AEB9CF"), 8)
def two_people(c, t, link=1.0, broken=0.0):
    """two people with a speech-bubble link (warm when link=1, broken when broken=1)"""
    c.save(); c.translate(-170, 40); person(c, PINK, arm=0.25, wave=link * 0.6); c.restore()
    c.save(); c.translate(170, 40); person(c, SKYC, arm=0.25); c.restore()
    if broken > 0:
        for sx in (-1, 1): line(c, [(sx * 95, -30), (sx * 30, -30 + sx * 8)], hx("#FFFFFF"), 8, 0.6)
        line(c, [(-12, -48), (12, -12)], RED, 9); line(c, [(12, -48), (-12, -12)], RED, 9)
        c.save(); c.translate(-170, -110); gear(c, 28, 7, t * 4, ORANGE); c.restore()
        c.save(); c.translate(-130, -140); gear(c, 20, 6, -t * 5, YEL); c.restore()
    if link > 0:
        c.save(); c.translate(0, -70 - 6 * math.sin(t * 3)); c.scale(link, link); speech(c, 130, 100, WHITE); heart(c, PINK, 0.55); c.restore()
        c.move_to(-110, -20); c.curve_to(-60, 40, 60, 40, 110, -20); sa(c, YEL, link); c.set_line_width(7); c.set_dash([4, 14]); c.stroke(); c.set_dash([])

# ---------------------------------------------------------- oxy_vaso
def molecule(c, t, col, col2, kind):
    """cute molecule character: ring of atoms + face"""
    bob = 6 * math.sin(t * 3 + (0 if kind == "oxy" else 1.5))
    c.save(); c.translate(0, bob)
    for k in range(6):
        a = k * math.pi / 3 + math.pi / 6; x, y = 92 * math.cos(a), 92 * math.sin(a)
        a2 = (k + 1) * math.pi / 3 + math.pi / 6; line(c, [(x, y), (92 * math.cos(a2), 92 * math.sin(a2))], WHITE, 10, 0.85)
    for k in range(6):
        a = k * math.pi / 3 + math.pi / 6; x, y = 92 * math.cos(a), 92 * math.sin(a); circ(c, x, y, 26, col2, stroke=WHITE, sw=4)
    for a in (-0.5, 3.6):
        x, y = 140 * math.cos(a), 140 * math.sin(a); line(c, [(92 * math.cos(a), 92 * math.sin(a)), (x, y)], WHITE, 8, 0.85); circ(c, x, y, 20, col2, stroke=WHITE, sw=4)
    circ(c, 0, 0, 70, col)
    blink = 1 if (t * 0.7) % 3 > 0.12 else 0.15
    for sx in (-1, 1):
        c.save(); c.translate(sx * 24, -12); c.scale(1, blink); circ(c, 0, 0, 10, INK); circ(c, 3, -3, 3.5, WHITE); c.restore()
        circ(c, sx * 44, 14, 11, hx("#FFFFFF"), 0.35)
    c.new_sub_path(); c.arc(0, 8, 20, 0.25, math.pi - 0.25); sa(c, INK); c.set_line_width(6); c.stroke()
    if kind == "vaso":  # little shield badge
        c.save(); c.translate(0, 62); c.move_to(-22, -18); c.line_to(22, -18); c.line_to(22, 2); c.curve_to(22, 18, 0, 28, 0, 28)
        c.curve_to(0, 28, -22, 18, -22, 2); c.close_path(); sa(c, GOLD); c.fill_preserve(); sa(c, WHITE); c.set_line_width(4); c.stroke(); c.restore()
    else:
        c.save(); c.translate(0, 64); heart(c, hx("#FFFFFF"), 0.35); c.restore()
    c.restore()
def rowing(c, t):
    c.move_to(-230, 20); c.line_to(230, 20); c.curve_to(200, 80, -200, 80, -230, 20); sa(c, GOLD); c.fill()
    for k in range(3):
        x = -130 + k * 130; a = math.sin(t * 3.2) * 0.45
        circ(c, x, -50, 24, CREAM); box(c, x - 24, -28, 48, 50, 18, [SKYC, PINK, PURPLE][k])
        line(c, [(x + 5, -5), (x + 5 - 120 * math.cos(1.0 + a), -5 + 120 * math.sin(1.0 + a))], hx("#C68B4E"), 9)
    for k in range(4):
        ph = (t * 0.8 + k / 4) % 1; x = 260 - ph * 520
        c.move_to(x - 30, 80); c.curve_to(x - 15, 70, x + 15, 90, x + 30, 80); sa(c, WHITE, 0.6 * (1 - abs(ph - 0.5) * 2)); c.set_line_width(5); c.stroke()
def spray(c, t, puff):
    box(c, -45, -20, 90, 150, 24, hx("#E9F2FF")); box(c, -45, 40, 90, 40, 6, SKYC)
    box(c, -22, -60, 44, 44, 8, WHITE); box(c, 10, -56, 50, 18, 6, WHITE); box(c, -10, -90, 40, 32, 8, NAVY)
    if puff > 0:
        for k in range(8):
            ph = (t * 1.4 + k / 8) % 1; x = 70 + ph * 160; y = -48 + math.sin(k * 2.3) * 60 * ph
            circ(c, x, y, 6 + 20 * ph, WHITE, 0.6 * (1 - ph) * puff)
def warn(c):
    c.move_to(0, -70); c.line_to(76, 60); c.line_to(-76, 60); c.close_path(); sa(c, YEL); c.fill_preserve(); sa(c, INK); c.set_line_width(8); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
    box(c, -7, -30, 14, 56, 6, INK); circ(c, 0, 42, 8, INK)
def helmet(c, col=RED):
    c.new_sub_path(); c.arc(0, 0, 60, math.pi, 0); sa(c, col); c.fill(); box(c, -82, -6, 164, 20, 10, col)
    c.move_to(-14, -58); c.line_to(14, -58); c.line_to(10, -10); c.line_to(-10, -10); c.close_path(); sa(c, YEL); c.fill()
def bar_up(c, u):
    for k, (h, col) in enumerate([(60, WHITE), (95, WHITE), (150, GREEN)]):
        hh = h * (u if k == 2 else 1); box(c, -80 + k * 60, 80 - hh, 44, hh, 8, col, 0.95 if k == 2 else 0.5)
    line(c, [(-90, 40), (-20, 10), (40, -10), (100, -80)], YEL, 9); c.move_to(100, -80); c.line_to(70, -78); c.line_to(96, -52); c.close_path(); sa(c, YEL); c.fill()
def pot(c, t, stir=True):
    box(c, -110, -30, 220, 120, 30, hx("#C9D3E6")); box(c, -130, -40, 260, 24, 12, hx("#AEB9CF"))
    line(c, [(-140, -10), (-165, -10)], INK, 14); line(c, [(140, -10), (165, -10)], INK, 14)
    for k in range(3):
        ph = (t * 0.7 + k / 3) % 1; x = -50 + k * 50
        c.move_to(x, -55 - 10 * ph); c.curve_to(x + 15, -80 - 40 * ph, x - 15, -100 - 50 * ph, x, -130 - 60 * ph); sa(c, WHITE, 0.55 * (1 - ph)); c.set_line_width(8); c.stroke()
    if stir:
        a = t * 4; x = 40 * math.cos(a); line(c, [(x, -40), (x + 60, -170)], hx("#C68B4E"), 14)
def chop(c, t):
    box(c, -150, 30, 300, 40, 12, hx("#D9A066"))
    for k in range(5): circ(c, -110 + k * 32, 22, 15, ORANGE, stroke=hx("#FFFFFF"), sw=3)
    box(c, 30, 0, 120, 30, 15, ORANGE)
    up = abs(math.sin(t * 7)); y = -60 * up
    c.save(); c.translate(10, y - 10)
    c.move_to(-20, 30); c.line_to(80, 30); c.curve_to(80, -10, 20, -30, -20, -30); c.close_path(); sa(c, hx("#E3EAF5")); c.fill()
    box(c, -90, -14, 75, 26, 12, INK); box(c, -120, -30, 50, 56, 24, CREAM)  # handle + hand
    c.restore()
def pan_smoke(c, t):
    line(c, [(110, 30), (220, 10)], INK, 22)
    c.save(); c.scale(1, 0.45); circ(c, 0, 60, 120, hx("#2B2F3A")); circ(c, 0, 60, 100, hx("#3B4050")); c.restore()
    for k in range(7):
        x = -70 + k * 22; circ(c, x, 22 + 6 * math.sin(k), 13, hx("#4A2A10"))
    for k in range(5):
        ph = (t * 0.55 + k / 5) % 1; x = -50 + k * 25 + 30 * math.sin(ph * 6 + k)
        circ(c, x, -20 - 200 * ph, 20 + 30 * ph, hx("#5A5F6E"), 0.65 * (1 - ph))
def long_table(c, t, n=6):
    cols = [PINK, SKYC, GOLD, PURPLE, GREEN, ORANGE]
    for k in range(n):
        x = -250 + k * 100; y = -40 + 6 * math.sin(t * 3 + k)
        c.save(); c.translate(x, y); c.scale(0.55, 0.55); person(c, cols[k % 6], arm=0.4 + 0.3 * math.sin(t * 2 + k)); c.restore()
    box(c, -320, 10, 640, 46, 18, hx("#C68B4E")); box(c, -300, 56, 20, 90, 6, hx("#8A5A2E")); box(c, 280, 56, 20, 90, 6, hx("#8A5A2E"))
    for k in range(5):
        x = -200 + k * 100; c.save(); c.scale(1, 0.35); circ(c, x, 28 / 0.35 + 2, 30, WHITE); c.restore(); circ(c, x, 18, 10, [GREEN, ORANGE, RED][k % 3])
    for k in range(2):
        ph = (t * 0.5 + k / 2) % 1; c.save(); c.translate(-80 + 160 * k, -150 - 60 * ph); heart(c, PINK, 0.35 * (1 - ph * 0.5)); c.restore()
def chef_hat(c):
    for x, y, r in [(-45, -30, 45), (0, -55, 55), (45, -30, 45)]: circ(c, x, y, r, WHITE)
    box(c, -60, -20, 120, 80, 12, WHITE); line(c, [(-60, 40), (60, 40)], hx("#C9D3E6"), 6)
def blocks(c, t, u):
    for k, (x, y, col) in enumerate([(-60, 40, SKYC), (0, 40, PINK), (60, 40, GOLD), (-30, -20, GREEN), (30, -20, PURPLE), (0, -80, ORANGE)]):
        v = ease(u * 6 - k); box(c, x - 28, y - 28 - (1 - v) * 80, 56, 56, 10, col, v)
def plate(c):
    circ(c, 0, 0, 90, WHITE); circ(c, 0, 0, 64, hx("#EEF3FA")); circ(c, -15, -8, 24, ORANGE); circ(c, 20, 10, 20, GREEN); circ(c, 8, -24, 14, RED)
    box(c, -130, -70, 14, 140, 7, hx("#D7DEE9")); box(c, 116, -70, 14, 140, 7, hx("#D7DEE9"))
