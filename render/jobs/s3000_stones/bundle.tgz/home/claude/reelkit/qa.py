"""reelkit qa: contact sheet, ebur128 loudness, ASR of the final audio vs the script (mismatch list), first-frame hook check,
dash check and simple layout checks. Writes OUT_DIR/qa.json and OUT_DIR/qa_sheet.png.
Standalone re-check of a finished reel:  python3 qa.py OUT_DIR   (needs OUT_DIR/reel.mp4 and OUT_DIR/timing.json)"""
import os, sys, re, json, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
DASHES = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015, 0x2E3A, 0x2E3B))
FONT = "/home/claude/vid/fonts/Heebo-700.ttf"

def sheet(thumbs, path, tw=360):
    th = int(tw * 16 / 9); cols = 5 if len(thumbs) > 8 else 4; rows = -(-len(thumbs) // cols)
    im = Image.new("RGB", (cols * (tw + 10) + 10, rows * (th + 50) + 10), (20, 20, 28)); d = ImageDraw.Draw(im); f = ImageFont.truetype(FONT, 34)
    for k, (t, fr) in enumerate(thumbs):
        x = 10 + (k % cols) * (tw + 10); y = 10 + (k // cols) * (th + 50); im.paste(fr.resize((tw, th), Image.LANCZOS), (x, y))
        d.text((x + 4, y + th + 4), f"{t:.2f}s", font=f, fill=(255, 255, 255))
    im.quantize(256, method=Image.Quantize.MEDIANCUT).save(path, optimize=True); return path

def loud(f):
    lo = subprocess.run(["ffmpeg", "-nostats", "-i", f, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", lo)[-1]); TP = float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", lo)[-1])
    LRA = float(re.findall(r"LRA:\s+(-?[\d.]+) LU", lo)[-1])
    pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,codec_name,sample_rate,width,height,r_frame_rate",
                                    "-of", "json", f], capture_output=True, text=True).stdout)
    v = [s for s in pr["streams"] if s["codec_type"] == "video"][0]; a = [s for s in pr["streams"] if s["codec_type"] == "audio"][0]
    return dict(file=os.path.basename(f), dur=round(float(pr["format"]["duration"]), 2), size=f"{v['width']}x{v['height']}", fps=v["r_frame_rate"],
                audio=f"{a['codec_name']} {a['sample_rate']} Hz", I=I, TP=TP, LRA=LRA, mb=round(os.path.getsize(f) / 1e6, 2),
                ok=abs(I + 14) <= 1.0 and TP <= -1.5)

def asr_final(media, tim, log=print):
    import asr as ASR
    x16 = ASR.load16(media); lines = [L["text"] for L in tim["lines"]]
    res, _ = ASR.isolated("check_audio", x16, lines, spans=[(L["t0"], L["t1"]) for L in tim["lines"]], log=log)
    mism = [dict(line=r["line"], heard=r["heard"], missing=r["missing"], extra=r["extra"], recall=r["recall"]) for r in res if r["missing"] or r["extra"]]
    return dict(lines=res, mismatches=mism, mean_recall=round(float(np.mean([r["recall"] for r in res])), 3))

def hook_check(frame0, frame15, frame0_text, scene0_kind):
    a0 = np.asarray(frame0.convert("L"), np.float32); a1 = np.asarray(frame15.convert("L"), np.float32)
    band = np.r_[200:1560]                                                         # content area, subtitle band excluded
    diff = float(np.abs(a0[band] - a1[band]).mean())
    ink = float((np.abs(a0[band] - np.median(a0[band])) > 40).mean())             # share of strongly drawn pixels
    ok = bool(frame0_text) and ink > 0.01 and diff > 0.8
    return dict(ok=ok, frame0_text=frame0_text[:12], ink_share=round(ink, 4), motion_0_to_1_5s=round(diff, 2), scene0=scene0_kind)

def dash_check(rendered, subs, fixes):
    bad = sorted({s for s in list(rendered) + list(subs) if any(d in s for d in DASHES)})
    return dict(ok=not bad, remaining=bad, replaced=[dict(src=a, shown=b) for a, b in sorted(set(fixes))])

def layout_check(QA_text):
    iss = set()
    for sc, s, sz, x0, y0, x1, y1, src in QA_text:
        if x0 < -1000: continue
        if sz < 30: iss.add(("small text", s, round(sz)))
        if x0 < 55 or x1 > 1025: iss.add(("x outside safe area", s, round(x0), round(x1)))
        if (y0 < 205 or y1 > 1565) and not src: iss.add(("y outside safe area", s, round(y0), round(y1)))
    return sorted(iss)

def run_all(out_dir, R, vid_info, mp4, web_mp4, tim, mix_rep, log=print, do_asr=True):
    import render as RD, kit
    rep = dict(video=loud(mp4), web=loud(web_mp4))
    rep["web"]["under_8mb"] = rep["web"]["mb"] < 8.0
    rep["hook"] = hook_check(vid_info["frame0"], vid_info["frame15"], vid_info["frame0_text"], R.scenes[0]["type"])
    rendered = {x[1] for x in kit.QA["text"]}; subs = [x[5] for x in R.subs]
    rep["dashes"] = dash_check(rendered, subs, RD.DASH_LOG)
    rep["layout_issues"] = layout_check(kit.QA["text"])
    last = R.scenes[-1]
    if last["type"] == "cta": rep["cta_hold_s"] = round(R.T_END - last["times"]["keyword"], 2); rep["cta_hold_ok"] = rep["cta_hold_s"] >= 3.0
    rep["scenes"] = [dict(type=S["type"], line=S.get("line"), t0=round(S["t0"], 2), t1=round(S["t1"], 2)) for S in R.scenes]
    rep["subtitles"] = [[round(a, 2), round(b, 2), d] for a, b, _, _, _, d, _ in R.subs]
    rep["warnings"] = R.warn; rep["mix"] = mix_rep
    sheet(vid_info["thumbs"], f"{out_dir}/qa_sheet.png"); rep["sheet"] = f"{out_dir}/qa_sheet.png"
    if do_asr: rep["asr"] = asr_final(mp4, tim, log)
    json.dump(rep, open(f"{out_dir}/qa.json", "w"), indent=1, ensure_ascii=False, default=str)
    return rep

def summary(rep):
    v, w = rep["video"], rep["web"]
    out = [f"video {v['size']} {v['fps']} {v['dur']}s {v['audio']}: {v['I']} LUFS, TP {v['TP']} dBTP, {v['mb']} MB ({'ok' if v['ok'] else 'CHECK'})",
           f"web {w['size']} {w['mb']} MB ({'ok' if w['under_8mb'] else 'OVER 8 MB'}), {w['I']} LUFS, TP {w['TP']}",
           f"hook: {'ok' if rep['hook']['ok'] else 'FAIL'} (frame-0 text {len(rep['hook']['frame0_text'])}, motion {rep['hook']['motion_0_to_1_5s']})",
           f"dashes: {'ok' if rep['dashes']['ok'] else 'FAIL'} ({len(rep['dashes']['replaced'])} replaced)",
           f"layout issues: {len(rep['layout_issues'])}"]
    if "cta_hold_s" in rep: out.append(f"cta hold {rep['cta_hold_s']}s ({'ok' if rep['cta_hold_ok'] else 'SHORT'})")
    if "asr" in rep: out.append(f"asr recall {rep['asr']['mean_recall']}, {len(rep['asr']['mismatches'])} lines with mismatches")
    return "\n".join(out)

if __name__ == "__main__":
    d = sys.argv[1]; tim = json.load(open(f"{d}/timing.json"))
    rep = dict(video=loud(f"{d}/reel.mp4")); rep["asr"] = asr_final(f"{d}/reel.mp4", tim)
    print(json.dumps(rep, indent=1, ensure_ascii=False))
