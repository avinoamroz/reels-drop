"""reelkit voice: raw narration (wav/mp3) in, processed house voice + word timing out.

House chain (same as /home/claude/reelkit/kit.py, shabbat_record vo_p2.wav, safety_v4):
  rubberband pitch 0.9715 (formants preserved) -> bass g=2 f=135 -> clean_vo -> atempo 1.1 -> 0.3 s lead.
Soft-ending restore (the Shabbat Part 2 fix, /home/claude/shabbat_record vo_p2.wav, scratchpad vo/vo_pipe.py "fix"):
  clean_vo sometimes ducks soft word endings as if they were breaths. Before atempo, inside every speech chunk, wherever
  the cleaned signal sits 4 dB or more under the dry chain (high-passed at 90 Hz, zero phase, so sample aligned) while the
  dry signal is real speech (within 40 dB of its speech level), the dry signal is crossfaded back in (15 ms ramps).
  After ASR, any script line that still lost words gets the lost words' neighbourhoods forced back from the full dry chain,
  and only the affected windows are re-checked (kept only if recall improves).
Timing: asr.align_voice (sherpa whisper turbo, 11-16 s windows at pauses, DP to the script lines).
Line selection: select() keeps a subset of script lines, joined at their natural pauses (pause between lines capped).

CLI:  python3 voice.py RAW.wav SCRIPT.txt OUT_DIR [--lines 1,2,3] [--no-restore]
  writes OUT_DIR/vo.wav (48 kHz float mono) and OUT_DIR/timing.json"""
import os, sys, json, time, subprocess
import numpy as np, soundfile as sf
from scipy.signal import butter, sosfiltfilt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clean_vo import clean as clean_vo
import asr as ASR

SR, TEMPO, LEAD = 48000, 1.1, 0.3
PITCH, BASS = "rubberband=pitch=0.9715:formant=preserved", "bass=g=2:f=135"

def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-800:]; return r.stdout
def read_script(path):
    return [l.strip() for l in open(path, encoding="utf-8").read().split("\n") if l.strip()]
def tempo(y):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                              "-f", "f32le", "pipe:1"], np.asarray(y, np.float32).tobytes()), np.float32).astype(np.float64)
def post(y): return np.concatenate([np.zeros(int(LEAD * SR)), tempo(y)])     # pre-tempo signal -> reel time
def pre_t(t): return max(0.0, (t - LEAD) * TEMPO)                              # reel time -> pre-tempo time

def chain_dry(raw_path):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-i", raw_path, "-af", f"{PITCH},{BASS}", "-ar", str(SR), "-ac", "1",
                              "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)

def _speech_spans_pre(dry):
    """speech chunks of the dry chain (pre-tempo seconds), silencedetect -38 dB / 0.22 s"""
    x16 = ASR.to16(dry, SR); return ASR.speech_chunks(x16)
def _ramp_mask(n_samp, spans, r_s=0.015):
    w = np.zeros(n_samp); r = int(r_s * SR)
    for a, b in spans:
        ia, ib = max(0, int(a * SR)), min(n_samp, int(b * SR))
        if ib <= ia: continue
        w[ia:ib] = 1
        lo = max(0, ia - r); w[lo:ia] = np.maximum(w[lo:ia], np.linspace(0, 1, ia - lo))
        hi = min(n_samp, ib + r); w[ib:hi] = np.maximum(w[ib:hi], np.linspace(1, 0, hi - ib))
    return w
def restore_soft(clean, dry, chunks, thr_db=4.0, floor_db=40.0):
    """crossfade the dry chain back wherever clean_vo ducked real speech inside a speech chunk. returns (y, spans)"""
    d = sosfiltfilt(butter(4, 90, "hp", fs=SR, output="sos"), dry)
    hop = int(0.01 * SR); n = len(clean) // hop
    lev = lambda y: 10 * np.log10((y[:n * hop].reshape(n, hop) ** 2).mean(1) + 1e-12)
    Lc, Ld = lev(clean), lev(d); ref = np.percentile(Ld, 95)
    inch = np.zeros(n, bool)
    for a, b in chunks: inch[max(0, int((a - 0.05) * 100)):min(n, int((b + 0.06) * 100))] = True
    m = inch & (Ld - Lc > thr_db) & (Ld > ref - floor_db)
    m = np.convolve(m.astype(float), np.ones(5), "same") > 0
    spans = []; i = 0
    while i < n:
        if m[i]:
            j = i
            while j < n and m[j]: j += 1
            spans.append((i / 100, j / 100)); i = j
        else: i += 1
    w = _ramp_mask(len(clean), spans)
    return clean * (1 - w) + d * w, spans

def process(raw_path, lines, work, restore=True, log=print):
    """full chain + ASR timing. returns dict(vo, timing, report)"""
    os.makedirs(work, exist_ok=True); T0 = time.time()
    dry = chain_dry(raw_path); cl = clean_vo(dry, SR)
    rep = dict(raw=raw_path, chain="rubberband pitch 0.9715 formant preserved, bass g=2 f=135, clean_vo, atempo 1.1, 0.3 s lead")
    if restore:
        chunks = _speech_spans_pre(dry); y, spans = restore_soft(cl, dry, chunks)
        rep["restored_spans"] = len(spans); rep["restored_s"] = round(sum(b - a for a, b in spans), 2)
        log(f"[voice] soft-ending restore: {len(spans)} spans, {rep['restored_s']} s (pre-tempo)")
    else: y = cl
    vo = post(y); log(f"[voice] chain done {time.time() - T0:.1f}s, {len(vo) / SR:.2f}s of voice")
    tim = ASR.isolated("align_voice", vo.astype(np.float32), SR, lines, cache_dir=work, log=log)
    bad = [L for L in tim["lines"] if L["missing"]]
    if restore and bad:
        # force the lost words back from the full dry chain, then re-check only the affected ASR windows
        win = []
        for L in bad:
            for w in tim["words"]:
                if w["line"] == L["i"] and not w["matched"]: win.append((pre_t(w["t0"] - 0.25), pre_t(w["t1"] + 0.3)))
        # only windows where forcing really changes the signal (clean_vo had ducked something there) are re-checked
        dh = sosfiltfilt(butter(4, 90, "hp", fs=SR, output="sos"), dry)
        wf = _ramp_mask(len(y), win); y2 = y * (1 - wf) + dh * wf; vo2 = post(y2)
        redo = set()
        for a, b in win:
            i0, i1 = int(a * SR), int(b * SR)
            d = np.sqrt(np.mean((y2[i0:i1] - y[i0:i1]) ** 2)) / (np.sqrt(np.mean(y[i0:i1] ** 2)) + 1e-12)
            if d > 0.25:   # clean_vo really took something here
                tr = a / TEMPO + LEAD
                redo |= {k for k, W_ in enumerate(tim["windows"]) if W_["t0"] - 0.5 <= tr <= W_["t1"] + 0.5}
        rep["forced"] = dict(windows=[[round(a, 2), round(b, 2)] for a, b in win], rechecked_windows=sorted(redo))
        if redo:
            tim2 = ASR.isolated("align_voice", vo2.astype(np.float32), SR, lines, cache_dir=work, log=log, prev=tim, redo=redo)
            r1 = sum(L["recall"] for L in tim["lines"]); r2 = sum(L["recall"] for L in tim2["lines"])
            rep["forced"].update(recall_before=round(r1, 3), recall_after=round(r2, 3), kept=r2 > r1)
            log(f"[voice] forced restore of {len(win)} word spans: recall {r1:.2f} -> {r2:.2f}" + (" (kept)" if r2 > r1 else " (reverted)"))
            if r2 > r1: vo, tim = vo2, tim2
        else: log(f"[voice] {len(win)} unmatched words are not clean_vo losses (signal unchanged by forcing); no re-check")
    rep["lines"] = [dict(i=L["i"], recall=L["recall"], missing=L["missing"]) for L in tim["lines"]]
    rep["seconds"] = round(time.time() - T0, 1)
    return dict(vo=vo, timing=tim, report=rep)

def select(vo, tim, keep=None, gap_max=0.6, gap_new=0.45, tail=0.0):
    """keep a subset of line indices (0-based, in order). Lines are cut at mid-pause, joined with their natural pause
    (capped at gap_max) or gap_new when the lines were not adjacent. Returns (vo, timing) re-timed."""
    L = tim["lines"]; keep = list(range(len(L))) if keep is None else list(keep)
    dur = len(vo) / SR; pieces = []; out_words = []; out_lines = []; cur = LEAD
    for n_, i in enumerate(keep):
        a, b = L[i]["t0"], L[i]["t1"]
        pa = L[i - 1]["t1"] if i > 0 else max(0.0, a - 0.3); nb = L[i + 1]["t0"] if i + 1 < len(L) else min(dur, b + 0.6)
        c0 = max(pa + (a - pa) / 2, a - 0.15) if i > 0 else max(0.0, a - 0.15)
        c1 = min(b + (nb - b) / 2, b + 0.28)
        if n_ == 0: cur = max(0.0, LEAD - (a - c0))
        else:
            prev = keep[n_ - 1]; nat = a - L[prev]["t1"] if prev == i - 1 else None
            g = min(gap_max, nat) if nat is not None else gap_new
            cur = out_lines[-1]["t1"] + g - (a - c0)
        seg = vo[int(c0 * SR):int(c1 * SR)].copy(); f = int(0.01 * SR)
        seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
        off = cur - c0; pieces.append((cur, seg))
        for w in tim["words"]:
            if w["line"] == i: out_words.append(dict(w, line=n_, src_line=i, t0=round(w["t0"] + off, 3), t1=round(w["t1"] + off, 3)))
        out_lines.append(dict(L[i], i=n_, src_line=i, t0=round(a + off, 3), t1=round(b + off, 3)))
    end = max(t + len(s) / SR for t, s in pieces) + tail
    y = np.zeros(int(end * SR) + 1)
    for t, s in pieces:
        k = int(round(t * SR)); y[k:k + len(s)] += s[:len(y) - k]
    return y, dict(lines=out_lines, words=out_words, dur=round(len(y) / SR, 3), selected=keep)

def write(out_dir, vo, tim, rep=None):
    os.makedirs(out_dir, exist_ok=True)
    sf.write(f"{out_dir}/vo.wav", np.asarray(vo, np.float32), SR, subtype="FLOAT")
    json.dump(dict(tim, report=rep or {}), open(f"{out_dir}/timing.json", "w"), indent=1, ensure_ascii=False)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("raw"); ap.add_argument("script"); ap.add_argument("out")
    ap.add_argument("--lines", help="1-based script lines to keep, e.g. 1,2,3,10"); ap.add_argument("--no-restore", action="store_true")
    A = ap.parse_args(); lines = read_script(A.script)
    r = process(A.raw, lines, os.path.join(A.out, "work"), restore=not A.no_restore)
    keep = [int(x) - 1 for x in A.lines.split(",")] if A.lines else None
    vo, tim = select(r["vo"], r["timing"], keep)
    write(A.out, vo, tim, r["report"]); print(json.dumps(r["report"], indent=1))
