"""reelkit render: declarative 1080x1920 / 30 fps reel renderer driven by a JSON/YAML spec + voice timing (voice.py).

Scene types: title, big_number, bullet_list, cards_grid, bar_race, image, quote, map_highlight, cta.
Each scene is tied to a script line ("line", 1-based, as in the script file) and starts 0.15 s before that line is spoken
(or at "at": phrase). Items inside a scene appear on their words ("at": phrase, or "N:phrase" for another line; when
"at" is missing the item's own text is looked up in the line, else items are spaced evenly).
Look: house silver/white/grey gradient (#F4F5F7 to #D9DDE3), navy #163260, blue #2A88D4, gold #B8923F; Heebo; Hebrew via
python-bidi get_display + PIL BASIC layout (as in /home/claude/reelkit/kit.py and the Shabbat/Guinness renderers).
Burned-in subtitles from the ASR words: short navy pills with a gold outline centred at y=1660.
Hook: scene 0 is fully drawn at frame 0 and moves by 1.5 s. Rendered text never contains en/em dashes (they become commas).
Frames stream straight into ffmpeg (no frame dumps).

CLI preview (no audio, no video):  python3 render.py spec.json timing.json --preview out.png [--times 0,1.5,4]"""
import os, sys, re, math, json, random, subprocess, time
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageOps
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import kit
from kit import W, H, FPS, ease, ramp, lerp, St, sa, rr, line as kline, circ, box, font, is_he, pil2cairo

DASHES = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015, 0x2E3A, 0x2E3B))
SUB_Y = 1660; SOURCE_Y = 1500; TOP = 300; CONTENT_BOTTOM = 1460
LEAD_IN = 0.15            # a scene lands this long before its line is spoken
HOOK_GRACE = 0.6          # in scene 0, anything due before this is already on screen at frame 0
EMOJI_FONT = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"
SUB_FONT = "/root/.fonts/Heebo-ExtraBold.ttf"
GEO = "/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"     # Natural Earth 1:50m, public domain

DEFAULT_PAL = dict(bg0="#F4F5F7", bg1="#D9DDE3", navy="#163260", blue="#2A88D4", gold="#B8923F", gold2="#E6C77E",
                   gold_text="#96702A", grey="#5B6B82", silver="#B9C0CA", red="#D63A4A", green="#1E9E62", amber="#E39B2D",
                   white="#FFFFFF", card="#FFFFFF", sea="#DCE7F3", land="#F3F5F8", border="#AEB8C6")
P = {}; P255 = {}
def set_palette(over=None):
    P.clear(); P255.clear()
    for k, v in dict(DEFAULT_PAL, **(over or {})).items():
        P[k] = kit.hx(v); P255[k] = tuple(int(round(c * 255)) for c in P[k][:3]) + (255,)
set_palette()
def col(name_or_hex, default="navy"):
    if not name_or_hex: name_or_hex = default
    if name_or_hex in P: return P[name_or_hex]
    return kit.hx(name_or_hex)
def c255(cc): return tuple(int(round(v * 255)) for v in cc[:3]) + (255,)

# ------------------------------------------------------------------ text hygiene
DASH_LOG = []
def clean(s):
    """no en/em dashes in rendered text: ' - ' style dashes become commas"""
    if s is None: return ""
    s = str(s); o = s
    for d in DASHES: s = re.sub(rf"\s*{d}\s*", ", ", s)
    s = re.sub(r",\s*,", ",", s); s = re.sub(r"\s+", " ", s).strip()
    if s != o and any(d in o for d in DASHES): DASH_LOG.append((o, s))   # only real dash swaps (not space clean-up)
    return s

# ------------------------------------------------------------------ text drawing
FRAME_TEXT = []           # strings drawn (alpha > 0.5) in the current frame, for the hook check
def T(c, s, sz, x, y, color=None, a=1.0, sc=1.0, w=900, hl=None, maxw=940, anchor="c", src=False):
    s = clean(s)
    if not s: return 0
    if is_he(s): s = s.replace("*", "")
    colr = c255(color or P["navy"]); hlc = c255(hl or P["blue"])
    if a * St.a > 0.5: FRAME_TEXT.append(s.replace("*", ""))
    ww = (700 if w == 900 else w) if is_he(s) else w   # shrink small text to maxw here: kit.tx only shrinks to 56/64 px, then asserts
    while sz > 20 and font(sz, ww).getlength(s.replace("*", "")) > maxw: sz -= 1
    n0 = len(kit.QA["text"])
    r = kit.tx(c, s, sz, x, y, w=w, col=colr, a=a, sc=sc, hl=hlc, shadow=False, maxw=maxw, src=src, anchor=anchor)
    if len(kit.QA["text"]) > n0:   # QA boxes in device (frame) coordinates, so text drawn inside translate/scale is checked where it lands
        q = kit.QA["text"][-1]; (dx0, dy0), (dx1, dy1) = c.user_to_device(q[3], q[4]), c.user_to_device(q[5], q[6])
        k = abs(c.get_matrix()[0]) or 1.0
        if abs(k - 1) > 0.03: kit.QA["text"].pop()      # mid-pop (scaled) frames are not layout evidence
        else: kit.QA["text"][-1] = (q[0], q[1], q[2] * k, min(dx0, dx1), min(dy0, dy1), max(dx0, dx1), max(dy0, dy1), q[7])
    return r


_wc = {}
def wrap(s, sz, w=900, maxw=900, max_lines=3, min_frac=0.68):
    """-> (size, [lines]) : shrink first, then wrap; keeps *highlight* spans balanced on each line"""
    s = clean(s); k = (s, sz, w, maxw, max_lines)
    if k in _wc: return _wc[k]
    he = is_he(s)
    if he: s = s.replace("*", "")
    ww = 700 if (he and w == 900) else w
    words = s.split(" ")
    def lay(z):
        f = font(z, ww); lines = []; cur = []; state = False; starts = []
        for wd in words:
            trial = " ".join(cur + [wd]).replace("*", "")
            if cur and f.getlength(trial) > maxw:
                lines.append((cur, starts[-1] if starts else False)); cur = []
            if not cur: starts.append(state)
            cur.append(wd); state ^= (wd.count("*") % 2 == 1)
        if cur: lines.append((cur, starts[-1]))
        out = []
        for ws, st in lines:
            txt = " ".join(ws); n = txt.count("*") + (1 if st else 0)
            if st: txt = "*" + txt
            if n % 2: txt += "*"
            out.append(txt)
        return out
    z = sz; best = None
    while z >= sz * min_frac:
        ls = lay(z)
        if len(ls) == 1 or (len(ls) <= max_lines and z <= sz * 0.9) or len(ls) <= max_lines and all(font(z, ww).getlength(l.replace("*", "")) <= maxw for l in ls) and z == sz:
            best = (z, ls)
            if len(ls) <= max_lines: break
        z -= 2
    if best is None or len(best[1]) > max_lines: best = (int(sz * min_frac), lay(int(sz * min_frac)))
    _wc[k] = best; return best
def block(c, s, sz, x, y, color=None, a=1.0, sc=1.0, w=900, hl=None, maxw=900, max_lines=3, lh=1.14, anchor="c"):
    """multi-line text centred on (x, y); returns its height"""
    if not s: return 0
    z, ls = wrap(s, sz, w, maxw, max_lines); step = z * lh; h = step * len(ls)
    if a <= 0.005: return h
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    for k, l in enumerate(ls):
        T(c, l, z, x, y - h / 2 + step * (k + 0.5), color, a, 1.0, w, hl, maxw + 4, anchor)
    c.restore(); return h
def block_h(s, sz, w=900, maxw=900, max_lines=3, lh=1.14):
    if not s: return 0
    z, ls = wrap(s, sz, w, maxw, max_lines); return z * lh * len(ls)

# ------------------------------------------------------------------ emoji / flags / images
_ec = {}
def flag_emoji(code): return "".join(chr(0x1F1E6 + ord(ch) - 65) for ch in code.upper()[:2])
def emoji_surf(e, px):
    k = (e, int(px))
    if k not in _ec:
        f = ImageFont.truetype(EMOJI_FONT, 109, layout_engine=ImageFont.Layout.RAQM)
        im = Image.new("RGBA", (420, 180), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.text((10, 10), e, font=f, embedded_color=True)
        bb = im.getbbox() or (0, 0, 1, 1); im = im.crop(bb); s = px / max(im.size)
        im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
        _ec[k] = (pil2cairo(im), im.width, im.height)
    return _ec[k]
def draw_emoji(c, e, x, y, px, a=1.0, sc=1.0, rot=0.0):
    if not e or a * St.a <= 0.01 or sc <= 0.01: return
    s, w_, h_ = emoji_surf(e, px)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc); c.set_source_surface(s, -w_ / 2, -h_ / 2); c.paint_with_alpha(min(1, a * St.a)); c.restore()
def icon_of(it):
    if it.get("flag"): return flag_emoji(it["flag"])
    return it.get("icon") or it.get("emoji")
_ic = {}
def image_surf(path, w, h, radius=0):
    k = (path, int(w), int(h), radius)
    if k not in _ic:
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGBA"); im = ImageOps.fit(im, (int(w), int(h)), Image.LANCZOS)
        if radius:
            m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, im.width - 1, im.height - 1], radius, fill=255); im.putalpha(m)
        _ic[k] = pil2cairo(im)
    return _ic[k]

# ------------------------------------------------------------------ small drawn pieces
def shadow_box(c, x, y, w, h, r, fill, a=1.0, stroke=None, sw=4, sh=12):
    sa(c, P["navy"], 0.10 * a); rr(c, x + 3, y + sh, w, h, r); c.fill()
    box(c, x, y, w, h, r, fill, a, stroke=stroke, sw=sw)
def diamond(c, x, y, s, cc, a=1.0):
    c.save(); c.translate(x, y); c.rotate(math.pi / 4); sa(c, cc, a); c.rectangle(-s / 2, -s / 2, s, s); c.fill(); c.restore()
def pill(c, s, sz, x, y, bg, fg, a=1.0, sc=1.0, outline=None, w=900, padx=0.6, padh=1.5):
    s = clean(s)
    if a * St.a <= 0.01 or sc <= 0.01: return 0
    f = font(sz, 700 if is_he(s) else w); tw = min(f.getlength(s.replace("*", "")), 900); pw = tw + sz * padx * 2; ph = sz * padh
    c.save(); c.translate(x, y); c.scale(sc, sc)
    sa(c, P["navy"], 0.16 * a); rr(c, -pw / 2, -ph / 2 + 8, pw, ph, ph / 2); c.fill()
    box(c, -pw / 2, -ph / 2, pw, ph, ph / 2, bg, a, stroke=outline, sw=5)
    c.restore()
    T(c, s, sz, x, y + 2 * sc, fg, a, sc, w, maxw=920); return pw
def hand_down(c):   # pointing-down hand (from /home/claude/guinness_il/v2.py via shabbat_render_v2.py)
    g = cairo.LinearGradient(-60, -100, 60, 100); g.add_color_stop_rgb(0, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
    box(c, -40, -120, 80, 34, 10, P["blue"])
    rr(c, -58, -92, 116, 96, 34); c.set_source(g); c.fill_preserve(); sa(c, kit.hx("#8E6E2A")); c.set_line_width(5); c.stroke()
    for k in range(3): kline(c, [(-30 + k * 26, -10), (-30 + k * 26, -40)], kit.hx("#8E6E2A"), 4)
    rr(c, -20, -20, 40, 130, 20); c.set_source(g); c.fill_preserve(); sa(c, kit.hx("#8E6E2A")); c.set_line_width(5); c.stroke()
    box(c, -10, 84, 20, 16, 7, P["white"], a=0.8)
def quote_marks(c):  # gold quote marks (shabbat_render_v2.py)
    for sx in (-34, 34):
        circ(c, sx, 0, 28, P["gold"]); c.move_to(sx + 10, 18); c.curve_to(sx + 26, 50, sx - 4, 84, sx - 26, 92)
        c.curve_to(sx - 6, 70, sx - 4, 46, sx - 10, 24); c.close_path(); sa(c, P["gold"]); c.fill()
def icon(c, x, y, s, fn, a=1.0):
    if a <= 0.01 or abs(s) < 1e-3: return
    c.save(); c.translate(x, y); c.scale(s, s); old = St.a; St.a *= a; fn(c); St.a = old; c.restore()
def count(t, t0, d, v0, v1, log=False):
    if t < t0: return v0
    u = ease(min(1.0, (t - t0) / d))
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def fmt(v, dec=0): return f"{v:,.{dec}f}"

# ------------------------------------------------------------------ background (house silver, from shabbat_render_v2.py)
_bg = {}
def background(c, t):
    if "base" not in _bg:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(s)
        g = cairo.LinearGradient(0, 0, W * 0.4, H); g.add_color_stop_rgb(0, *P["bg0"][:3]); g.add_color_stop_rgb(1, *P["bg1"][:3])
        cc.set_source(g); cc.paint(); _bg["base"] = s
        R = random.Random(3); _bg["sp"] = [(R.uniform(40, 1040), R.uniform(0, H), R.uniform(6, 13), R.uniform(14, 30), R.random() * 6) for _ in range(24)]
        gl = cairo.ImageSurface(cairo.FORMAT_ARGB32, 1200, 1200); gc = cairo.Context(gl)
        rg = cairo.RadialGradient(600, 600, 0, 600, 600, 600); rg.add_color_stop_rgba(0, 1, 1, 1, 0.75); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        gc.set_source(rg); gc.paint(); _bg["glow"] = gl
    c.set_source_surface(_bg["base"], 0, 0); c.paint()
    for k, (bx, by, br) in enumerate([(300, 520, 560), (820, 1350, 620)]):
        x = bx + 60 * math.sin(t * 0.25 + k * 2); y = by + 50 * math.cos(t * 0.3 + k); s = br / 600
        c.save(); c.translate(x - br, y - br); c.scale(s, s); c.set_source_surface(_bg["glow"], 0, 0); c.paint(); c.restore()
    for k, (x0, y0, r, sp, ph) in enumerate(_bg["sp"]):
        y = (y0 - t * sp) % (H + 60) - 30; x = x0 + 14 * math.sin(t * 0.7 + k); tw = 0.5 + 0.5 * math.sin(t * 2 + ph)
        diamond(c, x, y, r, P["silver"] if k % 4 else P["gold"], 0.35 + 0.35 * tw)

# ------------------------------------------------------------------ timing
def norm_w(w): return re.sub(r"[^a-z0-9']", "", w.lower().replace("’", "'"))
class Timeline:
    def __init__(s, tim):
        s.lines = tim["lines"]; s.words = tim["words"]; s.dur = tim["dur"]
        s.src = {L.get("src_line", L["i"]): L["i"] for L in s.lines}
    def li(s, line):
        """1-based script line -> index in this (possibly trimmed) timeline"""
        assert line - 1 in s.src, f"script line {line} is not in the selected voice lines"
        return s.src[line - 1]
    def start(s, line): return s.lines[s.li(line)]["t0"]
    def end(s, line): return s.lines[s.li(line)]["t1"]
    def at(s, line, phrase, end=False):
        """time a phrase starts (or ends) in a line; phrase may be 'N:phrase' to use another line. None if not found"""
        if isinstance(phrase, (int, float)): return float(phrase)
        m = re.match(r"^(\d+):(.*)$", phrase or "")
        if m: line, phrase = int(m.group(1)), m.group(2)
        i = s.li(line); ws = [w for w in s.words if w["line"] == i]
        q = [norm_w(x) for x in clean(phrase).replace("*", "").split() if norm_w(x)]
        if not q: return None
        nw = [norm_w(w["w"]) for w in ws]
        for k in range(len(ws) - len(q) + 1):
            if all(nw[k + j] == q[j] or (j == len(q) - 1 and nw[k + j].startswith(q[j])) for j in range(len(q))):
                return ws[k + len(q) - 1]["t1"] if end else ws[k]["t0"]
        return None

# ------------------------------------------------------------------ subtitles (vosubs.py pieces, navy pill + gold outline)
def sub_pieces(TL, replace=(), maxw_words=6):
    out = []
    for i, L in enumerate(TL.lines):
        ws = [w for w in TL.words if w["line"] == i]
        units = []; k = 0; nw = [norm_w(w["w"]) for w in ws]
        reps = [([norm_w(x) for x in a.split() if norm_w(x)], b) for a, b in replace]
        while k < len(ws):
            hit = None
            for q, b in reps:
                if q and nw[k:k + len(q)] == q: hit = (len(q), b); break
            if hit:
                n, b = hit; tail = re.sub(r"^.*?([.,?!:;]*)$", r"\1", ws[k + n - 1]["w"])
                units.append(dict(w=b + tail, t0=ws[k]["t0"], t1=ws[k + n - 1]["t1"])); k += n
            else: units.append(dict(w=ws[k]["w"], t0=ws[k]["t0"], t1=ws[k]["t1"])); k += 1
        cur = []
        def flush():
            if not cur: return
            n = len(cur); kk = max(1, -(-n // maxw_words)); size = -(-n // kk)
            for j in range(0, n, size):
                g = cur[j:j + size]; out.append([g[0]["t0"], g[-1]["t1"], " ".join(u["w"] for u in g)])
            cur.clear()
        for u in units:
            cur.append(u)
            if re.search(r"[.?!:,;]$", u["w"]): flush()
        flush()
    merged = []
    for it in out:   # one-word fragment -> previous piece of the same sentence when short
        if merged and len(it[2].split()) == 1 and len(merged[-1][2].split()) <= 4 and not re.search(r"[.?!]$", merged[-1][2]) and it[0] - merged[-1][1] < 0.4:
            merged[-1][1] = it[1]; merged[-1][2] += " " + it[2]
        else: merged.append(it)
    for a, b in zip(merged, merged[1:]):
        if b[0] - a[1] < 0.5: a[1] = b[0]
        else: a[1] += 0.25
    if merged: merged[-1][1] += 0.6
    return [(a, b, clean(re.sub(r"[,;:]$", "", d.strip()))) for a, b, d in merged]
def sub_surfs(pieces, sz=50, maxw=900):
    F = ImageFont.truetype(SUB_FONT, sz); out = []
    for t0, t1, d in pieces:
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 26
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=24, fill=P255["navy"][:3] + (232,), outline=P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 13 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        out.append((t0, t1, pil2cairo(im), (W - Wd) // 2, int(SUB_Y - Hd / 2), d, Hd))
    return out
def draw_subs(c, t, items):
    for t0, t1, surf, x, y, _, _ in items:
        if t0 <= t < t1:
            a = min(1.0, (t - t0) / 0.08, (t1 - t) / 0.08)
            c.set_source_surface(surf, x, y); c.paint_with_alpha(max(0, min(1, a)))

# ------------------------------------------------------------------ scene helpers
def PP(t, t0, S, d=0.45, s0=0.15, bounce=2.0):
    """pop (alpha, scale); scene 0 items due inside HOOK_GRACE are fully on screen at frame 0"""
    if t0 is None: return 0.0, 0.0
    if S.get("hook") and t0 <= HOOK_GRACE: return 1.0, 1.0
    return kit.pop(t, t0, d, s0, bounce)
def fade_in(t, t0, S, d=0.3):
    if S.get("hook") and t0 <= HOOK_GRACE: return 1.0
    return ramp(t, t0, t0 + d)
def heading(c, t, S, y=TOP):
    """scene heading EN (+HE); returns the y below it"""
    en, he = S.get("title") or S.get("heading"), S.get("title_he") or S.get("heading_he")
    if not en and not he: return y - 40
    a, s = PP(t, S["t0"] + 0.05, S); h1 = block_h(en, 74, 900, 940, 2)
    block(c, en, 74, 540, y + h1 / 2 - 37, P["navy"], a, s, hl=col(S.get("hl"), "blue"), maxw=940, max_lines=2)
    yy = y + h1 - 37 + 14
    if he:
        a, s = PP(t, S["t0"] + 0.2, S); h2 = block_h(he, 56, 700, 940, 2)
        block(c, he, 56, 540, yy + h2 / 2, P["blue"], a, s, w=700, maxw=940, max_lines=2); yy += h2
    return yy + 24
def source(c, t, S):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + S.get("source_delay", 0.6), S)
    z, ls = wrap(s, 34, 700, 940, 2, 0.85)
    for k, l in enumerate(ls): T(c, l, z, 540, SOURCE_Y - 22 * (len(ls) - 1) + 44 * k, P["grey"], a, 1.0, 700, src=True)
def series_chip(c, t, S, y=250):
    sp = S["_spec"].get("series") or {}
    if not sp: return
    a, s = PP(t, S["t0"], S)
    if sp.get("en"): pill(c, sp["en"], 36, 540, y, P["gold"], P["white"], a, s, w=800)
    if sp.get("he"): T(c, sp["he"], 40, 540, y + 64, P["navy"], a, s, w=700)

# ------------------------------------------------------------------ scenes
def sc_title(c, t, S):
    hook = S.get("hook"); series = hook or S.get("chip")
    if series: series_chip(c, t, S)
    en, he, sub, sub_he = S.get("en"), S.get("he"), S.get("sub"), S.get("sub_he")
    em = icon_of(S)
    h_en = block_h(en, S.get("size", 100), 900, 940, 3); h_he = block_h(he, 62, 700, 940, 2)
    h_sub = block_h(sub, 62, 900, 940, 2) + (block_h(sub_he, 52, 700, 940, 2) if sub_he else 0)
    total = (230 if em else 0) + h_en + 40 + h_he + (60 + h_sub if sub else 0)
    y = max(450 if series else 330, (330 + 1420) / 2 - total / 2)
    t0 = S["t0"]
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 100 + 10 * math.sin(t * 2.6), 190, a, s * (1 + 0.03 * math.sin(t * 3.1)))
        y += 230
    a, s = PP(t, t0 + 0.08, S); breath = 1 + 0.012 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, S.get("size", 100), 540, y + h_en / 2, P["navy"], a, s * breath, hl=col(S.get("hl"), "blue"), maxw=940, max_lines=3)
    y += h_en
    # gold underline sweep (gives the hook motion right away)
    u = ease((t - (t0 + 0.15)) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 330 * u, y + 6, 660 * u, 12, 6, P["gold"], a)
    y += 40
    a, s = PP(t, t0 + 0.25, S); block(c, he, 62, 540, y + h_he / 2, P["blue"], a, s, w=700, maxw=940, max_lines=2); y += h_he
    if sub:
        ts = S["times"].get("sub", t0 + 0.8); y += 60
        a, s = PP(t, ts, S); hs = block_h(sub, 62, 900, 940, 2)
        block(c, sub, 62, 540, y + hs / 2, P["navy"], a, s, hl=col(S.get("hl2"), "gold_text"), maxw=940, max_lines=2); y += hs
        if sub_he:
            a, s = PP(t, ts + 0.25, S); hh = block_h(sub_he, 52, 700, 940, 2); block(c, sub_he, 52, 540, y + hh / 2 + 6, P["blue"], a, s, w=700, maxw=940)
    source(c, t, S)

def sc_big_number(c, t, S):
    y = heading(c, t, S)
    steps = S["steps"]; ts = S["times"]["steps"]
    cy = max(y + 350, 840); x0, x1, y0, y1 = 100, 980, cy - 320, cy + 320
    a, s = PP(t, S["t0"] + 0.1, S, s0=0.6, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
    shadow_box(c, x0, y0, x1 - x0, y1 - y0, 30, P["card"], stroke=P["navy"], sw=6)
    rr(c, x0 + 16, y0 + 16, x1 - x0 - 32, y1 - y0 - 32, 18); sa(c, P["blue"]); c.set_line_width(2); c.stroke()
    for px, py in ((x0 + 16, y0 + 16), (x1 - 16, y0 + 16), (x0 + 16, y1 - 16), (x1 - 16, y1 - 16)): diamond(c, px, py, 16, P["gold"])
    # current value: count between steps
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0])
    st = steps[k]; dec = st.get("decimals", 0)
    if k == 0: v = count(t, ts[0], st.get("dur", 1.2), st.get("from", 0), st["value"]) if not (S.get("hook") and ts[0] <= HOOK_GRACE) else st["value"]
    else:
        pv = steps[k - 1]["value"]; big = max(abs(pv), abs(st["value"])) / max(1e-9, min(abs(pv), abs(st["value"]))) > 20
        v = count(t, ts[k], st.get("dur", 1.3), pv, st["value"], log=big)
    if t < ts[0] - 0.05 and not (S.get("hook") and ts[0] <= HOOK_GRACE): v = st.get("from", 0)
    lab = clean(f"{st.get('prefix', '')}{fmt(v, dec)}{st.get('suffix', '')}")
    T(c, lab, S.get("size", 200), 540, cy - 70, col(st.get("color"), "blue"), 1.0, 1.0, 900, maxw=820)
    pa = ramp(t, ts[k] - 0.05, ts[k] + 0.25) if k else 1.0
    T(c, st.get("label", ""), 60, 540, cy + 95, P["navy"], pa, 1.0, 800, hl=P["gold_text"], maxw=800)
    if st.get("he"): T(c, st["he"], 52, 540, cy + 180, P["gold_text"], pa, 1.0, 700, maxw=800)
    c.restore(); St.a = old
    if S.get("note"):
        a, s = PP(t, S["times"].get("note", S["t0"] + 1.5), S, bounce=2.4)
        pill(c, S["note"], 46, 540, y1 + 110, col(S.get("note_color"), "navy"), P["white"], a, s, outline=P["gold"])
        if S.get("note_he"): T(c, S["note_he"], 46, 540, y1 + 200, P["navy"], a, s, w=700)
    source(c, t, S)

def sc_bullet_list(c, t, S):
    y = heading(c, t, S); items = S["items"]; ts = S["times"]["items"]; n = len(items)
    foot = S.get("footer"); room_ = CONTENT_BOTTOM - y - (170 if foot else 20)
    rh = min(128, room_ / max(1, n)); bh = rh - 18
    for k, it in enumerate(items):
        tk = ts[k]
        if t < tk - 0.07 and not (S.get("hook") and tk <= HOOK_GRACE): continue
        a = fade_in(t, tk - 0.07, S, 0.2); u = 1.0 if (S.get("hook") and tk <= HOOK_GRACE) else ease((t - tk + 0.07) / 0.35)
        yy = y + rh * k + rh / 2; dx = 260 * (1 - u)
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, 110, yy - bh / 2, 860, bh, bh / 2.6, P["card"], stroke=col(it.get("color"), "silver"), sw=3, sh=6)
        em = icon_of(it); x_text = 190
        if em: draw_emoji(c, em, 180, yy, bh * 0.62); x_text = 238
        T(c, it.get("en", ""), min(58, bh * 0.52), x_text, yy + 2, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=420 if it.get("he") else 700, anchor="l")
        if it.get("he"): T(c, it["he"], min(50, bh * 0.45), 935, yy + 2, P["gold_text"], 1.0, 1.0, 700, maxw=300, anchor="r")
        c.restore(); St.a = old
    if foot:
        tf = S["times"].get("footer", ts[-1] + 0.8 if ts else S["t0"] + 1)
        a, s = PP(t, tf, S, bounce=2.4); yy = y + rh * n + 80
        pill(c, foot.get("en", ""), 52, 540, yy, col(foot.get("color"), "red"), P["white"], a, s, w=900)
        if foot.get("he"): T(c, foot["he"], 48, 540, yy + 88, col(foot.get("color"), "red"), a, s, w=700)
    source(c, t, S)

def sc_cards_grid(c, t, S):
    y = heading(c, t, S) + 10; cards = S["cards"]; ts = S["times"]["cards"]; n = len(cards)
    cols = S.get("cols", 2 if n <= 4 else 3); rows = -(-n // cols)
    gap = 28; cw = (900 - gap * (cols - 1)) / cols; avail = CONTENT_BOTTOM - y - 10
    ch = min(cw * 1.6, (avail - gap * (rows - 1)) / rows)
    for k, cd in enumerate(cards):
        r_, q = divmod(k, cols); in_row = min(cols, n - r_ * cols)
        x0 = 90 + (900 - (in_row * cw + (in_row - 1) * gap)) / 2 + q * (cw + gap); y0 = y + r_ * (ch + gap)
        a, s = PP(t, ts[k], S, s0=0.5, bounce=1.6)
        if a <= 0.01: continue
        cx, cy = x0 + cw / 2, y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(cx, cy); c.scale(s, s); c.translate(-cx, -cy)
        shadow_box(c, x0, y0, cw, ch, 26, P["card"], stroke=col(cd.get("color"), "navy"), sw=4)
        yy = y0 + ch * 0.06; isz = min(cw, ch) * 0.30
        if cd.get("image"):
            c.set_source_surface(image_surf(cd["image"], cw - 40, ch * 0.38, 18), x0 + 20, yy); c.paint_with_alpha(St.a); yy += ch * 0.38 + 8
        elif icon_of(cd): draw_emoji(c, icon_of(cd), cx, yy + isz / 2 + 4, isz, rot=0.04 * math.sin(t * 2 + k)); yy += isz + 14
        if cd.get("value"): T(c, cd["value"], min(78, cw * 0.2), cx, yy + 40, col(cd.get("value_color"), "blue"), 1, 1, 900, maxw=cw - 30); yy += 86
        hl_ = block_h(cd.get("label"), 42, 800, cw - 36, 2); block(c, cd.get("label"), 42, cx, yy + hl_ / 2, P["navy"], 1, 1, 800, maxw=cw - 36, max_lines=2); yy += hl_ + 6
        if cd.get("he"): hh = block_h(cd["he"], 38, 700, cw - 36, 2); block(c, cd["he"], 38, cx, yy + hh / 2, P["gold_text"], 1, 1, 700, maxw=cw - 36, max_lines=2)
        c.restore(); St.a = old
    source(c, t, S)

def sc_bar_race(c, t, S):
    y = heading(c, t, S)
    if S.get("unit"): T(c, S["unit"], 40, 540, y + 6, P["grey"], fade_in(t, S["t0"] + 0.3, S), 1, 700); y += 50
    bars = S["bars"]; ts = S["times"]["bars"]; n = len(bars)
    vmax = S.get("max") or max(b["value"] for b in bars) * 1.08
    X0, XM = 110, 960; room_ = CONTENT_BOTTOM - y - 30; rh = min(190, room_ / max(1, n))
    cur = []
    for k, b in enumerate(bars):
        hk = S.get("hook") and ts[k] <= HOOK_GRACE
        v = b["value"] if hk else count(t, ts[k] + 0.1, b.get("dur", 1.1), b.get("from", 0), b["value"])
        cur.append(v if (t >= ts[k] - 0.05 or hk) else None)
    order = list(range(n))
    if S.get("sort"):
        vis = [k for k in range(n) if cur[k] is not None]; order = sorted(vis, key=lambda k: -cur[k]) + [k for k in range(n) if cur[k] is None]
    rank = {k: r_ for r_, k in enumerate(order)}
    if "_rank" not in S: S["_rank"] = {k: float(k) for k in range(n)}
    for k in range(n):   # positions glide to their rank
        S["_rank"][k] += (rank[k] - S["_rank"][k]) * 0.25
    for k, b in enumerate(bars):
        if cur[k] is None: continue
        a = fade_in(t, ts[k] - 0.05, S, 0.2); old = St.a; St.a *= a
        yy = y + rh * S["_rank"][k] + 30; em = icon_of(b); xl = X0
        if em: draw_emoji(c, em, X0 + 34, yy + 4, 56); xl = X0 + 76
        T(c, b.get("label", ""), 50, xl, yy + 4, P["navy"], 1, 1, 800, anchor="l", maxw=560)
        if b.get("he"): T(c, b["he"], 44, XM, yy + 4, P["gold_text"], 1, 1, 700, anchor="r", maxw=330)
        bw = max(64, (XM - X0) * cur[k] / vmax); bc = col(b.get("color"), "navy" if k == n - 1 else "blue")
        box(c, X0, yy + 44, bw, 72, 36, bc)
        lab = clean(f"{b.get('prefix', '')}{fmt(cur[k], b.get('decimals', 0))}{b.get('suffix', '')}")
        if font(50, 900).getlength(lab) + 48 < bw: T(c, lab, 50, X0 + bw - 24, yy + 81, P["white"], 1, 1, 900, anchor="r")
        else: T(c, lab, 50, X0 + bw + 16, yy + 81, P["navy"], 1, 1, 900, anchor="l")
        St.a = old
    if S.get("note"):
        a, s = PP(t, S["times"].get("note", ts[-1] + 1.0), S, bounce=2.4)
        yy = y + rh * n + 70
        pill(c, S["note"], 44, 540, min(yy, 1400), col(S.get("note_color"), "gold"), P["white"], a, s)
        if S.get("note_he"): T(c, S["note_he"], 44, 540, min(yy, 1400) + 82, P["navy"], a, s, w=700)
    source(c, t, S)

def sc_image(c, t, S):
    y = heading(c, t, S) if (S.get("title") or S.get("title_he")) else 300
    cap_h = (block_h(S.get("caption"), 62, 900, 940, 2) + block_h(S.get("caption_he"), 52, 700, 940, 2) + 40) if (S.get("caption") or S.get("caption_he")) else 0
    x0, x1, y0, y1 = 80, 1000, y, CONTENT_BOTTOM - cap_h - 20
    pw, ph = x1 - x0, y1 - y0
    a = fade_in(t, S["t0"], S, 0.3)
    dur = max(1.0, S["t1"] - S["t0"]); u = min(1.0, max(0.0, (t - S["t0"]) / dur))
    z0, z1 = S.get("zoom", [1.0, 1.14]); z = lerp(z0, z1, u); dx, dy = S.get("pan", [-0.04, -0.03])
    old = St.a; St.a *= a
    sa(c, P["navy"], 0.12); rr(c, x0 + 3, y0 + 14, pw, ph, 30); c.fill()
    c.save(); rr(c, x0, y0, pw, ph, 30); c.clip()
    surf = image_surf(S["src"], pw * 1.2, ph * 1.2)
    c.translate(x0 + pw / 2 + dx * pw * u, y0 + ph / 2 + dy * ph * u); c.scale(z / 1.2, z / 1.2)
    c.set_source_surface(surf, -pw * 0.6, -ph * 0.6); c.paint_with_alpha(St.a); c.restore()
    rr(c, x0, y0, pw, ph, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    St.a = old
    yy = y1 + 40
    if S.get("caption"):
        a, s = PP(t, S["times"].get("caption", S["t0"] + 0.3), S); hc = block_h(S["caption"], 62, 900, 940, 2)
        block(c, S["caption"], 62, 540, yy + hc / 2, P["navy"], a, s, hl=col(S.get("hl"), "blue"), maxw=940, max_lines=2); yy += hc
    if S.get("caption_he"):
        a, s = PP(t, S["times"].get("caption", S["t0"] + 0.3) + 0.25, S); hh = block_h(S["caption_he"], 52, 700, 940, 2)
        block(c, S["caption_he"], 52, 540, yy + hh / 2 + 4, P["blue"], a, s, w=700, maxw=940)
    source(c, t, S)

def sc_quote(c, t, S):
    t0 = S["t0"]; y = 380
    a, s = PP(t, t0 + 0.05, S); icon(c, 540, y, 1.2 * s, quote_marks, a=a); y += 170
    parts = S["quote"] if isinstance(S["quote"], list) else [S["quote"]]; ts = S["times"]["quote"]
    for k, q in enumerate(parts):
        hq = block_h(q, S.get("size", 80), 900, 920, 3); a, s = PP(t, ts[k], S)
        block(c, q, S.get("size", 80), 540, y + hq / 2, P["navy"], a, s, hl=col(S.get("hl"), "gold_text"), maxw=920, max_lines=3); y += hq + 6
    y += 30
    ta = S["times"].get("author", ts[-1] + 0.4)
    if S.get("author"):
        a, s = PP(t, ta, S); box(c, 440, y - 4, 200 * a, 6, 3, P["gold"], a); y += 50
        T(c, S["author"], 54, 540, y, P["blue"], a, s, 800, maxw=900); y += 80
    if S.get("he"):
        a, s = PP(t, ta + 0.3, S); hh = block_h(S["he"], 56, 700, 920, 3)
        block(c, S["he"], 56, 540, y + hh / 2, P["navy"], a, s, w=700, maxw=920); y += hh + 10
    if S.get("author_he"): a, s = PP(t, ta + 0.4, S); T(c, S["author_he"], 48, 540, y + 30, P["gold_text"], a, s, 700)
    source(c, t, S)

# ---- map (Natural Earth 1:50m via /home/claude/bro_meter/geo, Israel + Judea/Samaria/Gaza as one gold land like safety_v4)
_geo = {}
def geo():
    if "c" not in _geo:
        from shapely.geometry import shape
        d = json.load(open(GEO)); C = {}
        for f in d["features"]:
            p = f["properties"]; iso = p.get("ISO_A2") if p.get("ISO_A2") not in (None, "-99") else p.get("ADM0_A3")
            C[iso] = dict(name=p.get("NAME"), he=p.get("NAME_HE"), g=shape(f["geometry"]), a3=p.get("ADM0_A3"))
        _geo["c"] = C
    return _geo["c"]
VIEWS = {"middle_east": [-10, 10, 62, 44], "israel": [33.6, 29.3, 36.6, 33.5], "world": [-170, -58, 180, 80],
         "europe": [-12, 34, 42, 66], "us": [-126, 23, -65, 50]}
class MapView:
    def __init__(s, view, box_):
        s.lon0, s.lat0, s.lon1, s.lat1 = VIEWS.get(view, view) if isinstance(view, str) else view
        s.x0, s.y0, s.x1, s.y1 = box_; s.cos = math.cos(math.radians((s.lat0 + s.lat1) / 2))
        sx = (s.x1 - s.x0) / ((s.lon1 - s.lon0) * s.cos); sy = (s.y1 - s.y0) / (s.lat1 - s.lat0); s.k = min(sx, sy)   # contain
        s.cx, s.cy = (s.lon0 + s.lon1) / 2, (s.lat0 + s.lat1) / 2
    def P(s, lon, lat): return ((s.x0 + s.x1) / 2 + (lon - s.cx) * s.cos * s.k, (s.y0 + s.y1) / 2 - (lat - s.cy) * s.k)
    def rings(s, g, tol):
        from shapely.geometry import box as sbox
        m = 4; vb = sbox(s.lon0 - m, s.lat0 - m, s.lon1 + m, s.lat1 + m)
        if not g.intersects(vb): return []
        g = g.intersection(vb).simplify(tol / s.k)
        ps = [g] if g.geom_type == "Polygon" else [p for p in getattr(g, "geoms", []) if p.geom_type == "Polygon"]
        return [np.array([s.P(x, y) for x, y in p.exterior.coords]) for p in ps if not p.is_empty]
def _main_poly(g):
    return max(g.geoms, key=lambda p: p.area) if g.geom_type == "MultiPolygon" else g
def auto_view(isos, box_, pad=0.12):
    """bounds of the highlighted countries (main landmass each) + pad, widened to the panel's aspect"""
    G = geo(); bs = [_main_poly(G[i]["g"]).bounds for i in isos if i in G]
    lon0 = min(b[0] for b in bs); lat0 = min(b[1] for b in bs); lon1 = max(b[2] for b in bs); lat1 = max(b[3] for b in bs)
    cos = math.cos(math.radians((lat0 + lat1) / 2)); w = (lon1 - lon0) * cos; h = lat1 - lat0
    w, h = w * (1 + 2 * pad), h * (1 + 2 * pad); ar = (box_[2] - box_[0]) / (box_[3] - box_[1])
    if w / h < ar: w = h * ar
    else: h = w / ar
    cx, cy = (lon0 + lon1) / 2, (lat0 + lat1) / 2
    return [cx - w / cos / 2, cy - h / 2, cx + w / cos / 2, cy + h / 2]
def _path(c, rings):
    for r in rings:
        c.move_to(*r[0])
        for x, y in r[1:]: c.line_to(x, y)
        c.close_path()
def sc_map_highlight(c, t, S):
    y = heading(c, t, S); box_ = (60, y, 1020, CONTENT_BOTTOM - 20)
    if "_mv" not in S:
        _sa_keep = St.a; St.a = 1.0   # build the cached base at full alpha (it was baked in mid fade-in, 27 Oct fix)
        G = geo(); view = S.get("view", "auto")
        if view == "auto": view = auto_view([h["iso"] for h in S["highlights"]] + ["IL"], box_, S.get("pad", 0.12))
        mv = MapView(view, box_); S["_mv"] = mv
        base = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); bc = cairo.Context(base)
        bc.rectangle(0, 0, W, H); sa(bc, P["sea"]); bc.fill()
        isr = [k for k in ("IL", "PS") if k in G]
        for k, v in G.items():
            rg = mv.rings(v["g"], 0.6)
            if not rg: continue
            _path(bc, rg); sa(bc, P["gold"] if (k in isr and S.get("israel_gold", True)) else P["land"]); bc.fill_preserve()
            sa(bc, P["border"]); bc.set_line_width(1.6); bc.stroke()
        if "PS" in G and S.get("israel_gold", True):   # Green Line: green dashed outline of Judea/Samaria and Gaza (house rule)
            rg = mv.rings(G["PS"]["g"], 0.3)
            if rg:
                _path(bc, rg); sa(bc, P["green"]); bc.set_line_width(4); bc.set_dash([10, 6]); bc.stroke(); bc.set_dash([])
        S["_base"] = base
        St.a = _sa_keep
        S["_hl"] = [(mv.rings(G[h["iso"]]["g"], 0.4), h) for h in S["highlights"] if h["iso"] in G]
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a = fade_in(t, S["t0"], S, 0.3); old = St.a; St.a *= a
    sa(c, P["navy"], 0.12); rr(c, x0 + 3, y0 + 14, x1 - x0, y1 - y0, 30); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    u = min(1.0, max(0.0, (t - S["t0"]) / max(1.0, S["t1"] - S["t0"]))); z = lerp(1.0, S.get("zoom", 1.06), ease(u))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(S["_base"], 0, 0); c.paint_with_alpha(St.a)
    ts = S["times"]["highlights"]; labels = []
    for k, (rg, h) in enumerate(S["_hl"]):
        hk = S.get("hook") and ts[k] <= HOOK_GRACE
        u = 1.0 if hk else ramp(t, ts[k] - 0.05, ts[k] + 0.3)
        if u <= 0.01: continue
        pulse = 0.15 * max(0.0, 1 - (t - ts[k]) / 0.6) if not hk else 0
        _path(c, rg); sa(c, col(h.get("color"), "red"), (0.85 + pulse) * u); c.fill_preserve(); sa(c, P["white"], u); c.set_line_width(2.2 / z); c.stroke()
        labels.append((k, h, u))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(6); c.stroke()
    G = geo()
    if "_lab" not in S:   # label anchors, pushed apart once (greedy, vertical) so chips do not overlap
        placed = []; S["_lab"] = {}
        for k, (rg, h) in enumerate(S["_hl"]):
            lon, lat = h.get("at_lonlat") or (lambda p: (p.x, p.y))(_main_poly(G[h["iso"]]["g"]).representative_point())
            px, py = mv.P(lon, lat); px = min(max(px, 190), 890); py = min(max(py, y0 + 50), y1 - 100)
            free = lambda x, y: not any(abs(q[0] - x) < 240 and abs(q[1] - y) < 96 for q in placed)
            if not free(px, py):
                opts = [(px + dx, py + dy) for r_ in (100, 200, 300) for dx, dy in ((0, r_), (0, -r_), (r_ * 1.6, 0), (-r_ * 1.6, 0), (r_, r_), (-r_, r_), (r_, -r_), (-r_, -r_))]
                opts = [(min(max(x, 190), 890), min(max(y, y0 + 50), y1 - 100)) for x, y in opts]
                px, py = next((o for o in opts if free(*o)), (px, py))
            placed.append((px, py)); S["_lab"][k] = (px, py)
    for k, h, u in labels:   # labels drawn unclipped, on top
        if h.get("label") is False: continue
        px, py = S["_lab"][k]; px = cx + (px - cx) * z; py = cy + (py - cy) * z
        en = h.get("en") or G[h["iso"]]["name"]; he = h.get("he") or G[h["iso"]]["he"]
        a2, s2 = PP(t, ts[k] + 0.1, S)
        pill(c, en, 36, px, py, P["white"], P["navy"], a2, s2, outline=col(h.get("color"), "red"), w=800, padh=1.4)
        if he: T(c, he, 32, px, py + 50, P["navy"], a2, s2, 700, maxw=300)
    St.a = old
    if S.get("legend"): T(c, S["legend"], 38, 540, y1 + 2 - 30, P["grey"], a, 1, 700, maxw=900)
    source(c, t, S)

def sc_cta(c, t, S):
    t0 = S["t0"]; y = 370; sp = S["_spec"]
    if S.get("en"):
        a, s = PP(t, t0 + 0.05, S); he_ = block_h(S["en"], 76, 900, 940, 2); block(c, S["en"], 76, 540, y + he_ / 2 - 38, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=2); y += he_ - 38 + 20
    if S.get("he"):
        a, s = PP(t, t0 + 0.2, S); hh = block_h(S["he"], 58, 700, 940, 2); block(c, S["he"], 58, 540, y + hh / 2, P["blue"], a, s, w=700); y += hh + 60
    kw = clean(S.get("keyword", "")); tk = S["times"]["keyword"]
    a, s = PP(t, tk - 0.25, S); T(c, S.get("comment_word", "Comment"), 72, 540, y + 40, P["navy"], a, s); y += 120
    a, s = PP(t, tk - 0.05, S, bounce=2.4)
    if a > 0.01 and kw:
        z = 140; f = font(z, 900)
        while f.getlength(kw) > 760: z -= 4; f = font(z, 900)
        pw = f.getlength(kw) + 130; ph = z * 1.58; yy = y + ph / 2
        c.save(); c.translate(540, yy); c.scale(s, s); old = St.a; St.a *= a
        sa(c, P["navy"], 0.18); rr(c, -pw / 2, -ph / 2 + 12, pw, ph, ph / 2); c.fill()
        g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *P["gold"][:3]); g.add_color_stop_rgb(0.5, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
        rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, P["navy"]); c.set_line_width(7); c.stroke()
        St.a = old; c.restore()
        T(c, kw, z, 540, yy + 4, P["navy"], a, s)
        y += ph + 40
    else: y += 260
    ha = fade_in(t, tk + 0.1, S, 0.2); icon(c, 540, y + 50 + 12 * math.sin(t * 7), 0.6, hand_down, a=ha); y += 190
    if S.get("keyword_he"): a, s = PP(t, tk + 0.15, S); T(c, S["keyword_he"], 60, 540, y, P["blue"], a, s, 700); y += 110
    tl = S["times"].get("link", tk + 0.35)
    if S.get("link"): a, s = PP(t, tl, S); pill(c, S["link"], 46, 540, y + 20, P["navy"], P["white"], a, s, w=800); y += 110
    acct = S.get("follow") or (f"Follow {sp['account']}" if sp.get("account") else None)
    if acct:
        a, s = PP(t, tl + 0.25, S); T(c, acct, 56, 540, y + 10, P["navy"], a, s, 800, hl=P["gold_text"]); y += 76
        if S.get("follow_he"): T(c, S["follow_he"], 46, 540, y + 6, P["gold_text"], a, s, 700)
    source(c, t, S)

SCENES = dict(title=sc_title, big_number=sc_big_number, bullet_list=sc_bullet_list, cards_grid=sc_cards_grid, bar_race=sc_bar_race,
              image=sc_image, quote=sc_quote, map_highlight=sc_map_highlight, cta=sc_cta)

# ------------------------------------------------------------------ build the timeline from the spec
def load_spec(path):
    txt = open(path, encoding="utf-8").read()
    if path.endswith((".yml", ".yaml")):
        import yaml; d = yaml.safe_load(txt)
    else: d = json.loads(txt)
    d["_dir"] = os.path.dirname(os.path.abspath(path)); return d

def load_scene_module(spec):
    """spec "scene_module": a .py file (path relative to the spec, or absolute) whose sc_<name>(c, t, S) functions are added
    to SCENES as scene type <name>. They get the same S as built-in scenes, with S["times"][mark] for every "marks" entry."""
    m = spec.get("scene_module")
    if not m: return
    import importlib.util
    p = m if os.path.isabs(m) else os.path.join(spec.get("_dir", "."), m)
    sp_ = importlib.util.spec_from_file_location(os.path.splitext(os.path.basename(p))[0], p); mod = importlib.util.module_from_spec(sp_)
    sp_.loader.exec_module(mod)
    for k, v in vars(mod).items():
        if k.startswith("sc_") and callable(v): SCENES[k[3:]] = v

class Reel:
    def __init__(s, spec, tim):
        s.spec = spec; set_palette(spec.get("palette")); _bg.clear(); load_scene_module(spec)
        s.TL = Timeline(tim); s.scenes = []; s.warn = []
        for k, sc in enumerate(spec["scenes"]):
            assert sc["type"] in SCENES, f"unknown scene type {sc['type']}"
            S = dict(sc); S["_spec"] = spec; S["hook"] = k == 0; ln = sc.get("line")
            if k == 0: t0 = 0.0
            elif sc.get("at") is not None: t0 = (s.TL.at(ln, sc["at"]) or s.TL.start(ln)) - LEAD_IN
            else: t0 = s.TL.start(ln) - LEAD_IN
            S["t0"] = max(0.0, t0); s.scenes.append(S)
        for a, b in zip(s.scenes, s.scenes[1:]): assert b["t0"] > a["t0"], f"scenes out of order at line {b.get('line')}"
        for k, S in enumerate(s.scenes):
            S["t1"] = s.scenes[k + 1]["t0"] if k + 1 < len(s.scenes) else None
        s.resolve_items()
        last = s.scenes[-1]; vo_end = s.TL.dur
        hold = max(3.0, float(spec.get("cta_hold", 3.2)))
        end = vo_end + float(spec.get("tail", 0.8))
        if last["type"] == "cta": end = max(end, last["times"]["keyword"] + hold)
        s.T_END = math.ceil(end * FPS) / FPS; last["t1"] = s.T_END
        s.subs = sub_surfs(sub_pieces(s.TL, spec.get("subs_replace", [])))
    def _t(s, S, phrase, fallback, line=None):
        ln = line or S.get("line")
        if phrase is None: return fallback
        v = s.TL.at(ln, phrase)
        if v is None: s.warn.append(f"phrase not found in line {ln}: {phrase!r}"); return fallback
        return v - 0.08
    def _seq(s, S, items, key_text, t_from, t_to):
        """item times: its 'at' phrase, else its 'word' / own text (key_text, label, en, country name) found in the line,
        else evenly spaced between t_from and t_to"""
        n = len(items); out = []; used = S["t0"] - 0.2
        for k, it in enumerate(items):
            even = lerp(t_from, t_to, k / max(1, n - 1)) if n > 1 else t_from
            if it.get("at") is not None: out.append(s._t(S, it["at"], even)); continue
            cands = [it.get("word"), it.get(key_text) if key_text else None, it.get("en"), it.get("label")]
            if it.get("iso"):
                g = geo().get(it["iso"]); cands.append(g["name"] if g else None)
            v = None
            for cnd in cands:
                if not cnd or not str(cnd).strip(): continue
                w0 = clean(str(cnd)).replace("*", "").split()
                for L in (len(w0), 1):
                    v = s.TL.at(S.get("line"), " ".join(w0[:L]))
                    if v is not None and v >= used: break
                    v = None
                if v is not None: break
            if v is not None: used = v; out.append(v - 0.08)
            else: out.append(even)
        for k in range(1, n): out[k] = max(out[k], out[k - 1] + 0.12)
        return out
    def resolve_items(s):
        for S in s.scenes:
            t0 = S["t0"]; t1 = S["t1"] if S["t1"] is not None else t0 + 4.0; tm = {}
            ty = S["type"]
            if ty == "title": tm["sub"] = s._t(S, S.get("sub_at"), t0 + 0.9)
            if ty == "big_number":
                st = S.get("steps") or [dict(value=S["value"], label=S.get("label", ""), he=S.get("he"), at=S.get("value_at"),
                                             prefix=S.get("prefix", ""), suffix=S.get("suffix", ""), decimals=S.get("decimals", 0), **({"from": S["from"]} if "from" in S else {}))]
                S["steps"] = st; tm["steps"] = [s._t(S, x.get("at"), t0 + 0.3 + 1.6 * k) for k, x in enumerate(st)]
                tm["note"] = s._t(S, S.get("note_at"), tm["steps"][-1] + 1.4)
            if ty == "bullet_list":
                tm["items"] = s._seq(S, S["items"], "en", t0 + 0.4, max(t0 + 0.6, t1 - 1.2))
                f = S.get("footer"); tm["footer"] = s._t(S, (f or {}).get("at"), (tm["items"][-1] if tm["items"] else t0) + 0.8)
            if ty == "cards_grid": tm["cards"] = s._seq(S, S["cards"], None, t0 + 0.3, max(t0 + 0.5, t1 - 1.2))
            if ty == "bar_race":
                tm["bars"] = s._seq(S, S["bars"], None, t0 + 0.3, max(t0 + 0.5, t1 - 1.6)); tm["note"] = s._t(S, S.get("note_at"), tm["bars"][-1] + 1.2)
            if ty == "image": tm["caption"] = s._t(S, S.get("caption_at"), t0 + 0.3)
            if ty == "quote":
                q = S["quote"] if isinstance(S["quote"], list) else [S["quote"]]; ats = S.get("quote_at") or [None] * len(q)
                tm["quote"] = [s._t(S, ats[k], t0 + 0.15 + 0.9 * k) for k in range(len(q))]; tm["author"] = s._t(S, S.get("author_at"), tm["quote"][-1] + 0.5)
            if ty == "map_highlight": tm["highlights"] = s._seq(S, S["highlights"], "en", t0 + 0.3, max(t0 + 0.5, t1 - 1.0))
            if ty == "cta":
                tm["keyword"] = s._t(S, S.get("keyword_at") or S.get("keyword"), t0 + 0.6); tm["link"] = s._t(S, S.get("link_at"), tm["keyword"] + 0.35)
            for name, ph in (S.get("marks") or {}).items():   # generic named times for any scene type ("N:phrase" for another line)
                tm[name] = s._t(S, ph, t0 + 0.3)
            if S["hook"]:   # frame 0 must already show the hook
                for k_, v in tm.items():
                    if isinstance(v, list): tm[k_] = [x for x in v]
            S["times"] = tm

    # -------------------------------------------------------------- frames
    def draw(s, c, t):
        kit.CUR["t"] = t; FRAME_TEXT.clear()
        background(c, t)
        for i, S in enumerate(s.scenes):
            a0 = S["t0"]; a1 = S["t1"]
            if t < a0 - 0.01 or t > a1 + 0.25: continue
            al = (1.0 if i == 0 else ramp(t, a0, a0 + 0.2)) * (1 - ramp(t, a1, a1 + 0.22) if i + 1 < len(s.scenes) else 1.0)
            if al <= 0.01: continue
            kit.CUR["scene"] = i; St.a = al; SCENES[S["type"]](c, t, S); St.a = 1.0
        kit.CUR["scene"] = None
        draw_subs(c, t, s.subs)
    def keytimes(s):
        ks = [0.0, 1.5]
        for S in s.scenes:
            d = S["t1"] - S["t0"]; ks += [S["t0"] + 0.75 * d]
        ks += [s.T_END - 0.05]
        return sorted(set(round(min(max(0, x), s.T_END - 1 / FPS), 2) for x in ks))
    def sfx_events(s):
        """(t, kind) : whoosh on scene starts, pop on items, ding on the CTA keyword"""
        cfg = s.spec.get("sfx", True)
        if not cfg: return []
        ev = []
        for k, S in enumerate(s.scenes):
            if k: ev.append((S["t0"] + 0.02, "whoosh"))
            for key in ("items", "cards", "bars", "highlights"):
                for x in S["times"].get(key, []):
                    if not (S["hook"] and x <= HOOK_GRACE): ev.append((x, "pop"))
            for name in S.get("pops", []):
                if name in S["times"]: ev.append((S["times"][name], "pop"))
            if S["type"] == "cta": ev.append((S["times"]["keyword"] - 0.03, "ding"))
            if S["type"] == "big_number":
                for x in S["times"]["steps"][1:]: ev.append((x, "pop"))
        return sorted(ev)

def surf2pil(surf):
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data()); return Image.fromarray(a[:, :, [2, 1, 0]].copy())
def render_video(R, wav, out_mp4, log=print, preset="fast", crf=21):
    """stream frames into ffmpeg (x264) + the mix; returns dict(thumbs, frame0, frame15, frame0_text, sec)"""
    T0 = time.time(); N = int(round(R.T_END * FPS))
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    cmd = ["nice", "-n", "10", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "pipe:0", "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-tune", "animation",
           "-maxrate", "6M", "-bufsize", "8M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
           "-t", f"{N / FPS:.3f}", "-movflags", "+faststart", out_mp4]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); kt = R.keytimes(); tset = {int(round(x * FPS)): x for x in kt}
    th = []; f0 = f15 = None; f0_text = []
    for fi in range(N):
        t = fi / FPS; R.draw(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi == 0: f0 = surf2pil(surf); f0_text = list(FRAME_TEXT)
        if fi == int(1.5 * FPS): f15 = surf2pil(surf)
        if fi in tset: th.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 150 == 0: log(f"[render] frame {fi}/{N}  {time.time() - T0:.0f}s")
    p.stdin.close(); assert p.wait() == 0, "ffmpeg failed"
    return dict(thumbs=th, frame0=f0, frame15=f15, frame0_text=f0_text, sec=round(time.time() - T0, 1), frames=N)
def preview(R, times, path):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); th = []
    for t in times: R.draw(c, t); th.append((t, surf2pil(surf)))
    import qa; qa.sheet(th, path)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument("spec"); ap.add_argument("timing"); ap.add_argument("--preview", required=True); ap.add_argument("--times")
    A = ap.parse_args(); R = Reel(load_spec(A.spec), json.load(open(A.timing)))
    ts = [float(x) for x in A.times.split(",")] if A.times else R.keytimes()
    preview(R, ts, A.preview); print("T_END", R.T_END, "warnings", R.warn, "dash fixes", DASH_LOG)
