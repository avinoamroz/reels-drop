"""Reel v2: "This is the first joke I ever heard in Russian." (@expressenglishcom, collab @noamroz__)
Same silver/navy look as russian_army.py (imported: look overrides, drawings, helpers).
Changes vs v1: silent hook card at frame 0, then Noam's REAL voice for the joke (Smeshno? / A diskoteka?) and for
"I served in Mamram." (from his m4a, natural speed, light high-pass + presence EQ + level match, no atempo/pitch).
The Cartesia narration keeps the v1 chain (rubberband pitch, bass, clean_vo, atempo 1.1) and is cut from vo/raw.wav by ASR chunks.
Order: hook > joke (real) > dad joke / crying laughing (TTS) > Mamram (real) > Everyone spoke Russian (TTS) > I wanted in ... CTA.
usage: python3 russian_army_v2.py [--preview [t1,t2,..]] [--vo-wav]"""
import sys; sys.path.insert(0, "/home/claude/reelkit")
import russian_army as R1
from russian_army import *
import kit
from kit import run, SR, TEMPO, GAPCAP, clean_vo, subchunks, subclean, SUB_BOTTOM, DASHES, W, FPS
import numpy as np, json, os, re

D = "/home/claude/russian_army"
REC = "/mnt/user-data/attachments/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/7954d8cf-Russian_jokes.m4a"
SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
NAME = "russian_army_v2"
REAL_AF = "highpass=f=80,equalizer=f=350:t=o:w=1:g=-1.5,equalizer=f=1400:t=o:w=1:g=2,equalizer=f=3600:t=o:w=1.6:g=6"
HOOK = 1.85          # hook card alone under music
# real clips in the recording (s). The take starts mid-word: the "С" of Смешно is missing (ASR hears "Мешно"),
# so his own /s/ from "served" (take 2) is spliced in front.
S_FIX = (5.285, 5.415); SMESH = (0.0, 0.60); DISKO = (0.985, 1.84); MAMRAM = (3.30, 4.43)  # take 1 (tighter, cleaner end)

def act_rms(y):
    n = 480; e = np.array([np.sqrt((y[i:i + n] ** 2).mean()) for i in range(0, len(y) - n, n)]); e = e[e > e.max() * 10 ** (-30 / 20)]
    return 20 * np.log10(np.sqrt((e ** 2).mean()))
def fade(y, fi, fo):
    y = y.copy(); a = int(fi * SR); b = int(fo * SR)
    if a: y[:a] *= np.linspace(0, 1, a)
    if b: y[-b:] *= np.linspace(1, 0, b)
    return y

class ReelV2(kit.Reel):
    def __init__(s, tail=2.6):
        s.D = D; s.name = NAME; s.nums = (); s.tail = tail
        J = json.load(open(f"{D}/vo/asr.json")); s.CH = J["chunks"]
        tl = [l.strip() for l in open(f"{D}/tts_v4.txt") if l.strip()]; seg = J["segs"]
        def ks(i): return [k for k, cc in enumerate(s.CH) if cc[0] >= seg[i][0] - 0.02 and cc[1] <= seg[i][1] + 0.02]
        # (kind, text, tts chunk ids | real clip key, gap before (s))
        s.spec = [("real", "Смешно?", "smesh", None), ("real", "А дискотека?", "disko", None),
                  ("tts", tl[5], ks(5), 0.15),("real", "I served in Mamram.", "mamram", 0.45),
                  ("tts", tl[2], ks(2), 1.1)] + [("tts", tl[i], ks(i), GAPCAP if i > 6 else 0.6) for i in range(6, 15)]
        s.lines = [x[1] for x in s.spec]
        s.clean = [x[1] if x[0] == "real" else subclean(x[1]) for x in s.spec]
    def real_clips(s):
        y = np.frombuffer(run(["ffmpeg", "-v", "error", "-i", REC, "-af", REAL_AF, "-ac", "1", "-ar", str(SR), "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
        cut = lambda a, b: y[int(a * SR):int(b * SR)].copy()
        sfx = fade(cut(*S_FIX), 0.02, 0.03) * 0.6; body = fade(cut(*SMESH), 0.006, 0.12); ov = int(0.03 * SR)
        sm = np.zeros(len(sfx) + len(body) - ov); sm[:len(sfx)] += sfx; sm[len(sfx) - ov:] += body
        C = {"smesh": sm, "disko": fade(cut(*DISKO), 0.02, 0.10), "mamram": fade(cut(*MAMRAM), 0.02, 0.08)}
        return C
    def build_vo(s):
        raw = run(["ffmpeg", "-v", "error", "-i", f"{D}/vo/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                   "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"])
        x = np.frombuffer(raw, np.float32).astype(np.float64); x = clean_vo(x, SR).astype(np.float32)
        x = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                               "-f", "f32le", "pipe:1"], x.tobytes()), np.float32).astype(np.float64)
        C = s.real_clips()
        ref = act_rms(x[int(0.3 * SR):]); g = 10 ** ((ref - act_rms(np.concatenate(list(C.values())))) / 20)
        s.real_gain_db = round(20 * np.log10(g), 2)
        for k in C: C[k] = C[k] * g
        # speech on/offset inside each real clip (for subtitle / scene timing)
        def on_off(y):
            n = 240; e = np.array([np.sqrt((y[i:i + n] ** 2).mean()) for i in range(0, len(y) - n, n)]); th = e.max() * 10 ** (-28 / 20)
            idx = np.where(e > th)[0]; return idx[0] * n / SR, (idx[-1] + 1) * n / SR
        CH = s.CH; n = len(CH); pieces = []; s.lmap = []; cur = None; s.real_span = {}
        # fixed opening timing (joke)
        starts = {0: HOOK + 0.25, 1: None}
        for i, (kind, text, ref_, gap) in enumerate(s.spec):
            if kind == "real":
                y = C[ref_]; a, b = on_off(y)
                if i == 0: st = starts[0] - a
                elif i == 1: st = s.T_NO + 0.95 - a        # beat for "No." then the disco
                else: st = cur + gap - a
                pieces.append((st, y)); s.lmap.append([(0.0, st + a), (1.0, st + b)]); s.real_span[ref_] = (st + a, st + b)
                cur = st + b
                if i == 0: s.T_NO = cur + 0.40              # "No." lands after a short beat
                if i == 1: cur += 0.35                      # let the disco land before the narration
            else:
                pts = []; L = [max(1, len(CH[k][2])) for k in ref_]; tot = sum(L); acc = 0; prev_en = None
                for j, k in enumerate(ref_):
                    a, b, _ = CH[k]
                    pb = CH[k - 1][1] if k else a - 0.3; na = CH[k + 1][0] if k < n - 1 else b + 0.6
                    a0 = max(a - 0.06, (pb + a) / 2) if k else max(0, a - 0.06); b0 = min(b + 0.14, (b + na) / 2)
                    seg = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR)
                    seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
                    st = (cur + gap) if j == 0 else prev_en + min(GAPCAP, (a - CH[k - 1][1]) / TEMPO)
                    en = st + (b - a) / TEMPO; prev_en = en
                    pieces.append((st - (a - a0) / TEMPO, seg))
                    pts.append((acc / tot, st)); acc += L[j]; pts.append((acc / tot, en))
                s.lmap.append(pts); cur = prev_en
        s.T_END = cur + s.tail
        yv = np.zeros(int(s.T_END * SR) + SR)
        for t0, seg in pieces: i = int(t0 * SR); yv[i:i + len(seg)] += seg
        s.vo = yv[:int(s.T_END * SR)]
        s.lspan = [(p[0][1], p[-1][1]) for p in s.lmap]
        print(NAME, "VO", round(s.T_END, 2), "s; real gain", s.real_gain_db, "dB; lines", [(round(a, 2), round(b, 2)) for a, b in s.lspan])
    def subs(s):
        items = []
        for i, l in enumerate(s.clean):
            cs = [l] if s.spec[i][0] == "real" else subchunks(l); L = len(l); pos = 0
            for cc in cs:
                p0 = l.find(cc, pos); p1 = p0 + len(cc); pos = p1
                items.append([s.ft(i, p0 / L), s.ft(i, p1 / L), cc])
        for a, b in zip(items, items[1:]):
            if b[0] - a[1] < 0.45: a[1] = b[0]
        out = []
        for a, b, cc in items:
            assert not any(d in cc for d in DASHES)
            cyr = bool(re.search("[Ѐ-ӿ]", cc))
            F = R1._IF.truetype(kit.FONTS["cyr"] if cyr else '/root/.fonts/Heebo-ExtraBold.ttf', 54)
            w = cc.split(); lines = []; cur = ''
            for x in w:
                tr = (cur + ' ' + x).strip()
                if F.getlength(tr) <= 920: cur = tr
                else: lines.append(cur); cur = x
            lines.append(cur); lh = 66; Wd = int(max(F.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
            im = R1._Im.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = R1._IDr.Draw(im)
            d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(22, 50, 96, 238))
            for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor='mm')
            out.append((a, b, pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd, cc))
        s.sub_items = out; return out

# ------------------------------------------------------------------ scenes
def build(r):
    A = r.at; S = []
    def add(t0, fn, **kw): S.append(dict(t0=t0, pal="navy", fn=fn, **kw))
    SM0, SM1 = r.real_span["smesh"]; DK0, DK1 = r.real_span["disko"]; MM0, MM1 = r.real_span["mamram"]

    def hook(c, t, sc):  # fully visible at frame 0, no pop-in
        T(c, "This is the", 104, 350); T(c, "*first joke*", 150, 490)
        T(c, "I ever heard", 104, 630); T(c, "in *Russian.*", 140, 770)
        icon(c, 540, 1040 + 6 * math.sin(t * 2), 0.82, one_finger, t, 0.0, r=170)
        HE(c, "זו הבדיחה הראשונה ששמעתי ברוסית", 1345, sz=60)
    add(-1, hook)

    def finger_sc(c, t, sc):
        a, s = P(t, SM0 - 0.08)
        if a > 0:
            c.save(); c.translate(540, 400); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.08); rr(c, -330, -110 + 10, 660, 220, 70); c.fill()
            box(c, -330, -110, 660, 220, 70, PAPER, stroke=LINEG, sw=3)
            c.move_to(-30, 108); c.line_to(0, 160); c.line_to(30, 108); c.close_path(); sa(c, PAPER); c.fill(); St.a = old; c.restore()
        RU(c, "Смешно?", 130, 395, a, s)
        a, s = P(t, SM0 + 0.3); pill(c, "Is it *funny?*", 72, 540, 590, PAPER, N255, a, s, outline=LINEG)
        rise = ramp(t, sc["t0"], sc["t0"] + 0.35)
        icon(c, 460, 930 + 260 * (1 - ease(rise)), 1.1, one_finger, t, rise, r=170)
        a, s = P(t, r.T_NO); pill(c, "No.", 110, 810, 820, NAVY, WH, a, s)
        a, s = P(t, r.T_NO + 0.12); HE(c, "מצחיק? לא.", 1385, a, s)
    add(HOOK, finger_sc)

    def disco(c, t, sc):
        t0 = sc["t0"]; up = ramp(t, t0, t0 + 0.4)
        sa(c, NAVY, 0.10); c.paint()
        for k in range(9):
            ang = t * 0.8 + k * 2 * math.pi / 9; x = 540 + 420 * math.cos(ang * 1.2 + k); y = 950 + 520 * math.sin(ang + k * 0.7)
            col = DISCO[k % 6]; rg = cairo.RadialGradient(x, y, 0, x, y, 190); rg.add_color_stop_rgba(0, *col[:3], 0.42 * St.a * up + 0.12 * St.a)
            rg.add_color_stop_rgba(1, *col[:3], 0); c.set_source(rg); c.arc(x, y, 190, 0, 2 * math.pi); c.fill()
            c.move_to(540, 330); c.line_to(x - 70, y); c.line_to(x + 70, y); c.close_path(); sa(c, col, 0.07 * up); c.fill()
        a, s = P(t, t0); icon(c, 540, 315 + 4 * math.sin(t * 2), 0.9 * s, disco_ball, t, a=a)
        a, s = P(t, DK0 - 0.05)
        if a > 0: card(c, 120, 425, 840, 260, a, 40)
        RU(c, "А дискотека?", 116, 512, a, s)
        a2, s2 = P(t, DK0 + 0.45); pill(c, "And the *disco?*", 64, 540, 622, NAVY, WH, a2 * (a > 0), s2)
        bob = 16 * abs(math.sin(math.pi * t / BEAT)) * up
        icon(c, 540, 940 - bob, 1.08, dancing_hand, t, up, a=1.0, rot=0.05 * up * math.sin(math.pi * t / BEAT), r=175)
        a, s = P(t, A(2, "a total")); pill(c, "A total *dad joke*", 76, 540, 1300, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, DK0 + 0.6)
        if a > 0: HE(c, "ודיסקוטק? בדיחת אבא קלאסית", 1398, a, s, 58)
    add(DK0 - 0.3, disco)

    def laugh(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "They were", 96, 340, a, s)
        T(c, "*crying laughing*", 110, 455, a, s)
        for k, (x, y, col) in enumerate([(230, 800, SLATE), (850, 800, SLATE), (380, 760, hx("#7B8DAA")), (700, 760, hx("#7B8DAA"))]):
            a2, s2 = P(t, sc["t0"] + 0.1 * k); jig = 10 * abs(math.sin(t * 14 + k))
            icon(c, x, y - jig, 0.8 * s2, bust, col, 0.07 * math.sin(t * 16 + k * 1.3), a=a2)
        for k, (x, y) in enumerate([(200, 600), (880, 590), (420, 560), (660, 600)]):
            a2, s2 = P(t, sc["t0"] + 0.3 + 0.15 * k)
            icon(c, x + 5 * math.sin(t * 20 + k), y, s2, bubble, "ХА ХА", 44, PAPER, N255, 1 if x < 540 else -1, a=a2)
        a, s = P(t, A(2, "and i didn't")); icon(c, 540, 1000, s, bust, NAVY, a=a, r=120)
        if a > 0: icon(c, 540, 820 - 6 * math.sin(t * 3), s, lambda c: dtxf(c, "?", 100, B255, 900), a=a)
        pill(c, "And I didn't get it.", 72, 540, 1205, NAVY, WH, a, s)
        a, s = P(t, A(2, "and i didn't") + 0.2); HE(c, "הם בכו מצחוק. ואני לא הבנתי", 1335, a, s)
    add(A(2, "but they") - 0.12, laugh)

    def army(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "I served in", 110, 340, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 540, 690, 0.95 * s, desk, t, ramp(t, sc["t0"], sc["t0"] + 2.0), a=a, r=200)
        km = MM0 + 0.45 * (MM1 - MM0)   # "Mamram" in his take
        a, s = P(t, km); icon(c, 890, 510, 0.7 * s, badge, a=a, r=100)
        T(c, "*Mamram.*", 140, 1045, a, s)
        a, s = P(t, km + 0.2); pill(c, "Mamram: the IDF's computing unit", 50, 540, 1180, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, km + 0.35); HE(c, "שירתתי בממר״ם, יחידת המחשב", 1310, a, s, 60)
    add(A(2, end=True) + 0.15, army)

    BUB = R1.__dict__.get("BUB") or [("Привет!", 220, 650, 1), ("Как дела?", 860, 640, -1), ("Давай, давай!", 250, 1010, 1), ("Ну что?", 850, 980, -1), ("Слушай!", 560, 1240, 1), ("Короче...", 230, 1180, 1)]
    def chatter(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Everyone around me", 84, 330, a, s)
        a, s = P(t, A(4, "spoke")); T(c, "spoke *Russian*", 120, 440, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 540, 900, 1.15 * s, bust, NAVY, a=a, r=130)
        for k, (w, x, y, tl) in enumerate(BUB):
            a2, s2 = P(t, sc["t0"] + 0.15 + 0.22 * k)
            icon(c, x, y + 8 * math.sin(t * 2 + k), s2, bubble, w, 48, NAVY if k % 3 == 1 else PAPER, WH if k % 3 == 1 else N255, tl, a=a2)
        a, s = P(t, A(4, "russian")); icon(c, 540, 720, s, lambda c: dtxf(c, "?", 90, B255, 900), a=a)
        a, s = P(t, A(4, "russian") + 0.2); HE(c, "כולם מסביבי דיברו רוסית", 1360, a, s)
    add(A(4) - 0.15, chatter)

    FLY = [("слово", (-120, 560)), ("смешно", (1200, 620)), ("друг", (-140, 1150)), ("слушай", (1220, 1180)), ("давай", (-120, 820)), ("привет", (1200, 900))]
    def words(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "I wanted *in.*", 130, 360, a, s)
        a, s = P(t, sc["t0"] + 0.15); tts = [A(5, "asked"), A(5, "words"), A(6, "repeated"), A(6, "shadowed"), A(6, "built"), A(6, "sentences")]
        landed = sum(1 for x in tts if t > x + 0.7) * 2
        icon(c, 540, 790, 1.0 * s, notebook, landed, a=a, r=180)
        for k, ((w, (fx, fy)), t1) in enumerate(zip(FLY, tts)):
            u = (t - t1) / 0.75
            if u < 0 or u > 1.15: continue
            ue = ease(min(1, u)); tx_, ty_ = 540 + (-140 if k % 2 == 0 else 140), 760
            cx, cy = (fx + tx_) / 2, min(fy, ty_) - 260
            x = (1 - ue) ** 2 * fx + 2 * (1 - ue) * ue * cx + ue ** 2 * tx_; y = (1 - ue) ** 2 * fy + 2 * (1 - ue) * ue * cy + ue ** 2 * ty_
            icon(c, x, y, lerp(1.1, 0.45, ue), word_card, w, a=1 - ramp(u, 0.85, 1.12), rot=(1 - ue) * (0.5 if k % 2 else -0.5))
        steps = [("Ask", A(5, "asked"), 230, 1090), ("Repeat", A(6, "repeated"), 520, 1090), ("Shadow", A(6, "shadowed"), 830, 1090), ("Build sentences", A(6, "built"), 540, 1210)]
        for k, (w, tt, x, y) in enumerate(steps):
            a, s = P(t, tt); pill(c, w, 64, x, y, NAVY if k == 3 else PAPER, WH if k == 3 else N255, a, s, outline=None if k == 3 else LINEG)
        a, s = P(t, A(6, "built") + 0.25); HE(c, "ביקשתי מילים, חזרתי, ובניתי משפטים", 1335, a, s)
    add(A(5) - 0.12, words)

    def dict_sc(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "A little", 110, 340, a, s)
        a, s = P(t, A(7, "dictionary")); T(c, "*dictionary*", 130, 465, a, s)
        tth = A(8, "threw"); u = (t - tth) / 0.9
        a, s = P(t, A(7, "little"))
        if u < 0:
            icon(c, 540, 790 + 8 * math.sin(t * 2), 1.05 * s, dictionary, a=a, r=160)
        elif u < 1.3:
            x = 540 + 620 * u; y = 790 - 760 * u + 520 * u * u
            for k in range(1, 4):
                uk = max(0, u - k * 0.06); circ(c, 540 + 620 * uk, 790 - 760 * uk + 520 * uk * uk, 14 - 3 * k, BLUE, 0.35)
            icon(c, x, y, 1.05 * (1 - 0.35 * u), dictionary, rot=u * 7)
        if u > 0:
            c.save(); c.set_dash([14, 16]); sa(c, BLUE, 0.45 * (1 - ramp(u, 1.4, 2.2))); c.set_line_width(5); c.move_to(540, 790)
            for j in range(1, 21):
                uu = min(u, 1.1) * j / 20; c.line_to(540 + 620 * uu, 790 - 760 * uu + 520 * uu * uu)
            c.stroke(); c.set_dash([]); c.restore()
        a, s = P(t, A(8, "studying")); pill(c, "Studying, not *listening*", 66, 540, 1085, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, tth); pill(c, "Threw it away", 84, 540, 1215, NAVY, WH, a, s)
        a, s = P(t, A(8, "listening") + 0.1); HE(c, "למדתי את המילון במקום להקשיב", 1340, a, s)
    add(A(7) - 0.12, dict_sc)

    def listen(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Listen.", 120, 345, a, s, x=315)
        a, s = P(t, A(9, "repeated")); T(c, "*Repeat.*", 120, 345, a, s, x=775)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 470, 820, 1.0 * s, profile_head, a=a, r=160)
        a2, _ = P(t, A(9, "listened")); icon(c, 330, 780, 1.0, waves, t, a=a2 * a)
        for k in range(3):
            x = 90 + k * 34; line(c, [(x, 780 - 50 + 18 * k), (x, 780 + 50 - 18 * k)], BLUE, 8, a2 * a * (0.5 + 0.5 * math.sin(t * 9 + k)))
        a, s = P(t, A(9, "talked")); icon(c, 770, 560, s, bubble, "Сам с собой", 48, NAVY, WH, -1, a=a)
        pill(c, "Talk to *myself*", 84, 540, 1110, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, A(9, "in russian")); T(c, "in *Russian*", 96, 1230, a, s)
        a, s = P(t, A(9, "in russian") + 0.15); HE(c, "הקשבתי, חזרתי, ודיברתי עם עצמי", 1345, a, s)
    add(A(9) - 0.12, listen)

    BOOKS = R1.__dict__.get("BOOKS") or [("Чебурашка", None, BLUE, motif_stars, "cheburashka", "Cheburashka", 225), ("Доктор", "Айболит", NAVY, motif_heart, "aybolit", "Doctor Aybolit", 540),
             ("Баба-Яга", None, SLATE, motif_hut, "baba yaga", "Baba Yaga", 855)]
    def books(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "*Night shifts*", 130, 345, a, s)
        a, s = P(t, A(10, "children's")); T(c, "Children's books", 84, 465, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 900, 600, 0.8 * s, moon, a=a)
        for k, (x, y) in enumerate([(130, 590), (210, 640), (780, 560), (990, 650)]):
            circ(c, x, y, 5, NAVY, a * (0.4 + 0.4 * math.sin(t * 3 + k)))
        a, s = P(t, A(10, "read")); icon(c, 540, 640, s, lamp, a=a * 0.9)
        for k, (ti, sub, col, mot, key, lab, x) in enumerate(BOOKS):
            a, s = P(t, A(10, "children's") + 0.15 * k); tk = A(10, key); hi = ramp(t, tk - 0.05, tk + 0.25) * (1 - ramp(t, tk + 1.1, tk + 1.4)) if k < 2 else ramp(t, tk - 0.05, tk + 0.25)
            if hi > 0.01: c.save(); old = St.a; St.a *= a; box(c, x - 146, 940 - 30 * hi - 202, 292, 404, 22, (1, 1, 1, 1), 0.0, stroke=BLUE, sw=6 * hi); St.a = old; c.restore()
            icon(c, x, 940 - 30 * hi + 6 * math.sin(t * 1.6 + k), (1.0 + 0.05 * hi) * s, book_cover, ti, sub, col, mot, t, a=a, rot=(-0.04, 0.0, 0.04)[k] * (1 - hi), r=150)
            T(c, lab, 40, 1170, a, s, x=x, w=800, maxw=300, col=B255 if hi > 0.5 else N255)
        a, s = P(t, A(10, "baba yaga") + 0.2); HE(c, "במשמרות לילה קראתי ספרי ילדים", 1290, a, s)
    add(A(10) - 0.12, books)

    def readwrite(c, t, sc):
        a, s = P(t, sc["t0"]); pill(c, "A year or two later", 64, 540, 340, PAPER, N255, a, s, outline=LINEG)
        a, s = P(t, A(11, "i could")); T(c, "I could *read*", 120, 480, a, s); T(c, "*and write*", 120, 600, a, s)
        a, s = P(t, sc["t0"] + 0.1); icon(c, 540, 915, s, paper, ["Я могу читать", "и писать!"], ramp(t, sc["t0"] + 0.2, sc["t0"] + 2.2), t, a=a, r=190)
        a, s = P(t, A(11, "read and")); HE(c, "שנה או שנתיים אחר כך, קראתי וכתבתי", 1265, a, s)
    add(A(11) - 0.3, readwrite)

    def key(c, t, sc):
        ts = A(12, "it started")
        a, s = P(t, sc["t0"]); pill(c, "Deciding to study", 72, 540, 335, PAPER, N255, a, s, outline=LINEG, strike=ramp(t, A(12, "study"), A(12, "study") + 0.45))
        a, s = P(t, ts); T(c, "It started with", 84, 465, a, s)
        icon(c, 540, 790, 0.82 * s, bust, NAVY, a=a, r=130)
        a2, s2 = P(t, A(12, "talking")); icon(c, 800, 575, s2, bubble, "Сам с собой", 46, PAPER, N255, -1, a=a2)
        if a2 > 0: c.save(); c.translate(540, 790); old = St.a; St.a *= a2; loop_arrow(c, ramp(t, A(12, "talking"), A(12, "talking") + 0.9)); St.a = old; c.restore()
        T(c, "Talking to", 120, 1010, a2, s2); T(c, "*myself*", 140, 1135, a2, s2)
        a, s = P(t, A(12, "myself")); T(c, "in *Russian*", 84, 1250, a, s)
        a, s = P(t, A(12, "talking") + 0.3); HE(c, "זה התחיל כשדיברתי עם עצמי ברוסית", 1355, a, s, 60)
    add(A(12) - 0.12, key)

    def cta(c, t, sc):
        a, s = P(t, sc["t0"]); T(c, "Want to do the same", 84, 345, a, s); T(c, "in *English?*", 120, 460, a, s)
        a, s = P(t, A(13, "comment")); T(c, "Comment", 110, 650, a, s)
        a, s = P(t, A(13, "speaker"))
        if a > 0:
            c.save(); c.translate(540, 850); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.14); rr(c, -400, -120 + 14, 800, 240, 60); c.fill()
            box(c, -400, -120, 800, 240, 60, NAVY); rr(c, -386, -106, 772, 212, 50); sa(c, BLUE); c.set_line_width(5); c.stroke()
            St.a = old; c.restore()
        T(c, "SPEAKER", 140, 856, a, s, col=WH)
        a2, s2 = P(t, A(13, "speaker") + 0.25); icon(c, 540, 1080, 0.8 * s2, comment_ic, t, a=a2, r=110)
        HE(c, "כתבו ספיקר בתגובות", 1250, a2, s2, 68)
    add(A(13) - 0.12, cta)
    return S

def main():
    r = ReelV2(); r.build_vo(); scenes = build(r)
    if "--vo-wav" in sys.argv:
        run(["ffmpeg", "-v", "error", "-y", "-f", "f64le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-ar", "16000", f"{SCR}/rv2/vo16.wav"], r.vo.tobytes()); return
    if "--preview" in sys.argv:
        nx = [sc["t0"] for sc in scenes[1:]] + [r.T_END]
        k = sys.argv.index("--preview")
        ts = [float(x) for x in sys.argv[k + 1].split(",")] if len(sys.argv) > k + 1 else [0.0] + [max(0, sc["t0"]) + 0.8 * (b - max(0, sc["t0"])) for sc, b in zip(scenes, nx)]
        kit.preview(r, scenes, ts, f"{SCR}/{NAME}_prev.png"); print(json.dumps(kit.qa_report(r, scenes)["issues"], ensure_ascii=False)); return
    kit.wait_disk(120)
    m4a = f"{SCR}/{NAME}_mix.m4a"; kit.mix_audio(r, "warm", 7, m4a)
    out = f"{D}/{NAME}.mp4"; nx = [sc["t0"] for sc in scenes[1:]] + [r.T_END]
    thumbs = [0.0] + [max(0, sc["t0"]) + 0.8 * (b - max(0, sc["t0"])) for sc, b in zip(scenes, nx)]
    kit.render(r, scenes, out, m4a, thumbs, f"{D}/qa/sheet_v2.png")
    os.remove(m4a); kit.wait_disk(60)
    run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", out, "-c:v", "libx264", "-preset", "medium", "-crf", "26", "-maxrate", "1M",
         "-bufsize", "2M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", f"{D}/{NAME}_web.mp4"])
    rep = kit.qa_report(r, scenes); rep["T_END"] = r.T_END; rep["real_gain_db"] = r.real_gain_db; rep["real_span"] = r.real_span
    rep["subs"] = [(round(a, 2), round(b, 2), cc) for a, b, *_, cc in r.sub_items]
    json.dump(rep, open(f"{D}/qa/qa_v2.json", "w"), indent=1, ensure_ascii=False); print(json.dumps(rep["issues"], ensure_ascii=False))

if __name__ == "__main__":
    main()
