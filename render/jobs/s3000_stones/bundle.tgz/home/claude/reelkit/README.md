# reelkit: narrated reels from a spec

`python3 make_reel.py spec.json vo_raw.wav out_dir/` runs voice, align, render, mix and QA in one go.
Output: 1080x1920, 30 fps, H.264 + AAC 48 kHz, -14 LUFS, -1.5 dBTP, plus a 540x960 web preview under 8 MB.

New files in this folder (the older `kit.py`, `narrate.py`, `vo_restore.py`, `draw.py`, `sfx2.py` are other
reels' code and were left unchanged; reelkit imports `kit.py` for text drawing and `sfx2.py` for the whoosh):

| file | job |
|---|---|
| `voice.py` | house voice chain, soft-ending restore, ASR timing, line selection |
| `asr.py` | sherpa whisper turbo: 11 to 16 s windows cut at pauses, word timing, DP alignment to the script, OOM-safe child process |
| `tts.py` | prints the exact Make "TTS1" request; decodes the Drive download |
| `render.py` | declarative renderer and scene library, burned-in subtitles |
| `mix.py` | music bed + SFX + voice, ducking, loudness; web preview |
| `qa.py` | contact sheet, ebur128, ASR of the final audio vs the script, hook check, dash check, layout check |
| `make_reel.py` | one-shot CLI |
| `clean_vo.py` | copy of `/home/claude/safety_v4/clean_vo.py` (identical to `vo_new/clean_vo.py`) |
| `sfx/` | Kenney CC0 glass ding and pluck (copied from `silly_maps/sfx_src`) |
| `demo/` | the demo spec, a spec that exercises the other scene types, and the demo output |

## Flow

1. **Script**: one TTS line per line in a text file (for example `tts.txt`).
2. **Narration** (Make scenario 4998936 "TTS1", not callable from the shell):
   - `python3 tts.py tts.txt my_reel.mp3` prints the exact `data` for Make `scenarios_run`:
     `{"body": "<Cartesia JSON as a string>", "name": "my_reel.mp3", "tag": "reel"}`.
     The body is `{"model_id":"sonic-3","transcript":"...","voice":{"mode":"id","id":"cd06f613-..."},"output_format":{"container":"mp3","sample_rate":44100,"bit_rate":192000},"language":"en"}`
     (format from `/home/claude/tts_api/README.md`).
   - Claude runs the scenario with that data. The mp3 lands in the Drive folder
     https://drive.google.com/drive/folders/1A04ai2ai6iUq5fkz2mH5t4meqCH8U1k9
   - Claude finds it (Google Drive `search_files`, title = the name), calls `download_file_content`, and then
     `python3 tts.py --decode <tool-result file> my_reel.mp3` writes the mp3.
   - The Cartesia key is in Make data store 94072 (field `other_1`). Never print it.
3. **Reel**: `python3 make_reel.py spec.json my_reel.mp3 out_dir/`. Add `--preview` to stop after timing and write
   `out_dir/preview.png` (keyframes only; the ASR result is cached, so the full run afterwards skips the ASR).

## Voice (voice.py)

House chain: rubberband pitch 0.9715 (formants preserved), bass g=2 f=135, clean_vo, atempo 1.1, 0.3 s lead.
Soft-ending restore, the Shabbat Part 2 fix (`shabbat_record/vo_p2.wav`): before atempo, inside every speech chunk,
wherever the cleaned voice sits 4 dB or more under the dry chain (and the dry chain is real speech, within 40 dB of its
level), the dry chain is crossfaded back in (15 ms ramps). After the ASR, words that are still missing are forced back
from the dry chain, but only where forcing changes the signal (so name or number spellings that whisper writes
differently do not cost a second ASR pass), and only the affected windows are re-checked.

Timing: whisper turbo (int8, `/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/`) on windows of about 11 to 16 s cut at
pauses (30 s windows ran out of memory). Each window's words are spread over its speech chunks by a small DP (spoken
length vs chunk length, punctuation at pauses), then a word-level edit-distance DP aligns them to the script (numbers
spelled with num2words on both sides). Every script word gets a start and end; lines get spans.
`use_lines` keeps a subset of script lines, cut at mid-pause and re-joined (pause between lines capped at 0.6 s).

The whisper model is about 1.7 GB and other jobs on this box load it too, so the OOM killer sometimes takes it.
Every reelkit ASR job takes a machine-wide `flock` on `/tmp/claude-0/asr.lock` (override with `RK_ASR_LOCK`) for its whole run, so reelkit jobs
serialise instead of loading several models at once. `asr.isolated()` runs the job in a child process that also waits for free memory
(other tools' whisper jobs do not take the lock) and retries if the OOM killer takes it; the reel process survives.

## Spec

JSON or YAML. `line` is the 1-based script line a scene belongs to; the scene lands 0.15 s before that line is
spoken (or at `"at": "phrase"`). Items appear on their words: `"at": "phrase"` (or `"N:phrase"` for another line);
without `at`, the item's own text (or `word`, or the country name on a map) is looked up in the line; else items are
spaced evenly. Text: `*word*` is highlighted. Every `he` field is Hebrew, drawn right to left. Any en or em dash in
rendered text becomes a comma (logged in qa.json).

```json
{
 "account": "@noamroz__",
 "script": "tts.txt",
 "use_lines": [1, 2, 3, 7, 8, 10],
 "series": {"en": "SAFETY MAP | MIDDLE EAST", "he": "מפת הביטחון | המזרח התיכון"},
 "palette": {"blue": "#2A88D4"},
 "music": "doc_piano",
 "sfx": true,
 "subs_replace": [["a hundred and thirty-five thousand", "135,000"]],
 "cta_hold": 3.2,
 "scenes": [
  {"type": "title", "line": 1, "icon": "🗺️", "en": "Where can a *Jew* walk safely?", "he": "איפה יהודי יכול להסתובב בבטחה?",
   "sub": "Let's check *the map.*", "sub_at": "Let's check", "sub_he": "בואו נבדוק את המפה."},
  {"type": "bullet_list", "line": 2, "title": "Israeli passport?", "title_he": "דרכון ישראלי?",
   "items": [{"flag": "IR", "en": "Iran", "he": "איראן"}, {"flag": "IQ", "en": "Iraq", "he": "עיראק"}],
   "footer": {"en": "Entry refused", "he": "הכניסה אסורה", "at": "turned away", "color": "red"},
   "source": "Source: visa rules for Israeli passport holders, Oct 2026"},
  {"type": "big_number", "line": 3, "title": "Jews in *Iraq*", "title_he": "יהודים בעיראק",
   "steps": [{"value": 135000, "label": "in 1948", "he": "ב-1948", "at": "a hundred"},
             {"value": 4, "prefix": "~", "label": "*today*", "he": "היום", "at": "About four", "color": "red"}]},
  {"type": "cards_grid", "line": 7, "cols": 2, "title": "Now *flip the map*",
   "cards": [{"flag": "IL", "value": "1 in 5", "label": "citizens of Israel are Arab", "he": "מאזרחי ישראל ערבים", "at": "One in five"}]},
  {"type": "bar_race", "line": 8, "max": 32, "title": "How many are *Arab?*",
   "bars": [{"label": "Citizens", "he": "אזרחים", "icon": "🧑", "value": 21, "suffix": "%"},
            {"label": "Doctors", "he": "רופאים", "icon": "🩺", "value": 25, "suffix": "%", "at": "doctors", "color": "gold"}],
   "note": "Arab judge: Katsav convicted, 2010", "note_at": "an Arab judge"},
  {"type": "cta", "line": 10, "en": "Did this *surprise* you?", "he": "משהו פה הפתיע אתכם?",
   "keyword": "SAFE", "keyword_he": "כתבו SAFE בתגובות", "link": "noamroz.com/safe",
   "follow": "Follow *@noamroz__*", "follow_he": "עקבו לעוד"}
 ]
}
```

Full examples: `demo/safety_demo.json` (the demo) and `demo/types_preview.json` (map, image, quote, 3x2 grid).

### Scene types

Every scene accepts `line`, `at`, `source` (grey source line at the bottom, up to 2 lines), `hl` (highlight colour
name), and most accept `title` / `title_he` as a heading.

| type | fields |
|---|---|
| `title` | `en` (big, `*highlight*`), `he`, `icon` (emoji), `sub` + `sub_at` + `sub_he`, `chip` (series chip; always on scene 0), `size` |
| `big_number` | `steps`: [{`value`, `at`, `label`, `he`, `prefix`, `suffix`, `decimals`, `color`, `from`}]; counts up to the first value, then from value to value (log-eased for big jumps); or a single `value` + `label`; `note`, `note_at`, `note_he` |
| `bullet_list` | `items`: [{`en`, `he`, `flag` (ISO2) or `icon`, `at`}], up to about 7; `footer`: {`en`, `he`, `at`, `color`} |
| `cards_grid` | `cols` 2 or 3; `cards`: [{`icon` / `flag` / `image` (path), `value`, `label`, `he`, `at`, `color`}], up to 6 |
| `bar_race` | `bars`: [{`label`, `he`, `icon` / `flag`, `value`, `prefix`, `suffix`, `decimals`, `at`, `color`}], `max`, `unit`, `sort` (bars glide to their rank), `note`, `note_at`, `note_he` |
| `image` | `src` (photo path), `caption`, `caption_he`, `caption_at`, `zoom` [from, to] (default 1.0 to 1.14), `pan` [dx, dy] |
| `quote` | `quote` (string or list of parts), `quote_at` (list of phrases), `author`, `author_at`, `he`, `author_he`, `size` |
| `map_highlight` | `highlights`: [{`iso` (ISO2), `color`, `at`, `en`, `he`, `label`: false, `at_lonlat`}], `view` ("auto" fits the highlights, or "middle_east", "israel", "world", "europe", "us", or [lon0, lat0, lon1, lat1]), `zoom`, `legend`, `israel_gold` (default true: Israel and Judea/Samaria/Gaza drawn as one gold land, as in safety_v4) |
| `cta` | `en`, `he`, `keyword` (gold pill), `keyword_at`, `keyword_he`, `comment_word`, `link`, `link_at`, `follow` (default "Follow @account"), `follow_he`. The reel is held at least 3 s after the keyword lands (`cta_hold`) |

Flags and icons are Noto Color Emoji (`"flag": "IL"` makes the flag emoji). The map is Natural Earth 1:50m
(`/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson`, public domain), with Hebrew names from its `NAME_HE`.

Palette keys (house default): `bg0 #F4F5F7`, `bg1 #D9DDE3`, `navy #163260`, `blue #2A88D4`, `gold #B8923F`,
`gold2 #E6C77E`, `gold_text #96702A` (gold for text on silver), `grey #5B6B82`, `red #D63A4A`, `green #1E9E62`,
`amber`, `white`, `card`, `sea`, `land`, `border`. Any colour field takes a palette key or a hex.

### Rules the renderer enforces

- Hook: scene 0 is fully on screen at frame 0 (items due in its first 0.6 s are already in); the gold underline
  sweep, the breathing title and the background give motion by 1.5 s. QA checks both.
- Subtitles from the ASR words: short pieces (split at punctuation, at most 6 words), navy pills with a gold outline,
  centred at y=1660. `subs_replace` swaps spoken phrases for display text (numbers, links).
- Content stays in x 55 to 1025, y 205 to 1565 (QA lists anything outside).
- No en/em dashes in any rendered text or subtitle.

## Music beds (mix.py)

All are the original procedural beds already made for earlier reels (no third-party music); they are generated to the
reel's exact length and imported read-only from their folders. `python3 mix.py` lists them.

| name | bed |
|---|---|
| `guinness` | bright pop, D major 112 BPM, pluck arpeggio + glock (`guinness_il/guinness_audio.py`) |
| `shabbat` | warm celebratory pop, softer end fade (`shabbat_record/shabbat_audio.py`) |
| `journey` | light adventurous documentary, D 100 BPM, strings + celesta (`island_israel/journey_audio.py`) |
| `doc_piano` | serious documentary piano, 86 BPM (`safety_v4/audio_v4.py` doc_music) |
| `playful` | marimba + pizzicato, F 112 BPM (`reelkit/sfx2.py`) |
| `roadtrip` | upbeat road-trip groove, 104 BPM (`reelkit/sfx2.py`) |
| `cinematic` | cinematic swell, 84 BPM (`reelkit/sfx2.py`) |
| `bounce`, `skip`, `warm` | colourful-series beds (`reelkit/kit.py`) |
| `file:/path.wav` | any wav, looped with a 1 s crossfade |

Mix: music 17 dB under the voice's active level (`music_db`), ducked a further 7 dB under speech; SFX (`whoosh` on
scene starts, `pop` on items, `ding` on the CTA keyword) about 12 dB under the voice and dipped under speech.
Loudness: gain to -14 LUFS, 4x-oversampled limiter at -2.2 dBFS (AAC headroom), re-measured twice; AAC 192k 48 kHz.

## QA (qa.json, qa_sheet.png)

- contact sheet: frame 0, 1.5 s, each scene at 75 % of its time, the last frame
- ebur128 of the reel and of the web preview (I, TP, LRA), size, fps, audio format
- ASR of the final mix vs the script: per line recall, missing and extra words, timing drift
- hook: text drawn at frame 0, ink share, motion between 0 and 1.5 s
- dashes: any dash left in rendered text or subtitles (must be none) and the replacements made
- layout: text outside the safe area or under 30 px; CTA hold time; phrases not found in their lines

## Limitations

- Hebrew narration is not supported by the ASR alignment (English whisper only); Hebrew is on-screen text only.
- Word times inside a pause-free speech chunk come from spoken length (char fraction), not from acoustic word
  boundaries: good to about 0.1 to 0.2 s, enough for pops and subtitles.
- Scenes are generic: anything bespoke (drawn objects, a moving camera over a map, complex charts) still needs code.
  New scene types are a function `sc_<name>(c, t, S)` added to `SCENES` in render.py.
- `map_highlight` fills whole countries; no sub-national regions (Area A, Gaza) or routes.
- Compute: the ASR is about 1.3x real time on this busy box (two passes: timing, then QA). Re-runs reuse the
  timing ASR from `out_dir/work`.

## Status (26 Oct 2026)

Built and checked by preview renders (no video encode yet): all nine scene types draw correctly, including Hebrew
RTL, flags, the map, 3x2 grids, Ken Burns and the CTA (`render.py spec timing --preview out.png`). The voice chain and
ASR alignment ran once end to end on `safety_v4/vo_raw_v5.wav` (55.4 s voice, 4 windows, every line aligned,
recall 0.92 to 1.0). The full `make_reel.py` demo has NOT been run yet: it was paused because the box was out of memory.
To do when the box is free:

    cd /home/claude/reelkit
    python3 make_reel.py demo/safety_demo.json /home/claude/safety_v4/vo_raw_v5.wav demo/out/

then check `demo/out/qa.json`, `qa_sheet.png`, `run.json` (stage timings) and watch `reel_web.mp4`.
Not yet exercised: `mix.py` (bed + SFX + loudness), `render_video` (ffmpeg streaming), `web()`, `qa.run_all`
and the final ASR check, the `file:` music bed, and `tts.py --decode` on a real Drive download.

## First real run (26 Oct 2026, principles reels physical_abstract and patterns_exceptions)

Full `make_reel.py` ran end to end twice; about 3.3 min per reel with the ASR cached (voice 8 s, mix 9 s, render 78 s,
web 27 s, QA 77 s), plus about 75 s for the first timing ASR. Fixes made:
- `asr.check_audio`: on the final mix the music fills the pauses, so silencedetect found one 50 s chunk and whisper
  dropped everything past 30 s (QA recall 0.57). It now falls back to the known line spans, and `split_long` caps any chunk at 16 s.
- `mix.web`: the web preview re-encoded AAC at 96k, which pushed true peak to -0.9 dBTP. The audio is now copied.
- `render.T`: small text wider than `maxw` hit kit.tx's assert (it only shrinks down to 56/64 px). T now shrinks it first.
- QA layout check: boxes are now in frame coordinates (text inside translate/scale was reported at its local position),
  and mid-pop scaled frames are skipped. The dash log no longer lists plain double-space clean-ups as dash replacements.
- New: spec `"scene_module": "file.py"` adds bespoke `sc_<name>` scenes; `"marks": {name: "phrase" | "N:phrase"}` gives any
  scene named times in `S["times"]`; `"pops": [mark names]` adds pop SFX on them. Example: `/home/claude/principles/principles_scenes.py`.
- Known: whisper hears the all-caps keywords as "later" (LADDER) and "Peyton" (PATTERN); check those by ear.

## Parallel rendering on GitHub (cloud_render.py)
Renders on GitHub Actions in avinoamroz/reels-drop (.github/workflows/render.yml): one 4-core machine per job, up to 20 at once, free (public repo). Tested 27 Oct: pop race, 45 s, 200 s render, identical output.
1. Do TTS / Make / ASR locally first. The cloud command must only render.
2. `python3 /home/claude/reelkit/cloud_render.py send --id <id> --cmd "<render command>" --out <abs path of mp4 it writes> --entry <build .py files> [--add <extra files/dirs built at runtime>]`
   Batch many in ONE push: `send --batch jobs.json` with [{id,cmd,out,entry,add}].
3. `python3 /home/claude/reelkit/cloud_render.py wait <id> ...` -> <id>.mp4 in reels-drop root (raw URL ready for posting) + render/out/<id>_540.mp4 preview. Then mix audio locally if the render was silent.
Repo is PUBLIC: never pack keys/tokens/data store 94072 values. Watch runs: https://github.com/avinoamroz/reels-drop/actions

## Trial setting (Noam, 27 Oct)
Payloads use trial_params graduation_strategy "SS_PERFORMANCE" (not MANUAL): trials that perform well are shared to followers and the profile grid automatically. MANUAL trials never reach the profile, which made the grid look empty. Tested: init with SS_PERFORMANCE returns 200.

## Launch Map caption + HD buttons (27 Oct)
For every reel delivered, also create ArtifactData doc captions/<Launch Map doc id> on artifact Fkdcnuz1oiYUa3hGP5FvLZ with {caption, video (raw GitHub mp4 URL), payload (file stem)}. The page shows "Copy caption" and "Full video (HD)" buttons from it, so Noam can post by hand.
