"""One ASR pass for vo_restore in its own small process: python3 vo_asr_pass.py IN.json OUT.json
IN: {wav16 (f32 raw 16 kHz path), spans: [[a, b], ...]}. OUT: {texts: [...]}. Uses the shared whisper lock."""
import sys, json, numpy as np
sys.path.insert(0, "/home/claude/reelkit")
import vo_restore as R
J = json.load(open(sys.argv[1])); x = np.fromfile(J["wav16"], np.float32)
R.asr()
json.dump(dict(texts=[R.transcribe(x, a, b) for a, b in J["spans"]]), open(sys.argv[2], "w"), ensure_ascii=False)
