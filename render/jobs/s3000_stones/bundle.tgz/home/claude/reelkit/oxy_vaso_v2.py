"""Reel v2 (26 Oct 2026): more professional framing, teams that eat together work better, team building days and offsites
build trust, ends "What do you do with your team?". Cartesia narration, timing from word timestamps (no ASR).
Reel: Oxytocin vs vasopressin: why teams that cook together work better. (@noamroz__, collab @expressenglishcom)
usage: python3 oxy_vaso.py [--preview [t,..]]
Cooking beats are modular: drop dinner photos (jpg/png) into /home/claude/oxy_vaso/photos/ and cooking_scene() shows them
(Ken Burns, one per beat, sorted by file name) instead of the illustrations. Labels and timing stay the same."""
import sys, glob; sys.path.insert(0, "/home/claude/reelkit")
from draw import *
import kit; kit.TEMPO = 1.0

PHOTO_DIR = "/home/claude/oxy_vaso/photos"
_ph = None
def photos():
    global _ph
    if _ph is None:
        _ph = []
        for p in sorted(glob.glob(f"{PHOTO_DIR}/*.jpg") + glob.glob(f"{PHOTO_DIR}/*.jpeg") + glob.glob(f"{PHOTO_DIR}/*.png")):
            im = Image.open(p).convert("RGBA"); s = max(1000 / im.width, 1000 / im.height); im = im.resize((int(im.width * s), int(im.height * s)))
            _ph.append(pil2cairo(im))
    return _ph

def photo_frame(c, t, surf, t0, a, x=540, y=760, w=880, h=880):
    """Ken Burns photo in a rounded frame"""
    z = 1.0 + 0.06 * min(1, max(0, (t - t0) / 4)); c.save(); rr(c, x - w / 2, y - h / 2, w, h, 48); c.clip()
    c.translate(x, y); c.scale(z * w / 1000 * 1.0, z * w / 1000 * 1.0); c.set_source_surface(surf, -surf.get_width() / 2, -surf.get_height() / 2)
    c.paint_with_alpha(a * St.a); c.restore()
    rr(c, x - w / 2, y - h / 2, w, h, 48); sa(c, WHITE, a); c.set_line_width(8); c.stroke()

def cooking_scene(c, t, beats, he_line):
    """beats: list of (label, t_word, illustration fn). Illustrated rows by default; real photos if PHOTO_DIR has files."""
    P = photos()
    if P:
        k = max([i for i, b in enumerate(beats) if t >= b[1] - 0.07] or [0])
        a, s = pop(t, beats[0][1] - 0.2, s0=0.85); photo_frame(c, t, P[k % len(P)], beats[k][1], a, y=700, h=760)
        a, s = pop(t, beats[k][1]); chip(c, beats[k][0], 84, 540, 1150, ORANGE, a=a, sc=s)
    else:
        for k, (label, tt, fn) in enumerate(beats):
            y = 430 + 270 * k; a, s = pop(t, tt)
            if a <= 0: continue
            circ(c, 280, y, 125 * s, [GOLD, SKYC, RED][k], a, stroke=WHITE, sw=7)
            c.save(); rr(c, 280 - 125, y - 125, 250, 250, 125); c.clip(); icon(c, 280, y + 15, 0.72 * s, fn, t, a=a); c.restore()
            tx(c, label, 96 if len(label) < 8 else 84, 450, y, a=a, anchor="l")
    a, s = pop(t, beats[-1][1] + 0.4); he(c, he_line, 540, 1265, a=a, sc=s)

def bubble(c, x, y, w, lines, col, tail_x, a, s, he_=False):
    if a <= 0: return
    h = 90 * len(lines) + 50
    c.save(); c.translate(x, y); c.scale(s, s); rr(c, -w / 2, -h / 2, w, h, 44); sa(c, col, a); c.fill()
    c.move_to(tail_x - 26, h / 2 - 4); c.line_to(tail_x + 26, h / 2 - 4); c.line_to(tail_x + (40 if tail_x > 0 else -40), h / 2 + 50); c.close_path(); c.fill(); c.restore()
    for k, ln in enumerate(lines):
        tx(c, ln, 64 if k else 56, x, y + (k - (len(lines) - 1) / 2) * 90 * s, col=(14, 30, 58, 255), hl=(200, 40, 110, 255), a=a, sc=s, shadow=False)

def build(r):
    A = r.at; S = []
    def add(t0, pal, fn): S.append(dict(t0=t0, pal=pal, fn=fn))
    def hook(c, t, sc):
        tx(c, "Eat together,", 130, 540, 390); tx(c, "*work better?*", 130, 540, 525)
        icon(c, 540, 850, 1.3, pot, t, r=150)
        for k, (x, col, col2, kind) in enumerate([(330, PINK, hx("#FFB3CF"), "oxy"), (750, SKYC, GOLD, "vaso")]):
            a, s = pop(t, A(0, "meet") + 0.15 * k); icon(c, x, 1105, 0.6 * s, molecule, t, col, col2, kind, a=a)
        a, s = pop(t, A(0, "2 hormones")); chip(c, "Meet 2 hormones", 72, 540, 1265, PURPLE, a=a, sc=s)
        he(c, "צוות שאוכל יחד, עובד טוב יותר?", 540, 1375)
    add(-1, "sunset", hook)
    def oxy(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 640, 1.45 * s, molecule, t, PINK, hx("#FFB3CF"), "oxy", a=a, r=150)
        for k in range(4):
            ph = (t * 0.5 + k / 4) % 1; icon(c, 540 + 260 * math.sin(k * 1.9 + ph * 2), 820 - 420 * ph, 0.45, heart, PINK, a=a * (1 - ph) * 0.8)
        tx(c, "Oxytocin", 130, 540, 960, a=a, sc=s, col=(255, 175, 205, 255))
        a, s = pop(t, A(1, "closeness")); tx(c, "The *closeness* hormone", 72, 540, 1075, a=a, sc=s)
        for w, ph, x, y, col in [("Warmth", "warmth", 230, 800, ORANGE), ("Trust", "trust", 860, 800, PURPLE), ("Feeling safe", "feeling safe", 540, 340, hx("#E0457B"))]:
            a, s = pop(t, A(1, ph)); chip(c, w, 64, x, y, col, a=a, sc=s)
        a, s = pop(t, A(1, "safe")); he(c, "אוקסיטוצין: הורמון הקרבה", 540, 1210, a=a, sc=s)
    add(A(1) - 0.12, "coral", oxy)
    def vaso(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 520, 1.1 * s, molecule, t, SKYC, GOLD, "vaso", a=a, r=150)
        tx(c, "Vasopressin", 120, 540, 790, a=a, sc=s, col=(150, 205, 255, 255))
        a, s = pop(t, A(1 + 1, "together")); tx(c, "*We're in this together*", 72, 540, 900, a=a, sc=s)
        for k, (w, ph, col) in enumerate([("Commitment", "commitment", GOLD), ("Protecting your people", "protecting", SKYC), ("Shared goal", "shared goal", GREEN)]):
            a, s = pop(t, A(2, ph)); chip(c, w, 64, 540, 1005 + 105 * k, col, a=a, sc=s)
        a, s = pop(t, A(2, "goal")); he(c, "וזופרסין: אנחנו בזה יחד", 540, 1330, a=a, sc=s)
    add(A(2) - 0.12, "blue", vaso)
    def both(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 210, 470, 0.7 * s, molecule, t, PINK, hx("#FFB3CF"), "oxy", a=a, r=150)
        a, s = pop(t, A(3, "i feel")); bubble(c, 650, 450, 560, ["*Oxytocin:*", "I feel close", "to you"], WHITE, -200, a, s)
        a, s = pop(t, A(3, "vasopressin")); icon(c, 870, 900, 0.7 * s, molecule, t, SKYC, GOLD, "vaso", a=a, r=150)
        a, s = pop(t, A(3, "i've got")); bubble(c, 430, 880, 560, ["*Vasopressin:*", "I've got", "your back"], hx("#FFE9A8"), 200, a, s)
        a, s = pop(t, A(3, "back")); he(c, "אני קרוב אליך. אני מאחוריך.", 540, 1190, a=a, sc=s)
    add(A(3) - 0.12, "violet", both)
    def study(c, t, sc):
        a, s = pop(t, sc["t0"]); chip(c, "Vasopressin spray", 72, 540, 350, SKYC, a=a, sc=s)
        a, s = pop(t, A(4, "spray")); icon(c, 330, 640, 1.15 * s, spray, t, ramp(t, A(4, "spray"), A(4, "spray") + 0.3), a=a, r=120)
        a, s = pop(t, A(4, "cooperate")); icon(c, 760, 650, 1.05 * s, handshake, a=a, r=130)
        tx(c, "More willing", 110, 540, 880, a=a, sc=s); tx(c, "to *cooperate*", 110, 540, 1000, a=a, sc=s)
        a, s = pop(t, A(4, "even when")); chip(c, "Even when it was risky", 64, 540, 1135, ORANGE, a=a, sc=s, icon_fn=warn)
        a, s = pop(t, A(4, "study")); tx(c, "Brunnlieb et al., PNAS 2016", 40, 540, 1250, w=700, a=a, src=True)
        a, s = pop(t, A(4, "risky")); he(c, "יותר שיתוף פעולה, גם כשזה מסוכן", 540, 1335, a=a, sc=s)
    add(A(4) - 0.12, "teal", study)
    def fire(c, t, sc):
        a, s = pop(t, A(5, "firefighters"))
        for k in range(3): icon(c, 300 + 240 * k, 470 + 8 * math.sin(t * 3 + k), 0.85 * s, helmet, [RED, ORANGE, GOLD][k], a=a)
        if a > 0:
            box(c, 170, 570, 740, 36, 16, hx("#C68B4E"), a)
            for k in range(4): c.save(); c.translate(260 + 187 * k, 562); c.scale(1, 0.35); circ(c, 0, 0, 40, WHITE, a); c.restore()
        a2, s2 = pop(t, A(5, "perform")); icon(c, 540, 790, 0.95 * s2, bar_up, ramp(t, A(5, "perform"), A(5, "perform") + 0.8), a=a2, r=110)
        tx(c, "Firefighters who", 110, 540, 965, a=a, sc=s); a3, s3 = pop(t, A(5, "eat together")); tx(c, "*eat together*", 110, 540, 1080, a=a3, sc=s3)
        chip(c, "perform better as a team", 64, 540, 1205, GREEN, a=a2, sc=s2)
        a, s = pop(t, A(5, "cornell")); tx(c, "Kniffin et al., Human Performance 2015 (Cornell)", 40, 540, 1295, w=700, a=a, src=True)
        a, s = pop(t, A(5, "team")); he(c, "כבאים שאוכלים יחד, עובדים טוב יותר", 540, 1370, a=a, sc=s)
    add(A(5) - 0.12, "red", fire)
    def offsite(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "Companies *invest* in", 92, 540, 410, a=a, sc=s)
        a, s = pop(t, A(6, "team building")); chip(c, "Team building days", 76, 540, 610, SKYC, a=a, sc=s)
        a, s = pop(t, A(6, "offsites")); chip(c, "Offsites", 76, 540, 735, PURPLE, a=a, sc=s)
        a, s = pop(t, A(6, "offsites") + 0.2); icon(c, 540, 925, 1.0 * s, long_table, t, a=a, r=1)
        a, s = pop(t, A(6, "they build")); tx(c, "They build *trust*", 100, 540, 1215, a=a, sc=s)
        a, s = pop(t, A(6, "trust")); he(c, "לדעתי, ימי גיבוש בונים אמון", 540, 1340, a=a, sc=s)
    add(A(6) - 0.12, "gold", offsite)
    def cook(c, t, sc):
        cooking_scene(c, t, [("Chop", A(7, "chops"), chop), ("Stir", A(7, "stirs"), lambda c_, t_: pot(c_, t_)),
                             ("Burn onions", A(7, "burns"), pan_smoke)], "חותכים, מערבבים, שורפים את הבצל")
    add(A(7) - 0.12, "coral", cook)
    def table(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "You *laugh.*", 130, 540, 380, a=a, sc=s)
        a, s = pop(t, sc["t0"] + 0.1); icon(c, 540, 700, 1.3 * s, long_table, t, a=a, r=1)
        a, s = pop(t, A(8, "chase")); chip(c, "One goal, together", 76, 540, 1010, PURPLE, a=a, sc=s)
        a, s = pop(t, A(8, "share")); chip(c, "Then share the result", 76, 540, 1125, GREEN, a=a, sc=s)
        a, s = pop(t, A(8, "result")); he(c, "צוחקים, מטרה אחת, ואז חולקים", 540, 1260, a=a, sc=s)
    add(A(8) - 0.12, "sunset", table)
    def nights(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 540, 1.3 * s, chef_hat, a=a, r=120)
        for k in range(5): circ(c, 540 + 300 * math.cos(k * 1.26 + t * 0.4), 520 + 150 * math.sin(k * 1.26 + t * 0.4), 9, YEL, a * (0.5 + 0.5 * math.sin(t * 4 + k)))
        tx(c, "I host", 110, 540, 760, a=a, sc=s)
        a, s = pop(t, A(9, "cooking nights")); tx(c, "*cooking nights*", 110, 540, 875, a=a, sc=s)
        a, s = pop(t, A(9, "entrepreneurs")); tx(c, "for entrepreneurs", 76, 540, 985, a=a, sc=s)
        a, s = pop(t, A(9, "a shared task")); tx(c, "A shared task builds", 84, 540, 1105, a=a, sc=s)
        a, s = pop(t, A(9, "connections")); tx(c, "*connections*", 84, 540, 1205, a=a, sc=s)
        a, s = pop(t, A(9, "entrepreneurs") + 0.4); he(c, "ערבי בישול ליזמים ואנשי עסקים", 540, 1330, a=a, sc=s)
    add(A(9) - 0.12, "navy", nights)
    def end(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 470, 1.1 * s, comment_icon, t, a=a, r=120)
        for k, ln in enumerate(["What do you do", "with your *team?*"]): tx(c, ln, 104, 540, 730 + 120 * k, a=a, sc=s)
        a, s = pop(t, A(10, "tell me")); chip(c, "Tell me in the comments", 72, 540, 1075, PINK, a=a, sc=s)
        a, s = pop(t, A(10, "team") + 0.2); he(c, "מה אתם עושים עם הצוות שלכם?", 540, 1215, a=a, sc=s, sz=66); he(c, "ספרו בתגובות", 540, 1305, a=a, sc=s, sz=66)
    add(A(10) - 0.12, "violet", end)
    return S

if __name__ == "__main__":
    main("/home/claude/oxy_vaso_v2", (("two hormones", "2 hormones"),), build, "warm", 3, tail=2.8)
