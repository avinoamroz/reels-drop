"""Reel: If I wanted to improve my English, here's what I would NOT do. (@expressenglishcom, collab @noamroz__)
usage: python3 wouldnt_do.py [--preview [t1,t2,..]]"""
import sys; sys.path.insert(0, "/home/claude/reelkit")
from draw import *

NCOL = {1: PINK, 2: PURPLE, 3: ORANGE, 4: SKYC}

def progress(c, t, cur):
    for n in range(1, 5):
        x = 540 + (n - 2.5) * 130; y = 320
        if n < cur: circ(c, x, y, 40, RED, stroke=WHITE, sw=5); line(c, [(x - 14, y - 14), (x + 14, y + 14)], WHITE, 8); line(c, [(x + 14, y - 14), (x - 14, y + 14)], WHITE, 8)
        elif n == cur:
            s = 1 + 0.06 * math.sin(t * 6); circ(c, x, y, 50 * s, NCOL[n], stroke=WHITE, sw=6); tx(c, str(n), 64, x, y + 2, shadow=False)
        else: circ(c, x, y, 40, WHITE, 0.15, stroke=(1, 1, 1, 0.6), sw=4); tx(c, str(n), 48, x, y + 2, shadow=False, a=0.8)

def build(r):
    A = r.at; S = []
    def add(t0, pal, fn, **kw): S.append(dict(t0=t0, pal=pal, fn=fn, **kw))
    # ---------------- 0 hook
    def hook(c, t, sc):
        chip(c, "To improve my English", 64, 540, 380, SKYC)
        tx(c, "What I would", 140, 540, 570)
        tx(c, "*NOT* do", 150, 540, 730)
        icon(c, 540, 1000, 1.25 + 0.04 * math.sin(t * 5), x_stamp, r=100)
        he(c, "מה לא הייתי עושה כדי לשפר אנגלית", 540, 1230)
    add(-1, "violet", hook)
    # ---------------- items
    def item(c, t, sc):
        progress(c, t, sc["n"])
        a, s = pop(t, sc["t0"] + 0.05); chip(c, "DON'T", 64, 540, 445, RED, a=a, sc=s)
        a, s = pop(t, sc["t_ic"]); icon(c, 540, 745, 1.6 * s, sc["ic"], *sc.get("args", ()), a=a, r=120)
        stamp(c, t, sc["t_x"], 700, 650, 0.95)
        for k, ln in enumerate(sc["title"]):
            a, s = pop(t, sc["t_ti"] + 0.08 * k); tx(c, ln, 110, 540, 1010 + 118 * k, a=a, sc=s)
        if sc["ex"]: a, s = pop(t, sc["t_ex"]); chip(c, sc["ex"], 64, 540, 1262, NCOL[sc["n"]], a=a, sc=s)
        a, s = pop(t, sc["t_he"]); he(c, sc["he"], 540, 1372, a=a, sc=s)
    class Anim:  # icons that need time
        @staticmethod
        def boring(c): boring_book(c, CUR["t"])
        @staticmethod
        def test(c): test_sheet(c, CUR["t"])
    t1 = A(0, end=True) + 0.02
    add(t1, "coral", item, n=1, ic=flashcards, t_ic=A(1, "start"), t_x=A(1, "vocabulary"), title=["Start with", "*word lists*"], t_ti=A(1, "lists"),
        ex=None, t_ex=None, he="לא להתחיל מרשימות מילים", t_he=A(1, "vocabulary") + 0.3)
    # ---------------- party prep
    def party(c, t, sc):
        a, s = pop(t, sc["t0"]); chip(c, "Memorizing without speaking", 64, 540, 335, SKYC, a=a, sc=s)
        a, s = pop(t, A(1, "preparing")); tx(c, "Preparing for", 116, 540, 480, a=a, sc=s)
        a, s = pop(t, A(1, "party")); tx(c, "a *party*", 116, 540, 600, a=a, sc=s)
        a, s = pop(t, A(1, "party") - 0.1); icon(c, 540, 850, 1.4 * s, invite, t, a=a, rot=0.05 * math.sin(t * 2), r=150)
        for k, (x, col) in enumerate([(165, PINK), (915, YEL)]):
            icon(c, x, 820, 1.0 * s, balloon, col, 0.0, t, k * 2, a=a)
        a, s = pop(t, A(1, "never")); chip(c, "Never throwing it", 84, 540, 1110, PINK, a=a, sc=s, strike=0)
        a, s = pop(t, A(1, "throwing")); he(c, "להתכונן למסיבה, ולא לעשות אותה", 540, 1265, a=a, sc=s)
    add(A(1, "memorizing") + 0.05, "magenta", party)
    add(A(2) - 0.12, "violet", item, n=2, ic=grammar_book, t_ic=A(2, "study"), t_x=A(2, "grammar"), title=["Grammar", "*first*"], t_ti=A(2, "grammar"),
        ex="With nothing to say yet", t_ex=A(2, "before"), he="לא ללמוד דקדוק לפני שיש מה להגיד", t_he=A(2, "something"))
    # ---------------- how vs what
    def howwhat(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "Grammar is the", 110, 540, 400, a=a, sc=s)
        a, s = pop(t, A(2, "how")); tx(c, "*HOW*", 150, 540, 545, a=a, sc=s)
        for k, (x, col, word, fn, tt) in enumerate([(300, SKYC, "HOW", wrench, A(2, "how")), (780, GOLD, "WHAT", qbubble, A(2, "what"))]):
            a, s = pop(t, tt)
            if a > 0:
                c.save(); c.translate(x, 840); c.scale(s, s); box(c, -200, -150, 400, 300, 40, col, a, stroke=WHITE, sw=6); c.restore()
                icon(c, x, 790, 0.75 * s, fn, a=a); tx(c, word, 84, x, 920 * s + 840 * (1 - s), a=a, sc=s, shadow=False)
        a, s = pop(t, A(2, "not instead")); chip(c, "Not instead of the *WHAT*", 76, 540, 1105, NAVY, a=a, sc=s)
        a, s = pop(t, A(2, "what") + 0.2); he(c, "דקדוק זה האיך. לא במקום המה", 540, 1265, a=a, sc=s)
    add(A(2, "grammar is") - 0.1, "blue", howwhat)
    # ---------------- party, no guests
    def noguests(c, t, sc):
        a, s = pop(t, sc["t0"]); tx(c, "Perfect party.", 120, 540, 360, a=a, sc=s)
        a, s = pop(t, A(3, "no guests")); tx(c, "*No guests.*", 120, 540, 488, a=a, sc=s)
        a, s = pop(t, sc["t0"] + 0.1); icon(c, 540, 760, 1.15 * s, dance_floor, t, a=a, r=150)
        df = ramp(t, A(3, "no guests"), A(3, "no fun", end=True) + 0.5)
        for k, (x, col) in enumerate([(150, PINK), (930, SKYC)]): icon(c, x, 700, 0.95 * s, balloon, col, df, t, k * 2.2, a=a)
        for k, (ph, bg, fg) in enumerate([("Lots of work", GOLD, W255), ("No feedback", SKYC, W255), ("No fun", PINK, W255)]):
            a, s = pop(t, A(3, ph.lower())); chip(c, ph, 64, 540, 1010 + 115 * k, bg, fg, a=a, sc=s)
        a, s = pop(t, A(3, "no fun") + 0.3); he(c, "מסיבה מושלמת, בלי אורחים", 540, 1362, a=a, sc=s)
    add(A(3) - 0.12, "sunset", noguests)
    add(A(4) - 0.12, "teal", item, n=3, ic=Anim.boring, t_ic=A(4, "read"), t_x=A(4, "boring"), title=["Read *boring*", "stuff"], t_ti=A(4, "boring"),
        ex="Just because it's important", t_ex=A(4, "just because"), he="לא לקרוא חומר משעמם", t_he=A(4, "someone"))
    add(A(5) - 0.12, "navy", item, n=4, ic=Anim.test, t_ic=A(5, "test"), t_x=A(5, "test"), title=["Test *yourself*", "too early"], t_ti=A(5, "myself"),
        ex="Before you can move in it", t_ex=A(5, "before"), he="לא לבחון את עצמכם מוקדם מדי", t_he=A(5, "actually"))
    # ---------------- classroom behaviour
    def classroom(c, t, sc):
        a, s = pop(t, sc["t0"] + 0.1); icon(c, 320, 760, 1.35 * s, desk_student, t, a=a, r=140)
        a, s = pop(t, sc["t0"] + 0.3); icon(c, 770, 760, 1.35 * s, speaker_fig, t, a=a * 0.45, r=140)
        a, s = pop(t, A(6, "classroom")); tx(c, "Classroom", 120, 540, 370, a=a, sc=s); tx(c, "*behavior*", 120, 540, 495, a=a, sc=s)
        a, s = pop(t, A(6, "student behavior")); chip(c, "Student behavior", 76, 540, 1060, RED, a=a, sc=s)
        a, s = pop(t, A(6, "not the natural")); chip(c, "Not a speaker's behavior", 64, 540, 1185, NAVY, a=a, sc=s, outline=WHITE)
        if a > 0: icon(c, 770, 600, 0.5 * s, qbubble, a=a)
        a, s = pop(t, A(6, "speaker")); he(c, "התנהגות של תלמיד, לא של דובר", 540, 1320, a=a, sc=s)
    add(A(6) - 0.12, "red", classroom)
    # ---------------- flip
    def flip(c, t, sc):
        a, s = pop(t, sc["t0"]); chip(c, "A student studying math", 64, 540, 340, NAVY, a=a, sc=s, outline=WHITE, strike=ramp(t, A(7, "math"), A(7, "math") + 0.4))
        a, s = pop(t, A(7, "act like a person")); icon(c, 540, 650, 1.5 * s, person, GREEN, 0.4, 1.0, a=a, r=130)
        if a > 0:
            icon(c, 700, 520, 0.6 * s, speech, 170, 120, WHITE, -1, a=a); icon(c, 380, 560, 0.5 * s, coffee, t, a=a)
        tx(c, "Act like a person", 104, 540, 935, a=a, sc=s)
        a, s = pop(t, A(7, "living")); tx(c, "living in *English*", 104, 540, 1060, a=a, sc=s)
        a, s = pop(t, A(7, "english")); he(c, "תתנהגו כמו מי שחי באנגלית", 540, 1215, a=a, sc=s)
    add(A(7) - 0.12, "green", flip)
    def native(c, t, sc):
        a, s = pop(t, sc["t0"]); chip(c, "Not like a native", 76, 540, 345, NAVY, a=a, sc=s, outline=WHITE, strike=ramp(t, A(7, "native"), A(7, "native") + 0.4))
        a, s = pop(t, A(7, "like someone")); x = 540 + 30 * math.sin(t * 1.5)
        if a > 0:
            line(c, [(150, 870), (930, 870)], WHITE, 10, a * 0.5)
            icon(c, x, 700, 1.3 * s, person, SKYC, 0.3, 0.8, a=a, r=130)
        a2, s2 = pop(t, A(7, "getting along")); icon(c, 760, 560, 0.9 * s2, check_badge, a=a2)
        tx(c, "Started later.", 110, 540, 980, a=a, sc=s)
        tx(c, "Doing *just fine.*", 110, 540, 1105, a=a2, sc=s2)
        a, s = pop(t, A(7, "just fine")); he(c, "התחלתם מאוחר? מסתדרים מצוין", 540, 1250, a=a, sc=s)
    add(A(7, "not like a native") - 0.1, "teal", native)
    # ---------------- do this instead
    def doit(c, t, sc):
        rows = [("Order the coffee", coffee, A(8, "order"), ORANGE), ("Ask the question", qbubble, A(8, "ask"), PURPLE), ("Tell the story", story_bubble, A(8, "tell"), PINK)]
        for k, (s_, fn, tt, col) in enumerate(rows):
            y = 430 + 215 * k; a, s = pop(t, tt)
            if a <= 0: continue
            circ(c, 200, y, 88 * s, col, a, stroke=WHITE, sw=6)
            icon(c, 200, y + 8, 0.62 * s, fn, *((t,) if fn is coffee else ()), a=a)
            tx(c, s_, 76, 320, y, a=a, sc=1, anchor="l")
            a2, s2 = pop(t, tt + 0.35); icon(c, 268, y - 62, 0.45 * s2, check_badge, a=a2)
        a, s = pop(t, A(8, "then fix")); chip(c, "Then fix grammar", 84, 540, 1085, GOLD, a=a, sc=s, icon_fn=wrench)
        a, s = pop(t, A(8, "grammar")); he(c, "קודם מדברים. אחר כך מתקנים דקדוק", 540, 1250, a=a, sc=s)
    add(A(8) - 0.12, "sunset", doit)
    # ---------------- 7 minutes
    def seven(c, t, sc):
        u = ramp(t, sc["t0"], sc["t0"] + 3.5); a, s = pop(t, sc["t0"])
        icon(c, 540, 560, s, clock_ring, t, u, a=a, r=170)
        tx(c, "7", 190, 540, 535, a=a, sc=s, col=Y255); tx(c, "min", 64, 540, 650, a=a, sc=s)
        a, s = pop(t, A(9, "talk")); tx(c, "Talk to yourself", 96, 540, 850, a=a, sc=s); tx(c, "in *English*", 96, 540, 960, a=a, sc=s)
        a, s = pop(t, A(9, "record")); chip(c, "Record it", 76, 540, 1100, RED, a=a, sc=s, icon_fn=rec_dot)
        a, s = pop(t, A(9, "about your day")); he(c, "7 דקות ביום, באנגלית, על היום שלכם", 540, 1250, a=a, sc=s)
    add(A(9) - 0.12, "blue", seven)
    def cta(c, t, sc):
        a, s = pop(t, sc["t0"]); icon(c, 540, 520, 1.25 * s, comment_icon, t, a=a, r=130)
        tx(c, "Comment", 120, 540, 780, a=a, sc=s)
        a, s = pop(t, A(10, "speaker"))
        if a > 0:
            f = font(130, 900); pw = f.getlength("SPEAKER") + 110; c.save(); c.translate(540, 945); c.scale(s, s)
            box(c, -pw / 2, -95, pw, 190, 95, INK, a, stroke=YEL, sw=8); c.restore()
        tx(c, "SPEAKER", 130, 540, 948, a=a, sc=s, col=Y255, shadow=False)
        a, s = pop(t, A(10, "send")); tx(c, "and get the guide", 76, 540, 1110, a=a, sc=s)
        a, s = pop(t, A(10, "speaker") + 0.3); he(c, "כתבו ספיקר", 540, 1240, a=a, sc=s, sz=72)
    add(A(10) - 0.12, "violet", cta)
    return S

if __name__ == "__main__":
    main("/home/claude/wouldnt_do", (("seven minutes", "7 minutes"),), build, "bounce", 11, tail=2.6)
