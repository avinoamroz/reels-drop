"""Audio for silly maps v2: original procedural music bed (pizzicato, 112 BPM), synthesised SFX, Kenney CC0 UI dings.
Everything returns float64 arrays at 48 kHz. No downloaded music; CC0 Kenney Interface Sounds for ding/pop only."""
import numpy as np, subprocess
from scipy.signal import butter, sosfilt, sosfiltfilt, fftconvolve

SR = 48000
KEN = "/home/claude/silly_maps/sfx_src"
rng = np.random.default_rng(7)

def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], "bp", fs=SR, output="sos"), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, "lp", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "hp", fs=SR, output="sos"), x)
def norm(x, peak=1.0): return x / (np.abs(x).max() + 1e-12) * peak
def load(path):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)
def room(x, t60=0.35, mix=0.18, seed=3):
    r = np.random.default_rng(seed); n = int(t60 * SR); ir = r.standard_normal(n) * np.exp(-6.9 * np.arange(n) / n)
    ir = lp(ir, 5000); ir /= np.sqrt((ir ** 2).sum()); y = fftconvolve(x, ir)[:len(x) + n]
    out = np.zeros(len(y)); out[:len(x)] = x; return out * (1 - mix) + y * mix

# ------------------------------------------------------------------ SFX
def bark(seed=1, f0=620):
    """small dog 'arf': pitch-swept harmonic source + noise through two formants, fast attack"""
    r = np.random.default_rng(seed); d = 0.17; n = int(d * SR); t = np.arange(n) / SR
    u = t / d; f = f0 * (1 + 0.45 * np.sin(np.pi * np.minimum(1, u * 1.6)) - 0.35 * u) * (1 + 0.02 * r.standard_normal(n).cumsum() / 60)
    ph = 2 * np.pi * np.cumsum(f) / SR
    src = sum(np.sin(k * ph) / k ** 0.9 for k in range(1, 14)) * (1 + 0.35 * np.sin(2 * np.pi * 55 * t))
    src = src + 1.4 * r.standard_normal(n) * (0.4 + 0.6 * u)
    v = 1.0 * bp(src, 700, 1500) + 0.7 * bp(src, 1900, 3200) + 0.25 * bp(src, 3800, 5200)
    env = np.minimum(1, t / 0.006) * np.exp(-((u - 0.18) / 0.42) ** 2 * 2.2)
    return norm(room(v * env, 0.3, 0.15))
def woof_woof():
    a = bark(1, 640); b = bark(2, 590); out = np.zeros(int(0.52 * SR) + len(b)); out[:len(a)] += a; i = int(0.24 * SR); out[i:i + len(b)] += 0.9 * b
    return norm(out)
def honk():
    """two short car horn beeps (classic 420/525 Hz pair, overdriven, bandpassed)"""
    def beep(d):
        n = int(d * SR); t = np.arange(n) / SR
        s = np.tanh(3.2 * (np.sin(2 * np.pi * 420 * t) + np.sin(2 * np.pi * 525 * t + 1.1)))
        s = bp(s, 300, 3600, 3) + 0.4 * bp(s, 1800, 2600)
        env = np.minimum(1, t / 0.008) * np.minimum(1, (d - t) / 0.03); return s * env
    a = beep(0.13); b = beep(0.26); out = np.zeros(int(0.2 * SR) + len(b)); out[:len(a)] += a; i = int(0.2 * SR); out[i:i + len(b)] += b
    return norm(room(out, 0.4, 0.12))
def rain(d):
    n = int(d * SR); nz = rng.standard_normal(n)
    bed = 0.5 * hp(lp(nz, 9000), 900) + 0.25 * bp(nz, 300, 900)
    drops = np.zeros(n)
    for i in rng.integers(0, n - 2000, int(d * 260)):
        m = int(rng.uniform(0.004, 0.012) * SR); tt = np.arange(m) / SR; f = rng.uniform(1800, 6000)
        drops[i:i + m] += rng.uniform(0.2, 1) * np.sin(2 * np.pi * f * tt * (1 - 4 * tt)) * np.exp(-tt * 600)
    x = bed + 0.9 * drops; fade = np.minimum(1, np.arange(n) / (0.4 * SR)) * np.minimum(1, (n - np.arange(n)) / (0.6 * SR))
    return norm(x * fade)
def waves(d):
    n = int(d * SR); t = np.arange(n) / SR; nz = rng.standard_normal(n); b = np.cumsum(nz); b = hp(b, 30); b /= np.abs(b).max()
    sw = 0.25 + 0.75 * (0.5 - 0.5 * np.cos(2 * np.pi * (t / 4.2 + 0.15))) ** 2
    x = lp(b, 500) * sw + 0.5 * hp(lp(nz, 6000), 1500) * sw ** 2
    fade = np.minimum(1, t / 0.6) * np.minimum(1, (d - t) / 0.8); return norm(x * fade)
def sprinkler(d, step=0.105):
    """impulse sprinkler: rapid tch tch tch of hissy bursts plus a soft water spray bed"""
    n = int(d * SR); out = np.zeros(n); k = 0
    while k * step < d - 0.05:
        m = int(0.035 * SR); tt = np.arange(m) / SR; i = int(k * step * SR)
        out[i:i + m] += hp(rng.standard_normal(m), 2500) * np.exp(-tt * 110) * (0.8 + 0.2 * rng.random()); k += 1
    spray = 0.18 * hp(lp(rng.standard_normal(n), 10000), 3000)
    t = np.arange(n) / SR; fade = np.minimum(1, t / 0.05) * np.minimum(1, (d - t) / 0.25); return norm((out + spray) * fade)
def murmur(vo, d, seed=5):
    """crowd murmur: babble of many time-shifted, pitch-shifted, low-passed copies of narration material (unintelligible)"""
    r = np.random.default_rng(seed); n = int(d * SR); out = np.zeros(n); L = len(vo)
    for k in range(14):
        rate = r.uniform(0.82, 1.18); m = int(n * rate) + 10; s0 = r.integers(0, max(1, L - m))
        seg = vo[s0:s0 + m]; seg = np.interp(np.arange(n) * rate, np.arange(len(seg)), seg)
        out += np.roll(seg, r.integers(0, n)) * r.uniform(0.5, 1)
    out = lp(hp(out, 180), 1100, 4); t = np.arange(n) / SR
    fade = np.minimum(1, t / 0.5) * np.minimum(1, (d - t) / 0.7); return norm(out * fade)
def ding(): return norm(load(f"{KEN}/glass_001.wav"))
def pop(): return norm(load(f"{KEN}/pluck_001.wav"))

# ------------------------------------------------------------------ music: quirky pizzicato bed, 112 BPM, I vi ii V in C
def pluck(f, d=0.6, bright=0.5, seed=0):
    """Karplus-Strong pizzicato"""
    r = np.random.default_rng(seed); N = max(2, int(SR / f)); n = int(d * SR)
    buf = r.uniform(-1, 1, N) * np.hanning(N) ** 0.3; out = np.zeros(n); a = 0.5 * (1 + bright) * 0.5 + 0.25
    for i in range(n):
        v = buf[i % N]; out[i] = v; buf[i % N] = 0.996 * (a * v + (1 - a) * buf[(i + 1) % N])
    t = np.arange(n) / SR; return out * np.exp(-t * 5.5) * np.minimum(1, t / 0.002)
_pc = {}
def pz(m, d=0.6, bright=0.5):
    k = (m, d, bright)
    if k not in _pc: _pc[k] = pluck(440 * 2 ** ((m - 69) / 12), d, bright, seed=m)
    return _pc[k]
def glock(m, d=1.0):
    f = 440 * 2 ** ((m - 69) / 12); t = np.arange(int(d * SR)) / SR
    return (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 9)) * np.exp(-t * 4) * np.minimum(1, t / 0.002)
def music(dur, end_at):
    bpm = 112; beat = 60 / bpm; bar = 4 * beat; n = int(dur * SR); L = np.zeros(n); R = np.zeros(n)
    def put(sig, st, g, pan=0.0):
        i = int(st * SR); j = min(n, i + len(sig))
        if 0 <= i < n and j > i: L[i:j] += g * (1 - pan) * sig[:j - i]; R[i:j] += g * (1 + pan) * sig[:j - i]
    prog = [(36, [60, 64, 67]), (45, [60, 64, 69]), (38, [62, 65, 69]), (43, [59, 62, 67])]   # C Am Dm G
    mel = [76, None, 79, 76, 74, None, 72, None, 76, 77, 79, None, 74, None, 71, None]        # 8th notes, 2 bars
    nb = int(dur / bar) + 1
    for b in range(nb):
        st = b * bar; root, ch = prog[b % 4]; last = st >= end_at
        if last:   # final resolve on the end card: C major pizz + glock, then silence
            for k, m in enumerate([36, 48] + ch + [72]): put(pz(m, 1.4, 0.6), st + 0.02 * k, 0.5 if m < 50 else 0.3)
            put(glock(84, 1.8), st, 0.12); break
        # bass: pizz on 1, 2.5, 3, 4 (walking feel)
        for off, mm in ((0, root), (1.5, root + 7), (2, root + 12), (3, root + 7)): put(pz(mm, 0.5, 0.35), st + off * beat, 0.55)
        # off-beat chord stabs
        for q in (0.5, 1.5, 2.5, 3.5):
            for k, m in enumerate(ch): put(pz(m, 0.28, 0.55), st + q * beat + 0.006 * k, 0.16, pan=0.2)
        # pizz melody on bars 3+ (two-bar phrase), light
        if b >= 2:
            ph = mel[(b % 2) * 8:(b % 2) * 8 + 8]
            for q, m in enumerate(ph):
                if m is not None: put(pz(m, 0.4, 0.7), st + q * beat / 2, 0.20, pan=-0.25)
        if b % 4 == 3: put(glock(84 if b % 8 == 3 else 88, 1.2), st + 3.5 * beat, 0.06, pan=0.3)
        # soft kick 1 and 3, brushy shaker on 8ths
        for q in (0, 2):
            t3 = np.arange(int(0.22 * SR)) / SR; f = 95 * np.exp(-t3 * 20) + 48
            put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t3 * 16), st + q * beat, 0.32 if b >= 1 else 0)
        for q in range(8):
            m = int(0.045 * SR); nz = hp(rng.standard_normal(m), 6000) * np.exp(-np.arange(m) / SR * 80)
            put(nz, st + q * beat / 2, 0.05 if q % 2 else 0.035, pan=0.35)
        for q in (1, 3):  # finger snap / rim
            m = int(0.06 * SR); nz = bp(rng.standard_normal(m), 1500, 4500) * np.exp(-np.arange(m) / SR * 60)
            put(nz, st + q * beat, 0.09 if b >= 1 else 0)
    t = np.arange(n) / SR; fade = np.minimum(1, t / 0.3) * np.minimum(1, (dur - t) / 0.8)
    out = np.stack([L * fade, R * fade]); return out / (np.abs(out).max() + 1e-9)
