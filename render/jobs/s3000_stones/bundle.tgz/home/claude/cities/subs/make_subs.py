"""Burn in narration subtitles. usage: make_subs.py VIDEO TTS SEGS OUT"""
import sys,re,json,os,subprocess
from PIL import Image,ImageDraw,ImageFont
vid,tts,segsf,out=sys.argv[1:5]
D=os.path.dirname(os.path.abspath(out))+'/subs_'+os.path.basename(out).split('.')[0];os.makedirs(D,exist_ok=True)
F=ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf',54)
L=[l.strip() for l in open(tts) if l.strip()];S=json.load(open(segsf))['segs']
KEEP={'CE','P','I','I\'m','I\'ll','TV','MBA','HAMAS','SPEAKER','OK','NBA'}
NUMS=[('seventy two CE','72 CE'),('eighth century','8th century')]
def clean(l):
    for x,y in NUMS: l=l.replace(x,y)
    l=re.sub(r'\[[^\]]*\]','',l).replace('"','').replace('Lahm...','Lahm,').replace('... ',' ').replace(' ,',',')
    l=re.sub(r',\s*,',',',l); l=re.sub(r'\s+',' ',l).strip(' ,')
    w=[]
    for x in l.split():
        core=re.sub(r'[^A-Za-z\']','',x)
        if len(core)>1 and core.isupper() and core not in KEEP:
            x=x.replace(core,core.capitalize() if core in ('ENGLISH',) else core.lower())
        w.append(x)
    s=' '.join(w); s=re.sub(r'([.?!] )([a-z])',lambda m:m.group(1)+m.group(2).upper(),s); return s[0].upper()+s[1:]
def chunks(s,n=7):
    sents=re.findall(r'(?:[^.?!]|(?<=\d)\.(?=\d))+[.?!]?',s);out=[]
    for se in sents:
        w=se.split()
        if not w: continue
        if out and len(w)<=2 and len(out[-1].split())+len(w)<=n: out[-1]+=' '+' '.join(w);continue
        k=max(1,-(-len(w)//n));size=-(-len(w)//k)
        for i in range(0,len(w),size): out.append(' '.join(w[i:i+size]))
    return out
items=[]
for l,(a,b) in zip(L,S):
    cs=chunks(clean(l));tot=sum(len(c) for c in cs);t=a
    for c in cs:
        d=(b-a)*len(c)/tot;items.append((t,t+d,c));t+=d
def wrap(txt,maxw=920):
    w=txt.split();lines=[];cur=''
    for x in w:
        tr=(cur+' '+x).strip()
        if F.getlength(tr)<=maxw: cur=tr
        else: lines.append(cur);cur=x
    lines.append(cur);return lines
inputs=[];filt=[];prev='[0:v]'
for i,(a,b,c) in enumerate(items):
    lines=wrap(c);lh=66;W=int(max(F.getlength(x) for x in lines))+56;H=lh*len(lines)+28
    im=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(im)
    d.rounded_rectangle([0,0,W-1,H-1],radius=22,fill=(8,16,40,200))
    for k,x in enumerate(lines): d.text((W/2,14+k*lh+lh/2),x,font=F,fill=(255,255,255),anchor='mm')
    p=f'{D}/s{i:03d}.png';im.save(p);inputs+=['-i',p]
    y=int(os.environ.get('SUB_BOTTOM','1530'))-H
    filt.append(f"{prev}[{i+1}:v]overlay=x=(W-w)/2:y={y}:enable='between(t,{a:.3f},{b:.3f})'[v{i}]");prev=f'[v{i}]'
fs=f'{D}/filter.txt';open(fs,'w').write(';'.join(filt))
subprocess.run(['nice','-n','15','ffmpeg','-v','error','-y','-i',vid]+inputs+['-filter_complex_script',fs,'-map',prev,'-map','0:a','-c:v','libx264','-crf','20','-preset','medium','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',out],check=True)
print(out,len(items),'subtitle chunks')
