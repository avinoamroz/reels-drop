#!/bin/bash
# Narrated finals for the map reels, ONE AT A TIME (shared box). Each step is resumable; re-running skips finished reels.
# hard_languages is rendered separately (narr_chunks.sh). Log: /home/claude/vo_new/chain_maps_narrated.log
VO=vo/clean/noam.wav; NC=/home/claude/vo_new/narr_chunks.sh; FIN=/home/claude/vo_new/finalize_ln.sh
done_(){ [ -s "/home/claude/$1/$1_narrated_final.mp4" ]; }
waitmem(){ until [ $(free -m | awk '/Mem:/{print $7}') -gt ${1:-1800} ]; do sleep 10; done; }
retry(){ for i in $(seq 1 40); do waitmem; nice -n 15 "$@" && return 0; echo "retry $i: $*"; sleep 20; done; return 1; }
say(){ echo "$(date +%T) $*"; }

# 1 numbers_map (own chunked driver)
R=numbers_map; if ! done_ $R; then cd /home/claude/$R
  retry python3 render_chunks.py --vo $VO --chunk 300 && bash $FIN $PWD/numbers_map_v1_vo.mp4 $PWD/${R}_narrated_final.mp4; say "$R done"; fi

# 2 name_riddle_map (--chunk i/n parts, --mux n)
R=name_riddle_map; if ! done_ $R; then cd /home/claude/$R; N=2651; P=9
  for i in $(seq 0 $((P-1))); do f=name_riddle_silent_vo_part$i.mp4; exp=$(( N*(i+1)/P - N*i/P ))
    for try in $(seq 1 20); do n=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 $f 2>/dev/null); [ "$n" = "$exp" ] && break
      waitmem; nice -n 15 python3 engine_riddle.py cfg_riddle.py --vo $VO --chunk $i/$P >> narr_render.log 2>&1; done; done
  retry python3 engine_riddle.py cfg_riddle.py --vo $VO --mux $P >> narr_render.log 2>&1 && bash $FIN $PWD/name_riddle_v1_vo.mp4 $PWD/${R}_narrated_final.mp4; say "$R done"; fi

# 3 new_places_map (--f0/--f1 segments, --mux-only)
R=new_places_map; if ! done_ $R; then E="python3 engine_new.py cfg_new.py --vo $VO"
  bash $NC /home/claude/$R 3792 240 partsvo "$E --f0 {a} --f1 {b} && mv new_places_silent_vo_seg\$(printf %05d {a}).mp4 {p}" new_places_silent_vo.mp4 "$E --mux-only" new_places_v1_vo.mp4; say "$R done"; fi

# 4 geo_names_map (--frames, opt-in --mux-only)
R=geo_names_map; if ! done_ $R; then E="python3 engine_geo.py cfg_geo.py --vo $VO"
  bash $NC /home/claude/$R 3126 300 partsvo "$E --frames {a}:{b} && mv geo_names_silent_vo_chunk\$(printf %05d {a}).mp4 {p}" geo_names_silent_vo.mp4 "$E --mux-only" geo_names_v1_vo.mp4; say "$R done"; fi

# 5 endonyms_map (--frames/--part, --audio_only), same S/preset as the music version
R=endonyms_map; if ! done_ $R; then E="env ENDO_S=1 ENDO_PRESET=fast python3 engine_endonyms.py cfg_endonyms.py --vo $VO"
  bash $NC /home/claude/$R 4312 240 partsvo "$E --frames {a}:{b} --part {p}" endonyms_map_silent_vo.mp4 "$E --audio_only" endonyms_map_v1_vo.mp4; say "$R done"; fi

# 6 continents_count, 7 oceans (engine's own resumable --chunk segments, full mux)
for R in continents_count oceans; do if ! done_ $R; then cd /home/claude/$R; CF=$(ls cfg_*.py | head -1)
  FV=$(python3 -c "import runpy;print(runpy.run_path('$CF')['FINAL_VO'])")
  retry python3 engine_doubles.py $CF --vo $VO --chunk 300 >> narr_render.log 2>&1 && bash $FIN $FV $PWD/${R}_narrated_final.mp4; say "$R done"; fi; done

# 8 continents_map (--frames/--part, opt-in --mux-only)
R=continents_map; if ! done_ $R; then E="python3 engine_continents.py cfg_continents.py --vo $VO"
  bash $NC /home/claude/$R 3556 300 partsvo "$E --frames {a}:{b} --part {p}" continents_map_silent_vo.mp4 "$E --mux-only" continents_map_v1_vo.mp4; say "$R done"; fi

# 9 true_size_map (--frames/--part i -> parts/vo_partNN.mp4, --mux)
R=true_size_map; if ! done_ $R; then E="python3 -W ignore engine_truesize.py --vo $VO --segs manual_segs.json"
  bash $NC /home/claude/$R 2866 300 partsvo "$E --frames {a}:{b} --part \$(({a}/300)) && ln -f parts/vo_part\$(printf %02d \$(({a}/300))).mp4 {p}" partsvo/joined_unused.mp4 "$E --mux" true_size_vo.mp4; say "$R done"; fi

# 10 vowels_riddle (resumable JPEG frames, 1 x264 thread via opt-in env)
R=vowels_riddle; if ! done_ $R; then cd /home/claude/$R
  X264_THREADS=1 retry python3 engine_vowels.py cfg_vowels.py --vo $VO --segs manual_segs.json --frames frames_vo >> narr_render.log 2>&1 \
    && bash $FIN $(python3 -c "import runpy;print(runpy.run_path('cfg_vowels.py')['FINAL_VO'])") $PWD/${R}_narrated_final.mp4; say "$R done"; fi
say CHAIN_DONE
