"""Voice-timed helpers shared by the narrated reel renderers.

timeline(keys, vodir): lays the per-line voice clips out back to back.
  hook voice at HOOK_AT; every next line starts GAP after the previous clip ends.
  Returns list of dicts {key, v0 (voice start), v1 (voice end), card (card start)} and total length.
  Card start = voice start - LEAD, so each card appears as its line is spoken.
mix(segs, vodir, music_wav, out_wav, total): voice + music ducked ~18 dB under the voice.
"""
import subprocess, numpy as np, soundfile as sf, os

SR = 44100
HOOK_AT = 0.05; GAP = 0.80; LEAD = 0.10; TAIL = 2.0
HOOK_MAX = 1.0          # hook card on screen for at most this long

def load(p, sr=SR):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)

def timeline(keys, vodir):
    segs = []; t = HOOK_AT
    for k in keys:
        x = load(os.path.join(vodir, f"{k}.wav"))
        d = len(x) / SR
        segs.append(dict(key=k, v0=t, v1=t + d, card=(0.0 if not segs else t - LEAD), x=x))
        t = t + d + GAP
    total = segs[-1]["v1"] + TAIL
    return segs, total

def smooth(g, n):
    if n < 2: return g
    k = np.ones(n) / n
    return np.convolve(np.pad(g, (n, n), mode="edge"), k, "same")[n:-n]

def mix(segs, music_wav, out_wav, total, duck_db=18.0, gap_db=10.0, fade_out=1.5):
    N = int((total + 0.2) * SR)
    v = np.zeros(N)
    for s in segs:
        i = int(s["v0"] * SR); x = s["x"][:N - i]; v[i:i + len(x)] += x
    # voice level (active frames only)
    hop = int(0.02 * SR)
    fr = np.sqrt(np.convolve(v ** 2, np.ones(hop) / hop, "same") + 1e-12)
    act = 20 * np.log10(fr) > (20 * np.log10(np.abs(v).max() + 1e-9) - 35)
    lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)) + 1e-12)
    # voice-activity mask: hold 250 ms after speech, ramps ~120 ms
    m = act.astype(float)
    hold = int(0.25 * SR); mm = np.convolve(m, np.ones(hold), "full")[:N] > 0
    mm = np.maximum(mm, np.convolve(m, np.ones(int(0.08 * SR)), "full")[int(0.08 * SR) - 1:][:N] > 0)
    mask = smooth(mm.astype(float)[::hop], 6)
    mask = np.interp(np.arange(N), np.arange(len(mask)) * hop, mask)
    # music
    mu = load(music_wav)
    xf = int(2 * SR); mo = mu.copy()
    while len(mo) < N:
        r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:] * (1 - r) + mu[:xf] * r, mu[xf:]])
    mo = mo[:N]
    lm = 20 * np.log10(np.sqrt(np.mean(mo ** 2)) + 1e-12)
    g_duck = 10 ** ((lv - duck_db - lm) / 20); g_gap = 10 ** ((lv - gap_db - lm) / 20)
    gain = g_gap + (g_duck - g_gap) * mask
    fo = int(fade_out * SR); gain[-fo:] *= np.linspace(1, 0, fo)
    fi = int(0.3 * SR); gain[:fi] *= np.linspace(0, 1, fi)
    out = v + mo * gain
    out = out / max(1.0, np.abs(out).max() / 0.95)
    sf.write(out_wav, out.astype(np.float32), SR)
    return dict(voice_db=round(lv, 1), music_under_voice_db=round(lv - duck_db, 1), music_gap_db=round(lv - gap_db, 1))

def encoder(out, mixw, W=1080, H=1920, FPS=30, crf=20):
    return subprocess.Popen(["nice", "-n", "15", "ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                             "-i", mixw, "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                             "-shortest", "-movflags", "+faststart", out], stdin=subprocess.PIPE)

def schedule(segs):
    """List of (start, kind, key) for video: hook 0..min(HOOK_MAX, line1 card), title, then cards."""
    sc = [(0.0, "hook", segs[0]["key"])]
    c1 = segs[1]["card"]
    if c1 > HOOK_MAX: sc.append((HOOK_MAX, "title", None))
    for s in segs[1:]: sc.append((s["card"], "line", s["key"]))
    return sc

def at(sc, t):
    cur = sc[0]
    for e in sc:
        if e[0] <= t: cur = e
    return cur[1], cur[2], t - cur[0]
