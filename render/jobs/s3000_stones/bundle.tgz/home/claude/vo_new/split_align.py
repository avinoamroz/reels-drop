"""Split a narration MP3 into its <break> segments, verified by ASR alignment.
usage: python3 split_align.py MP3 BATCH_KEY|TTS_TXT KEYS_JSON OUTDIR [model=turbo|small]
Writes OUTDIR/<key>.wav (24 kHz mono, loudnorm) and OUTDIR/align.json."""
import json, re, subprocess, sys, difflib, functools, os
import numpy as np, sherpa_onnx, soundfile as sf

mp3, bkey, keysf, outd = sys.argv[1:5]
model = sys.argv[5] if len(sys.argv) > 5 else "turbo"
txt = open(bkey).read() if bkey.endswith(".txt") else json.load(open("/home/claude/names_vo_batch.json"))[bkey]
lines = [re.sub(r"\s+", " ", l).strip() for l in re.split(r"<break[^>]*/>", txt)]
lines = [l for l in lines if l]
keys = json.load(open(keysf)); assert len(keys) == len(lines), (len(keys), len(lines))
SR = 16000
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", mp3, "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768; dur = len(x) / SR
hop = 160; fr = np.sqrt(np.convolve(x ** 2, np.ones(320) / 320, "same")[::hop] + 1e-12); db = 20 * np.log10(fr)
floor = np.percentile(db, 8); peak = np.percentile(db, 99)
thr = float(os.environ.get("THR", "-45"))
sp = db > thr
runs = []; i = 0; n = len(sp)
while i < n:
    if sp[i]:
        j = i
        while j < n and sp[j]: j += 1
        runs.append([i * 0.01, j * 0.01]); i = j
    else: i += 1
MING = float(os.environ.get("MING", "0.20"))
ch = []
for r in runs:
    if ch and r[0] - ch[-1][1] < MING: ch[-1][1] = r[1]
    else: ch.append(r)
ch = [c for c in ch if c[1] - c[0] > 0.08]
print(f"dur {dur:.2f} thr {thr:.1f} chunks {len(ch)} lines {len(lines)}", flush=True)
Wd = f"/tmp/claude-0/asr/sherpa-onnx-whisper-{model}/"
asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + f"{model}-encoder.int8.onnx", decoder=Wd + f"{model}-decoder.int8.onnx",
                                                 tokens=Wd + f"{model}-tokens.txt", language="en", task="transcribe", num_threads=2)
def transcribe(a, b):
    seg = np.concatenate([x[int(max(0, a - 0.05) * SR):int(min(dur, b + 0.08) * SR)], np.zeros(int(0.4 * SR), np.float32)])
    s = asr.create_stream(); s.accept_waveform(SR, seg); asr.decode_stream(s); return s.result.text.strip()
ct = [transcribe(a, b) for a, b in ch]
def norm(t):
    t = t.lower().replace("-", "")
    return re.sub(r"[^a-z ]", "", re.sub(r"\s+", " ", t)).strip()
NL = [norm(l) for l in lines]; NC = [norm(c) for c in ct]
m, nl = len(ch), len(lines)
def sim(i, j, k):
    return difflib.SequenceMatcher(None, " ".join(NC[i:j]), NL[k]).ratio() * (len(NL[k]) + 10)
@functools.lru_cache(None)
def best(i, k):
    if k == nl: return (0, ()) if i == m else (-1e9, ())
    if i == m: return (-1e9, ())
    r = (-1e9, ())
    for j in range(i + 1, m + 1 - (nl - k - 1)):
        v, p = best(j, k + 1); v += sim(i, j, k)
        if v > r[0]: r = (v, ((i, j),) + p)
    return r
sys.setrecursionlimit(10000)
_, assign = best(0, 0)
os.makedirs(outd, exist_ok=True)
out = {"mp3": mp3, "dur": dur, "segs": []}; bad = []
NOISE = {"", "you", "thank you", "uh", "um", "hmm", "mm"}
def noise(q): return NC[q] in NOISE or (ch[q][1] - ch[q][0] < 0.18 and len(NC[q]) < 4)
for k, (i, j) in enumerate(assign):
    while j - i > 1 and noise(i): i += 1
    while j - i > 1 and noise(j - 1): j -= 1
    a, b = ch[i][0], ch[j - 1][1]
    sc = difflib.SequenceMatcher(None, " ".join(NC[i:j]), NL[k]).ratio()
    gap = a - (out["segs"][k - 1]["end"] if k else 0)
    a0 = max(0, a - 0.06); b0 = min(dur, b + 0.15)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{a0:.3f}", "-to", f"{b0:.3f}", "-i", mp3, "-af",
                    "afade=t=in:d=0.02,afade=t=out:st=%.3f:d=0.05" % (b0 - a0 - 0.05), "-ar", "24000", "-ac", "1", f"{outd}/{keys[k]}.wav"])
    out["segs"].append({"key": keys[k], "start": a, "end": b, "clip_start": a0, "score": round(sc, 3), "asr": " / ".join(ct[i:j]), "text": lines[k]})
    flag = "" if sc > 0.7 else "   <<< CHECK"
    if sc <= 0.7: bad.append(keys[k])
    print(f"{keys[k]:5s} {a:6.2f}-{b:6.2f} gap {gap:4.2f} {sc:.2f} | {' / '.join(ct[i:j])}{flag}", flush=True)
out["bad"] = bad
json.dump(out, open(f"{outd}/align.json", "w"), indent=1)
print("bad", bad)
