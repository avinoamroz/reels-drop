#!/bin/bash
# Resumable low-memory narrated render for one reel: one chunk per process (1 x264 thread, nice 15), retries,
# concat, engine audio pass (music bed + VO mix), then 2-pass loudnorm I=-14 TP=-1.5 LRA=11 -> 48 kHz AAC 192k, video copied.
# usage: render_narrated.sh REEL_DIR KIND   (KIND: gx | pm | table | women)
R=$1; K=$2; cd "$R" || exit 1; B=$(basename "$R"); LOG="$R/render_narrated.log"; VO=vo/clean/noam.wav
case $K in
  gx)    ENG="python3 engine_gx.py --vo $VO";             CD=chunksvo; SILV=genocide_silent_vo.mp4;      OUTV=genocide_explainer_v1_vo.mp4; AO=--audio_only;;
  pm)    ENG="python3 engine_pm.py cfg_pm.py --vo $VO";   CD=chunksvo; SILV=pm_race_silent_vo.mp4;       OUTV=pm_race_v1_vo.mp4;            AO=--audio_only;;
  table) ENG="python3 engine_table.py --vo $VO";          CD=chunksvo; SILV=satire_silent_vo.mp4;        OUTV=satire_table_v1_vo.mp4;       AO=--audio_only;;
  women) ENG="python3 engine_table.py --vo $VO";          CD=segsvo;   SILV=women_rights_v1_silent_vo.mp4; OUTV=women_rights_v1_vo.mp4;       AO=--audio-only;;
esac
mkdir -p $CD
if [ $K = women ]; then
  VD=$(ffprobe -v error -show_entries format=duration -of csv=p=0 $VO); NCH=$(python3 -c "import math;print(math.ceil(($VD+1.6)*30/300))")
else NCH=""; fi
c=0
while :; do
  if [ $K = women ]; then f=$CD/seg$(printf %02d $c)_vo.mp4; ARGS="--seg $c --nseg $NCH"; else f=$CD/c$(printf %02d $c).mp4; ARGS="--chunk $c"; fi
  for try in 1 2 3; do
    [ -s "$f.ok" ] && break
    nice -n 15 $ENG $ARGS > $CD/last.out 2>&1; rc=$?; cat $CD/last.out >> $LOG
    if [ $rc = 0 ] && [ -s "$f" ]; then echo ok > "$f.ok"; echo "chunk $c ok $(date +%T)" >> $LOG; break; fi
    echo "chunk $c failed try $try rc=$rc" >> $LOG; sleep 20
  done
  [ -s "$f.ok" ] || { echo "ABORT chunk $c" >> $LOG; exit 1; }
  if [ -z "$NCH" ]; then NCH=$(grep -o "NCHUNKS [0-9]*" $CD/last.out | tail -1 | awk '{print $2}'); [ -n "$NCH" ] || NCH=$(grep -o "NCHUNKS [0-9]*" $LOG | tail -1 | awk '{print $2}'); fi
  c=$((c+1)); [ $c -ge $NCH ] && break
done
echo "NCH=$NCH" >> $LOG
if [ $K = women ]; then ls $CD/seg*_vo.mp4 | sort | sed "s#^$CD/#file '#; s/$/'/" > $CD/list.txt
else ls $CD/c*.mp4 | sort | sed "s#^$CD/#file '#; s/$/'/" > $CD/list.txt; fi
ffmpeg -nostdin -loglevel error -y -f concat -safe 0 -i $CD/list.txt -c copy $SILV && echo "concat ok" >> $LOG || { echo "CONCAT FAILED" >> $LOG; exit 1; }
nice -n 15 $ENG $AO >> $LOG 2>&1 || { echo "AUDIO FAILED" >> $LOG; exit 1; }
# 2-pass loudnorm
J=$(nice -n 15 ffmpeg -nostdin -hide_banner -i $OUTV -vn -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g(){ echo "$J" | python3 -c "import sys,json;print(json.load(sys.stdin)['$1'])"; }
LN="loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true"
echo "loudnorm pass2: $LN" >> $LOG
nice -n 15 ffmpeg -nostdin -loglevel error -y -i $OUTV -c:v copy -af "$LN" -ar 48000 -c:a aac -b:a 192k -movflags +faststart ${B}_narrated_final.mp4 \
  && echo "FINAL $R/${B}_narrated_final.mp4 ALLDONE $(date +%T)" >> $LOG || echo "LOUDNORM FAILED" >> $LOG
