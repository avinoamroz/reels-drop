"""qa_narrated.py FINAL.mp4 SEGS.json NARR.txt OUT_SHEET.png [idx,idx,...]
Checks streams / duration / frame count, then a contact sheet: one frame 0.5 s after each chosen line start,
red line at x=540, labelled with the time and the start of the spoken line."""
import sys, json, subprocess, os
from PIL import Image, ImageDraw, ImageFont
vid, sj, narr, out = sys.argv[1:5]
segs = json.load(open(sj))["segs"]; NL = [l.strip() for l in open(narr) if l.strip()]
idx = [int(i) for i in sys.argv[5].split(",")] if len(sys.argv) > 5 else list(range(len(segs)))
pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-show_entries", "stream=codec_type,codec_name,sample_rate,nb_read_frames,r_frame_rate,width,height:format=duration",
                                "-of", "json", vid], capture_output=True, text=True).stdout)
st = {s["codec_type"]: s for s in pr["streams"]}; dur = float(pr["format"]["duration"])
v, a = st.get("video"), st.get("audio")
nf = int(v["nb_read_frames"]); exp = round(dur * 30)
print(f"video {v['codec_name']} {v['width']}x{v['height']} {v['r_frame_rate']} frames {nf} (dur*30 = {exp}) | audio {a['codec_name'] if a else None} {a.get('sample_rate') if a else ''} | duration {dur:.2f}")
r = subprocess.run(["ffmpeg", "-nostdin", "-i", vid, "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
I = [l for l in r.splitlines() if l.strip().startswith("I:")]; print("integrated loudness", I[-1].strip() if I else "?")
F = ImageFont.truetype("/home/claude/vid/fonts/Heebo-800.ttf", 22); tiles = []
for i in idx:
    t = segs[i][0] + 0.5; p = f"/tmp/claude-0/qa_{os.getpid()}_{i}.png"
    subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", vid, "-frames:v", "1", p], check=True)
    im = Image.open(p).convert("RGB"); d = ImageDraw.Draw(im); d.line([(540, 0), (540, 1920)], fill=(255, 0, 0), width=4)
    im = im.resize((360, 640)); os.remove(p)
    lab = Image.new("RGB", (360, 70), (0, 0, 0)); dl = ImageDraw.Draw(lab)
    dl.text((6, 4), f"L{i + 1}  {t:.2f}s", font=F, fill=(255, 220, 80)); dl.text((6, 36), NL[i][:30], font=F, fill=(255, 255, 255))
    tile = Image.new("RGB", (360, 710)); tile.paste(im, (0, 0)); tile.paste(lab, (0, 640)); tiles.append(tile)
cols = min(6, len(tiles)); rows = (len(tiles) + cols - 1) // cols
sheet = Image.new("RGB", (cols * 364, rows * 714), (40, 40, 40))
for k, tl in enumerate(tiles): sheet.paste(tl, ((k % cols) * 364, (k // cols) * 714))
sheet.save(out); print("sheet", out)
