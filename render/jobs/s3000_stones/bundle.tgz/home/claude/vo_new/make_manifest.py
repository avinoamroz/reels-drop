"""Write /home/claude/clean_manifest.json from reclean_results.json plus the earlier surname reels."""
import json, os, re, subprocess, sys
sys.path.insert(0, "/home/claude/vo_new"); import reclean_all as RA
R = json.load(open(RA.RES)); J = json.load(open(RA.JOBS)); order = [j["name"] for j in J]
out = []
for p, c in [("/home/claude/surnames/family_names.mp4", "/home/claude/surnames/family_names_clean.mp4"),
             ("/home/claude/names/family2/family2_narrated.mp4", "/home/claude/names/family2/family2_narrated_clean.mp4"),
             ("/home/claude/names/family2/family2_narrated_7min.mp4", "/home/claude/names/family2/family2_narrated_7min_clean.mp4"),
             ("/home/claude/names/family3/family3_narrated.mp4", "/home/claude/names/family3/family3_narrated_clean.mp4"),
             ("/home/claude/names/family3/family3_narrated_7min.mp4", "/home/claude/names/family3/family3_narrated_7min_clean.mp4")]:
    I, _ = RA.lufs(c)
    out.append(dict(original=p, clean=c, method="rebuild", duration=round(RA.fdur(c), 3), lufs=I, caption_head=RA.caption_for(p), note="done earlier (remix_clean.py)"))
for n in order:
    r = R.get(n)
    if not r: continue
    if "error" in r: out.append(dict(original=r["original"], clean=None, method=None, error=r["error"])); continue
    out.append(dict(original=r["original"], clean=r["clean"], method=r["method"], duration=r["duration"], lufs=r["lufs"], caption_head=r["caption_head"]))
json.dump(out, open("/home/claude/clean_manifest.json", "w"), indent=1, ensure_ascii=False)
print(len(out), "entries;", sum(1 for o in out if o.get("method") == "rebuild"), "rebuild,", sum(1 for o in out if o.get("method") == "master"), "master,",
      sum(1 for o in out if o.get("error")), "errors")
