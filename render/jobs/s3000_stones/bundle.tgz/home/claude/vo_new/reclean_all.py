"""Voice cleanup for every narrated reel: rebuild from clean VO where the build allows it, else master the final mix.

  nice -n 15 python3 reclean_all.py plan            -> /home/claude/vo_new/reclean_jobs.json
  nice -n 15 python3 reclean_all.py run [name ...]  -> <orig>_clean.mp4 next to each original, results in reclean_results.json

Methods
  rebuild/vt      per-line clips laid out by vt.timeline: clips cleaned with clean_vo.py, placed at the same v0,
                  same music file held steady 17 dB under the voice (no ducking).
  rebuild/engine  one VO file from t=0 + generated music (car_names family of engines): VO cleaned with clean_vo.py,
                  the engine's own make_music() bed (no-voice mode) held steady 17 dB under the voice.
                  Layout is proven first: the engine's original ducked mix is rebuilt and correlated with the mp4 audio.
  master          final mixed audio: 90 Hz high-pass + adaptive de-plosive (clean_vo steps 1 and 2), no breath gating.
All: -14 LUFS integrated, true peak <= -1.5 dBTP (remix_clean.loud_finish), video stream copied unchanged.
"""
import sys, os, json, glob, subprocess, importlib.util, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/vo_new")
import vt, clean_vo, remix_clean as RC
from scipy.signal import butter, sosfiltfilt

H = "/home/claude"; JOBS = f"{H}/vo_new/reclean_jobs.json"; RES = f"{H}/vo_new/reclean_results.json"
UNDER_DB = 17.0

def fdur(p): return float(RC.dur(p))
def dec(p, sr):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-vn", "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)

# ------------------------------------------------------------------ planning
def vt_job(name, mp4, tl, clip_dirs, music):
    T = json.load(open(tl)); voice = T["voice"]; total = T["total"]
    for cd in clip_dirs:
        ok = all(os.path.exists(f"{cd}/{k}.wav") for k, _, _ in voice)
        if not ok: continue
        d = {k: sf.info(f"{cd}/{k}.wav").duration for k, _, _ in voice}
        if max(abs(d[k] - (b - a)) for k, a, b in voice) < 0.012:
            return dict(name=name, orig=mp4, method="rebuild", kind="vt", tl=tl, clips=cd, music=music, total=total)
    return dict(name=name, orig=mp4, method="master", kind="master", why=f"no clip dir matches {tl}")

def plan():
    J = []
    # names batch (render_batch.py): vo/clips + reel_batch.json music
    for D in sorted(glob.glob(f"{H}/names/*/reel_batch.json")):
        D = os.path.dirname(D); k = os.path.basename(D)
        if k in ("family2", "family3"): continue
        mus = f"{H}/vid/music/{json.load(open(f'{D}/reel_batch.json'))['music']}.wav"
        for suf, tl in (("", "timeline_narrated.json"), ("_7min", "timeline_narrated_7min.json")):
            mp4 = f"{D}/{k}_narrated{suf}.mp4"
            if os.path.exists(mp4) and os.path.exists(f"{D}/{tl}"): J.append(vt_job(f"{k}{suf}", mp4, f"{D}/{tl}", [f"{D}/vo/clips"], mus))
    # names render.py --vt (reel.json music) and other vt renderers
    for D, mp4, tl, cds in [("male", "male_v3.mp4", "vt_timeline.json", ["vo_noam"]), ("female", "female_v3.mp4", "vt_timeline.json", ["vo_noam"]),
                            ("months", "months_narrated.mp4", "vt_timeline.json", ["vo_noam"]), ("army", "army_narrated.mp4", "vt_timeline.json", ["vo_noam"]),
                            ("leaders", "leaders_v5.mp4", "vt_timeline_v5.json", ["vo/clips_v5", "vo/clips", "vo/clips_v3"])]:
        P = f"{H}/names/{D}"; mus = f"{H}/vid/music/{json.load(open(f'{P}/reel.json'))['music']}.wav"
        J.append(vt_job(D, f"{P}/{mp4}", f"{P}/{tl}", [f"{P}/{c}" for c in cds], mus))
    J.append(vt_job("demonyms", f"{H}/demonyms/aliyah_nationalities_v3_narrated.mp4", f"{H}/demonyms/vt_timeline.json", [f"{H}/demonyms/vo_noam"], f"{H}/demonyms/music.wav"))
    J.append(vt_job("nicknames_male", f"{H}/nick/nicknames_male_narrated.mp4", f"{H}/nick/vt_timeline.json", [f"{H}/nick/vo_noam"], f"{H}/nick/music_v2.wav"))
    # engine family: one VO from t=0, generated music
    E = lambda name, d, mp4, vo, timing, extra=None: dict(name=name, orig=f"{H}/{d}/{mp4}", method="rebuild", kind="engine", script=f"{H}/{d}/render.py",
                                                         vo=f"{H}/{d}/vo/{vo}", timing=f"{H}/{d}/{timing}", extra=extra)
    J += [E("car_names", "car_names", "car_names_vo.mp4", "noam.mp3", "timing.json"),
          E("car_names_7min", "car_names", "car_names_vo_7min.mp4", "noam_7min.mp3", "timing_7min.json"),
          E("bible_funny", "bible_funny", "bible_funny_vo.mp4", "noam.mp3", "timing.json"),
          E("jewish_languages", "jewish_languages", "jewish_languages_vo.mp4", "noam.mp3", "timing.json"),
          E("pronunciation_v2", "pronunciation_jokes", "pronunciation_vo_v2.mp4", "noam_v2.mp3", "timing_vo.json"),
          E("hijacker_course", "hijacker_course", "hijacker_course_vo.mp4", "noam.mp3", "timing.json", "chimes"),
          E("myth_busters", "myth_busters", "myth_busters_vo.mp4", "noam.mp3", "timing.json", "quiet9"),
          E("culture_advocacy", "culture_advocacy", "culture_advocacy_vo.mp4", "noam.mp3", "timing.json")]
    # master: engines whose voice track is re-cut / re-laid inside the render (no stored per-line layout)
    M = lambda name, p, why: dict(name=name, orig=f"{H}/{p}", method="master", kind="master", why=why)
    J += [M("elections", "elections/elections_v2.mp4", "voice re-laid per card inside render.py"),
          M("elections_7min", "elections/elections_v2_7min.mp4", "voice re-laid per card inside render.py")]
    for b in ["branches/branches_vo", "branches/executive/government_vo", "branches/legislative/knesset_vo", "branches/judicial/courts_vo", "idf/corps/corps_vo", "idf/ranks/ranks_vo"]:
        for suf in ("", "_7min"): J.append(M(os.path.basename(b) + suf, f"{b}{suf}.mp4", "engine re-lays split voice segments, no stored layout"))
    for g in ["goals_scorecard/goals_scorecard_vo", "goals_scorecard/goals_scorecard_vo_map", "goals_scorecard/part2/goals_scorecard_p2_vo", "goals_scorecard/part2/goals_scorecard_p2_vo_map"]:
        J.append(M(os.path.basename(g), f"{g}.mp4", "scorecard engine / aligned map cut"))
    for s in ["tenses", "emotional_work", "hard_to_speak", "like_kids", "no_restart", "table_test"]:
        for suf in ("", "_7min"): J.append(M(f"face_{s}{suf}", f"face_reels/{s}_reel{suf}.mp4", "camera recording edit"))
    for i in range(1, 6): J.append(M(f"subs_hook{i}", f"subsreel/hooks/subs_hook{i}.mp4", "voice note edit with sfx"))
    # Noam-voice reels outside the *_vo / *_narrated naming (latest version of each)
    for p in ["israel_tech/israel_tech_v5.mp4", "ethnoreligion/ethnoreligion_v3.mp4", "english_israel/english_israel_v2.mp4", "mother_factor/mother_factor_v4.mp4",
              "thank_you_jews/thank_you_jews_v4.mp4", "colonize/colonize_v2.mp4", "movie_titles/movie_titles_v3.mp4", "names/days/days_v3.mp4",
              "hatikvah/hatikvah_v2.mp4", "moses_us/moses_america_v2.mp4", "quran/quran_land_v4.mp4", "roles_reels/dev/dev_reel_v3.mp4",
              "roles_reels/mkt/mkt_reel_v3.mp4", "roles_reels/pm/pm_reel_v3.mp4", "roles_reels/sales/sales_reel_v3.mp4", "series/narr/false_friends_1_noam_final.mp4"]:
        J.append(M(os.path.basename(p)[:-4], p, "extra reel, build not mapped"))
    # race videos: vid/vo/mix.py = one VO + music held steady under it (already no ducking)
    for name, vo, mus, dd in [("pop_race_30s_v2", "pop30.mp3", "cine_30s2.wav", 60.2), ("pop_race_jerusalem_v2", "popjlm.mp3", "cine_jlm2.wav", 74.6)]:
        J.append(dict(name=name, orig=f"{H}/vid/final/{name}.mp4", method="rebuild", kind="simple", vo=f"{H}/vo_new/{vo}", music=f"{H}/vid/music/{mus}", total=dd))
    for j in J:
        stem = os.path.splitext(j["orig"])[0]; j["clean"] = stem + "_clean.mp4"
        j["caption"] = caption_for(j["orig"])
    json.dump(J, open(JOBS, "w"), indent=1); print(len(J), "jobs", {m: sum(1 for j in J if j["method"] == m) for m in ("rebuild", "master")})
    for j in J:
        if not os.path.exists(j["orig"]): print("MISSING", j["orig"])
        if j.get("why", "").startswith("no clip"): print("FALLBACK", j["name"], j["why"])

def caption_for(mp4):
    d = os.path.dirname(mp4); b = os.path.basename(mp4)
    if "face_reels" in d: c = os.path.join(d, b.split("_reel")[0] + "_caption.txt")
    elif "subsreel/hooks" in d: c = os.path.join(d, "caption_" + b.replace("subs_", "").replace(".mp4", ".txt"))
    else: c = os.path.join(d, "caption.txt")
    if not os.path.exists(c): return None
    return open(c).read().strip()[:80]

# ------------------------------------------------------------------ processing
def steady(v, bed, sr, total, fade_in=0.3, fade_out=1.5):
    N = len(v)
    hop = int(0.02 * sr)
    fr = np.sqrt(np.convolve(v ** 2, np.ones(hop) / hop, "same") + 1e-12)
    act = 20 * np.log10(fr) > (20 * np.log10(np.abs(v).max() + 1e-9) - 35)
    lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)) + 1e-12)
    nz = np.abs(bed) > 1e-6
    lm = 20 * np.log10(np.sqrt(np.mean(bed[nz] ** 2)) + 1e-12)
    g = np.full(N, 10 ** ((lv - UNDER_DB - lm) / 20))
    fi = int(fade_in * sr); g[:fi] *= np.linspace(0, 1, fi)
    return v + bed * g

def clean_dir(src, dst):
    os.makedirs(dst, exist_ok=True); rep = {}
    for f in sorted(glob.glob(f"{src}/*.wav")):
        o = f"{dst}/{os.path.basename(f)}"
        if os.path.exists(o) and os.path.getmtime(o) > os.path.getmtime(f): continue
        x, sr = sf.read(f); x = x.mean(1) if x.ndim > 1 else x
        r = {}; y = clean_vo.clean(x, sr, r); assert len(y) == len(x)
        sf.write(o, y.astype(np.float32), sr, subtype="FLOAT"); rep[os.path.basename(f)] = r
    if rep: json.dump(rep, open(f"{dst}/clean_report.json", "w"), indent=1)

def do_vt(j):
    T = json.load(open(j["tl"])); voice = T["voice"]; total = T["total"]
    cd = j["clips"].rstrip("/") + "_clean"; clean_dir(j["clips"], cd)
    # exact layout: vt chain (GAP 0.8) if it reproduces the stored (rounded) starts, else the stored starts
    v0s = []; t = voice[0][1]
    for k, a, b in voice:
        v0s.append(t); t += sf.info(f"{j['clips']}/{k}.wav").duration + vt.GAP
    if max(abs(x - a) for x, (_, a, _) in zip(v0s, voice)) > 0.006: v0s = [a for _, a, _ in voice]
    SR = vt.SR; N = int((total + 0.2) * SR); v = np.zeros(N)
    for (k, _, _), a in zip(voice, v0s):
        x = vt.load(f"{cd}/{k}.wav"); i = int(a * SR); x = x[:N - i]; v[i:i + len(x)] += x
    mu = vt.load(j["music"]); xf = int(2 * SR); mo = mu.copy()
    while len(mo) < N:
        r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:] * (1 - r) + mu[:xf] * r, mu[xf:]])
    mo = mo[:N]; fo = int(1.5 * SR); mo[-fo:] *= np.linspace(1, 0, fo)
    return steady(v, mo, SR, total), SR, dict(clips=cd, layout="vt chain" if v0s[1] != voice[1][1] else "stored starts")

ENGINE_HELPER = r'''
import sys, json, importlib.util, numpy as np, soundfile as sf
script, vo, timing, extra, out, mode = sys.argv[1:7]
spec = importlib.util.spec_from_file_location("eng", script); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
T = json.load(open(timing)); total = T["total"]; starts = T["starts"]
kw = {}
args = []
if extra == "chimes": args = [[s + 0.05 for s in starts]]
if extra == "quiet9":
    ends = starts[1:] + [total]; kw["quiet"] = (starts[9], ends[9])
v = m.read_vo(vo) if vo != "-" else None
if mode == "bed":
    a = m.make_music(total, *args, None, **kw)
else:
    a = m.make_music(total, *args, v, **kw)
a = np.asarray(a); a = a[:, 0] if a.ndim > 1 else a
sf.write(out, a.astype(np.float32), m.SR, subtype="FLOAT")
if v is not None: sf.write(out + ".voice.wav", v.astype(np.float32), m.SR, subtype="FLOAT")
print(json.dumps(dict(SR=m.SR, total=total)))
'''

def do_engine(j, tmp):
    hp = f"{tmp}/eng_helper.py"; open(hp, "w").write(ENGINE_HELPER)
    run = lambda vo, mode, out: json.loads(subprocess.run(["nice", "-n", "15", "python3", hp, j["script"], vo, j["timing"], j.get("extra") or "-", out, mode],
                                                          capture_output=True, text=True, check=True, cwd=os.path.dirname(j["script"])).stdout.strip().splitlines()[-1])
    # 1. prove the layout: original ducked mix vs the mp4's audio
    info = run(j["vo"], "mix", f"{tmp}/orig_mix.wav"); SR = info["SR"]; total = info["total"]
    a, _ = sf.read(f"{tmp}/orig_mix.wav"); b = dec(j["orig"], SR); n = min(len(a), len(b))
    lag = best_lag(a[:n], b[:n], SR)
    aa, bb = (a[:n - lag], b[lag:n]) if lag >= 0 else (a[-lag:n], b[:n + lag])
    corr = float(np.dot(aa, bb) / (np.linalg.norm(aa) * np.linalg.norm(bb) + 1e-12))
    if corr < 0.97: raise RuntimeError(f"layout check failed, corr {corr:.3f}")
    # 2. clean the VO at the engine rate, keep length
    x = dec(j["vo"], SR); r = {}; y = clean_vo.clean(x, SR, r); assert len(y) == len(x)
    cvo = os.path.splitext(j["vo"])[0] + "_clean.wav"; sf.write(cvo, y.astype(np.float32), SR, subtype="FLOAT")
    json.dump(r, open(cvo + ".report.json", "w"), indent=1)
    # 3. bed in no-voice mode + cleaned voice (engine normalisation read_vo, x 0.95 as in the mix)
    run(cvo, "bed", f"{tmp}/bed.wav"); bed, _ = sf.read(f"{tmp}/bed.wav"); vv, _ = sf.read(f"{tmp}/bed.wav.voice.wav")
    n = len(bed); vv = vv[:n] if len(vv) >= n else np.pad(vv, (0, n - len(vv)))
    return steady(vv * 0.95, bed, SR, total), SR, dict(layout_corr=round(corr, 4), lag_ms=round(lag / SR * 1000, 1), clean_vo=cvo, breaths=len(r["breaths"]))

def do_simple(j):
    SR = 44100; n = int(j["total"] * SR)
    fit = lambda a: a[:n] if len(a) >= n else np.pad(a, (0, n - len(a)))
    x = dec(j["vo"], SR); r = {}; y = clean_vo.clean(x, SR, r); assert len(y) == len(x)
    cvo = os.path.splitext(j["vo"])[0] + "_clean.wav"; sf.write(cvo, y.astype(np.float32), SR, subtype="FLOAT")
    # layout check: VO from t=0 in the original mix
    b = dec(j["orig"], SR); a = fit(x); m = min(len(a), len(b)); lag = best_lag(a[:m], b[:m], SR)
    v = fit(y); mu = fit(dec(j["music"], SR))
    return steady(v, mu, SR, j["total"], fade_in=0.0), SR, dict(clean_vo=cvo, breaths=len(r["breaths"]), lag_ms=round(lag / SR * 1000, 1))

def best_lag(a, b, sr, maxms=60):
    m = int(maxms / 1000 * sr); seg = slice(int(1 * sr), int(min(len(a), 20 * sr)))
    best = (0, -1)
    for L in range(-m, m + 1, max(1, sr // 4000)):
        x = a[seg.start:seg.stop]; y = b[seg.start + L:seg.stop + L]
        if len(y) != len(x): continue
        c = np.dot(x, y)
        if c > best[1]: best = (L, c)
    return best[0]

def master_clean(x, sr):
    x = sosfiltfilt(butter(4, 90, "hp", fs=sr, output="sos"), x)
    lp = sosfiltfilt(butter(4, 250, "lp", fs=sr, output="sos"), x); rest = x - lp
    mb = sosfiltfilt(butter(2, [250, 4000], "bp", fs=sr, output="sos"), x)
    w = int(0.005 * sr); env = lambda s: np.sqrt(np.convolve(s ** 2, np.ones(w) / w, "same") + 1e-12)
    over = 20 * np.log10(env(lp) / env(mb)); lvl = 20 * np.log10(env(x)); spk = np.percentile(lvl, 95)
    red = np.clip(over - clean_vo.PLOS_DB, 0, 9) * (lvl > spk - 35)
    a_r = np.exp(-1 / (0.04 * sr)); g = np.empty_like(red); acc = 0.0
    for i in range(0, len(red), 32):
        tgt = red[i:i + 32].max(); acc = tgt if tgt > acc else acc * a_r ** 32 + tgt * (1 - a_r ** 32); g[i:i + 32] = acc
    return rest + lp * 10 ** (-g / 20), dict(plosive_max_db=round(float(g.max()), 1), plosive_ms=round(float((g > 3).sum() / sr * 1000)))

def do_master(j):
    SR = 48000; x = dec(j["orig"], SR); y, r = master_clean(x, SR); return y, SR, r

def loud_finish(x, sr, out_wav, target=-14.0, tp=-1.5):
    """gain + 4x oversampled look-ahead limiter; the gain is re-solved from the unlimited source until I is within 0.15 LU."""
    src = out_wav + ".pre.wav"; sf.write(src, x.astype(np.float32), sr, subtype="FLOAT")
    I0, _ = lufs(src); g = target - I0; lim = 10 ** ((tp - 0.3) / 20)
    for _ in range(4):
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-af",
                        f"volume={g:.2f}dB,aresample={sr*4},alimiter=limit={lim:.4f}:attack=2:release=60:level=disabled,aresample={sr}",
                        "-c:a", "pcm_f32le", out_wav], check=True)
        I, P = lufs(out_wav)
        if abs(I - target) <= 0.15: break
        g += target - I
    os.remove(src)
    return dict(before_I=I0, I=I, TP=P)

def lufs(p):
    o = subprocess.run(["ffmpeg", "-nostats", "-hide_banner", "-i", p, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    s = o[o.rfind("Summary"):]; import re
    return float(re.search(r"I:\s+(-?[\d.]+)", s).group(1)), float(re.search(r"Peak:\s+(-?[\d.]+)", s).group(1))

def process(j):
    tmp = f"/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/reclean/{j['name']}"; os.makedirs(tmp, exist_ok=True)
    try:
        if j["kind"] == "vt": y, SR, info = do_vt(j); method = "rebuild"
        elif j["kind"] == "engine": y, SR, info = do_engine(j, tmp); method = "rebuild"
        elif j["kind"] == "simple": y, SR, info = do_simple(j); method = "rebuild"
        else: y, SR, info = do_master(j); method = "master"
    except Exception as e:
        if j["kind"] == "master": raise
        print("  rebuild failed, mastering instead:", e, flush=True)
        y, SR, info = do_master(j); method = "master"; info["rebuild_error"] = str(e)
    wav = f"{tmp}/final_mix.wav"
    tgt = -14.0
    for _ in range(3):   # aim the delivered mp4 (after AAC) at -14 LUFS
        li = loud_finish(y, SR, wav, target=tgt)
        RC.mux(j["orig"], wav, j["clean"]); I, TP = lufs(j["clean"])
        if abs(I + 14.0) <= 0.15: break
        tgt += -14.0 - I
    d0, d1 = fdur(j["orig"]), fdur(j["clean"])
    return dict(name=j["name"], original=j["orig"], clean=j["clean"], method=method, duration=round(d1, 3), orig_duration=round(d0, 3),
                dur_ok=abs(d1 - d0) <= 0.05, lufs=I, true_peak=TP, caption_head=j["caption"], info=info)

if __name__ == "__main__":
    if sys.argv[1] == "plan": plan(); sys.exit()
    J = json.load(open(JOBS)); want = set(sys.argv[2:])
    R = json.load(open(RES)) if os.path.exists(RES) else {}
    for j in J:
        if want and j["name"] not in want: continue
        if not want and j["name"] in R and os.path.exists(j["clean"]): continue
        print("->", j["name"], j["kind"], flush=True)
        try:
            r = process(j); R[j["name"]] = r
            print("   ", r["method"], r["duration"], r["orig_duration"], r["lufs"], r["true_peak"], r["info"].get("layout_corr", ""), flush=True)
        except Exception as e:
            R[j["name"]] = dict(name=j["name"], original=j["orig"], error=repr(e)); print("   FAIL", repr(e), flush=True)
        json.dump(R, open(RES, "w"), indent=1)
