#!/bin/bash
S=/home/claude/vo_new/render_narrated.sh
$S /home/claude/genocide_explainer gx
$S /home/claude/satire_compare table
$S /home/claude/women_rights women
$S /home/claude/pm_race pm
echo "CHAIN DONE $(date +%T)" >> /home/claude/vo_new/chain_4reels.log
