"""sync_check.py VIDEO TIMELINE_JSON KEY1,KEY2,KEY3 PREFIX
For each key: grab a frame 0.4 s after its card starts, ASR the rendered audio over that line's voice window."""
import sys, json, subprocess, numpy as np, sherpa_onnx
vid, tl, keys, pre = sys.argv[1], sys.argv[2], sys.argv[3].split(","), sys.argv[4]
J = json.load(open(tl)); V = {k: (a, b) for k, a, b in J["voice"]}
C = {(e[2] or e[1]): e[0] for e in J["schedule"]}
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", vid, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx", tokens=Wd + "turbo-tokens.txt", language="en", task="transcribe", num_threads=2)
pngs = []
for k in keys:
    cs = C.get(k, 0.0); a, b = V[k]
    p = f"/tmp/claude-0/{pre}_{k}.png"; pngs.append(p)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{cs + 0.4:.2f}", "-i", vid, "-frames:v", "1", "-vf", "scale=360:-1", p])
    # audio right at the card start (first 2.5 s) and the whole line window
    def tr(s, e):
        seg = np.concatenate([x[int(s * 16000):int(e * 16000)], np.zeros(6400, np.float32)])
        st = asr.create_stream(); st.accept_waveform(16000, seg); asr.decode_stream(st); return st.result.text.strip()
    print(f"{k:5s} card {cs:6.2f}  voice {a:6.2f}-{b:6.2f}  lead {a - cs:+.2f}s | at card start: {tr(cs, cs + 2.5)!r} | prev 1s before card: {tr(max(0, cs - 1.0), cs)!r}")
subprocess.run(["ffmpeg", "-v", "error", "-y"] + sum([["-i", p] for p in pngs], []) + ["-filter_complex", f"hstack={len(pngs)}", f"/tmp/claude-0/{pre}_sync.png"])
