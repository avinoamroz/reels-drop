#!/bin/bash
# Generic resumable chunked narrated render.
# usage: narr_chunks.sh DIR N CHUNK PARTDIR "RENDER_CMD with {a} {b} {p}" CONCAT_OUT "MUX_CMD" FINAL_VO
# Each part is checked for its exact frame count; waits for 1800 MB free before each part; retries.
D=$1; N=$2; CH=$3; PD=$4; RC=$5; SILV=$6; MUX=$7; FV=$8
cd "$D" || exit 1; B=$(basename "$D"); LOG="$D/narr_render.log"; mkdir -p "$PD"; : > "$PD/list.txt"
for ((a=0; a<N; a+=CH)); do b=$((a+CH)); [ $b -gt $N ] && b=$N; p="$PD/v_$(printf %05d $a).mp4"; exp=$((b-a))
  for try in $(seq 1 12); do
    n=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "$p" 2>/dev/null)
    [ "$n" = "$exp" ] && break
    until [ $(free -m | awk '/Mem:/{print $7}') -gt 1800 ]; do sleep 10; done
    cmd=${RC//\{a\}/$a}; cmd=${cmd//\{b\}/$b}; cmd=${cmd//\{p\}/$p}
    echo "part $a:$b try $try $(date +%T)" >> "$LOG"
    nice -n 15 bash -c "$cmd" >> "$LOG" 2>&1
  done
  n=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "$p" 2>/dev/null)
  [ "$n" = "$exp" ] || { echo "ABORT part $a got $n want $exp" >> "$LOG"; exit 1; }
  echo "file '$D/$p'" >> "$PD/list.txt"
done
ffmpeg -nostdin -y -loglevel error -f concat -safe 0 -i "$PD/list.txt" -c copy "$SILV" && echo "concat ok" >> "$LOG" || { echo "CONCAT FAILED" >> "$LOG"; exit 1; }
until [ $(free -m | awk '/Mem:/{print $7}') -gt 1500 ]; do sleep 10; done
nice -n 15 bash -c "$MUX" >> "$LOG" 2>&1 || { echo "MUX FAILED" >> "$LOG"; exit 1; }
bash /home/claude/vo_new/finalize_ln.sh "$D/$FV" "$D/${B}_narrated_final.mp4" >> "$LOG" 2>&1 && echo "ALLDONE $(date +%T)" >> "$LOG"
