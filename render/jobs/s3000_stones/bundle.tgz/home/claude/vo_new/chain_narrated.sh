#!/bin/bash
# Narrated renders from the vo_new MP3s (clips already split into each project's vo_noam/ by split_align.py).
# One at a time, nice 15, waits for 2500 MB available, retries OOM kills.
run(){ # dir, command...
  local d=$1; shift
  for try in 1 2 3 4; do
    until [ $(free -m | awk '/Mem:/{print $7}') -gt 2500 ]; do sleep 15; done
    (cd "$d" && nice -n 15 "$@") && { echo "OK $d $(date +%T)"; return 0; }
    echo "FAIL $d try $try $(date +%T)"; sleep 20
  done
  return 1
}
run /home/claude/names/months python3 render.py --vt vo_noam --out months_narrated.mp4
run /home/claude/names/army python3 render.py --vt vo_noam --out army_narrated.mp4
run /home/claude/demonyms python3 demonyms_v3.py vt vo_noam aliyah_nationalities_v3_narrated.mp4
run /home/claude/nick env VT=vo_noam python3 reel2.py male.json nicknames_male_narrated.mp4
echo ALLDONE
