#!/bin/bash
# finalize_ln.sh IN.mp4 OUT.mp4 : 2-pass loudnorm I=-14 TP=-1.5 LRA=11, 48 kHz AAC 192k, video stream copied
IN=$1; OUT=$2
J=$(nice -n 15 ffmpeg -nostdin -hide_banner -i "$IN" -vn -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g(){ echo "$J" | python3 -c "import sys,json;print(json.load(sys.stdin)['$1'])"; }
LN="loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true"
echo "loudnorm: $LN"
nice -n 15 ffmpeg -nostdin -loglevel error -y -i "$IN" -map 0:v:0 -map 0:a:0 -c:v copy -af "$LN" -ar 48000 -c:a aac -b:a 192k -movflags +faststart "$OUT" && echo "FINAL $OUT"
