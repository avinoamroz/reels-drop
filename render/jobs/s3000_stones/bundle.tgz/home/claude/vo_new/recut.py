"""recut.py MP3 OUTDIR KEY START END : re-cut one segment and update align.json"""
import sys,json,subprocess
mp3,outd,key,a,b=sys.argv[1],sys.argv[2],sys.argv[3],float(sys.argv[4]),float(sys.argv[5])
a0=max(0,a-0.06); b0=b+0.15
subprocess.run(["ffmpeg","-y","-v","error","-ss",f"{a0:.3f}","-to",f"{b0:.3f}","-i",mp3,"-af","afade=t=in:d=0.02,afade=t=out:st=%.3f:d=0.05"%(b0-a0-0.05),"-ar","24000","-ac","1",f"{outd}/{key}.wav"],check=True)
J=json.load(open(f"{outd}/align.json"))
for s in J["segs"]:
    if s["key"]==key: s.update(start=a,end=b,clip_start=a0,manual=True)
J["bad"]=[k for k in J["bad"] if k!=key]
json.dump(J,open(f"{outd}/align.json","w"),indent=1); print(key,a,b)
