"""Rebuild the audio of an already rendered reel from cleaned voice clips, same timing, and remux.

  nice -n 15 python3 remix_clean.py narrated <reel dir> <timeline json> <clips dir> <orig mp4> <out mp4> [--verify-orig <orig clips dir> <orig mix wav>]
  nice -n 15 python3 remix_clean.py surnames <out mp4>

narrated: voice placed exactly where timeline_*.json says (vt timeline), music held at a steady
          level 17 dB under the voice (no ducking, so nothing swells and dips between lines).
surnames: surnames.py layout, VO from vo_clean/, music at the same constant 0.12 as before.
Both: loudness to -14 LUFS integrated, true peak <= -1.5 dBTP, then the new audio is muxed onto the
untouched video stream (video copied, not re-encoded).
"""
import sys, os, json, subprocess, numpy as np, soundfile as sf, re
sys.path.insert(0, "/home/claude/vo_new"); import vt

def loud_finish(x, sr, out_wav, target=-14.0, tp=-1.5):
    tmp = out_wav + ".pre.wav"; sf.write(tmp, x.astype(np.float32), sr, subtype="FLOAT")
    def measure(p):
        o = subprocess.run(["ffmpeg", "-nostats", "-hide_banner", "-i", p, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
        s = o[o.rfind("Summary"):]
        return float(re.search(r"I:\s+(-?[\d.]+)", s).group(1)), float(re.search(r"Peak:\s+(-?[\d.]+)", s).group(1))
    I, P = measure(tmp)
    g = target - I
    # gain, then a transparent look-ahead limiter at 4x oversampling for the few peaks above the ceiling
    lim = 10 ** ((tp - 0.3) / 20)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", tmp, "-af",
                    f"volume={g:.2f}dB,aresample={sr*4},alimiter=limit={lim:.4f}:attack=2:release=60:level=disabled,aresample={sr}",
                    "-c:a", "pcm_f32le", out_wav], check=True)
    os.remove(tmp)
    I2, P2 = measure(out_wav)
    if I2 < target - 0.4:   # limiter took some level; top up once
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", out_wav, "-af",
                        f"volume={target - I2:.2f}dB,aresample={sr*4},alimiter=limit={lim:.4f}:attack=2:release=60:level=disabled,aresample={sr}",
                        "-c:a", "pcm_f32le", out_wav + ".2.wav"], check=True)
        os.replace(out_wav + ".2.wav", out_wav); I2, P2 = measure(out_wav)
    return dict(before_I=I, before_TP=P, I=I2, TP=P2)

def mux(video, wav, out):
    subprocess.run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", video, "-i", wav, "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "1", "-t", dur(video), "-movflags", "+faststart", out], check=True)

def dur(p):
    return subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True).stdout.strip()

def narrated_segs(tl, clips):
    T = json.load(open(tl)); keys = [k for k, _, _ in T["voice"]]
    segs, _ = vt.timeline(keys, clips)          # exact (unrounded) layout, as render_batch.py built it
    assert max(abs(s["v0"] - v[1]) for s, v in zip(segs, T["voice"])) < 0.002, "clip lengths changed: timing would move"
    return segs, T["total"]

def steady_mix(segs, music_wav, total, under_db=17.0):
    SR = vt.SR; N = int((total + 0.2) * SR); v = np.zeros(N)
    for s in segs:
        i = int(s["v0"] * SR); x = s["x"][:N - i]; v[i:i + len(x)] += x
    hop = int(0.02 * SR)
    fr = np.sqrt(np.convolve(v ** 2, np.ones(hop) / hop, "same") + 1e-12)
    act = 20 * np.log10(fr) > (20 * np.log10(np.abs(v).max() + 1e-9) - 35)
    lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)) + 1e-12)
    mu = vt.load(music_wav); xf = int(2 * SR); mo = mu.copy()
    while len(mo) < N:
        r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:] * (1 - r) + mu[:xf] * r, mu[xf:]])
    mo = mo[:N]; lm = 20 * np.log10(np.sqrt(np.mean(mo ** 2)) + 1e-12)
    gain = np.full(N, 10 ** ((lv - under_db - lm) / 20))
    fo = int(1.5 * SR); gain[-fo:] *= np.linspace(1, 0, fo); fi = int(0.3 * SR); gain[:fi] *= np.linspace(0, 1, fi)
    return v + mo * gain, SR

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "narrated":
        D, tl, clips, vin, vout = sys.argv[2:7]
        R = json.load(open(os.path.join(D, "reel_batch.json")))
        music = f"/home/claude/vid/music/{R['music']}.wav"
        if "--verify-orig" in sys.argv:   # rebuild the original mix with vt.mix to prove the layout matches
            i = sys.argv.index("--verify-orig"); oc, ow = sys.argv[i + 1], sys.argv[i + 2]
            s0, tt = narrated_segs(tl, oc); chk = ow + ".chk.wav"; vt.mix(s0, music, chk, tt)
            a, _ = sf.read(chk); b, _ = sf.read(ow); n = min(len(a), len(b))
            print("layout check vs original mix: len", len(a), len(b), "max diff", float(np.abs(a[:n] - b[:n]).max())); os.remove(chk)
        segs, tt = narrated_segs(tl, clips)
        y, SR = steady_mix(segs, music, tt)
        wav = os.path.splitext(vout)[0] + "_mix.wav"
    else:
        vout = sys.argv[2]; D = "/home/claude/surnames"; vin = os.path.join(D, "family_names.mp4")
        VO = os.path.join(D, sys.argv[3] if len(sys.argv) > 3 else "vo_clean")
        NAMES = 8; PERS = 4
        def dd(k): x, sr = sf.read(f"{VO}/{k}.wav"); return len(x) / sr
        segs = [("hook", dd("hook") + 0.9, "hook", 0.15)]
        for i in range(NAMES): segs.append(("n", dd(f"n{i}") + 0.6, f"n{i}", 0.1))
        segs.append(("pc", dd("pers") + 0.9, "pers", 0.1))
        for i in range(PERS): segs.append(("p", dd(f"p{i}") + 0.6, f"p{i}", 0.1))
        segs.append(("end", dd("end") + 2.0, "end", 0.1))
        TT = sum(s[1] for s in segs)
        x0, SR = sf.read(f"{VO}/hook.wav"); mix = np.zeros(int((TT + 0.5) * SR)); t = 0.0
        for kind, ln, k, off in segs:
            x, sr = sf.read(f"{VO}/{k}.wav"); x = x.mean(1) if x.ndim > 1 else x; s = int((t + off) * SR); mix[s:s + len(x)] += x[:len(mix) - s]; t += ln
        mix = mix / np.abs(mix).max() * 0.9
        m, msr = sf.read("/home/claude/vid/music/p_rel.wav"); m = m.mean(1) if m.ndim > 1 else m
        if msr != SR: m = np.interp(np.arange(0, len(m), msr / SR), np.arange(len(m)), m)
        m = m / np.abs(m).max(); xf = int(2 * SR); out = m.copy()
        while len(out) < len(mix):
            r = np.linspace(0, 1, xf); out = np.concatenate([out[:-xf], out[-xf:] * (1 - r) + m[:xf] * r, m[xf:]])
        out = out[:len(mix)]; fo = int(1.5 * SR); out[-fo:] *= np.linspace(1, 0, fo)
        y = mix + out * 0.12
        if "--verify-orig" in sys.argv:
            b, _ = sf.read(os.path.join(D, "mix.wav")); n = min(len(y), len(b))
            print("layout check vs original mix: len", len(y), len(b), "max diff", float(np.abs(np.clip(y[:n], -1, 1) - b[:n]).max())); sys.exit()
        wav = os.path.splitext(vout)[0] + "_mix.wav"
    info = loud_finish(y, SR, wav)
    mux(vin, wav, vout)
    print(vout, info, "dur", dur(vin), "->", dur(vout))
