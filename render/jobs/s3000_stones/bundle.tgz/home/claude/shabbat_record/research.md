# Research: Largest Shabbat dinner reel (@noamroz__)

Checked 25 Oct 2026 with WebSearch / WebFetch. Status: VERIFIED = read on the page itself; FLAG = uncertain, kept off screen or worded carefully.

## 1. Why Shabbat dinner matters

- **Shabbat every Friday from sundown, kept for thousands of years.** Commanded in the Torah: "Remember the Sabbath day, to keep it holy" (Exodus 20:8). On screen we say "for thousands of years", NOT "3,000 years": the exact age cannot be dated with confidence, so a specific number would be a guess. VERIFIED (wording kept general on purpose).
- **Ahad Ha'am's line.** Original Hebrew: "יותר משישראל שמרו את השבת, שמרה השבת אותם" (fuller: "אפשר לומר בלי שום הפרזה, כי יותר משישראל שמרו את השבת, שמרה השבת אותם"). Literal English: "More than Israel has kept the Sabbath, the Sabbath has kept them." The usual English rendering is "More than the Jews have kept the Sabbath, the Sabbath has kept the Jews." Author: Ahad Ha'am (Asher Ginsberg, 1856 to 1927). Published in Hashiloah, 1898.
  - https://www.thetorah.com/article/shabbat-is-core-to-jewish-identity-even-for-the-secular (Hebrew text, Hashiloah, June 1898, column "Yalkut Katan")
  - https://www.etzion.org.il/he/tanakh/torah/sefer-shemot/parashat-yitro/יתרו-לעשות-את-יום-השבת (full Hebrew sentence, cites Al Parashat Derakhim vol. 3, ch. 30)
  - https://rabbisacks.org/quotes/shabbat-kept-the-jews/ , https://njop.org/more-than-shabbat/
  - FLAG (minor): sources name the piece differently ("Yalkut Katan" column in Hashiloah vs. the essay usually called "Shabbat and Zionism", collected in Al Parashat Derakhim). On screen we only say "Ahad Ha'am, 1898", which all sources agree on. The English on screen is the common translation, marked as such in the caption; the Hebrew on screen is his original.

## 2. Largest Shabbat dinner: record history

| Year | Place | Diners | Status | Source |
|---|---|---|---|---|
| 13 June 2014 | Tel Aviv port (hangar), White City Shabbat | 2,226 | First record; GWR adjudicator Pravin Patel at the event | https://archive.israel21c.org/tel-aviv-sets-guinness-record-shabbat-dinner/ |
| 2015 (Friday before 5 Aug 2015, so about 31 July) | Berlin, European Maccabi Games | 2,322 | Beat Tel Aviv's 2,226 (GWR says so) | https://guinnessworldrecords.com/news/2015/8/record-breaking-shabbat-dinner-at-the-european-maccabi-games-is-shared-by-30-nati-390498 |
| 21 Nov 2025 | New York, Javits Center, Temple Emanu-El Streicker Center | 2,761 | **CURRENT RECORD on guinnessworldrecords.com** | https://www.guinnessworldrecords.com/world-records/largest-shabbat-dinner ; JTA: https://www.clevelandjewishnews.com/jta/new-york-city-sets-guinness-record-for-largest-ever-shabbat-dinner-with-2-800-at/article_a99cae75-7622-555f-bfe3-5b9af3dd7325.html |

- GWR record definition: "the greatest number of people to eat during a Shabbat dinner at a single venue." VERIFIED.
- No newer or bigger record found; the GWR page still lists New York 2,761 (21 Nov 2025) as the holder. VERIFIED.
- FLAG: the JTA headline says "2,800"; the official GWR figure is 2,761, which is what we use.
- So 3,000 would beat the current record by 239 diners.

## 3. "Eating together" records (all read on guinnessworldrecords.com)

| Record | Figure | Where / who | Date | URL |
|---|---|---|---|---|
| Longest table | 3,255.80 m | Beirut, Lebanon (Ajialouna and partners) | 21 Feb 2026 | https://guinnessworldrecords.com/world-records/longest-table |
| Longest table setting | 5,050 m, places set for 15,000 | Vasco da Gama bridge, Lisbon, Portugal | 22 Mar 1998 | https://www.guinnessworldrecords.com/world-records/67125-longest-table-setting |
| Longest line of tables | 6,000.45 m | Santo Tomas, Pangasinan, Philippines | 2 Apr 2017 | https://www.guinnessworldrecords.com/world-records/longest-line-of-tables |
| Largest picnic | 22,232 people | Parque da Bela Vista, Lisbon, Portugal | 20 Jun 2009 | https://www.guinnessworldrecords.com/world-records/largest-picnic |

All four are used in the reel (VERIFIED on the GWR page).

### Checked but NOT used (FLAG)
- **Largest iftar:** the GWR page "largest iftar dinner (multiple venues)" returned 404. Gulf News (27 Feb 2026) reports a Beirut iftar of about 5,700 people *aiming* for GWR, with no confirmation (probably the same Ajialouna event as the 21 Feb 2026 longest table). Older "longest iftar table" claims (Beirut 2017, 2,184 m, 5,400 people; Egypt 2019, 3,100 m, about 7,000 people) come from news reports without a GWR page I could read. Not used.
- **Largest dinner party / plated dinner:** Delta Sigma Theta, Atlanta, about 22,000 guests (BizBash), but the article says GWR still had to certify it, and the GWR page could not be fetched. Not used.
- **Largest Passover Seder:** no Guinness record found. "Largest Seder in the world" claims (Kibbutz Naan, about 1,000 to 1,300 people, Times of Israel; Chabad Kathmandu; Ethiopia, 3,000+ expected) are organisers' or press claims, not GWR. Not used.
- **Israel or Jewish table records:** apart from the Shabbat dinner (Tel Aviv 2014), I found none on GWR. Lebanon's 2026 longest table is the regional one; it is shown neutrally (flag, number, year).

## 4. Our plan (on screen as a plan, not a record)
- Attempt: 3,000 people, one Shabbat dinner, Tel Aviv beach, April 2027 (public copy says "April 2027"; possibly 2 April 2027, not shown).
- Sign up: noamroz.com/shabbat. Comment keyword: SHABBAT.
