"""Shabbat record reel audio (copied from /home/claude/guinness_il/guinness_audio.py, then changed). Guinness v2 audio: original procedural celebratory music bed + synthesised SFX, plus one CC0 Kenney glass ding.
Helpers (filters, room, mix/loudnorm) copied from /home/claude/island_israel/journey_audio.py and
/home/claude/silly_maps/audio_v2.py (copied, not moved). Everything float64 at 48 kHz.
Music: bright premium pop bed in D, 112 BPM (Dadd9, A6sus, Bm7, Gmaj9): warm pad, Karplus-Strong pluck arpeggio,
bass, kick/clap/shaker, glock sparkle. On the beach beat the bed swells: pad filter opens, a string layer and a
riser + soft cymbal come in, gain up about 4 dB. Ducked under the voice."""
import numpy as np, subprocess, json
from scipy.signal import butter, sosfilt, fftconvolve, lfilter

SR = 48000
rng = np.random.default_rng(23)
KEN_DING = "/home/claude/shabbat_record/sfx_src/glass_001.wav"
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], "bp", fs=SR, output="sos"), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, "lp", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "hp", fs=SR, output="sos"), x)
def norm(x, peak=1.0): return x / (np.abs(x).max() + 1e-12) * peak
def tt(d): return np.arange(int(d * SR)) / SR
def env(n, a, r):
    t = np.arange(n) / SR; d = n / SR; return np.minimum(1, t / max(a, 1e-4)) * np.minimum(1, (d - t) / max(r, 1e-4))
def load(path):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)
def room(x, t60=0.6, mix=0.2, seed=3):
    r = np.random.default_rng(seed); n = int(t60 * SR); ir = r.standard_normal(n) * np.exp(-6.9 * np.arange(n) / n)
    ir = lp(ir, 4500); ir /= np.sqrt((ir ** 2).sum()); y = fftconvolve(x, ir)[:len(x)]; return x * (1 - mix) + y * mix
def saw(ph): return 2 * ((ph / (2 * np.pi)) % 1.0) - 1
def hz(m): return 440 * 2 ** ((m - 69) / 12)

# ------------------------------------------------------------------ SFX
def trophy_ding():
    """Kenney CC0 glass ding layered with a short synthesised bell (inharmonic partials) for a 'trophy' shine"""
    g = load(KEN_DING); t = tt(1.4); f = hz(88)
    bell = sum(a * np.sin(2 * np.pi * f * k * t) * np.exp(-t * dcy) for k, a, dcy in ((1, 1, 3.2), (2.76, 0.35, 7), (5.4, 0.15, 12), (0.5, 0.25, 4)))
    bell *= np.minimum(1, t / 0.002); y = np.zeros(len(t)); y[:len(g)] += norm(g) * 0.9; y += 0.55 * norm(bell)
    return norm(room(y, 0.9, 0.18))
def stamp_thunk():
    """rubber stamp hitting paper on a desk: low body thump + paper slap + tiny wood knock"""
    t = tt(0.45); body = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 30) + 58) / SR) * np.exp(-t * 22)
    slap = bp(rng.standard_normal(len(t)), 400, 3200) * np.exp(-t * 70)
    knock = np.sin(2 * np.pi * 420 * t) * np.exp(-t * 55) * 0.3
    return norm(room(1.0 * body + 0.7 * slap + knock, 0.25, 0.12))
def crowd_cheer(d=3.2, voices=26):
    """crowd 'yay' + applause: formant-filtered rising vowel voices and dense hand claps, all synthesised"""
    t = tt(d); u = t / d; out = np.zeros(len(t))
    for v in range(voices):
        r = np.random.default_rng(300 + v); f0 = r.uniform(150, 330); on = r.uniform(0, 0.35); dv = r.uniform(1.0, 2.2)
        w = np.clip((t - on) / dv, 0, 1); a = np.sin(np.pi * w) ** 0.7 * (t >= on)
        f = f0 * (1 + 0.35 * np.minimum(1, (t - on).clip(0) / 0.25)) * (1 + 0.01 * np.sin(2 * np.pi * r.uniform(4, 7) * t))
        src = saw(2 * np.pi * np.cumsum(f) / SR) + 0.25 * r.standard_normal(len(t))
        F1, F2 = ((730, 1090), (660, 1700), (570, 840))[v % 3]
        y = bp(src, F1 * 0.8, F1 * 1.25) + 0.6 * bp(src, F2 * 0.85, F2 * 1.2)
        out += norm(y * a) * r.uniform(0.4, 1.0)
    clap = np.zeros(len(t))
    for i in rng.integers(0, len(t) - 2000, int(d * 70)):
        m = int(0.018 * SR); clap[i:i + m] += bp(rng.standard_normal(m), 900, 5000) * np.exp(-np.arange(m) / SR * 220) * rng.uniform(0.3, 1)
    whistle = np.sin(2 * np.pi * np.cumsum(1900 + 500 * np.minimum(1, t / 0.35)) / SR) * env(len(t), 0.05, 0.1) * (t < 0.9) * 0.12
    x = norm(lp(out, 4200)) + 0.8 * norm(clap) * np.minimum(1, t / 0.15) + whistle
    return norm(room(x * env(len(t), 0.06, 1.4), 1.1, 0.3))
def candle_whoosh(d=1.4):
    """soft match-strike/candle whoosh: band-passed noise sweeping up then settling, panned left to right"""
    t = tt(d); u = t / d; nz = rng.standard_normal(len(t))
    a = np.exp(-((u - 0.35) / 0.22) ** 2)
    y = 0.0
    for c in (500, 800, 1300, 2100, 3400):
        w = np.exp(-((np.log((600 + 2400 * np.sin(np.pi * np.minimum(1, u * 1.4)) ** 2) / c)) / 0.5) ** 2); y = y + w * bp(nz, c / 1.4, c * 1.4)
    x = norm(lp(y, 5000) * a) + 0.25 * norm(lp(nz, 250)) * a
    pan = np.clip(u * 1.6 - 0.8, -0.8, 0.8)
    return np.stack([x * (1 - pan) / 2, x * (1 + pan) / 2]) * 2

def match_strike():
    """match strike: rough scratch (jittered high band noise) then the flare (short rising whoosh)"""
    t = tt(0.9); nz = rng.standard_normal(len(t)); y = np.zeros(len(t))
    m = int(0.13 * SR); jit = np.repeat(rng.uniform(0.2, 1.0, m // 240 + 1), 240)[:m]
    y[:m] += bp(nz[:m], 2200, 7000) * jit * np.exp(-np.arange(m) / SR * 12)
    f0 = int(0.1 * SR); tf = t[f0:] - t[f0]
    flare = (bp(nz[f0:], 300, 2500) * 0.7 + lp(nz[f0:], 400) * 0.6) * np.minimum(1, tf / 0.04) * np.exp(-tf * 4.5)
    y[f0:] += flare
    return norm(room(y, 0.3, 0.15))

# ------------------------------------------------------------------ music (new for this reel)
def pluck(f, d=0.6, bright=0.5, seed=0):
    """Karplus-Strong pluck (from silly_maps/audio_v2.py via guinness_audio.py): oud-like when dark"""
    r = np.random.default_rng(seed); N = max(2, int(SR / f)); n = int(d * SR); a = 0.5 * (1 + bright) * 0.5 + 0.25
    buf = r.uniform(-1, 1, N) * np.hanning(N) ** 0.3; out = np.zeros(n)
    for i in range(0, n, N):
        k = min(N, n - i); out[i:i + k] = buf[:k]; buf = 0.996 * (a * buf + (1 - a) * np.roll(buf, -1))
    t = np.arange(n) / SR; return out * np.exp(-t * 4.0) * np.minimum(1, t / 0.002)
_pc = {}
def pz(m, d=0.6, bright=0.5):
    k = (m, d, bright)
    if k not in _pc: _pc[k] = pluck(hz(m), d, bright, seed=m)
    return _pc[k]
def reed(m, d, vib=5.5):
    """clarinet-ish lead: odd harmonics, soft attack, delayed vibrato"""
    t = tt(d); f = hz(m) * (1 + 0.006 * np.sin(2 * np.pi * vib * t) * np.minimum(1, t / 0.25))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) + 0.45 * np.sin(3 * ph) + 0.22 * np.sin(5 * ph) + 0.1 * np.sin(7 * ph)
    return lp(x, 2600) * env(len(t), 0.03, min(0.25, d * 0.5))
def music(dur, swell=(None, None), seed=7, end_fade=1.6):
    """warm groove in D freygish (Ahava Rabbah mode), 104 BPM: D | Gm | Cm | D7.
    pad + oud-ish pluck arpeggio + bass + doum/tek hand-drum pattern + shaker + reed lead melody.
    swell (s0, s1): strings, octave lead, riser, cymbal and fuller drums between s0 and s1."""
    r = np.random.default_rng(seed); n = int(dur * SR); L = np.zeros(n); R = np.zeros(n)
    bpm = 104; beat = 60 / bpm; bar = 4 * beat; nb = int(dur / bar) + 2; s0, s1 = swell
    prog = [(38, [62, 66, 69]), (43, [62, 67, 70]), (36, [60, 63, 67]), (38, [60, 62, 66, 69])]
    mel = [[74, 75, 78, None, 79, 78, 75, 74], [79, None, 82, 81, 79, 78, 79, None],
           [84, 82, 79, None, 75, 79, 78, 75], [74, None, 78, 75, 74, None, None, None]]
    def put(sig, st, g, pan=0.0):
        i = int(st * SR)
        if i >= n or i < 0: return
        j = min(n, i + len(sig)); L[i:j] += g * (1 - pan) * sig[:j - i]; R[i:j] += g * (1 + pan) * sig[:j - i]
    for b in range(nb):
        root, ch = prog[b % 4]; st = b * bar
        inS = s0 is not None and st >= s0 - 0.01 and (s1 is None or st < s1 + bar)
        sw = 1.0 if inS else 0.0
        tp = tt(bar + 0.6)
        pad = sum(sum(saw(2 * np.pi * hz(m) * (1 + dt) * tp + r.uniform(0, 6)) for dt in (-0.004, 0.004)) for m in ch)
        pad = lp(pad, 1200 + 2000 * sw, 2) * np.minimum(1, tp / 0.4) * np.minimum(1, (bar + 0.6 - tp) / 0.6); put(pad, st, 0.014 * (1 + 0.5 * sw))
        if sw:
            strg = sum(saw(2 * np.pi * hz(m + 12) * (1 + dt) * tp + r.uniform(0, 6)) for m in ch for dt in (-0.003, 0.0, 0.003))
            strg = lp(strg, 3400, 2) * np.minimum(1, tp / 0.8) * np.minimum(1, (bar + 0.6 - tp) / 0.6) * (1 + 0.05 * np.sin(2 * np.pi * 5.5 * tp))
            put(strg, st, 0.009)
        # bass: syncopated (1, 2&, 3, 4&)
        for off, mm in ((0, root), (1.5, root + 7), (2, root), (3.5, root + 12 if b % 2 else root + 7)):
            tb = tt(beat * 0.9); bs = (np.sin(2 * np.pi * hz(mm) * tb) + 0.35 * np.sin(4 * np.pi * hz(mm) * tb)) * env(len(tb), 0.006, 0.12)
            put(lp(bs, 900), st + off * beat, 0.26)
        # oud-ish pluck arpeggio, eighths
        pat = [0, 1, 2, 1, 0, 2, 1, 2]
        for q in range(8):
            m = ch[pat[q] % len(ch)]; put(pz(m, 0.5, 0.35), st + q * beat / 2, 0.12, pan=0.3 * (1 if q % 2 else -1))
        # hand drum: doum on 1 and 2&, tek on 2, 3&, 4 ; kick reinforcement in the swell
        if b >= 1:
            for q, kind in ((0, "D"), (1, "T"), (1.5, "D"), (2.5, "T"), (3, "T"), (3.5, "t")):
                if kind == "D":
                    td = tt(0.35); f = 75 * np.exp(-td * 9) + 60
                    put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-td * 9), st + q * beat, 0.40 * (1 + 0.3 * sw))
                else:
                    m = int(0.09 * SR); g = 0.12 if kind == "T" else 0.06
                    tk = bp(r.standard_normal(m), 1800, 6000) * np.exp(-np.arange(m) / SR * 60) + 0.4 * np.sin(2 * np.pi * 900 * np.arange(m) / SR) * np.exp(-np.arange(m) / SR * 80)
                    put(tk, st + q * beat, g, pan=0.2)
            for q in range(16):
                m = int(0.04 * SR); nz = hp(r.standard_normal(m), 6500) * np.exp(-np.arange(m) / SR * 85)
                put(nz, st + q * beat / 4, 0.02 if q % 2 else 0.032, pan=-0.35)
            if sw:
                for q in range(4):
                    td = tt(0.3); f = 100 * np.exp(-td * 20) + 48
                    put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-td * 12), st + q * beat, 0.30)
                for q in (1, 3):
                    m = int(0.16 * SR); c = sum(bp(r.standard_normal(m), 1000, 4500) * np.exp(-np.arange(m) / SR * 35) * (np.arange(m) >= int(k * 0.008 * SR)) for k in range(3))
                    put(room(c, 0.5, 0.3), st + q * beat, 0.08)
        # reed lead from bar 2
        if b >= 2:
            for q, m in enumerate(mel[b % 4]):
                if m is None: continue
                ln = 1
                while q + ln < 8 and mel[b % 4][q + ln] is None and ln < 2: ln += 1
                sig = reed(m - 12 if not sw else m, ln * beat / 2 * 0.98)
                put(sig, st + q * beat / 2, 0.05 * (1 + 0.4 * sw), pan=0.15)
                if sw: put(reed(m - 12, ln * beat / 2 * 0.98), st + q * beat / 2, 0.03, pan=-0.15)
    if s0 is not None:
        dr = 2.0; tr = tt(dr); nz = rng.standard_normal(len(tr)); u = tr / dr
        ris = hp(nz, 2000) * u ** 2.5 + 0.4 * bp(nz, 600, 3000) * u ** 2; put(norm(ris), s0 - dr, 0.10)
        tc = tt(3.0); cy = hp(rng.standard_normal(len(tc)), 4500) * np.exp(-tc * 1.6) * np.minimum(1, tc / 0.004); put(norm(room(cy, 1.5, 0.4)), s0, 0.09)
    x = np.stack([room(L, 1.0, 0.2, 1), room(R, 1.0, 0.2, 2)])
    fade = np.minimum(1, np.arange(n) / (0.02 * SR)) * np.minimum(1, (n - np.arange(n)) / (end_fade * SR))
    return x * fade / (np.abs(x).max() + 1e-9)

def act_rms(x):
    n = int(0.05 * SR); e = np.array([np.sqrt((x[i:i + n] ** 2).mean()) for i in range(0, len(x) - n, n)]); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
def mix(dur, events, out_wav, swell=(None, None), swell_db=4.0):
    """music-only mix (loudnorm TP target -2.2 dB on the WAV so the AAC encode stays under -1.5 dBTP): SFX set relative to the music's active RMS (xdb per event), swell gain curve, two-pass loudnorm"""
    n = int(dur * SR); m = music(dur, swell); tq = np.arange(n) / SR; s0, s1 = swell
    g = np.ones(n) if s0 is None else 10 ** (swell_db * np.clip((tq - (s0 - 1.0)) / 1.2, 0, 1) * (1 - 0.6 * np.clip((tq - s1) / 1.0, 0, 1)) / 20)
    mr = act_rms(m.mean(0)); m = m * g
    S = np.zeros((2, n)); rep = []
    for t0, x, xdb in events:
        x = np.atleast_2d(x); x = np.vstack([x, x]) if x.shape[0] == 1 else x
        gg = mr * 10 ** (xdb / 20) / (act_rms(x.mean(0)) + 1e-12); i = int(t0 * SR); j = min(n, i + x.shape[1])
        if j > i: S[:, i:j] += x[:, :j - i] * gg; rep.append(round(t0, 2))
    y = m + S
    raw = y.T.astype(np.float32).tobytes()
    meas = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af",
                           "loudnorm=I=-14:TP=-2.2:LRA=11:print_format=json", "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
    J = json.loads(meas[meas.rfind("{"):meas.rfind("}") + 1])
    af = (f"loudnorm=I=-14:TP=-2.2:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
          f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af, "-ar", "48000", "-c:a", "pcm_s16le", out_wav], input=raw, capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-400:]
    return {"input_I": J["input_i"], "sfx_at": rep}
