"""Shabbat World Record, Part 2: "Let's break a Guinness World Record. Together."
Music-driven reel (no VO), bilingual EN + HE burned-in text, SFX. 1080x1920, 30 fps. Frames stream into ffmpeg.

Importable: Part 3 (/home/claude/shabbat_p3) may reuse the visuals:
    sys.path.insert(0, "/home/claude/shabbat_record"); import shabbat_render as SR
    SR.background(c, t, warm)                # silver house gradient, optional candle-warm glow
    SR.long_table(c, t, box, lit0, step)     # one-point-perspective candle-lit table at dusk inside a rounded panel
    SR.beach(c, t, lit0, t3000=None)         # Tel Aviv beach at sunset, long table, candles light front to back
    SR.flag(c, code, x, y, w)                # IL DE US LB PT PH
    SR.flame / SR.candle / SR.challah / SR.cup / SR.record_card / SR.stamp / SR.series_chip / SR.T
Nothing runs on import; render with:  python3 shabbat_render.py [--preview t1,t2,...]"""
import sys, os, math, json, random, subprocess
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/shabbat_record")
import numpy as np, cairo
from PIL import Image
import kit
from kit import (W, H, FPS, ease, ramp, lerp, hx, pop, St, sa, rr, line, circ, box, tx, font, is_he, QA, CUR,
                 surf2pil, sheet_of, DASHES, chip)

D = "/home/claude/shabbat_record"
SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/shabbat"
NAVY = hx("#163260"); BLUE = hx("#2A88D4"); GOLD = hx("#B8923F"); GOLD2 = hx("#E6C77E"); SILV = hx("#B9C0CA")
WHITE = (1, 1, 1, 1); RED = hx("#D63A4A"); GREEN = hx("#1E9E62"); GREY = hx("#5B6B82"); AMBER = hx("#FFB23F")
def c255(col): return tuple(int(round(v * 255)) for v in col[:3]) + (255,)
N2, B2, G2, W2, R2, GY2 = map(c255, (NAVY, BLUE, GOLD, WHITE, RED, GREY))
GD2 = (150, 112, 40, 255)        # darker gold for text on silver (contrast)
LG2 = c255(GOLD2)                # light gold for text on dark panels

def T(c, s, sz, x, y, col=N2, a=1.0, sc=1.0, w=900, hl=B2, maxw=940, src=False, anchor="c"):
    return tx(c, s, sz, x, y, w=w, col=col, a=a, sc=sc, hl=hl, shadow=False, maxw=maxw, src=src, anchor=anchor)
def count(t, t0, d, v0, v1): return lerp(v0, v1, ease((t - t0) / d)) if t >= t0 else v0
def fmt(v, dec=0): return f"{v:,.{dec}f}"
def icon(c, x, y, s, fn, *args, a=1.0):
    if a <= 0.01 or abs(s) < 1e-3: return
    c.save(); c.translate(x, y); c.scale(s, s); old = St.a; St.a *= a; fn(c, *args); St.a = old; c.restore()

# ------------------------------------------------------------------ background
_sp = None
def background(c, t, warm=0.0):
    global _sp
    g = cairo.LinearGradient(0, 0, W * 0.4, H); g.add_color_stop_rgb(0, *hx("#F4F5F7")[:3]); g.add_color_stop_rgb(1, *hx("#D9DDE3")[:3])
    c.set_source(g); c.paint()
    for k, (bx, by, br) in enumerate([(300, 520, 560), (820, 1350, 620)]):
        x = bx + 60 * math.sin(t * 0.25 + k * 2); y = by + 50 * math.cos(t * 0.3 + k)
        rg = cairo.RadialGradient(x, y, 0, x, y, br); rg.add_color_stop_rgba(0, 1, 1, 1, 0.75); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        c.set_source(rg); c.arc(x, y, br, 0, 2 * math.pi); c.fill()
    if warm > 0.01:   # candlelight warmth
        fl = 1 + 0.04 * math.sin(t * 9) + 0.03 * math.sin(t * 13.7)
        rg = cairo.RadialGradient(540, 700, 0, 540, 700, 1100 * fl)
        rg.add_color_stop_rgba(0, 1, 0.78, 0.42, 0.30 * warm); rg.add_color_stop_rgba(1, 1, 0.75, 0.4, 0); c.set_source(rg); c.paint()
    if _sp is None:
        R = random.Random(3); _sp = [(R.uniform(40, 1040), R.uniform(0, H), R.uniform(6, 13), R.uniform(14, 30), R.random() * 6) for _ in range(26)]
    for k, (x0, y0, r, sp, ph) in enumerate(_sp):
        y = (y0 - t * sp) % (H + 60) - 30; x = x0 + 14 * math.sin(t * 0.7 + k); tw = 0.5 + 0.5 * math.sin(t * 2 + ph)
        sa(c, SILV if k % 4 else GOLD, 0.35 + 0.35 * tw); c.save(); c.translate(x, y); c.rotate(math.pi / 4)
        c.rectangle(-r / 2, -r / 2, r, r); c.fill(); c.restore()

# ------------------------------------------------------------------ candles and Shabbat table things
def flame(c, x, y, s, t, j=0, u=1.0, glow=1.0):
    """flame whose base sits at (x, y); u = 0..1 ignition"""
    if u <= 0.01: return
    fl = 1 + 0.12 * math.sin(t * 17 + j * 1.3) + 0.05 * math.sin(t * 29 + j)
    if glow > 0:
        R_ = 46 * s * u * glow; rg = cairo.RadialGradient(x, y - 10 * s, 0, x, y - 10 * s, R_)
        rg.add_color_stop_rgba(0, 1, 0.85, 0.45, 0.6 * u * St.a); rg.add_color_stop_rgba(1, 1, 0.8, 0.4, 0); c.set_source(rg)
        c.arc(x, y - 10 * s, max(R_, 0.1), 0, 2 * math.pi); c.fill()
    c.save(); c.translate(x, y); c.rotate(0.05 * math.sin(t * 5 + j)); c.scale(s * u, s * u * fl)
    c.move_to(0, 2); c.curve_to(-8, -4, -6, -14, 0, -22); c.curve_to(6, -14, 8, -4, 0, 2); sa(c, AMBER); c.fill()
    c.move_to(0, 1); c.curve_to(-4, -3, -3, -9, 0, -14); c.curve_to(3, -9, 4, -3, 0, 1); sa(c, hx("#FFF1B8")); c.fill(); c.restore()
def candle(c, x, y, s, h=60):
    """candle standing on (x, y), returns the wick top y"""
    box(c, x - 6 * s, y - h * s, 12 * s, h * s, 3 * s, WHITE, stroke=SILV, sw=max(1, 2 * s))
    line(c, [(x, y - h * s), (x, y - (h + 6) * s)], hx("#3A3A3A"), max(1, 2 * s))
    return y - (h + 5) * s
def candlestick(c, x, y, s=1.0):
    g = cairo.LinearGradient(x - 40 * s, 0, x + 40 * s, 0)
    for st_, col in ((0, "#9AA3AF"), (0.45, "#F4F5F7"), (1, "#8D96A3")): g.add_color_stop_rgb(st_, *hx(col)[:3])
    c.save(); c.scale(1, 1)
    c.move_to(x - 48 * s, y); c.line_to(x + 48 * s, y); c.line_to(x + 14 * s, y - 22 * s); c.line_to(x + 8 * s, y - 120 * s)
    c.line_to(x + 26 * s, y - 132 * s); c.line_to(x - 26 * s, y - 132 * s); c.line_to(x - 8 * s, y - 120 * s); c.line_to(x - 14 * s, y - 22 * s); c.close_path()
    c.set_source(g); c.fill(); c.restore()
    return candle(c, x, y - 132 * s, s * 1.6, 70)
def challah(c, x, y, s=1.0):
    for k in range(6):
        cx = x + (k - 2.5) * 34 * s; cy = y - 26 * s * math.sin(math.pi * (k + 0.5) / 6)
        c.save(); c.translate(cx, cy); c.rotate(0.5 if k % 2 else -0.5); c.scale(1, 0.72)
        g = cairo.RadialGradient(-8 * s, -10 * s, 4 * s, 0, 0, 38 * s); g.add_color_stop_rgb(0, *hx("#E9A65A")[:3]); g.add_color_stop_rgb(1, *hx("#9C5A22")[:3])
        c.arc(0, 0, 36 * s, 0, 2 * math.pi); c.set_source(g); c.fill(); c.restore()
    for k in range(9):
        circ(c, x + (k - 4) * 20 * s, y - 34 * s - 6 * s * math.sin(k), 2.4 * s, hx("#FFF6E0"))
def cup(c, x, y, s=1.0):
    g = cairo.LinearGradient(x - 40 * s, 0, x + 40 * s, 0)
    for st_, col in ((0, "#9AA3AF"), (0.45, "#F4F5F7"), (1, "#8D96A3")): g.add_color_stop_rgb(st_, *hx(col)[:3])
    c.move_to(x - 40 * s, y); c.line_to(x + 40 * s, y); c.line_to(x + 8 * s, y - 18 * s); c.line_to(x + 8 * s, y - 60 * s)
    c.curve_to(x + 46 * s, y - 70 * s, x + 46 * s, y - 130 * s, x + 44 * s, y - 140 * s); c.line_to(x - 44 * s, y - 140 * s)
    c.curve_to(x - 46 * s, y - 130 * s, x - 46 * s, y - 70 * s, x - 8 * s, y - 60 * s); c.line_to(x - 8 * s, y - 18 * s); c.close_path()
    c.set_source(g); c.fill()
    c.save(); c.translate(x, y - 132 * s); c.scale(1, 0.25); circ(c, 0, 0, 42 * s, hx("#7A1E33")); c.restore()

def panel_clip(c, x0, y0, x1, y1, r=34):
    sa(c, NAVY, 0.18); rr(c, x0 + 4, y0 + 16, x1 - x0, y1 - y0, r); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, r); c.clip()
def panel_end(c, x0, y0, x1, y1, r=34):
    c.restore(); rr(c, x0, y0, x1 - x0, y1 - y0, r); sa(c, NAVY); c.set_line_width(6); c.stroke()

COLS = (NAVY, BLUE, GOLD, hx("#D9665B"), hx("#1E9E62"))
def long_table(c, t, bx=(80, 360, 1000, 980), lit0=-10.0, step=0.12, n=11):
    """one-point-perspective long Shabbat table at dusk, string lights overhead, diners both sides.
    candles light from the front (lit0) back, one every `step` s. bx = panel box (x0, y0, x1, y1)."""
    x0, y0, x1, y1 = bx; cx = (x0 + x1) / 2; Hh = y1 - y0
    hz_ = y0 + 0.40 * Hh; near = y1 - 0.08 * Hh; hwN = 0.30 * (x1 - x0)
    panel_clip(c, x0, y0, x1, y1)
    g = cairo.LinearGradient(0, y0, 0, hz_)
    for st_, col in ((0, "#0F2346"), (0.55, "#2E2C5E"), (0.85, "#7A4A6A"), (1, "#C9805E")): g.add_color_stop_rgb(st_, *hx(col)[:3])
    c.set_source(g); c.paint()
    R_ = random.Random(4)
    for k in range(16):
        circ(c, R_.uniform(x0 + 20, x1 - 20), R_.uniform(y0 + 15, hz_ - 60), R_.uniform(1.5, 3), WHITE, 0.3 + 0.4 * (0.5 + 0.5 * math.sin(t * 2 + k)))
    g = cairo.LinearGradient(0, hz_, 0, y1); g.add_color_stop_rgb(0, *hx("#3B3552")[:3]); g.add_color_stop_rgb(1, *hx("#1C2340")[:3])
    c.rectangle(x0, hz_, x1 - x0, y1 - hz_); c.set_source(g); c.fill()
    rg = cairo.RadialGradient(cx, (hz_ + near) / 2, 0, cx, (hz_ + near) / 2, 0.6 * (x1 - x0))
    rg.add_color_stop_rgba(0, 1, 0.75, 0.4, 0.35); rg.add_color_stop_rgba(1, 1, 0.7, 0.4, 0); c.set_source(rg); c.paint()
    def P(z):  # depth z>=1 -> scale, y, half width
        s = 1 / z; return s, hz_ + (near - hz_) * s, 8 + (hwN - 8) * s
    # string lights: two strands converging to the vanishing point
    for side in (-1, 1):
        pts = []
        for z in np.linspace(1, 14, 40):
            s, y, hw = P(z); pts.append((cx + side * (hw + 70 * s), y - 330 * s - 40 * s * math.sin(z * 1.3) ** 2))
        line(c, pts, hx("#0B1530"), 2, 0.8)
        for k, (px, py) in enumerate(pts[::3]):
            circ(c, px, py + 6, 6 * P(1 + k * 1.0)[0] + 2, hx("#FFD98A"), 0.75 + 0.25 * math.sin(t * 3 + k * 1.7))
    zs = np.linspace(1.0, 12, n)
    # table top (trapezoid) and front edge
    sF, yF, hwF = P(zs[0] * 0.92); sB, yB, hwB = P(30)
    c.move_to(cx - hwF, yF); c.line_to(cx + hwF, yF); c.line_to(cx + hwB, yB); c.line_to(cx - hwB, yB); c.close_path()
    g = cairo.LinearGradient(0, yB, 0, yF); g.add_color_stop_rgb(0, *hx("#C9C2C0")[:3]); g.add_color_stop_rgb(1, *hx("#FFFFFF")[:3]); c.set_source(g); c.fill()
    box(c, cx - hwF, yF, 2 * hwF, 34 * sF, 4, hx("#E3DED8"))
    # diners and candles back to front
    for i in range(n - 1, -1, -1):
        s, y, hw = P(zs[i])
        for side in (-1, 1):
            col = COLS[(i * 2 + (side > 0)) % 5]
            hx_ = cx + side * (hw + 44 * s); circ(c, hx_, y - 92 * s, 30 * s, col)
            box(c, hx_ - 36 * s, y - 62 * s, 72 * s, 70 * s, 26 * s, COLS[(i * 2 + 2 + (side > 0)) % 5])
        for side in (-0.42, 0.42):
            px = cx + side * hw
            circ(c, px + (24 if side < 0 else -24) * s, y + 4 * s, 22 * s, WHITE, stroke=SILV, sw=max(1, 2 * s))
        wy = candle(c, cx, y, s * 1.2, 46)
        tl = lit0 + step * i; u = ramp(t, tl, tl + 0.25)
        flame(c, cx, wy, s * 1.9, t, i, u)
        if i % 3 == 1: challah(c, cx + 0.2 * hw, y + 2 * s, s * 0.6)
    panel_end(c, x0, y0, x1, y1)

# ------------------------------------------------------------------ the beach (flat vector, Tel Aviv at sunset; from guinness_il/v2.py, adapted)
PX0, PY0, PX1, PY1 = 80, 392, 1000, 1030; HZ = 760
def shore_y(x): return HZ + 2 + (620 - x) / 540 * 140 if x < 620 else HZ + 2
TAB = [(lerp(175, 905, u), lerp(952, 840, u), lerp(1.0, 0.5, u)) for u in np.linspace(0, 1, 18)]
def beach(c, t, lit0, step=0.16, t3000=None, appear=None):
    """beach panel; candles light front to back from lit0 (one every `step` s); big gold counter to 3,000 from t3000"""
    a, s_ = (1.0, 1.0) if appear is None else pop(t, appear, d=0.55, s0=0.7, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, 711); c.scale(s_, s_); c.translate(-540, -711)
    panel_clip(c, PX0, PY0, PX1, PY1)
    g = cairo.LinearGradient(0, PY0, 0, HZ)
    for st_, col in ((0, "#163260"), (0.38, "#4B3A7A"), (0.7, "#D9665B"), (0.9, "#F29A57"), (1, "#F7C873")): g.add_color_stop_rgb(st_, *hx(col)[:3])
    c.set_source(g); c.paint()
    R_ = random.Random(9)
    for k in range(18):
        x = R_.uniform(PX0 + 20, PX1 - 20); y = R_.uniform(PY0 + 15, PY0 + 150); tw = 0.5 + 0.5 * math.sin(t * 2.2 + k)
        circ(c, x, y, R_.uniform(1.6, 3.2), WHITE, 0.35 + 0.45 * tw)
    sx, sy = 330, HZ + 4; rg = cairo.RadialGradient(sx, sy, 40, sx, sy, 330)
    rg.add_color_stop_rgba(0, 1, 0.86, 0.5, 0.55 * St.a); rg.add_color_stop_rgba(1, 1, 0.7, 0.4, 0); c.set_source(rg); c.paint()
    circ(c, sx, sy, 88, hx("#FFD27A"))
    sky = hx("#3A2E5E")
    for (x, w_, h_) in ((640, 40, 40), (684, 30, 62), (720, 46, 48), (770, 28, 96), (804, 36, 70), (846, 50, 118), (900, 30, 80), (936, 44, 58), (982, 30, 44)):
        box(c, x, HZ - h_, w_, h_ + 6, 3, sky)
    c.move_to(846, HZ - 118); c.line_to(871, HZ - 150); c.line_to(896, HZ - 118); c.close_path(); sa(c, sky); c.fill()
    circ(c, 787, HZ - 100, 15, sky)
    for (x, y) in ((690, HZ - 40), (812, HZ - 50), (860, HZ - 90), (944, HZ - 36)):
        box(c, x, y, 6, 8, 1, hx("#FFD27A"), 0.7 + 0.3 * math.sin(t * 3 + x))
    box(c, 600, HZ - 4, 420, 10, 2, hx("#2E2450"))
    g = cairo.LinearGradient(0, HZ, 0, PY1); g.add_color_stop_rgb(0, *hx("#E0875F")[:3]); g.add_color_stop_rgb(0.35, *hx("#3E6FA8")[:3]); g.add_color_stop_rgb(1, *hx("#21497F")[:3])
    c.move_to(PX0, HZ); c.line_to(620, HZ); c.line_to(620, HZ + 2)
    for x in np.linspace(620, PX0, 20): c.line_to(x, shore_y(x))
    c.line_to(PX0, PY1); c.close_path(); c.set_source(g); c.fill()
    for k in range(9):
        y = HZ + 14 + k * 13; wv = 90 - k * 7 + 10 * math.sin(t * 2 + k)
        line(c, [(sx - wv / 2 + 8 * math.sin(t * 1.7 + k), y), (sx + wv / 2 + 8 * math.sin(t * 1.7 + k), y)], hx("#FFD27A"), 4, 0.55)
    g = cairo.LinearGradient(0, HZ, 0, PY1); g.add_color_stop_rgb(0, *hx("#F3C98E")[:3]); g.add_color_stop_rgb(1, *hx("#E7B173")[:3])
    c.move_to(620, HZ + 2); c.line_to(PX1, HZ + 2); c.line_to(PX1, PY1); c.line_to(PX0, PY1)
    for x in np.linspace(PX0, 620, 20): c.line_to(x, shore_y(x) + 8 * math.sin(t * 1.2 + x * 0.02) * (620 - x) / 540)
    c.close_path(); c.set_source(g); c.fill()
    pts = [(x, shore_y(x) + 6 * math.sin(t * 1.2 + x * 0.02) * (620 - x) / 540) for x in np.linspace(PX0, 620, 24)]
    line(c, pts, WHITE, 5, 0.75)
    A = [(x, y - 14 * s) for x, y, s in TAB]; B = [(x, y + 14 * s) for x, y, s in TAB]
    for k, (x, y, s) in enumerate(TAB[::-1]):
        circ(c, x + 6 * s, y - 40 * s, 13 * s, COLS[k % 5]); box(c, x - 8 * s, y - 30 * s, 28 * s, 18 * s, 8 * s, COLS[(k + 2) % 5])
    c.move_to(*A[0])
    for p in A[1:]: c.line_to(*p)
    for p in B[::-1]: c.line_to(*p)
    c.close_path(); sa(c, WHITE); c.fill()
    c.move_to(*B[0])
    for p in B[1:]: c.line_to(*p)
    for x, y, s in TAB[::-1]: c.line_to(x, y + 22 * s)
    c.close_path(); sa(c, hx("#D9DDE3")); c.fill()
    for k, (x, y, s0_) in enumerate(TAB[::-1]):
        s = s0_ * 1.6; j = len(TAB) - 1 - k; tl = lit0 + step * j
        wy = candle(c, x, y - 4 * s, s, 22)
        flame(c, x, wy + 2 * s, s, t, j, ramp(t, tl, tl + 0.25))
        if k % 3 == 1: circ(c, x + 12 * s0_, y - 6 * s0_, 6 * s0_, hx("#C77A36"))
    for k, (x, y, s) in enumerate(TAB[::-1]):
        circ(c, x - 10 * s, y + 34 * s, 14 * s, COLS[(k + 3) % 5]); box(c, x - 26 * s, y + 42 * s, 32 * s, 26 * s, 10 * s, COLS[(k + 1) % 5])
    panel_end(c, PX0, PY0, PX1, PY1)
    c.restore(); St.a = old
    if t3000 is not None and t >= t3000 - 0.05:
        v = count(t, t3000, 1.2, 0, 3000); land = t3000 + 1.2
        a2 = ramp(t, t3000 - 0.05, t3000 + 0.1); pu = 1 + 0.12 * math.exp(-((t - land) / 0.12) ** 2) if t > land - 0.3 else 1
        tx(c, fmt(round(v / 10) * 10 if t < land else 3000), 210, 540, 545, col=LG2, a=a2 * a, sc=pu, shadow=True)
        if t > land:
            for k in range(16):
                ang = k / 16 * 2 * math.pi; d_ = 160 + 260 * ease((t - land) / 0.9); al = 1 - ramp(t, land + 0.3, land + 1.0)
                if al > 0.01:
                    c.save(); c.translate(540 + d_ * math.cos(ang), 545 + 0.6 * d_ * math.sin(ang)); c.rotate(ang + t * 3)
                    sa(c, GOLD2 if k % 2 else WHITE, al * a); c.rectangle(-7, -7, 14, 14); c.fill(); c.restore()

# ------------------------------------------------------------------ flags (simplified, drawn)
def star(c, x, y, r, n=5, inner=0.45, rot=-math.pi / 2):
    for k in range(2 * n):
        rr_ = r if k % 2 == 0 else r * inner; a = rot + k * math.pi / n
        (c.move_to if k == 0 else c.line_to)(x + rr_ * math.cos(a), y + rr_ * math.sin(a))
    c.close_path()
def flag(c, code, x, y, w):
    """flag centred on (x, y), width w, 3:2"""
    h = w * 2 / 3; x0, y0 = x - w / 2, y - h / 2
    sa(c, NAVY, 0.15); rr(c, x0 + 3, y0 + 6, w, h, 8); c.fill()
    c.save(); rr(c, x0, y0, w, h, 8); c.clip()
    def band(col, fx0, fy0, fx1, fy1): sa(c, col); c.rectangle(x0 + fx0 * w, y0 + fy0 * h, (fx1 - fx0) * w, (fy1 - fy0) * h); c.fill()
    if code == "IL":
        band(WHITE, 0, 0, 1, 1); ib = hx("#0038B8"); band(ib, 0, 0.1, 1, 0.25); band(ib, 0, 0.75, 1, 0.9)
        r = h * 0.2; sa(c, ib); c.set_line_width(max(2, h * 0.035))
        for rot in (-math.pi / 2, math.pi / 2):
            for k in range(3):
                a = rot + k * 2 * math.pi / 3; (c.move_to if k == 0 else c.line_to)(x + r * math.cos(a), y + r * math.sin(a))
            c.close_path(); c.stroke()
    elif code == "DE":
        band(hx("#111111"), 0, 0, 1, 1 / 3); band(hx("#DD0000"), 0, 1 / 3, 1, 2 / 3); band(hx("#FFCE00"), 0, 2 / 3, 1, 1)
    elif code == "US":
        for k in range(13): band(hx("#B22234") if k % 2 == 0 else WHITE, 0, k / 13, 1, (k + 1) / 13)
        band(hx("#3C3B6E"), 0, 0, 0.4, 7 / 13)
        for i in range(5):
            for j in range(4): circ(c, x0 + (0.05 + i * 0.075) * w, y0 + (0.07 + j * 0.13) * h, max(1, h * 0.022), WHITE)
    elif code == "LB":
        band(hx("#ED1C24"), 0, 0, 1, 0.25); band(WHITE, 0, 0.25, 1, 0.75); band(hx("#ED1C24"), 0, 0.75, 1, 1)
        sa(c, hx("#00A651"))
        for k in range(3):
            yy = y - h * 0.2 + k * h * 0.12; ww = w * (0.08 + 0.05 * k)
            c.move_to(x, yy - h * 0.06); c.line_to(x + ww, yy + h * 0.08); c.line_to(x - ww, yy + h * 0.08); c.close_path(); c.fill()
        c.rectangle(x - w * 0.015, y + h * 0.13, w * 0.03, h * 0.08); c.fill()
    elif code == "PT":
        band(hx("#006600"), 0, 0, 0.4, 1); band(hx("#FF0000"), 0.4, 0, 1, 1)
        circ(c, x0 + 0.4 * w, y, h * 0.24, hx("#FFCC00")); box(c, x0 + 0.4 * w - h * 0.12, y - h * 0.14, h * 0.24, h * 0.28, h * 0.08, hx("#FF0000"), stroke=WHITE, sw=max(1, h * 0.03))
    elif code == "PH":
        band(hx("#0038A8"), 0, 0, 1, 0.5); band(hx("#CE1126"), 0, 0.5, 1, 1)
        c.move_to(x0, y0); c.line_to(x0 + 0.433 * h * 1.0, y); c.line_to(x0, y0 + h); c.close_path(); sa(c, WHITE); c.fill()
        circ(c, x0 + 0.16 * h, y, h * 0.08, hx("#FCD116"))
        for (fx, fy) in ((0.05, 0.1), (0.05, 0.9), (0.36, 0.5)):
            star(c, x0 + fx * h, y0 + fy * h, h * 0.045); sa(c, hx("#FCD116")); c.fill()
    c.restore(); rr(c, x0, y0, w, h, 8); sa(c, hx("#9AA3AF")); c.set_line_width(2); c.stroke()

# ------------------------------------------------------------------ certificate pieces
def series_chip(c, a=1.0, sc=1.0, y=272):
    """small gold series chip (Part 2 of 3)"""
    chip(c, "SHABBAT WORLD RECORD | PART 2", 38, 540, y, GOLD, fg=W2, a=a, sc=sc, w=800, padh=1.5)
def stamp(c, t, t0, s, x, y, col, rot=-0.08, sz=50):
    if t < t0: return
    u = (t - t0) / 0.28; sc = 1.0 if u >= 1 else lerp(2.4, 1.0, ease(u)); a = ramp(t, t0, t0 + 0.12)
    f = font(sz, 900); tw = f.getlength(s); pw, ph = tw + 64, sz * 1.6
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc)
    box(c, -pw / 2, -ph / 2, pw, ph, 14, WHITE, a=0.94 * a, stroke=col, sw=7)
    c.restore()
    c.save(); c.translate(x, y); c.rotate(rot); T(c, s, sz, 0, 2, col=c255(col), a=a, sc=sc, maxw=880); c.restore()
def record_card(c, t, t0, x, y, w, h, fl, num, dec, unit, title, he, place, extra=None):
    """generic WORLD RECORD card (no Guinness art): flag, counter, unit, EN title, HE title, place/year"""
    a, s = pop(t, t0, d=0.5, s0=0.6, bounce=1.5)
    if a <= 0.01: return
    old = St.a; St.a *= a
    c.save(); c.translate(x, y); c.scale(s, s); c.translate(-x, -y)
    x0, y0 = x - w / 2, y - h / 2
    sa(c, NAVY, 0.16); rr(c, x0 + 4, y0 + 14, w, h, 24); c.fill()
    box(c, x0, y0, w, h, 24, WHITE, stroke=NAVY, sw=6)
    rr(c, x0 + 14, y0 + 14, w - 28, h - 28, 14); sa(c, BLUE); c.set_line_width(2); c.stroke()
    for (px, py) in ((x0 + 14, y0 + 14), (x0 + w - 14, y0 + 14), (x0 + 14, y0 + h - 14), (x0 + w - 14, y0 + h - 14)):
        c.save(); c.translate(px, py); c.rotate(math.pi / 4); sa(c, GOLD); c.rectangle(-8, -8, 16, 16); c.fill(); c.restore()
    flag(c, fl, x, y0 + 72, 108)
    v = count(t, t0 + 0.25, 1.0, 0, num)
    T(c, fmt(v, dec if t > t0 + 1.25 else 0) if t < t0 + 1.25 else fmt(num, dec), 76, x, y0 + 178, col=N2, maxw=w - 40)
    T(c, unit, 38, x, y0 + 234, col=GY2, w=700, maxw=w - 40)
    yy = y0 + 292
    for k, ln in enumerate(title): T(c, ln, 44, x, yy + 50 * k, col=B2, w=800, maxw=w - 40)
    yy += 50 * len(title) + 6
    T(c, he, 40, x, yy, col=GD2, w=700, maxw=w - 40)
    T(c, place, 36, x, yy + 56, col=GY2, w=700, maxw=w - 40)
    if extra: T(c, extra, 36, x, yy + 100, col=GY2, w=700, maxw=w - 40)
    c.restore(); St.a = old
def source(c, t, t0, lines, y0=1430):
    a = ramp(t, t0, t0 + 0.3)
    for k, s in enumerate(lines): T(c, s, 36, 540, y0 + 46 * k, col=GY2, a=a, w=700, src=True)
def hand_down(c):   # the pointing-down hand, drawn (from guinness_il/v2.py)
    g = cairo.LinearGradient(-60, -100, 60, 100); g.add_color_stop_rgb(0, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
    box(c, -40, -120, 80, 34, 10, BLUE)
    rr(c, -58, -92, 116, 96, 34); c.set_source(g); c.fill_preserve(); sa(c, hx("#8E6E2A")); c.set_line_width(5); c.stroke()
    for k in range(3): line(c, [(-30 + k * 26, -10), (-30 + k * 26, -40)], hx("#8E6E2A"), 4)
    rr(c, -20, -20, 40, 130, 20); c.set_source(g); c.fill_preserve(); sa(c, hx("#8E6E2A")); c.set_line_width(5); c.stroke()
    box(c, -10, 84, 20, 16, 7, WHITE, a=0.8)
def quote_marks(c):
    for sx in (-34, 34):
        circ(c, sx, 0, 28, GOLD); c.move_to(sx + 10, 18); c.curve_to(sx + 26, 50, sx - 4, 84, sx - 26, 92)
        c.curve_to(sx - 6, 70, sx - 4, 46, sx - 10, 24); c.close_path(); sa(c, GOLD); c.fill()

# ------------------------------------------------------------------ timeline
TL = dict(hook=0.0, shabbat=3.6, quote=8.6, tables=13.4, race=24.0, plan=34.2, cta=42.6, end=47.8)

def build():
    S = []
    def add(key, fn, **kw): S.append(dict(t0=TL[key], key=key, fn=fn, **kw))

    def hook(c, t, sc):        # everything on screen at frame 0
        series_chip(c)
        long_table(c, t, (80, 330, 1000, 990), lit0=-10)
        T(c, "Let's break a", 84, 540, 1080)
        T(c, "*Guinness World Record.*", 92, 540, 1185, hl=B2)
        T(c, "*Together.*", 104, 540, 1300, hl=GD2)
        T(c, "בואו נשבור שיא גינס. ביחד.", 60, 540, 1405, col=N2)
    add("hook", hook, warm=1.0)

    def shabbat(c, t, sc):
        t0 = sc["t0"]; sc_l = sc["light"]
        panel_clip(c, 80, 300, 1000, 900)
        g = cairo.LinearGradient(0, 300, 0, 900); g.add_color_stop_rgb(0, *hx("#1A2448")[:3]); g.add_color_stop_rgb(1, *hx("#3B2C4A")[:3]); c.set_source(g); c.paint()
        u = max(ramp(t, sc_l[0], sc_l[0] + 0.4), 0.0)
        rg = cairo.RadialGradient(540, 520, 0, 540, 520, 520); rg.add_color_stop_rgba(0, 1, 0.75, 0.4, 0.5 * u); rg.add_color_stop_rgba(1, 1, 0.7, 0.4, 0); c.set_source(rg); c.paint()
        c.move_to(80, 760); c.line_to(1000, 760); c.line_to(1000, 900); c.line_to(80, 900); c.close_path(); sa(c, WHITE); c.fill()
        box(c, 80, 752, 920, 16, 0, hx("#E3DED8"))
        for k, (x, tl) in enumerate(((330, sc_l[0]), (750, sc_l[1]))):
            wy = candlestick(c, x, 790, 1.15); flame(c, x, wy, 2.3, t, k, ramp(t, tl, tl + 0.3), glow=1.6)
        challah(c, 540, 850, 1.25); cup(c, 900, 880, 0.75)
        panel_end(c, 80, 300, 1000, 900)
        a, s = pop(t, t0 + 0.15); T(c, "Every Friday night.", 84, 540, 990, a=a, sc=s)
        a, s = pop(t, t0 + 0.7); T(c, "Candles. Challah. *One table.*", 66, 540, 1090, a=a, sc=s, hl=GD2)
        a, s = pop(t, t0 + 1.4); T(c, "For thousands of years.", 66, 540, 1180, a=a, sc=s, hl=B2)
        a, s = pop(t, t0 + 1.0); T(c, "כל שישי בערב. נרות, חלה, שולחן אחד.", 56, 540, 1275, a=a, sc=s, col=B2)
        a, s = pop(t, t0 + 1.6); T(c, "כבר אלפי שנים.", 56, 540, 1345, a=a, sc=s, col=B2)
        source(c, t, t0 + 1.2, ["Exodus 20:8: \"Remember the Sabbath day\""])
    add("shabbat", shabbat, warm=1.0, light=(TL["shabbat"] + 0.45, TL["shabbat"] + 1.05))

    def quote(c, t, sc):
        t0 = sc["t0"]
        a, s = pop(t, t0 + 0.1); icon(c, 540, 340, 1.0 * s, quote_marks, a=a)
        for k, (ln, d) in enumerate((("More than the Jews", 0.3), ("have kept Shabbat,", 0.5), ("Shabbat has kept", 1.0), ("*the Jews.*", 1.2))):
            a, s = pop(t, t0 + d); T(c, ln, 82, 540, 500 + 98 * k, a=a, sc=s, hl=GD2)
        a, s = pop(t, t0 + 1.6); T(c, "Ahad Ha'am, 1898", 56, 540, 920, a=a, sc=s, col=B2, w=800)
        a, s = pop(t, t0 + 1.9)
        T(c, "יותר משישראל שמרו את השבת,", 60, 540, 1040, a=a, sc=s, col=N2)
        T(c, "שמרה השבת אותם.", 60, 540, 1112, a=a, sc=s, col=N2)
        T(c, "אחד העם, 1898", 52, 540, 1190, a=a, sc=s, col=B2)
        source(c, t, t0 + 1.4, ["Ahad Ha'am (Asher Ginsberg), Hashiloah, 1898"], y0=1300)
    add("quote", quote, warm=0.7)

    CARDS = [  # (flag, value, decimals, unit, title, HE, place, extra)
        ("LB", 3255.8, 1, "metres", ["Longest table"], "השולחן הארוך בעולם", "Beirut, Lebanon, 2026", None),
        ("PT", 5050, 0, "metres, 15,000 places", ["Longest", "table setting"], "השולחן הערוך הארוך", "Lisbon, Portugal, 1998", None),
        ("PH", 6000.45, 2, "metres", ["Longest line", "of tables"], "שורת שולחנות ארוכה", "Philippines, 2017", None),
        ("PT", 22232, 0, "people", ["Largest picnic"], "הפיקניק הגדול בעולם", "Lisbon, Portugal, 2009", None),
    ]
    def tables(c, t, sc):
        t0 = sc["t0"]
        a, s = pop(t, t0 + 0.1); T(c, "The world's *biggest tables*", 70, 540, 284, a=a, sc=s)
        a, s = pop(t, t0 + 0.3); T(c, "השולחנות הגדולים בעולם", 56, 540, 352, a=a, sc=s, col=B2)
        for k, cd in enumerate(CARDS):
            x = 304 if k % 2 == 0 else 776; y = 660 if k < 2 else 1180
            record_card(c, t, sc["cards"][k], x, y, 456, 500, *cd)
        source(c, t, t0 + 0.6, ["Source: guinnessworldrecords.com"], y0=1482)
    add("tables", tables, cards=[TL["tables"] + 0.6 + 2.5 * k for k in range(4)])

    ROWS = [("IL", "Tel Aviv, 2014", 2226), ("DE", "Berlin, 2015", 2322), ("US", "New York, 2025", 2761)]
    def race(c, t, sc):
        t0 = sc["t0"]; ts = sc["rows"]
        a, s = pop(t, t0 + 0.1); T(c, "The largest *Shabbat dinner*", 72, 540, 300, a=a, sc=s)
        a, s = pop(t, t0 + 0.3); T(c, "ארוחת השבת הגדולה בעולם", 58, 540, 382, a=a, sc=s, col=B2)
        a, s = pop(t, t0 + 0.4); T(c, "WORLD RECORD: diners at one venue", 40, 540, 452, a=a, sc=s, col=GY2, w=700)
        X0, XM = 110, 860   # bar from X0, 3,000 diners = XM
        for k, (fl, who, n) in enumerate(ROWS):
            tk = ts[k]
            if t < tk - 0.05: continue
            y = 560 + 200 * k; a = ramp(t, tk - 0.05, tk + 0.15); old = St.a; St.a *= a
            flag(c, fl, X0 + 42, y, 84); T(c, who, 50, X0 + 104, y + 2, col=N2, w=800, anchor="l")
            v = count(t, tk + 0.1, 1.2, 0, n); bw = max(60, (XM - X0) * v / 3000)
            col = BLUE if k < 2 else NAVY
            box(c, X0, y + 46, bw, 70, 35, col)
            lab = fmt(v)
            if font(50, 900).getlength(lab) + 44 < bw: T(c, lab, 50, X0 + bw - 22, y + 82, col=W2, anchor="r")
            else: T(c, lab, 50, X0 + bw + 16, y + 82, col=N2, anchor="l")
            if k == 2 and t > tk + 1.3:
                a3, s3 = pop(t, tk + 1.3)
                chip(c, "CURRENT RECORD", 36, 830, y + 2, GOLD, fg=W2, a=a3, sc=s3, w=800)
            St.a = old
        stamp(c, t, sc["lost"], "LOST IT", 840, 641, RED, rot=-0.08, sz=46)
        a, s = pop(t, sc["lost"] + 0.25); T(c, "איבדנו את השיא", 44, 850, 562, a=a, sc=s, col=R2, w=700)
        tq = sc["tease"]
        if t >= tq - 0.05:
            y = 1160; a = ramp(t, tq - 0.05, tq + 0.2); old = St.a; St.a *= a
            flag(c, "IL", X0 + 42, y, 84); T(c, "Tel Aviv, April 2027", 50, X0 + 104, y + 2, col=GD2, w=800, anchor="l")
            u = ease((t - tq) / 1.0); bw = max(60, (XM - X0) * u)
            rr(c, X0, y + 46, bw, 70, 35); sa(c, GOLD, 0.18); c.fill_preserve(); sa(c, GOLD); c.set_line_width(5); c.set_dash([18, 12]); c.stroke(); c.set_dash([])
            if font(54, 900).getlength("3,000?") + 50 < bw: T(c, "3,000?", 54, X0 + bw - 26, y + 82, col=GD2, anchor="r")
            else: T(c, "3,000?", 54, X0 + bw + 16, y + 82, col=GD2, anchor="l")
            St.a = old
        source(c, t, t0 + 0.8, ["Sources: israel21c (Tel Aviv, 13 June 2014),", "GWR (Berlin 2015; New York, 21 Nov 2025)"], y0=1390)
    rt = TL["race"]
    add("race", race, rows=[rt + 0.8, rt + 2.6, rt + 5.0], lost=rt + 3.6, tease=rt + 7.4)

    def plan(c, t, sc):
        t0 = sc["t0"]
        a, s = pop(t, t0 + 0.05); T(c, "Now it's *our turn.*", 84, 540, 300, a=a, sc=s, hl=GD2)
        beach(c, t, sc["lit"], step=0.16, t3000=sc["c3000"], appear=t0 + 0.05)
        a, s = pop(t, sc["date"], bounce=2.4)
        chip(c, "APRIL 2027", 68, 540, 1110, NAVY, fg=LG2, a=a, sc=s, w=900, outline=GOLD)
        a, s = pop(t, sc["date"] + 0.35); T(c, "Tel Aviv beach. *3,000 people.*", 62, 540, 1215, a=a, sc=s, hl=GD2)
        a, s = pop(t, sc["date"] + 0.7); T(c, "One Shabbat dinner.", 62, 540, 1290, a=a, sc=s)
        a, s = pop(t, sc["date"] + 1.0); T(c, "אפריל 2027. חוף תל אביב.", 56, 540, 1365, a=a, sc=s, col=B2)
        T(c, "3,000 איש. ארוחת שבת אחת.", 56, 540, 1430, a=a, sc=s, col=B2)
        source(c, t, sc["date"] + 1.6, ["Our attempt. Not a record yet."], y0=1500)
    pt = TL["plan"]
    add("plan", plan, warm=0.6, lit=pt + 0.9, c3000=pt + 3.4, date=pt + 1.2)

    def cta(c, t, sc):
        t0 = sc["t0"]
        a, s = pop(t, t0 + 0.05); T(c, "Want a seat *at the table?*", 76, 540, 300, a=a, sc=s)
        a, s = pop(t, t0 + 0.2); T(c, "רוצים מקום ליד השולחן?", 60, 540, 385, a=a, sc=s, col=B2)
        a, s = pop(t, t0 + 0.35); T(c, "Comment", 70, 540, 480, a=a, sc=s)
        a, s = pop(t, t0 + 0.5, bounce=2.4)
        if a > 0.01:
            f = font(118, 900); pw = f.getlength("SHABBAT") + 130; ph = 186
            c.save(); c.translate(540, 620); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.18); rr(c, -pw / 2, -ph / 2 + 12, pw, ph, ph / 2); c.fill()
            g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *GOLD[:3]); g.add_color_stop_rgb(0.5, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
            rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, NAVY); c.set_line_width(7); c.stroke()
            St.a = old; c.restore()
            T(c, "SHABBAT", 118, 540, 624, a=a, sc=s)
        a, s = pop(t, t0 + 0.7); T(c, "+ *share*", 76, 540, 775, a=a, sc=s)
        icon(c, 540, 880 + 12 * math.sin(t * 7), 0.5, hand_down, a=ramp(t, t0 + 0.8, t0 + 1.0))
        a, s = pop(t, t0 + 0.8); T(c, "כתבו שבת ושתפו", 60, 540, 990, a=a, sc=s, col=B2)
        a, s = pop(t, t0 + 1.0); chip(c, "Sign up: noamroz.com/shabbat", 50, 540, 1090, NAVY, fg=W2, a=a, sc=s, w=800)
        a, s = pop(t, t0 + 1.1); T(c, "להרשמה: noamroz.com/shabbat", 52, 540, 1180, a=a, sc=s, col=N2)
        a, s = pop(t, t0 + 1.25); chip(c, "Part 3: how we'll build it. On my profile", 38, 540, 1280, GOLD, fg=W2, a=a, sc=s, w=800)
        a, s = pop(t, t0 + 1.35); T(c, "חלק 3: איך נבנה את זה, בפרופיל", 48, 540, 1360, a=a, sc=s, col=GD2)
        a = ramp(t, t0 + 1.5, t0 + 1.8); T(c, "April 2027, Tel Aviv beach. Sources in the caption.", 36, 540, 1430, a=a, col=GY2, w=700, src=True)
    add("cta", cta)
    return S

def draw_frame(c, t, S):
    CUR["t"] = t
    # warmth follows the active scene (smooth)
    warm = 0.0
    for i, sc in enumerate(S):
        a0 = sc["t0"]; a1 = S[i + 1]["t0"] if i + 1 < len(S) else 1e9
        w = sc.get("warm", 0.0)
        if a0 - 0.3 <= t < a1 + 0.3: warm = max(warm, w * min(ramp(t, a0 - 0.3, a0 + 0.3) if i else 1, 1 - ramp(t, a1 - 0.1, a1 + 0.3)))
    background(c, t, warm)
    for i, sc in enumerate(S):
        a0 = sc["t0"]; a1 = S[i + 1]["t0"] if i + 1 < len(S) else 1e9
        if t < a0 - 0.01 or t > a1 + 0.25: continue
        al = (1.0 if i == 0 else ramp(t, a0, a0 + 0.2)) * (1 - ramp(t, a1, a1 + 0.22))
        if al <= 0.01: continue
        CUR["scene"] = i; St.a = al; sc["fn"](c, t, sc); St.a = 1.0
    CUR["scene"] = None

def qa_issues(S):
    iss = []
    for sc_, s, sz, x0, y0, x1, y1, src in QA["text"]:
        if x0 < 0 or y0 < 0: continue
        if sz < 36: iss.append(("small", s, sz))
        if x0 < 70 - 1 or x1 > 1010 + 1: iss.append(("x safe", s, round(x0), round(x1)))
        if y0 < 230 or y1 > 1540: iss.append(("y safe", s, round(y0), round(y1)))
        if any(d in s for d in DASHES): iss.append(("dash", s))
    for i, sc in enumerate(S):
        a1 = S[i + 1]["t0"] if i + 1 < len(S) else TL["end"]
        if a1 - sc["t0"] < 3.0: iss.append(("card<3s", sc["key"], round(a1 - sc["t0"], 2)))
    return sorted(set(map(tuple, iss)))

def sfx_events(S):
    import shabbat_audio as A
    ding, thunk, cheer, whoosh, match = A.trophy_ding(), A.stamp_thunk(), A.crowd_cheer(), A.candle_whoosh(), A.match_strike()
    B = {sc["key"]: sc for sc in S}; ev = [(0.05, ding, -6)]
    for tl in B["shabbat"]["light"]: ev += [(tl - 0.12, match, -3), (tl, whoosh, -8)]
    ev.append((B["quote"]["t0"] + 0.15, ding, -8))
    for tc in B["tables"]["cards"]: ev.append((tc, ding, -4))
    r = B["race"]
    for tr in r["rows"]: ev.append((tr, ding, -5))
    ev += [(r["lost"] - 0.02, thunk, -1), (r["tease"], ding, -4)]
    p = B["plan"]; ev += [(p["lit"] - 0.1, whoosh, -5), (p["c3000"] + 1.15, cheer, -1)]
    ev.append((B["cta"]["t0"] + 0.5, ding, -5))
    return ev

def keytimes(S):
    B = {sc["key"]: sc for sc in S}
    ks = [0.0, 2.5, 4.0, 7.6, 12.0, B["tables"]["cards"][1] + 1.4, 22.8, B["race"]["lost"] + 0.5, 33.0,
          B["plan"]["lit"] + 1.2, B["plan"]["c3000"] + 1.5, 41.8, 44.4, 47.5]
    return sorted(set(round(x, 2) for x in ks))

def main():
    S = build(); os.makedirs(SCR, exist_ok=True)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    if "--preview" in sys.argv:
        k = sys.argv.index("--preview"); ts = [float(x) for x in sys.argv[k + 1].split(",")] if len(sys.argv) > k + 1 else keytimes(S)
        th = []
        for t in ts: draw_frame(c, t, S); th.append((t, surf2pil(surf)))
        sheet_of(th, f"{SCR}/prev.png"); print(qa_issues(S)); return
    import shabbat_audio as A
    os.nice(5); kit.wait_disk(150)
    B = {sc["key"]: sc for sc in S}; T_END = TL["end"]
    wav = f"{SCR}/mix.wav"; mrep = A.mix(T_END, sfx_events(S), wav, swell=(B["plan"]["t0"], B["cta"]["t0"]))
    out = f"{D}/shabbat_record.mp4"; N = int(math.ceil(T_END * FPS))
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "pipe:0", "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-maxrate", "2.4M", "-bufsize", "4M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); kt = keytimes(S); tset = {int(round(x * FPS)): x for x in kt}; th = []
    for fi in range(N):
        t = fi / FPS; draw_frame(c, t, S); surf.flush(); p.stdin.write(surf.get_data())
        if fi in tset: th.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 300 == 0: print("frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0; os.remove(wav)
    sheet_of(th, f"{D}/qa_sheet.png")
    kit.run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", out, "-c:v", "libx264", "-preset", "medium", "-crf", "25", "-maxrate", "0.9M",
             "-bufsize", "1.8M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "48000", "-movflags", "+faststart", f"{D}/shabbat_record_web.mp4"])
    timing = {"file": "shabbat_record.mp4", "fps": FPS, "size": [W, H], "duration_s": T_END, "beats": TL,
              "events": {"candles_shabbat": B["shabbat"]["light"], "cards": B["tables"]["cards"], "race_rows": B["race"]["rows"],
                         "lost_it": B["race"]["lost"], "tease_3000": B["race"]["tease"], "beach_candles": B["plan"]["lit"],
                         "counter_3000": B["plan"]["c3000"], "music_swell": [B["plan"]["t0"], B["cta"]["t0"]]},
              "mix": dict(mrep, target="-14 LUFS integrated, -1.5 dBTP, 48 kHz"), "qa_issues": qa_issues(S)}
    json.dump(timing, open(f"{D}/timing.json", "w"), indent=1, ensure_ascii=False); print("issues", timing["qa_issues"])

if __name__ == "__main__":
    main()
