"""Narration timing, burned-in subtitles and the voice + music + SFX mix for the Shabbat record reels (Part 2 and 3).
VO(asr_json, tts_txt, vo_wav, gaps, disp): chunks/segs from asr_segs.py on the processed voice; gaps = [(t, extra_s)]
inserts silence into the voice at time t (in a pause) and shifts every later chunk. at(line, phrase) gives the time a
phrase starts in a line (piecewise char-fraction map across that line's ASR chunks)."""
import json, re, subprocess, numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont
import cairo
SR = 48000
DASHES = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))

class VO:
    def __init__(s, asr_json, tts, vo_wav, gaps=(), disp=(), protect=()):
        J = json.load(open(asr_json)); s.CH = [list(c) for c in J["chunks"]]; s.SEG = [list(x) for x in J["segs"]]
        s.lines = [l.strip() for l in open(tts).read().split("\n") if l.strip()]; assert len(s.lines) == len(s.SEG)
        x, sr = sf.read(vo_wav); assert sr == SR; x = x.mean(1) if x.ndim > 1 else x
        for tg, ex in sorted(gaps, reverse=True):
            i = int(tg * SR); x = np.concatenate([x[:i], np.zeros(int(ex * SR)), x[i:]])
            for c in s.CH:
                if c[0] >= tg: c[0] += ex; c[1] += ex
            for g in s.SEG:
                if g[0] >= tg: g[0] += ex; g[1] += ex
        s.vo = x; s.dur = len(x) / SR; s.disp = list(disp); s.protect = list(protect)
        s.lmap = []
        for i, (la, lb) in enumerate(s.SEG):
            ks = [k for k, c in enumerate(s.CH) if c[0] >= la - 0.02 and c[1] <= lb + 0.02]; assert ks, i
            L = [max(1, len(s.CH[k][2])) for k in ks]; tot = sum(L); pts = []; acc = 0
            for k, l in zip(ks, L):
                pts.append((acc / tot, s.CH[k][0])); acc += l; pts.append((acc / tot, s.CH[k][1]))
            s.lmap.append(pts)
    def start(s, i): return s.SEG[i][0]
    def end(s, i): return s.SEG[i][1]
    def ft(s, i, fr):
        P = s.lmap[i]
        for (f0, t0), (f1, t1) in zip(P, P[1:]):
            if fr <= f1 + 1e-9: return t0 if f1 - f0 < 1e-9 else t0 + (t1 - t0) * (fr - f0) / (f1 - f0)
        return P[-1][1]
    def at(s, i, phrase, end=False, k=0):
        L = s.lines[i].lower(); p = phrase.lower(); pos = -1
        for _ in range(k + 1):
            pos = L.find(p, pos + 1); assert pos >= 0, (i, phrase)
        return s.ft(i, (pos + (len(p) if end else 0)) / len(L))
    # -------------------------------------------------------------- subtitles
    def pieces(s, maxw=6):
        """split each line at sentence/clause punctuation, then into chunks of at most maxw words"""
        items = []
        for i, l in enumerate(s.lines):
            l2 = l
            for p in s.protect:   # keep number phrases / the link in one piece (same length, so positions match l)
                l2 = re.sub(re.escape(p), lambda m: m.group(0).replace(" ", "_").replace(",", "~"), l2, flags=re.I)
            for m in re.finditer(r"[^.?!:,]+[.?!:,]?", l2):
                seg = m.group(0); ws = [(w.start() + m.start(), w.end() + m.start()) for w in re.finditer(r"\S+", seg)]
                if not ws: continue
                k = max(1, -(-len(ws) // maxw)); size = -(-len(ws) // k)
                for j in range(0, len(ws), size):
                    a, b = ws[j][0], ws[min(len(ws), j + size) - 1][1]; items.append([i, a, b, l[a:b]])
        # merge one-word fragments into the previous piece of the same line when short
        out = []
        for it in items:
            if out and out[-1][0] == it[0] and len(it[3].split()) == 1 and len(out[-1][3].split()) <= 4 and not re.search(r"[.?!]$", out[-1][3]):
                out[-1][2] = it[2]; out[-1][3] = s.lines[it[0]][out[-1][1]:it[2]]
            else: out.append(it)
        return out
    def subs(s, font_path, y_center, sz=50, maxw=900, fill=(22, 50, 96, 225), outline=(184, 146, 63, 255)):
        res = []
        for i, a, b, txt in s.pieces():
            L = len(s.lines[i]); t0, t1 = s.ft(i, a / L), s.ft(i, b / L)
            d = txt.strip(" ,:.")
            for x, y in s.disp: d = re.sub(re.escape(x), y, d, flags=re.I)
            assert not any(ch in d for ch in DASHES), d
            res.append([t0, t1, d])
        for p, q in zip(res, res[1:]):
            if q[0] - p[1] < 0.5: p[1] = q[0]
            else: p[1] += 0.25
        res[-1][1] += 0.6
        F = ImageFont.truetype(font_path, sz); out = []
        for t0, t1, d in res:
            words = d.split(); lines = []; cur = ""
            for w in words:
                tr = (cur + " " + w).strip()
                if F.getlength(tr) <= maxw - 60: cur = tr
                else: lines.append(cur); cur = w
            lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 26
            im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
            dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=24, fill=fill, outline=outline, width=3)
            for k, x in enumerate(lines): dr.text((Wd / 2, 13 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
            out.append((t0, t1, pil2cairo(im), (1080 - Wd) // 2, int(y_center - Hd / 2), d, Hd))
        s.sub_items = out; return out

def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float64) / 255; al = a[:, :, 3:4]
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, :3] = (a[:, :, 2::-1] * al * 255).astype(np.uint8); bgra[:, :, 3] = (a[:, :, 3] * 255).astype(np.uint8)
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)

def draw_subs(c, t, items, alpha=1.0):
    for t0, t1, surf, x, y, _, _ in items:
        if t0 <= t < t1:
            a = min(1.0, (t - t0) / 0.08, (t1 - t) / 0.08) * alpha
            c.set_source_surface(surf, x, y); c.paint_with_alpha(max(0, min(1, a)))

# -------------------------------------------------------------- mix
def act_rms(x):
    n = int(0.05 * SR); e = np.array([np.sqrt((x[i:i + n] ** 2).mean()) for i in range(0, len(x) - n, n)]); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
def speech_env(v):
    """0..1 speech presence: 10 ms RMS over a -40 dB gate, held 250 ms, 60 ms attack / 350 ms release"""
    hop = int(0.01 * SR); n = len(v) // hop; L = 20 * np.log10(np.sqrt((v[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9)
    on = (L > L.max() - 40).astype(float); on = np.convolve(on, np.ones(25), "same") > 0
    e = np.zeros(n); acc = 0.0
    for i in range(n):
        tgt = 1.0 if on[i] else 0.0; k = 0.01 / (0.06 if tgt > acc else 0.35); acc += (tgt - acc) * min(1, k * 3); e[i] = acc
    return np.interp(np.arange(len(v)), np.arange(n) * hop + hop / 2, e)
def mix(vo, dur, music, events, out_wav, music_db=-11.0, duck_db=-8.0, sfx_db=-6.0, swell=None, swell_db=3.0, tp=-2.0):
    """voice at 0 dB reference; music bed music_db under the voice's active RMS, ducked another duck_db under speech;
    SFX relative to the voice RMS (sfx_db + per-event xdb), dipped 4 dB under speech; two-pass loudnorm to -14 LUFS."""
    n = int(dur * SR); v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]; vr = act_rms(v); sp = speech_env(v)
    m = music[:, :n]; m = np.pad(m, ((0, 0), (0, n - m.shape[1]))); mr = act_rms(m.mean(0))
    tq = np.arange(n) / SR; g = np.ones(n)
    if swell: g = 10 ** (swell_db * np.clip((tq - (swell[0] - 1.0)) / 1.2, 0, 1) * (1 - 0.6 * np.clip((tq - swell[1]) / 1.0, 0, 1)) / 20)
    m = m * (vr * 10 ** (music_db / 20) / mr) * g * 10 ** (duck_db * sp / 20)
    S = np.zeros((2, n)); rep = []
    for t0, x, xdb in events:
        x = np.atleast_2d(x); x = np.vstack([x, x]) if x.shape[0] == 1 else x
        gg = vr * 10 ** ((sfx_db + xdb) / 20) / (act_rms(x.mean(0)) + 1e-12); i = int(t0 * SR); j = min(n, i + x.shape[1])
        if j > i and i >= 0: S[:, i:j] += x[:, :j - i] * gg; rep.append(round(t0, 2))
    S *= 10 ** (-4 * sp / 20)
    y = m + S + np.vstack([v, v])
    raw = y.T.astype(np.float32).tobytes()
    meas = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af",
                           f"loudnorm=I=-14:TP={tp}:LRA=11:print_format=json", "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
    J = json.loads(meas[meas.rfind("{"):meas.rfind("}") + 1])
    af = (f"loudnorm=I=-14:TP={tp}:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
          f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af, "-ar", "48000", "-c:a", "pcm_s16le", out_wav], input=raw, capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-400:]
    return {"input_I": J["input_i"], "input_TP": J["input_tp"], "sfx_at": rep}
