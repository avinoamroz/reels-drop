# Let's break a Guinness World Record. Together.

Account: @noamroz__. Length: about 47 s, 1080x1920, 30 fps. No voice-over: music-driven, burned-in bilingual text (EN + HE), SFX.
Every fact is in research.md with its URL; a source line sits on every fact beat.

| # | Time (s) | Visual | On screen EN | On screen HE | SFX / music |
|---|---|---|---|---|---|
| 1 Hook | 0.0 to 3.6 | Long candle-lit table at dusk, fully lit at frame 0, warm glow, flames flicker | Let's break a *Guinness World Record.* / *Together.* | בואו נשבור שיא גינס. ביחד. | Music in from frame 0 (warm groove), soft ding |
| 2 Shabbat | 3.6 to 8.4 | Two Shabbat candles light (match flare), challah, wine cup on a white cloth | Every Friday night. / Candles. Challah. One table. / For thousands of years. | כל שישי בערב. נרות, חלה, שולחן אחד. כבר אלפי שנים. | Match strike + whoosh on each candle |
| 3 Quote | 8.4 to 13.0 | Quote card, gold quote marks | "More than the Jews have kept Shabbat, / Shabbat has kept the Jews." / Ahad Ha'am, 1898 | "יותר משישראל שמרו את השבת, שמרה השבת אותם" / אחד העם, 1898 | Soft ding |
| 4 Tables | 13.0 to 23.6 | 2x2 WORLD RECORD cards with flags, each counts up | The world's biggest tables / Longest table 3,255.8 m (Lebanon, 2026) / Longest table setting 5,050 m, 15,000 places (Portugal, 1998) / Longest line of tables 6,000 m (Philippines, 2017) / Largest picnic 22,232 people (Portugal, 2009) | השולחנות הגדולים בעולם / השולחן הארוך / השולחן הערוך הארוך / שורת השולחנות הארוכה / הפיקניק הגדול | Ding on each card |
| 5 Race | 23.6 to 33.8 | Racing bars with flags. Tel Aviv 2,226 grows; Berlin 2,322 passes it: LOST IT stamp; New York 2,761 takes the crown; a gold dashed bar "Tel Aviv 2027: 3,000?" slides in | The largest Shabbat dinner / Tel Aviv 2014: 2,226 / Berlin 2015: 2,322 / New York 2025: 2,761 (current record) / Tel Aviv 2027: 3,000? | ארוחת השבת הגדולה בעולם / איבדנו את השיא | Ding per bar, stamp thunk on LOST IT |
| 6 Announcement | 33.8 to 42.4 | Beach at sunset, Tel Aviv skyline, a long table; candles light one by one along it; big gold 3,000 counter | April 2027. / Tel Aviv beach. / 3,000 people. / One Shabbat dinner. | אפריל 2027. חוף תל אביב. 3,000 איש. ארוחת שבת אחת. | Music swells; candle whoosh; crowd cheer as 3,000 lands |
| 7 CTA | 42.4 to 47.4 | Gold SHABBAT pill, hand pointing, link | Want a seat at the table? / Comment *SHABBAT* + share / Sign up: noamroz.com/shabbat | רוצים מקום ליד השולחן? כתבו שבת ושתפו / להרשמה: noamroz.com/shabbat | Ding on the pill; fully on screen for 3 s+ before the end |

## Source lines on screen
- Shabbat: "Exodus 20:8: Remember the Sabbath day"
- Quote: "Ahad Ha'am (Asher Ginsberg), Hashiloah, 1898"
- Tables: "Source: guinnessworldrecords.com"
- Race: "Sources: israel21c (2014), GWR (2015, 2025)"
- Announcement: "Our attempt. Not a record yet."

## Notes
- "3,000 years" is NOT used: "for thousands of years" instead (cannot be dated precisely).
- Largest iftar, largest dinner party and a Passover Seder record were checked and left out (no GWR page could be confirmed; see research.md).
- Generic certificate look, no Guinness logo or artwork. The word "Guinness" appears only as plain text.
