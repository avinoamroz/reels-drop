# v3: v2 with the 7-minute card removed (Noam, 19 Oct) and narration in Noam's Shadow voice.
# v2 of cfg_jews_safety_map.py: same story, rebuilt for phone legibility (Noam: "the text needs to be larger").
# Bigger bold outlined map labels shown only while each country is in focus, a closer camera per region,
# big legend/counter chips, short captions split over more beats, bigger end cards.
# Render: nice -n 15 python3 engine_safety_v2.py cfg_jews_safety_map_v2.py            (music version)
#         nice -n 15 python3 engine_safety_v2.py cfg_jews_safety_map_v2.py --vo vo/noam_safety.mp3   (narrated version)
# Sources: final/jews_safety_map_sources.txt
TAG = "jews_safety_map_v3"; STYLE = "dawn"
OUT = "/home/claude/vid/safety3_silent.mp4"
FINAL = "/home/claude/vid/final/jews_safety_map_v3_music.mp4"; FINAL_VO = "/home/claude/vid/final/jews_safety_map_v3.mp4"
NARR = "/home/claude/vid/final/jews_safety_map_v3_narration.txt"; SNAPDIR = "/home/claude/vid/final/qa_jews_safety_map_v3"
RED, AMB, GRN, GOLDC, CITY = "#F0525A", "#F5A524", "#34C97F", "#F2D58A", "#64D2FF"

# layout (1080x1920). Safe zone: y 250..1536, x < 930 for anything that must be read.
TITLES = [(0, "Can Israelis even get in?", "האם ישראלים בכלל יכולים להיכנס?"),
          (12, "Arabs in the Jewish state", "ערבים במדינה היהודית")]
TY = 256; T_FS = 50; T_HFS = 42; T_GAP = 58
CHIP_Y = 372; CHIP_H = 140; CHIP_X = [40, 335, 630]; CHIP_W = 280; CHIP_NFS = 76
PANEL = (0, 524, 1080, 744)
EV_Y = 1282; EV_FS = 52; EV_HFS = 42; EV_W = 860; EV_X = 480
DISC_Y = 1474; DISC_FS = 17; DISC_LH = 20
LAB_EN, LAB_HE, LAB_L2 = 38, 34, 30

# beats -> seconds (music version). VO version re-times these from the narration (VO_MAP).
TL = [(0, 0.0), (1, 3.0), (2, 6.2), (3, 9.6), (4, 12.6), (5, 15.2), (6, 18.4), (7, 21.6), (8, 25.0), (9, 28.6), (10, 31.4),
      (11, 34.6), (12, 37.8), (13, 41.2), (14, 44.0), (15, 46.6), (16, 50.0), (17, 52.4), (18, 55.4)]
T_CARDS = [("CARD1", 55.6), ("CTA", 61.0)]; T_END = 65.0
HIT_BEATS = [12]; TURN = 12

# cameras: (centre lon, centre lat, visible degrees of longitude)
WIDE = (25.0, 29.0, 74.0); LEV = (45.0, 32.6, 30.0); GULF = (50.0, 22.5, 32.0); ASIA = (90.0, 18.0, 80.0)
NAFR = (12.0, 30.5, 46.0); HOLY = (35.0, 32.0, 4.6); GREEN = (26.0, 28.5, 76.0); ISR = (35.1, 31.45, 5.6)
CAM = [(0, *WIDE), (0.55, *WIDE), (0.98, *LEV), (2.9, *LEV), (3.25, *GULF), (4.9, *GULF), (5.25, *ASIA), (5.9, *ASIA),
       (6.25, *NAFR), (7.9, *NAFR), (8.3, *HOLY), (9.9, *HOLY), (10.25, *GREEN), (11.9, *GREEN), (12.3, *ISR), (18, *ISR)]

# name in Natural Earth: he, category, reveal beat, label point (lon, lat), label direction, line 2,
# lab_to = beat the label fades (labels only live while their region is in focus), lab=None = no own label,
# jews = (1948, today, "today label", shrink start beat, circle fade beat)
C_ = {}
def c(name, he, cat, r, ll, lab, l2=None, jews=None, lab_to=None, en=None):
    C_[name] = dict(he=he, cat=cat, r=r, ll=ll, lab=lab, l2=l2, jews=jews, lab_to=lab_to if lab_to else int(r) + 1, en=en or name)
# RED: Israeli passport holders refused entry
c("Iran", "איראן", "red", 1.00, (52.0, 31.6), (0, -1), jews=(100000, 9000, "~9,000", 2.05, 2.9), lab_to=2.95)
c("Iraq", "עיראק", "red", 1.08, (43.8, 33.0), (-0.1, 1), jews=(135000, 4, "4", 2.05, 2.9), lab_to=2.95)
c("Syria", "סוריה", "red", 1.16, (38.6, 35.4), (0, -1), jews=(30000, 5, "~5", 2.05, 2.9), lab_to=2.95)
c("Lebanon", "לבנון", "red", 1.24, (35.85, 33.9), (-1, 0.35), lab_to=2.95)
c("Kuwait", "כווית", "red", 3.30, (47.6, 29.3), (-1, -0.2), lab_to=4.95)
c("Yemen", "תימן", "red", 3.38, (46.5, 15.8), (-1, 0.1), jews=(63000, 0, "0", 3.45, 4.9), lab_to=4.95)
c("Oman", "עומאן", "red", 3.46, (55.6, 20.2), (-0.2, 1), l2="transit only", lab_to=4.95)
c("Afghanistan", "אפגניסטן", "red", 5.30, (65.5, 34.0), (0, -1), lab_to=6.0)
c("Bangladesh", "בנגלדש", "red", 5.40, (90.3, 23.8), (0, -1), lab_to=6.0)
c("Maldives", "מלדיביים", "red", 5.50, (73.4, 3.5), (0, 1), lab_to=6.0)
c("Brunei", "ברוניי", "red", 5.60, (114.7, 4.7), (-0.5, -1), lab_to=6.0)
c("Libya", "לוב", "red", 6.30, (17.5, 27.5), (0, 1), jews=(38000, 0, "0", 6.4, 7.9), lab_to=7.95)
c("Algeria", "אלג'יריה", "red", 6.38, (2.6, 28.5), (0, 1), jews=(140000, 200, "<200", 6.4, 7.9), lab_to=7.95)
# AMBER: entry only with special permits / no relations
c("Saudi Arabia", "ערב הסעודית", "amb", 4.05, (44.5, 23.5), (0, 1), lab_to=4.95)
c("Pakistan", "פקיסטן", "amb", 5.45, (69.5, 29.0), (0.1, 1), lab_to=6.0)
c("Malaysia", "מלזיה", "amb", 5.55, (101.7, 3.8), (0, 1), lab_to=6.0)
c("Tunisia", "תוניסיה", "amb", 7.05, (9.4, 34.0), (0.1, -1), l2="no relations", lab_to=7.95)
# GREEN: open to Israelis (Bahrain + UAE share one group label)
c("Egypt", "מצרים", "grn", 10.30, (29.0, 26.5), (-0.6, 1), l2="peace 1979", lab_to=11.95)
c("Jordan", "ירדן", "grn", 10.42, (36.6, 30.8), (1, -0.8), l2="peace 1994", lab_to=11.95)
c("Morocco", "מרוקו", "grn", 11.05, (-6.3, 32.0), (1, -0.9), l2="~2,000 Jews", lab_to=11.95)
c("Bahrain", "בחריין", "grn", 11.15, (50.55, 26.05), None, lab_to=11.95)
c("United Arab Emirates", "איחוד האמירויות", "grn", 11.20, (54.3, 24.0), None, lab_to=11.95, en="UAE")
COUNTRIES_STATUS = C_
GROUPS = [dict(r=11.15, lab_to=11.95, ll=(51.5, 23.0), dr=(-0.7, 1), en="Bahrain + UAE", he="בחריין ואמירויות", l2="Abraham Accords", cat="grn")]
RK = 0.12            # Jewish-population circle: r = RK * sqrt(jews) px

# West Bank / Gaza (beats 8-9), from the "Palestine" polygon
WB = dict(r=8.3, to=10.0, he="יהודה ושומרון", en="West Bank", ll=(35.36, 32.08), lab=(1, -0.2), l2="Area A: no entry", lab_to=9.0)
AREA_A = [(35.30, 32.46), (35.03, 32.31), (34.97, 32.19), (35.26, 32.22), (35.20, 31.90), (35.45, 31.86), (35.20, 31.705), (35.10, 31.53)]
GAZA = dict(r=9.0, to=10.0, he="עזה", en="Gaza", ll=(34.40, 31.43), lab=(-1, 0.1), l2="251 hostages")
SIGN = dict(r=8.45, to=9.0, x=40, y=1040, w=880,
            head="The red sign at the entrance  |  השלט האדום בכניסה",
            lines=["This road leads to Area \"A\"", "under the Palestinian Authority.", "Entrance for Israeli citizens is forbidden,",
                   "dangerous to your lives and against Israeli law."])

# Israel (beats 12+): Arab and mixed cities (labels in pairs, then dots only), then pins
CITIES = [("Haifa", "חיפה", (34.99, 32.79), (-1, -0.1), 12.30, 12.62), ("Nazareth", "נצרת", (35.30, 32.70), (1, 0.1), 12.30, 12.62),
          ("Sakhnin", "סח'נין", (35.30, 32.865), (1, -0.2), 12.58, 12.86), ("Tayibe", "טייבה", (34.98, 32.27), (-1, 0), 12.58, 12.86),
          ("Umm al-Fahm", "אום אל-פחם", (35.15, 32.52), (1, 0.2), 12.82, 13.05), ("Rahat", "רהט", (34.75, 31.39), (-1, 0), 12.82, 13.05)]
CITY_LEGEND = ("Arab and mixed cities", "ערים ערביות ומעורבות")
PINS = [("Knesset", "הכנסת", (35.205, 31.777), (1, 0.3), "10 Arab seats", 13.0, 16.0),
        ("District Court", "בית המשפט המחוזי", (34.785, 32.075), (-1, 0.1), "Katsav convicted, 2010", 16.0, 99)]

# chips: phase A = legend + live counts, phase B = the Israel facts
COUNTERS_A = [("Refused", "אסורה", "red", RED), ("Permit only", "רק בהיתר", "amb", AMB), ("Open", "פתוחות", "grn", GRN)]
COUNTERS_B = [("Arabs in Israel", "ערבים בישראל", "21%", GOLDC, 12.1), ("Knesset seats", "מושבים בכנסת", "10/120", CITY, 13.1),
              ("Doctors", "רופאים", "25%", GRN, 15.1)]

EVENTS = [(0, "Where can a Jew walk safely?", "איפה יהודי יכול להסתובב בבטחה?"),
 (1, "Israeli passport? Entry refused.", "דרכון ישראלי? הכניסה אסורה."),
 (2, "Iraq had 135,000 Jews in 1948.\nToday: about 4.", "בעיראק חיו 135,000 יהודים ב-1948. היום: כ-4."),
 (3, "Kuwait, Yemen, Oman: refused too", "כווית, תימן, עומאן: גם שם אסור"),
 (4, "Saudi Arabia: special permit only", "ערב הסעודית: רק בהיתר מיוחד"),
 (5, "Further east: refused, or permit only", "מזרחה יותר: אסור, או רק בהיתר"),
 (6, "North Africa: whole Jewish\ncommunities, gone", "צפון אפריקה: קהילות יהודיות שלמות נעלמו"),
 (7, "Tunisia, 2023: a gunman\nkilled 2 Jewish pilgrims", "תוניסיה, 2023: מחבל רצח 2 עולי רגל יהודים"),
 (8, "West Bank, Area A:\nIsraeli law bars Israelis", "שטח A: החוק אוסר על ישראלים להיכנס"),
 (9, "Gaza, 7 Oct 2023:\n251 people taken hostage", "עזה, 7 באוקטובר 2023: 251 נחטפו"),
 (10, "To be fair: Egypt and Jordan\nmade peace with Israel", "ולמען ההגינות: שלום עם מצרים וירדן"),
 (11, "Jews live openly in Morocco,\nthe UAE and Bahrain", "יהודים חיים בגלוי במרוקו, באמירויות ובבחריין"),
 (12, "Now flip it:\n1 in 5 people in Israel is Arab", "ועכשיו הפוך: 1 מכל 5 תושבי ישראל ערבי"),
 (13, "Arab parties won 10 Knesset seats", "מפלגות ערביות זכו ב-10 מושבים בכנסת"),
 (14, "2021: Ra'am joined the government", "2021: רע\"מ הצטרפה לממשלה"),
 (15, "1 in 4 doctors is Arab.\nAbout half of pharmacists, too.", "1 מכל 4 רופאים וכמחצית מהרוקחים הם ערבים"),
 (16, "2010: Arab judge George Karra", "2010: השופט הערבי ג'ורג' קרא"),
 (17, "led the panel that convicted\nex-President Katsav", "ראש ההרכב שהרשיע את הנשיא לשעבר קצב")]
DISC = {0: ["Colours = entry rules for Israeli passport holders (Oct 2026), not a safety rating.",
            "Jews 1948 vs today: DellaPergola, AJYB 2023. Sources in the caption.",
            "הצבעים = כללי כניסה לבעלי דרכון ישראלי, לא דירוג בטיחות."],
        12: ["Israel CBS (Apr 2026). Rosen & Miaari, Isr. J. Health Policy Res. 2025 (CBS 2023 data).",
             "Knesset election 2022. Katsav verdict 30 Dec 2010. Sources in the caption.",
             "המקורות בכיתוב."]}

HOOK = {"dur": 1.0, "lines": [(745, "Where can a Jew", "#0E1E3A", 74), (835, "walk safely?", "#0E1E3A", 92),
                              (960, "איפה יהודי יכול", "#0E1E3A", 60), (1035, "להסתובב בבטחה?", "#0E1E3A", 60),
                              (1140, "A map  |  מפה", "#0E1E3A", 30)]}
CARDS = {
 "CARD1": dict(edge="#a9bbd8", ew=3, y=470, h=760, lines=[(550, "In many Arab countries,", "#FFFFFF", 56, 900), (616, "Jews can't live safely.", "#FFFFFF", 56, 900),
     (700, "In the Jewish state, Arab citizens", "#D2AA53", 44, 800), (754, "are in the market, the Knesset,", "#D2AA53", 44, 800), (808, "and the courts.", "#D2AA53", 44, 800),
     (896, "בהרבה מדינות ערב,", "#FFFFFF", 42, 800), (948, "יהודים לא יכולים לחיות בבטחה.", "#FFFFFF", 42, 800),
     (1028, "במדינה היהודית, אזרחים ערבים נמצאים", "#D2AA53", 42, 800), (1080, "בשוק, בכנסת ובבתי המשפט.", "#D2AA53", 42, 800)]),
 "STAND": dict(edge="#59A5DF", ew=3, y=470, h=760, lines=[(550, "The best way to improve?", "#FFFFFF", 56, 900),
     (632, "Open your WhatsApp, take 7 minutes,", "#FFFFFF", 42, 800), (684, "and record yourself explaining", "#FFFFFF", 42, 800),
     (736, "this topic out loud.", "#FFFFFF", 42, 800), (794, "No one interrupting you.", "#D2AA53", 42, 800),
     (884, "הדרך הכי טובה להשתפר?", "#FFFFFF", 44, 800), (940, "פתחו וואטסאפ, קחו 7 דקות", "#FFFFFF", 40, 800),
     (990, "והקליטו את עצמכם מסבירים את זה בקול.", "#FFFFFF", 40, 800), (1048, "בלי שאף אחד יפריע לכם.", "#D2AA53", 40, 800)]),
 "CTA": dict(edge="#D2AA53", ew=4, y=560, h=580, lines=[(650, "Did any of this surprise you?", "#FFFFFF", 54, 900), (752, "Comment SAFE", "#D2AA53", 80, 900),
     (828, "for the sources", "#FFFFFF", 42, 700), (930, "משהו פה הפתיע אתכם?", "#FFFFFF", 50, 800), (1014, "כתבו SAFE בתגובות למקורות", "#D2AA53", 46, 800)]),
}
# narration line -> beat it lands on; card keys start that card with the line
VO_MAP = [0, 1, 5, 8, 10, 12, 15, "CARD1", "CTA"]
