"""safety_v5 build: mix (audio_v4 music + sfx, cues from cfg_v5) -> verified loudness (rk.finish_audio: -14 LUFS, <= -1.5 dBTP,
48 kHz AAC) -> silent video (engine_v4.py cfg_v5.py) -> mux -> safety_v5.mp4.  usage: nice -n 15 python3 build_v5.py [--snaps 0.5,12]"""
import sys, os, runpy, subprocess, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
D = "/home/claude/safety_v4"; CFG = f"{D}/cfg_v5.py"
if len(sys.argv) > 2 and sys.argv[1] == "--snaps":
    subprocess.run(["nice", "-n", "15", "python3", f"{D}/engine_v4.py", CFG, "--snaps", sys.argv[2]], check=True); sys.exit()
import audio_v4 as AU, rk
C = runpy.run_path(CFG); dur = C["T_END"]
vo, sr = sf.read(C["VO"]); assert sr == AU.SR
bed = AU.doc_music(dur, flip_at=C["TURN"] - 0.3)
ev = [(t0 - 0.02, AU.stamp(i) * (0.9 + 0.2 * AU.rng.random()), -2.0) for i, t0 in enumerate(C["STAMPS"])]
ev.append((C["WHOOSH"] - 0.2, AU.jet_whoosh(1.4), -1.0))
for h in C["HITS"]: ev.append((h, AU.soft_hit(), -4.0))
mix_wav = f"{D}/work5/mix.wav"; rep = AU.mix(vo, dur, ev, mix_wav, music_db=-19.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mix_wav); m4a = f"{D}/work5/mix.m4a"; J = rk.finish_audio(x.T.astype(np.float64), m4a); os.remove(mix_wav)
print("audio", J["final_I"], J["final_TP"], J["steps"], flush=True)
subprocess.run(["nice", "-n", "15", "python3", f"{D}/engine_v4.py", CFG, "--silent"], check=True)
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", C["OUT"], "-i", m4a, "-map", "0:v", "-map", "1:a", "-c", "copy",
                "-t", f"{dur:.2f}", "-movflags", "+faststart", C["FINAL"]], check=True)
os.remove(C["OUT"]); os.remove(m4a)
json.dump(dict(T_END=dur, loudnorm=J, subs=C["SUBS"], span=C["SPAN"]), open(f"{D}/work5/build_v5.json", "w"), indent=1, ensure_ascii=False)
print("final", C["FINAL"])
