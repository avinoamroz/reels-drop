"""Restore word endings that clean_vo ducked: inside each speech chunk (from ASR on the dry chain), wherever the cleaned
signal sits 4 dB or more under the dry signal while the dry signal is real speech (within 40 dB of the speech level),
crossfade back to the dry signal (high-passed at 90 Hz like clean_vo, zero phase, so it is sample aligned).
Writes work/vo_fixed.wav and prints every restored span."""
import json, numpy as np, soundfile as sf
from scipy.signal import butter, sosfiltfilt
D = "/home/claude/safety_v4/work"
c, sr = sf.read(f"{D}/pre_clean.wav"); d, _ = sf.read(f"{D}/pre_dry.wav")   # pre-tempo, same length
TEMPO, LEAD = 1.1, 0.3; pre = lambda t: max(0.0, (t - LEAD) * TEMPO)
d = sosfiltfilt(butter(4, 90, "hp", fs=sr, output="sos"), d)
CH = json.load(open(f"{D}/asr_dry.json"))["chunks"]
hop = int(0.01 * sr); n = len(c) // hop
def lev(x):
    f = x[:n * hop].reshape(n, hop); return 10 * np.log10((f ** 2).mean(1) + 1e-12)
Lc, Ld = lev(c), lev(d); ref = np.percentile(Ld, 95)
inch = np.zeros(n, bool)
for a, b, _ in CH: a, b = pre(a), pre(b); inch[max(0, int((a - 0.05) * 100)):min(n, int((b + 0.06) * 100))] = True
m = inch & (Ld - Lc > 4) & (Ld > ref - 40)
# dilate by 2 frames, then build a sample mask with 15 ms ramps
m = np.convolve(m.astype(float), np.ones(5), "same") > 0
spans = []; i = 0
while i < n:
    if m[i]:
        j = i
        while j < n and m[j]: j += 1
        spans.append((i / 100, j / 100)); i = j
    else: i += 1
w = np.zeros(len(c)); r = int(0.015 * sr)
for a, b in spans:
    ia, ib = int(a * sr), int(b * sr); w[ia:ib] = 1
    w[max(0, ia - r):ia] = np.maximum(w[max(0, ia - r):ia], np.linspace(0, 1, ia - max(0, ia - r)))
    w[ib:ib + r] = np.maximum(w[ib:ib + r], np.linspace(1, 0, len(w[ib:ib + r])))
# forced windows (reel time): word endings ASR still missed after the automatic pass ("the map" x2), restored from the
# unfiltered dry chain so the plosive release is back in full
d_raw, _ = sf.read(f"{D}/pre_dry.wav"); FORCE = [(2.62, 3.00), (34.40, 34.75)]
wf = np.zeros(len(c))
for a, b in FORCE:
    ia, ib = int(pre(a) * sr), int(pre(b) * sr); wf[ia:ib] = 1; wf[ia - r:ia] = np.linspace(0, 1, r); wf[ib:ib + r] = np.linspace(1, 0, r)
y = c * (1 - w) + d * w
y = y * (1 - wf) + d_raw * wf
sf.write(f"{D}/pre_fixed.wav", y.astype(np.float32), sr, subtype="FLOAT")
tot = sum(b - a for a, b in spans)
print(f"restored {len(spans)} spans, {tot:.2f} s total, plus forced windows {FORCE}")
for a, b in spans:
    po = lambda t: t / TEMPO + LEAD; k = [t for (x0, x1, t) in CH if x0 - 0.06 <= po(a) <= x1 + 0.07]; a, b = po(a), po(b)
    print(f"  {a:6.2f} to {b:6.2f}  ({(b - a) * 1000:.0f} ms reel time)  in: {k[0] if k else '?'}")
