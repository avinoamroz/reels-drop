"""v4 engine (copied from /home/claude/vid/engine_safety_v2.py, which is unchanged). v4 changes: the clock is seconds (cfg
times come from the narration ASR), whole land of Israel in gold with the Green Line, Area A / Gaza red highlights inside it,
Hebrew via python-bidi get_display + PIL BASIC layout, burned-in subtitles, chip count pop, map legend, audio from mix_v4.py.
usage: nice -n 15 python3 engine_v4.py cfg_v4.py [--snaps 0.5,12,30]
---- original notes:
Status map v2 (phone-legible): same pipeline as engine_safety.py (PIL at 2x then downsampled, Natural Earth map, beats,
camera keyframes, hook, end cards, music/VO mux) but with big bold outlined labels that live only while their region is in
focus, per-country Jewish-population shrink timing, big legend/counter chips, wrapped captions, and a wider quoted sign.
usage: nice -n 15 python3 engine_safety_v2.py CFG.py [--vo vo/noam.mp3] [--snaps 0.5,12,30] [--silent]
  no --vo : music-only version -> FINAL (cfg), tune made by music/apple2.py (STYLE) to the video length
  --vo    : narrated version -> FINAL_VO (cfg), beats re-timed to the narration (VO_MAP) via vo/align.py, music 18 dB under.
  --snaps : QA stills (PNG) at those seconds into SNAPDIR (cfg) instead of a video.
Geography: Natural Earth 1:10m countries (world-atlas 2.0.2, public domain) from /home/claude/goals_scorecard/geodata."""
import sys, os, json, math, runpy, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon, MultiPolygon, box
from shapely.ops import unary_union

from bidi.algorithm import get_display
from shapely.geometry import LineString, MultiLineString
ap = argparse.ArgumentParser(); ap.add_argument("cfg"); ap.add_argument("--snaps"); ap.add_argument("--silent", action="store_true"); ap.add_argument("--audio")
A = ap.parse_args(); C = runpy.run_path(A.cfg)
HERE = "/home/claude/vid"; S = 2; W, H, FPS = 1080, 1920, 30
def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
BG_T, BG_B = hx("#0E1E3A"), hx("#163260")
GOLD = hx("#D2AA53"); SUBC = hx("#a9bbd8"); DISCC = hx("#8ea3c6"); WHITE = hx("#FFFFFF")
SEA = hx("#0B1830"); LAND = hx("#1d3a6b"); BORDER = (120, 160, 220, 110); ISRF = hx(C["ISR_GOLD"], 245); GLC = hx(C["GREEN_LINE"])
CATC = {"red": C["RED"], "amb": C["AMB"], "grn": C["GRN"]}
FONT = {w: f"{HERE}/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(sz * S), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONT[w], k[0], layout_engine=ImageFont.Layout.BASIC)
    return _fc[k]

# ---------------------------------------------------------------- geometry
def topo(path):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
RAW = topo("/home/claude/goals_scorecard/geodata/countries-10m.json")
# whole land between the river and the sea: Israel (incl. Golan in this dataset) + Judea and Samaria + Gaza, one gold shape
LANDI = unary_union([RAW["Israel"], RAW["Palestine"]]).buffer(0.0005).buffer(-0.0005)
# Green Line = the parts of the Judea and Samaria / Gaza outlines shared with Israel (not the Jordan, the Egypt border or the sea)
GL_RAW = RAW["Palestine"].boundary.intersection(RAW["Israel"].buffer(0.004))
VIEWBOX = box(-30, -16, 135, 64); NEAR = box(24, 24, 46, 38)
COARSE = {k: v.intersection(VIEWBOX).simplify(0.03) for k, v in RAW.items() if v.intersects(VIEWBOX)}
FINE = {k: v.intersection(NEAR).simplify(0.002) for k, v in RAW.items() if v.intersects(NEAR)}
for G_, tol in ((COARSE, 0.03), (FINE, 0.002)): G_["_LAND"] = LANDI.simplify(tol)
GL_C, GL_F = GL_RAW.simplify(0.01), GL_RAW.simplify(0.0015)
def lines_of(g):
    if g.is_empty: return []
    if isinstance(g, LineString): return [list(g.coords)]
    return [list(x.coords) for x in getattr(g, "geoms", []) if isinstance(x, LineString)]
def split_pal(G):
    ps = list(G.geoms) if isinstance(G, MultiPolygon) else [G]
    gz = unary_union([p for p in ps if p.centroid.x < 34.6]); wb = unary_union([p for p in ps if p.centroid.x >= 34.6]); return gz, wb
GZ_C, WB_C = split_pal(COARSE["Palestine"]); GZ_F, WB_F = split_pal(FINE["Palestine"])
def rings(g):
    if g.is_empty: return []
    if isinstance(g, Polygon): return [list(g.exterior.coords)]
    return [list(p.exterior.coords) for p in getattr(g, "geoms", []) if isinstance(p, Polygon)]

PX, PY, PW, PH = C["PANEL"]; COSF = math.cos(math.radians(32))
def smooth(u): return u * u * (3 - 2 * u)
def cam_at(b):
    K = C["CAM"]
    if b <= K[0][0]: return K[0][1:]
    for (t0, *a), (t1, *c_) in zip(K[:-1], K[1:]):
        if t0 <= b <= t1:
            u = smooth((b - t0) / (t1 - t0) if t1 > t0 else 1)
            return (a[0] + (c_[0] - a[0]) * u, a[1] + (c_[1] - a[1]) * u, math.exp(math.log(a[2]) + (math.log(c_[2]) - math.log(a[2])) * u))
    return K[-1][1:]
def proj(cam, lon, lat):
    cx, cy, span = cam; s = PW / (span * COSF)
    return (PX + PW / 2 + (lon - cx) * COSF * s, PY + PH / 2 - (lat - cy) * s)
def geo(cam):   # fine outlines only when the whole view sits inside the NEAR box (else land would go missing)
    cx, cy, span = cam; hl = span / 2; hv = span * COSF * PH / PW / 2
    inside = cx - hl > 24 and cx + hl < 46 and cy - hv > 24 and cy + hv < 38
    return (FINE, GZ_F, WB_F) if inside else (COARSE, GZ_C, WB_C)
def gline(cam): return GL_F if geo(cam)[0] is FINE else GL_C
def pxl(cam, r): return [((proj(cam, x, y)[0] - PX) * S, (proj(cam, x, y)[1] - PY) * S) for x, y in r]
_base = {}
FADE = None
def fade(im):
    global FADE
    if FADE is None:
        a = np.ones((PH * S, 1)); fd = int(40 * S); a[:fd, 0] = np.linspace(0, 1, fd) ** 1.5; a[-fd:, 0] = np.linspace(1, 0, fd) ** 1.5; FADE = a[:, :, None]
    arr = np.array(im); arr[:, :, 3:4] = (arr[:, :, 3:4].astype(float) * FADE).astype(np.uint8); return Image.fromarray(arr, "RGBA")
def base_map(cam):
    key = tuple(round(c, 4) for c in cam)
    if key in _base: return _base[key]
    G, gz, wb = geo(cam); im = Image.new("RGBA", (PW * S, PH * S), SEA); d = ImageDraw.Draw(im)
    SKIP = ("Israel", "Palestine", "_LAND")
    for nm, g in G.items():
        if nm in SKIP: continue
        for r in rings(g): d.polygon(pxl(cam, r), fill=LAND)
    for r in rings(G["_LAND"]): d.polygon(pxl(cam, r), fill=ISRF)
    for nm, g in G.items():
        if nm in SKIP: continue
        for r in rings(g): d.line(pxl(cam, r), fill=BORDER, width=max(1, int(1.2 * S)))
    for r in rings(G["_LAND"]): d.line(pxl(cam, r), fill=(255, 236, 190, 150), width=max(1, int(1.2 * S)))
    for ln in lines_of(gline(cam)): d.line(pxl(cam, ln), fill=GLC, width=max(2, int(1.6 * S)), joint="curve")
    if len(_base) > 4: _base.pop(next(iter(_base)))
    _base[key] = im; return im

# ---------------------------------------------------------------- timeline (beats)
TC = dict(C["T_CARDS"]); T_END = C["T_END"]; OUTFILE = C["FINAL"]
N = int(round(T_END * FPS)); RS = C["RS"]
def beat_at(t): return t
def ramp(x, w=0.12): w *= RS; return max(0.0, min(1.0, x / w))
CARD_ORDER = sorted(TC.items(), key=lambda kv: kv[1])
TURN = C["TURN"]

# ---------------------------------------------------------------- drawing helpers
BG = None
def bg():
    global BG
    if BG is None:
        r = np.linspace(0, 1, H * S)[:, None, None]; g = np.array(BG_T)[None, None, :] * (1 - r) + np.array(BG_B)[None, None, :] * r
        BG = Image.fromarray((g * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
    return BG.copy()
def txt(d, x, y, s, sz, col, w=800, anchor="la", maxw=None, alpha=1.0, stroke=0, shadow=False):
    if alpha <= 0.01: return
    if any("\u0590" <= ch <= "\u05ff" for ch in s): s = get_display(s)
    f = font(sz, w)
    if maxw:
        while f.getlength(s) > maxw * S and sz > 10: sz -= 1; f = font(sz, w)
    c = col[:3] + (int(col[3] * alpha),)
    if shadow: d.text(((x + 2.5) * S, (y + 3) * S), s, font=f, fill=(0, 0, 0, int(170 * alpha)), anchor=anchor, stroke_width=int(stroke * S), stroke_fill=(0, 0, 0, int(170 * alpha)))
    if stroke: d.text((x * S, y * S), s, font=f, fill=c, anchor=anchor, stroke_width=int(stroke * S), stroke_fill=(6, 14, 30, int(245 * alpha)))
    else: d.text((x * S, y * S), s, font=f, fill=c, anchor=anchor)
def wrap(s, sz, w, maxw):
    if "\n" in s: return sum((wrap(p, sz, w, maxw) for p in s.split("\n")), [])
    f = font(sz, w); out = [""]
    for word in s.split(" "):
        tr = (out[-1] + " " + word).strip()
        if f.getlength(tr) <= maxw * S or not out[-1]: out[-1] = tr
        else: out.append(word)
    return out
def circle(d, x, y, r, fill, ring=None, rw=1.5):
    if r < 0.6: return
    d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=fill, outline=ring, width=int(rw * S) if ring else 0)
def overlay(im, col, a):
    if a > 0: im.alpha_composite(Image.new("RGBA", im.size, col[:3] + (int(255 * a),)))
def card(im, x, y, w, h, fill, edge, a=1.0, rad=34, ew=3):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S], rad * S, fill=fill[:3] + (int(fill[3] * a),), outline=(edge[:3] + (int(edge[3] * a),)) if edge else None, width=int(ew * S))
    im.alpha_composite(lay)
LE, LHE, L2 = C["LAB_EN"], C["LAB_HE"], C["LAB_L2"]
def label(d, x, y, r, dr, lines, a):
    """lines: [(text, size, colour)], stacked; placed on the side of the point given by dr."""
    if a <= 0.01 or not lines: return
    dx, dy = dr; nrm = math.hypot(dx, dy) or 1; dx, dy = dx / nrm, dy / nrm
    r = max(r, 11); bx, by = x + dx * (r + 10), y + dy * (r + 10); hs = [sz * 1.1 for _, sz, _ in lines]; hh = sum(hs)
    top = by - hh if dy < -0.35 else (by if dy > 0.35 else by - hh / 2)
    ah = "l" if dx > 0.35 else ("r" if dx < -0.35 else "m")
    yy = top
    for (s, sz, col), h_ in zip(lines, hs):
        txt(d, bx, yy + h_ / 2, s, sz, col, 900, ah + "m", alpha=a, stroke=max(3, sz * 0.12), shadow=True); yy += h_
def clines(en, he, col, l2=None, l2col=None):
    out = [(en, LE, WHITE), (he, LHE, col)]
    if l2: out.append((l2, L2, l2col or col))
    return out
def chip(im, x, y, w, h, col, num, en, he, a, pp=0.0):
    if a <= 0.01: return
    card(im, x, y, w, h, hx(col, 70), hx(col, 255), a, 22, 3)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    circle(d, x + 30, y + 46, 14, hx(col, int(255 * a)), hx("#FFFFFF", int(230 * a)), 2)
    txt(d, x + 56, y + 46, num, C["CHIP_NFS"] * (1 + 0.18 * pp), WHITE, 900, "lm", w - 70, a, stroke=3)
    if pp > 0: card(im, x - 4 * pp, y - 4 * pp, w + 8 * pp, h + 8 * pp, hx(col, 0), hx("#FFFFFF", int(230 * pp)), a, 24, 3)
    txt(d, x + 18, y + 97, en, 30, WHITE, 800, "lm", w - 30, a)
    txt(d, x + 18, y + 125, he, 28, hx(col), 800, "lm", w - 30, a)
    im.alpha_composite(lay)

# ---------------------------------------------------------------- subtitles (kit.py look: Heebo ExtraBold 54, dark box)
SUBF = ImageFont.truetype("/root/.fonts/Heebo-ExtraBold.ttf", 54 * S, layout_engine=ImageFont.Layout.BASIC)
DASHES = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))
def sub_draw(im, t):
    cur = [x for x in C["SUBS"] if x[0] <= t < x[1]]
    if not cur: return
    a0, a1, cc = cur[-1]; assert not any(d_ in cc for d_ in DASHES)
    lines = []; w_ = ""
    for x in cc.split():
        tr = (w_ + " " + x).strip()
        if SUBF.getlength(tr) <= 920 * S: w_ = tr
        else: lines.append(w_); w_ = x
    lines.append(w_)
    if len(lines) > 1: print('WARNING 2-line subtitle', round(t, 2), cc)
    lh = 66; Wd = max(SUBF.getlength(x) for x in lines) / S + 56; Hd = lh * len(lines) + 28
    x0 = (W - Wd) / 2; y0 = C["SUB_BOTTOM"] - Hd
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([x0 * S, y0 * S, (x0 + Wd) * S, (y0 + Hd) * S], 22 * S, fill=(8, 16, 40, 200))
    for k, x in enumerate(lines): d.text((W / 2 * S, (y0 + 14 + k * lh + lh / 2) * S), x, font=SUBF, fill=(255, 255, 255, 255), anchor="mm")
    im.alpha_composite(lay)
def pulse(t, t0, per=1.1): return 0.5 - 0.5 * math.cos(2 * math.pi * max(0.0, t - t0) / per)

# ---------------------------------------------------------------- frames
ST = C["COUNTRIES_STATUS"]; WBc, GZc, SIGN = C["WB"], C["GAZA"], C["SIGN"]
SNAPS = [float(x) for x in A.snaps.split(",")] if A.snaps else None
SNAPF = set(int(round(s * FPS)) for s in SNAPS) if SNAPS else set()
SIL = C["OUT"]
EVW = {}
for e in C["EVENTS"]:
    EVW[e[0]] = (wrap(e[1], C["EV_FS"], 900, C["EV_W"]), wrap(e[2], C["EV_HFS"], 800, C["EV_W"]))
    if len(EVW[e[0]][0]) + len(EVW[e[0]][1]) > 3: print("WARNING caption too long:", e[0], EVW[e[0]])
ff = None if SNAPS else subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
     "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", "-threads", "2", SIL], stdin=subprocess.PIPE)
for f in range(N):
    if SNAPS and f not in SNAPF: continue
    t = f / FPS; b = t; cam = cam_at(b); G, gz, wb = geo(cam)
    im = bg(); tl_ = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(tl_)
    for i, (b0, en, he) in enumerate(C["TITLES"]):
        nb = C["TITLES"][i + 1][0] if i + 1 < len(C["TITLES"]) else 1e9
        a = min(ramp(b - b0, 0.15) if b0 > 0 else 1.0, 1 - ramp(b - nb, 0.15))
        txt(d, 480, C["TY"], en, C["T_FS"], WHITE, 900, "ma", 860, a); txt(d, 480, C["TY"] + C["T_GAP"], he, C["T_HFS"], GOLD, 800, "ma", 860, a)
    im.alpha_composite(tl_)
    pan = base_map(cam).copy(); fl = Image.new("RGBA", pan.size, (0, 0, 0, 0)); pd = ImageDraw.Draw(fl)
    zf = min(1.0, max(0.0, (math.log(cam[2]) - math.log(6)) / (math.log(40) - math.log(6))))
    for n, v in ST.items():
        g = G.get(n); a = ramp(b - v["r"], 0.06); col = CATC[v["cat"]]
        if g is None or a <= 0: continue
        pop_ = 1 - ramp(b - v["r"] - 0.1, 0.12)          # stamp flash: brighter fill for a moment
        fa = (38 + 92 * zf) * (1 + 0.8 * pop_)
        for rr in rings(g): pd.polygon(pxl(cam, rr), fill=hx(col, int(min(230, fa) * a)))
        for rr in rings(g): pd.line(pxl(cam, rr), fill=hx(col, int(235 * a)), width=int((2.2 + 2.5 * pop_) * S))
    # Area A / Judea and Samaria: Green Line pulses, Area A cities glow red (inside the gold land, nothing cut out)
    a5 = ramp(b - WBc["r"], 0.15) * (1 - ramp(b - WBc["to"], 0.2))
    if a5 > 0:
        pu = pulse(b, WBc["r"])
        for ln in lines_of(gline(cam)): pd.line(pxl(cam, ln), fill=hx(C["GREEN_LINE"], int((120 + 135 * pu) * a5)), width=int((2.5 + 3.5 * pu) * S), joint="curve")
    a6 = ramp(b - GZc["r"], 0.15) * (1 - ramp(b - GZc["to"], 0.2))
    if a6 > 0:
        pu = pulse(b, GZc["r"])
        for rr in rings(gz): pd.polygon(pxl(cam, rr), fill=hx(C["RED"], int((40 + 50 * pu) * a6)))
        for rr in rings(gz): pd.line(pxl(cam, rr), fill=hx(C["RED"], int((150 + 105 * pu) * a6)), width=int((2.5 + 3.5 * pu) * S), joint="curve")
    if b >= TURN - 0.1:  # land glow at the flip
        ga = ramp(b - TURN, 0.2) * (0.55 + 0.45 * math.cos(min(1, max(0, b - TURN) / 2.2) * math.pi * 2) ** 2) * (1 - ramp(b - TURN - 3.0, 0.4))
        for rr in rings(G["_LAND"]): pd.line(pxl(cam, rr), fill=hx("#FFE9A8", int(255 * ga)), width=int(3.4 * S))
    pan.alpha_composite(fl); im.alpha_composite(fade(pan), (PX * S, PY * S))
    fg = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(fg)
    inpanel = lambda x, y: PX - 40 < x < PX + PW + 40 and PY + 10 < y < PY + PH - 10
    labs = []
    for n, v in ST.items():
        a = ramp(b - v["r"], 0.06)
        if a <= 0: continue
        x, y = proj(cam, *v["ll"])
        if not inpanel(x, y): continue
        col = hx(CATC[v["cat"]]); rr = 10 if cam[2] > 22 else 0; jw = v["jews"]
        if jw and jw[3] - 3.2 < b < jw[4] + 0.4:
            then, now, nowl, sh0, jto = jw; ja = ramp(b - (jw[3] - 3.2), 0.12) * (1 - ramp(b - jw[4], 0.12))
            u = smooth(min(1, max(0, (b - sh0) / 1.0)))
            val = math.exp(math.log(then) * (1 - u) + math.log(max(now, 1)) * u)
            R0 = C["RK"] * math.sqrt(then); r1 = C["RK"] * math.sqrt(val)
            d.ellipse([(x - R0) * S, (y - R0) * S, (x + R0) * S, (y + R0) * S], outline=hx("#FFFFFF", int(170 * ja)), width=int(2 * S))
            circle(d, x, y, max(r1, 1.2), hx("#64D2FF", int(160 * ja)), hx("#FFFFFF", int(210 * ja)), 1.4)
            rr = R0 * ja + rr * (1 - ja)
        elif rr > 0:
            circle(d, x, y, 10, col[:3] + (int(235 * a),), hx("#FFFFFF", int(220 * a)), 2)
        if v["lab"] is None: continue
        if "lab_show" in v: la = min(ramp(b - v["lab_show"][0], 0.1), 1 - ramp(b - v["lab_show"][1], 0.1))
        else: la = min(ramp(b - v["r"], 0.06), 1 - ramp(b - v["lab_to"], 0.1))
        if jw and jw[3] - 3.2 < b < jw[4] + 0.4: la = max(la, ramp(b - (jw[3] - 3.2), 0.12) * (1 - ramp(b - jw[4], 0.12)))
        l2, l2c = v["l2"], None
        if jw and b >= jw[3] - 3.2:
            l2, l2c = (f"{jw[0]:,} » {jw[2]}" if b >= jw[3] + 0.5 else f"{jw[0]:,} Jews, 1948"), hx("#64D2FF")
        labs.append((x, y, rr, v["lab"], clines(v["en"], v["he"], col, l2, l2c), la))
    for gr in C.get("GROUPS", []):
        a = min(ramp(b - gr["r"], 0.1), 1 - ramp(b - gr["lab_to"], 0.1)); x, y = proj(cam, *gr["ll"])
        if a > 0 and inpanel(x, y): labs.append((x, y, 4, gr["dr"], clines(gr["en"], gr["he"], hx(CATC[gr["cat"]]), gr["l2"]), a))
    # Tunisia attack marker
    dj = C["DJERBA"]; ad = ramp(b - dj["r"], 0.08) * (1 - ramp(b - dj["to"], 0.1))
    if ad > 0:
        x, y = proj(cam, *dj["ll"]); pu = ((b - dj["r"]) % 1.1) / 1.1
        circle(d, x, y, 9, hx(C["RED"], int(250 * ad)), hx("#FFFFFF", int(240 * ad)), 2)
        d.ellipse([(x - 12 - 34 * pu) * S, (y - 12 - 34 * pu) * S, (x + 12 + 34 * pu) * S, (y + 12 + 34 * pu) * S], outline=hx(C["RED"], int(230 * ad * (1 - pu))), width=int(3 * S))
    if a5 > 0:
        pu = ((b - WBc["r"]) % 1.1) / 1.1
        for lo, la_ in C["AREA_A"]:
            x, y = proj(cam, lo, la_)
            circle(d, x, y, 15, hx(C["RED"], int(120 * a5)), None)
            d.ellipse([(x - 15 - 22 * pu) * S, (y - 15 - 22 * pu) * S, (x + 15 + 22 * pu) * S, (y + 15 + 22 * pu) * S], outline=hx(C["RED"], int(220 * a5 * (1 - pu))), width=int(2.5 * S))
            circle(d, x, y, 7, hx(C["RED"], int(250 * a5)), hx("#FFFFFF", int(230 * a5)), 1.6)
        x, y = proj(cam, *WBc["ll"]); la = a5 * (1 - ramp(b - WBc["lab_to"], 0.1))
        labs.append((x, y, 8, WBc["lab"], clines(WBc["en"], WBc["he"], hx(C["RED"]), WBc["l2"]), la))
    if a6 > 0:
        x, y = proj(cam, *GZc["ll"])
        labs.append((x, y, 11, GZc["lab"], clines(GZc["en"], GZc["he"], hx(C["RED"]), GZc["l2"]), a6))
    # map legend: gold = Israel, green line = Green Line (1949); city legend joins after the flip
    ml = ramp(b - C["MAP_LEGEND"]["r"], 0.15) * (1 - ramp(b - TC["CARD1"], 0.1))
    if ml > 0:
        lx, ly = 40, PY + 50
        d.rounded_rectangle([lx * S, (ly - 13) * S, (lx + 26) * S, (ly + 13) * S], 5 * S, fill=hx(C["ISR_GOLD"], int(255 * ml)), outline=hx("#FFFFFF", int(200 * ml)), width=int(1.5 * S))
        txt(d, lx + 38, ly, "Israel  |  ישראל", 28, WHITE, 800, "lm", alpha=ml, stroke=3)
        d.line([lx * S, (ly + 44) * S, (lx + 26) * S, (ly + 44) * S], fill=hx(C["GREEN_LINE"], int(255 * ml)), width=int(4 * S))
        txt(d, lx + 38, ly + 44, "Green Line, 1949  |  הקו הירוק", 28, WHITE, 800, "lm", alpha=ml, stroke=3)
    if b >= TURN:
        for nm, he, ll, dr, r0, lt in C["CITIES"]:
            a = ramp(b - r0, 0.08); x, y = proj(cam, *ll)
            circle(d, x, y, 11, hx(C["CITY"], int(210 * a)), hx("#FFFFFF", int(230 * a)), 2)
            la = min(a, 1 - ramp(b - lt, 0.08))
            labs.append((x, y, 11, dr, [(nm, LE, WHITE), (he, LHE, hx(C["CITY"]))], la))
        ca = ramp(b - TURN - 0.3, 0.15) * (1 - ramp(b - TC["CARD1"], 0.1)); lx, ly = 40, PY + 138
        circle(d, lx + 13, ly, 13, hx(C["CITY"], int(210 * ca)), hx("#FFFFFF", int(230 * ca)), 2)
        txt(d, lx + 38, ly, C["CITY_LEGEND"][0] + "  |  " + C["CITY_LEGEND"][1], 28, WHITE, 800, "lm", alpha=ca, stroke=3)
        for nm, he, ll, dr, l2, r0, lt in C["PINS"]:
            a = min(ramp(b - r0, 0.08), 1 - ramp(b - lt, 0.08))
            if a <= 0: continue
            x, y = proj(cam, *ll); s_ = 14
            d.polygon([((x) * S, (y - s_ * 1.3) * S), ((x + s_) * S, (y) * S), ((x) * S, (y + s_ * 1.3) * S), ((x - s_) * S, (y) * S)],
                      fill=hx(C["GOLDC"], int(255 * a)), outline=hx("#0E1E3A", int(255 * a)), width=int(2 * S))
            labs.append((x, y, 16, dr, [(nm, LE, WHITE), (he, LHE, hx(C["GOLDC"])), (l2, L2, hx(C["GOLDC"]))], a))
    for L_ in labs: label(d, *L_)
    sa = ramp(b - SIGN["r"], 0.08) * (1 - ramp(b - SIGN["to"], 0.08))
    if sa > 0:
        sx, sy, sw = SIGN["x"], SIGN["y"], SIGN["w"]; nl = len(SIGN["lines"]); LH_ = 44
        txt(d, sx + sw / 2, sy - 22, SIGN["head"], 28, WHITE, 800, "mm", sw, sa, stroke=3)
        d.rounded_rectangle([sx * S, sy * S, (sx + sw) * S, (sy + 26 + nl * LH_) * S], 16 * S, fill=hx("#C8102E", int(245 * sa)), outline=hx("#FFFFFF", int(255 * sa)), width=4 * S)
        for i, l in enumerate(SIGN["lines"]): txt(d, sx + sw / 2, sy + 13 + LH_ / 2 + i * LH_, l, 36, WHITE, 900, "mm", sw - 40, sa)
    im.alpha_composite(fg)
    # chips: scorecard (phase A, counts with a pop on every stamp), Israel facts (phase B)
    pa = 1 - ramp(b - TURN + 0.05, 0.12)
    for (le, lh, cat, col), cx_ in zip(C["COUNTERS_A"], C["CHIP_X"]):
        rs = [s_["r"] for n, s_ in ST.items() if s_["cat"] == cat and b >= s_["r"]]; v = len(rs)
        pp = (1 - min(1, (b - max(rs)) / 0.22)) if rs else 0
        chip(im, cx_, C["CHIP_Y"], C["CHIP_W"], C["CHIP_H"], col, str(v), le, lh, pa, pp)
    for (le, lh, val, col, r0), cx_ in zip(C["COUNTERS_B"], C["CHIP_X"]):
        chip(im, cx_, C["CHIP_Y"], C["CHIP_W"], C["CHIP_H"], col, val, le, lh, ramp(b - r0, 0.1), 1 - min(1, max(0, b - r0) / 0.3) if b >= r0 else 0)
    fg = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(fg)
    ev = [e for e in C["EVENTS"] if e[0] <= b + 1e-6]
    if ev and b < TC["CARD1"] + 0.4:
        e = ev[-1]; a = ramp(b - e[0], 0.06) if e[0] > 0 else 1.0; en_l, he_l = EVW[e[0]]
        y = C["EV_Y"]; EF, HF = C["EV_FS"], C["EV_HFS"]
        for l in en_l: txt(d, C["EV_X"], y, l, EF, WHITE, 900, "ma", C["EV_W"], a, stroke=2); y += EF * 1.16
        y += 8
        for l in he_l: txt(d, C["EV_X"], y, l, HF, GOLD, 800, "ma", C["EV_W"], a, stroke=2); y += HF * 1.22
    dk = max(k for k in C["DISC"] if k <= b + 1e-6)
    for i, l in enumerate(C["DISC"][dk]): txt(d, 480, C["DISC_Y"] + i * C["DISC_LH"], l, C["DISC_FS"], SUBC, 700, "ma", 900)
    im.alpha_composite(fg)
    hk = C["HOOK"]
    if t < hk["dur"]:
        a = 1.0 if t < hk["dur"] - 0.2 else max(0, (hk["dur"] - t) / 0.2)
        overlay(im, hx("#0A1630"), 0.93 * a); card(im, 54, 640, 972, 560, GOLD, WHITE, a, 40, 5)
        sc = 1.0 + 0.05 * min(1, t / hk["dur"]); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        for (yy2, s, col, sz) in hk["lines"]: txt(d, 540, yy2, s, sz * sc, hx(col), 900, "mm", 900, a)
        im.alpha_composite(lay)
    if t >= CARD_ORDER[0][1]:
        overlay(im, hx("#06101F"), 0.70 * min(1, (t - CARD_ORDER[0][1]) / 0.4))
        for i, (key, t0) in enumerate(CARD_ORDER):
            if t < t0: continue
            t1 = CARD_ORDER[i + 1][1] if i + 1 < len(CARD_ORDER) else 1e9
            a = min(1, (t - t0) / 0.4) * (1 - min(1, max(0, (t - t1) / 0.35)))
            if a <= 0: continue
            cd = C["CARDS"][key]; sc = 0.94 + 0.06 * smooth(min(1, (t - t0) / 0.45))
            card(im, 36, cd["y"], 888, cd["h"], hx("#0E1E3A", 248), hx(cd["edge"], 230), a, 36, cd["ew"])
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            for (yy2, s, col, sz, w_) in cd["lines"]: txt(d, 480, yy2, s, sz * sc, hx(col), w_, "mm", 830, a)
            im.alpha_composite(lay)
    sub_draw(im, t)
    out = im.reduce(S).convert("RGB")
    if SNAPS: os.makedirs(C["SNAPDIR"], exist_ok=True); out.save(f"{C['SNAPDIR']}/{C['TAG']}_{t:05.2f}.png"); continue
    ff.stdin.write(out.tobytes())
    if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
if SNAPS: print("snaps ->", C["SNAPDIR"]); sys.exit()
ff.stdin.close(); ff.wait(); print("video", SIL, f"{T_END:.2f}s")
if A.silent or not A.audio: sys.exit()
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", SIL, "-i", A.audio, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-ar", "48000", "-movflags", "+faststart", "-t", f"{T_END:.2f}", OUTFILE], check=True)
os.remove(SIL); print("final", OUTFILE)
