"""QA for safety_v5: web copy, contact sheet, ebur128, ASR of the final mix vs tts.txt, first frame hook text."""
import sys, json; sys.path.insert(0, "/home/claude/rehook"); import rk5, numpy as np
D = "/home/claude/safety_v4"; W = rk5.words_of(f"{D}/work5")["words"]; L = rk5.lines_of(f"{D}/tts.txt")
B = json.load(open(f"{D}/work5/build_v5.json")); T = B["T_END"]
times = [0.0, 0.7, 1.4] + [round(float(x), 2) for x in np.linspace(2.5, T - 0.8, 12)]
R = rk5.qa("safety_v5", f"{D}/safety_v5.mp4", f"{D}/safety_v5_web.mp4", L, W, f"{D}/safety_v5_qa.png", times,
           extra_notes=[f"Voice: all Cartesia (vo_raw_v5.wav), house chain, restored spans {len(json.load(open(f'{D}/work5/words.json'))['restored_spans'])}. Sources text 30 px. Hook card 0 to 1.5 s."],
           hook_box=(60, 650, 1020, 1190))
B["qa"] = R; json.dump(B, open(f"{D}/work5/build_v5.json", "w"), indent=1, ensure_ascii=False)
print(json.dumps({k: R[k] for k in ("main", "web", "loudness", "asr_mismatches", "asr_inserted", "first_frame_ink")}, ensure_ascii=False))
