# v5 of "Where can a Jew walk safely?" (v4: cfg_v4.py, not modified). v5 changes: new all-Cartesia narration (vo_raw_v5.wav, tts.txt)
# through the house chain + ASR restore (/home/claude/rehook/v5lib.py -> work5/vo.wav, work5/words.json); every beat re-timed to the
# new word times; three corrected lines ("a military order bars Israelis from Area A", "One in five citizens of Israel is Arab",
# "So in many Arab countries, Jews can't live safely") in subtitles, captions and the end card; source lines at 30 px (were 26).
# Render: nice -n 15 python3 engine_v4.py cfg_v5.py [--snaps 0.5,12,30]
# Sources: /home/claude/vid/final/jews_safety_map_sources.txt
import json, re
D = "/home/claude/safety_v4"
TAG = "safety_v5"
OUT = f"{D}/work5/silent.mp4"; FINAL = f"{D}/safety_v5.mp4"; SNAPDIR = f"{D}/work5/snaps"
VO = f"{D}/work5/vo.wav"
RED, AMB, GRN, GOLDC, CITY = "#F0525A", "#F5A524", "#34C97F", "#F2D58A", "#64D2FF"
ISR_GOLD = "#B8923F"; GREEN_LINE = "#2ECC71"      # video-guidelines.md: whole land of Israel gold, Green Line (46,204,113)

# ------------------------------------------------------------------ narration timing (reel seconds, from the word alignment)
WORDS = json.load(open(f"{D}/work5/words.json"))["words"]
def _n(w): return re.sub(r"[^a-z0-9']", "", w.lower())
# (script line, phrase as spoken in tts.txt, subtitle / display text)
CTL = [(0, "Where can a Jew walk safely?", "Where can a Jew walk safely?"), (0, "Let's check the map.", "Let's check the map."),
       (1, "Iran.", "Iran."), (1, "Iraq.", "Iraq."), (1, "Syria.", "Syria."), (1, "Lebanon.", "Lebanon."), (1, "Yemen.", "Yemen."), (1, "Libya.", "Libya."),
       (1, "Show an Israeli passport,", "Show an Israeli passport,"), (1, "and you're turned away.", "and you're turned away."),
       (2, "Iraq once had a hundred and thirty-five thousand Jews.", "Iraq once had 135,000 Jews."), (2, "Today?", "Today?"), (2, "About four.", "About 4."),
       (3, "In Tunisia, in 2023,", "In Tunisia, in 2023,"), (3, "a gunman killed two Jewish pilgrims at a synagogue.", "a gunman killed 2 Jewish pilgrims at a synagogue."),
       (4, "Closer to home, a military order bars Israelis from Area A.", "Closer to home, a military order bars Israelis from Area A."),
       (4, "And Gaza?", "And Gaza?"), (4, "Two hundred and fifty-one hostages.", "251 hostages."), (5, "To be fair:", "To be fair:"),
       (5, "Egypt and Jordan made peace with Israel.", "Egypt and Jordan made peace with Israel."),
       (5, "And Jews live openly in Morocco, the Emirates and Bahrain.", "And Jews live openly in Morocco, the Emirates and Bahrain."),
       (6, "Now flip the map.", "Now flip the map."), (6, "One in five citizens of Israel is Arab.", "1 in 5 citizens of Israel is Arab."),
       (6, "Arab parties sit in the Knesset.", "Arab parties sit in the Knesset."), (6, "Ra'am joined the government.", "Ra'am joined the government."),
       (7, "A quarter of the doctors are Arab.", "A quarter of the doctors are Arab."),
       (7, "And an Arab judge led the panel that convicted a former President.", "And an Arab judge led the panel that convicted a former President."),
       (8, "So in many Arab countries,", "So in many Arab countries,"), (8, "Jews can't live safely.", "Jews can't live safely."),
       (8, "In the Jewish state,", "In the Jewish state,"), (8, "Arab citizens are in the market,", "Arab citizens are in the market,"),
       (8, "the Knesset and the courts.", "the Knesset and the courts."), (9, "Did this surprise you?", "Did this surprise you?"),
       (9, "Comment SAFE for the sources.", "Comment SAFE for the sources.")]
CT = [x[2] for x in CTL]
def _pw(li, phrase):
    ws = [w for w in WORDS if w["li"] == li]; key = [_n(x) for x in phrase.split()]
    hits = [i for i in range(len(ws) - len(key) + 1) if [_n(w["w"]) for w in ws[i:i + len(key)]] == key]
    assert len(hits) >= 1, (li, phrase); return ws[hits[0]:hits[0] + len(key)]
PW = [_pw(li, p) for li, p, _ in CTL]
SPAN = [(p[0]["t0"], p[-1]["t1"]) for p in PW]
assert all(a < b for a, b in SPAN) and all(SPAN[k][1] <= SPAN[k + 1][0] + 0.05 for k in range(len(SPAN) - 1)), SPAN
def at(k, word=None, end=False):
    """time phrase k starts/ends, or a word (spoken form, as in tts.txt) inside it starts/ends"""
    a, b = SPAN[k]
    if word is None: return b if end else a
    ws = PW[k]; key = [_n(x) for x in word.split()]
    hits = [i for i in range(len(ws) - len(key) + 1) if [_n(w["w"]) for w in ws[i:i + len(key)]] == key]
    assert hits, (k, word); i = hits[0]
    return ws[i + len(key) - 1]["t1"] if end else ws[i]["t0"]
VO_END = SPAN[-1][1]; T_END = round(VO_END + 3.0, 2)     # 3 s CTA hold after the voice

# subtitles: (start, end, text); listed names build up one by one
SUBS = []
def sub(k0, k1, txt, t0=None, t1=None): SUBS.append([t0 if t0 is not None else at(k0), t1 if t1 is not None else at(k1, end=True), txt])
sub(0, 0, CT[0]); sub(1, 1, CT[1])
sub(2, 2, "Iran.", t1=at(3)); sub(3, 3, "Iran. Iraq.", t1=at(4)); sub(4, 4, "Iran. Iraq. Syria.")
sub(5, 5, "Lebanon.", t1=at(6)); sub(6, 6, "Lebanon. Yemen.", t1=at(7)); sub(7, 7, "Lebanon. Yemen. Libya.")
sub(8, 8, "Show an Israeli passport,"); sub(9, 9, CT[9]); sub(10, 10, CT[10]); sub(11, 12, "Today? About 4.")
sub(13, 13, CT[13]); sub(14, 14, "A gunman killed 2 Jewish pilgrims", t1=at(14, "at")); sub(14, 14, "at a synagogue.", t0=at(14, "at"))
sub(15, 15, "Closer to home,", t1=at(15, "a military")); sub(15, 15, "a military order", t0=at(15, "a military"), t1=at(15, "bars")); sub(15, 15, "bars Israelis from Area A.", t0=at(15, "bars"))
sub(16, 16, CT[16]); sub(17, 17, CT[17]); sub(18, 18, CT[18]); sub(19, 19, "Egypt and Jordan", t1=at(19, "made")); sub(19, 19, "made peace with Israel.", t0=at(19, "made"))
sub(20, 20, "And Jews live openly in Morocco,", t1=at(20, "the Emirates")); sub(20, 20, "the Emirates and Bahrain.", t0=at(20, "the Emirates"))
for k in range(21, 26): sub(k, k, CT[k])
sub(26, 26, "And an Arab judge led the panel", t1=at(26, "that")); sub(26, 26, "that convicted a former President.", t0=at(26, "that"))
sub(27, 27, CT[27], t1=at(28)); sub(28, 28, CT[28])
sub(29, 29, CT[29]); sub(30, 30, CT[30]); sub(31, 31, CT[31]); sub(32, 32, CT[32]); sub(33, 33, CT[33])
SUBS[-1][1] = T_END - 0.2
SUB_BOTTOM = 1650

# ------------------------------------------------------------------ layout (1080x1920)
TITLES = [(0, "Can Israelis even get in?", "האם ישראלים בכלל יכולים להיכנס?"),
          (at(21) + 0.1, "Arabs in the Jewish state", "ערבים במדינה היהודית")]
TY = 256; T_FS = 50; T_HFS = 42; T_GAP = 58
CHIP_Y = 372; CHIP_H = 140; CHIP_X = [40, 335, 630]; CHIP_W = 280; CHIP_NFS = 76
PANEL = (0, 520, 1080, 708)
EV_Y = 1238; EV_FS = 52; EV_HFS = 42; EV_W = 860; EV_X = 480
DISC_Y = 1424; DISC_FS = 30; DISC_LH = 34
LAB_EN, LAB_HE, LAB_L2 = 38, 34, 30
RS = 2.6             # fade widths: v3 ramps were in beats (about 3 s each); here the clock is seconds
TURN = at(21)

# cameras: (time s, centre lon, centre lat, visible degrees of longitude)
WIDE = (27.0, 28.5, 72.0); FAR = (55.0, 21.0, 124.0); IRQ = (42.5, 32.4, 24.0); TUN = (11.0, 31.0, 26.0)
HOLY = (35.0, 31.95, 4.4); FAIR = (34.0, 28.8, 34.0); GREEN = (25.0, 27.5, 76.0); ISR = (35.1, 31.45, 5.6)
CAM = [(0, *WIDE), (at(8) - 0.1, *WIDE), (at(8) + 1.1, *FAR), (at(9, end=True), *FAR), (at(10) + 0.8, *IRQ), (at(12, end=True), *IRQ),
       (at(13) + 0.9, *TUN), (at(14, end=True), *TUN), (at(15) + 1.2, *HOLY), (at(17, end=True), *HOLY), (at(18) + 0.9, *FAIR),
       (at(19, end=True), *FAIR), (at(20) + 1.0, *GREEN), (at(20, end=True), *GREEN), (at(21) + 1.0, *ISR), (99, *ISR)]

# countries: he, category, reveal time, label point, label direction, line 2, jews, label end time
C_ = {}
def c(name, he, cat, r, ll, lab, l2=None, jews=None, lab_to=None, en=None):
    C_[name] = dict(he=he, cat=cat, r=r, ll=ll, lab=lab, l2=l2, jews=jews, lab_to=lab_to if lab_to else r + 1.3, en=en or name)
# named one by one (stamp + label while named)
c("Iran", "איראן", "red", at(2), (53.0, 32.0), (0, -1), lab_to=at(4) + 0.4)
c("Iraq", "עיראק", "red", at(3), (43.8, 33.0), (0.2, 1), lab_to=at(5),
  jews=(135000, 4, "4", at(11), at(12, end=True) + 0.8))
c("Syria", "סוריה", "red", at(4), (38.6, 35.4), (-0.4, -1), lab_to=at(5) + 0.5)
c("Lebanon", "לבנון", "red", at(5), (35.85, 33.9), (-1, 0.35), lab_to=at(6) + 0.6)
c("Yemen", "תימן", "red", at(6), (46.5, 15.8), (-1, 0.2), lab_to=at(7) + 0.6)
c("Libya", "לוב", "red", at(7), (17.5, 27.5), (0, 1), lab_to=at(8) + 0.4)
# the rest stamp in on "Show an Israeli passport, and you're turned away" (no labels: the chips count them)
_burst = [("Kuwait", "כווית", "red"), ("Saudi Arabia", "ערב הסעודית", "amb"), ("Oman", "עומאן", "red"), ("Algeria", "אלג'יריה", "red"),
          ("Tunisia", "תוניסיה", "amb"), ("Pakistan", "פקיסטן", "amb"), ("Afghanistan", "אפגניסטן", "red"), ("Maldives", "מלדיביים", "red"),
          ("Bangladesh", "בנגלדש", "red"), ("Malaysia", "מלזיה", "amb"), ("Brunei", "ברוניי", "red")]
_t0 = at(8) + 0.35; _dt = (at(9, end=True) - _t0) / len(_burst)
_ll = {"Kuwait": (47.6, 29.3), "Saudi Arabia": (44.5, 23.5), "Oman": (56.0, 20.5), "Algeria": (2.6, 28.5), "Tunisia": (9.4, 34.0),
       "Pakistan": (69.5, 29.0), "Afghanistan": (65.5, 34.0), "Maldives": (73.4, 3.5), "Bangladesh": (90.3, 23.8), "Malaysia": (101.7, 3.8),
       "Brunei": (114.7, 4.7)}
for i, (n, he, cat) in enumerate(_burst): c(n, he, cat, _t0 + i * _dt, _ll[n], None)
C_["Tunisia"].update(lab=(0.1, -1), l2="no relations", lab_show=(at(13), at(14, end=True) + 0.3))
# open to Israelis (named in the fair beat)
c("Egypt", "מצרים", "grn", at(19, "Egypt"), (29.0, 26.5), (-0.6, 1), l2="peace 1979", lab_to=at(20) + 0.6)
c("Jordan", "ירדן", "grn", at(19, "Jordan"), (36.6, 30.8), (1, -0.8), l2="peace 1994", lab_to=at(20) + 0.6)
c("Morocco", "מרוקו", "grn", at(20, "Morocco"), (-6.3, 32.0), (1, -0.9), l2="~2,000 Jews", lab_to=at(21) + 0.3)
c("United Arab Emirates", "איחוד האמירויות", "grn", at(20, "Emirates"), (54.3, 24.0), None, lab_to=at(21) + 0.3, en="UAE")
c("Bahrain", "בחריין", "grn", at(20, "Bahrain"), (50.55, 26.05), None, lab_to=at(21) + 0.3)
COUNTRIES_STATUS = C_
GROUPS = [dict(r=at(20, "Emirates"), lab_to=at(21) + 0.3, ll=(51.5, 23.0), dr=(-0.7, 1), en="UAE + Bahrain", he="אמירויות ובחריין", l2="Abraham Accords", cat="grn")]
RK = 0.12
STAMPS = sorted(v["r"] for v in C_.values())          # one stamp thunk per country that lights up

# Tunisia attack marker (El Ghriba synagogue, Djerba)
DJERBA = dict(ll=(10.86, 33.81), r=at(14, "gunman"), to=at(14, end=True) + 0.5)
# Area A (inside Judea and Samaria) and Gaza: red highlight inside the gold land, Green Line pulses
AREA_A = [(35.30, 32.46), (35.03, 32.31), (34.97, 32.19), (35.26, 32.22), (35.20, 31.90), (35.45, 31.86), (35.20, 31.705), (35.10, 31.53)]
WB = dict(r=at(15, "military"), to=at(16) + 0.2, he="יהודה ושומרון", en="Judea and Samaria", ll=(35.36, 32.08), lab=(1, -0.2),
          l2="Area A: no entry", lab_to=at(16))
GAZA = dict(r=at(16), to=at(18), he="עזה", en="Gaza", ll=(34.40, 31.43), lab=(-1, 0.1), l2="251 hostages")
SIGN = dict(r=at(15, "Area A") - 0.6, to=at(16) - 0.1, x=40, y=990, w=880,
            head="The red sign at the entrance  |  השלט האדום בכניסה",
            lines=["This road leads to Area \"A\"", "under the Palestinian Authority.", "Entrance for Israeli citizens is forbidden,",
                   "dangerous to your lives and against Israeli law."])
MAP_LEGEND = dict(r=at(15) + 0.6)    # gold = Israel, green line = Green Line (1949); stays to the end

# Israel: Arab and mixed cities, then pins
_c1 = at(22); _c2 = at(22, end=True)
CITIES = [("Haifa", "חיפה", (34.99, 32.79), (-1, -0.1), _c1, _c1 + 0.9), ("Nazareth", "נצרת", (35.30, 32.70), (1, 0.1), _c1, _c1 + 0.9),
          ("Sakhnin", "סח'נין", (35.30, 32.865), (1, -0.2), _c1 + 0.8, _c1 + 1.7), ("Tayibe", "טייבה", (34.98, 32.27), (-1, 0), _c1 + 0.8, _c1 + 1.7),
          ("Umm al-Fahm", "אום אל-פחם", (35.15, 32.52), (1, 0.2), _c1 + 1.6, at(23) + 0.4), ("Rahat", "רהט", (34.75, 31.39), (-1, 0), _c1 + 1.6, at(23) + 0.4)]
CITY_LEGEND = ("Arab and mixed cities", "ערים ערביות ומעורבות")
PINS = [("Knesset", "הכנסת", (35.205, 31.777), (1, 0.3), "10 Arab seats", at(23, "Knesset") - 0.3, at(26)),
        ("District Court", "בית המשפט המחוזי", (34.785, 32.075), (-1, 0.1), "Katsav convicted, 2010", at(26), 99)]

COUNTERS_A = [("Refused", "אסורה", "red", RED), ("Permit only", "רק בהיתר", "amb", AMB), ("Open", "פתוחות", "grn", GRN)]
COUNTERS_B = [("Arabs in Israel", "ערבים בישראל", "21%", GOLDC, at(22, "One in five")), ("Knesset seats", "מושבים בכנסת", "10/120", CITY, at(23)),
              ("Doctors", "רופאים", "25%", GRN, at(25))]

EVENTS = [(0, "Where can a Jew walk safely?", "איפה יהודי יכול להסתובב בבטחה?"),
 (at(2) - 0.1, "Israeli passport? Entry refused.", "דרכון ישראלי? הכניסה אסורה."),
 (at(8), "13 countries refuse Israelis.\n4 more: special permit only.", "13 מדינות לא מכניסות ישראלים, 4 רק בהיתר."),
 (at(10), "Iraq had 135,000 Jews in 1948.\nToday: about 4.", "בעיראק חיו 135,000 יהודים ב-1948. היום: כ-4."),
 (at(13), "Tunisia, 2023: a gunman\nkilled 2 Jewish pilgrims", "תוניסיה, 2023: מחבל רצח 2 עולי רגל יהודים"),
 (at(15, "a military"), "Area A: a military order\nbars Israelis", "שטח A: צו צבאי אוסר על ישראלים להיכנס"),
 (at(16), "Gaza, 7 Oct 2023:\n251 people taken hostage", "עזה, 7 באוקטובר 2023: 251 נחטפו"),
 (at(18), "To be fair: Egypt and Jordan\nmade peace with Israel", "ולמען ההגינות: שלום עם מצרים וירדן"),
 (at(20), "Jews live openly in Morocco,\nthe UAE and Bahrain", "יהודים חיים בגלוי במרוקו, באמירויות ובבחריין"),
 (at(21), "Now flip the map: 1 in 5\ncitizens of Israel is Arab", "ועכשיו הפוך: 1 מכל 5 אזרחי ישראל ערבי"),
 (at(23), "Arab parties won 10 Knesset seats", "מפלגות ערביות זכו ב-10 מושבים בכנסת"),
 (at(24), "2021: Ra'am joined the government", "2021: רע\"מ הצטרפה לממשלה"),
 (at(25), "1 in 4 doctors is Arab.\nAbout half of pharmacists, too.", "1 מכל 4 רופאים וכמחצית מהרוקחים הם ערבים"),
 (at(26), "2010: Arab judge George Karra", "2010: השופט הערבי ג'ורג' קרא"),
 (at(26, "that"), "led the panel that convicted\nex-President Katsav", "ראש ההרכב שהרשיע את הנשיא לשעבר קצב")]
DISC = {0: ["Colours = entry rules for Israeli passports, not safety.",
            "Visa lists: Wikipedia, Oct 2026. Jews: DellaPergola 2023.",
            "הצבעים = כללי כניסה לבעלי דרכון ישראלי, לא דירוג בטיחות."],
        at(13) - 0.2: ["Djerba, El Ghriba synagogue, 9 May 2023 (JTA).", "Colours = entry rules, not a safety rating."],
        at(15) - 0.2: ["Area A: Israeli military order, red signs at the entrances.", "Hostages: IDF, 7 Oct 2023. Green Line: 1949 armistice line."],
        at(18) - 0.2: ["Peace treaties: Egypt 1979, Jordan 1994. Abraham Accords 2020.", "Morocco: about 2,000 Jews (DellaPergola 2023)."],
        TURN - 0.1: ["Israel CBS (Apr 2026). Rosen & Miaari, IJHPR 2025.",
                     "Knesset 2022. Katsav verdict 30 Dec 2010. Sources in caption."]}

HOOK = {"dur": 1.5, "lines": [(745, "Where can a Jew", "#0E1E3A", 74), (835, "walk safely?", "#0E1E3A", 92),
                              (960, "איפה יהודי יכול", "#0E1E3A", 60), (1035, "להסתובב בבטחה?", "#0E1E3A", 60),
                              (1140, "A map  |  מפה", "#0E1E3A", 30)]}
T_CARDS = [("CARD1", at(27) - 0.15), ("CTA", at(32) - 0.15)]
CARDS = {
 "CARD1": dict(edge="#a9bbd8", ew=3, y=470, h=760, lines=[(550, "In many Arab countries,", "#FFFFFF", 56, 900), (616, "Jews can't live safely.", "#FFFFFF", 56, 900),
     (700, "In the Jewish state, Arab citizens", "#D2AA53", 44, 800), (754, "are in the market, the Knesset,", "#D2AA53", 44, 800), (808, "and the courts.", "#D2AA53", 44, 800),
     (896, "בהרבה מדינות ערביות,", "#FFFFFF", 42, 800), (948, "יהודים לא יכולים לחיות בבטחה.", "#FFFFFF", 42, 800),
     (1028, "במדינה היהודית, אזרחים ערבים נמצאים", "#D2AA53", 42, 800), (1080, "בשוק, בכנסת ובבתי המשפט.", "#D2AA53", 42, 800)]),
 "CTA": dict(edge="#D2AA53", ew=4, y=560, h=580, lines=[(650, "Did this surprise you?", "#FFFFFF", 54, 900), (752, "Comment SAFE", "#D2AA53", 80, 900),
     (828, "for the sources", "#FFFFFF", 42, 700), (930, "משהו פה הפתיע אתכם?", "#FFFFFF", 50, 800), (1014, "כתבו SAFE בתגובות למקורות", "#D2AA53", 46, 800)]),
}
# audio cues (s): stamp thunks on every country that lights up, whoosh into the flip, soft hits on the cards
WHOOSH = at(21) - 0.45
HITS = [T_CARDS[0][1], T_CARDS[1][1]]

# ------------------------------------------------------------------ v5 checks: no dashes on screen, source lines >= 30 px without shrinking
from PIL import ImageFont as _IF
_D = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))
_txt = [x[2] for x in SUBS] + [e[1] + e[2] for e in EVENTS] + [l for v in DISC.values() for l in v] + [l[1] for cd in CARDS.values() for l in cd["lines"]] + CT
assert not any(d in s for s in _txt for d in _D)
_f = _IF.truetype("/home/claude/vid/fonts/Heebo-700.ttf", DISC_FS * 2)
for _v in DISC.values():
    for _l in _v: assert _f.getlength(_l) <= 900 * 2, ("source line would shrink under 30 px", _l)
