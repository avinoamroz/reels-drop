"""v4 narration: house chain (kit.py / russian_army_v2.py): rubberband pitch 0.9715 formant preserved, bass g2 f135,
clean_vo, atempo 1.1, 0.3 s lead. Pauses are kept as recorded (no gap cap) so the voice lands at about 55 s.
Writes work/vo_clean.wav (chain with clean_vo) and work/vo_dry.wav (same chain without clean_vo, sample aligned),
so word endings that clean_vo ducks can be restored locally from the dry signal (vo_fix.py)."""
import sys, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4")
from clean_vo import clean as clean_vo
SR, TEMPO, LEAD = 48000, 1.1, 0.3
D = "/home/claude/safety_v4"
def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-800:]; return r.stdout
raw = run(["ffmpeg", "-v", "error", "-i", f"{D}/vo_raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
           "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"])
x = np.frombuffer(raw, np.float32).astype(np.float64)
xc = clean_vo(x, SR).astype(np.float32); assert len(xc) == len(x)
def tempo(y):
    return np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                              "-f", "f32le", "pipe:1"], y.astype(np.float32).tobytes()), np.float32).astype(np.float64)
lead = np.zeros(int(LEAD * SR))
if len(sys.argv) > 1 and sys.argv[1] == "final":
    # tempo + lead on the restored pre-tempo signal (vo_fix.py) -> the narration used in the reel
    y, _ = sf.read(f"{D}/work/pre_fixed.wav"); z = np.concatenate([lead, tempo(y)])
    sf.write(f"{D}/work/vo_fixed.wav", z.astype(np.float32), SR, subtype="FLOAT"); print("fixed", round(len(z) / SR, 2), "s"); sys.exit()
for nm, y in (("clean", xc), ("dry", x)):
    sf.write(f"{D}/work/pre_{nm}.wav", y.astype(np.float32), SR, subtype="FLOAT")   # pre-tempo, sample aligned
    z = np.concatenate([lead, tempo(y)]); sf.write(f"{D}/work/vo_{nm}.wav", z.astype(np.float32), SR, subtype="FLOAT")
    print(nm, round(len(z) / SR, 2), "s")
