"""ASR-checked line boundaries for a narration wav.
usage: python3 asr_segs.py VO.wav TTS.txt OUT.json
1. silencedetect (-38 dB, 0.22 s) splits the wav into speech chunks.
2. Each chunk is transcribed with the local whisper (sherpa-onnx turbo, int8).
3. A DP groups consecutive chunks into exactly one group per script line, maximising word overlap (F1) between each
   group's transcript and its line (digits spelled out with num2words, so lone-number chunks attach to the right line). segs = [start, end] of each group."""
import sys, re, json, subprocess, numpy as np, sherpa_onnx
wav, tts, out = sys.argv[1:4]
lines = [re.sub(r"\[[^\]]*\]", "", l).strip() for l in open(tts).read().split("\n") if l.strip()]; n = len(lines)
r = subprocess.run(["ffmpeg", "-nostdin", "-i", wav, "-af", "silencedetect=noise=-38dB:d=0.22", "-f", "null", "-"], capture_output=True, text=True).stderr
st = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r)]; en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r)]
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", wav], capture_output=True, text=True).stdout)
b = [0.0] + [x for p in zip(st, en) for x in p] + [dur]
if len(st) > len(en): b = b[:-1]
ch = [(b[2 * i], b[2 * i + 1]) for i in range(len(b) // 2) if b[2 * i + 1] - b[2 * i] > 0.12]
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", wav, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
Wd = "/tmp/claude-0/asr/sherpa-onnx-whisper-turbo/"
asr = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=Wd + "turbo-encoder.int8.onnx", decoder=Wd + "turbo-decoder.int8.onnx", tokens=Wd + "turbo-tokens.txt", language="en", task="transcribe", num_threads=1)
txt = []
for a, e in ch:
    s = asr.create_stream(); s.accept_waveform(16000, np.concatenate([x[int(a * 16000):int(e * 16000)], np.zeros(6400, np.float32)])); asr.decode_stream(s)
    txt.append(s.result.text.strip()); print(f"{a:6.2f} {e:6.2f} {txt[-1]}", flush=True)
NUM = set("zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty thirty forty fifty sixty seventy eighty ninety hundred thousand million point percent".split())
from num2words import num2words
def spell(s):   # ASR writes digits ("1948", "14", "25.8%"); the script spells them out: compare in words
    def one(m):
        t = m.group(0).replace(",", "")
        try:
            v = float(t); iv = int(v)
            return num2words(iv, to="year") if v == iv and 1900 <= iv <= 2099 else num2words(v if v != iv else iv)
        except Exception: return t
    return re.sub(r"\d[\d,]*(\.\d+)?", one, s)
def toks(s): return re.findall(r"[a-z']+", spell(s).lower().replace("-", " "))
def f1(a, b):
    a, b = toks(a), toks(b)
    if not a or not b: return 0.0
    from collections import Counter
    c = sum((Counter(a) & Counter(b)).values()); return 0 if c == 0 else 2 * c / (len(a) + len(b))
m = len(ch); NEG = -1e9
best = np.full((n + 1, m + 1), NEG); bk = np.zeros((n + 1, m + 1), int); best[0][0] = 0
for i in range(1, n + 1):
    for j in range(i, m - (n - i) + 1):
        for k in range(i - 1, j):
            if best[i - 1][k] == NEG: continue
            v = best[i - 1][k] + f1(" ".join(txt[k:j]), lines[i - 1])
            if v > best[i][j]: best[i][j] = v; bk[i][j] = k
cut = [m]; j = m
for i in range(n, 0, -1): j = bk[i][j]; cut.append(j)
cut = cut[::-1]; segs = []; rep = []
for i in range(n):
    g = range(cut[i], cut[i + 1]); segs.append([round(ch[g[0]][0], 3), round(ch[g[-1]][1], 3)])
    rep.append(dict(line=lines[i], heard=" ".join(txt[k] for k in g), f1=round(f1(" ".join(txt[k] for k in g), lines[i]), 2)))
json.dump({"chunks": [[round(a, 3), round(e, 3), t] for (a, e), t in zip(ch, txt)], "segs": segs, "method": "silencedetect -38 dB chunks, each transcribed (sherpa whisper turbo), DP grouping to script lines by word F1", "vo": wav, "check": rep},
          open(out, "w"), ensure_ascii=False, indent=1)
for s, r_ in zip(segs, rep): print(f"{s[0]:6.2f} to {s[1]:6.2f}  F1 {r_['f1']:.2f}  {r_['heard'][:70]}")
print("wrote", out, "| min F1", min(r_["f1"] for r_ in rep))
