# 5 world records Israel broke without even noticing

Account: @noamroz__ (Israel story). Length: about 45 s. Draft is silent; VO lines below are for Noam to record later.
Rule: every record below is on guinnessworldrecords.com or was confirmed by a GWR adjudicator in a named news report. Sources go on screen.

## Beat sheet

| # | Time | On screen (EN) | On screen (HE) | VO (Noam) |
|---|------|----------------|----------------|-----------|
| Hook | 0.0 to 3.5 | 5 world records Israel broke *without even noticing* | 5 שיאי עולם שישראל שברה בלי לשים לב | 5 world records Israel broke without even noticing. |
| 5 | 3.5 to 10.5 | Heaviest strawberry. 289 g. Kadima-Zoran, 12 Feb 2021. STILL OURS | התות הכבד בעולם | Number 5. The heaviest strawberry ever: 289 grams. Kadima-Zoran. That's heavier than any iPhone. Do not put it in your pocket. |
| 4 | 10.5 to 17.5 | Highest protein consumption (country). 128.6 g per person, per day. GWR data: 2006 | הכי הרבה חלבון לנפש בעולם | Number 4. Israel eats more protein per person than any country on Guinness's list. Hummus, schnitzel, cottage. We weren't trying. We were just hungry. |
| 3 | 17.5 to 24.5 | Largest Shabbat dinner. 2,226 diners. Tel Aviv port, 13 June 2014. LOST IT: Berlin 2,322 (2015), New York 2,761 | ארוחת השבת הגדולה בעולם | Number 3. Biggest Shabbat dinner ever: 2,226 people, Tel Aviv. A year later Berlin beat it. Then New York. Next time we book a bigger hangar. |
| 2 | 24.5 to 31.5 | Lowest town on Earth. Ein Bokek, 393.5 m below sea level. Also: lowest road, 393 m. NOBODY CAN TAKE IT | העיר הנמוכה בעולם | Number 2. Lowest town on Earth: Ein Bokek, Dead Sea. Our lowest achievement. Literally. And in my view, nobody's coming to take it. |
| 1 | 31.5 to 40.0 | The hummus war. Abu Ghosh, 8 Jan 2010: 4,090 kg (served in a satellite dish). Lebanon, 8 May 2010: 10,452 kg. STILL LEBANON'S | מלחמת החומוס | Number 1. The hummus war. 2010, Abu Ghosh makes 4 tons of hummus, in a satellite dish. Four months later Lebanon makes 10. In my view, the only war where everyone ends up full. Lebanon, respect. Rematch? |
| CTA | 40.0 to 45.0 | Which record should we break next? Comment RECORD 👇 | איזה שיא נשבור הבא? כתבו RECORD | Which record should we break next? Comment RECORD. |

Notes on tone: the hummus beat is friendly rivalry, a salute to Lebanon's chefs, no jabs at any people. "In my view" marks the two opinion lines. No soldiers beat: see "What I could not verify" below.

## Visual plan (house style, generic certificate, no Guinness logo or artwork)

Global: silver gradient background #F4F5F7 to #D9DDE3 with a soft white glow and slow floating silver sparkles. Top row: five small medals as a countdown tracker (current one large, gold, with its number). Centre: a white "WORLD RECORD" certificate (navy #163260 double border, thin blue #2A88D4 inner rule, gold corner diamonds, gold seal). Under it: the comic one-liner in navy, then a small source line in blue-grey. Status stamp on each certificate: green "STILL OURS" / red "LOST IT" / gold "STILL LEBANON'S".

- Hook: big trophy (gold cup, navy base) pops on frame 1 with the headline already fully on screen. Chip: "All real. Sources on screen."
- #5: red strawberry icon pops above the certificate; "289 g" counts up; a scale needle bounces; stamp STILL OURS.
- #4: protein plate icon (hummus bowl + drumstick); 128.6 g counts up; sub line "GWR data: 2006".
- #3: long table icon; 2,226 counts up, then a red LOST IT stamp slams and two rows slide in: Berlin 2015, 2,322 / New York, 2,761.
- #2: sea-level gauge icon with a blue water line and a pin dropping below zero; "-393.5 m" counts down; stamp NOBODY CAN TAKE IT.
- #1: two bowls race as bars: Abu Ghosh 4,090 kg (blue) grows, then Lebanon 10,452 kg (gold) grows past it; stamp STILL LEBANON'S; one-liner.
- CTA: big gold "Comment RECORD" pill with a bouncing navy arrow, HE line under it.

## Sources (on screen per beat, full list in caption)

1. Heaviest strawberry, 289 g, Ariel Chahi, Kadima-Zoran, 12 Feb 2021: https://www.guinnessworldrecords.com/news/2022/2/worlds-heaviest-strawberry-grown-in-israel-breaks-record-692512
2. Highest consumption of protein (country), Israel, 128.6 g per person per day, 2006: https://www.guinnessworldrecords.com/world-records/84561-highest-consumption-of-protein-country
3. Largest Shabbat dinner, 2,226, Tel Aviv, 13 June 2014: https://archive.israel21c.org/tel-aviv-sets-guinness-record-shabbat-dinner/ ; broken by Berlin 2,322 (2015): https://guinnessworldrecords.com/news/2015/8/record-breaking-shabbat-dinner-at-the-european-maccabi-games-is-shared-by-30-nati-390498 ; then New York 2,761: https://www.clevelandjewishnews.com/jta/new-york-city-sets-guinness-record-for-largest-ever-shabbat-dinner-with-2-800-at/article_a99cae75-7622-555f-bfe3-5b9af3dd7325.html
4. Lowest town, Ein Bokek, 393.5 m below sea level: https://www.guinnessworldrecords.com/world-records/65057-lowest-town ; Lowest road, 393 m: https://www.guinnessworldrecords.com/world-records/62915-lowest-road
5. Largest serving of hummus, 10,452 kg, Lebanon, 8 May 2010 (current): https://guinnessworldrecords.com/world-records/largest-serving-of-hummus ; Abu Ghosh 4,090 kg, Jan 2010: https://gulfnews.com/world/mena/latest-shot-in-hummus-war-israel-doubles-record-1.565318 and https://archive.israel21c.org/israel-resets-guinness-hummus-record/

## What I could not verify (kept out of the reel)

- Soldiers / IDF: no GWR record page found. Israel Hayom says Guinness listed Maj. Gen. David Laskov as the world's oldest serving soldier (served until he died in 1989, aged 85), but I found no GWR page or second source naming Guinness. A 1988 Detroit Jewish News piece only calls him "perhaps the oldest man still in active service with any army". Needs a GWR check before use.
- Largest falafel: the 2010 New York ball (an Israeli chef) was only "believed" to be a record; no GWR confirmation found.
- Kidney donors (Matnat Chaim, Jan 2026): reported as a record attempt after GWR resumed Israeli submissions on 15 Jan 2026; no GWR certificate found yet.
- Museums per capita: no solid source, dropped.
