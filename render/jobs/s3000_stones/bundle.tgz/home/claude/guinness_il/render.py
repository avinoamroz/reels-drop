"""Silent draft: 5 world records Israel broke without even noticing. Streams frames to ffmpeg (no PNGs).
usage: python3 render.py [--preview]"""
import sys, os, json, math, subprocess, random
sys.path.insert(0, "/home/claude/reelkit")
from kit import (W, H, FPS, ease, eob, ramp, lerp, hx, pop, St, sa, rr, line, circ, box, tx, font, is_he, QA, CUR,
                 surf2pil, sheet_of, DASHES)
import cairo
from PIL import Image

OUT = "/home/claude/guinness_il"
NAVY = hx("#163260"); BLUE = hx("#2A88D4"); GOLD = hx("#D9A93A"); GOLD2 = hx("#F3D27A"); SILV = hx("#B9C0CA")
WHITE = (1, 1, 1, 1); RED = hx("#D63A4A"); GREEN = hx("#1E9E62"); GREY = hx("#5B6B82")
def c255(col): return tuple(int(round(v * 255)) for v in col[:3]) + (255,)
N2, B2, G2, W2, R2, GR2, GY2 = map(c255, (NAVY, BLUE, GOLD, WHITE, RED, GREEN, GREY))

def T(c, s, sz, x, y, col=N2, a=1.0, sc=1.0, w=900, hl=B2, maxw=940, src=False):
    return tx(c, s, sz, x, y, w=w, col=col, a=a, sc=sc, hl=hl, shadow=False, maxw=maxw, src=src)

# ---------------------------------------------------------------- background
_sp = None
def background(c, t):
    global _sp
    g = cairo.LinearGradient(0, 0, W * 0.4, H); g.add_color_stop_rgb(0, *hx("#F4F5F7")[:3]); g.add_color_stop_rgb(1, *hx("#D9DDE3")[:3])
    c.set_source(g); c.paint()
    for k, (bx, by, br) in enumerate([(300, 520, 560), (820, 1350, 620)]):
        x = bx + 60 * math.sin(t * 0.25 + k * 2); y = by + 50 * math.cos(t * 0.3 + k)
        rg = cairo.RadialGradient(x, y, 0, x, y, br); rg.add_color_stop_rgba(0, 1, 1, 1, 0.75); rg.add_color_stop_rgba(1, 1, 1, 1, 0)
        c.set_source(rg); c.arc(x, y, br, 0, 2 * math.pi); c.fill()
    if _sp is None:
        R = random.Random(3); _sp = [(R.uniform(40, 1040), R.uniform(0, H), R.uniform(6, 13), R.uniform(14, 30), R.random() * 6) for _ in range(26)]
    for k, (x0, y0, r, sp, ph) in enumerate(_sp):
        y = (y0 - t * sp) % (H + 60) - 30; x = x0 + 14 * math.sin(t * 0.7 + k); tw = 0.5 + 0.5 * math.sin(t * 2 + ph)
        sa(c, SILV if k % 4 else GOLD, 0.35 + 0.35 * tw); c.save(); c.translate(x, y); c.rotate(math.pi / 4)
        c.rectangle(-r / 2, -r / 2, r, r); c.fill(); c.restore()

# ---------------------------------------------------------------- icons (drawn around 0,0, ~200 px box)
def trophy(c):
    g = cairo.LinearGradient(-90, 0, 90, 0); g.add_color_stop_rgb(0, *GOLD[:3]); g.add_color_stop_rgb(0.45, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
    for sx in (-1, 1):  # handles
        sa(c, GOLD); c.set_line_width(16); c.new_sub_path(); c.arc(sx * 78, -40, 38, math.pi / 2 if sx > 0 else -math.pi / 2, 3 * math.pi / 2 if sx > 0 else math.pi / 2)
        c.stroke()
    c.move_to(-90, -100); c.line_to(90, -100); c.curve_to(90, 10, 50, 40, 0, 40); c.curve_to(-50, 40, -90, 10, -90, -100); c.close_path()
    c.set_source(g); c.fill_preserve(); sa(c, hx("#B8862A")); c.set_line_width(4); c.stroke()
    box(c, -14, 38, 28, 40, 4, GOLD); box(c, -60, 76, 120, 26, 6, NAVY); box(c, -78, 100, 156, 30, 8, NAVY)
    circ(c, 0, -40, 26, WHITE, 0.9); T(c, "1", 40, 0, -38)
def medal(c, n, big=True):
    for sx, col in ((-1, BLUE), (1, NAVY)):
        c.move_to(sx * 10, -40); c.line_to(sx * 52, -120); c.line_to(sx * 18, -120); c.line_to(sx * -14, -40); c.close_path(); sa(c, col); c.fill()
    g = cairo.RadialGradient(-20, -20, 5, 0, 0, 70); g.add_color_stop_rgb(0, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
    c.arc(0, 0, 64, 0, 2 * math.pi); c.set_source(g); c.fill_preserve(); sa(c, hx("#B8862A")); c.set_line_width(5); c.stroke()
    circ(c, 0, 0, 48, WHITE, 0.0, stroke=hx("#FFFFFF", 0.8), sw=3)
    T(c, str(n), 70, 0, 3)
def strawberry(c):
    c.move_to(0, 95); c.curve_to(-95, 30, -90, -60, -40, -62); c.curve_to(-15, -64, 15, -64, 40, -62); c.curve_to(90, -60, 95, 30, 0, 95)
    g = cairo.LinearGradient(-80, -60, 80, 90); g.add_color_stop_rgb(0, *hx("#F04A5A")[:3]); g.add_color_stop_rgb(1, *hx("#B81E35")[:3]); c.set_source(g); c.fill()
    R = random.Random(5)
    for k in range(22):
        x = R.uniform(-60, 60); y = R.uniform(-45, 70)
        if abs(x) < 70 - (y + 45) * 0.45: c.save(); c.translate(x, y); c.scale(1, 1.6); c.arc(0, 0, 3.5, 0, 2 * math.pi); c.restore(); sa(c, GOLD2); c.fill()
    for a in range(5):
        ang = -math.pi / 2 + (a - 2) * 0.55; c.move_to(0, -62); c.line_to(55 * math.cos(ang - 0.25), -62 + 40 * math.sin(ang - 0.25) - 8)
        c.line_to(70 * math.cos(ang), -62 + 48 * math.sin(ang)); c.close_path(); sa(c, GREEN); c.fill()
    line(c, [(0, -70), (6, -100)], GREEN, 9)
def protein(c):
    c.save(); c.scale(1, 0.42); circ(c, 0, 150, 110, WHITE, stroke=SILV, sw=8); c.restore()
    c.move_to(-110, 40); c.curve_to(-100, 120, 100, 120, 110, 40); c.close_path(); sa(c, WHITE); c.fill_preserve(); sa(c, SILV); c.set_line_width(6); c.stroke()
    c.save(); c.scale(1, 0.35); circ(c, 0, 115, 104, hx("#EBCB8B")); circ(c, 0, 115, 40, hx("#C9A24E")); c.restore()
    circ(c, 0, 40, 9, GREEN); circ(c, 22, 34, 7, hx("#9C3A2A")); circ(c, -24, 36, 6, hx("#9C3A2A"))
    c.save(); c.translate(70, -40); c.rotate(-0.6)  # drumstick
    c.save(); c.scale(1.25, 1); circ(c, 0, 0, 42, hx("#C77A36")); c.restore(); box(c, 40, -9, 52, 18, 9, WHITE, stroke=SILV, sw=3)
    circ(c, 94, -12, 12, WHITE, stroke=SILV, sw=3); circ(c, 94, 12, 12, WHITE, stroke=SILV, sw=3); c.restore()
def table(c):
    box(c, -150, -10, 300, 26, 8, NAVY); box(c, -140, -16, 280, 10, 4, WHITE)
    for x in (-130, 120): box(c, x, 14, 12, 70, 3, NAVY)
    for k in range(5):
        x = -110 + k * 55; circ(c, x, -55, 18, BLUE if k % 2 else GOLD); box(c, x - 20, -38, 40, 34, 14, BLUE if k % 2 else GOLD)
    for x in (-60, 60): box(c, x - 6, -40, 12, 30, 3, WHITE, stroke=GOLD, sw=2); circ(c, x, -46, 5, GOLD)
def gauge(c, t):
    box(c, -150, -110, 300, 220, 28, WHITE, stroke=SILV, sw=5)
    sa(c, BLUE, 0.85); c.move_to(-146, -20)
    for k in range(30): c.line_to(-146 + k * 10, -20 + 6 * math.sin(k * 0.8 + t * 3))
    c.line_to(146, -20); c.line_to(146, 0); c.line_to(-146, 0); c.close_path(); c.fill()
    T(c, "0 m", 38, -95, -60, col=GY2)
    y = 70 + 6 * math.sin(t * 2.2)
    line(c, [(60, -10), (60, y - 18)], NAVY, 6); circ(c, 60, y, 18, RED, stroke=WHITE, sw=4)
def bowl(c, col):
    c.move_to(-90, -10); c.curve_to(-80, 70, 80, 70, 90, -10); c.close_path(); sa(c, col); c.fill()
    c.save(); c.scale(1, 0.3); circ(c, 0, -33, 90, hx("#EBCB8B")); c.restore(); circ(c, 0, -14, 8, GREEN)
def arrow_down(c):
    c.move_to(-26, -60); c.line_to(26, -60); c.line_to(26, 0); c.line_to(56, 0); c.line_to(0, 60); c.line_to(-56, 0); c.line_to(-26, 0); c.close_path()
    sa(c, NAVY); c.fill()
def icon(c, x, y, s, fn, *args, a=1.0):
    if a <= 0.01 or abs(s) < 1e-3: return
    c.save(); c.translate(x, y); c.scale(s, s); old = St.a; St.a *= a; fn(c, *args); St.a = old; c.restore()

# ---------------------------------------------------------------- certificate pieces
CX, CY0, CY1 = 540, 590, 1240
def certificate(c, t, t0):
    a, s = pop(t, t0 + 0.05, d=0.5, s0=0.6, bounce=1.3);
    if a <= 0.01: return a
    c.save(); c.translate(540, (CY0 + CY1) / 2 + 40 * (1 - s)); c.translate(-540, -(CY0 + CY1) / 2)
    old = St.a; St.a *= a
    x0, x1 = 80, 1000; h = CY1 - CY0
    sa(c, NAVY, 0.16); rr(c, x0 + 4, CY0 + 18, x1 - x0, h, 26); c.fill()
    box(c, x0, CY0, x1 - x0, h, 26, WHITE, stroke=NAVY, sw=7)
    rr(c, x0 + 20, CY0 + 20, x1 - x0 - 40, h - 40, 16); sa(c, BLUE); c.set_line_width(2.5); c.stroke()
    for (x, y) in ((x0 + 20, CY0 + 20), (x1 - 20, CY0 + 20), (x0 + 20, CY1 - 20), (x1 - 20, CY1 - 20)):
        c.save(); c.translate(x, y); c.rotate(math.pi / 4); sa(c, GOLD); c.rectangle(-11, -11, 22, 22); c.fill(); c.restore()
    T(c, "WORLD RECORD", 44, 540, CY0 + 68, col=B2, w=800)
    for sx in (-1, 1): line(c, [(540 + sx * 175, CY0 + 70), (540 + sx * 330, CY0 + 70)], GOLD, 4)
    St.a = old; c.restore(); return a
def stamp(c, t, t0, s, x, y, col, rot=-0.08, sz=50):
    if t < t0: return
    u = (t - t0) / 0.28; sc = 1.0 if u >= 1 else lerp(2.4, 1.0, ease(u)); a = ramp(t, t0, t0 + 0.12)
    f = font(sz, 900); tw = f.getlength(s); pw, ph = tw + 64, sz * 1.6
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc)
    box(c, -pw / 2, -ph / 2, pw, ph, 14, WHITE, a=0.92 * a, stroke=col, sw=7)
    c.restore()
    c.save(); c.translate(x, y); c.rotate(rot); T(c, s, sz, 0, 2, col=c255(col), a=a, sc=sc, maxw=880); c.restore()
def count(t, t0, d, v0, v1):
    return lerp(v0, v1, ease((t - t0) / d)) if t >= t0 else v0
def fmt(v, dec=0):
    return f"{v:,.{dec}f}"
def progress(c, t, n):
    for k in range(5, 0, -1):
        x = 540 + (5 - k - 2) * 130; y = 330
        if k == n: icon(c, x, y + 10, 0.62 + 0.03 * math.sin(t * 5), medal, k)
        elif k > n: circ(c, x, y, 30, GOLD, 0.9, stroke=WHITE, sw=4); T(c, str(k), 40, x, y + 2, col=W2)
        else: circ(c, x, y, 30, WHITE, 0.7, stroke=SILV, sw=4); T(c, str(k), 40, x, y + 2, col=GY2)
def oneliner(c, t, t0, lines, sz=54, t_out=None):
    fo = 1 - ramp(t, t_out, t_out + 0.25) if t_out else 1
    for k, s in enumerate(lines):
        a, sc = pop(t, t0 + 0.12 * k); T(c, s, sz, 540, 1290 + 62 * k, a=a * fo, sc=sc)
def source(c, t, t0, s):
    a = ramp(t, t0, t0 + 0.3); T(c, s, 36, 540, 1418, col=GY2, a=a, w=700, src=True, maxw=940)

# ---------------------------------------------------------------- scenes
SC = []
def add(t0, t1, fn, **kw): SC.append(dict(t0=t0, t1=t1, fn=fn, **kw))

def hook(c, t, sc):
    icon(c, 540, 520 + 8 * math.sin(t * 2.5), 1.45, trophy)
    T(c, "5 world records", 116, 540, 800); T(c, "Israel broke", 116, 540, 930)
    T(c, "*without even noticing*", 84, 540, 1050, hl=B2)
    T(c, "5 שיאי עולם שישראל שברה", 60, 540, 1150); T(c, "בלי לשים לב", 60, 540, 1220)
    a, s = pop(t, 0.9); box_chip(c, "All real. Sources on screen.", 46, 540, 1340, NAVY, a, s)
def box_chip(c, s, sz, x, y, bg, a=1.0, sc=1.0, fg=W2):
    if a <= 0.01: T(c, s, sz, -5000, -5000, a=0); return
    f = font(sz, 800); pw = f.getlength(s) + sz * 1.2; ph = sz * 1.55
    c.save(); c.translate(x, y); c.scale(sc, sc); box(c, -pw / 2, -ph / 2, pw, ph, ph / 2, bg, a); c.restore()
    T(c, s, sz, x, y + 2, col=fg, a=a, sc=sc, w=800)

def rec(c, t, sc):
    t0 = sc["t0"]; progress(c, t, sc["n"])
    a, s = pop(t, t0 + 0.25, d=0.5); icon(c, 540, 470, 0.95 * s, sc["ic"], *sc.get("args", lambda t: ())(t), a=a)
    if certificate(c, t, t0) < 0.5: return
    for k, ln in enumerate(sc["title"]):
        a, s = pop(t, t0 + 0.35 + 0.08 * k); T(c, ln, 62, 540, CY0 + 150 + 72 * k, a=a, sc=s)
    yh = CY0 + 150 + 72 * len(sc["title"]) + 2
    a, s = pop(t, t0 + 0.55); T(c, sc["he"], 52, 540, yh, a=a, sc=s, col=B2)
    sc["body"](c, t, sc, yh)

def strawberry_body(c, t, sc, yh):
    t0 = sc["t0"]; v = count(t, t0 + 0.8, 1.2, 0, 289)
    if t >= t0 + 0.8: T(c, f"{fmt(v)} g", 150, 540, yh + 135, col=B2)
    a = ramp(t, t0 + 2.0, t0 + 2.3); T(c, "Kadima-Zoran, 12 Feb 2021", 44, 540, yh + 245, a=a, w=700, col=GY2)
    stamp(c, t, t0 + 2.6, "STILL OURS", 540, yh + 335, GREEN)
    oneliner(c, t, t0 + 3.4, ["Heavier than any iPhone.", "Don't put it in your pocket."])
    source(c, t, t0 + 1.0, "Source: guinnessworldrecords.com (news, Feb 2022)")
def protein_body(c, t, sc, yh):
    t0 = sc["t0"]; v = count(t, t0 + 0.8, 1.2, 0, 128.6)
    if t >= t0 + 0.8: T(c, f"{fmt(v, 1)} g", 124, 540, yh + 100, col=B2)
    a = ramp(t, t0 + 2.0, t0 + 2.3); T(c, "per person, per day (GWR data: 2006)", 42, 540, yh + 192, a=a, w=700, col=GY2)
    stamp(c, t, t0 + 2.6, "ISRAEL, No.1", 540, yh + 272, GREEN)
    oneliner(c, t, t0 + 3.4, ["Hummus. Schnitzel. Cottage.", "We weren't trying. We were hungry."])
    source(c, t, t0 + 1.0, "Source: GWR, Highest protein consumption (country)")
def shabbat_body(c, t, sc, yh):
    t0 = sc["t0"]; v = count(t, t0 + 0.7, 1.0, 0, 2226); lost = t0 + 2.4
    sh = ramp(t, lost + 0.3, lost + 0.7)
    if t >= t0 + 0.7: T(c, fmt(v), lerp(150, 96, sh), 540, yh + lerp(120, 85, sh), col=B2)
    a = ramp(t, t0 + 1.6, t0 + 1.9) * (1 - sh); T(c, "diners, Tel Aviv port, 13 June 2014", 42, 540, yh + 230, a=a, w=700, col=GY2)
    for k, (who, n) in enumerate([("Berlin, 2015", "2,322"), ("New York", "2,761")]):
        a, s = pop(t, lost + 0.6 + 0.35 * k)
        if a > 0.01:
            y = yh + 175 + 72 * k
            T(c, who, 50, 330, y, a=a, sc=s, w=800, col=GY2); T(c, n, 58, 760, y, a=a, sc=s, col=R2)
    stamp(c, t, lost, "LOST IT", 540, yh + 330, RED, rot=-0.06, sz=54)
    oneliner(c, t, t0 + 4.0, ["Next time,", "we book a bigger hangar."])
    source(c, t, t0 + 1.0, "Sources: israel21c.org, GWR news Aug 2015, JTA")
def lowest_body(c, t, sc, yh):
    t0 = sc["t0"]; v = count(t, t0 + 0.8, 1.2, 0, 393.5)
    if t >= t0 + 0.8: T(c, f"{fmt(v, 1)} m", 140, 540, yh + 125, col=B2)
    a = ramp(t, t0 + 2.0, t0 + 2.3); T(c, "below sea level. Ein Bokek, Dead Sea", 42, 540, yh + 232, a=a, w=700, col=GY2)
    stamp(c, t, t0 + 2.6, "NOBODY CAN TAKE IT", 540, yh + 325, GREEN, sz=46)
    oneliner(c, t, t0 + 3.4, ["Our lowest achievement.", "*Literally.*"])
    source(c, t, t0 + 1.0, "Source: GWR, Lowest town (also: Lowest road, 393 m)")
def hummus_body(c, t, sc, yh):
    t0 = sc["t0"]; L = t0 + 2.6
    rows = [("Abu Ghosh, Jan 2010", 4090, BLUE, t0 + 0.8), ("Lebanon, May 2010", 10452, GOLD, L)]
    for k, (who, kg, col, ts) in enumerate(rows):
        if t < ts - 0.05: continue
        y = yh + 70 + 120 * k; u = ease((t - ts) / 1.1); full = 760 * kg / 10452
        a = ramp(t, ts - 0.05, ts + 0.15)
        T(c, who, 44, 540, y, a=a, w=800, col=GY2)
        bw = max(30, full * u); box(c, 160, y + 32, bw, 46, 23, col, a)
        T(c, f"{fmt(kg * u)} kg", 48, min(800, 160 + bw + 115), y + 56, a=a, col=c255(col) if col is not BLUE else B2)
    a = ramp(t, t0 + 1.6, t0 + 1.9); T(c, "(served in a satellite dish)", 38, 540, yh + 290, a=a, w=700, col=GY2)
    stamp(c, t, L + 1.4, "STILL LEBANON'S", 540, yh + 375, GOLD, sz=48)
    oneliner(c, t, t0 + 4.6, ["In my view, the only war", "where everyone ends up full."], t_out=t0 + 6.9)
    a, s = pop(t, t0 + 7.1); T(c, "Lebanon, respect. *Rematch?*", 60, 540, 1330, a=a, sc=s, hl=c255(GOLD))
    source(c, t, t0 + 1.0, "Sources: GWR (Largest serving of hummus), Gulf News")
def cta(c, t, sc):
    t0 = sc["t0"]
    a, s = pop(t, t0 + 0.05); T(c, "Which record should", 96, 540, 560, a=a, sc=s)
    a, s = pop(t, t0 + 0.15); T(c, "we break next?", 96, 540, 675, a=a, sc=s)
    a, s = pop(t, t0 + 0.5, bounce=2.4)
    if a > 0.01:
        f = font(92, 900); pw = f.getlength("Comment RECORD") + 110; ph = 150
        c.save(); c.translate(540, 900); c.scale(s, s)
        g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *GOLD[:3]); g.add_color_stop_rgb(0.5, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
        rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, NAVY); c.set_line_width(6); c.stroke(); c.restore()
        T(c, "Comment *RECORD*", 92, 540, 902, a=a, sc=s, hl=W2)
    icon(c, 540, 1090 + 18 * math.sin(t * 7), 0.9, arrow_down, a=ramp(t, t0 + 0.8, t0 + 1.0))
    a, s = pop(t, t0 + 0.9); T(c, "איזה שיא נשבור הבא? כתבו RECORD", 60, 540, 1250, a=a, sc=s, col=B2)
    a = ramp(t, t0 + 1.4, t0 + 1.7); T(c, "Every record here is real. Sources in the caption.", 38, 540, 1400, a=a, w=700, col=GY2, src=True)

add(0.0, 3.5, hook)
add(3.5, 10.5, rec, n=5, ic=strawberry, title=["Heaviest strawberry"], he="התות הכבד בעולם", body=strawberry_body)
add(10.5, 17.5, rec, n=4, ic=protein, title=["Highest protein", "consumption (country)"], he="הכי הרבה חלבון לנפש בעולם", body=protein_body)
add(17.5, 24.5, rec, n=3, ic=table, title=["Largest Shabbat dinner"], he="ארוחת השבת הגדולה בעולם", body=shabbat_body)
add(24.5, 31.5, rec, n=2, ic=gauge, args=lambda t: (t,), title=["Lowest town on Earth"], he="העיר הנמוכה בעולם", body=lowest_body)
add(31.5, 40.0, rec, n=1, ic=bowl, args=lambda t: (GOLD,), title=["Largest serving of hummus"], he="מלחמת החומוס", body=hummus_body)
add(40.0, 45.0, cta)
T_END = 45.0

def draw_frame(c, t):
    CUR["t"] = t; background(c, t)
    for i, sc in enumerate(SC):
        if t < sc["t0"] - 0.01 or t > sc["t1"] + 0.25: continue
        al = (1.0 if i == 0 else ramp(t, sc["t0"], sc["t0"] + 0.2)) * (1 - ramp(t, sc["t1"], sc["t1"] + 0.22))
        if i == len(SC) - 1: al = ramp(t, sc["t0"], sc["t0"] + 0.2)
        if al <= 0.01: continue
        CUR["scene"] = i; St.a = al; sc["fn"](c, t, sc); St.a = 1.0
    CUR["scene"] = None

def qa_issues():
    iss = []
    for sc_, s, sz, x0, y0, x1, y1, src in QA["text"]:
        if x0 < 0: continue  # local-coordinate (translated) text
        if sz < 36: iss.append(("small", s, sz))
        if x0 < 70 - 1 or x1 > 1010 + 1: iss.append(("x safe", s, round(x0), round(x1)))
        if y0 < 230 or y1 > 1450: iss.append(("y safe", s, round(y0), round(y1)))
        if any(d in s for d in DASHES): iss.append(("dash", s))
    return sorted(set(map(tuple, iss)))

if __name__ == "__main__":
    os.nice(5)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    mids = [0.0] + [sc["t0"] + 0.85 * (sc["t1"] - sc["t0"]) for sc in SC] + [4.2, 21.1, 34.0, 36.5]
    mids = sorted(set(round(x, 2) for x in mids))
    if "--preview" in sys.argv:
        th = []
        for t in mids: draw_frame(c, t); th.append((t, surf2pil(surf)))
        sheet_of(th, "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/gw_prev.png")
        print(qa_issues()); sys.exit()
    N = int(T_END * FPS); out = f"{OUT}/guinness_draft.mp4"
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
           "-c:v", "libx264", "-preset", "medium", "-crf", "21", "-maxrate", "2M", "-bufsize", "4M", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); tset = {int(round(x * FPS)): x for x in mids}; th = []
    for fi in range(N):
        t = fi / FPS; draw_frame(c, t); surf.flush(); p.stdin.write(surf.get_data())
        if fi in tset: th.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 300 == 0: print("frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0
    sheet_of(th, f"{OUT}/qa_sheet.png")
    timing = {"file": "guinness_draft.mp4", "fps": FPS, "size": [W, H], "duration_s": T_END, "audio": "none (silent draft)",
              "beats": [{"id": ["hook", "#5 strawberry", "#4 protein", "#3 shabbat dinner", "#2 lowest town", "#1 hummus", "cta"][i],
                         "start": sc["t0"], "end": sc["t1"], "dur": round(sc["t1"] - sc["t0"], 2)} for i, sc in enumerate(SC)],
              "qa_issues": qa_issues()}
    json.dump(timing, open(f"{OUT}/timing.json", "w"), indent=1, ensure_ascii=False); print("issues", timing["qa_issues"])
