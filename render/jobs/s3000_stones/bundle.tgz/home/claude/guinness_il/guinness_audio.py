"""Guinness v2 audio: original procedural celebratory music bed + synthesised SFX, plus one CC0 Kenney glass ding.
Helpers (filters, room, mix/loudnorm) copied from /home/claude/island_israel/journey_audio.py and
/home/claude/silly_maps/audio_v2.py (copied, not moved). Everything float64 at 48 kHz.
Music: bright premium pop bed in D, 112 BPM (Dadd9, A6sus, Bm7, Gmaj9): warm pad, Karplus-Strong pluck arpeggio,
bass, kick/clap/shaker, glock sparkle. On the beach beat the bed swells: pad filter opens, a string layer and a
riser + soft cymbal come in, gain up about 4 dB. Ducked under the voice."""
import numpy as np, subprocess, json
from scipy.signal import butter, sosfilt, fftconvolve, lfilter

SR = 48000
rng = np.random.default_rng(23)
KEN_DING = "/home/claude/guinness_il/sfx_src/glass_001.wav"
def bp(x, lo, hi, o=2): return sosfilt(butter(o, [lo, hi], "bp", fs=SR, output="sos"), x)
def lp(x, f, o=2): return sosfilt(butter(o, f, "lp", fs=SR, output="sos"), x)
def hp(x, f, o=2): return sosfilt(butter(o, f, "hp", fs=SR, output="sos"), x)
def norm(x, peak=1.0): return x / (np.abs(x).max() + 1e-12) * peak
def tt(d): return np.arange(int(d * SR)) / SR
def env(n, a, r):
    t = np.arange(n) / SR; d = n / SR; return np.minimum(1, t / max(a, 1e-4)) * np.minimum(1, (d - t) / max(r, 1e-4))
def load(path):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)
def room(x, t60=0.6, mix=0.2, seed=3):
    r = np.random.default_rng(seed); n = int(t60 * SR); ir = r.standard_normal(n) * np.exp(-6.9 * np.arange(n) / n)
    ir = lp(ir, 4500); ir /= np.sqrt((ir ** 2).sum()); y = fftconvolve(x, ir)[:len(x)]; return x * (1 - mix) + y * mix
def saw(ph): return 2 * ((ph / (2 * np.pi)) % 1.0) - 1
def hz(m): return 440 * 2 ** ((m - 69) / 12)

# ------------------------------------------------------------------ SFX
def trophy_ding():
    """Kenney CC0 glass ding layered with a short synthesised bell (inharmonic partials) for a 'trophy' shine"""
    g = load(KEN_DING); t = tt(1.4); f = hz(88)
    bell = sum(a * np.sin(2 * np.pi * f * k * t) * np.exp(-t * dcy) for k, a, dcy in ((1, 1, 3.2), (2.76, 0.35, 7), (5.4, 0.15, 12), (0.5, 0.25, 4)))
    bell *= np.minimum(1, t / 0.002); y = np.zeros(len(t)); y[:len(g)] += norm(g) * 0.9; y += 0.55 * norm(bell)
    return norm(room(y, 0.9, 0.18))
def stamp_thunk():
    """rubber stamp hitting paper on a desk: low body thump + paper slap + tiny wood knock"""
    t = tt(0.45); body = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-t * 30) + 58) / SR) * np.exp(-t * 22)
    slap = bp(rng.standard_normal(len(t)), 400, 3200) * np.exp(-t * 70)
    knock = np.sin(2 * np.pi * 420 * t) * np.exp(-t * 55) * 0.3
    return norm(room(1.0 * body + 0.7 * slap + knock, 0.25, 0.12))
def crowd_cheer(d=3.2, voices=26):
    """crowd 'yay' + applause: formant-filtered rising vowel voices and dense hand claps, all synthesised"""
    t = tt(d); u = t / d; out = np.zeros(len(t))
    for v in range(voices):
        r = np.random.default_rng(300 + v); f0 = r.uniform(150, 330); on = r.uniform(0, 0.35); dv = r.uniform(1.0, 2.2)
        w = np.clip((t - on) / dv, 0, 1); a = np.sin(np.pi * w) ** 0.7 * (t >= on)
        f = f0 * (1 + 0.35 * np.minimum(1, (t - on).clip(0) / 0.25)) * (1 + 0.01 * np.sin(2 * np.pi * r.uniform(4, 7) * t))
        src = saw(2 * np.pi * np.cumsum(f) / SR) + 0.25 * r.standard_normal(len(t))
        F1, F2 = ((730, 1090), (660, 1700), (570, 840))[v % 3]
        y = bp(src, F1 * 0.8, F1 * 1.25) + 0.6 * bp(src, F2 * 0.85, F2 * 1.2)
        out += norm(y * a) * r.uniform(0.4, 1.0)
    clap = np.zeros(len(t))
    for i in rng.integers(0, len(t) - 2000, int(d * 70)):
        m = int(0.018 * SR); clap[i:i + m] += bp(rng.standard_normal(m), 900, 5000) * np.exp(-np.arange(m) / SR * 220) * rng.uniform(0.3, 1)
    whistle = np.sin(2 * np.pi * np.cumsum(1900 + 500 * np.minimum(1, t / 0.35)) / SR) * env(len(t), 0.05, 0.1) * (t < 0.9) * 0.12
    x = norm(lp(out, 4200)) + 0.8 * norm(clap) * np.minimum(1, t / 0.15) + whistle
    return norm(room(x * env(len(t), 0.06, 1.4), 1.1, 0.3))
def candle_whoosh(d=1.4):
    """soft match-strike/candle whoosh: band-passed noise sweeping up then settling, panned left to right"""
    t = tt(d); u = t / d; nz = rng.standard_normal(len(t))
    a = np.exp(-((u - 0.35) / 0.22) ** 2)
    y = 0.0
    for c in (500, 800, 1300, 2100, 3400):
        w = np.exp(-((np.log((600 + 2400 * np.sin(np.pi * np.minimum(1, u * 1.4)) ** 2) / c)) / 0.5) ** 2); y = y + w * bp(nz, c / 1.4, c * 1.4)
    x = norm(lp(y, 5000) * a) + 0.25 * norm(lp(nz, 250)) * a
    pan = np.clip(u * 1.6 - 0.8, -0.8, 0.8)
    return np.stack([x * (1 - pan) / 2, x * (1 + pan) / 2]) * 2

# ------------------------------------------------------------------ music
def pluck(f, d=0.6, bright=0.5, seed=0):
    """Karplus-Strong pluck (copied from silly_maps/audio_v2.py, vectorised per period)"""
    r = np.random.default_rng(seed); N = max(2, int(SR / f)); n = int(d * SR); a = 0.5 * (1 + bright) * 0.5 + 0.25
    buf = r.uniform(-1, 1, N) * np.hanning(N) ** 0.3; out = np.zeros(n)
    for i in range(0, n, N):
        k = min(N, n - i); out[i:i + k] = buf[:k]; buf = 0.996 * (a * buf + (1 - a) * np.roll(buf, -1))
    t = np.arange(n) / SR; return out * np.exp(-t * 4.5) * np.minimum(1, t / 0.002)
_pc = {}
def pz(m, d=0.6, bright=0.5):
    k = (m, d, bright)
    if k not in _pc: _pc[k] = pluck(hz(m), d, bright, seed=m)
    return _pc[k]
def glock(m, d=1.2):
    f = hz(m); t = tt(d)
    return (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 9)) * np.exp(-t * 3.5) * np.minimum(1, t / 0.002)
def music(dur, swell=(None, None), seed=5, end_ring=2.0):
    r = np.random.default_rng(seed); n = int(dur * SR); L = np.zeros(n); R = np.zeros(n)
    bpm = 112; beat = 60 / bpm; bar = 4 * beat; nb = int(dur / bar) + 2; s0, s1 = swell
    prog = [(38, [62, 64, 66, 69]), (33, [61, 64, 66, 69]), (35, [62, 66, 69, 73]), (31, [62, 66, 69, 71])]  # Dadd9 A6 Bm7(add11) Gmaj9
    def put(sig, st, g, pan=0.0):
        i = int(st * SR)
        if i >= n or i < 0: return
        j = min(n, i + len(sig)); L[i:j] += g * (1 - pan) * sig[:j - i]; R[i:j] += g * (1 + pan) * sig[:j - i]
    mel = [78, None, 81, 78, 76, None, 74, 76, 78, None, 83, 81, 78, None, 76, None]
    for b in range(nb):
        root, ch = prog[b % 4]; st = b * bar
        sw = 0.0 if s0 is None else float(np.clip((st - s0 + bar) / (2 * bar), 0, 1)) * (1.0 if s1 is None or st < s1 + bar else 0.6)
        inten = min(1.0, 0.55 + 0.25 * b)
        tp = tt(bar + 0.6)
        pad = sum(sum(saw(2 * np.pi * hz(m) * (1 + dt) * tp + r.uniform(0, 6)) for dt in (-0.005, 0.005)) for m in ch)
        pad = lp(pad, 1300 + 1900 * sw, 2) * np.minimum(1, tp / 0.5) * np.minimum(1, (bar + 0.6 - tp) / 0.6); put(pad, st, 0.016 * (1 + 0.6 * sw))
        if sw > 0:  # string layer an octave up, slow attack
            strg = sum(saw(2 * np.pi * hz(m + 12) * (1 + dt) * tp + r.uniform(0, 6)) for m in ch[1:] for dt in (-0.003, 0.0, 0.003))
            strg = lp(strg, 3200, 2) * np.minimum(1, tp / 1.0) * np.minimum(1, (bar + 0.6 - tp) / 0.6) * (1 + 0.05 * np.sin(2 * np.pi * 5.5 * tp))
            put(strg, st, 0.008 * sw)
        for off, mm in ((0, root), (1.5, root), (2, root + 7), (3, root + 12)):
            tb = tt(beat * 0.95); bs = (np.sin(2 * np.pi * hz(mm) * tb) + 0.3 * np.sin(4 * np.pi * hz(mm) * tb)) * env(len(tb), 0.006, 0.12)
            put(bs, st + off * beat, 0.24 * inten)
        pat = [0, 2, 3, 2, 1, 3, 2, 3]
        for q in range(8):
            m = ch[pat[q]] + 12; put(pz(m, 0.45, 0.6), st + q * beat / 2, 0.11 * inten, pan=0.28 * (1 if q % 2 else -1))
        if b >= 2:
            ph = mel[(b % 2) * 8:(b % 2) * 8 + 8]
            for q, m in enumerate(ph):
                if m is not None: put(glock(m, 0.9), st + q * beat / 2, 0.035 * (1 + 0.5 * sw), pan=-0.2)
        if b >= 1:
            for q in range(4):
                td = tt(0.3); f = 100 * np.exp(-td * 20) + 50
                put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-td * 13), st + q * beat, (0.34 if q % 2 == 0 else 0.22) * inten)
            for q in (1, 3):
                m = int(0.16 * SR); c = sum(bp(r.standard_normal(m), 1000, 4500) * np.exp(-np.arange(m) / SR * 35) * (np.arange(m) >= int(k * 0.008 * SR)) for k in range(3))
                put(room(c, 0.5, 0.3), st + q * beat, 0.07)
            for q in range(16):
                m = int(0.04 * SR); nz = hp(r.standard_normal(m), 6500) * np.exp(-np.arange(m) / SR * 85)
                put(nz, st + q * beat / 4, 0.022 if q % 2 else 0.036, pan=0.35)
    if s0 is not None:   # riser into the swell + soft cymbal on arrival
        dr = 2.2; tr = tt(dr); nz = rng.standard_normal(len(tr)); u = tr / dr
        ris = hp(nz, 2000) * u ** 2.5 + 0.4 * bp(nz, 600, 3000) * u ** 2; put(norm(ris), s0 - dr, 0.10)
        tc = tt(3.0); cy = hp(rng.standard_normal(len(tc)), 4500) * np.exp(-tc * 1.6) * np.minimum(1, tc / 0.004); put(norm(room(cy, 1.5, 0.4)), s0, 0.09)
    x = np.stack([L, R]); x = np.stack([room(x[0], 1.1, 0.2, 1), room(x[1], 1.1, 0.2, 2)])
    fade = np.minimum(1, np.arange(n) / (0.3 * SR)) * np.minimum(1, (n - np.arange(n)) / (end_ring * SR))
    return x * fade / (np.abs(x).max() + 1e-9)

# ------------------------------------------------------------------ mix (journey_audio.mix with a gain curve for the swell)
def act_rms(x, sr=SR):
    n = int(0.05 * sr); e = np.array([np.sqrt((x[i:i + n] ** 2).mean()) for i in range(0, len(x) - n, n)]); th = e.max() * 10 ** (-30 / 20)
    return np.sqrt((e[e > th] ** 2).mean())
def mix(vo, dur, events, out_wav, swell=(None, None), music_db=-17.0, sfx_db=-11.0, swell_db=4.0, tp=-1.5):
    n = int(dur * SR); v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]
    vr = act_rms(v); m = music(dur, swell)
    e2 = lfilter([1], [1, -0.9995], v ** 2) * 0.0005; envv = np.sqrt(np.maximum(e2, 0)); envv = np.convolve(envv, np.ones(4800) / 4800, "same")
    sp = np.clip(envv / (np.percentile(envv[envv > 0], 75) + 1e-9), 0, 1)
    duck = 10 ** ((-7.0 * sp) / 20)
    tq = np.arange(n) / SR; s0, s1 = swell
    gcurve = np.ones(n) if s0 is None else 10 ** (swell_db * np.clip((tq - (s0 - 1.0)) / 1.5, 0, 1) * (1 - 0.5 * np.clip((tq - s1) / 1.5, 0, 1)) / 20)
    mr = act_rms(m.mean(0)); m = m * (vr * 10 ** (music_db / 20) / mr) * duck * gcurve
    S = np.zeros((2, n)); rep = []
    for t0, x, xdb in events:
        x = np.atleast_2d(x); x = np.vstack([x, x]) if x.shape[0] == 1 else x
        g = vr * 10 ** ((sfx_db + xdb) / 20) / (act_rms(x.mean(0)) + 1e-12); i = int(t0 * SR); j = min(n, i + x.shape[1])
        if j > i: S[:, i:j] += x[:, :j - i] * g; rep.append(round(t0, 2))
    y = np.stack([v, v]) + m + S
    raw = y.T.astype(np.float32).tobytes()
    meas = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af",
                           f"loudnorm=I=-14:TP={tp}:LRA=11:print_format=json", "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
    J = json.loads(meas[meas.rfind("{"):meas.rfind("}") + 1])
    af = (f"loudnorm=I=-14:TP={tp}:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
          f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af, "-ar", "48000", "-c:a", "pcm_s16le", out_wav], input=raw, capture_output=True)
    assert r.returncode == 0, r.stderr.decode()[-400:]
    return {"input_I": J["input_i"], "sfx_at": rep}
