"""Growth reel narration: drop the broken first take, deeper voice, clean, 1.1x, reassemble lines with natural gaps.
out: vo/vo.wav (48 kHz mono) + vo/segs.json (one [start,end] per script line) + vo/segs_full.json (chunks remapped)"""
import json, subprocess, os, sys, shutil, numpy as np, soundfile as sf
D = "/home/claude/growth/vo"; SR = 48000; TEMPO = 1.1
J = json.load(open(f"{D}/asr.json")); SEG = [list(s) for s in J["segs"]]; CH = J["chunks"]
SEG[0][0] = 3.429                      # broken first take 0.00 to 2.95 dropped
CH = [c for c in CH if c[0] >= 3.4]
# 1. pitch -0.5 st (formants kept) + bass, on the whole take (timing unchanged)
os.makedirs(f"{D}/c_in", exist_ok=True); os.makedirs(f"{D}/c_out", exist_ok=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/c_in/full.wav"], check=True)
# 2. clean (length kept)
subprocess.run(["nice", "-n", "15", "python3", "/home/claude/vo_new/clean_vo.py", f"{D}/c_in", f"{D}/c_out", "--report"], check=True)
# 3. speed up 1.1x
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/c_out/full.wav", "-af", f"atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/fast.wav"], check=True)
x, sr = sf.read(f"{D}/fast.wav"); assert sr == SR
# 4. reassemble: each line cut with small margins, then placed with chosen gaps
WORDS = [5, 5, 7, 4, 7, 6, 8, 8, 8, 6, 7, 9, 7, 11, 9, 4, 8]            # English words on each line's card
GAP = {i: 0.55 for i in range(17)}
for i in (4, 6, 11, 12, 14, 16): GAP[i - 1] = 0.85                       # longer breath before a new section (gap after line i-1)
GAP[15] = 1.7                                                            # the calm silent beat after "Silence is part of it."
LEAD = 0.3
pieces = []; segs = []; orig = []; prev_en = None
for i, (a, b) in enumerate(SEG):
    pa = SEG[i - 1][1] if i else a - 0.3; nb = SEG[i + 1][0] if i < 16 else b + 0.5
    a0 = max(a - 0.08, (pa + a) / 2) if i else a - 0.06; b0 = min(b + 0.15, (b + nb) / 2)
    s = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f)
    st = LEAD if i == 0 else prev_en + GAP[i - 1]; t = st - (a - a0) / TEMPO; en = t + (b - a0) / TEMPO; prev_en = en
    pieces.append((t, s)); segs.append([st, en]); orig.append((a0, t))
# pad so every card gets its guideline minimum (card k on screen from seg_k start - 0.12 to seg_k+1 start - 0.12)
for k in range(16):
    need = max(3.0, WORDS[k] / 3 + 1) + 0.15
    span = segs[k + 1][0] - (0 if k == 0 else segs[k][0])
    if span < need:
        add = need - span; print("pad line", k + 1, round(add, 2))
        for j in range(k + 1, 17):
            segs[j][0] += add; segs[j][1] += add; pieces[j] = (pieces[j][0] + add, pieces[j][1]); orig[j] = (orig[j][0], orig[j][1] + add)
T_END = segs[-1][1] + 2.0
y = np.zeros(int(T_END * SR) + SR)
for t0, s in pieces: i = int(t0 * SR); y[i:i + len(s)] += s
y = y[:int(T_END * SR)]
sf.write(f"{D}/vo.wav", y.astype(np.float32), SR, subtype="FLOAT")
segs = [[round(a, 3), round(b, 3)] for a, b in segs]
json.dump({"segs": segs, "vo": f"{D}/vo.wav", "tempo": TEMPO, "lead": LEAD, "dropped": "raw 0.00 to 3.43 (broken first take)"}, open(f"{D}/segs.json", "w"), indent=1)
# chunk times remapped to the new timeline (for animation cues)
def remap(tt):
    k = max(i for i in range(17) if SEG[i][0] - 0.2 <= tt or i == 0)
    a0, t0 = orig[k]; return round(t0 + (tt - a0) / TEMPO, 3)
chunks = [[remap(c[0]), remap(c[1]), c[2]] for c in CH]
json.dump({"chunks": chunks, "segs": segs}, open(f"{D}/segs_full.json", "w"), indent=1, ensure_ascii=False)
shutil.rmtree(f"{D}/c_in"); os.remove(f"{D}/fast.wav")
print("vo", round(len(y) / SR, 2), "s; segs", segs)
