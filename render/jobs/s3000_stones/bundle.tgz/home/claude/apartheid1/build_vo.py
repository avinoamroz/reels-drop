"""Apartheid reels narration (shared by part 1 and 2): deeper voice (pitch 0.9715 formant kept, bass), clean_vo, atempo 1.1,
reassemble lines with chosen gaps, 0.3 s lead. Same chain as /home/claude/growth/build_vo.py (no takes dropped: ASR F1 1.00 / 0.98).
usage: build_vo.py PART   ->  apartheidN/vo/vo.wav, segs.json, segs_full.json"""
import json, subprocess, os, sys, shutil, numpy as np, soundfile as sf
P = sys.argv[1]; D = f"/home/claude/apartheid{P}/vo"; SR = 48000; TEMPO = 1.1; LEAD = 0.3
J = json.load(open(f"{D}/asr.json")); SEG = [list(s) for s in J["segs"]]; CH = J["chunks"]; NL = len(SEG)
if P == "1":
    WORDS = [5, 10, 12, 10, 12, 12, 8, 10, 8, 10]
    LONG = (2, 3, 4, 5, 6, 9)                 # longer breath before these lines (new section)
    EXTRA = {3: 0.35, 8: 0.25}; LONGGAP = 0.72; TAIL = 2.2                  # a held beat before "South Africa" (checklist built) and before the verdict
else:
    WORDS = [7, 10, 10, 10, 10, 10, 6, 9]
    LONG = (1, 2, 3, 4, 5, 6, 7)
    EXTRA = {6: 0.4}; LONGGAP = 0.85; TAIL = 2.5
GAP = {i: 0.55 for i in range(NL)}
for i in LONG: GAP[i - 1] = LONGGAP
for i, e in EXTRA.items(): GAP[i - 1] += e
os.makedirs(f"{D}/c_in", exist_ok=True); os.makedirs(f"{D}/c_out", exist_ok=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/c_in/full.wav"], check=True)
subprocess.run(["nice", "-n", "15", "python3", "/home/claude/vo_new/clean_vo.py", f"{D}/c_in", f"{D}/c_out", "--report"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/c_out/full.wav", "-af", f"atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/fast.wav"], check=True)
x, sr = sf.read(f"{D}/fast.wav"); assert sr == SR
pieces = []; segs = []; orig = []; prev_en = None
for i, (a, b) in enumerate(SEG):
    pa = SEG[i - 1][1] if i else a - 0.3; nb = SEG[i + 1][0] if i < NL - 1 else b + 0.5
    a0 = max(a - 0.08, (pa + a) / 2) if i else max(0, a - 0.06); b0 = min(b + 0.15, (b + nb) / 2)
    s = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f)
    st = LEAD if i == 0 else prev_en + GAP[i - 1]; t = st - (a - a0) / TEMPO; en = t + (b - a0) / TEMPO; prev_en = en
    pieces.append((t, s)); segs.append([st, en]); orig.append((a0, t))
for k in range(NL - 1):
    need = max(3.0, WORDS[k] / 3 + 1) + 0.15
    span = segs[k + 1][0] - (0 if k == 0 else segs[k][0])
    if span < need:
        add = need - span; print("pad line", k + 1, round(add, 2))
        for j in range(k + 1, NL):
            segs[j][0] += add; segs[j][1] += add; pieces[j] = (pieces[j][0] + add, pieces[j][1]); orig[j] = (orig[j][0], orig[j][1] + add)
T_END = segs[-1][1] + TAIL
y = np.zeros(int(T_END * SR) + SR)
for t0, s in pieces: i = int(t0 * SR); y[i:i + len(s)] += s
y = y[:int(T_END * SR)]
sf.write(f"{D}/vo.wav", y.astype(np.float32), SR, subtype="FLOAT")
segs = [[round(a, 3), round(b, 3)] for a, b in segs]
json.dump({"segs": segs, "vo": f"{D}/vo.wav", "tempo": TEMPO, "lead": LEAD}, open(f"{D}/segs.json", "w"), indent=1)
def remap(tt):
    k = max(i for i in range(NL) if SEG[i][0] - 0.2 <= tt or i == 0)
    a0, t0 = orig[k]; return round(t0 + (tt - a0) / TEMPO, 3)
chunks = [[remap(c[0]), remap(c[1]), c[2]] for c in CH]
json.dump({"chunks": chunks, "segs": segs, "T_END": round(T_END, 3)}, open(f"{D}/segs_full.json", "w"), indent=1, ensure_ascii=False)
shutil.rmtree(f"{D}/c_in"); shutil.rmtree(f"{D}/c_out", ignore_errors=True); os.remove(f"{D}/fast.wav")
print("vo", round(len(y) / SR, 2), "s; segs", segs)
