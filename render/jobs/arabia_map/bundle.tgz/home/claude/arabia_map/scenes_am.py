"""arabia_map scenes (1 Nov 2026): daily_1101 house scenes (dark stage, label chip, circular loop, bar-cut music) plus
- sc_amap: a wide map from Spain to Central Asia on the dark stage. Countries (modern borders, approximate) take colours per
  step; changes cross-fade. Fields: steps [{year, fills{iso: hex}, km, n, tags [{en, lon, lat}]}], keep (fills carry over
  between steps, default true), base (fills before step 0), pins [{en, lon, lat, lx, ly}], legend [[hex, label]], en, en_y,
  size, year (shown when no steps), km_label, n_label, israel ("outline" or "gold"), glow (isos that pulse), source, note.
  The whole land of Israel always gets a gold outline and the Green Line in green; "gold" also fills it in house gold.
- sc_cbars: dark bar list. rows [{en, value, text, gold, nodata, at}], title, source."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))
from shapely.geometry import Polygon as _Poly

REGION = [-11.0, 9.0, 70.0, 45.0]
LANDC = (0.13, 0.20, 0.36); BORDC = (0.30, 0.40, 0.58); SANDC = kit.hx("#C9A24A"); WBGC = kit.hx("#A8853A")
GLINE = (46 / 255, 204 / 255, 113 / 255)
GOLAN = _Poly([(35.62, 33.25), (35.628, 33.278), (35.704, 33.306), (35.715, 33.331), (35.79, 33.335), (35.83, 33.30),
               (35.82, 33.26), (35.83, 33.20), (35.815, 33.14), (35.82, 33.10), (35.85, 33.04), (35.87, 32.97), (35.88, 32.90),
               (35.87, 32.83), (35.84, 32.76), (35.836, 32.729), (35.791, 32.754), (35.683, 32.708), (35.644, 32.69),
               (35.64, 32.82), (35.635, 32.90), (35.62, 33.0), (35.60, 33.1), (35.60, 33.2)])
_RC = {}

def _rings(mv, iso, tol=0.5):
    k = (mv.lon0, mv.lat0, mv.lon1, mv.lat1, mv.x0, mv.y0, mv.x1, mv.y1, iso, tol)
    if k not in _RC:
        G = geo(); _RC[k] = mv.rings(G[iso]["g"], tol) if iso in G else []
    return _RC[k]

def _golan(mv): return [np.array([mv.P(x, y) for x, y in GOLAN.exterior.coords])]

def _hx(h): return kit.hx(h) if isinstance(h, str) else h

def _mixc(a, b, u): return tuple(a[i] + (b[i] - a[i]) * u for i in range(3))

def _state(S, k):
    """fill dict at step k (carry-over unless keep is false)"""
    st = dict(S.get("base") or {})
    for i, x in enumerate(S.get("steps") or []):
        if i > k: break
        if not S.get("keep", True) and i < k: continue
        st.update(x.get("fills") or {})
    return st

def _steps_t(S):
    steps = S.get("steps") or [{}]
    return [S["times"].get(f"s{i}", S["t0"] + 0.2 + 1.6 * i) if not (S.get("hook") and i == 0) else -1.0 for i in range(len(steps))]

def sc_amap(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); _stage_bg(c, t, S)
    box_ = tuple(S.get("box", (0, 590, W, 1245)))
    if "_mv" not in S: S["_mv"] = MapView(S.get("view", REGION), box_)
    mv = S["_mv"]; steps = S.get("steps") or [{}]; ts = _steps_t(S)
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0])
    u = 1.0 if ts[k] < 0 else ease(min(1.0, max(0.0, (t - ts[k]) / 0.8)))
    cur = _state(S, k); prev = _state(S, k - 1) if k else dict(S.get("base") or {})
    a0 = 1.0 if hook else RD.fade_in(t, t0, S, 0.3)
    keep = St.a; St.a = 1.0
    c.save(); x0, y0, x1, y1 = box_
    dur = max(1.0, ((S["t1"] or t0 + 4) - t0)); uz = min(1.0, max(0.0, (t - t0) / dur))
    z = 1.0 + 0.025 * (0.5 - 0.5 * math.cos(t * 1.6)) if hook or S.get("breathe") else lerp(S.get("z0", 1.0), S.get("zoom", 1.03), ease(uz))
    fx, fy = S.get("focus", [540, (y0 + y1) / 2]); c.translate(fx, fy); c.scale(z, z); c.translate(-fx, -fy)
    G = geo(); glow = set(S.get("glow") or [])
    for iso in G:
        rg = _rings(mv, iso)
        if not rg: continue
        cb = _hx(prev.get(iso, LANDC)); ca = _hx(cur.get(iso, LANDC)); colr = _mixc(cb, ca, u)
        if iso in glow:
            colr = _mixc(colr, (1, 1, 1), 0.10 + 0.10 * math.sin(t * 3.2))
        _path(c, rg); sa(c, colr, a0); c.fill_preserve(); sa(c, BORDC, a0); c.set_line_width(1.2 / z); c.stroke()
    if glow:   # bright rim around the pulsing set
        for iso in glow:
            rg = _rings(mv, iso)
            if rg: _path(c, rg); sa(c, (1, 0.86, 0.45), (0.55 + 0.35 * math.sin(t * 3.2)) * a0); c.set_line_width(3.0 / z); c.stroke()
    # whole land of Israel: gold fill (modern scenes) or gold outline, and the Green Line in green
    il = _rings(mv, "IL", 0.3) + _golan(mv); ps = _rings(mv, "PS", 0.3)
    if S.get("israel") == "gold":
        _path(c, il); sa(c, SANDC, a0); c.fill(); _path(c, ps); sa(c, WBGC, a0); c.fill()
    _path(c, il + ps); sa(c, SANDC, a0); c.set_line_width(3.0 / z); c.stroke()
    _path(c, ps); sa(c, GLINE, a0); c.set_line_width(2.6 / z); c.stroke()
    # pins (dots on the map)
    shown = []
    for i, p in enumerate(S.get("pins", [])):
        tk = S["times"].get(f"p{i}", t0 + 0.5 + 0.8 * i); hk = hook and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 12 + 60 * (1 - pr), YEL, 0.6 * pr * uu)
        circ(c, px, py, 13 * uu, WHITE, uu); circ(c, px, py, 8 * uu, YEL, uu)
        shown.append((i, p, tk, fx + (px - fx) * z, fy + (py - fy) * z))
    c.restore()
    for ya, yb, up in ((y0 - 10, y0 + 50, True), (y1 - 50, y1 + 10, False)):
        gg = cairo.LinearGradient(0, ya, 0, yb)
        gg.add_color_stop_rgba(0, 0.03, 0.06, 0.14, 0.9 if up else 0.0); gg.add_color_stop_rgba(1, 0.03, 0.06, 0.14, 0.0 if up else 0.9)
        c.rectangle(0, ya, W, yb - ya); c.set_source(gg); c.fill()
    for i, p, tk, px, py in shown:
        a2, s2 = (1.0, 1.0) if (hook and tk <= RD.HOOK_GRACE) else PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        lx, ly = p.get("lx", px), p.get("ly", py - 70)
        sa(c, WHITE, 0.85 * a2); c.set_line_width(3); c.move_to(px, py); c.line_to(lx, ly); c.stroke()
        pill(c, p["en"], p.get("sz", 46), lx, ly, INK, WHITE, a2, s2, outline=_hx(p.get("color", "#FFC93C")), w=800, padh=1.4)
    # step tags (year pills next to countries), only the current step's
    for j, tg in enumerate(steps[k].get("tags") or []):
        a2, s2 = (1.0, 1.0) if ts[k] < 0 else PP(t, ts[k] + 0.1 + 0.12 * j, S)
        px, py = mv.P(tg["lon"], tg["lat"]); px = fx + (px - fx) * z; py = fy + (py - fy) * z
        pill(c, tg["en"], tg.get("sz", 46), px + tg.get("dx", 0), py + tg.get("dy", 0), INK, WHITE, a2, s2, outline=YEL, w=800, padh=1.35)
    # bottom row: year (yellow) and a counter (km² or a count), or the legend
    st = steps[k]; pv = steps[k - 1] if k else st
    yr = st.get("year", S.get("year"))
    if isinstance(yr, int) and isinstance(pv.get("year"), int) and k: yr = int(round(pv["year"] + (yr - pv["year"]) * u))
    if isinstance(yr, int) and yr < 0: yr = None
    cnt = None
    for key, lab in (("km", S.get("km_label", "under Arab rule")), ("n", S.get("n_label", "Arab states"))):
        if st.get(key) is not None:
            v0 = pv.get(key, st[key]) if k else S.get(key + "0", st[key]); v = v0 + (st[key] - v0) * u
            cnt = ((f"{v:.1f} million km²" if key == "km" else f"{v:.0f}"), lab)
    ay = 1.0 if hook else RD.fade_in(t, t0 + 0.05, S)
    if yr is not None and S.get("show_year", True):
        ys = str(yr) + (" CE" if isinstance(yr, int) and yr < 1000 else "")
        kit.tx(c, ys, 116 if cnt else 140, 250 if cnt else 540, 1300, w=900, col=RD.c255(YEL), a=ay, shadow=True, maxw=440 if cnt else 1000)
    if cnt:
        kit.tx(c, cnt[0], 72, 760 if yr is not None else 540, 1282, w=900, col=RD.c255(WHITE), a=ay, shadow=True, maxw=580 if yr is not None else 1000)
        kit.tx(c, cnt[1], 44, 760 if yr is not None else 540, 1348, w=800, col=RD.c255(SKY), a=ay, shadow=True, maxw=560 if yr is not None else 1000)
    if S.get("legend") and not cnt and (yr is None or not S.get("show_year", True)):
        f = kit.font(44, 800); items = S["legend"]; ws_ = [f.getlength(lb) + 90 for _, lb in items]; gap = 24
        x = 540 - (sum(ws_) + gap * (len(items) - 1)) / 2; la = 1.0 if hook else RD.fade_in(t, t0 + 0.3, S)
        for (hc, lb), wv in zip(items, ws_):
            sa(c, INK, 0.75 * la); rr(c, x, 1300 - 34, wv, 68, 34); c.fill()
            circ(c, x + 38, 1300, 16, _hx(hc), la)
            kit.tx(c, lb, 44, x + 62 + (wv - 90) / 2, 1300, w=800, col=RD.c255(WHITE), a=la, shadow=False, maxw=1000)
            x += wv + gap
    if S.get("en"):
        a1, s1 = (1.0, 1.0) if hook else PP(t, t0 + 0.05, S)
        br = 1.0 + 0.012 * math.sin(t * 2.2) if hook else 1.0
        _wtext(c, S["en"], S.get("size", 100), S.get("en_y", 455), a=a1, sc=s1 * br, max_lines=S.get("max_lines", 2))
    la = 1.0 if hook else RD.fade_in(t, t0 + 0.4, S)
    if S.get("note"): _label(c, S["note"], 1418 - 62, la)
    if S.get("source"): _label(c, S["source"], 1418, la)
    St.a = keep

def sc_cbars(c, t, S):
    t0 = S["t0"]; _stage_bg(c, t, S); y = TOP + 40
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); _wtext(c, S["title"], 100, y + 20, a=a1, sc=s1, max_lines=1); y += 150
    rows = S["rows"]; n = len(rows); top = y + 20; rh = min(150, (1330 - top) / n); vmax = S.get("max", 35.0)
    for i, r in enumerate(rows):
        tk = S["times"].get(f"r{i}", t0 + 0.4 + 0.45 * i); a2, s2 = PP(t, tk, S)
        if a2 <= 0.01: continue
        cy = top + rh * (i + 0.5); ub = ease(min(1.0, max(0.0, (t - tk) / 0.9)))
        gold = r.get("gold"); cc = SANDC if gold else SKY
        kit.tx(c, r["en"], 60, 40, cy, w=900, col=RD.c255(YEL if gold else WHITE), a=a2, shadow=True, maxw=330, anchor="l")
        bx = 380; bw = 470 * min(1.0, r.get("value", 0) / vmax) * ub
        if r.get("nodata"):
            kit.tx(c, "no reliable count", 52, bx, cy, w=700, col=RD.c255((0.75, 0.8, 0.9)), a=a2, shadow=False, maxw=680, anchor="l")
            continue
        sa(c, (1, 1, 1), 0.08 * a2); rr(c, bx, cy - 30, 470, 60, 30); c.fill()
        if bw > 4: sa(c, cc, a2); rr(c, bx, cy - 30, max(60, bw), 60, 30); c.fill()
        kit.tx(c, r["text"], 60, bx + max(60, bw) + 22, cy, w=900, col=RD.c255(WHITE), a=a2 * min(1, ub * 2), shadow=True, maxw=1060 - bx - max(60, bw) - 22, anchor="l")
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("note"): _label(c, S["note"], 1418 - 62, la)
    if S.get("source"): _label(c, S["source"], 1418, la)
