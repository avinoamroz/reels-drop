import sys,glob
from PIL import Image
d=sys.argv[1];fs=sorted(glob.glob(f'{d}/qa/f_*.png'));ims=[Image.open(f).resize((324,576)) for f in fs]
S=Image.new('RGB',(324*5,576*((len(ims)+4)//5)));[S.paste(im,((i%5)*324,(i//5)*576)) for i,im in enumerate(ims)];S.save(f'{d}/qa/sheet.png')
