"""send_cloud.py: four GitHub render jobs (voice and mix local, cloud ASR on)."""
import sys; sys.path.insert(0, "/home/claude/reelkit")
import cloud_render as C
B = "/home/claude/border_jokes"
jobs = []
for r in sys.argv[1:] or ["border_knock_1", "border_knock_2", "border_question_1", "border_collie"]:
    jobs.append({"id": r, "cmd": f"cd {B} && python3 engine.py {r} --out {B}/{r}/final.mp4", "out": f"{B}/{r}/final.mp4",
                 "entry": [f"{B}/engine.py"], "add": [f"{B}/{r}/timing.json", f"{B}/{r}/mix.m4a", f"{B}/common/geo_il.json"]})
C.send(jobs)
