"""border_jokes engine: four comedy reels on the Gaza and Egypt border at Rafah (@noamroz__).
python3 engine.py RID [--frames t1,t2,...] [--out path.mp4]
RID: border_knock_1 | border_knock_2 (knock-knock, door on the map) | border_question_1 (deadpan quiz show) | border_collie.
Data: RID/timing.json + RID/mix.m4a (assemble.py, mix_step.py), common/geo_il.json (Natural Earth, from jews_white).
Brand: night #0B1426, navy #163261, sky #45A4DD (Israel), gold #FFCD50 (numbers), red #E5484D (shut gate), sand #C9A85C (Gaza),
Green Line green. Heebo. Circular: the last 0.8 s cross-fade into frame 0."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

B = "/home/claude/border_jokes"
RID = sys.argv[1]; ARGS = sys.argv[2:]; D = f"{B}/{RID}"
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def shade(c, f): return (c[0] * f, c[1] * f, c[2] * f, c[3])
def tint(c, f): return (c[0] + (1 - c[0]) * f, c[1] + (1 - c[1]) * f, c[2] + (1 - c[2]) * f, c[3])

NIGHT, NAVY, SKY, GOLD, RED, SAND = hx("#0B1426"), hx("#163261"), hx("#45A4DD"), hx("#FFCD50"), hx("#E5484D"), hx("#C9A85C")
SAND2 = hx("#B89A55"); GREEN = (46 / 255, 204 / 255, 113 / 255, 1); WHITE = (1, 1, 1, 1); INK = hx("#1B1F2A")
LAND = hx("#22417A"); PINK = hx("#F28CA0"); GREYD = hx("#9AA5B4"); SEA = hx("#12284E"); WATER = hx("#3D8FD1")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0, rot=0.0):
    if a <= 0.01 or sc <= 0.01 or not s: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y - size * 0.35); c.rotate(rot); c.scale(sc, sc); c.translate(-x, -(y - size * 0.35))
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def tlen(s, size, w=900): return font(size, w).getlength(s.replace("*", ""))
def rich(c, parts, size, x, y, w=900, a=1.0, sc=1.0, hl=GOLD, base=WHITE):
    toks = [t for t in re.split(r"(\*[^*]+\*)", parts) if t]
    f = font(size, w); tot = sum(f.getlength(t.strip("*")) for t in toks); cx = x - tot / 2
    c.save(); c.translate(x, y - size * 0.35); c.scale(sc, sc); c.translate(-x, -(y - size * 0.35))
    for t_ in toks:
        s = t_.strip("*"); text(c, s, size, cx, y, w, hl if t_.startswith("*") else base, a, "l"); cx += f.getlength(s)
    c.restore()
def wrap(s, size, maxw, w=900):
    """wrap rich text into lines (keeps *highlight* spans balanced per line)"""
    words = s.split(); lines = []; cur = []; on = False; tags = []
    for wd in words:
        tst = " ".join(cur + [wd])
        if cur and tlen(tst, size, w) > maxw: lines.append(cur); cur = [wd]
        else: cur.append(wd)
    lines.append(cur); out = []; open_ = False
    for ln in lines:
        s2 = " ".join(ln)
        if open_: s2 = "*" + s2
        n = s2.count("*")
        if n % 2 == 1: s2 = s2 + "*"; open_ = True
        else: open_ = False
        out.append(s2.replace("**", ""))
    return out
def block(c, s, size, x, ycen, maxw=940, a=1.0, sc=1.0, lh=1.18, w=900, hl=GOLD, base=WHITE):
    ls = wrap(s, size, maxw, w); n = len(ls); y0 = ycen - (n - 1) * size * lh / 2 + size * 0.36
    for k, l in enumerate(ls): rich(c, l, size, x, y0 + k * size * lh, w, a, sc, hl, base)
    return n
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def ell(c, cx, cy, rx, ry):
    c.save(); c.translate(cx, cy); c.scale(max(rx, 0.01), max(ry, 0.01)); c.new_sub_path(); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
def fill(c, col, a=1.0): c.set_source_rgba(col[0], col[1], col[2], col[3] * a); c.fill()
def stroke(c, col, w, a=1.0):
    c.set_source_rgba(col[0], col[1], col[2], col[3] * a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
def pill(c, s, x, y, a=1.0, col=SKY, tc=WHITE, sz=44):
    if a <= 0.01: return
    tw = font(sz, 800).getlength(s); rr(c, x - tw / 2 - 30, y - sz * 0.9, tw + 60, sz * 1.8, sz * 0.9); fill(c, col, a)
    text(c, s, sz, x, y + sz * 0.35, 800, tc, a)
def source(c, s, y=1548, a=1.0):
    text(c, s, 38, 540, y, 400, tint(SKY, 0.55), a)
def stamp(c, s, x, y, u, rot=-0.10, size=100, col=GOLD):
    if u <= 0.01: return
    sc = lerp(1.9, 1.0, eout(u)); a = clamp(u * 3); tw = font(size, 900).getlength(s)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc)
    rr(c, -tw / 2 - 34, -size * 0.95, tw + 68, size * 1.3, 26); c.set_source_rgba(*col[:3], a); c.set_line_width(10); c.stroke()
    text(c, s, size, 0, size * 0.18, 900, col, a); c.restore()

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]; EV = TM["events"]; NL = len(LINES)
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    if not ws: return LINES[li]["t0"]
    return ws[min(nth, len(ws) - 1)]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
def le(li): return LINES[li]["t1"]
END = round(TM["dur"] + 0.25, 2); T_FADE = END - 0.8
def cur_line(t):
    k = 0
    for i in range(NL):
        if t >= LINES[i]["t0"] - 0.12: k = i
    return k

# ------------------------------------------------------------------ map (whole land of Israel)
GIL = json.load(open(f"{B}/common/geo_il.json"))
GAZA = min(GIL["pal"], key=len); WB = max(GIL["pal"], key=len)
RAFAH_LINE = [(34.2489, 31.2122), (34.2237, 31.2764), (34.1985, 31.3135)]
RAFAH = (34.236, 31.245)
class Cam:
    def __init__(s, lon, lat, k, x, y): s.lon, s.lat, s.k, s.x, s.y, s.cs = lon, lat, k, x, y, math.cos(math.radians(lat))
    def P(s, lon, lat): return (s.x + (lon - s.lon) * s.cs * s.k, s.y - (lat - s.lat) * s.k)
def _ring(c, cam, r):
    for i, (lo, la) in enumerate(r):
        x, y = cam.P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
    c.close_path()
_mc = {}
def map_surface(cam, clip=None, labels=True, key=None):
    k = key or (cam.lon, cam.lat, cam.k, cam.x, cam.y, clip, labels)
    if k in _mc: return _mc[k]
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    if clip: rr(c, *clip, 44); c.clip(); c.set_source_rgba(*SEA[:3], 1); c.paint()
    for iso, rings in GIL["me"].items():
        for r in rings: _ring(c, cam, r)
        c.set_source_rgba(*LAND[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.35); c.set_line_width(1.5); c.stroke()
    for r in GIL["isr"]: _ring(c, cam, r)
    fill(c, SKY)
    _ring(c, cam, WB); fill(c, SAND2); _ring(c, cam, GAZA); fill(c, SAND)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = cam.P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.set_source_rgba(*GREEN[:3], 1); c.set_line_width(max(2.0, cam.k / 80)); c.stroke()
    if labels:
        ex, ey = cam.P(32.9, 30.0); text(c, "EGYPT", 40, ex, ey, 900, tint(SKY, 0.5), 0.9)
        ix, iy = cam.P(35.05, 30.45); text(c, "ISRAEL", 40, ix, iy, 900, WHITE, 0.95)
        jx, jy = cam.P(36.4, 31.0); text(c, "JORDAN", 36, jx, jy, 900, tint(SKY, 0.5), 0.8)
    s.flush(); _mc[k] = s; return s
def rafah_line(c, cam, t, a=1.0, wdt=None):
    pul = 0.6 + 0.4 * math.sin(t * 6)
    for w_, al in ((wdt or cam.k / 9, 0.25 * pul), ((wdt or cam.k / 9) * 0.45, 1.0)):
        for i, (lo, la) in enumerate(RAFAH_LINE):
            x, y = cam.P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        stroke(c, RED, w_, a * al)
def padlock(c, x, y, s, a=1.0, shake=0.0):
    c.save(); c.translate(x + shake, y); c.scale(s, s)
    c.arc(0, -34, 26, math.pi, 2 * math.pi); c.line_to(26, -10); c.move_to(-26, -10); c.line_to(-26, -34); stroke(c, hx("#D7DCE4"), 11, a)
    rr(c, -40, -14, 80, 66, 14); fill(c, RED, a); ell(c, 0, 12, 9, 9); fill(c, NIGHT, a); rr(c, -4, 14, 8, 20, 4); fill(c, NIGHT, a)
    c.restore()

# ------------------------------------------------------------------ background
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NIGHT[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1D427F")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1000, 720, SKY, 0.14); return s
BG = bg_surface()

# ------------------------------------------------------------------ subtitles (narration that is not already on screen word for word)
REPL = [("Twelve kilometers.", "12 km."), ("twenty tunnels", "20 tunnels"), ("Number twenty six", "No. 26"), ("about twenty more", "about 20 more"),
        ("Hamas", "HAMAS"), ("Hamas says:", "HAMAS says:")]
SUB_BOTTOM = 1712
def build_subs(skip):
    items = []
    for li, L in enumerate(LINES):
        if li in skip: continue
        toks = []
        ws = [dict(w) for w in L["words"]]; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower() == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.15, " ".join(x["w"] for x in cur), L["spk"]]); cur = []
    items.sort()
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
def draw_subs(c, t, subs):
    for a0, a1, s, spk in subs:
        if a0 <= t < a1:
            f = font(54, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.84); c.fill()
            if spk == "K": rr(c, 540 - wmax / 2, y0, wmax, bh, 24); stroke(c, SKY, 4)
            for n, l in enumerate(lines): text(c, l, 54, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ================================================================== KNOCK KNOCK
def knock_events(): return [e[0] for e in EV if e[1] == "knock"]
def bubble(c, s, side, y, u, a=1.0):
    if u <= 0.01 or a <= 0.01: return
    sz = 66; tw = tlen(s, sz, 800); bw, bh = tw + 76, 112
    x = 70 if side == "L" else 1010 - bw
    p = eob(clamp(u)); ox = x + (0 if side == "L" else bw)
    c.save(); c.translate(ox, y); c.scale(p, p); c.translate(-ox, -y)
    rr(c, x, y - bh / 2, bw, bh, 50); fill(c, WHITE if side == "L" else SKY, a)
    tx = x + 38 if side == "L" else x + bw - 38
    c.move_to(x + (30 if side == "L" else bw - 30), y + bh / 2 - 6); c.line_to(x + (8 if side == "L" else bw - 8), y + bh / 2 + 26)
    c.line_to(x + (70 if side == "L" else bw - 70), y + bh / 2 - 6); c.close_path(); fill(c, WHITE if side == "L" else SKY, a)
    text(c, s, sz, tx, y + 24, 800, NAVY if side == "L" else WHITE, a, "l" if side == "L" else "r")
    c.restore()

KCAM = Cam(34.9, 31.4, 158, 720, 1240)          # whole land of Israel, Eilat to the Golan, y about 940 to 1540
DOOR = (130, 1030, 250, 440)                    # x, y, w, h (stands in Sinai, callout to Rafah)
def door(c, t, open_=0.0, shake=0.0, locked=1.0, label="RAFAH", flash=0.0):
    x, y, w, h = DOOR
    c.save(); c.translate(shake * 9 * math.sin(t * 70), 0)
    rr(c, x - 26, y - 26, w + 52, h + 26, 18); fill(c, hx("#0E1C3A"))
    rr(c, x - 26, y - 26, w + 52, h + 26, 18); stroke(c, SKY, 6, 0.8)
    rr(c, x, y, w, h, 8); fill(c, hx("#FFF3C4") if flash > 0 else NIGHT)
    if flash > 0: glow(c, x + w / 2, y + h / 2, 260, GOLD, 0.8 * flash)
    sx = 1 - 0.82 * ease(open_)
    c.save(); c.translate(x, y); c.scale(sx, 1)
    rr(c, 0, 0, w, h, 8); fill(c, hx("#2A5BA8"))
    for py, ph in ((30, 170), (230, 180)): rr(c, 28, py, w - 56, ph, 12); stroke(c, hx("#1C437F"), 8)
    ell(c, w - 34, h * 0.55, 14, 14); fill(c, GOLD)
    c.restore()
    if locked > 0.01:
        c.move_to(x - 10, y + h * 0.42); c.line_to(x + w + 10, y + h * 0.55); stroke(c, hx("#C9D1DC"), 10, locked)
        c.move_to(x - 10, y + h * 0.58); c.line_to(x + w + 10, y + h * 0.44); stroke(c, hx("#C9D1DC"), 10, locked)
        padlock(c, x + w / 2, y + h * 0.5, 1.25, locked, shake * 6 * math.sin(t * 50))
    pill(c, label, x + w / 2, y - 62, 1.0, RED if locked > 0.5 else SKY, WHITE, 42)
    c.restore()
    if shake > 0.05:
        for k in range(3):
            r = 30 + 40 * ((t * 3 + k / 3) % 1)
            c.arc(x + w + 30, y + h * 0.3, r, -0.8, 0.8); stroke(c, WHITE, 5, shake * (1 - ((t * 3 + k / 3) % 1)))

def knock_frame_data():
    """jokes: [knock, who's there, X, X who, punch]; then the fair line and the lead-in"""
    jokes = []; i = 0
    while i < NL:
        if LINES[i]["text"] == "Knock knock.": jokes.append(list(range(i, i + 5))); i += 5
        else: break
    return jokes, list(range(i, NL))
JOKES, TAIL = {"border_knock_1": ([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14], [15, 16, 17, 18, 19]], [20, 21]),
               "border_knock_2": ([[0, 1, 2, 3, 4], [5, 6, 7, 8, 9], [10, 11, 12, 13, 14], [15, 16, 17, None, 18]], [19, 20])}.get(RID, ([], []))
PUNCH = {
 "border_knock_1": [("Exactly. Nobody ever asks *Egypt.*", None, None),
                    ("After 2007, Egypt kept me *shut for years.*", "Open 34 days in 11 months", "Source: UN OCHA, 2015 (Oct 2014 to Sep 2015)"),
                    ("Gaza's border with *Egypt.*", "12.6 km. Never trending.", "Length: Egypt Gaza border, 12.6 km"),
                    ("Egypt pumped *seawater* into the tunnels.", "2015. No protests.", "Source: Al Jazeera, Sep 2015")],
 "border_knock_2": [("*Nobody.* That's who talks about the Egypt border.", None, None),
                    ("Egypt's president: not in Sinai. Try *Israel's Negev.*", "October 2023", "Source: Reuters, 18 Oct 2023 (paraphrase)"),
                    ("The strip on the Egypt border.", "IDF says: about 20 tunnels", "Source: IDF spokesman, 29 May 2024"),
                    ("Israel! Come in, we were *just talking about you.*", None, None)],
}
FAIR = {"border_knock_1": ("Since May 2024, Israel holds *the Gaza side.*", "Two borders. Only one gets *the blame.*", "But"),
        "border_knock_2": ("Since May 2024, Israel holds *the Gaza side.*", "Two borders. Only one gets *the knock.*", "But")}
ENDL = {"border_knock_1": "Go on. Try *the other door.*", "border_knock_2": "Okay. *One more.*"}
FAIR_SRC = "Sources: AP, May 2024 and Feb 2026"

def sc_knock(c, t):
    KE = knock_events()
    # map + door (bottom half)
    c.set_source_surface(map_surface(KCAM, clip=(60, 900, 960, 660), labels=False, key="kmap"), 0, 0); c.paint()
    rr(c, 60, 900, 960, 660, 44); stroke(c, SKY, 4, 0.5)
    ix, iy = KCAM.P(35.05, 30.45); text(c, "ISRAEL", 40, ix, iy, 900, WHITE, 0.95)
    ex, ey = KCAM.P(33.9, 29.75); text(c, "EGYPT", 40, ex, ey, 900, tint(SKY, 0.6), 0.95)
    rafah_line(c, KCAM, t)
    rx, ry = KCAM.P(*RAFAH)
    x, y, w, h = DOOR
    c.move_to(x + w + 26, y + 120); c.curve_to(x + w + 120, y + 120, rx - 80, ry, rx - 10, ry); c.set_dash([14, 12]); stroke(c, RED, 5, 0.9); c.set_dash([])
    ell(c, rx, ry, 11, 11); fill(c, RED)
    gx, gy = KCAM.P(34.25, 31.55); text(c, "GAZA", 38, gx - 14, gy - 10, 900, SAND, 1, "r")
    sh = max([clamp(1 - (t - e) / 0.6) if 0 <= t - e < 0.6 else 0 for e in KE] + [0])
    fair_on = TAIL and t >= lt(TAIL[0]) - 0.12
    # which joke
    j = 0
    for k, J in enumerate(JOKES):
        if t >= (KE[k] if k < len(KE) else lt(J[0])) - 0.05: j = k
    J = JOKES[j]; tp = lt(J[4]) - 0.1
    is_israel = RID == "border_knock_2" and j == 3
    opn = 0.0; flash = 0.0; lock = 1.0
    if is_israel and t >= lt(J[4]) - 0.1 and not fair_on:
        opn = eout((t - lt(J[4]) + 0.1) / 0.35); flash = opn; lock = 1 - opn
    door(c, t, opn, sh, lock, "ISRAEL" if (is_israel and opn > 0.5) else "RAFAH", flash)
    if is_israel and opn > 0.2:
        for k in range(6):
            ph = (t * 1.7 + k * 0.37) % 1
            if ph < 0.12:
                fx = x + 30 + (k * 53) % (w - 40); fy = y + 60 + (k * 97) % (h - 120); glow(c, fx, fy, 70, WHITE, 0.9)
        text(c, "everyone's talking", 40, x + w / 2, y + h + 70, 800, GOLD, opn)
    if fair_on:
        # Israel holds the Gaza side since May 2024: small sky marker on the Gaza side of Rafah
        u = eout((t - lt(TAIL[0])) / 0.4); gx2, gy2 = KCAM.P(34.30, 31.27)
        rr(c, gx2 + 30, gy2 - 30, 300 * u, 60, 30); fill(c, SKY, u)
        text(c, "Israel, Gaza side", 34, gx2 + 48, gy2 + 12, 800, WHITE, clamp(u * 2 - 1), "l")
    # top half: dialogue bubbles, punchline, fair line
    if fair_on:
        L0 = TAIL[0]; tb = wt(L0, FAIR[RID][2]) - 0.1
        end_on = len(TAIL) > 1 and t >= lt(TAIL[-1]) - 0.12
        if end_on:
            block(c, ENDL[RID], 96, 540, 560, 900, 1, eob(clamp((t - lt(TAIL[-1]) + 0.12) / 0.3)))
        else:
            a1 = 1 - ramp(t, tb - 0.1, tb + 0.15)
            block(c, FAIR[RID][0], 88, 540, 560, 920, a1, eob(clamp((t - lt(L0) + 0.12) / 0.3)))
            block(c, FAIR[RID][1], 92, 540, 560, 920, ramp(t, tb, tb + 0.2), eob(clamp((t - tb) / 0.3)))
            source(c, FAIR_SRC, 868, 1)
        return
    if t < tp:
        for k in range(4):
            li = J[k]
            if li is None: continue
            t0 = lt(li) - 0.08
            u = 1.0 if (j == 0 and k < 2) else clamp((t - t0) / 0.22)
            if j == 0 and k < 2 and t < 0.01: u = 1.0
            if u <= 0 and not (j == 0 and k < 2): continue
            bubble(c, LINES[li]["text"], "L" if k % 2 == 0 else "R", 360 + k * 132, u)
    else:
        u = clamp((t - tp) / 0.3)
        for k in range(4):
            if J[k] is None: continue
            bubble(c, LINES[J[k]]["text"], "L" if k % 2 == 0 else "R", 360 + k * 132 - 80 * u, 1, 1 - u)
        pt, big, src = PUNCH[RID][j]
        block(c, pt, 86, 540, 470 if big else 560, 940, u, eob(u))
        if big:
            text(c, big, 70, 540, 720, 900, GOLD, ramp(t, tp + 0.4, tp + 0.7), "c", eob(clamp((t - tp - 0.4) / 0.3)))
        if src: source(c, src, 868, ramp(t, tp + 0.3, tp + 0.6))
        if RID == "border_knock_1" and j == 0:
            stamp(c, "EGYPT?", 790, 840, (t - wt(J[4], "Egypt")) / 0.35, 0.1, 70, RED)

# ================================================================== QUIZ
QCAM = Cam(34.9, 31.4, 112, 760, 1262)
QS = [i for i, L in enumerate(LINES) if L["text"].startswith("Question")]
QTEXT = {}
for i in QS:
    s = LINES[i]["text"].split(". ", 1)[1]; QTEXT[i] = s
I_ANS = next((i for i, L in enumerate(LINES) if L["text"] == "Okay. The answer."), 0)
def q_index(t):
    k = -1
    for n, i in enumerate(QS):
        if t >= lt(i) - 0.25: k = n
    return k
BUZZ = [e[0] for e in EV if e[1] == "buzzer"]; TICKS = [e[0] for e in EV if e[1] == "ticks"]
def stage_bg(c, t, a=1.0):
    for k, (x0, col) in enumerate(((160, SKY), (920, GOLD))):
        sw = math.sin(t * 0.9 + k * 2) * 120
        c.move_to(x0, 180); c.line_to(540 + sw - 260, 1500); c.line_to(540 + sw + 260, 1500); c.close_path()
        g = cairo.LinearGradient(0, 180, 0, 1500); g.add_color_stop_rgba(0, *col[:3], 0.20 * a); g.add_color_stop_rgba(1, *col[:3], 0.0)
        c.set_source(g); c.fill()
    ell(c, 540, 1500, 470, 70); fill(c, hx("#0E1C3A"), a)
    for k in range(14):
        x = 70 + k * 72; on = (int(t * 4) + k) % 2
        ell(c, x, 1500 + 20 * math.sin(k / 13 * math.pi) * 0, 9, 9); fill(c, GOLD if on else hx("#40507A"), a)
def contestant(c, t, a=1.0, talk=0.0, sweat=0.0):
    x, y = 540, 1440
    c.save(); c.translate(0, math.sin(t * 2.2) * 3)
    ell(c, x, y - 380, 68, 72); fill(c, hx("#F1C7A3"), a)                          # flat, faceless head
    c.move_to(x - 70, y - 400); c.curve_to(x - 70, y - 470, x + 70, y - 470, x + 70, y - 400); c.close_path(); fill(c, hx("#3B2A22"), a)
    rr(c, x - 120, y - 310, 240, 200, 70); fill(c, hx("#6C7FA8"), a)
    if sweat > 0.01:
        c.move_to(x + 80, y - 420); c.curve_to(x + 96, y - 392, x + 96, y - 370, x + 80, y - 370); c.curve_to(x + 64, y - 370, x + 64, y - 392, x + 80, y - 420); fill(c, SKY, sweat * a)
    c.restore()
    rr(c, x - 230, y - 190, 460, 210, 24); fill(c, SKY, a)                          # podium
    rr(c, x - 200, y - 160, 400, 70, 20); fill(c, NAVY, a)
    text(c, "CONTESTANT", 44, x, y - 110, 900, WHITE, a)
    ell(c, x, y - 196, 60, 16); fill(c, shade(RED, 0.7), a); ell(c, x, y - 206, 52, 16); fill(c, RED, a)   # buzzer
def qcard(c, t, content, sc_x=1.0, a=1.0, chip=None, clock=None):
    x, y, w, h = 70, 300, 940, 600
    c.save(); c.translate(540, y + h / 2); c.scale(max(0.02, sc_x), 1); c.translate(-540, -(y + h / 2))
    rr(c, x, y, w, h, 46); fill(c, hx("#10224A"), a); rr(c, x, y, w, h, 46); stroke(c, GOLD, 8, a)
    if chip: pill(c, chip, 540, y + 4, a, GOLD, NIGHT, 42)
    content(c)
    c.restore()
    if clock is not None and sc_x > 0.95:
        cx, cy, r = 940, 330, 62
        ell(c, cx, cy, r + 10, r + 10); fill(c, NIGHT, a); c.arc(cx, cy, r, 0, 2 * math.pi); stroke(c, hx("#2B3C66"), 12, a)
        c.arc(cx, cy, r, -math.pi / 2, -math.pi / 2 + 2 * math.pi * clock); stroke(c, RED if clock < 0.3 else GOLD, 12, a)
        text(c, str(max(0, int(math.ceil(clock * 10)))), 60, cx, cy + 22, 900, WHITE, a)
ANS_ROWS = [("After 2007", "Egypt kept Rafah *shut*", "After", "UN OCHA, 2015: open 34 days in 11 months"),
            ("2015", "Egypt *flooded the tunnels*", "2015", "Al Jazeera, Sep 2015"),
            ("2023", "Egypt: *no Gazans in Sinai*", "2023", "Reuters, 18 Oct 2023")]
def sc_quiz(c, t):
    stage_bg(c, t)
    qi = q_index(t); ans = t >= lt(I_ANS) - 0.12
    # contestant (fades out for the answer)
    ca = 1 - ramp(t, lt(I_ANS) + 0.4, lt(I_ANS) + 0.9)
    kl = [i for i, L in enumerate(LINES) if L["spk"] == "K"]
    talk = None
    for i in kl:
        if lt(i) - 0.1 <= t < le(i) + 1.0: talk = i
    tick_on = any(0 <= t - x < 1.3 for x in TICKS)
    if ca > 0.01:
        contestant(c, t, ca, sweat=1.0 if tick_on else 0.0)
        if talk is not None:
            u = clamp((t - lt(talk) + 0.1) / 0.2); s = LINES[talk]["text"]
            sz = 68; tw = tlen(s, sz, 900); bcx = 820; bx = bcx - tw / 2 - 40
            c.save(); c.translate(bcx, 1080); c.scale(eob(u), eob(u)); c.translate(-bcx, -1080)
            rr(c, bx, 1020, tw + 80, 116, 50); fill(c, WHITE); c.move_to(bx + 30, 1110); c.line_to(bx + 80, 1120); c.line_to(bx - 20, 1150); c.close_path(); fill(c, WHITE)
            text(c, s, sz, bcx, 1102, 900, NAVY); c.restore()
        if tick_on:
            k = int((t * 3) % 4); text(c, "." * (k + 1), 110, 820, 1100, 900, WHITE, ca, "c")
    # buzzer flash
    for b in BUZZ:
        if 0 <= t - b < 0.62:
            u = (t - b) / 0.62; a = 1 - ease(max(0, u - 0.6) / 0.4)
            c.set_source_rgba(*RED[:3], 0.18 * a); c.paint()
            sz = 260 * eob(clamp(u / 0.25))
            c.save(); c.translate(540, 1160); c.rotate(0.05)
            c.move_to(-sz / 2, -sz / 2); c.line_to(sz / 2, sz / 2); c.move_to(sz / 2, -sz / 2); c.line_to(-sz / 2, sz / 2); stroke(c, RED, 44, a); c.restore()
            word = "TIME'S UP" if any(abs(b - (x + 1.3)) < 0.05 for x in TICKS) else "WRONG"
            stamp(c, word, 540, 1420, u / 0.3, -0.06, 92, RED)
    # score line
    if not ans:
        rich(c, "Correct answers: *0*", 52, 540, 968, 800, ca * (1 if qi >= 0 else 0))
    # card
    if not ans:
        if qi < 0:
            def cont(cc): block(cc, "The hardest question *on earth.*", 118, 540, 600, 860)
            qcard(c, t, cont, 1.0, 1.0, None)
        else:
            i = QS[qi]; t0 = lt(i) - 0.25; u = clamp((t - t0) / 0.45)
            sx = abs(math.cos(math.pi * u)); show = i if u >= 0.5 else (QS[qi - 1] if qi > 0 else None)
            def cont(cc, show=show):
                if show is None: block(cc, "The hardest question *on earth.*", 118, 540, 600, 860)
                else: block(cc, QTEXT[show], 92, 540, 620, 840)
            nb = [b for b in BUZZ if b > lt(i)]; tend = nb[0] if nb else lt(i) + 6
            clk = clamp(1 - (t - lt(i)) / max(0.5, tend - lt(i))) if u >= 1 else 1.0
            chip = f"QUESTION {QS.index(show) + 1} OF 8" if show is not None else "QUIZ SHOW"
            qcard(c, t, cont, sx, 1.0, chip, clk)
        return
    # answer part
    ta = lt(I_ANS); drum = [e[0] for e in EV if e[1] == "drumroll"][0]; ding = [e[0] for e in EV if e[1] == "ding"][0]
    if t < ding:
        u = clamp((t - ta + 0.12) / 0.45); sx = abs(math.cos(math.pi * u))
        def cont(cc):
            if u < 0.5: block(cc, QTEXT[QS[-1]], 92, 540, 620, 840)
            else: block(cc, "The *answer.*", 140, 540, 620, 860)
        qcard(c, t, cont, sx, 1.0, "FINAL ROUND")
        if t > drum:
            for k in range(8):
                ph = (t * 3 + k / 8) % 1; glow(c, 100 + k * 125, 260 + 40 * math.sin(k), 120, GOLD if k % 2 else SKY, 0.5 * (1 - ph))
        return
    i_f = I_ANS + 1; i_fair = I_ANS + 2; i_end = I_ANS + 3
    c.set_source_surface(map_surface(QCAM, clip=(70, 990, 940, 545), key="qmap"), 0, 0); c.paint()
    rr(c, 70, 990, 940, 545, 44); stroke(c, SKY, 4, 0.6)
    rafah_line(c, QCAM, t)
    rx, ry = QCAM.P(*RAFAH); padlock(c, rx - 52, ry + 14, 0.75)
    if t < lt(i_fair) - 0.12:
        rr(c, 70, 290, 940, 670, 46); fill(c, hx("#10224A")); rr(c, 70, 290, 940, 670, 46); stroke(c, GOLD, 8)
        pill(c, "THE ANSWER", 540, 294, 1, GOLD, NIGHT, 42)
        for k, (yr, s, w_, src) in enumerate(ANS_ROWS):
            tk = wt(i_f, w_) - 0.1 if k else max(ding, wt(i_f, w_) - 0.1)
            u = clamp((t - tk) / 0.3); yy = 372 + k * 196
            text(c, yr, 60, 540, yy + 20, 900, GOLD, u, "c", eob(u))
            rich(c, s, 64, 540, yy + 92, 800, u)
            text(c, src, 36, 540, yy + 140, 400, tint(SKY, 0.6), u)
        return
    if t < lt(i_end) - 0.12:
        tb = wt(i_fair, "Two") - 0.1
        rr(c, 70, 290, 940, 620, 46); fill(c, hx("#10224A")); rr(c, 70, 290, 940, 620, 46); stroke(c, GOLD, 8)
        block(c, "Since May 2024, Israel holds *the Gaza side.*", 84, 540, 600, 860, 1 - ramp(t, tb - 0.1, tb + 0.15))
        block(c, "Two borders. Only one gets *the questions.*", 88, 540, 600, 860, ramp(t, tb, tb + 0.2), eob(clamp((t - tb) / 0.3)))
        source(c, FAIR_SRC, 868)
        gx2, gy2 = QCAM.P(34.30, 31.27); u = eout((t - lt(i_fair)) / 0.4)
        rr(c, gx2 + 30, gy2 - 30, 300 * u, 60, 30); fill(c, SKY, u); text(c, "Israel, Gaza side", 34, gx2 + 48, gy2 + 12, 800, WHITE, clamp(u * 2 - 1), "l")
        return
    rr(c, 70, 290, 940, 620, 46); fill(c, hx("#10224A")); rr(c, 70, 290, 940, 620, 46); stroke(c, GOLD, 8)
    block(c, "Next contestant. *Same question.*", 100, 540, 600, 860, 1, eob(clamp((t - lt(i_end) + 0.12) / 0.3)))

# ================================================================== BORDER COLLIE
DARK = hx("#23262E"); SNOW = hx("#FAFAFA")
def collie_head(c, t, bark=0.0):
    op = max(0.0, math.sin(t * 11)) * bark
    for ex, rot in ((-30, -0.3), (16, 0.25)):                                     # semi-erect ears, tips folded
        c.save(); c.translate(ex, -40); c.rotate(rot); c.move_to(-22, 8); c.line_to(-4, -54); c.line_to(22, 8); c.close_path(); fill(c, DARK)
        c.move_to(-10, -30); c.line_to(-4, -54); c.line_to(6, -30); c.close_path(); fill(c, shade(DARK, 0.7)); c.restore()
    ell(c, 0, 0, 62, 60); fill(c, DARK)
    c.move_to(30, -60); c.curve_to(10, -20, 14, 10, 24, 40); c.line_to(60, 40); c.curve_to(56, 10, 46, -30, 40, -58); c.close_path(); fill(c, SNOW)   # blaze
    ell(c, 50, 22, 44, 30); fill(c, SNOW)
    ell(c, 88, 10, 13, 10); fill(c, INK); ell(c, 84, 6, 4, 3); fill(c, WHITE, 0.6)
    ell(c, 10, -14, 10, 11); fill(c, hx("#5B3A1E")); ell(c, 13, -18, 3.6, 3.6); fill(c, WHITE)
    if op > 0.05:
        c.move_to(30, 36); c.curve_to(42, 36 + 34 * op, 74, 36 + 34 * op, 84, 30); c.close_path(); fill(c, hx("#5A1E2A"))
    else:
        c.move_to(42, 36); c.curve_to(54, 46, 66, 46, 78, 34); stroke(c, INK, 5)
        sw = math.sin(t * 9) * 3; c.save(); c.translate(60 + sw, 42); rr(c, -10, -2, 20, 30, 10); fill(c, PINK); c.restore()
def collie(c, x, y, s, t, face=1, wag=1.0, walk=0.0, bark=0.0, ball=False):
    c.save(); c.translate(x, y); c.scale(s * face, s)
    bob = -(abs(math.sin(t * 8)) * 5 if walk else 0); c.translate(0, bob)
    a = 0.5 * math.sin(t * 15) * wag
    c.save(); c.translate(-112, -140); c.rotate(-0.9 + a)
    c.move_to(0, 0); c.curve_to(-20, -20, -50, -40, -40, -90); c.curve_to(-30, -60, -6, -30, 14, 14); c.close_path(); fill(c, DARK)
    ell(c, -38, -84, 12, 14); fill(c, SNOW); c.restore()
    for lx, k, far in ((-46, 0, True), (78, 1, True), (-80, 1, False), (44, 0, False)):
        sw = math.sin(t * 10 + k * math.pi) * 14 * walk
        c.save(); c.translate(lx, -82); c.rotate(sw / 60)
        rr(c, -15, 0, 30, 84, 15); fill(c, shade(DARK, 0.7) if far else DARK); rr(c, -15, 50, 30, 34, 15); fill(c, SNOW if not far else tint(GREYD, 0.4))
        c.restore()
    rr(c, -125, -178, 250, 108, 54); fill(c, DARK)
    c.move_to(60, -178); c.curve_to(150, -170, 150, -60, 90, -70); c.curve_to(70, -100, 50, -150, 60, -178); c.close_path(); fill(c, SNOW)   # white chest
    c.move_to(70, -186); c.curve_to(110, -150, 130, -140, 150, -150); stroke(c, SNOW, 26)                                                     # white collar
    c.save(); c.translate(108, -196); collie_head(c, t, bark)
    if ball:
        ell(c, 92, 36, 24, 24); fill(c, hx("#C8E04A")); c.arc(92, 36, 16, 0.4, 2.6); stroke(c, WHITE, 4)
    c.restore(); c.restore()
CCAM = Cam(34.9, 31.4, 128, 795, 1080)
LP = (70, 560, 460, 790); RP = (550, 560, 460, 790)      # left (collie) and right (border) panels
def panel(c, p, a=1.0, hl=0.0):
    x, y, w, h = p; rr(c, x, y, w, h, 40); fill(c, hx("#10224A"), a); rr(c, x, y, w, h, 40); stroke(c, GOLD if hl > 0.5 else SKY, 6, a * (0.5 + 0.5 * hl))
def right_map(c, t, a=1.0):
    c.set_source_surface(map_surface(CCAM, clip=RP, labels=False, key="cmap"), 0, 0); c.paint_with_alpha(a)
    rafah_line(c, CCAM, t, a)
    rx, ry = CCAM.P(*RAFAH); padlock(c, rx - 64, ry + 26, 0.75, a)
    text(c, "ISRAEL", 38, CCAM.P(35.05, 30.5)[0], CCAM.P(35.05, 30.5)[1], 900, WHITE, a * 0.95)
    text(c, "EGYPT", 38, 660, 1320, 900, tint(SKY, 0.5), a)
    gx, gy = CCAM.P(34.4, 31.55); text(c, "GAZA", 36, gx - 16, gy - 40, 900, SAND, a, "r")
def sc_collie(c, t):
    li = cur_line(t); u = t - (lt(li) - 0.12)
    endish = li == NL - 1 or li == 0
    # title
    if endish:
        rich(c, "Border collie *vs.*", 112, 540, 340, 900, 1, 1 + 0.01 * math.sin(t * 3))
        rich(c, "Gaza's border", 112, 540, 470, 900, 1, 1 + 0.01 * math.sin(t * 3))
    full = li in (6, 7, 8, 9)
    if not full:
        panel(c, LP, 1, 1.0 if li in (1, 3, 10) else 0.0); panel(c, RP, 1, 1.0 if li in (2, 3, 4, 5) else 0.0)
        right_map(c, t)
        c.save(); rr(c, *LP, 40); c.clip()
        bk = 0.0
        if li == 10:
            # collie brings the ball back
            p = clamp((u - 0.2) / 1.6); xx = lerp(160, 260, ease(p))
            collie(c, xx + 40, 1290, 1.0, t, face=1, walk=1.0 if p < 1 else 0.0, ball=True)
        else:
            collie(c, 272, 1290, 1.04, t, face=1, wag=1.4 if li in (1, 3) else 0.6, bark=bk)
        c.restore()
        text(c, "BORDER COLLIE", 40, 300, 620, 900, WHITE, 1); text(c, "THE RAFAH BORDER", 40, 780, 620, 900, WHITE, 1)
        if li == 1:
            for k in range(6):
                ph = (t * 0.7 + k / 6) % 1; hx_ = 120 + (k * 67) % 360; hy = 1150 - ph * 420
                c.save(); c.translate(hx_, hy); c.scale(1.2, 1.2)
                c.move_to(0, 8); c.curve_to(-22, -8, -12, -26, 0, -12); c.curve_to(12, -26, 22, -8, 0, 8); fill(c, PINK, math.sin(ph * math.pi)); c.restore()
            block(c, "Everyone *talks about it.*", 80, 540, 360, 940)
            rich(c, "*No. 26* dog in America", 66, 540, 470, 900, ramp(t, wt(1, "Number") - 0.1, wt(1, "Number") + 0.2))
            source(c, "Source: AKC most popular breeds, 2025", 1420, ramp(t, wt(1, "Number"), wt(1, "Number") + 0.3))
        if li == 2:
            block(c, "Nobody *talks about it.*", 84, 540, 410, 940)
            for k in range(3):
                ph = (t * 1.3 + k / 3) % 1; text(c, "...", 90, 700 + k * 110, 760 - ph * 60, 900, WHITE, math.sin(ph * math.pi) * 0.9)
        if li == 3:
            tn = wt(3, "Nobody") - 0.1
            block(c, "Nobody takes *ownership.*" if t > tn else "A border collie has *an owner.*", 84, 540, 410, 940)
            rr(c, 90, 1380, 420, 120, 30); fill(c, NIGHT, 0.85); rich(c, "Owners: *lots*", 60, 300, 1462, 900, 1)
            rr(c, 570, 1380, 420, 120, 30); fill(c, NIGHT, 0.85)
            v = 0 if t > tn else 1
            rich(c, "Owners: *0*", 60, 780, 1462, 900, ramp(t, tn - 0.6, tn - 0.3))
            if t > tn: stamp(c, "0", 860, 1000, (t - tn) / 0.35, 0.1, 150, GOLD)
        if li in (4, 5):
            if li == 4: block(c, "Nobody takes *ownership.*", 80, 540, 410, 940, 0.5)
            # speech bubbles over the border panel
            for k, (who, line, col, tc, y) in enumerate((("HAMAS", "blah blah blah", WHITE, NAVY, 760), ("CRITICS", "Israel's blockade!", SKY, WHITE, 960))):
                tl = 4 + k
                if li < tl: continue
                uu = clamp((t - lt(tl) + 0.1) / 0.25); tw = tlen(line, 60, 900)
                bx = 540 - tw / 2 - 40
                c.save(); c.translate(540, y); c.scale(eob(uu), eob(uu)); c.translate(-540, -y)
                rr(c, bx, y - 60, tw + 80, 120, 46); fill(c, col)
                c.move_to(bx + tw / 2 + 120, y + 58); c.line_to(bx + tw / 2 + 200, y + 58); c.line_to(bx + tw / 2 + 210, y + 110); c.close_path(); fill(c, col)
                text(c, line, 60, 540, y + 22, 900, tc); c.restore()
                pill(c, who, bx + 70, y - 72, uu, RED if k == 0 else GOLD, WHITE if k == 0 else NIGHT, 38)
            if li == 5:
                ix, iy = CCAM.P(34.9, 31.2)
                for k in range(3):
                    r = 30 + 60 * ((t * 1.5 + k / 3) % 1); c.arc(ix, iy, r, 0, 2 * math.pi); stroke(c, GOLD, 5, 1 - ((t * 1.5 + k / 3) % 1))
            rich(c, "Meanwhile, *the gate stays shut.*", 58, 540, 1450, 800, 1 if li == 5 else 0)
        if li == 10:
            block(c, "Everyone throws it *at Israel.*", 86, 540, 410, 940, ramp(t, wt(10, "With") - 0.2, wt(10, "With")))
            block(c, "A border collie brings *the ball back.*", 80, 540, 410, 940, 1 - ramp(t, wt(10, "With") - 0.2, wt(10, "With")))
            tw0 = wt(10, "With"); ix, iy = CCAM.P(34.95, 31.3)
            for k in range(6):
                t0 = tw0 + k * 0.28; p = clamp((t - t0) / 0.6)
                if p <= 0: continue
                sx, sy = [(570, 700), (1000, 760), (590, 1220), (1000, 1150), (780, 600), (990, 960)][k]
                bx = lerp(sx, ix + (k % 3 - 1) * 14, p); by = lerp(sy, iy + (k // 3) * 14, p) - math.sin(p * math.pi) * 90
                ell(c, bx, by, 18, 18); fill(c, hx("#C8E04A")); c.arc(bx, by, 12, 0.4, 2.6); stroke(c, WHITE, 3)
                if p >= 1 and t - t0 - 0.6 < 0.3: glow(c, ix, iy, 90, GOLD, 0.6 * (1 - (t - t0 - 0.6) / 0.3))
        if endish and li == NL - 1: pass
        return
    # full-width fact scenes
    c.set_source_surface(map_surface(CCAM, clip=RP, labels=False, key="cmap"), 0, 0)
    if li == 6:
        rr(c, 70, 300, 940, 560, 46); fill(c, hx("#10224A")); rr(c, 70, 300, 940, 560, 46); stroke(c, GOLD, 6)
        block(c, "Egypt kept Rafah *shut for years* after 2007.", 84, 540, 520, 860, 1, eob(clamp(u / 0.3)))
        text(c, "34 days open in 11 months", 66, 540, 760, 900, GOLD, ramp(t, lt(6) + 0.8, lt(6) + 1.1))
        source(c, "Source: UN OCHA, 2015 (Oct 2014 to Sep 2015)", 830, ramp(t, lt(6) + 0.8, lt(6) + 1.1))
        full_map(c, t)
    elif li in (7, 8):
        tunnels(c, t, li, u)
    elif li == 9:
        rr(c, 70, 300, 940, 560, 46); fill(c, hx("#10224A")); rr(c, 70, 300, 940, 560, 46); stroke(c, GOLD, 6)
        tb = wt(9, "But") - 0.1
        block(c, "Since May 2024, Israel holds *the Gaza side.*", 84, 540, 560, 860, 1 - ramp(t, tb - 0.1, tb + 0.15))
        block(c, "That border has *two sides.*", 96, 540, 560, 860, ramp(t, tb, tb + 0.2), eob(clamp((t - tb) / 0.3)))
        source(c, FAIR_SRC, 830)
        full_map(c, t, fair=True)
FCAM = Cam(34.9, 31.4, 130, 700, 1200)
def full_map(c, t, fair=False):
    c.save(); rr(c, 70, 900, 940, 620, 44); c.clip()
    c.set_source_surface(map_surface(FCAM, clip=(70, 900, 940, 620), key="fmap"), 0, 0); c.paint(); c.restore()
    rr(c, 70, 900, 940, 620, 44); stroke(c, SKY, 4, 0.6)
    rafah_line(c, FCAM, t); rx, ry = FCAM.P(*RAFAH); padlock(c, rx - 52, ry + 14, 0.75)
    if fair:
        gx2, gy2 = FCAM.P(34.30, 31.27)
        rr(c, gx2 + 30, gy2 - 30, 300, 60, 30); fill(c, SKY); text(c, "Israel, Gaza side", 34, gx2 + 48, gy2 + 12, 800, WHITE, 1, "l")
def tunnels(c, t, li, u):
    # cross-section: Gaza side | border fence | Egypt side; tunnels under the border
    top = 1000
    block(c, "Smuggling tunnels. Egypt *flooded them, 2015.*" if li == 7 else "IDF says: *about 20 tunnels* there, 2024", 80, 540, 470, 940, 1, eob(clamp(u / 0.3)))
    source(c, "Source: Al Jazeera, Sep 2015" if li == 7 else "Source: IDF spokesman, 29 May 2024", 650)
    if li == 8:
        tn = wt(8, "twenty") - 0.6; v = int(20 * eout((t - tn) / 1.0)) if t > tn else 0
        text(c, f"{v}", 170, 540, 860, 900, GOLD, ramp(t, tn, tn + 0.2)); text(c, "tunnels (IDF)", 52, 540, 920, 800, WHITE, ramp(t, tn, tn + 0.3))
    rr(c, 70, top, 940, 520, 44); c.save(); c.clip()
    c.set_source_rgba(*hx("#24365F")[:3], 1); c.paint()
    rr(c, 70, top, 940, 110, 0); fill(c, hx("#1A2A4E"))
    rr(c, 70, top + 110, 940, 410, 0); fill(c, hx("#8B6A3E"))
    for k in range(40):
        ell(c, 80 + (k * 97) % 940, top + 140 + (k * 53) % 360, 6, 4); fill(c, hx("#6E5230"))
    c.move_to(540, top + 10); c.line_to(540, top + 110); stroke(c, RED, 14)
    for k in range(9): c.move_to(500 + k * 10, top + 30); c.line_to(500 + k * 10, top + 110); stroke(c, hx("#C9D1DC"), 3)
    text(c, "GAZA", 44, 300, top + 80, 900, SAND); text(c, "EGYPT", 44, 780, top + 80, 900, tint(SKY, 0.6))
    n = 3 if li == 7 else 5
    for k in range(n):
        y = top + 190 + k * (300 / n); rr(c, 150, y, 780, 40, 20); fill(c, hx("#3E2C17"))
        if li == 7:
            tw = wt(7, "Egypt") - 0.1; p = clamp((t - tw - k * 0.15) / 1.2)
            if p > 0: rr(c, 930 - 780 * p, y + 4, 780 * p, 32, 16); fill(c, WATER)
            if p > 0: text(c, "~", 50, 930 - 780 * p, y + 34, 900, WHITE, 0.8)
        else:
            q = (t * 0.5 + k * 0.23) % 1; rr(c, 150 + q * 700, y + 6, 60, 28, 8); fill(c, GOLD, 0.8)
    c.restore(); rr(c, 70, top, 940, 520, 44); stroke(c, SKY, 4, 0.6)

# ------------------------------------------------------------------ frame
if RID.startswith("border_knock"):
    SCENE = sc_knock; SKIP = {i for J in JOKES for i in J[:4] if i is not None}
elif RID == "border_question_1":
    SCENE = sc_quiz; SKIP = set(QS) | {i for i, L in enumerate(LINES) if L["spk"] == "K"}
else:
    SCENE = sc_collie; SKIP = set()
SUBS = build_subs(SKIP)
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    SCENE(c, t)
    draw_subs(c, t, SUBS)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)
def blend0(t, img, F0):
    if t < T_FADE: return img
    u = ease((t - T_FADE) / (END - T_FADE))
    return (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = f"{D}/qa"; os.makedirs(out, exist_ok=True); F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); Image.fromarray(blend0(tt, frame(tt), F0)).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; p.stdin.write(blend0(tt, frame(tt), F0).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
