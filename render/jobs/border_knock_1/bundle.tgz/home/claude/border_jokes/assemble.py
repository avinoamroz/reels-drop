"""assemble.py RID: cut the batched Cartesia takes (narrator N = Noam clone, K = Katie stock voice) into lines,
house chain on N (pitch, bass, clean_vo, soft restore, atempo 1.1), light chain on K (atempo 1.05, level matched),
lay them on a comedy timeline with SFX gaps -> RID/vo_final.wav (48k mono), RID/timing.json (lines, words, events)."""
import sys, os, json, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/border_jokes")
import voice as V
from clean_vo import clean as clean_vo
from scripts import S
SR = V.SR; VD = "/home/claude/reels-drop/voice"; RID = sys.argv[1]; OUT = f"/home/claude/border_jokes/{RID}"
os.makedirs(OUT, exist_ok=True)

def ff_tempo(y, k):
    return np.frombuffer(V.run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={k}",
                                "-f", "f32le", "pipe:1"], np.asarray(y, np.float32).tobytes()), np.float32).astype(np.float64)
def load48(p, af="anull"):
    return np.frombuffer(V.run(["ffmpeg", "-v", "error", "-i", p, "-af", af, "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
def arms(x):
    n = int(0.03 * SR); m = len(x) // n
    if m == 0: return 1e-6
    e = np.sqrt((x[:m * n].reshape(m, n) ** 2).mean(1)); th = e.max() * 0.1; return np.sqrt((e[e > th] ** 2).mean())

# narrator: full house chain on the whole take, then slice
nraw = f"{VD}/{RID}_N.wav"; NW = json.load(open(f"{VD}/{RID}_N_words.json"))
dry = V.chain_dry(nraw); cl = clean_vo(dry, SR); ny, _ = V.restore_soft(cl, dry, V._speech_spans_pre(dry))
kraw = f"{VD}/border_jokes_K.wav"; KW = json.load(open(f"{VD}/border_jokes_K_words.json"))
ky = load48(kraw, "highpass=f=80")
# which K lines belong to this reel: K lines are in global order across reels
kstart = 0
for rid, L in S.items():
    if rid == RID: break
    kstart += sum(len(t.split()) for s, t in L if s == "K")

def cuts(words, sig, idx):
    """slice [start of first word, end of last word] with soft margins at mid-gap"""
    a, b = idx[0], idx[-1]
    s0 = words[a]["start"]; e0 = words[b]["end"]
    pg = s0 - (words[a - 1]["end"] if a > 0 else 0.0); ng = (words[b + 1]["start"] - e0) if b + 1 < len(words) else 0.3
    t0 = max(0.0, s0 - min(0.08, pg / 2)); t1 = e0 + min(0.16, max(0.02, ng / 2))
    seg = sig[int(t0 * SR):int(t1 * SR)].copy(); f = int(0.008 * SR)
    seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
    return seg, t0

clips = []; ni = 0; ki = kstart; nref = None
for spk, txt in S[RID]:
    n = len(txt.split())
    if spk == "N":
        idx = list(range(ni, ni + n)); ni += n; seg, t0 = cuts(NW, ny, idx); k = V.TEMPO; ws = NW
    else:
        idx = list(range(ki, ki + n)); ki += n; seg, t0 = cuts(KW, ky, idx); k = 1.05; ws = KW
    out = ff_tempo(seg, k)
    wl = [dict(w=ws[j]["word"], t0=(ws[j]["start"] - t0) / k, t1=(ws[j]["end"] - t0) / k) for j in idx]
    assert [w["w"] for w in wl] == txt.split(), (wl, txt)
    clips.append(dict(spk=spk, text=txt, y=out, words=wl))
assert ni == len(NW), (ni, len(NW))
nr = arms(np.concatenate([c["y"] for c in clips if c["spk"] == "N"]))
for c in clips:
    if c["spk"] == "K": c["y"] *= nr / arms(c["y"]) * 0.95

# ------------------------------------------------ timeline (gaps + events per format)
ev = []; t = 0.25; lines = []
def place(c, gap_after):
    global t
    lines.append(dict(spk=c["spk"], text=c["text"], t0=round(t + c["words"][0]["t0"], 3), t1=round(t + c["words"][-1]["t1"], 3),
                      words=[dict(w=w["w"], t0=round(t + w["t0"], 3), t1=round(t + w["t1"], 3)) for w in c["words"]], at=t))
    c["at"] = t; t += len(c["y"]) / SR + gap_after
fmt = "knock" if "knock" in RID else ("quiz" if "question" in RID else "collie")
for i, c in enumerate(clips):
    nxt = clips[i + 1] if i + 1 < len(clips) else None
    if fmt == "knock":
        if c["text"] == "Knock knock.":
            ev.append((t, "knock", 0)); t += 0.62
            place(c, 0.12)
        elif c["spk"] == "K": place(c, 0.14 if c["text"].endswith("who?") or c["text"] == "Who's there?" else 0.5)
        else:
            nk = nxt is not None and nxt["text"] == "Knock knock."
            place(c, 0.75 if nk else (0.18 if nxt and nxt["spk"] == "K" else 0.4))
            if nk and len(lines) > 3: ev.append((t - 0.7, "rimshot", 0))
    elif fmt == "quiz":
        txt = c["text"]
        if c["spk"] == "N" and txt.startswith("Question"):
            ev.append((t - 0.05, "pop", 0))
            if nxt and nxt["spk"] == "K": place(c, 0.35)
            else:
                place(c, 0.15); ev.append((t, "ticks", 0)); t += 1.3; ev.append((t, "buzzer", 0)); t += 0.65
        elif c["spk"] == "K":
            place(c, 0.12); ev.append((t, "buzzer", 0)); t += 0.62
        elif txt == "Okay. The answer.":
            place(c, 0.1); ev.append((t, "drumroll", 0)); t += 1.05; ev.append((t, "ding", 0)); t += 0.3
        else: place(c, 0.4)
    else:
        place(c, 0.35)
dur = t + 0.6
vo = np.zeros(int(dur * SR) + SR)
for c in clips:
    i0 = int(c["at"] * SR); vo[i0:i0 + len(c["y"])] += c["y"]
vo = vo[:int(dur * SR)]
sf.write(f"{OUT}/vo_final.wav", vo.astype(np.float32), SR)
for L in lines: L.pop("at")
json.dump(dict(dur=round(dur, 3), lines=lines, events=[(round(a, 3), b, c) for a, b, c in ev]), open(f"{OUT}/timing.json", "w"), indent=0)
print(RID, "dur", round(dur, 2), "lines", len(lines), "events", len(ev))
for k, L in enumerate(lines): print(k, L["spk"], L["t0"], L["t1"], L["text"])
