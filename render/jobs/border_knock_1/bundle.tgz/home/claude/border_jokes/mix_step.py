"""mix_step.py RID: in-house playful bed (reelkit sfx2 marimba, loop clean) + synthesized SFX (knock, rimshot, buzzer, ticks,
drumroll; glass ding and pluck from reelkit/sfx, Kenney CC0) under RID/vo_final.wav -> RID/mix.m4a"""
import sys, os, json, subprocess, numpy as np, soundfile as sf
RID = sys.argv[1]; D = f"/home/claude/border_jokes/{RID}"
sys.path.insert(0, "/home/claude/reelkit"); sys.argv = [sys.argv[0]]
import mix as MX
SR = MX.SR; rng = np.random.default_rng(7)
TM = json.load(open(f"{D}/timing.json")); END = round(TM["dur"] + 0.25, 2)
def env(n, a, d): t = np.arange(n) / SR; return np.minimum(1, t / a) * np.exp(-t / d)
def lp(x, k):
    y = np.zeros_like(x); s = 0.0
    for i in range(len(x)): s += k * (x[i] - s); y[i] = s
    return y
def knock():
    out = np.zeros(int(0.62 * SR))
    for k, t0 in enumerate((0.0, 0.17, 0.34)):
        n = int(0.12 * SR); t = np.arange(n) / SR
        x = (np.sin(2 * np.pi * 150 * t) * 0.8 + np.sin(2 * np.pi * 310 * t) * 0.3) * env(n, 0.002, 0.025)
        x += lp(rng.standard_normal(n), 0.25) * env(n, 0.001, 0.012) * 1.2
        i = int(t0 * SR); out[i:i + n] += x * (1.0 if k < 2 else 1.1)
    return out
def rimshot():
    out = np.zeros(int(1.2 * SR)); t = lambda n: np.arange(n) / SR
    for t0, f in ((0.0, 190), (0.16, 140)):
        n = int(0.18 * SR); x = np.sin(2 * np.pi * f * t(n)) * env(n, 0.002, 0.06) + rng.standard_normal(n) * env(n, 0.001, 0.01) * 0.5
        out[int(t0 * SR):int(t0 * SR) + n] += x
    n = int(0.8 * SR); hp = rng.standard_normal(n); hp = hp - lp(hp, 0.3)
    out[int(0.32 * SR):int(0.32 * SR) + n] += hp * env(n, 0.002, 0.22) * 0.7
    return out
def buzzer():
    n = int(0.55 * SR); t = np.arange(n) / SR
    x = np.sign(np.sin(2 * np.pi * 98 * t)) * 0.5 + np.sign(np.sin(2 * np.pi * 147 * t)) * 0.35
    return lp(x, 0.2) * np.minimum(1, t / 0.01) * np.minimum(1, (0.55 - t) / 0.05)
def ticks(sec=1.3):
    out = np.zeros(int(sec * SR)); n = int(0.03 * SR); t = np.arange(n) / SR
    for k in range(int(sec / 0.25)):
        f = 2400 if k % 2 == 0 else 1800; x = np.sin(2 * np.pi * f * t) * env(n, 0.0005, 0.006)
        out[int(k * 0.25 * SR):int(k * 0.25 * SR) + n] += x
    return out
def drumroll(sec=1.05):
    out = np.zeros(int(sec * SR)); n = int(0.05 * SR)
    k = 0; t0 = 0.0
    while t0 < sec - 0.06:
        x = lp(rng.standard_normal(n), 0.35) * env(n, 0.001, 0.02) * (0.5 + 0.5 * t0 / sec)
        out[int(t0 * SR):int(t0 * SR) + n] += x; t0 += 0.045; k += 1
    return out
SYN = {"knock": (knock, 6), "rimshot": (rimshot, -2), "buzzer": (buzzer, -1), "ticks": (ticks, -4), "drumroll": (drumroll, 0)}
vo, sr = sf.read(f"{D}/vo_final.wav"); dur = END
m = MX._mod(*MX.BEDS["playful"][:2]); n = int(dur * SR); f = int(0.8 * SR)
x = np.asarray(m.music_playful(dur + 4.5, dur + 20), np.float64)
if x.ndim == 1: x = np.vstack([x, x])
if x.shape[0] != 2: x = x.T
music = x[:, :n].copy()
music[:, :f] = x[:, :f] * np.sin(np.linspace(0, np.pi / 2, f)) + x[:, n:n + f] * np.cos(np.linspace(0, np.pi / 2, f))
music /= np.abs(music).max() + 1e-12
ev = []
for t0, kind, xdb in TM["events"]:
    if kind in SYN: fn, db = SYN[kind]; ev.append((t0, fn(), xdb + db))
    else: ev.append((t0, kind, xdb))
if RID == "border_collie":
    L = TM["lines"]
    for li in (1, 3, 4, 5, 10): ev.append((L[li]["t0"] - 0.1, "pop", 0))
    ev.append((L[3]["words"][-2]["t0"], "ding", 0))
    for li in (6, 7, 8, 9): ev.append((L[li]["t0"] - 0.15, "whoosh", 0))
if RID.startswith("border_knock"):
    L = TM["lines"]
    for k, l in enumerate(L):
        if l["spk"] == "K" and l["text"] == "Who's there?": pass
rep = MX.mix(vo, dur, music, ev, f"{D}/mix.wav", music_db=-17.0 if "question" not in RID else -19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{D}/mix.m4a"], check=True)
os.remove(f"{D}/mix.wav"); print(RID, rep)
