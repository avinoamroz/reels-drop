# -*- coding: utf-8 -*-
"""Wikipedia and Zionism: one generic encyclopedia page (no logos) whose first line is edited live, a year counter,
a 2007 to 2026 timeline of documented edits and decisions, comment bubble trigger at frame 0, loop into frame 0.
usage: page.py [--snaps=0,1,3,...]"""
import sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, "/home/claude/wiki_zionism")
from ck import *

rid = "wiki_zionism"; T = Timing(rid); DUR = round(T.dur + 0.9, 2)
SERIF = "/home/claude/wiki_zionism/Lora-Variable.ttf"
_sf = {}
def sfont(sz, wt="Regular"):
    k = (int(sz), wt)
    if k not in _sf:
        f = ImageFont.truetype(SERIF, k[0]); f.set_variation_by_name(wt); _sf[k] = f
    return _sf[k]

# ------------------------------------------------------------------ page texts (short quotes, under 15 words)
# each: list of (word, colour key). hl keys: n normal, y yellow highlight, g green, s sky
S_NOW = [("Zionism", "b"), ("is", "n"), ("an", "n"), ("ethnic", "n"), ("nationalist", "n"), ("movement", "n"), ("...", "n"),
         ("a", "n"), ("Jewish", "n"), ("homeland", "n"), ("through", "y"), ("colonization.", "y")]
S_2007 = [("Zionism", "b"), ("...", "n"), ("supports", "n"), ("a", "n"), ("homeland", "g"), ("for", "g"), ("the", "g"), ("Jewish", "g"),
          ("people", "g"), ("in", "n"), ("the", "n"), ("Land", "s"), ("of", "s"), ("Israel.", "s")]
S_2024 = [("Zionism", "b"), ("is", "n"), ("an", "n"), ("ethno-cultural", "n"), ("nationalist", "n"), ("movement", "n"), ("...", "n"),
          ("colonization", "y"), ("of", "y"), ("a", "y"), ("land", "y"), ("outside", "y"), ("of", "y"), ("Europe.", "y")]
S_BRIT = [("Zionism,", "b"), ("Jewish", "n"), ("nationalist", "n"), ("movement", "n"), ("...", "n"), ("creation", "n"), ("and", "n"),
          ("support", "n"), ("of", "n"), ("a", "g"), ("Jewish", "g"), ("national", "g"), ("state.", "g")]
COL = dict(n=WHITE, b=WHITE, y=YEL, g=GREEN, s=SKY_L)
LZ, LLH = 64, 86                         # lead text size and line height
PX0, PX1, PY0, PY1 = 56, 1024, 560, 1112   # page panel
TX0, TMAXW = 100, 880
def layout(S):
    """word boxes [(x, y_line, word, key)] wrapped inside the page"""
    out, x, ln = [], 0, 0
    for w, k in S:
        f = sfont(LZ, "Bold" if k == "b" else "Regular"); wl = f.getlength(w); sp = f.getlength(" ")
        if x > 0 and x + wl > TMAXW: x, ln = 0, ln + 1
        out.append((x, ln, w, k, wl)); x += wl + sp
    return out
LAY = {id(S): layout(S) for S in (S_NOW, S_2007, S_2024, S_BRIT)}
def nchars(S): return sum(len(w) + 1 for w, _ in S)
def draw_lead(d, S, frac, strike=0.0, cursor=True, t=0.0, y0=790):
    """draw first frac of the characters of S; strike = fraction of words struck in red"""
    L = LAY[id(S)]; tot = nchars(S); n = int(round(frac * tot)); used = 0; cx, cy = TX0, y0
    nst = int(round(strike * len(L)))
    for i, (x, ln, w, k, wl) in enumerate(L):
        if used >= n: break
        part = w[:max(0, n - used)]; used += len(w) + 1
        f = sfont(LZ, "Bold" if k == "b" else "Regular"); col = COL[k]
        px, py = TX0 + x, y0 + ln * LLH
        if k in ("y", "g", "s") and part:
            pl = f.getlength(part)
            d.rounded_rectangle([px - 2, py + LZ + 14, px + pl + 2, py + LZ + 21], 3, fill=col)
        d.text((px, py), clean(part), font=f, fill=col)
        pl = f.getlength(part); cx, cy = px + pl + 4, py
        if i < nst:
            d.rounded_rectangle([px - 4, py + LZ * 0.55, px + wl + 4, py + LZ * 0.55 + 6], 3, fill=RED)
    if cursor and (int(t * 2.2) % 2 == 0 or 0 < frac < 1):
        d.rectangle([cx, cy + 4, cx + 5, cy + LZ + 8], fill=SKY)

# ------------------------------------------------------------------ timings
t2, t3, t4 = T.at(2), T.at(3), T.at(4); t4a = T.at("4:a homeland"); t4e = T.at("4$")
t5, t5r = T.at(5), T.at("5:Most"); t6 = T.at(6); t6c = T.at("6:Colonization."); t7 = T.at(7); t8 = T.at(8)
t9 = T.at(9); t9b = T.at("9:The co-founder"); t10 = T.at(10); t11 = T.at(11); t11b = T.at("11:Britannica."); t12 = T.at(12)
t12e = T.at("12$"); t13 = T.at(13); t14 = T.at(14)
def lerp(t, a, b, va, vb): return va + (vb - va) * ease((t - a) / max(1e-6, b - a))
def state(t):
    """-> (S, frac, strike, year, label)"""
    if t < t2: return S_NOW, 1.0, 0, 2026, "First line, today"
    if t < t4a:   # rewind: delete today's line, year counts down
        fr = 1 - min(1, (t - t2) / max(0.6, (t3 + 0.6 - t2)))
        return S_NOW, max(0, fr), 0, round(lerp(t, t2, t4, 2026, 2007)), "Rewinding the edits"
    if t < t5: return S_2007, min(1, (t - t4a) / max(0.5, t4e - t4a)), 0, 2007, "First line, 2007"
    if t < t6:
        return S_2007, 1.0, min(0.8, max(0, (t - t5r) / 1.6) * 0.8), round(lerp(t, t5, t5r, 2007, 2023)), "First line, 2023"
    if t < t11:
        y = 2024 if t < t8 else 2025
        if t < t6 + 0.5: return S_2007, 1 - (t - t6) / 0.5, 0.8, y, "First line, 2024"
        return S_2024, min(1, (t - t6 - 0.5) / max(0.5, t6c + 0.55 - t6 - 0.5)), 0, y, f"First line, {y}"
    if t < t11b + 0.1: return S_2024, max(0, 1 - (t - t11) / 0.6), 0, 2026, "Another encyclopedia"
    return S_BRIT, min(1, (t - t11b - 0.1) / max(0.5, t12e - 0.6 - t11b)), 0, 2026, "Britannica, 2026"

# events on the timeline: (start, year position, date label, text lines, colour, source)
EV = [
    (t4, 2007, "2007", "The article's first line", WHITE, "Source: 2007 Schools Wikipedia Selection (archived copy)"),
    (t5, 2023.77, "7 October 2023", None, WHITE, "Source: Quillette analysis of the article history, Oct 2026"),
    (t6, 2024.7, "2024", "Colonization enters the first line", YEL, "Source: Israel Hayom, Sep 2024; Wikipedia, Nov 2026"),
    (t7, 2024.45, "June 2024", "ADL rated unreliable on the conflict", WHITE, "Source: CNN, June 2024"),
    (t8, 2025.07, "January 2025", "8 editors banned: 6 pro Palestinian, 2 pro Israel", WHITE, "Source: Times of Israel, Feb 2025"),
    (t9, 2025.65, "August 2025", "US House Oversight asks for records", WHITE, "Source: House Oversight letter, 27 Aug 2025"),
    (t9b, 2025.84, "November 2025", "Co-founder Jimmy Wales: Gaza article breaks neutrality", WHITE, "Source: Semafor; Al Jazeera, Nov 2025"),
    (t10, 2025.9, "The foundation's reply", "\"We take bias claims seriously\"", SKY_L, "Source: Wikimedia Foundation via Jewish Insider, 2025"),
    (t11, 2026.8, "The definition", "Encyclopaedia Britannica", GREEN, "Source: Encyclopaedia Britannica, Zionism, 2026"),
]
TL_X0, TL_X1, TL_Y = 110, 970, 1178
def tl_x(y):
    y = min(2026.9, max(2007, y)); u = (y - 2007) / 16 * 0.3 if y < 2023 else 0.3 + (y - 2023) / 3.9 * 0.7
    return TL_X0 + (TL_X1 - TL_X0) * u

COMMENT = "Zionism? Yuck. I don't need to understand it. I know what it means."
def draw_comment(im, t, a):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    x0, y0, x1 = 70, 1146, 1010
    lines = wrap(COMMENT, 58, 780, 700); h = 62 + 70 * len(lines) + 24
    d.rounded_rectangle([x0, y0, x1, y0 + h], 34, fill=(30, 44, 78, int(250 * a)), outline=SILVER[:3] + (int(120 * a),), width=2)
    d.ellipse([x0 + 26, y0 + 24, x0 + 106, y0 + 104], fill=GREY[:3] + (int(255 * a),))
    d.ellipse([x0 + 50, y0 + 38, x0 + 82, y0 + 70], fill=(30, 44, 78, int(255 * a)))   # generic silhouette
    d.pieslice([x0 + 38, y0 + 72, x0 + 94, y0 + 128], 180, 360, fill=(30, 44, 78, int(255 * a)))
    txt(d, x0 + 130, y0 + 22, "A comment I got", 40, SILVER, 700, "la", a)
    nc = len(COMMENT); used = 0
    for i, l in enumerate(lines):
        part = l[:max(0, nc - used)]; used += len(l) + 1
        if part: txt(d, x0 + 130, y0 + 74 + 70 * i, part, 58, WHITE, 700, "la", a)
    im.alpha_composite(lay)

SUBS = sub_chunks(T, [("Two thousand seven", "2007"), ("Twenty twenty four", "2024"), ("Twenty twenty five", "2025"),
                      ("October seventh", "October 7"), ("eight editors", "8 editors")])

out = Out(rid, DUR, snaps_arg())
for f, t in out.frames():
    im = stage(); d = ImageDraw.Draw(im)
    yh = hook(d, ["You hate Zionism.", "Can you define it?"], t, y=226, sz=108)
    txt(d, W / 2, yh + 2, "One first line. 2007 to today.", 56, SILVER, 700, "ma")
    S, frac, strike, year, label = state(t)
    # page panel
    glow = 0.0
    if t3 <= t < t4: glow = 0.5 + 0.5 * math.sin((t - t3) * 6)
    d.rounded_rectangle([PX0, PY0, PX1, PY1], 30, fill=(22, 36, 70, 255), outline=(SKY[:3] + (int(90 + 165 * glow),)), width=3 + int(3 * glow))
    d.text((TX0, PY0 + 30), "Zionism", font=sfont(84, "Bold"), fill=WHITE)
    ys = str(year); txt(d, PX1 - 44, PY0 + 34, ys, 84, YEL, 900, "ra")
    txt(d, TX0, PY0 + 128, label, 44, SILVER, 700, "la")
    d.rectangle([TX0, PY0 + 186, PX1 - 44, PY0 + 189], fill=(90, 112, 150, 255))
    draw_lead(d, S, frac, strike, True, t, y0=PY0 + 208)
    # bottom zone: comment first, then the timeline
    ca = 1.0 if t < t4 - 0.3 else max(0, 1 - (t - (t4 - 0.3)) / 0.3)
    if ca > 0: draw_comment(im, t, ca); d = ImageDraw.Draw(im)
    if ca < 1:
        a = 1 - ca
        d.rounded_rectangle([TL_X0, TL_Y - 4, TL_X1, TL_Y + 4], 4, fill=(70, 92, 130, int(255 * a)))
        for yy in (2007, 2023, 2024, 2025, 2026):
            x = tl_x(yy); txt(d, x, TL_Y + 16, str(yy), 40, GREY, 700, "ma", a)
        on = [e for e in EV if e[0] <= t]
        for e in on:
            x = tl_x(e[1]); r = 13
            d.ellipse([x - r, TL_Y - r, x + r, TL_Y + r], fill=e[4][:3] + (int(255 * a),))
        cur = on[-1] if on else None
        # playhead follows the page year
        px = tl_x(year + (0.5 if year >= 2024 else 0)); d.polygon([(px - 14, TL_Y - 36), (px + 14, TL_Y - 36), (px, TL_Y - 14)], fill=YEL[:3] + (int(255 * a),))
        if cur:
            ea = a * min(1, (t - cur[0]) / 0.3)
            txt(d, W / 2, 1246, cur[2], 50, YEL if cur[4] != SKY_L else SKY_L, 800, "ma", ea)
            if cur[3] is None:   # rewrite counter
                pc = int(round(80 * min(1, max(0, (t - t5r) / 1.6))))
                s = f"About {pc}% of the article rewritten"; txt(d, W / 2, 1308, s, fit(s, 60, 960, 800, 48), cur[4], 800, "ma", ea)
            else:
                ls = wrap(cur[3], 60, 940, 800)
                for i, l in enumerate(ls[:2]): txt(d, W / 2, 1306 + 66 * i, l, 60, cur[4], 800, "ma", ea)
            source(d, cur[5])
    else:
        source(d, "First line: Wikipedia, Zionism article, 3 Nov 2026. Comment anonymised.")
    draw_sub(im, SUBS, t)
    out.put(f, t, im)
out.close()
