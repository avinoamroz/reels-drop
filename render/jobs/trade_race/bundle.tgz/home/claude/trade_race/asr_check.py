import sys, json; sys.path.insert(0, "/home/claude/reelkit"); import asr
lines = [l.strip() for l in open("/home/claude/trade_race/tts.txt") if l.strip()]
x16 = asr.load16(sys.argv[1]); W = json.load(open("/home/claude/trade_race/vo_words.json"))
spans = [(min(w["start"] for w in W if w["line"] == i), max(w["end"] for w in W if w["line"] == i)) for i in range(len(lines))]
out, texts = asr.isolated("check_audio", x16, lines, spans)
bad = 0
for d in out:
    flag = "" if not d["missing"] else "  <-- MISSING " + str(d["missing"]); bad += bool(d["missing"])
    print(f'{d["recall"]:.2f} | {d["heard"]}{flag}')
json.dump(out, open(sys.argv[2], "w"), indent=1); print("lines with missing words:", bad)
