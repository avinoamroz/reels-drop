#!/bin/bash
# music bed (p_t10 extended by a crossfaded loop) ducked under the voice -> mix.m4a, -14 LUFS
set -e; cd /home/claude/trade_race; M=/home/claude/vid/music/p_t10.wav; T=49.6
ffmpeg -v error -y -i $M -ss 8 -t 12 -i $M -filter_complex "[0:a][1:a]acrossfade=d=2:c1=tri:c2=tri,atrim=0:$T,afade=t=out:st=$(echo "$T-0.8"|bc):d=0.8,volume=-17dB,aresample=48000[bed]" -map "[bed]" -ac 2 bed.wav
ffmpeg -v error -y -i vo.wav -i bed.wav -filter_complex "[0:a]apad,atrim=0:$T,aformat=channel_layouts=stereo,asplit[v][sc];[1:a][sc]sidechaincompress=threshold=0.03:ratio=4:attack=20:release=350[b];[v][b]amix=inputs=2:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11" -ar 48000 -c:a aac -b:a 192k mix.m4a
rm bed.wav
ffmpeg -v error -i mix.m4a -af ebur128=peak=true -f null - 2>&1 | tail -0
