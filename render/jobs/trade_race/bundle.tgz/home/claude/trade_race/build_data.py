"""Build data.json for the trade race: Israel's goods exports by destination and imports by origin, current US$ million.
1949-1995: Correlates of War Trade v4.0 (Barbieri & Keshk 2016, built on IMF DOTS), via peacesciencer cow_trade_ndy (git blob of
           svmiller/peacesciencer data/cow_trade_ndy.rda, commit 327a19e^), extract in cow_israel_flows.csv.
           West Germany 1960-1989 is missing in that file: filled from TIME 1969 (1968 values), JTA 1983 (1982 exports),
           bpb APuZ 1990 (1988 values, DM at 1.76 per US$), geometric interpolation between them, flagged est.
1996-2023: WITS (UN Comtrade, Israel-reported) top-5 partner lists; 2025: UN Comtrade shares via Lloyds Bank trade portal
           and worldstopexports values. 'Unspecified' and 'Bunkers' rows are not countries and are left out.
"""
import json, math
import pandas as pd
D = "/home/claude/trade_race"
COW = {2: "United States", 200: "United Kingdom", 210: "Netherlands", 211: "Belgium", 220: "France", 225: "Switzerland",
       325: "Italy", 740: "Japan", 710: "China", 640: "Turkey", 205: "Ireland", 750: "India", 390: "Denmark", 560: "South Africa",
       20: "Canada", 380: "Sweden", 375: "Finland", 315: "Czechoslovakia", 290: "Poland", 350: "Greece", 630: "Iran", 345: "Yugoslavia"}
t = pd.read_csv(f"{D}/cow_israel_flows.csv")
X, M = {}, {}
def put(S, n, y, v, est=False):
    S.setdefault(n, {})[int(y)] = {"v": round(float(v), 1), **({"est": True} if est else {})}
# all COW partners 1949..1995 (so the top 4 is the true top 4 among states in the file)
for (p, y), r in t[(t.year >= 1949) & (t.year <= 1995)].groupby(["p", "year"]):
    r = r.iloc[0]; n = COW.get(int(p), f"cow{int(p)}")
    if int(p) in (255, 260): n = "Germany"
    if r.exp == r.exp: put(X, n, y, r.exp)
    if r.imp == r.imp: put(M, n, y, r.imp)
# West Germany gap 1960..1989: real anchor points + geometric interpolation (est.)
GER_X = {1959: X["Germany"][1959]["v"], 1968: 56.0, 1982: 400.0, 1988: round(1260 / 1.76, 1), 1990: X["Germany"][1990]["v"]}
GER_M = {1959: M["Germany"][1959]["v"], 1968: 115.0, 1988: round(2330 / 1.76, 1), 1990: M["Germany"][1990]["v"]}
def geo(anch, y):
    ks = sorted(anch); a = max(k for k in ks if k <= y); b = min(k for k in ks if k >= y)
    if a == b: return anch[a]
    return anch[a] * (anch[b] / anch[a]) ** ((y - a) / (b - a))
for S, A in ((X, GER_X), (M, GER_M)):
    for y in range(1960, 1990):
        put(S, "Germany", y, geo(A, y), est=y not in A)
# WITS / Comtrade, Israel-reported (US$ million)
WX = {1996: {"United States": 6281, "United Kingdom": 1365, "Japan": 1216, "Belgium": 1123, "Hong Kong": 1066},
      2000: {"United States": 11734, "Belgium": 1873, "Germany": 1521, "Hong Kong": 1384},
      2005: {"United States": 15499, "Belgium": 3680, "Hong Kong": 2374, "United Kingdom": 1650},
      2010: {"United States": 18488, "Hong Kong": 3915, "Belgium": 3117, "India": 2890, "United Kingdom": 2270},
      2013: {"United States": 17505, "Hong Kong": 5378, "United Kingdom": 3853, "Belgium": 3118},
      2016: {"United States": 17598, "Hong Kong": 4436, "United Kingdom": 3909, "China": 3328},
      2019: {"United States": 15959, "United Kingdom": 4992, "China": 4422, "Hong Kong": 3041},
      2021: {"United States": 16323, "China": 4398, "India": 2735, "Netherlands": 2234},
      2023: {"United States": 17332, "Ireland": 3422, "China": 3400, "Netherlands": 2399, "India": 2240},
      2025: {"United States": 16100, "Germany": 3000, "China": 2800, "Netherlands": 2600, "India": 2500, "Hong Kong": 2000,
             "Ireland": 1530, "United Kingdom": 1520, "France": 1410, "Belgium": 1330, "Italy": 1290}}
MT25 = 95481  # Comtrade/WTO 2025 imports, US$ million; shares from the Lloyds Bank trade portal (Comtrade 2026)
WM = {1996: {"United States": 5966, "Belgium": 3638, "Germany": 2801, "United Kingdom": 2633, "Italy": 2258},
      2000: {"United States": 6641, "Belgium": 3547, "United Kingdom": 2712, "Germany": 2672},
      2005: {"United States": 6065, "Belgium": 4558, "Germany": 2987, "United Kingdom": 2552},
      2010: {"United States": 6703, "China": 4737, "Germany": 3679, "Belgium": 3576},
      2013: {"United States": 8159, "China": 5660, "Germany": 4666, "Switzerland": 4397},
      2016: {"United States": 8098, "China": 5896, "Switzerland": 4288, "Germany": 4069, "Belgium": 3914},
      2019: {"United States": 12825, "China": 10235, "Germany": 4833, "Turkey": 3998},
      2021: {"China": 10728, "United States": 8638, "Switzerland": 6618, "Germany": 6561},
      2023: {"China": 16329, "United States": 9686, "Germany": 5649, "Turkey": 5272},
      2025: {k: round(MT25 * s / 100) for k, s in {"China": 21.8, "United States": 10.5, "Germany": 6.2, "Italy": 4.2, "South Korea": 2.6,
             "France": 2.5, "India": 2.3, "United Kingdom": 2.2, "Turkey": 2.2, "Netherlands": 1.6, "Belgium": 1.6, "Switzerland": 1.5}.items()}}
TOT = {"X": {1996: 20510, 2000: 31407, 2005: 42771, 2010: 58413, 2013: 66781, 2016: 60571, 2019: 58488, 2021: 60160, 2023: 58905, 2025: 59010},
       "M": {1996: 29949, 2000: 35742, 2005: 45032, 2010: 59194, 2013: 71995, 2016: 65803, 2019: 76579, 2021: 92159, 2023: 91877, 2025: 95481}}
for S, W in ((X, WX), (M, WM)):
    for y, row in W.items():
        for n, v in row.items(): put(S, n, y, v)
for k, S in (("X", X), ("M", M)):
    for y in range(1949, 1996):
        TOT[k][y] = round(sum(S[n][y]["v"] for n in S if y in S[n]), 1)
src = {
 "cow": {"name": "Correlates of War Trade v4.0 (Barbieri and Keshk 2016; built on IMF Direction of Trade Statistics), current US$ million, via peacesciencer cow_trade_ndy",
         "url": "https://correlatesofwar.org/data-sets/bilateral-trade/", "file": "https://github.com/svmiller/peacesciencer/blob/327a19e^/data/cow_trade_ndy.rda",
         "years": "1949-1995", "note": "Israel exports = partner imports from Israel (flow), imports = Israel imports from partner. Hong Kong is not a COW state and is absent. West Germany 1960-1989 absent in this file."},
 "wits": {"name": "World Bank WITS country profile (UN Comtrade, Israel-reported), top 5 partners", "years": "1996-2023",
          "urls": {str(y): f"https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/{y}/Summary{'text' if y in (1996, 2000, 2005, 2010, 2013, 2019) else ''}" for y in WX if y != 2025}},
 "comtrade2025": {"name": "UN Comtrade 2025 shares (Lloyds Bank trade portal), export values (worldstopexports.com)",
                  "urls": ["https://www.lloydsbanktrade.com/en/market-potential/israel/trade-profile", "https://www.worldstopexports.com/israels-top-trading-partners/"]},
 "germany_gap": {"1968": "https://time.com/archive/6636859/trade-should-an-israeli-buy-a-volkswagen/",
                 "1982": "https://jta.org/archive/israeli-exports-to-germany-amounted-to-some-400",
                 "1988": "https://www.bpb.de/shop/zeitschriften/apuz/archiv/535204/verbindungen-in-die-zukunft-25-jahre-diplomatische-beziehungen-zwischen-deutschland-und-israel/",
                 "dm_rate_1988": "https://marcuse.faculty.history.ucsb.edu/projects/currency.htm"},
}
out = {"unit": "current US$ million, goods incl. diamonds", "exports": X, "imports": M, "totals": TOT, "sources": src}
json.dump(out, open(f"{D}/data.json", "w"), indent=0)
def top(S, y, k=5):
    r = sorted(((S[n][y]["v"], n + ("*" if S[n][y].get("est") else "")) for n in S if y in S[n]), reverse=True)[:k]
    return [(n, round(v)) for v, n in r]
for y in [1949, 1950, 1955, 1957, 1960, 1965, 1966, 1967, 1968, 1970, 1975, 1980, 1985, 1990, 1995, 1996, 2000, 2010, 2016, 2019, 2021, 2023, 2025]:
    print(y, "X", top(X, y)); print("     M", top(M, y))
