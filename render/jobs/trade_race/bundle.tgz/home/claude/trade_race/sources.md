# Israel trade race: sources and data notes

Values: Israel's trade in goods, current US$ million, diamonds included, services excluded. Built by `build_data.py` into `data.json`.

## 1949 to 1995: Correlates of War Trade v4.0
- Barbieri, Katherine and Omar Keshk (2016). Correlates of War Project Trade Data Set Codebook, Version 4.0. Built on IMF Direction of Trade Statistics. https://correlatesofwar.org/data-sets/bilateral-trade/
- File used: `cow_trade_ndy` from the R package peacesciencer (git blob `data/cow_trade_ndy.rda` at commit 327a19e^ of https://github.com/svmiller/peacesciencer). Israel rows extracted to `cow_israel_flows.csv`.
- Exports = partner's imports from Israel; imports = Israel's imports from the partner.
- Gaps: Hong Kong is not a COW state, so it is absent before 1996. West Germany (COW code 260) has Israel rows only for 1955 to 1959; 1949 to 1954 and 1960 to 1989 are missing.

## West Germany 1960 to 1989 (estimate, shown as "est." on screen)
Real points, geometric interpolation between them:
- 1968: West Germany bought $56M of Israeli goods; Israel imported $115M from West Germany. TIME, 11 Apr 1969: https://time.com/archive/6636859/trade-should-an-israeli-buy-a-volkswagen/
- 1982: Israeli exports to Germany about $400M. JTA, 4 Jan 1983: https://jta.org/archive/israeli-exports-to-germany-amounted-to-some-400
- 1988: German exports to Israel DM 2.33bn, imports from Israel DM 1.26bn (bpb, APuZ 1990): https://www.bpb.de/shop/zeitschriften/apuz/archiv/535204/verbindungen-in-die-zukunft-25-jahre-diplomatische-beziehungen-zwischen-deutschland-und-israel/ converted at DM 1.76 per US$ (1988 average, Officer, Historical Statistics of the US): https://marcuse.faculty.history.ucsb.edu/projects/currency.htm
- Same bpb article: Germany has been Israel's #2 trading partner (after the US) since 1976.

## 1996 to 2023: World Bank WITS (UN Comtrade, Israel-reported), top 5 partners per year
- 1996 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/1996/Summarytext
- 2000 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2000/Summarytext
- 2005 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2005/Summarytext
- 2010 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2010/Summarytext
- 2013 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2013/Summarytext
- 2016 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2016/Summary
- 2019 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2019/Summarytext
- 2021 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2021/Summary
- 2023 https://wits.worldbank.org/CountryProfile/en/Country/ISR/Year/2023/Summary
- "Unspecified" and "Bunkers" rows are not countries and are left out (Bunkers in imports is mostly fuel).
- Only the top 5 are published per year. A country missing from a year's list is drawn from its own neighbouring values, capped under that year's 4th listed value, so the top 4 at each data year is exactly the published one.

## 2025: UN Comtrade
- Shares (exports and imports) and totals: Lloyds Bank trade portal, source Comtrade 2026 / WTO: https://www.lloydsbanktrade.com/en/market-potential/israel/trade-profile (imports = share x $95,481M)
- Export values: https://www.worldstopexports.com/israels-top-trading-partners/

## Context sources
- 1950 top destinations (UK about $11M, US about $8M), Israel Export Institute via Agri Portal, 26 Apr 2012: https://www.israel.agrisupportonline.com/news/csv/csvread.pl?show=2793&mytemplate=tp2
- CBS Israel at 70: US share of imports about 35% in 1950, 12% in 2017: https://www.cbs.gov.il/en/Statistical/stat171e.pdf
- US-reported US-Israel trade 1948 to 2024: https://jewishvirtuallibrary.org/u-s-israel-bilateral-trade-statistics-1948-present
- China and Hong Kong 2024 (CBS, excl. diamonds): https://www.inss.org.il/publication/israel-china-2024/

## Caveats
- COW (mirror, CIF) and Comtrade (Israel-reported, exports FOB) are different series; the switch is at 1995/1996.
- Between data years bars move by linear interpolation.
- Not checked: UAE never reaches the top 4 (2025: 1.1% of exports, under 1.2% of imports).
