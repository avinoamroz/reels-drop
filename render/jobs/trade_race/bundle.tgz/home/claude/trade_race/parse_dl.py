"""parse every Drive download (tool-results JSON) whose title is trade_race_lNN.txt into vo/lNN.wav + _words.json; delete the download"""
import glob, json, os, re, subprocess
for f in glob.glob("/root/.claude/projects/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/tool-results/mcp-Google_Drive-download_file_content-*.txt"):
    try: t = json.load(open(f)).get("title", "")
    except Exception: continue
    m = re.match(r"trade_race_(l\d\d)\.txt", t)
    if not m: continue
    r = subprocess.run(["python3", "/home/claude/tts_api/sse_parse.py", f, f"/home/claude/trade_race/vo/{m.group(1)}"], capture_output=True, text=True)
    print(m.group(1), r.stdout.strip(), r.stderr.strip()[-200:])
    if r.returncode == 0: os.remove(f)
