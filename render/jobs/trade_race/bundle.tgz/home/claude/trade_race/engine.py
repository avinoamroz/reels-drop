"""Israel trade race reel (@noamroz__): exports race, then imports race. English only, big text, IG safe zones.
data: /home/claude/trade_race/data.json (see build_data.py, sources.md). audio: /home/claude/trade_race/mix.m4a (voice + bed).
usage: python3 engine.py            -> /home/claude/trade_race/out/trade_race.mp4
       python3 engine.py --snaps 0,5,12 --snapdir DIR   -> PNG stills only
Layout: content x 64..900 (right 180 clear), nothing below y 1540 (bottom 380 clear)."""
import sys, os, json, math, subprocess, argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--snapdir"); A = ap.parse_args()
D = "/home/claude/trade_race"; FONTD = "/home/claude/vid/fonts"
W, H, FPS, S = 1080, 1920, 30, 2
X0, X1 = 64, 900; CX = (X0 + X1) / 2
T_TOTAL = 49.6; T_ENDC = 48.75; T_SWITCH = 22.0
def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
NAVY_T, NAVY_B = hx("#0B1A33"), hx("#163260"); BLUE = hx("#2A88D4"); BLUE_L = hx("#59A5DF")
GOLD = hx("#B8923F"); GOLD2 = hx("#E6C77E"); SILVER = hx("#D9DDE3"); SILVER2 = hx("#A9B6CB"); WHITE = hx("#FFFFFF")
_fc = {}
def font(sz, w=800):
    k = (int(sz * S), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTD}/Heebo-{w}.ttf", k[0])
    return _fc[k]
def clean(s):
    for d in ("–", "—", "‒", "―"): s = s.replace(d, ",")
    return s
def tw(s, sz, w=800): return font(sz, w).getlength(s) / S
def fit(s, sz, maxw, w=800, mn=None):
    mn = mn or sz * 0.9
    while tw(s, sz, w) > maxw and sz > mn: sz -= 1
    return sz
def txt(d, x, y, s, sz, col, w=800, anchor="la", alpha=1.0):
    d.text((x * S, y * S), clean(s), font=font(sz, w), fill=col[:3] + (int(col[3] * max(0, min(1, alpha))),), anchor=anchor)
def ease(u): u = max(0, min(1, u)); return u * u * (3 - 2 * u)

# ------------------------------------------------------------------ data
J = json.load(open(f"{D}/data.json"))
FLAG = {"United States": "us", "United Kingdom": "gb", "Germany": "de", "Netherlands": "nl", "Belgium": "be", "France": "fr",
        "Switzerland": "ch", "Italy": "it", "Japan": "jp", "China": "cn", "Turkey": "tr", "Ireland": "ie", "India": "in",
        "Denmark": "dk", "South Africa": "za", "Canada": "ca", "Sweden": "se", "Finland": "fi", "Hong Kong": "hk", "South Korea": "kr", "Yugoslavia": "yu"}
SHORT = {"United States": "USA", "United Kingdom": "UK", "Netherlands": "Netherlands", "South Africa": "S. Africa", "Switzerland": "Switzerland"}
COL = {"United States": "#2A88D4", "United Kingdom": "#D9DDE3", "Germany": "#E6C77E", "China": "#E0604A", "Belgium": "#B8923F",
       "Hong Kong": "#59A5DF", "Ireland": "#8FD0A0", "Turkey": "#C98A8A", "Japan": "#F0D9A8", "France": "#8FB8E8", "Italy": "#CFAE62",
       "Switzerland": "#A9B6CB", "India": "#E8B07A", "Netherlands": "#E89A5A"}
ANCH = [1996, 2000, 2005, 2010, 2013, 2016, 2019, 2021, 2023, 2025]
def series(S_):
    """per country sorted [(year, v, est)]; at WITS/Comtrade years (top lists only) a country without a value gets its own
    interpolation, capped under that year's 4th listed value, so the ranking at every data year is the published one"""
    raw = {n: {int(y): (p["v"], p.get("est", False)) for y, p in S_[n].items()} for n in S_}
    for y in ANCH:
        listed = sorted([raw[n][y][0] for n in raw if y in raw[n]], reverse=True)
        cap = 0.97 * listed[3]
        for n, P in raw.items():
            if y in P: continue
            ks = sorted(P)
            if not ks or ks[0] > y: continue
            lo = max(k for k in ks if k < y); hi = [k for k in ks if k > y]
            v = P[lo][0] if not hi else P[lo][0] + (P[hi[0]][0] - P[lo][0]) * (y - lo) / (hi[0] - lo)
            P[y] = (min(v, cap), True)
    return {n: sorted((y, v, e) for y, (v, e) in P.items()) for n, P in raw.items()}
RACE = {"X": series(J["exports"]), "M": series(J["imports"])}
TOT = {k: sorted((int(y), v) for y, v in J["totals"][k].items()) for k in ("X", "M")}
def val(pts, y):
    if not pts or y < pts[0][0] - 1e-6: return 0.0
    if y <= pts[0][0]: return pts[0][1]
    if y >= pts[-1][0]: return pts[-1][1]
    ys = [p[0] for p in pts]; i = max([j for j in range(len(ys)) if ys[j] <= y + 1e-9] + [0])
    i = min(i, len(pts) - 2); a, b = pts[i], pts[i + 1]; return a[1] + (b[1] - a[1]) * (y - a[0]) / (b[0] - a[0])
def is_est(pts, y):
    near = [p for p in pts if abs(p[0] - y) < 0.5]
    return bool(near and near[0][2]) and 1959.5 < y < 1989.5
def fmt(v):
    if v >= 1000: return f"${v / 1000:.1f}B"
    return f"${v:.0f}M"

# ------------------------------------------------------------------ timeline (times from vo_words.json, see stitch.py)
TL = {"X": [(1949, 0.0), (1949, 4.7), (1966, 8.4), (1996, 11.6), (2013, 13.9), (2023, 15.0), (2023, 16.7), (2025, 17.7), (2025, 99)],
      "M": [(1949, 0.0), (1949, 24.7), (1950, 25.6), (1955, 28.6), (1955, 30.7), (1985, 32.1), (2005, 33.3), (2019, 34.5), (2021, 35.5),
            (2021, 37.4), (2023, 38.1), (2023, 39.5), (2025, 40.6), (2025, 99)]}
def year_at(k, t):
    p = TL[k]; return float(np.interp(t, [q[1] for q in p], [q[0] for q in p]))
TITLE = {"hook": ["Israel's #1 customer", "in 1949? Not the US."], "X": ["Who buys", "from Israel?"], "M": ["Who sells", "to Israel?"],
         "end": ["So who was #1", "in 1949?"]}
SUB = {"X": "Israel's goods exports, top 4", "M": "Israel's goods imports, top 4"}
EVENTS = [(4.4, "Britain buys the most"), (7.6, "1966: the US takes #1"), (11.5, "Diamonds lift Belgium, Hong Kong"),
          (14.1, "2023: Ireland is #2"), (16.8, "Today: US $16.1B, Germany #2"), (19.6, "1 in 4 export dollars: USA"),
          (22.2, ""), (24.8, "1950: the US, by far"), (27.7, "1952 reparations deal: West Germany #2"), (30.8, "Belgium #2: diamonds again"),
          (33.6, "China closes in"), (37.6, "2023: Turkey #4"), (39.4, "2024: Turkey's trade ban"), (40.7, "China: 22% of all imports"),
          (43.4, "From 0% to #1 in 30 years")]
REV = (35.6, 37.5, ["2021: China passes", "the US"])
SRC = {"X": ["Goods incl. diamonds. COW Trade v4 (IMF DOTS) 1949 to 1995,", "UN Comtrade/WITS 1996 to 2025. est. = estimate"],
       "M": ["Goods incl. diamonds. COW Trade v4 (IMF DOTS) 1949 to 1995,", "UN Comtrade/WITS 1996 to 2025. est. = estimate"]}

# ------------------------------------------------------------------ layout
Y_TITLE = 132; T_FS = 96; T_LH = 104
Y_SUB = Y_TITLE + 2 * T_LH + 16; SUB_FS = 56
Y_BARS = Y_SUB + 92; ROWS = 4; ROW_H = 156; LAB_FS = 62; VAL_FS = 60; BAR_T = 54
Y_YEAR = Y_BARS + ROWS * ROW_H + 18
Y_EV = Y_YEAR + 160; EV_FS = 60
Y_SRC = 1458; SRC_FS = 34
FLAGS = {}
def flag(code, h):
    k = (code, h)
    if k not in FLAGS:
        p = f"{D}/flags/{code}.png" if os.path.exists(f"{D}/flags/{code}.png") else f"/home/claude/vid/flags/{code}.png"
        f = Image.open(p).convert("RGBA"); w = int(h * S * 1.5)
        f = f.resize((w, int(h * S)), Image.LANCZOS); m = Image.new("L", f.size, 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, f.width - 1, f.height - 1], int(6 * S), fill=255); f.putalpha(m); FLAGS[k] = f
    return FLAGS[k]
r = np.linspace(0, 1, H * S)[:, None, None]
BG = Image.fromarray(((np.array(NAVY_T)[None, None, :] * (1 - r) + np.array(NAVY_B)[None, None, :] * r) * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
yy_g, xx_g = np.mgrid[0:H // 4, 0:W // 4]
def glow(t):
    gx = 0.5 + 0.18 * math.sin(t * 0.35); gy = 0.40 + 0.08 * math.cos(t * 0.27)
    dd = np.sqrt((xx_g / (W / 4) - gx) ** 2 + ((yy_g / (H / 4) - gy) * 1.6) ** 2)
    a = np.clip(1 - dd / 0.55, 0, 1) ** 2 * 40
    g = np.zeros((H // 4, W // 4, 4), np.uint8); g[..., 0] = 42; g[..., 1] = 136; g[..., 2] = 212; g[..., 3] = a.astype(np.uint8)
    return Image.fromarray(g, "RGBA").resize((W * S, H * S), Image.BILINEAR)

# ------------------------------------------------------------------ frames
N = int(round(T_TOTAL * FPS))
SNAPS = [float(x) for x in A.snaps.split(",")] if A.snaps else None
SNAPF = {int(round(s * FPS)): s for s in SNAPS} if SNAPS else {}
OUT = f"{D}/out/trade_race.mp4"; OUTV = OUT.replace(".mp4", "_silent.mp4")
ff = None
if not SNAPS:
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-preset", "medium", OUTV], stdin=subprocess.PIPE)
state = {k: dict(pos={}, alpha={}, xmax=None) for k in ("X", "M")}
def step(k, t):
    """advance the smoothed ranking state of race k to time t; returns (year, vals, ranked)"""
    st = state[k]; R = RACE[k]; year = year_at(k, t)
    vals = {n: val(P, year) for n, P in R.items()}
    order = sorted(R, key=lambda n: -vals[n]); ranked = [n for n in order[:ROWS] if vals[n] > 0.5]
    for i, n in enumerate(order):
        st["pos"][n] = i if n not in st["pos"] else st["pos"][n] + (i - st["pos"][n]) * 0.16
        st["alpha"][n] = st["alpha"].get(n, 0.0) + ((1.0 if n in ranked else 0.0) - st["alpha"].get(n, 0.0)) * 0.2
    mx = max([vals[n] for n in ranked] + [1])
    st["xmax"] = mx if st["xmax"] is None else max(mx, st["xmax"] + (mx - st["xmax"]) * 0.12)
    return year, vals, ranked
def draw_race(im, d, k, t, year, vals, a_all):
    st = state[k]; R = RACE[k]; tot = val(TOT[k], year)
    bw_max = (X1 - X0) - 300
    for n in sorted(R, key=lambda n: -st["pos"][n]):
        p = st["pos"][n]; a = min(st["alpha"][n] * 2, 1.0, max(0.0, ROWS - 0.3 - p)) * a_all
        if a < 0.03 or p > ROWS - 0.45: continue
        v = vals[n]; c = hx(COL.get(n, "#A9B6CB")); y0 = Y_BARS + p * ROW_H
        fl = flag(FLAG.get(n, "il"), 48); fl2 = fl.copy(); fl2.putalpha(Image.eval(fl.getchannel("A"), lambda q: int(q * a)))
        im.alpha_composite(fl2, (int(X0 * S), int((y0 + 10) * S))); d = ImageDraw.Draw(im); lx = X0 + fl.width / S + 18
        lab = SHORT.get(n, n)
        if n == "Germany" and year < 1990: lab = "West Germany"
        if is_est(R[n], year): lab += " (est.)"
        txt(d, lx, y0 + 34, lab, fit(lab, LAB_FS, X1 - lx, 800, 56), c, 800, "lm", a)
        L = max(8, bw_max * v / max(st["xmax"], 1e-9)); yb = y0 + 72
        d.rounded_rectangle([X0 * S, yb * S, (X0 + L) * S, (yb + BAR_T) * S], int(12 * S), fill=c[:3] + (int(240 * a),))
        vs = fmt(v); txt(d, X0 + L + 16, yb + BAR_T / 2 + 2, vs, VAL_FS, WHITE, 900, "lm", a)
        sh = f"{100 * v / tot:.0f}%" if tot > 0 else ""
        txt(d, X0 + L + 16 + tw(vs, VAL_FS, 900) + 14, yb + BAR_T / 2 + 4, sh, 44, SILVER2, 700, "lm", a)
    # year + total
    ys = str(int(round(year))); txt(d, X0 - 4, Y_YEAR - 14, ys, 156, hx("#FFFFFF", int(255 * a_all)), 900, "la")
    txt(d, X1, Y_YEAR + 8, "Total " + ("exports" if k == "X" else "imports"), 50, SILVER2, 700, "ra", a_all)
    txt(d, X1, Y_YEAR + 64, fmt(tot), 80, BLUE_L, 900, "ra", a_all)
    return d
for f in range(N):
    t = f / FPS
    rx = step("X", min(t, T_SWITCH)); rm = step("M", max(t, T_SWITCH))
    if SNAPS and f not in SNAPF: continue
    im = BG.copy(); im.alpha_composite(glow(t)); d = ImageDraw.Draw(im)
    # crossfade between the two races
    u = ease((t - (T_SWITCH - 0.25)) / 0.5); aX, aM = 1 - u, u
    # title
    key = "hook" if t < 4.3 else ("X" if t < T_SWITCH else ("end" if t >= 45.6 else "M"))
    ta = 1.0
    for b in (4.3, T_SWITCH, 45.6):
        if abs(t - b) < 0.2: ta = abs(t - b) / 0.2
    pop = 1.0 + 0.06 * (1 - ease(t / 0.5)) if key == "hook" else 1.0
    for i, (s, col) in enumerate(zip(TITLE[key], (GOLD2, WHITE))):
        sz = fit(s, T_FS * pop, X1 - X0, 900, 90); txt(d, CX, Y_TITLE + i * T_LH, s, sz, col, 900, "ma", ta)
    ul = 320 * ease(t / 1.0) if t < 4.3 else 320
    d.rounded_rectangle([(CX - ul) * S, (Y_SUB - 12) * S, (CX + ul) * S, (Y_SUB - 5) * S], 3 * S, fill=GOLD)
    sub = SUB["X" if t < T_SWITCH else "M"]
    txt(d, CX, Y_SUB + 4, sub, fit(sub, SUB_FS, X1 - X0, 700, 50), SILVER, 700, "ma", ta if key != "hook" else 1)
    if aX > 0.01: d = draw_race(im, d, "X", t, *rx[:2], aX)
    if aM > 0.01: d = draw_race(im, d, "M", t, *rm[:2], aM)
    # event line (or reveal box)
    ra = 0.0
    if REV[0] <= t <= REV[1]: ra = min(1, (t - REV[0]) / 0.25, (REV[1] - t) / 0.25)
    ev = [e for e in EVENTS if e[0] <= t]
    if ev and ra < 1 and ev[-1][1]:
        e0, s = ev[-1]; ea = min(1, (t - e0) / 0.25) * (1 - ra); dy = 18 * (1 - ease((t - e0) / 0.3))
        sz = fit(s, EV_FS, X1 - X0, 800, 54)
        if tw(s, 54, 800) > X1 - X0:
            ws = s.split(); h = len(ws) // 2
            for i, l in enumerate((" ".join(ws[:h]), " ".join(ws[h:]))): txt(d, CX, Y_EV + dy + i * 70, l, 58, GOLD2, 800, "ma", ea)
        else: txt(d, CX, Y_EV + dy + 20, s, sz, GOLD2, 800, "ma", ea)
    if ra > 0:
        sc_ = 0.9 + 0.1 * ease((t - REV[0]) / 0.3)
        lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(lay)
        ld.rounded_rectangle([(X0 - 8) * S, (Y_EV - 10) * S, (X1 + 8) * S, (Y_EV + 186) * S], int(26 * S), fill=(10, 22, 46, int(240 * ra)),
                             outline=GOLD2[:3] + (int(255 * ra),), width=int(4 * S))
        for i, (s, col) in enumerate(zip(REV[2], (WHITE, GOLD2))):
            txt(ld, CX, Y_EV + 4 + i * 82, s, fit(s, 80 * sc_, X1 - X0 - 40, 900, 70), col, 900, "ma", ra)
        im.alpha_composite(lay); d = ImageDraw.Draw(im)
    # sources
    for i, s in enumerate(SRC["X" if t < T_SWITCH else "M"]):
        txt(d, CX, Y_SRC + i * 42, s, fit(s, SRC_FS + 2, X1 - X0, 400, SRC_FS), SILVER2, 400, "ma")
    # end card (< 1 s): loops into the hook
    if t >= T_ENDC:
        a = ease((t - T_ENDC) / 0.15)
        lay = Image.new("RGBA", im.size, (7, 15, 32, int(238 * a))); ld = ImageDraw.Draw(lay)
        for i, (s, col) in enumerate(zip(["Israel's #1 customer", "in 1949?"], (GOLD2, WHITE))):
            txt(ld, CX, 720 + i * 112, s, fit(s, 96, X1 - X0, 900, 84), col, 900, "ma", a)
        im.alpha_composite(lay)
    out = im.reduce(S).convert("RGB")
    if SNAPS:
        os.makedirs(A.snapdir, exist_ok=True); out.save(f"{A.snapdir}/snap_{SNAPF[f]:05.2f}.png"); continue
    ff.stdin.write(out.tobytes())
if SNAPS: print("snaps ->", A.snapdir); sys.exit()
ff.stdin.close(); ff.wait()
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", OUTV, "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "copy",
                "-c:a", "copy", "-t", f"{T_TOTAL:.2f}", "-movflags", "+faststart", OUT], check=True)
os.remove(OUTV); print("final", OUT)
