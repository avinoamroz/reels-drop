"""stitch vo/lNN.wav (one Cartesia SSE clip per script line) -> vo.wav + vo_words.json (word times on the final timeline)
trim each clip to its words (+pad), squeeze inner pauses to <= 0.32 s, fixed gaps between lines, atempo 1.06 (pitch kept)."""
import json, wave, subprocess, os
import numpy as np
D = "/home/claude/trade_race"; SR = 44100; TEMPO = 1.06; LEAD = 0.25
LINES = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
GAP = {0: 0.30, 1: 0.35, 2: 0.35, 3: 0.35, 4: 0.35, 5: 0.65, 6: 0.30, 7: 0.35, 8: 0.35, 9: 0.40, 10: 0.40, 11: 0.35, 12: 0.55}
MAXP = 0.32
out = [np.zeros(int(LEAD * SR), np.float32)]; words = []; t = LEAD
for i in range(len(LINES)):
    w = wave.open(f"{D}/vo/l{i:02d}.wav"); a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768
    W = json.load(open(f"{D}/vo/l{i:02d}_words.json"))
    s0 = max(0, W[0]["start"] - 0.06); e1 = min(len(a) / SR, W[-1]["end"] + 0.18)
    keep = []; cur = s0
    for k in range(len(W) - 1):
        g0, g1 = W[k]["end"], W[k + 1]["start"]
        if g1 - g0 > MAXP:
            m = (g0 + g1) / 2; keep.append((cur, m - MAXP / 2)); cur = m + MAXP / 2
    keep.append((cur, e1))
    def mp(x):
        acc = 0.0
        for k0, k1 in keep:
            if x <= k1: return t + acc + max(0, x - k0)
            acc += k1 - k0
        return t + acc
    for x in W: words.append(dict(word=x["word"], line=i, start=mp(x["start"]), end=mp(x["end"])))
    for k0, k1 in keep:
        seg = a[int(k0 * SR):int(k1 * SR)].copy(); f = min(len(seg) // 2, int(0.01 * SR))
        seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f); out.append(seg); t += len(seg) / SR
    if i in GAP: out.append(np.zeros(int(GAP[i] * SR), np.float32)); t += GAP[i]
out.append(np.zeros(int(0.4 * SR), np.float32)); y = np.concatenate(out)
raw = f"{D}/vo_raw.wav"
with wave.open(raw, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((y.clip(-1, 1) * 32767).astype(np.int16).tobytes())
# light chain: atempo, slight warmth, high-pass
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", raw, "-af", f"highpass=f=70,equalizer=f=140:t=q:w=1:g=1.5,atempo={TEMPO}", "-ar", "48000", f"{D}/vo.wav"], check=True)
os.remove(raw)
for x in words: x["start"] = round(x["start"] / TEMPO, 3); x["end"] = round(x["end"] / TEMPO, 3)
json.dump(words, open(f"{D}/vo_words.json", "w"), indent=0)
dur = len(y) / SR / TEMPO
print("vo", round(dur, 2), "s")
for i in range(len(LINES)):
    ws = [x for x in words if x["line"] == i]; print(i, ws[0]["start"], ws[-1]["end"], LINES[i][:50])
