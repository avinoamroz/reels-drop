"""dummy 5 s job to test cloud ASR (1 Nov pipeline upgrade)"""
import subprocess
D = "/home/claude/zz_pipeline_test"
subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=0x163261:s=1080x1920:r=30:d=5.5",
                "-i", D + "/first_x_identity_from.wav", "-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac",
                "-shortest", D + "/final.mp4"], check=True)
