"""Bespoke reelkit scenes for promenade_steps (30 Oct 2026): the Tel Aviv promenade steps riddle.
IG safe zones: content in x 60..920 (right 160 clear), y <= 1540 (bottom 380 clear); centre x = 490.
Subtitles moved to y 1482, centred at x 490, max width 820. Sources 34 px fixed.
Scene types: hook, options, calc, reveal, coast, endcard. A schematic shoreline (landmark points, not survey data)
with the promenade (Tel Aviv Port to Jaffa Port), a walker emoji walking it and a step counter."""
import math, re
import cairo
from PIL import Image, ImageDraw, ImageFont
import render as RD
from render import P, T, pill, PP, fade_in, block, block_h, draw_emoji, shadow_box, col, pil2cairo
from kit import ease, ramp, lerp, St, sa, rr, circ, W, H, font
import kit

CX = 490; X0, X1 = 60, 920; SUBY = 1482; SRC_Y = 1378
MEN, WOMEN = 10411, 11343        # 7600 / 0.73, 7600 / 0.67

# ---------------------------------------------------------------- subtitles inside the IG safe zone
def sub_surfs(pieces, sz=48, maxw=820):
    F = ImageFont.truetype(RD.SUB_FONT, sz); out = []
    for t0, t1, d in pieces:
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 22
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=RD.P255["navy"][:3] + (232,), outline=RD.P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 11 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        y = int(SUBY - Hd / 2) if len(lines) == 1 else int(SUBY + 40 - Hd)      # two lines grow upward, bottom stays < 1540
        out.append((t0, t1, pil2cairo(im), int(CX - Wd / 2), y, d, Hd))
    return out
RD.sub_surfs = sub_surfs

def src(c, t, S, y=SRC_Y):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + 0.5, S)
    ls = s if isinstance(s, list) else [s]
    for k, l in enumerate(ls): T(c, l, 34, CX, y + 42 * k, P["grey"], a, 1.0, 700, maxw=860, src=True)

# ---------------------------------------------------------------- schematic shoreline (lat, lon), north to south
COAST = [(32.146, 34.7950), (32.135, 34.7905), (32.125, 34.7870), (32.115, 34.7825), (32.108, 34.7790), (32.1030, 34.7760),
         (32.0985, 34.7730),                                    # 6: Tel Aviv Port (promenade start)
         (32.0930, 34.7703), (32.0880, 34.7686), (32.0830, 34.7672), (32.0780, 34.7658), (32.0730, 34.7642), (32.0680, 34.7620),
         (32.0630, 34.7586), (32.0590, 34.7552),
         (32.0550, 34.7514),                                    # 15: Jaffa Port (promenade end)
         (32.0515, 34.7500), (32.0465, 34.7490), (32.0400, 34.7472), (32.0330, 34.7445), (32.0250, 34.7415)]
I0, I1 = 6, 15
VIEW_PROM = (32.0475, 32.1060)     # lat span of the promenade views
VIEW_ALL = (32.022, 32.150)

class Map:
    """linear projection of (lat, lon) into a panel; z zooms around the panel centre; ox shifts the coast in x"""
    def __init__(s, box_, lat0, lat1, z=1.0, cx_lon=34.766, ox=-40):
        s.x0, s.y0, s.x1, s.y1 = box_; s.k = (s.y1 - s.y0) / (lat1 - lat0) * z; s.clat = (lat0 + lat1) / 2
        s.cos = math.cos(math.radians(s.clat)); s.clon = cx_lon; s.ox = ox
    def P(s, lat, lon):
        return ((s.x0 + s.x1) / 2 + s.ox + (lon - s.clon) * s.cos * s.k, (s.y0 + s.y1) / 2 - (lat - s.clat) * s.k)

def poly_len(pts):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:]))
def along(pts, u):
    """point and heading at fraction u of a polyline"""
    L = poly_len(pts); d = u * L
    for a, b in zip(pts, pts[1:]):
        l = math.hypot(b[0] - a[0], b[1] - a[1])
        if d <= l or b is pts[-1]:
            f = 0 if l == 0 else min(1, d / l); return (lerp(a[0], b[0], f), lerp(a[1], b[1], f)), math.atan2(b[1] - a[1], b[0] - a[0])
        d -= l
    return pts[-1], 0
def sub_poly(pts, u):
    L = poly_len(pts); d = u * L; out = [pts[0]]
    for a, b in zip(pts, pts[1:]):
        l = math.hypot(b[0] - a[0], b[1] - a[1])
        if d >= l: out.append(b); d -= l
        else:
            f = 0 if l == 0 else d / l; out.append((lerp(a[0], b[0], f), lerp(a[1], b[1], f))); break
    return out
def stroke(c, pts, cc, w, a=1.0, dash=None):
    if len(pts) < 2: return
    sa(c, cc, a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    if dash: c.set_dash(dash)
    c.move_to(*pts[0]); [c.line_to(*p) for p in pts[1:]]; c.stroke(); c.set_dash([])

def draw_map(c, t, box_, view, z=1.0, draw_u=1.0, walk_u=None, full_coast=False, labels=True, counter=None, a=1.0, lab_sz=40):
    """panel with sea, land, the promenade and the walker. draw_u: share of the promenade line drawn; walk_u: walker position."""
    x0, y0, x1, y1 = box_
    if a <= 0.01: return
    old = St.a; St.a *= a
    sa(c, P["navy"], 0.12); rr(c, x0 + 3, y0 + 12, x1 - x0, y1 - y0, 30); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    g = cairo.LinearGradient(x0, 0, x1, 0); g.add_color_stop_rgb(0, 0.67, 0.82, 0.95); g.add_color_stop_rgb(1, 0.80, 0.89, 0.97)
    c.set_source(g); c.paint_with_alpha(St.a)
    m = Map(box_, *view, z=z); pts = [m.P(*p) for p in COAST]
    # waves
    for k in range(7):
        yy = y0 + 40 + k * (y1 - y0) / 7 + 10 * math.sin(t * 1.3 + k)
        xx = x0 + 40 + 30 * math.sin(t * 0.8 + k * 1.7)
        sa(c, P["white"], 0.55); c.set_line_width(4); c.move_to(xx, yy)
        for j in range(3): c.rel_curve_to(12, -10, 24, -10, 36, 0)
        c.stroke()
    # land
    c.move_to(x1 + 400, y0 - 400); c.line_to(*pts[0]); c.line_to(pts[0][0] + 30, y0 - 400)
    c.move_to(pts[0][0] + 200, y0 - 2000); [c.line_to(*p) for p in pts]; c.line_to(pts[-1][0], y1 + 2000); c.line_to(x1 + 2000, y1 + 2000); c.line_to(x1 + 2000, y0 - 2000); c.close_path()
    sa(c, kit.hx("#F1EBDD")); c.fill()
    stroke(c, pts, kit.hx("#E3D3A8"), 22)                          # sand
    stroke(c, pts, P["border"], 3)
    # a few street blocks for texture
    for k in range(9):
        yy = y0 + (k + 0.5) * (y1 - y0) / 9
        sa(c, P["border"], 0.35); c.set_line_width(3); c.move_to(x1 - 330, yy); c.line_to(x1 + 50, yy - 30); c.stroke()
    prom = pts[I0:I1 + 1]
    if full_coast:
        stroke(c, pts, P["white"], 20); stroke(c, pts, P["gold"], 12)
    stroke(c, sub_poly(prom, draw_u), P["white"], 20); stroke(c, sub_poly(prom, draw_u), P["blue"], 11)
    if walk_u is not None and walk_u > 0:
        stroke(c, sub_poly(prom, walk_u), P["gold"], 11)
    # endpoints
    for i, cc in ((I0, "navy"), (I1, "gold")):
        if i == I1 and draw_u < 0.99: continue
        px, py = pts[i]; circ(c, px, py, 17, P["white"]); circ(c, px, py, 11, col(cc))
    c.restore()
    rr(c, x0, y0, x1 - x0, y1 - y0, 30); sa(c, P["navy"]); c.set_line_width(5); c.stroke()
    if labels:
        for i, txt, dy in ((I0, "Tel Aviv Port", 0), (I1, "Jaffa Port", 0)):
            if i == I1 and draw_u < 0.99: continue
            px, py = pts[i]
            if not (y0 + 30 < py < y1 - 30): continue
            lx = min(px + 40 + font(lab_sz, 800).getlength(txt) / 2 + 24, x1 - 20 - font(lab_sz, 800).getlength(txt) / 2 - 24)
            pill(c, txt, lab_sz, lx, py + dy, P["white"], P["navy"], 1, 1, outline=P["navy"] if i == I0 else P["gold"], w=800, padx=0.45, padh=1.4)
    if walk_u is not None:
        (wx, wy), ang = along(prom, max(0.0, min(1.0, walk_u)))
        bob = abs(math.sin(t * 9)) * 10
        if y0 < wy < y1:
            circ(c, wx, wy, 30, P["white"], 0.85)
            draw_emoji(c, "\U0001F6B6", wx - 4, wy - 46 - bob, 92, 1.0, 1.0, 0.08 * math.sin(t * 9))
    if counter is not None:
        txt = f"{int(round(counter)):,} steps"
        f = font(56, 900); tw = f.getlength(txt); pw = tw + 150; ph = 92; px = x1 - 24 - pw; py = y0 + 24
        shadow_box(c, px, py, pw, ph, ph / 2, P["navy"], stroke=P["gold"], sw=4, sh=6)
        draw_emoji(c, "\U0001F463", px + 52, py + ph / 2, 52)
        T(c, txt, 56, px + 90 + tw / 2, py + ph / 2 + 2, P["white"], 1, 1, 900, maxw=700)
    St.a = old
    return m

def tm(S, k, d):
    return S["times"].get(k, S["t0"] + d)

# ---------------------------------------------------------------- scenes
def chip(c, t, S, txt="RIDDLE", y=228):
    a, s = PP(t, S["t0"], S); pill(c, txt, 36, CX, y, P["gold"], P["white"], a, s, w=800)

def walker_loop(t, t0, speed=0.045):
    return (t - t0) * speed

def sc_hook(c, t, S):
    """frame 0: title + map already drawn (line 55 % in), zooming, walker already moving"""
    chip(c, t, S, S.get("chip", "TEL AVIV RIDDLE"))
    en = S["en"]; h = block_h(en, 96, 900, 860, 4)
    a, s = PP(t, S["t0"], S)
    block(c, en, 96, CX, 300 + h / 2, P["navy"], a, 1.0 + 0.012 * math.sin(t * 2.2), hl=P["blue"], maxw=860, max_lines=4, lh=1.08)
    # gold underline sweep under the title
    u = ramp(t, S["t0"] + 0.1, S["t0"] + 1.3); yy = 300 + h + 14
    stroke(c, [(CX - 300, yy), (CX - 300 + 600 * u, yy)], P["gold"], 10)
    y0 = yy + 40; box_ = (X0, y0, X1, 1340)
    z = lerp(1.0, 1.18, ease((t - S["t0"]) / 5.0)); du = lerp(0.55, 1.0, ease((t - S["t0"]) / 1.4))
    draw_map(c, t, box_, VIEW_PROM, z=z, draw_u=du, walk_u=0.03 + 0.045 * (t - S["t0"]), lab_sz=40)
    src(c, t, S)

def sc_endcard(c, t, S):
    """same layout as the hook, so the loop back to frame 0 is seamless"""
    chip(c, t, S, S.get("chip", "TEL AVIV RIDDLE"))
    en = S["en"]; h = block_h(en, 96, 900, 860, 4)
    a, s = PP(t, S["t0"] + 0.05, S)
    block(c, en, 96, CX, 300 + h / 2, P["navy"], a, s, hl=P["blue"], maxw=860, max_lines=4, lh=1.08)
    yy = 300 + h + 14; stroke(c, [(CX - 300, yy), (CX + 300, yy)], P["gold"], 10)
    y0 = yy + 40; box_ = (X0, y0, X1, 1340)
    # ends where the hook starts: zoom back to 1.0, walker back near the start
    u = ease((t - S["t0"]) / max(0.5, S["t1"] - S["t0"]))
    draw_map(c, t, box_, VIEW_PROM, z=lerp(1.12, 1.0, u), draw_u=lerp(1.0, 0.6, ramp(u, 0.4, 1.0)), walk_u=lerp(0.0, 0.025, u), lab_sz=40)

def sc_options(c, t, S):
    a, s = PP(t, S["t0"] + 0.05, S)
    block(c, S.get("title", "How many *steps?*"), 84, CX, 300, P["navy"], a, s, hl=P["blue"], maxw=860, max_lines=2)
    opts = S["options"]; times = [tm(S, f"o{k}", 0.4 + 1.4 * k) for k in range(len(opts))]
    ch = 168; gap = 26; ytop = 410
    for k, (letter, val) in enumerate(opts):
        a, s = PP(t, times[k], S)
        if a <= 0.01: continue
        y = ytop + k * (ch + gap); old = St.a; St.a *= a
        c.save(); c.translate(CX, y + ch / 2); c.scale(s, s); c.translate(-CX, -(y + ch / 2))
        shadow_box(c, X0 + 20, y, X1 - X0 - 40, ch, 40, P["card"], stroke=P["silver"], sw=4, sh=8)
        circ(c, X0 + 120, y + ch / 2, 58, P["navy"]); T(c, letter, 76, X0 + 120, y + ch / 2 + 3, P["white"], 1, 1, 900)
        T(c, val, 96, CX + 70, y + ch / 2 + 4, P["navy"], 1, 1, 900, maxw=600)
        c.restore(); St.a = old
    tp = tm(S, "pick", 6.0); a, s = PP(t, tp, S, bounce=2.4)
    yp = ytop + 4 * (ch + gap) + 70
    pill(c, "Pick one \U0001F447", 76, CX, yp, P["gold"], P["white"], a, s, w=900)
    tw = tm(S, "walk", 7.5); a2 = fade_in(t, tw, S)
    if a2 > 0.01: T(c, "Now let's *walk* it", 64, CX, yp + 130, P["navy"], a2, 1, 900, hl=P["blue"], maxw=860)

def row(c, t, y, h, icon, small, big, t_in, t_big=None, big2=None, color="navy", S=None, replace=False):
    if t < t_in - 0.07: return
    a = fade_in(t, t_in - 0.07, S, 0.2); u = ease((t - t_in + 0.07) / 0.35); dx = 200 * (1 - u)
    old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
    shadow_box(c, X0 + 10, y, X1 - X0 - 20, h, 34, P["card"], stroke=col(color, "silver"), sw=4, sh=6)
    draw_emoji(c, icon, X0 + 82, y + h / 2, 72)
    T(c, small, 40, X0 + 140, y + 40, P["grey"], 1, 1, 800, maxw=680, anchor="l")
    show2 = t_big is not None and t >= t_big - 0.07
    bt = (big2 if replace else big + " " + big2) if (big2 and show2) else big
    T(c, bt, 68, X0 + 140, y + h - 50, P["navy"], 1, 1, 900, hl=P["gold_text"], maxw=680, anchor="l")
    c.restore(); St.a = old

def sc_calc(c, t, S):
    """map on top (walker walks the whole promenade while the counter climbs), the working below, one row about every 3 s"""
    box_ = (X0, 210, X1, 700)
    t0, t_end = S["t0"], S["t1"] + 0.25
    u = min(1, max(0, (t - t0 - 0.3) / max(1, (t_end - t0 - 0.3))))
    draw_map(c, t, box_, VIEW_PROM, z=1.0, draw_u=1.0, walk_u=u, counter=u * S.get("counter_to", MEN), lab_sz=38)
    rh = 140; g = 18; y = 728
    R = S["rows"]
    for k, r in enumerate(R):
        row(c, t, y + k * (rh + g), rh, r["icon"], r["small"], r["big"], tm(S, f"r{k}", 0.5 + 3 * k),
            S["times"].get(f"r{k}b"), r.get("big2"), r.get("color", "silver"), S, r.get("replace", False))
    src(c, t, S)

def sc_reveal(c, t, S):
    box_ = (X0, 210, X1, 560)
    draw_map(c, t, box_, VIEW_PROM, z=1.0, draw_u=1.0, walk_u=1.0, counter=S.get("counter_to", MEN), labels=True, lab_sz=34)
    cards = S["cards"]; ch = 210; y = 590
    for k, cd in enumerate(cards):
        tk = tm(S, f"c{k}", 0.3 + 3 * k); a, s = PP(t, tk, S, bounce=2.4)
        if a <= 0.01: continue
        yy = y + k * (ch + 22); old = St.a; St.a *= a
        c.save(); c.translate(CX, yy + ch / 2); c.scale(s, s); c.translate(-CX, -(yy + ch / 2))
        shadow_box(c, X0 + 10, yy, X1 - X0 - 20, ch, 40, P["navy"], stroke=P["gold"], sw=5, sh=8)
        draw_emoji(c, cd["icon"], X0 + 92, yy + ch / 2, 96)
        T(c, cd["label"], 44, X0 + 200, yy + 52, P["gold2"], 1, 1, 800, maxw=600, anchor="l")
        T(c, cd["value"], 104, X0 + 200, yy + ch - 74, P["white"], 1, 1, 900, maxw=560, anchor="l")
        c.restore(); St.a = old
    # options row with the winners lit
    tw = tm(S, "win", 6.5); yo = y + 2 * (ch + 22) + 92
    opts = S["options"]; wx = (X1 - X0 - 40) / 4
    for k, (letter, val) in enumerate(opts):
        xx = X0 + 20 + wx * k + wx / 2
        win = S["winners"].get(letter); lit = win and t >= tw - 0.07
        a, s = (1.0, 1.0)
        if lit: a, s = PP(t, tw + 0.15 * (letter == "C"), S, bounce=2.6)
        bg = P["gold"] if lit else P["card"]; fg = P["white"] if lit else P["navy"]
        shadow_box(c, xx - wx / 2 + 8, yo - 80, wx - 16, 160, 30, bg, stroke=P["gold"] if lit else P["silver"], sw=4, sh=6)
        T(c, letter, 72, xx, yo - 26, fg, 1, 1, 900)
        T(c, val, 52, xx, yo + 44, fg, 1, 1, 900, maxw=wx - 24)
        if lit: T(c, win, 40, xx, yo + 120, P["gold_text"], a, s, 900, maxw=wx)
    src(c, t, S)

def sc_coast(c, t, S):
    a, s = PP(t, S["t0"] + 0.05, S)
    block(c, S["title"], 76, CX, 262, P["navy"], a, s, hl=P["blue"], maxw=860, max_lines=1)
    box_ = (X0, 330, X1, 1010)
    u = ease((t - S["t0"]) / 1.2)
    m = draw_map(c, t, box_, (lerp(VIEW_PROM[0], VIEW_ALL[0], u), lerp(VIEW_PROM[1], VIEW_ALL[1], u)), z=1.0, draw_u=1.0, walk_u=None,
                 full_coast=u > 0.6, labels=u < 0.3, lab_sz=34)
    if u > 0.6:
        al = ramp(t, S["t0"] + 0.9, S["t0"] + 1.3); mp = Map(box_, *VIEW_ALL)
        for (lat, lon), txt in (((32.146, 34.7950), "Herzliya border"), ((32.0250, 34.7415), "Bat Yam border")):
            px, py = mp.P(lat, lon); py = min(max(py, box_[1] + 50), box_[3] - 50)
            pill(c, txt, 36, min(px + 230, X1 - 190), py, P["white"], P["navy"], al, 1, outline=P["gold"], w=800, padx=0.45, padh=1.4)
    tk = tm(S, "v", 1.6); a, s = PP(t, tk, S, bounce=2.4)
    y = 1040
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(CX, y + 140); c.scale(s, s); c.translate(-CX, -(y + 140))
        shadow_box(c, X0 + 10, y, X1 - X0 - 20, 280, 40, P["navy"], stroke=P["gold"], sw=5, sh=8)
        T(c, S["label"], 46, CX, y + 58, P["gold2"], 1, 1, 800, maxw=820)
        T(c, S["value"], 100, CX, y + 150, P["white"], 1, 1, 900, maxw=820)
        T(c, S["sub"], 44, CX, y + 232, P["white"], 1, 1, 800, maxw=820)
        c.restore(); St.a = old
    src(c, t, S)
