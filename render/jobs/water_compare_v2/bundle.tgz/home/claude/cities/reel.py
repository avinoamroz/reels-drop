"""Where do Israel's city names come from? reel.  usage: nice -n 15 python3 reel.py --snaps t1,t2 | --check | --render
Map: Natural Earth 1:10m (world-atlas 2.0.2) Israel + Palestine polygons, all filled gold #B8923F (Golan, West Bank, Gaza incl.),
Green Line = Palestine outline where it touches Israel, in (46,204,113). Lakes from ne_10m_lakes.
Layout: header (English city name + Hebrew line) on top, map with pins in the left column, name evolution chips in the right column."""
import sys, os, json, math, subprocess, argparse, re, time
import numpy as np, cairo
from PIL import Image, ImageDraw
from shapely.geometry import Polygon, shape
from shapely.ops import unary_union
sys.path.insert(0, "/home/claude/fff")
from lib import *

ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); ap.add_argument("--check", action="store_true")
A = ap.parse_args()
D = "/home/claude/cities"; QA = f"{D}/qa"; os.makedirs(QA, exist_ok=True)
TTS = [l.strip() for l in open(f"{D}/tts_v4.txt") if l.strip()]
for l in TTS: assert not any(d in l for d in DASHES), l
SEGS = json.load(open(f"{D}/vo/segs.json"))["segs"]; assert len(SEGS) == 16 == len(TTS)
CH = json.load(open(f"{D}/vo/segs_full.json"))["chunks"]; assert len(CH) == 54
T_END = SEGS[-1][1] + 2.8
B = [0.0] + [s[0] - 0.12 for s in SEGS[1:]] + [T_END]
N = int(round(T_END * FPS))
def cw(k, j=0): return CH[k][j]
def cm(k, f): return cw(k) + f * (cw(k, 1) - cw(k))
print("total", round(T_END, 2), "frames", N)
for k in range(16): assert B[k + 1] - B[k] >= 3.0, (k, B[k + 1] - B[k])
CUES = dict(B=B, T_END=T_END, SEGS=SEGS)
def cue(name, v): CUES.setdefault(name, []); CUES[name] += v if isinstance(v, list) else [v]
def pop(t, t0, d=0.35): return eob(min(1, max(0, (t - t0) / d))) if t > t0 else 0.0
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 4, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()
WORDS_NOW = []
def say(s, a):            # register visible English for the 12 word check
    if a > 0.5: WORDS_NOW.append(s)
def nwords(s): return len([w for w in re.split(r"\s+", s.replace("*", "")) if re.search("[A-Za-z0-9]", w)])

# ------------------------------------------------------------------ geography
def topo(path):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g["properties"]["name"] not in ("Israel", "Palestine"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
GEO = "/home/claude/goals_scorecard/geodata"
RG = topo(f"{GEO}/countries-10m.json"); ISR, PAL = RG["Israel"], RG["Palestine"]
LANDG = unary_union([ISR.buffer(0.002), PAL.buffer(0.002)]).buffer(-0.002).simplify(0.003)
LAND_R = [np.array(p.exterior.coords) for p in (LANDG.geoms if hasattr(LANDG, "geoms") else [LANDG]) if p.area > 0.002]
LAKES = []
for f in json.load(open(f"{GEO}/ne_10m_lakes.geojson"))["features"]:
    s_ = shape(f["geometry"])
    if 34 < s_.centroid.x < 36.5 and 29 < s_.centroid.y < 34:
        for p in (s_.geoms if hasattr(s_, "geoms") else [s_]): LAKES.append(np.array(p.simplify(0.003).exterior.coords))
GREEN = []
_ib = ISR.buffer(0.015)
for poly in (PAL.geoms if hasattr(PAL, "geoms") else [PAL]):
    g = poly.exterior.intersection(_ib)
    for ln in (g.geoms if hasattr(g, "geoms") else [g]):
        if ln.geom_type == "LineString" and ln.length > 0.01: GREEN.append(np.array(ln.simplify(0.003).coords))
LON0, LAT0, COSF = 35.05, 31.45, math.cos(math.radians(31.5))
def mp(pose, lon, lat): cx, cy, k = pose; return cx + (lon - LON0) * COSF * k, cy - (lat - LAT0) * k
POSE_HOOK = (540, 1112, 162); POSE_COL = (232, 965, 204); POSE_END = (540, 1050, 192)
CITY = {"Nablus": (35.262, 32.221), "Jerusalem": (35.217, 31.778), "Acre": (35.076, 32.927), "Bethlehem": (35.202, 31.705), "Hebron": (35.095, 31.532),
        "Beit Shean": (35.497, 32.500), "Beit Guvrin": (34.896, 31.612), "Lod": (34.895, 31.952), "Caesarea": (34.895, 32.500), "Tiberias": (35.531, 32.794),
        "Ramla": (34.870, 31.927)}
PINS = [("Nablus", cw(1) + 0.25), ("Jerusalem", cw(7)), ("Acre", cw(12)), ("Bethlehem", cw(17)), ("Hebron", cw(22)), ("Beit Shean", cw(31)),
        ("Beit Guvrin", cw(35)), ("Lod", cw(38)), ("Caesarea", cw(42)), ("Tiberias", cw(44)), ("Ramla", cw(46))]
cue("PIN", [p[1] for p in PINS])
def map_pose(t):
    def lp(p, q, u): return tuple(lerp(p[i], q[i], u) for i in range(3))
    u1 = ramp(t, B[1] - 0.1, B[1] + 0.8); u2 = ramp(t, B[14] - 0.1, B[14] + 0.9)
    return lp(lp(POSE_HOOK, POSE_COL, u1), POSE_END, u2)
def path_ring(c, pose, r):
    for i, (lo, la) in enumerate(r):
        x, y = mp(pose, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
    c.close_path()
def draw_map(c, t, a):
    if a <= 0.01: return
    pose = map_pose(t); k = pose[2] / 204
    glow(c, *mp(pose, 35.1, 31.6), 520 * k, SKY, 0.20 * a)
    c.push_group()
    for r in LAND_R: path_ring(c, pose, r)
    g = cairo.LinearGradient(0, pose[1] - 420 * k, 0, pose[1] + 420 * k); g.add_color_stop_rgba(0, *hx("#C9A24E")[:3], 1); g.add_color_stop_rgba(1, *hx("#B8923F")[:3], 1)
    c.set_source(g); c.fill_preserve(); stroke_style(c, (*hx("#EBCB7E")[:3], 0.9), 2.5 * k); c.stroke()
    for r in LAKES: path_ring(c, pose, r)
    c.set_source_rgba(*NAVYD[:3], 1); c.fill()
    stroke_style(c, (46 / 255, 204 / 255, 113 / 255, 1), 3.2 * k)
    for ln in GREEN:
        for i, (lo, la) in enumerate(ln):
            x, y = mp(pose, lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a)
    # pins: faint dots (hook twinkle), then dropped pins; the newest pin of the current scene is the active one
    cur = scene_at(t)
    for j, (nm, tp) in enumerate(PINS):
        x, y = mp(pose, *CITY[nm])
        tw = 0.2 + 0.2 * j
        fa = a * ramp(t, tw, tw + 0.3) * (0.35 + 0.25 * math.sin(t * 3 + j)) * (1 - ramp(t, tp - 0.2, tp))
        if fa > 0.01: c.set_source_rgba(1, 1, 1, fa); c.arc(x, y, 6 * k, 0, 2 * math.pi); c.fill()
        if t < tp: continue
        u = ramp(t, tp, tp + 0.45); dy = -70 * (1 - eob(u, 1.2)) if u < 1 else 0
        active = cur == PINS_SCENE[j]
        endwave = ramp(t, B[14], B[14] + 0.5) * (0.5 + 0.5 * math.sin(t * 3.2 - j * 0.7))
        if active or endwave > 0.01:
            ph = ((t - tp) % 1.4) / 1.4; aa = a * (1 if active else endwave)
            stroke_style(c, (*YEL[:3], aa * 0.8 * (1 - ph)), 4); c.arc(x, y + dy, (16 + 34 * ph) * k, 0, 2 * math.pi); c.stroke()
            glow(c, x, y + dy, 46 * k, YEL, 0.45 * aa)
        r_ = (15 if active else 10) * k
        c.set_source_rgba(*NAVYD[:3], a * min(1, u * 3)); c.arc(x, y + dy, r_ + 4, 0, 2 * math.pi); c.fill()
        c.set_source_rgba(*(YEL if active or endwave > 0.3 else (1, 0.93, 0.7, 1))[:3], a * min(1, u * 3)); c.arc(x, y + dy, r_, 0, 2 * math.pi); c.fill()

# ------------------------------------------------------------------ text pieces
CHIP_FILL = (0.04, 0.09, 0.19, 0.95)
_cs = {}
def chip_text(s):
    if s not in _cs:
        sz = 68 if font(68, 800).getlength(s) <= 500 else 64; assert font(sz, 800).getlength(s) <= 520, s
        _cs[s] = T(s, sz, 800)
    return _cs[s]
_g = {}
def glyph(ch, col=(255, 255, 255, 255)):   # common baseline glyphs for the Nablus gag
    k = (ch, col)
    if k not in _g:
        f = font(68, 800); w_ = int(f.getlength(ch)) + 24; im = Image.new("RGBA", (w_, 120), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((12, 84), ch, font=f, fill=col, anchor="ls"); _g[k] = pil2cairo(im)
    return _g[k]
def emoji(code, sz):
    k = ("emoji", code, sz)
    if k not in _cs: _cs[k] = pil2cairo(emoji_img(code, sz))
    return _cs[k]
def he_line(s, sz=68):
    f = font(sz, 700)
    while f.getlength(s) > 930 and sz > 56: sz -= 1; f = font(sz, 700)
    assert f.getlength(s) <= 930 and sz >= 56, s
    return T(s, sz, 700)

# ------------------------------------------------------------------ scenes
# row: text, tag, gloss, t (chip), tt (tag), tg (gloss), frm (morph source row index), emoji (code, t), icon, dim (t), gag
def R(text, t, tag=None, tt=None, gloss=None, tg=None, frm=None, **kw):
    d = dict(text=text, t=t, tag=tag, tt=tt if tt is not None else t + 0.2, gloss=gloss, tg=tg, frm=frm); d.update(kw); return d
SC = [  # name, k0, k1, header EN, [Hebrew per line], rows groups [(until, rows)], extra
 dict(n="hook", k=(0, 1)),
 dict(n="Nablus", k=(1, 4), en="*Nablus*", he=["שכם"], src=True, groups=[(None, [
     R("Shechem", cm(2, 0.45), "Hebrew"),
     R("Neapolis", cw(4) - 0.1, "72 CE, Vespasian", tt=cm(3, 0.12), gloss="= new city", tg=cm(5, 0.3), frm=0, gag=True, gloss_off=cm(6, 0.22)),
     R("Nablus", cm(6, 0.66), "Arabic", frm=1)])]),
 dict(n="Jerusalem", k=(4, 6), en="*Jerusalem*", he=["ירושלים", "בית המקדש"], src=True, groups=[
     (B[5], [R("Yerushalayim", cm(8, 0.5), "Hebrew"), R("Aelia Capitolina", cm(9, 0.72), "135 CE, Hadrian", tt=cm(9, 0.35), frm=0)]),
     (None, [R("Beit HaMikdash", cm(10, 0.86), "Hebrew", gloss="the Temple", tg=cw(11) - 0.05), R("Bayt al-Maqdis", cm(10, 0.30), "Arabic")])]),
 dict(n="Acre", k=(6, 7), en="*Acre*", he=["עכו"], src=True, groups=[(None, [
     R("Akko", cm(13, 0.55), "Hebrew, Bible", tt=cm(14, 0.4)), R("Ptolemais", cm(15, 0.7), "Greek", frm=0), R("Saint Jean d'Acre", cm(16, 0.45), "Crusaders", frm=1)])]),
 dict(n="Bethlehem", k=(7, 8), en="*Bethlehem*", he=["בית לחם"], src=False, groups=[(None, [
     R("Beit Lechem", cw(18), gloss="house of bread", tg=cw(19), emoji="1f35e"), R("Bayt Lahm", cm(20, 0.5), gloss="house of meat", tg=cw(21), emoji="1f969", frm=0)])]),
 dict(n="Hebron", k=(8, 9), en="*Hebron*", he=["חברון, מלשון חבר"], src=True, double=cw(29), groups=[(None, [
     R("Chevron", cw(23), "Hebrew", gloss="chaver = friend", tg=cm(24, 0.4)), R("al-Khalil", cw(27), "Arabic", gloss="the friend", tg=cw(28))])]),
 dict(n="Beit Shean", k=(9, 10), en="*Beit She'an*", he=["בית שאן"], src=True, from_header=True, bypass=(1, cm(33, 0.15)), groups=[(None, [
     R("Scythopolis", cm(32, 0.7), "Greek", dim=cm(33, 0.05)), R("Beisan", cm(33, 0.55), "Arabic", gloss="old name kept", tg=cw(34), frm=0)])]),
 dict(n="Beit Guvrin", k=(10, 11), en="*Beit Guvrin*", he=["בית גוברין"], src=False, from_header=True, bypass=(1, cw(37) - 0.3), groups=[(None, [
     R("Eleutheropolis", cm(36, 0.45), "200 CE", gloss="city of the free", tg=cm(36, 0.74), dim=cw(37) - 0.35), R("Bayt Jibrin", cm(37, 0.3), "Arabic", frm=0)])]),
 dict(n="Lod", k=(11, 12), en="*Lod*", he=["לוד"], src=True, from_header=True, bypass=(1, cw(40) - 0.3), groups=[(None, [
     R("Diospolis", cm(39, 0.55), "Roman, 200 CE", gloss="city of Zeus", tg=cm(39, 0.82), dim=cw(40) - 0.35), R("al-Lydd", cw(40) + 0.1, "Arabic", frm=0)])]),
 dict(n="Emperors", k=(12, 13), en="Named for *emperors*", en_sz=92, he=["קיסריה וטבריה"], src=False, noarrow=True, groups=[(None, [
     R("Caesarea", cw(42), "Herod", tt=cm(43, 0.15), gloss="for Caesar Augustus", tg=cm(43, 0.55), icon="coin"),
     R("Tiberias", cw(44), gloss="for Emperor Tiberius", tg=cm(45, 0.45), icon="coin")])]),
 dict(n="Ramla", k=(13, 14), en="*Ramla*", he=["רמלה"], src=True, noarrow=True, dunes=cm(48, 0.5), groups=[(None, [
     R("Founded by Arabs", cm(47, 0.45), "8th century CE", tt=cm(47, 0.8)), R("raml", cm(48, 0.45), "Arabic", gloss="= sand", tg=cm(48, 0.7))])]),
 dict(n="end", k=(14, 15)),
 dict(n="cta", k=(15, 16)),
]
PINS_SCENE = [next(i for i, s in enumerate(SC) if s["k"][0] <= [k for k in range(16) if B[k] <= tp][-1] < s["k"][1]) for nm, tp in PINS]
def scene_at(t):
    for i, s in enumerate(SC):
        if B[s["k"][0]] - 1e-6 <= t < B[s["k"][1]]: return i
    return len(SC) - 1
def scene_alpha(t, s):
    k0, k1 = s["k"]
    ai = 1.0 if k0 == 0 else ramp(t, B[k0] + 0.12, B[k0] + 0.42)
    ao = 1.0 if k1 == 16 else 1 - ramp(t, B[k1] - 0.02, B[k1] + 0.22)
    return ai * ao
CX = 708; Y0 = 600; CHIP_H = 104; ARROW = 66
for s in SC:
    if "en" not in s: continue
    s["en_s"] = pil2cairo(caption([("head", s["en"], s.get("en_sz", 112))])); s["he_s"] = [he_line(h) for h in s["he"]]
    s["en_w"] = font(s.get("en_sz", 112), 900).getlength(s["en"].replace("*", ""))
    for until, rows in s["groups"]:
        y = Y0
        for r in rows:
            tw = chip_text(r["text"]).get_width() - 16
            r["w"] = tw + 72 + (86 if r.get("icon") else 0); r["cy"] = y + CHIP_H / 2; y += CHIP_H
            assert CX + r["w"] / 2 <= 1010 and CX - r["w"] / 2 >= 400, (r["text"], r["w"])
            if r["tag"]: r["tag_s"] = T(r["tag"], 40, 700, S255); r["tag_y"] = y + 30; y += 52
            if r["gloss"]:
                r["gl_s"] = T(r["gloss"], 54, 800, Y255); r["gl_y"] = y + 38; y += 70
                gw = r["gl_s"].get_width() + (76 if r.get("emoji") else 0); assert gw <= 590, r["gloss"]
            r["bot"] = y; y += ARROW
        assert y - ARROW <= 1360, (s["n"], y)
HOOK_S = pil2cairo(caption([("head", "Where do *city names* come from?", 130), ("he", "מאיפה מגיעים שמות הערים בישראל?", 64)], 1.04))
END_S = pil2cairo(caption([("body", "Empires *renamed* them.\nThe oldest names\n*keep coming back.*", 80), ("he", "השמות העתיקים תמיד חוזרים", 66)]))
def card(els):
    im = end_card(els); bb = im.getbbox(); dy = 0
    if bb[3] > 1330: dy = 1330 - bb[3]
    assert bb[1] + dy >= 260, bb
    out = Image.new("RGBA", im.size, (0, 0, 0, 0)); out.alpha_composite(im, (0, dy)); return pil2cairo(out)
CTA_S = card([("emoji", "1f4ac", 130), ("head", "Which city *next?*", 124), ("body", "Tell me in the comments", 76), ("he", "איזו עיר הבאה? כתבו בתגובות", 66)])
SRC1 = T("Source: Wikipedia", 40, 700, S255); SRC2 = T("Sources: Wikipedia, Jewish Encyclopedia", 40, 700, S255); SRC_Y = 1405

def arrow_down(c, x, y0, y1, a, u, col=SKY, double=False):
    if a <= 0.01 or u <= 0.01: return
    ye = lerp(y0, y1, u); stroke_style(c, (*col[:3], a), 6); c.move_to(x, y0); c.line_to(x, ye); c.stroke()
    if u > 0.6:
        h = 15 * min(1, (u - 0.6) / 0.4); c.move_to(x - h, ye - h); c.line_to(x, ye); c.line_to(x + h, ye - h); c.stroke()
        if double: c.move_to(x - h, y0 + h); c.line_to(x, y0); c.line_to(x + h, y0 + h); c.stroke()
def coin(c, x, y, a):
    c.set_source_rgba(*hx("#E2BC5C")[:3], a); c.arc(x, y, 26, 0, 2 * math.pi); c.fill()
    stroke_style(c, (*hx("#8E6A22")[:3], a), 3); c.arc(x, y, 20, 0, 2 * math.pi); c.stroke()
    for side in (-1, 1):   # laurel leaves around the coin
        for i in range(6):
            ang = math.pi / 2 + side * (0.35 + i * 0.42); lx, ly = x + 36 * math.cos(ang), y + 36 * math.sin(ang)
            c.save(); c.translate(lx, ly); c.rotate(ang + side * 1.2); c.scale(1, 0.45); c.arc(0, 0, 9, 0, 2 * math.pi); c.restore()
            c.set_source_rgba(*hx("#7FD49A")[:3], a); c.fill()
def chip(c, x, y, w, a, active, sc=1.0, dashed=False):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    if active: glow(c, 0, 0, w * 0.6, YEL, 0.18 * a)
    rr(c, -w / 2, -CHIP_H / 2, w, CHIP_H, CHIP_H / 2)
    if not dashed: c.set_source_rgba(*CHIP_FILL[:3], CHIP_FILL[3] * a); c.fill_preserve()
    stroke_style(c, (*(YEL if active else SKY)[:3], a), 5 if active else 3.5)
    if dashed: c.set_dash([14, 12])
    c.stroke(); c.set_dash([]); c.restore()
def gag_text(c, r, x, y, a, t):
    s = "Neapolis"; f = font(68, 800); tot = f.getlength(s); x0 = x - tot / 2
    gP, gF, gB = cm(6, 0.26), cm(6, 0.40), cm(6, 0.50); back = cm(6, 0.66) + 0.9
    for i, ch in enumerate(s):
        gx = x0 + f.getlength(s[:i]) - 12; gy = y - 60 - 6
        if i != 3: paste(c, glyph(ch), gx, gy, a, anchor="tl"); continue
        if t < gF:
            sh = 5 * math.sin(t * 60) * ramp(t, gP, gP + 0.1)
            col = (255, 90, 110, 255) if t >= gP else (255, 255, 255, 255); paste(c, glyph("p", col), gx + sh, gy, a, anchor="tl")
        else:
            dt = t - gF
            if dt < 1.2:
                c.save(); c.translate(gx + 22 + 70 * dt, gy + 60 + 0.5 * 2600 * dt * dt); c.rotate(3.2 * dt)
                paste(c, glyph("p", (255, 90, 110, 255)), -22, -60, a * (1 - ramp(dt, 0.6, 1.1)), anchor="tl"); c.restore()
            if t >= gB:
                ub = ramp(t, gB, gB + 0.35); rb = ramp(t, back, back + 0.4)
                paste(c, glyph("b", Y255), gx, gy - 110 * (1 - eob(ub)), a * min(1, ub * 2) * (1 - rb), anchor="tl")
                paste(c, glyph("p"), gx, gy, a * rb, anchor="tl")
    if gP <= t < cm(6, 0.66) + 0.4:   # "no P" badge
        u = pop(t, gP); ua = a * (1 - ramp(t, cm(6, 0.66), cm(6, 0.66) + 0.4))
        bx, by = x + r["w"] / 2 - 14, y - CHIP_H / 2 - 8
        c.save(); c.translate(bx, by); c.scale(u, u)
        c.set_source_rgba(*NAVYD[:3], ua); c.arc(0, 0, 40, 0, 2 * math.pi); c.fill()
        paste(c, T("P", 50, 900), 0, 0, ua)
        stroke_style(c, (*RED[:3], ua), 7); c.arc(0, 0, 36, 0, 2 * math.pi); c.stroke(); c.move_to(-25, 25); c.line_to(25, -25); c.stroke(); c.restore()
cue("FALL", cm(6, 0.40)); cue("POP", [cm(6, 0.26), cm(6, 0.50)])
def draw_rows(c, t, s, a):
    for gi, (until, rows) in enumerate(s["groups"]):
        ga = a * (1 - ramp(t, until - 0.05, until + 0.3)) if until else a
        if until and gi + 1 < len(s["groups"]) and t > until + 0.35: continue
        if ga <= 0.01: continue
        newest = max((r["t"] for r in rows if t >= r["t"]), default=None)
        if s.get("from_header"):
            arrow_down(c, CX, 535, Y0 - 12, ga, ramp(t, rows[0]["t"] - 0.35, rows[0]["t"]))
        for j, r in enumerate(rows):
            t0 = min(r["t"], r["tt"])
            if t < t0: continue
            dim = 1 - 0.6 * ramp(t, r["dim"], r["dim"] + 0.4) if r.get("dim") else 1.0
            ra = ga * dim; active = r["t"] == newest
            # arrow from the previous row
            if j and not s.get("noarrow"):
                p = rows[j - 1]
                if s.get("double"):
                    arrow_down(c, CX, p["bot"] + 10, r["cy"] - CHIP_H / 2 - 10, ga, ramp(t, s["double"] - 0.1, s["double"] + 0.3), YEL, True)
                    if t >= s["double"]: paste(c, emoji("1f91d", 64), CX + 80, (p["bot"] + r["cy"] - CHIP_H / 2) / 2, ga * min(1, pop(t, s["double"])), pop(t, s["double"]))
                else: arrow_down(c, CX, p["bot"] + 10, r["cy"] - CHIP_H / 2 - 10, ga, ramp(t, t0 - 0.05, t0 + 0.35))
            # tag first, with a dashed placeholder until the chip lands
            if r["tag"] and t >= r["tt"]:
                ta = ra * ramp(t, r["tt"], r["tt"] + 0.3); paste(c, r["tag_s"], CX, r["tag_y"] + 10 * (1 - ramp(t, r["tt"], r["tt"] + 0.3)), ta); say(r["tag"], ta)
            if t < r["t"]:
                chip(c, CX, r["cy"], 260, ga * (0.55 + 0.25 * math.sin(t * 5)), False, dashed=True); paste(c, T("?", 64, 900, S255), CX, r["cy"], ga * 0.8); continue
            u = ramp(t, r["t"], r["t"] + 0.45)
            if r["frm"] is not None and u < 1:
                p = rows[r["frm"]]; y = lerp(p["cy"], r["cy"], ease(u)); w = lerp(p["w"], r["w"], ease(u))
                chip(c, CX, y, w, ra, True)
                paste(c, chip_text(p["text"]), CX, y, ra * (1 - ramp(u, 0.15, 0.5)))
                if r.get("gag"): gag_text(c, r, CX, y, ra * ramp(u, 0.4, 0.8), t)
                else: paste(c, chip_text(r["text"]), CX, y, ra * ramp(u, 0.4, 0.8))
                say(r["text"], ra * ramp(u, 0.4, 0.8))
            else:
                sc = 1.0 if r["frm"] is not None else pop(t, r["t"]); y = r["cy"]
                chip(c, CX, y, r["w"], ra * min(1, sc * 2), active, sc)
                tx = CX + (43 if r.get("icon") else 0)
                if r.get("icon"): coin(c, CX - r["w"] / 2 + 62, y, ra * min(1, sc * 2))
                if r.get("gag"): gag_text(c, r, CX, y, ra, t)
                else: paste(c, chip_text(r["text"]), tx, y, ra * min(1, sc * 2), sc)
                say(r["text"], ra)
                if r.get("dim") and t > r["dim"]:   # strike through the name that did not stick
                    us = ramp(t, r["dim"], r["dim"] + 0.4); hw = chip_text(r["text"]).get_width() / 2 - 4
                    stroke_style(c, (*PINK[:3], ga * 0.95), 6); c.move_to(CX - hw, y + 4); c.line_to(lerp(CX - hw, CX + hw, us), y + 4); c.stroke()
            if r["gloss"] and r["tg"] is not None and t >= r["tg"]:
                go = 1 - ramp(t, r["gloss_off"], r["gloss_off"] + 0.3) if r.get("gloss_off") else 1
                gu = pop(t, r["tg"]); gx = CX - (38 if r.get("emoji") else 0); gla = ra * min(1, gu * 2) * go
                paste(c, r["gl_s"], gx, r["gl_y"], gla, 0.6 + 0.4 * gu); say(r["gloss"], gla)
                if r.get("emoji"): paste(c, emoji(r["emoji"], 64), gx + r["gl_s"].get_width() / 2 + 44, r["gl_y"], gla, gu * (1 + 0.06 * math.sin(t * 6)))
        if s.get("bypass"):   # the old name comes back: a yellow arc from the header around the Greek / Roman name
            j, tb = s["bypass"]; r = rows[j]; u = ramp(t, tb, tb + 0.7)
            if u > 0.01:
                x0, y0 = 540 + s["en_w"] / 2 + 46, 345; x3, y3 = CX + r["w"] / 2 + 16, r["cy"]
                pts = [((1 - v) ** 3 * x0 + 3 * (1 - v) ** 2 * v * 995 + 3 * (1 - v) * v * v * 995 + v ** 3 * x3,
                        (1 - v) ** 3 * y0 + 3 * (1 - v) ** 2 * v * (y0 + 40) + 3 * (1 - v) * v * v * (y3 - 60) + v ** 3 * y3) for v in np.linspace(0, u, 40)]
                assert max(p[0] for p in pts) <= 1010
                stroke_style(c, (*YEL[:3], ga), 6); c.move_to(*pts[0])
                for p in pts[1:]: c.line_to(*p)
                c.stroke()
                if u > 0.95:
                    (ax, ay), (bx, by) = pts[-2], pts[-1]; ang = math.atan2(by - ay, bx - ax)
                    for d_ in (2.5, -2.5): c.move_to(bx, by); c.line_to(bx + 18 * math.cos(ang + d_), by + 18 * math.sin(ang + d_))
                    c.stroke()
        if s.get("dunes") and t >= s["dunes"]:
            u = ramp(t, s["dunes"], s["dunes"] + 0.6); da = ga * u; yb = 1350 - 0 * u; dy = 40 * (1 - u)
            c.save(); rr(c, CX - 290, 1110, 580, 250, 40); c.clip()
            for i, (col, amp_, base) in enumerate((("#E3C88A", 26, 1230), ("#CFA862", 30, 1270), ("#B48A45", 22, 1310))):
                c.move_to(CX - 300, 1370)
                for xx in range(-300, 301, 12):
                    c.line_to(CX + xx, base + dy - amp_ * math.sin(xx / (95 + 20 * i) + i * 1.7 + t * 0.15 * (i + 1)))
                c.line_to(CX + 300, 1370); c.close_path(); c.set_source_rgba(*hx(col)[:3], da); c.fill()
            rng = np.random.default_rng(3)
            for q in range(40):   # wind blown sand grains
                sx = (rng.random() * 600 + t * (120 + 80 * rng.random())) % 600 - 300; sy = 1150 + rng.random() * 120 + 8 * math.sin(t * 2 + q)
                c.set_source_rgba(*hx("#F1DDA8")[:3], da * 0.8); c.arc(CX + sx, sy, 2.2 + 1.5 * rng.random(), 0, 2 * math.pi); c.fill()
            c.restore()
for s in SC:
    if "groups" in s:
        for until, rows in s["groups"]:
            cue("POP", [r["t"] for r in rows if r["frm"] is None]); cue("MORPH", [r["t"] for r in rows if r["frm"] is not None])
            cue("TICK", [r["tt"] for r in rows if r["tag"] and r["tt"] < r["t"] - 0.3]); cue("GLOSS", [r["tg"] for r in rows if r["gloss"]])
            cue("STRIKE", [r["dim"] for r in rows if r.get("dim")])
        if s.get("bypass"): cue("ARC", s["bypass"][1])
        if s.get("dunes"): cue("SAND", s["dunes"])
        if s.get("double"): cue("CHIME2", s["double"])
cue("WHOOSH", [B[s["k"][0]] for s in SC[1:]]); cue("END", B[14]); cue("CARD", B[15])
json.dump(CUES, open(f"{D}/cues.json", "w"))

def frame(fi):
    t = fi / FPS; WORDS_NOW.clear()
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG_S, 0, 0); c.paint(); dust(c, t)
    draw_map(c, t, 1 - 0.9 * ramp(t, B[15] - 0.1, B[15] + 0.5))
    for sc_ in SC:
        a = scene_alpha(t, sc_)
        if a <= 0.005: continue
        k0, k1 = sc_["k"]; dy = 0 if k0 == 0 else 24 * (1 - ramp(t, B[k0], B[k0] + 0.45))
        if sc_["n"] == "hook": paste(c, HOOK_S, 0, 266, a, anchor="tl"); say("Where do city names come from?", a)
        elif sc_["n"] == "end": paste(c, END_S, 0, 266 + dy, a, anchor="tl"); say("Empires renamed them. The oldest names keep coming back.", a)
        elif sc_["n"] == "cta":
            u = ramp(t, B[15] - 0.05, B[15] + 0.4); sc = 1 + 0.025 * math.sin((t - B[15]) * 3.0) * ramp(t, B[15] + 0.5, B[15] + 1)
            c.save(); c.translate(540, 960); c.scale(sc, sc); c.translate(-540, -960); paste(c, CTA_S, 0, 30 * (1 - u), u, anchor="tl"); c.restore()
            say("Which city next? Tell me in the comments", u); paste(c, SRC2, 540, SRC_Y, u); say("Sources: Wikipedia, Jewish Encyclopedia", u)
        else:
            paste(c, sc_["en_s"], 0, 262 + dy, a, anchor="tl"); say(sc_["en"], a)
            hy = 262 + sc_["en_s"].get_height() + 2 + dy
            for j, hs in enumerate(sc_["he_s"]):
                kk = k0 + j; ha = a * (1 if j == 0 else ramp(t, B[kk], B[kk] + 0.3)) * (1 if j == len(sc_["he_s"]) - 1 else 1 - ramp(t, B[kk + 1] - 0.1, B[kk + 1] + 0.2))
                paste(c, hs, 540, hy + hs.get_height() / 2, ha)
            draw_rows(c, t, sc_, a)
            if sc_["src"]: paste(c, SRC1, 540, SRC_Y, a); say("Source: Wikipedia", a)
    s.flush(); return s
def to_rgb(s): return np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1].copy()

if A.check:   # 12 English words per card, measured on what is actually drawn
    worst = (0, 0, None)
    for fi in range(0, N, 3):
        frame(fi); n = sum(nwords(x) for x in WORDS_NOW)
        if n > worst[0]: worst = (n, fi / FPS, list(WORDS_NOW))
        assert n <= 12, (fi / FPS, n, WORDS_NOW)
    print("word check ok, max", worst); sys.exit(0)
if A.snaps:
    for ts in A.snaps.split(","):
        fi = min(N - 1, int(float(ts) * FPS)); Image.fromarray(to_rgb(frame(fi))).save(f"{QA}/snap_{float(ts):05.1f}.png")
    print("snaps done"); sys.exit(0)
if A.render:
    CHD = f"{D}/chunks"; os.makedirs(CHD, exist_ok=True); STEP = 300; parts = []; t0 = time.time()
    for a0 in range(0, N, STEP):
        b0 = min(N, a0 + STEP); p = f"{CHD}/c_{a0:05d}.mp4"; parts.append(p)
        if os.path.exists(p) and os.path.getsize(p) > 1000: continue
        ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-c:v", "libx264", "-threads", "1", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-profile:v", "high", p + ".tmp.mp4"], stdin=subprocess.PIPE)
        for fi in range(a0, b0):
            s = frame(fi); ff.stdin.write(np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W].tobytes())
        ff.stdin.close(); ff.wait(); os.replace(p + ".tmp.mp4", p); print(f"chunk {a0}-{b0} of {N}  {time.time() - t0:.0f}s", flush=True)
    open(f"{CHD}/list.txt", "w").write("".join(f"file '{p}'\n" for p in parts))
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", f"{CHD}/list.txt", "-c", "copy", f"{D}/video_only.mp4"], check=True)
    import shutil; shutil.rmtree(CHD, ignore_errors=True); print("video done", N, "frames")
