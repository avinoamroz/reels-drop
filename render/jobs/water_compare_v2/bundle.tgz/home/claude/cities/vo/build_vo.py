"""Cities reel narration: deeper voice (rubberband 0.9715 formant kept + bass), clean, 1.1x, reassembled chunk by chunk.
The DP grouping in asr.json misplaced lines 9 to 13 (foreign names lowered F1), so lines are grouped here by hand from the ASR chunks.
No retakes or false starts were found (every chunk matches the script), so nothing is cut.
Internal pauses longer than MAXIN (after tempo) are tightened to MAXIN; lines are placed with GAP between them.
out: vo/vo.wav (48 kHz mono float) + vo/segs.json (one [start,end] per script line) + vo/segs_full.json (chunks on the new timeline)"""
import json, subprocess, os, shutil, numpy as np, soundfile as sf
D = "/home/claude/cities/vo"; SR = 48000; TEMPO = 1.1; MAXIN = 0.36; LEAD = 0.25
J = json.load(open(f"{D}/asr.json")); CH = J["chunks"]
# first chunk index of each of the 16 script lines
FIRST = [0, 1, 3, 6, 7, 10, 12, 17, 22, 31, 35, 38, 42, 46, 50, 52]
LINE = [max(i for i, f in enumerate(FIRST) if f <= k) for k in range(len(CH))]
if not os.path.exists(f"{D}/fast.wav"):
  os.makedirs(f"{D}/c_in", exist_ok=True); os.makedirs(f"{D}/c_out", exist_ok=True)
  subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/c_in/full.wav"], check=True)
  subprocess.run(["nice", "-n", "15", "python3", "/home/claude/vo_new/clean_vo.py", f"{D}/c_in", f"{D}/c_out", "--report"], check=True)
  subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/c_out/full.wav", "-af", f"atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/fast.wav"], check=True)
x, sr = sf.read(f"{D}/fast.wav"); assert sr == SR
GAP = {k: 0.5 for k in range(16)}; GAP[14] = 0.85; GAP[15] = 0.7          # gap before line k
pieces = []; chunks = []; t = LEAD; prev_b = None
for k, (a, b, txt) in enumerate(CH):
    pa = CH[k - 1][1] if k else a - 0.3; nb = CH[k + 1][0] if k + 1 < len(CH) else b + 0.5
    a0 = max(0.0, a - 0.06, (pa + a) / 2); b0 = min(b + 0.12, (b + nb) / 2)
    if k:
        g = GAP[LINE[k]] if LINE[k] != LINE[k - 1] else min((a - CH[k - 1][1]) / TEMPO, MAXIN)
        t = prev_b + g
    s = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f)
    pieces.append((t - (a - a0) / TEMPO, s)); en = t + (b - a) / TEMPO; chunks.append([round(t, 3), round(en, 3), txt, LINE[k]]); prev_b = en
segs = [[min(c[0] for c in chunks if c[3] == i), max(c[1] for c in chunks if c[3] == i)] for i in range(16)]
T_END = segs[-1][1] + 2.0
y = np.zeros(int(T_END * SR) + SR)
for t0, s in pieces: i = int(t0 * SR); y[i:i + len(s)] += s
y = y[:int(T_END * SR)]
sf.write(f"{D}/vo.wav", y.astype(np.float32), SR, subtype="FLOAT")
json.dump({"segs": segs, "vo": f"{D}/vo.wav", "tempo": TEMPO, "lead": LEAD, "note": "hand grouped lines, internal pauses capped at 0.36 s"}, open(f"{D}/segs.json", "w"), indent=1)
json.dump({"chunks": chunks, "segs": segs}, open(f"{D}/segs_full.json", "w"), indent=1, ensure_ascii=False)
shutil.rmtree(f"{D}/c_in", True); shutil.rmtree(f"{D}/c_out", True); os.remove(f"{D}/fast.wav")
print("vo", round(len(y) / SR, 2), "s")
for i, s in enumerate(segs): print(i + 1, s, round(s[1] - s[0], 2))
