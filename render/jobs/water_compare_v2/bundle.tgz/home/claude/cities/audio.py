"""Cities reel: warm pad + plucked arpeggio bed in D harmonic minor (a light old-world colour), subtle sfx on the visual cues,
ducked narration -> mix.wav 48 kHz stereo (pre loudnorm). Same structure as /home/claude/growth/audio.py."""
import json, subprocess, numpy as np, soundfile as sf
from scipy.signal import lfilter, butter, sosfilt, fftconvolve
D = "/home/claude/cities"; SR = 48000
cue = json.load(open(f"{D}/cues.json")); T_END = cue["T_END"]; B = cue["B"]
n = int(T_END * SR) + 1; rng = np.random.default_rng(31)
def nf(m): return 440 * 2 ** ((m - 69) / 12)
def lp(x, a): return lfilter([a], [1, a - 1], x)
tt_ = lambda d: np.arange(int(d * SR)) / SR
tA = np.arange(n) / SR
def place(buf, sig, st, g=1.0, pan=0.0):
    i = int(st * SR); j = min(n, i + len(sig))
    if i < 0: sig = sig[-i:]; i = 0
    if j > i: s = g * sig[:j - i]; buf[0][i:j] += s * (1 - pan); buf[1][i:j] += s * (1 + pan)
def env_curve(points): px, py = zip(*points); return np.interp(tA, px, py)
def pluck(m, d=2.2, vel=1.0):   # oud / harp like pluck
    t = tt_(d); f = nf(m); x = np.zeros_like(t)
    for k in range(1, 7): x += (1 / k ** 1.3) * np.sin(2 * np.pi * f * k * (1 + 0.0006 * k * k) * t) * np.exp(-t * (2.2 + 1.6 * k))
    x *= np.minimum(1, t / 0.004) * np.minimum(1, (d - t) / 0.3); return x * vel
# ---------------- bed
BED = (np.zeros(n), np.zeros(n)); beat = 60 / 84; bar = 4 * beat
PROG = [(38, [50, 53, 57, 62]), (46, [50, 53, 58, 62]), (43, [50, 55, 58, 62]), (45, [49, 52, 57, 61])]   # Dm Bb Gm A
ARP = [0, 2, 1, 3, 2, 1, 3, 2]
level = env_curve([(0, 0.6), (B[1], 0.85), (B[14], 1.0), (B[15], 0.8), (T_END, 0.8)])
st = 0.0; b = 0
while st < T_END:
    root, ch = PROG[b % 4]; d = bar + 1.6; t = tt_(d); pad = np.zeros_like(t)
    for m in ch:
        for dt in (-0.07, 0.0, 0.07): pad += np.sin(2 * np.pi * nf(m - 12) * 2 ** (dt / 12) * t + rng.random() * 6)
    pad *= np.minimum(1, t / 1.2) * np.minimum(1, (d - t) / 1.2); pad = lp(pad, 0.035)
    lv = level[min(n - 1, int(st * SR))]
    place(BED, pad, st, 0.012 * lv, -0.1)
    place(BED, pluck(root, 3.0), st, 0.05 * lv)
    for q in range(8):
        tq = st + q * beat / 2
        m = ch[ARP[q]] + 12 + (1 if (b % 4 == 3 and ARP[q] == 0) else 0) * 0
        place(BED, pluck(m, 1.6, 0.9 if q % 2 == 0 else 0.6), tq, 0.026 * lv, 0.3 if q % 2 else -0.3)
    if b % 2 == 1: place(BED, sosfilt(butter(2, [150, 900], "bp", fs=SR, output="sos"), rng.standard_normal(int(0.12 * SR))) * np.exp(-tt_(0.12) * 30), st + 3 * beat, 0.02 * lv)
    st += bar; b += 1
BED = np.stack(BED)
# ---------------- sfx
SFX = (np.zeros(n), np.zeros(n))
def noise(d): return rng.standard_normal(int(d * SR))
def chime(t0, base, g=0.10, ints=(0, 7, 12)):
    for k, iv in enumerate(ints):
        t = tt_(2.2); f = nf(base + iv)
        x = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 5)) * np.minimum(1, t / 0.004) * np.exp(-t * 2.2)
        place(SFX, x, t0 + 0.07 * k, g * (1 - 0.2 * k), (-0.3, 0, 0.3)[k % 3])
def whoosh(t0, d=0.9, g=0.25):
    t = tt_(d); x = noise(d); sw = np.zeros_like(x)
    for k in range(0, len(x), 480):
        fc = 300 + 2200 * np.sin(np.pi * min(1, k / len(x))); sw[k:k + 480] = sosfilt(butter(2, [fc * 0.6, fc * 1.4], "bp", fs=SR, output="sos"), x[k:k + 480])
    place(SFX, sw * np.sin(np.pi * t / d) ** 2, t0 - 0.3, g, 0.15)
def thud(t0, g=0.35, f0=48, pan=0.0):
    t = tt_(0.5); k = np.sin(2 * np.pi * (f0 + 60 * np.exp(-t * 25)) * t) * np.exp(-t * 8)
    place(SFX, k + 0.2 * sosfilt(butter(2, 900, "lp", fs=SR, output="sos"), noise(0.5)) * np.exp(-t * 30), t0, g, pan)
def popf(t0, g=0.10, f0=500):
    t = tt_(0.09); f = f0 + 900 * (t / 0.09); place(SFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / 0.09), t0, g, rng.random() * 0.6 - 0.3)
def tick(t0, g=0.05, f=1500):
    t = tt_(0.05); place(SFX, np.sin(2 * np.pi * f * t) * np.exp(-t * 120), t0, g, rng.random() * 0.4 - 0.2)
def ping(t0, f, g=0.05, d=0.3):
    t = tt_(d); place(SFX, np.sin(2 * np.pi * f * t) * np.exp(-t * 20) + 0.3 * np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t * 25), t0, g, rng.random() - 0.5)
def strike(t0, g=0.12):
    x = sosfilt(butter(2, [2000, 6000], "bp", fs=SR, output="sos"), noise(0.3)); t = tt_(0.3)
    place(SFX, x * np.sin(np.pi * t / 0.3) * (0.6 + 0.4 * np.sin(2 * np.pi * 18 * t)), t0, g)
def slide(t0, f0, f1, d, g):   # pitch glide (falling letter, drawn arc)
    t = tt_(d); f = f0 * (f1 / f0) ** (t / d); place(SFX, np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / d) ** 0.5, t0, g)
for tp in cue["PIN"]: popf(tp + 0.35, 0.07, 350); thud(tp + 0.4, 0.07, 90)
for tp in cue["POP"]: popf(tp, 0.08)
for tm in cue["MORPH"]: whoosh(tm + 0.25, 0.5, 0.06); ping(tm + 0.45, 990, 0.035)
for tk in cue["TICK"]: tick(tk, 0.05, 1400); tick(tk + 0.08, 0.04, 1800)
for tg in cue["GLOSS"]: chime(tg, 79, 0.025, (0,))
for ts in cue["STRIKE"]: strike(ts)
for ta in cue["ARC"]: slide(ta, 500, 1100, 0.7, 0.03); chime(ta + 0.7, 74, 0.05, (0, 7))
for ts in cue["SAND"]:
    x = sosfilt(butter(2, [1500, 7000], "bp", fs=SR, output="sos"), noise(2.5)); t = tt_(2.5); place(SFX, x * np.sin(np.pi * t / 2.5) ** 2, ts, 0.05, 0.3)
for tc in cue["CHIME2"]: chime(tc, 77, 0.05, (0, 4, 7))
for tf in cue["FALL"]: slide(tf, 1400, 300, 0.75, 0.05); thud(tf + 0.75, 0.10, 70)
for tw in cue["WHOOSH"]: whoosh(tw, 0.6, 0.10)
for te in cue["END"]: chime(te + 0.1, 69, 0.07, (0, 7, 12))
for tc in cue["CARD"]: whoosh(tc, 0.7, 0.13); chime(tc + 0.3, 74, 0.06)
# ---------------- narration + ducking
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", f"{D}/vo/vo.wav", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
v = np.frombuffer(raw, np.float32).astype(np.float64)[:n]; v = np.pad(v, (0, n - len(v)))
hop = int(0.02 * SR); env = np.sqrt(np.abs(fftconvolve(v ** 2, np.ones(hop) / hop, "same")) + 1e-12)
act = 20 * np.log10(env) > 20 * np.log10(np.abs(v).max()) - 35
lv = 20 * np.log10(np.sqrt(np.mean(v[act] ** 2)))
lb = 20 * np.log10(np.sqrt(np.mean(BED ** 2)) + 1e-12)
held = fftconvolve(act.astype(float), np.ones(int(0.3 * SR)), "full")[:n] > 0.5
mask = np.clip(fftconvolve(held.astype(float), np.ones(int(0.15 * SR)) / int(0.15 * SR), "same"), 0, 1)
g_sp, g_gap = 10 ** ((lv - 19 - lb) / 20), 10 ** ((lv - 12 - lb) / 20)
gain = g_gap + (g_sp - g_gap) * mask
sfx = np.stack(SFX); ls = 20 * np.log10(np.sqrt(np.mean(sfx[:, sfx[0] != 0] ** 2)) + 1e-12)
sgain = 10 ** ((lv - 11 - ls) / 20) * (1 - 0.35 * mask)
out = np.stack([v, v]) + BED * gain + sfx * sgain
fi = int(0.02 * SR); out[:, :fi] *= np.linspace(0, 1, fi); fo = int(1.5 * SR); out[:, -fo:] *= np.linspace(1, 0, fo)
out /= max(1.0, np.abs(out).max() / 0.95)
sf.write(f"{D}/mix.wav", out.T.astype(np.float32), SR)
print("voice", round(lv, 1), "bed", round(lb, 1), "sfx", round(ls, 1), "len", out.shape[1] / SR)
