#!/bin/bash
# mux video_only.mp4 + mix.wav (two pass loudnorm to -14 LUFS, 48 kHz), burn subtitles, web copy, contact sheet, cleanup
set -e
cd /home/claude/cities
J=$(ffmpeg -nostdin -hide_banner -i mix.wav -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g() { echo "$J" | python3 -c "import sys,json;print(json.load(sys.stdin)['$1'])"; }
LN="loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true"
nice -n 15 ffmpeg -nostdin -v error -y -i video_only.mp4 -i mix.wav -af "$LN" -ar 48000 -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart nosubs.mp4
SUB_BOTTOM=1600 nice -n 15 python3 subs/make_subs.py nosubs.mp4 tts_v4.txt vo/segs.json cities_v1.mp4
nice -n 15 ffmpeg -nostdin -v error -y -i cities_v1.mp4 -c:v libx264 -crf 26 -preset medium -pix_fmt yuv420p -c:a copy -movflags +faststart cities_v1_web.mp4
ls -la cities_v1.mp4 cities_v1_web.mp4
ffmpeg -nostdin -hide_banner -i cities_v1.mp4 -af ebur128 -f null - 2>&1 | grep -A3 "Integrated loudness" | head -4
ffprobe -v error -show_entries stream=codec_name,sample_rate,width,height:format=duration -of compact cities_v1.mp4
# contact sheet at phone size (390 px wide tiles)
mkdir -p qa/sheet_frames; rm -f qa/sheet_frames/*.png
for t in 0.0 5.5 12.9 16.4 18.4 24.5 31.9 38.9 45.3 52.6 58.9 65.5 71.3 76.5 83.9 88.0 93.0; do
  ffmpeg -nostdin -v error -y -ss $t -i cities_v1.mp4 -frames:v 1 -vf scale=390:-1 qa/sheet_frames/f_$t.png
done
python3 - <<'E'
import glob
from PIL import Image, ImageDraw
fs = sorted(glob.glob("/home/claude/cities/qa/sheet_frames/*.png"), key=lambda p: float(p.split("_")[-1][:-4]))
ims = [Image.open(f) for f in fs]; w, h = ims[0].size; cols = 6; rows = -(-len(ims) // cols)
S = Image.new("RGB", (cols * w, rows * (h + 30)), (10, 10, 10)); d = ImageDraw.Draw(S)
for i, (f, im) in enumerate(zip(fs, ims)):
    x, y = (i % cols) * w, (i // cols) * (h + 30); S.paste(im, (x, y + 30)); d.text((x + 8, y + 8), f.split("_")[-1][:-4] + " s", fill=(255, 255, 255))
S.save("/home/claude/cities/qa/sheet.png"); print("sheet", S.size)
E
rm -rf qa/sheet_frames subs_cities_v1 nosubs.mp4
