"""Soft "as if Apple made it" bed, new family (not pleasant.py / friendly.py / cine.py).
usage: python3 apple2.py OUT.wav DUR STYLE [hits]
STYLE: glass  (MENA video)  : F# minor-ish vi-IV-I-V in A major, 92 BPM, marimba + glass bell, brushed groove
       bloom  (aliyah map)  : Fmaj7-Am7-Bbmaj7-Bbm6, 104 BPM, kalimba pluck + warm keys, light four-on-floor
hits: comma list of seconds for a soft swell + low bloom (e.g. 1948 moment)
The last ~8 s thin out to pad + bell so the end cards breathe."""
import sys, numpy as np, wave
from scipy.signal import lfilter
out_p = sys.argv[1]; DUR = float(sys.argv[2]); STYLE = sys.argv[3]
hits = [float(x) for x in sys.argv[4].split(",")] if len(sys.argv) > 4 and sys.argv[4] else []
SR = 44100; n = int(SR * DUR); L = np.zeros(n); R = np.zeros(n)
rng = np.random.default_rng(11 if STYLE == "glass" else 23)
if STYLE == "glass":
    BPM = 92.0; T = 0
    prog = [(42, [57, 61, 64, 66]), (38, [57, 62, 66, 69]), (45, [57, 61, 64, 68]), (40, [56, 59, 64, 66])]  # F#m9 Dmaj7 Amaj7 E6/9
else:
    BPM = 104.0; T = 0
    prog = [(41, [57, 60, 64, 65]), (45, [55, 60, 64, 67]), (46, [57, 60, 62, 65]), (46, [56, 61, 62, 65])]  # Fmaj7 Am7 Bbmaj7 Bbm6
beat = 60 / BPM; bar = 4 * beat; nb = int(DUR / bar) + 2
END_THIN = DUR - 8.5
def note(m): return 440 * 2 ** ((m - 69 + T) / 12)
def lp(x, a): return lfilter([a], [1, a - 1], x)
def place(sig, st, g=1.0, pan=0.0):
    i = int(st * SR); j = min(n, i + len(sig))
    if 0 <= i < n and j > i:
        s = g * sig[:j - i]; L[i:j] += s * (1 - pan) ; R[i:j] += s * (1 + pan)
def env_ar(tt, a, r): return np.minimum(1, tt / a) * np.exp(-tt * r)
def marimba(f, d=0.7):
    tt = np.arange(int(d * SR)) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.5 * np.sin(2 * np.pi * 4 * f * tt) * np.exp(-tt * 30) + 0.15 * np.sin(2 * np.pi * 10 * f * tt) * np.exp(-tt * 60)) * env_ar(tt, 0.002, 7)
def kalimba(f, d=0.9):
    tt = np.arange(int(d * SR)) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.35 * np.sin(2 * np.pi * 5.4 * f * tt) * np.exp(-tt * 25)) * env_ar(tt, 0.002, 5)
def bell(f, d=1.6):
    tt = np.arange(int(d * SR)) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 2.76 * f * tt) * np.exp(-tt * 6) + 0.1 * np.sin(2 * np.pi * 5.4 * f * tt) * np.exp(-tt * 12)) * env_ar(tt, 0.004, 2.4)
def keys(f, d):
    tt = np.arange(int(d * SR)) / SR
    return (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(4 * np.pi * f * tt) * np.exp(-tt * 3)) * env_ar(tt, 0.01, 1.6)
mel_r = np.random.default_rng(5 if STYLE == "glass" else 9)
motif = [[c[1][int(mel_r.integers(1, 4))] + 12 for _ in range(4)] for c in prog]
for b in range(nb):
    root, ch = prog[b % 4]; st = b * bar
    if st > DUR: break
    inten = min(1.0, 0.45 + st / 20); thin = st >= END_THIN
    # pad: detuned sines, slow attack, lowpassed
    Lp = bar + 0.6; tt = np.arange(int(Lp * SR)) / SR; pad = np.zeros_like(tt)
    for m in ch:
        for dt in (-0.07, 0.07): pad += np.sin(2 * np.pi * note(m - 12) * 2 ** (dt / 12) * tt)
    pad *= np.minimum(1, tt / 0.9) * np.minimum(1, (Lp - tt) / 0.6)
    place(lp(pad, 0.08), st, 0.030 * (1.25 if thin else 1.0), pan=-0.1)
    # sub bass
    if not thin:
        for q in ((0, 2.5, 3.5) if STYLE == "glass" else (0, 1, 2, 3)):
            tt = np.arange(int(beat * 1.2 * SR)) / SR
            place(np.sin(2 * np.pi * note(root - 12) * tt) * env_ar(tt, 0.01, 2.5), st + q * beat, 0.20 * inten)
    # arpeggio
    pat = [0, 2, 1, 3, 2, 1, 3, 2] if STYLE == "glass" else [0, 1, 2, 3, 1, 2, 3, 2]
    for q in range(8):
        if b == 0 and q % 2: continue
        if thin and q % 2: continue
        m = ch[pat[q]] + (12 if STYLE == "bloom" else 0)
        sig = marimba(note(m)) if STYLE == "glass" else kalimba(note(m))
        place(sig, st + q * beat / 2, 0.065 * (0.85 + 0.3 * (q % 4 == 0)), pan=(0.25 if q % 2 else -0.25))
    if STYLE == "bloom" and not thin:  # warm keys on beat 1 and the "and" of 2
        for q in (0, 1.5):
            for m in ch: place(keys(note(m), beat * 1.4), st + q * beat, 0.018)
    # bell motif from bar 2
    if b >= 2:
        for q, m in enumerate(motif[b % 4]):
            if thin and q % 2: continue
            place(bell(note(m)), st + q * beat + (beat / 2 if (STYLE == "glass" and q == 3) else 0), 0.040 * inten, pan=0.3)
    if thin or b < 2: continue
    # groove
    for q in range(4):
        t0 = st + q * beat
        if STYLE == "bloom" or q in (0, 2):
            tt = np.arange(int(0.28 * SR)) / SR; f = 48 + 55 * np.exp(-tt * 28)
            place(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 11), t0, 0.32 * inten)
        if q in (1, 3):  # brushed snap
            nz = rng.standard_normal(int(0.16 * SR)); nz = (nz - lp(nz, 0.3)) * np.exp(-np.arange(len(nz)) / SR * 26)
            place(nz, t0, 0.045 * inten, pan=0.15)
    for q in range(16):  # shaker
        nz = rng.standard_normal(int(0.035 * SR)); nz = (nz - lp(nz, 0.65)) * np.exp(-np.arange(len(nz)) / SR * 95)
        place(nz, st + q * beat / 4, 0.014 * (1.3 if q % 2 else 0.7) * inten, pan=-0.3)
for h in hits:  # soft swell into a low bloom chord
    rl = 1.4; tt = np.arange(int(rl * SR)) / SR; nz = rng.standard_normal(len(tt)); nz = lp(nz - lp(nz, 0.02), 0.3)
    place(nz * (tt / rl) ** 2.5, h - rl, 0.05)
    tt = np.arange(int(3.5 * SR)) / SR; s = sum(np.sin(2 * np.pi * note(m - 12) * tt) for m in prog[0][1]) + np.sin(2 * np.pi * note(prog[0][0] - 12) * tt)
    place(s * np.exp(-tt * 0.9) * np.minimum(1, tt / 0.05), h, 0.05)
# resolve chord under the end cards
tt = np.arange(int(7 * SR)) / SR; fc = np.zeros_like(tt)
for m in [prog[2][0]] + [x + 12 for x in prog[2][1]]: fc += np.sin(2 * np.pi * note(m) * tt) + 0.4 * np.sin(2 * np.pi * note(m) * 1.002 * tt)
place(fc * np.exp(-tt * 0.45) * np.minimum(1, tt / 0.3), max(0, DUR - 7.2), 0.022)
mix = np.stack([L, np.roll(R, int(0.012 * SR))], 1)
mix = np.tanh(mix * 1.3); fo = int(1.8 * SR); mix[-fo:] *= np.linspace(1, 0, fo)[:, None]; mix[:int(0.03 * SR)] *= np.linspace(0, 1, int(0.03 * SR))[:, None]
mix = mix / np.max(np.abs(mix)) * 0.88
w = wave.open(out_p, "wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype(np.int16).tobytes()); w.close(); print("ok", out_p)
