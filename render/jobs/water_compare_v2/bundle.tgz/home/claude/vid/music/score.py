import numpy as np, wave
SR=44100; DUR=45.0; HIT=40.0
n=int(SR*DUR); t=np.arange(n)/SR
out=np.zeros(n); rng=np.random.default_rng(7)
def note(f): return 440*2**((f-69)/12)
def saw(f,tt): return 2*((f*tt)%1)-1
def lp(x,a):  # one-pole lowpass, a in (0,1)
    y=np.empty_like(x); s=0.0
    for i in range(len(x)): s+=a*(x[i]-s); y[i]=s
    return y
def place(sig,start,gain=1.0):
    i=int(start*SR); j=min(n,i+len(sig))
    if i<n: out[i:j]+=gain*sig[:j-i]
# beat grid with accelerating tempo 96 -> 150 bpm up to HIT
beats=[0.0]; 
while beats[-1]<HIT:
    p=beats[-1]/HIT; bpm=96+54*p**1.6
    beats.append(beats[-1]+60/bpm)
beats=[b for b in beats if b<HIT]
# chord progression (minor, cinematic): Dm Bb Gm A
prog=[(50,[62,65,69]),(46,[58,62,65]),(43,[55,58,62]),(45,[57,61,64])]
def chord_at(i): return prog[(i//8)%4]
# 1. bass ostinato (eighths)
for k,b in enumerate(beats):
    root,_=chord_at(k)
    nb=beats[k+1] if k+1<len(beats) else b+0.4
    for h in range(2):
        st=b+h*(nb-b)/2; L=(nb-b)/2*0.9
        tt=np.arange(int(L*SR))/SR
        f=note(root-12 if h==0 else root)
        env=np.exp(-tt*6)
        sig=(saw(f,tt)+saw(f*1.005,tt))*env
        place(sig,st,0.18+0.1*(b/HIT))
# 2. heartbeat kick from 6s, every beat; double thump
def kick(L=0.35):
    tt=np.arange(int(L*SR))/SR
    f=45+90*np.exp(-tt*30); ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-tt*9)
K=kick()
for k,b in enumerate(beats):
    if b>6: place(K,b,0.55+0.25*(b/HIT))
    if b>22 and k%2==1: place(K*0.6,b+0.12*(60/120),0.4)
# 3. ticking clock (noise ticks) on beats from 12s, sixteenths from 28s
def tick(L=0.03):
    s=rng.standard_normal(int(L*SR)); s=s-lp(s,0.3)
    return s*np.exp(-np.arange(len(s))/SR*180)
for k,b in enumerate(beats):
    nb=beats[k+1] if k+1<len(beats) else b+0.4
    if b>12: place(tick(),b,0.12)
    if b>28:
        for q in (1,2,3): place(tick(),b+q*(nb-b)/4,0.07)
# 4. string pad: detuned saws, filtered, swelling
pad=np.zeros(n)
seg_starts=[beats[i] for i in range(0,len(beats),8)]
for si,st in enumerate(seg_starts):
    en=seg_starts[si+1] if si+1<len(seg_starts) else HIT
    _,ch=prog[si%4]
    tt=np.arange(int((en-st+0.3)*SR))/SR
    s=np.zeros_like(tt)
    for m in ch:
        for d in (-0.15,0,0.15):
            s+=saw(note(m-12)*2**(d/12),tt)
    env=np.minimum(1,tt/0.4)*np.minimum(1,(len(tt)/SR-tt)/0.3)
    i=int(st*SR); j=min(n,i+len(tt)); pad[i:j]+=(s*env)[:j-i]
pad=lp(pad,0.03)*np.clip((t-3)/30,0,1)*0.12
out+=pad
# 5. riser 32s -> HIT (noise sweep + rising tone)
rs=int(32*SR); re_=int(HIT*SR); rt=np.arange(re_-rs)/SR; p=rt/rt[-1]
noise=rng.standard_normal(len(rt)); hp=noise-lp(noise,0.05+0.5*0)
f=200+1800*p**2; tone=np.sin(2*np.pi*np.cumsum(f)/SR)
out[rs:re_]+= (0.10*hp+0.08*tone)*p**2.2
# drop everything 0.25s before hit (tension gap)
gap=int((HIT-0.25)*SR); out[gap:int(HIT*SR)]*=0.05
# 6. impact + final chord
it=np.arange(int(4*SR))/SR
boom=np.sin(2*np.pi*np.cumsum(38+120*np.exp(-it*8))/SR)*np.exp(-it*1.2)
crash=rng.standard_normal(len(it)); crash=(crash-lp(crash,0.2))*np.exp(-it*1.8)
place(boom,HIT,0.9); place(crash,HIT,0.25)
fl=np.arange(int((DUR-HIT)*SR))/SR; fc=np.zeros_like(fl)
for m in (38,50,57,62,65,69):
    fc+=saw(note(m),fl)+saw(note(m)*1.004,fl)
fc=lp(fc,0.04)*np.exp(-fl*0.7)*0.09
place(fc,HIT)
# master: soft clip, fade, normalize
out=np.tanh(out*1.4); out[:int(0.05*SR)]*=np.linspace(0,1,int(0.05*SR))
out[-int(1.5*SR):]*=np.linspace(1,0,int(1.5*SR))
out=out/np.max(np.abs(out))*0.89
st=np.stack([out,np.roll(out,int(0.012*SR))],1)  # slight stereo width
w=wave.open("/home/claude/vid/music/score.wav","wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
w.writeframes((st*32767).astype(np.int16).tobytes()); w.close(); print("ok")
