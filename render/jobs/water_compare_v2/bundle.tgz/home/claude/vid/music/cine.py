"""Cinematic tension bed for the pop race reels.
usage: python3 cine.py OUT.wav DUR BPM TRANSPOSE SEED [stops] [hits]
stops: "a-b,c-d"  seconds where the groove drops to a held drone (freeze moments)
hits:  "t1,t2"    seconds for a big impact (riser leads into each)
"""
import sys, numpy as np, wave
from scipy.signal import lfilter
out_p=sys.argv[1]; DUR=float(sys.argv[2]); BPM=float(sys.argv[3]); T=int(sys.argv[4]); seed=int(sys.argv[5])
stops=[tuple(map(float,s.split("-"))) for s in sys.argv[6].split(",")] if len(sys.argv)>6 and sys.argv[6] else []
hits=[float(x) for x in sys.argv[7].split(",")] if len(sys.argv)>7 and sys.argv[7] else []
SR=44100; n=int(SR*DUR); out=np.zeros(n); drum=np.zeros(n); rng=np.random.default_rng(seed)
def note(m): return 440*2**((m-69+T)/12)
def lp(x,a): return lfilter([a],[1,a-1],x)
def place(buf,sig,st,g=1.0):
    i=int(st*SR); j=min(n,i+len(sig))
    if 0<=i<n and j>i: buf[i:j]+=g*sig[:j-i]
def stopped(t): return any(a<=t<b for a,b in stops)
beat=60/BPM; bar=4*beat; nb=int(DUR/bar)+2
PROGS=[[(45,[57,60,64]),(41,[57,60,65]),(48,[55,60,64]),(43,[55,59,62])],
       [(45,[57,60,64]),(43,[55,59,62]),(41,[53,57,60]),(40,[56,59,64])],
       [(50,[62,65,69]),(46,[58,62,65]),(41,[57,60,65]),(45,[57,61,64])]]
prog=PROGS[seed%3]; r2=np.random.default_rng(seed*13)
mel=[[c[1][int(r2.integers(0,3))]+12 for _ in range(8)] for c in prog]
for b in range(nb):
    root,ch=prog[b%4]; st=b*bar; inten=min(1.0,0.5+st/(DUR*0.6))
    # pad (always, also under stops)
    L=bar+0.4; tt=np.arange(int(L*SR))/SR; pad=np.zeros_like(tt)
    for m in ch:
        for d in (-0.08,0.08): pad+=np.sin(2*np.pi*note(m-12)*2**(d/12)*tt)+0.25*np.sin(4*np.pi*note(m-12)*2**(d/12)*tt)
    env=np.minimum(1,tt/0.6)*np.minimum(1,(L-tt)/0.4); place(out,lp(pad*env,0.06),st,0.035)
    for q in range(16):  # 16th pulse bass (ostinato)
        t0=st+q*beat/4
        if stopped(t0): continue
        tt=np.arange(int(beat/4*0.9*SR))/SR; m=root-12+(12 if q%4==2 else 0)
        sig=(np.sin(2*np.pi*note(m)*tt)+0.3*np.sign(np.sin(2*np.pi*note(m)*tt)))*np.exp(-tt*14)
        place(out,lp(sig,0.2),t0,0.10*inten)
    for q in range(4):  # kick + low tom pattern
        t0=st+q*beat
        if stopped(t0) or b==0: continue
        tt=np.arange(int(0.35*SR))/SR; f=45+70*np.exp(-tt*25); place(drum,np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*8),t0,0.45*inten)
        if q in (1,3):
            nz=rng.standard_normal(int(0.2*SR)); nz=(nz-lp(nz,0.25))*np.exp(-np.arange(len(nz))/SR*22); place(drum,nz,t0,0.07*inten)
        if q==3 and b%2==1:
            tt=np.arange(int(0.3*SR))/SR; f=110+60*np.exp(-tt*18); place(drum,np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*9),t0+beat/2,0.25*inten)
    for q in range(8):  # hats
        t0=st+q*beat/2
        if stopped(t0) or b<1: continue
        nz=rng.standard_normal(int(0.04*SR)); nz=(nz-lp(nz,0.6))*np.exp(-np.arange(len(nz))/SR*90); place(drum,nz,t0,0.025*inten)
    if b>=2:  # plucked motif
        for q,m in enumerate(mel[b%4]):
            t0=st+q*beat/2
            if stopped(t0): continue
            tt=np.arange(int(0.45*SR))/SR; f=note(m)
            place(out,(np.sin(2*np.pi*f*tt)+0.3*np.sin(6*np.pi*f*tt)*np.exp(-tt*20))*np.exp(-tt*6),t0,0.05*inten)
for a,b_ in stops:  # tension drone + ticking clock during freeze
    L=b_-a; tt=np.arange(int(L*SR))/SR
    dr=sum(np.sin(2*np.pi*note(m)*tt*(1+0.002*np.sin(2*np.pi*0.5*tt))) for m in (33,40,45))
    place(out,dr*np.minimum(1,tt/0.15)*np.minimum(1,(L-tt)/0.05)*(0.6+0.4*tt/L),a,0.09)
    for k in range(int(L/(beat/2))):
        ct=np.arange(int(0.03*SR))/SR; place(drum,np.sin(2*np.pi*1800*ct)*np.exp(-ct*150),a+k*beat/2,0.12)
for h in hits:  # riser into impact
    rl=1.2; tt=np.arange(int(rl*SR))/SR; nz=rng.standard_normal(len(tt)); nz=nz-lp(nz,0.05)
    place(out,nz*(tt/rl)**2,h-rl,0.10)
    tt=np.arange(int(2.5*SR))/SR; f=38+90*np.exp(-tt*12); boom=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*2.2)
    nz=rng.standard_normal(len(tt)); nz=lp(nz,0.08)*np.exp(-tt*5)
    place(drum,boom,h,0.9); place(drum,nz,h,0.5)
    tt=np.arange(int(3*SR))/SR; ch=prog[0][1]; s=sum(np.sin(2*np.pi*note(m)*tt)+np.sin(2*np.pi*note(m-12)*tt) for m in ch)
    place(out,s*np.exp(-tt*1.1)*np.minimum(1,tt/0.02),h,0.05)
mix=np.tanh((out+drum)*1.4)
fo=int(1.5*SR); mix[-fo:]*=np.linspace(1,0,fo); mix[:int(0.02*SR)]*=np.linspace(0,1,int(0.02*SR))
mix=mix/np.max(np.abs(mix))*0.89
st=np.stack([mix,np.roll(mix,int(0.011*SR))],1)
w=wave.open(out_p,"wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((st*32767).astype(np.int16).tobytes()); w.close(); print("ok",out_p)
