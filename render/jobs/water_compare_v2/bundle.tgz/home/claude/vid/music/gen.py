import sys, numpy as np, wave
tag=sys.argv[1]; T=int(sys.argv[2]); B0=float(sys.argv[3]); B1=float(sys.argv[4]); seed=int(sys.argv[5]); mode=sys.argv[6]; arp=sys.argv[7]
src=open("/home/claude/vid/music/score.py").read()
progs={"minor":"[(50,[62,65,69]),(46,[58,62,65]),(43,[55,58,62]),(45,[57,61,64])]",
 "epic":"[(50,[62,65,69]),(48,[60,64,67]),(46,[58,62,65]),(48,[60,64,67])]",
 "dark":"[(50,[62,65,69]),(51,[63,67,70]),(50,[62,65,69]),(49,[61,65,68])]",
 "hope":"[(46,[58,62,65]),(48,[60,64,67]),(50,[62,65,69]),(45,[57,61,64])]"}
import re
pr=progs[mode]; pr=re.sub(r"\d+",lambda m:str(int(m.group())+T),pr)
s=src.replace("prog=[(50,[62,65,69]),(46,[58,62,65]),(43,[55,58,62]),(45,[57,61,64])]","prog="+pr)
s=s.replace("bpm=96+54*p**1.6",f"bpm={B0}+{B1}*p**1.5").replace("default_rng(7)",f"default_rng({seed})")
s=s.replace("for m in (38,50,57,62,65,69):",f"for m in [x+{T} for x in (38,50,57,62,65,69)]:")
if arp!="none":
    pat={"up":[0,1,2,1],"down":[2,1,0,1],"skip":[0,2,1,2]}[arp]
    s=s.replace("# 5. riser",f'''arpz=np.zeros(n)
for k2,b in enumerate(beats):
    if b<10: continue
    _,ch=chord_at(k2); nb=beats[k2+1] if k2+1<len(beats) else b+0.4
    for q in range(4):
        st=b+q*(nb-b)/4; L=0.18; tt=np.arange(int(L*SR))/SR
        f=note(ch[{pat}[q]]+12); sig=(np.sin(2*np.pi*f*tt)+0.3*np.sin(4*np.pi*f*tt))*np.exp(-tt*14)
        i=int(st*SR); j=min(n,i+len(sig))
        if i<n: arpz[i:j]+=sig[:j-i]
out+=arpz*0.07*np.clip((t-10)/20,0.3,1)
# 5. riser''')
s=s.replace("music/score.wav",f"music/s_{tag}.wav")
exec(compile(s,"gen","exec"))
