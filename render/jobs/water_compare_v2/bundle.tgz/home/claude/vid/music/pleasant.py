import sys, numpy as np, wave
tag=sys.argv[1]; T=int(sys.argv[2]); BPM=float(sys.argv[3]); seed=int(sys.argv[4])
SR=44100; DUR=45.0; n=int(SR*DUR); t=np.arange(n)/SR; out=np.zeros(n); rng=np.random.default_rng(seed)
def note(m): return 440*2**((m-69+T)/12)
def place(sig,st,g=1.0):
    i=int(st*SR); j=min(n,i+len(sig))
    if i<n: out[i:j]+=g*sig[:j-i]
def lp(x,a):
    y=np.empty_like(x); s=0.0
    for i in range(len(x)): s+=a*(x[i]-s); y[i]=s
    return y
beat=60/BPM; bar=4*beat
prog=[(48,[60,64,67,71]),(43,[59,62,67,71]),(45,[60,64,69,72]),(41,[60,65,69,72])]  # Cmaj7 G Am F(add)
nbars=int(DUR/bar)+1
def epiano(f,L,vel=1.0):
    tt=np.arange(int(L*SR))/SR
    s=np.sin(2*np.pi*f*tt)+0.35*np.sin(4*np.pi*f*tt)*np.exp(-tt*3)+0.12*np.sin(6*np.pi*f*tt)*np.exp(-tt*6)
    return vel*s*np.exp(-tt*2.2)*np.minimum(1,tt/0.005)
for b in range(nbars):
    root,ch=prog[b%4]; st=b*bar; inten=min(1,0.35+st/32)
    # pad
    L=bar+0.4; tt=np.arange(int(L*SR))/SR; pad=np.zeros_like(tt)
    for m in ch: pad+=np.sin(2*np.pi*note(m-12)*tt)+0.5*np.sin(2*np.pi*note(m-12)*1.003*tt)
    env=np.minimum(1,tt/0.8)*np.minimum(1,(L-tt)/0.6); place(pad*env,st,0.035*(0.6+0.4*inten))
    # sub bass
    for q in (0,2):
        tt=np.arange(int(beat*1.8*SR))/SR; place(np.sin(2*np.pi*note(root-12)*tt)*np.exp(-tt*1.5)*np.minimum(1,tt/0.01),st+q*beat,0.22*inten)
    # e-piano arpeggio in 8ths
    pat=[0,1,2,3,2,1,2,3]
    for q in range(8):
        if st<2 and q%2: continue
        m=ch[pat[q]]+(12 if (q==3 and b%2) else 0)
        place(epiano(note(m),0.9,0.5+0.2*(q%4==0)),st+q*beat/2,0.07)
    # melody bell from bar 4
    if b>=4:
        mel=[ch[3]+12,ch[2]+12,ch[3]+12,ch[1]+12] if b%2==0 else [ch[2]+12,ch[3]+12,ch[2]+12,ch[0]+12]
        for q,m in enumerate(mel):
            tt=np.arange(int(1.2*SR))/SR; f=note(m)
            place((np.sin(2*np.pi*f*tt)+0.2*np.sin(2*np.pi*2.76*f*tt)*np.exp(-tt*8))*np.exp(-tt*3),st+q*beat,0.045*inten)
    # soft clap on 2 and 4, shaker 16ths after bar 2
    if b>=2:
        for q in (1,3):
            nz=rng.standard_normal(int(0.12*SR)); nz=(nz-lp(nz,0.25))*np.exp(-np.arange(len(nz))/SR*30); place(nz,st+q*beat,0.05*inten)
        for q in range(16):
            nz=rng.standard_normal(int(0.04*SR)); nz=(nz-lp(nz,0.6))*np.exp(-np.arange(len(nz))/SR*90); place(nz,st+q*beat/4,0.018*(1.3 if q%2 else 0.8)*inten)
    # kick soft
    if b>=2:
        for q in (0,2.5):
            tt=np.arange(int(0.3*SR))/SR; f=50+60*np.exp(-tt*25); place(np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*10),st+q*beat,0.35*inten)
# final warm chord at 40s
tt=np.arange(int(5*SR))/SR; fc=np.zeros_like(tt)
for m in (48,55,60,64,67,71,76): fc+=np.sin(2*np.pi*note(m)*tt)+0.4*np.sin(2*np.pi*note(m)*1.002*tt)
place(fc*np.exp(-tt*0.6)*np.minimum(1,tt/0.05),40,0.04)
out=np.tanh(out*1.2); out[-int(2*SR):]*=np.linspace(1,0,int(2*SR)); out=out/np.max(np.abs(out))*0.85
st=np.stack([out,np.roll(out,int(0.015*SR))],1)
w=wave.open(f"/home/claude/vid/music/p_{tag}.wav","wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((st*32767).astype(np.int16).tobytes()); w.close(); print("ok")
