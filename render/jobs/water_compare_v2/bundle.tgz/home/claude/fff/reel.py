"""FIGHT, FLIGHT, FREEZE reel.
usage: nice -n 15 python3 reel.py --snaps t1,t2,...  |  --render [--resume]
"""
import sys, os, json, math, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, "/home/claude/fff")
from lib import *

ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--render", action="store_true"); ap.add_argument("--resume", action="store_true")
A = ap.parse_args()
D = "/home/claude/fff"; QA = f"{D}/qa"; os.makedirs(QA, exist_ok=True)
TTS = [l.strip() for l in open(f"{D}/tts_v4.txt") if l.strip()]
for l in TTS: assert not any(d in l for d in DASHES), l
SEGS = json.load(open(f"{D}/vo/segs.json"))["segs"]
assert len(SEGS) == 15 == len(TTS)
B = [0.0] + [s[0] - 0.12 for s in SEGS[1:]]
T_END = SEGS[-1][1] + 1.0
N = int(round(T_END * FPS))
def dur(i): return (B[i + 1] if i + 1 < len(B) else T_END) - B[i]
def at(i, frac): return B[i] + frac * dur(i)
SF = json.load(open(f"{D}/vo/segs_full.json")); CH = SF["chunks"]; FS = SF["segs"]
CT = {}
for si, (f0, f1) in enumerate(FS):
    g = [k for k, ch in enumerate(CH) if ch[0] >= f0 - 0.01 and ch[1] <= f1 + 0.01]
    g0, g1 = CH[g[0]][0], CH[g[-1]][1]; s0, s1 = SEGS[si]
    for k in g: CT[k] = tuple(s0 + (CH[k][j] - g0) / (g1 - g0) * (s1 - s0) for j in (0, 1))
assert sorted(CT) == list(range(len(CH)))
def cw(k, j=0): return CT[k][j]
print("total", round(T_END, 2), "frames", N)

ORANGE = hx("#FF9F43"); ICE = hx("#A8E6FF"); SEPIA = hx("#D9BC8C"); SEPD = hx("#2B2118")
FRONT = (0.96, 0.975, 1.0, 1); BACKC = (0.72, 0.80, 0.93, 1); COLL = (0.55, 0.64, 0.80, 1)
R255 = (255, 90, 110, 255); O255 = (255, 170, 90, 255); I255 = (168, 230, 255, 255)

# ------------------------------------------------------------------ extra brain layers (soft blue amygdala for the calm state)
def L_amygb(c): amyg_path(c); c.set_source_rgba(*SKY[:3], 1); c.fill_preserve(); stroke_style(c, (0.9, 0.97, 1, 1), 5); c.stroke()
def L_amygb_g(c): amyg_path(c); c.set_source_rgba(*SKY[:3], 1); c.fill()
def L_alarm_g(c):
    c.save(); cerebrum_path(c); c.clip(); c.set_source_rgba(*RED[:3], 1); c.arc(-104, 100, 230, 0, 2 * math.pi); c.fill(); c.restore()
BR.update(amygb=layer(L_amygb), amygb_g=layer(L_amygb_g, 22, 2.0), alarm_g=layer(L_alarm_g, 40, 1.0))
def brain(c, cx, cy, sc, a, t, alarm=0.0, calm=0.0, flash=8.0):
    """alarm: 0..1 red amygdala with flashing; calm: 0..1 blend to soft blue"""
    if a <= 0.01: return
    c.save(); c.translate(cx, cy); c.scale(sc, sc); c.translate(-BOX, -BOY)
    def P(k, al):
        if al > 0.01: c.set_source_surface(BR[k], 0, 0); c.paint_with_alpha(min(1, al))
    P("rimglow", a * (0.35 + 0.1 * math.sin(t * 1.6))); P("base", a); P("ghost", a * 0.5)
    fl = 0.5 + 0.5 * math.sin(t * flash)
    r = alarm * (1 - calm)
    if r > 0.01: P("alarm_g", a * r * (0.15 + 0.45 * fl)); P("amyg_g", a * r * (0.5 + 0.5 * fl)); P("amyg", a * r)
    if calm > 0.01:
        pul = 0.8 + 0.2 * math.sin(t * 1.8); P("amygb_g", a * calm * pul); P("amygb", a * calm)
    P("rim", a); c.restore()
def amyg_xy(cx, cy, sc): return cx - 104 * sc, cy + 100 * sc
def alarm_rings(c, x, y, t, a, col=RED, n=3, period=0.9, rmax=260):
    if a <= 0.01: return
    for k in range(n):
        u = ((t / period) + k / n) % 1
        stroke_style(c, (*col[:3], a * (1 - u) * 0.7), 6 * (1 - u) + 2); c.arc(x, y, 20 + rmax * u, 0, 2 * math.pi); c.stroke()
def vignette(c, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(540, 960, 380, 540, 960, 1150); g.add_color_stop_rgba(0, *col[:3], 0); g.add_color_stop_rgba(1, *col[:3], a)
    c.set_source(g); c.paint()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 10, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()

# ------------------------------------------------------------------ heart-rate line
_GRID = np.arange(-10, T_END + 10, 0.005)
def bpm_of(tau):
    if tau < B[1] + 2.2: return 72
    if tau < B[3]: return lerp(72, 150, ramp(tau, B[1] + 2.2, B[1] + 3.0))
    if tau < B[9]: return 150
    return lerp(150, 64, ramp(tau, B[9], B[10] + 2.5))
_PH = np.cumsum([bpm_of(x) / 60 * 0.005 for x in _GRID])
def ecg_val(tau, amp):
    i = int(np.clip((tau + 10) / 0.005, 0, len(_PH) - 1)); p = _PH[i] % 1.0
    v = 0.12 * math.exp(-((p - 0.15) / 0.04) ** 2) - 0.18 * math.exp(-((p - 0.30) / 0.012) ** 2) + 1.0 * math.exp(-((p - 0.33) / 0.014) ** 2)
    v += -0.32 * math.exp(-((p - 0.36) / 0.012) ** 2) + 0.22 * math.exp(-((p - 0.55) / 0.05) ** 2)
    return v * amp
def ecg(c, x0, x1, y, t, amp, col, a, speed=420, lw=6):
    if a <= 0.01: return
    pts = []
    for x in range(int(x0), int(x1) + 1, 4):
        tau = t - (x1 - x) / speed; pts.append((x, y - ecg_val(tau, amp(tau) if callable(amp) else amp)))
    c.save(); c.rectangle(x0, y - 200, x1 - x0, 400); c.clip()
    g = cairo.LinearGradient(x0, 0, x1, 0); g.add_color_stop_rgba(0, *col[:3], 0); g.add_color_stop_rgba(0.25, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], a)
    c.set_source(g); c.set_line_width(lw); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke(); c.restore()
    c.set_source_rgba(*col[:3], a); c.arc(pts[-1][0], pts[-1][1], 10, 0, 2 * math.pi); c.fill()
    glow(c, pts[-1][0], pts[-1][1], 50, col, 0.5 * a)

# ------------------------------------------------------------------ faceless front figure (feet at y=0, head at y=-256)
def figure(c, x, y, s, t, pose="idle", col=FRONT, back=BACKC, a=1.0, jit=0.0, breathe=1.0, lean=0.0):
    if a <= 0.01: return
    c.push_group(); c.save(); c.translate(x + jit, y); c.scale(s, s)
    b = -3 * math.sin(t * 2.0) * breathe
    hip_y = -118; sh_y = -200 + b; hd = (lean * 20, -258 + b)
    stroke_style(c, col, 24)
    c.move_to(-17, hip_y); c.line_to(-26, -2); c.move_to(17, hip_y); c.line_to(26, -2); c.stroke()
    def arm(p, e, h, cl, w=19): stroke_style(c, cl, w); c.move_to(*p); c.line_to(*e); c.line_to(*h); c.stroke()
    L, R = (-40, sh_y + 8), (40, sh_y + 8)
    if pose == "crossed":
        arm(L, (-50, sh_y + 60), (30, sh_y + 52), back)
    rr(c, -44 + lean * 8, sh_y - 8, 88, hip_y - sh_y + 22, 34); c.set_source_rgba(*col); c.fill()
    c.set_source_rgba(*col); c.arc(*hd, 40, 0, 2 * math.pi); c.fill()
    if pose == "idle":
        arm(L, (-56, sh_y + 52), (-58, sh_y + 104), col); arm(R, (56, sh_y + 52), (58, sh_y + 104), col)
    elif pose == "crossed":
        arm(R, (50, sh_y + 60), (-32, sh_y + 46), col)
    elif pose == "frozen":
        arm(L, (-50, sh_y + 50), (-50, sh_y + 108), col); arm(R, (50, sh_y + 50), (50, sh_y + 108), col)
    elif pose == "talk":
        w = math.sin(t * 3.2)
        arm(L, (-56, sh_y + 52), (-58, sh_y + 104), col); arm(R, (70, sh_y + 46), (110 + 12 * w, sh_y - 4 + 14 * w), col)
    elif pose == "point":
        arm(L, (-56, sh_y + 52), (-58, sh_y + 104), col); arm(R, (84, sh_y + 6), (150, sh_y - 14), col)
    elif pose == "open":
        w = math.sin(t * 2.4)
        arm(L, (-74, sh_y + 44), (-120, sh_y + 10 + 6 * w), col); arm(R, (74, sh_y + 44), (120, sh_y + 10 - 6 * w), col)
    c.restore(); c.pop_group_to_source(); c.paint_with_alpha(min(1, a))
    return x + jit + hd[0] * s, y + hd[1] * s

# ------------------------------------------------------------------ captions
CAPS = [  # beat -> parts (+ optional highlight colour)
    ([("head", "Why your mind\ngoes *blank*\nin English", 116), ("he", "למה הראש מתרוקן באנגלית", 66)], None),
    ([("body", "Your brain hears\n*DANGER*", 104), ("he", "המוח שומע סכנה", 68)], (255, 90, 110, 255)),
    ([("body", "Shame. Frustration.\n*Again and again.*", 88), ("he", "בושה. תסכול. שוב ושוב.", 66)], None),
    ([("body", "Mistake =\n*I look stupid*", 100), ("he", "טעות = אני נראה טיפש", 66)], None),
    ([("body", "The alarm:\n*3 reactions*", 100), ("he", "האזעקה: 3 תגובות", 66)], None),
    ([("head", "*FIGHT*", 160), ("he", "להילחם", 72)], R255),
    ([("head", "*FLIGHT*", 160), ("he", "לברוח", 72)], O255),
    ([("head", "*FREEZE*", 160), ("he", "לקפוא", 72)], I255),
    ([("body", "Not a language problem.\n*Protection.*", 80), ("he", "זו לא בעיה של שפה. זו הגנה.", 64)], None),
    ([("body", "The fix:\n*trust yourself*", 100), ("he", "הפתרון: לסמוך על עצמכם", 66)], None),
    ([("body", "Gently.\n*Step by step.*", 100), ("he", "בעדינות. צעד אחר צעד.", 66)], None),
    ([("body", "Who\n*corrects* you?", 104), ("he", "מי מתקן אתכם?", 68)], None),
    ([("body", "Correct yourself.\n*Kindly.*", 96), ("he", "לתקן את עצמכם. בעדינות.", 66)], None),
]
CAPY = 270
CAP_S, CAP_H = [], []
for k, (parts, hl) in enumerate(CAPS):
    im = caption(parts, 1.04 if k == 0 else 1.10, hl=hl or (255, 213, 74, 255)); CAP_S.append(pil2cairo(im)); CAP_H.append(im.size[1])
    nw = sum(len([w for w in re.split(r"\s+", s.replace("*", "")) if re.search("[A-Za-z]", w)]) for kk, s, _ in parts if kk != "he")
    assert nw <= 12, parts
print("caption bottoms", [CAPY + h for h in CAP_H])

# ------------------------------------------------------------------ cue times
T_DANGER = cw(2, 0) - 0.15; T_D2 = cw(3, 0)
T_SCHOOL, T_WORK, T_SHAME, T_FRUS, T_AGAIN = cw(4), cw(5), cw(6), cw(7), cw(8)
T_RULE, T_STAMP = cw(9), cw(10) + 0.25
T_AMY, T_3W = cw(11), cw(12)
T_FIGHT, T_FINE, T_DEF, T_AGG = cw(13), cw(14), cw(15), cw(16)
_f0, _f1 = cw(17, 0), cw(17, 1); T_FLIGHT, T_MEET, T_COLL = _f0, _f0 + 0.2 * (_f1 - _f0), _f0 + 0.6 * (_f1 - _f0); T_ESC = cw(18)
T_FREEZE, T_WORDS, T_NOTH = cw(19), cw(20), cw(21)
T_NOTLANG, T_PROT, T_SAFE = cw(22), cw(23), cw(24)
T_GRAM, T_TRUST, T_RELY = cw(25), cw(26), cw(27)
T_GENT, T_STEP, T_FORCE = cw(28), cw(29), cw(30)
T_TEACH, T_WHEN = cw(31), cw(32)
T_TALK, T_CATCH, T_FIX, T_QUIET = cw(33), cw(34), cw(35), cw(36)
PLANK_T = [T_TRUST, T_TRUST + 0.4, T_RELY, T_RELY + 0.6, T_GENT, T_STEP, T_STEP + 0.45, T_FORCE]
PEN_T = [T_TEACH + 0.1 + k * 0.55 for k in range(4)]
SHIELD_HITS = [T_PROT + 0.35, T_PROT + 1.1, T_SAFE + 0.4, T_SAFE + 1.2]
CUES = dict(B=B, T_END=T_END, BEEPS=[T_DANGER + 0.3, T_D2, T_AMY, T_AMY + 0.5, T_AMY + 1.0], HEART=[T_DANGER, B[3]], STAMP=T_STAMP,
            FLASH=[T_SCHOOL, T_WORK], STACK=[T_SHAME, T_FRUS] + [T_AGAIN + 0.3 * k for k in range(4)],
            FORK=[T_3W + 0.2 + 0.25 * k for k in range(3)], FIGHT_HIT=[T_FIGHT, T_FINE], FLIGHT=[T_FLIGHT, T_ESC], DOOR=T_ESC + 0.5,
            FROST=T_FREEZE, SHIELD=T_NOTLANG + 0.3, HITS=SHIELD_HITS, PLANKS=PLANK_T, PEN=PEN_T, CHIME=[T_FIX], QUIET=T_QUIET,
            WARM=B[9], WHOOSH=[T_DANGER, B[2], B[3], B[4], B[5], B[6], B[7], B[8], B[9], B[11], B[12]], CARDS=[B[13], B[14]])
json.dump(CUES, open(f"{D}/cues.json", "w"))

# ------------------------------------------------------------------ scene 0: meeting (hook) -> zoom into the head
BUB_Q = bubble("Can you walk us through it?", "speech", 54)
def table(c, y, x0, x1, a):
    rr(c, x0, y, x1 - x0, 40, 14); c.set_source_rgba(*hx("#0B1A36")[:3], 0.96 * a); c.fill_preserve(); stroke_style(c, (*LIGHT[:3], 0.45 * a), 4); c.stroke()
    c.set_source_rgba(*hx("#0B1A36")[:3], 0.7 * a); c.rectangle(x0 + 60, y + 40, 26, 160); c.rectangle(x1 - 86, y + 40, 26, 160); c.fill()
def scene_meeting(c, t):
    a = 1 - ramp(t, T_DANGER - 0.05, T_DANGER + 0.3)
    if a <= 0.01: return
    z = ramp(t, T_DANGER - 0.45, T_DANGER + 0.3)          # zoom into the head
    c.save(); c.translate(600, 1150); c.scale(1 + 1.6 * z ** 2, 1 + 1.6 * z ** 2); c.translate(-600, -1150)
    c.push_group()
    glow(c, 540, 1180, 520, SKY, 0.18)
    figure(c, 190, 1380, 0.92, t + 1, "idle", COLL, COLL)
    figure(c, 900, 1380, 0.92, t + 2, "idle", COLL, COLL)
    hx_, hy_ = figure(c, 600, 1540, 1.25, t, "idle")
    table(c, 1370, 90, 990, 1.0)
    # colleague question
    paste(c, BUB_Q, 82, 770 + 4 * math.sin(t * 2), 1.0, anchor="tl")
    # blank thought: empty white box above the head
    bx, by = 690, 925; bw, bh = 300, 170
    for k, (dx, dy, r) in enumerate(((hx_ + 40, hy_ - 64, 12), (hx_ + 64, hy_ - 104, 18))): c.set_source_rgba(1, 1, 1, 0.95); c.arc(dx, dy, r, 0, 2 * math.pi); c.fill()
    glow(c, bx + bw / 2, by + bh / 2, 260, (1, 1, 1, 1), 0.18 + 0.06 * math.sin(t * 3))
    rr(c, bx, by, bw, bh, 26); c.set_source_rgba(1, 1, 1, 1); c.fill()
    if (t * 2.2) % 1 < 0.55: c.set_source_rgba(*NAVY[:3], 1); c.rectangle(bx + 44, by + 52, 9, bh - 104); c.fill()
    # small sweat drop for pressure
    u = (t * 0.7) % 1; c.set_source_rgba(*LIGHT[:3], 0.8 * (1 - u)); c.arc(hx_ - 52, hy_ - 10 + 40 * u, 9, 0, 2 * math.pi); c.fill()
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()
    if z > 0.3: c.set_source_rgba(1, 1, 1, 0.5 * (1 - abs(z - 0.75) / 0.45) if abs(z - 0.75) < 0.45 else 0); c.paint()

# ------------------------------------------------------------------ scene 1: brain alarm
def tension(c, cx, cy, t, a):
    if a <= 0.01: return
    for k in range(8):
        ang = k / 8 * 2 * math.pi + 0.2; r0 = 420 + 18 * math.sin(t * 9 + k)
        x, y = cx + r0 * math.cos(ang), cy + 0.82 * r0 * math.sin(ang)
        stroke_style(c, (*RED[:3], a * (0.5 + 0.5 * math.sin(t * 12 + k * 2))), 7)
        c.move_to(x, y)
        for j in range(1, 4):
            rr_ = r0 + j * 22; d = 14 * (1 if j % 2 else -1)
            c.line_to(cx + rr_ * math.cos(ang) - d * math.sin(ang), cy + 0.82 * (rr_ * math.sin(ang) + d * math.cos(ang)))
        c.stroke()
def scene_danger(c, t):
    a = win(t, T_DANGER, B[2] + 0.15, 0.25, 0.35)
    if a <= 0.01: return
    al = ramp(t, T_D2 - 0.2, T_D2 + 0.1)
    sc = lerp(1.3, 0.92, ease((t - T_DANGER) / 0.6))
    cx, cy = 540, 1010 + 4 * math.sin(t * 7) * al
    vignette(c, RED, 0.35 * al * (0.6 + 0.4 * math.sin(t * 8)) * a)
    brain(c, cx, cy, sc, a, t, alarm=max(0.35 * ramp(t, T_DANGER, T_DANGER + 0.4), al))
    ax, ay = amyg_xy(cx, cy, sc); alarm_rings(c, ax, ay, t, a * al)
    tension(c, cx, cy, t, a * al * 0.8)
    ecg(c, 100, 980, 1440, t, 70, RED, a * ramp(t, T_DANGER + 0.2, T_DANGER + 0.6))

# ------------------------------------------------------------------ scene 2: sepia flashbacks
def sepia_rgba(col, al=1.0): return (*col[:3], al)
SEP_HA = T("HA", 46, 900, (240, 215, 170, 255)); SEP_HA2 = T("HA HA", 44, 900, (240, 215, 170, 255))
SEP_ACT = bubble("Actually, it's...", "speech", 46, (43, 33, 24, 255), (232, 214, 180, 245))
def polaroid(c, kind, cx, cy, rot, sc, a, t, tk):
    if a <= 0.01: return
    c.push_group(); c.save(); c.translate(cx, cy); c.rotate(rot); c.scale(sc, sc)
    rr(c, -350, -270, 700, 560, 14); c.set_source_rgba(0.90, 0.85, 0.76, 1); c.fill()
    c.save(); rr(c, -320, -240, 640, 450, 6); c.clip(); c.set_source_rgba(*SEPD); c.paint()
    ink = sepia_rgba(SEPIA, 1); dim = sepia_rgba(SEPIA, 0.55)
    if kind == "class":
        rr(c, -220, -210, 440, 150, 6); c.set_source_rgba(0.16, 0.20, 0.16, 1); c.fill_preserve(); stroke_style(c, dim, 6); c.stroke()
        stroke_style(c, (0.85, 0.82, 0.7, 0.6), 4)
        for k in range(3): c.move_to(-180, -170 + k * 36); c.line_to(-60 + 70 * (k % 2), -170 + k * 36); c.stroke()
        # standing kid (us), lighter
        c.set_source_rgba(0.96, 0.9, 0.78, 1); c.arc(250, -60, 26, 0, 2 * math.pi); c.fill(); rr(c, 222, -30, 56, 120, 22); c.fill()
        for row in range(2):
            for k in range(5):
                x = -260 + k * 110 + 50 * row; y = 70 + row * 110
                shake = 5 * math.sin(t * 16 + k * 2 + row) * ramp(t, tk + 0.3, tk + 0.6)
                c.set_source_rgba(*SEPIA[:3], 0.75 + 0.1 * row); c.arc(x + shake, y - 34, 26, 0, 2 * math.pi); c.fill(); rr(c, x - 38, y - 6, 76, 90, 30); c.fill()
        for k, (x, y) in enumerate(((-200, -20), (60, 10), (-60, -40))):
            tt = tk + 0.35 + 0.22 * k
            if t > tt: paste(c, SEP_HA if k != 1 else SEP_HA2, x, y - 10 * ease((t - tt) / 0.4), ramp(t, tt, tt + 0.15), sc=eob(min(1, (t - tt) / 0.3)))
    else:
        rr(c, -300, 60, 600, 30, 8); c.set_source_rgba(*SEPIA[:3], 0.6); c.fill()
        for x in (-210, 210):
            c.set_source_rgba(*SEPIA[:3], 0.7); c.arc(x, -30, 30, 0, 2 * math.pi); c.fill(); rr(c, x - 44, 4, 88, 60, 26); c.fill()
        c.set_source_rgba(0.96, 0.9, 0.78, 1); c.arc(0, -10, 30, 0, 2 * math.pi); c.fill(); rr(c, -44, 24, 88, 40, 20); c.fill()   # us, centre, small
        stroke_style(c, sepia_rgba(SEPIA, 0.8), 16); pu = ramp(t, tk + 0.2, tk + 0.5)
        c.move_to(210 - 34, 14); c.line_to(lerp(176, 90, pu), lerp(14, -16, pu)); c.stroke()
        if t > tk + 0.35: paste(c, SEP_ACT, 290, -230, ramp(t, tk + 0.35, tk + 0.5), sc=eob(min(1, (t - tk - 0.35) / 0.3)), anchor="tr")
    # film grain lines
    for k in range(3):
        x = ((t * 300 + k * 233) % 640) - 320; c.set_source_rgba(1, 1, 1, 0.06); c.rectangle(x, -240, 3, 450); c.fill()
    c.restore(); c.restore(); c.pop_group_to_source(); c.paint_with_alpha(a * (0.92 + 0.08 * math.sin(t * 23)))
STACK_P = [pill("SHAME", 60, (255, 255, 255, 255), (150, 40, 60, 235), (255, 120, 140, 255)), pill("FRUSTRATION", 60, (255, 255, 255, 255), (150, 70, 30, 235), (255, 170, 100, 255))]
X3 = T("x3", 110, 900, Y255)
def scene_flash(c, t):
    a = win(t, B[2] - 0.1, B[3] + 0.1, 0.35, 0.35)
    if a <= 0.01: return
    vignette(c, SEPIA, 0.12 * a)
    rep = [T_SCHOOL, T_WORK, T_AGAIN, T_AGAIN + 0.3, T_AGAIN + 0.6, T_AGAIN + 0.9]
    poses = [("class", 530, 950, -0.05), ("work", 555, 990, 0.06), ("class", 515, 965, -0.10), ("work", 565, 980, 0.09), ("class", 535, 960, -0.02), ("work", 545, 975, 0.04)]
    for k, (tk, (kind, x, y, rot)) in enumerate(zip(rep, poses)):
        if t < tk - 0.05: continue
        u = ramp(t, tk - 0.05, tk + 0.3); sc = lerp(1.25, 1.0, eob(u)) * (0.92 if k else 1.0)
        polaroid(c, kind, x, y + 30 * (1 - u), rot * u, sc * 1.08, a * u, t, tk)
    # stacking labels
    for k, tk in enumerate([T_SHAME, T_FRUS]):
        u = ramp(t, tk - 0.1, tk + 0.2)
        if u > 0.01: paste(c, STACK_P[k], 540, 1330 + 110 * k, a * u, sc=eob(min(1, (t - tk + 0.1) / 0.3)))
    ux = ramp(t, T_AGAIN + 0.6, T_AGAIN + 0.9)
    if ux > 0.01: paste(c, X3, 900, 1385, a * ux, sc=eob(min(1, (t - T_AGAIN - 0.6) / 0.3)) * (1 + 0.06 * math.sin(t * 8)))

# ------------------------------------------------------------------ scene 3: the rule is stamped
def make_stamp():
    f = font(88, 900); s_ = "MISTAKE = STUPID"; tw = f.getlength(s_); pw, ph = int(tw + 90), 170
    im = Image.new("RGBA", (pw + 20, ph + 20), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([10, 10, 10 + pw, 10 + ph], radius=24, outline=(255, 70, 95, 255), width=12)
    d.text((10 + pw / 2, 10 + ph / 2 + 4), s_, font=f, fill=(255, 70, 95, 255), anchor="mm")
    a = np.asarray(im).astype(np.float32); rng = np.random.default_rng(3)
    nz = np.asarray(Image.fromarray((rng.random(a.shape[:2]) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.6))).astype(np.float32)
    a[:, :, 3] *= np.clip((nz - 98) / 22, 0.25, 1.0); assert pw + 20 < 930
    return pil2cairo(Image.fromarray(a.astype(np.uint8), "RGBA"))
STAMP = make_stamp()
def scene_rule(c, t):
    a = win(t, B[3] - 0.1, B[4] + 0.1, 0.35, 0.3)
    if a <= 0.01: return
    cx, cy, sc = 540, 1060 + 5 * math.sin(t), 0.9
    hit = ramp(t, T_STAMP, T_STAMP + 0.08)
    shake = 10 * math.sin(t * 60) * (1 - ramp(t, T_STAMP, T_STAMP + 0.35)) * hit
    brain(c, cx + shake, cy, sc, a, t, alarm=0.25 + 0.5 * hit, flash=4)
    if t > T_STAMP - 0.3:
        u = ramp(t, T_STAMP - 0.3, T_STAMP)
        c.save(); c.translate(540 + shake, 1060); c.rotate(-0.09); s = lerp(2.4, 1.0, u ** 2); c.scale(s, s)
        paste(c, STAMP, 0, 0, a * u); c.restore()
        if hit > 0 and t < T_STAMP + 0.6:
            r = 160 + 500 * ramp(t, T_STAMP, T_STAMP + 0.6); stroke_style(c, (*RED[:3], a * 0.6 * (1 - ramp(t, T_STAMP, T_STAMP + 0.6))), 8); c.arc(540, 1060, r, 0, 2 * math.pi); c.stroke()

# ------------------------------------------------------------------ scene 4: the alarm forks into three
FORK = [("FIGHT", RED, R255, 210), ("FLIGHT", ORANGE, O255, 540), ("FREEZE", ICE, I255, 870)]
FORK_L = [pill(n, 48, N255, tuple(int(v * 255) for v in col[:3]) + (255,), (255, 255, 255, 255)) for n, col, _, _ in FORK]
def scene_fork(c, t):
    a = win(t, B[4] - 0.1, B[5] + 0.15, 0.35, 0.35)
    if a <= 0.01: return
    cx, cy, sc = 540, 790, 0.58
    al = ramp(t, T_AMY, T_AMY + 0.3)
    vignette(c, RED, 0.28 * al * (0.6 + 0.4 * math.sin(t * 8)) * a)
    brain(c, cx, cy, sc, a, t, alarm=0.4 + 0.6 * al)
    ax, ay = amyg_xy(cx, cy, sc); alarm_rings(c, ax, ay, t, a * al, rmax=200)
    for k, (name, col, _, x) in enumerate(FORK):
        tk = T_3W + 0.2 + 0.25 * k; u = ramp(t, tk, tk + 0.6)
        if u <= 0.01: continue
        p0 = (ax, ay + 20); p3 = (x, 1300)
        c.save(); stroke_style(c, (*col[:3], 0.9 * a), 14); c.move_to(*p0)
        # draw partial bezier by sampling
        pts = []
        for j in range(41):
            s = j / 40 * u; m = 1 - s
            bx_ = m ** 3 * p0[0] + 3 * m * m * s * p0[0] + 3 * m * s * s * x + s ** 3 * x
            by_ = m ** 3 * p0[1] + 3 * m * m * s * (p0[1] + 220) + 3 * m * s * s * (p3[1] - 260) + s ** 3 * p3[1]
            pts.append((bx_, by_))
        for p in pts[1:]: c.line_to(*p)
        c.stroke(); c.restore()
        glow(c, pts[-1][0], pts[-1][1], 90, col, 0.6 * a)
        if u > 0.9:
            v = ramp(t, tk + 0.5, tk + 0.8)
            c.set_source_rgba(*col[:3], a * v); c.arc(x, 1300, 26, 0, 2 * math.pi); c.fill()
            paste(c, FORK_L[k], x, 1405, a * v, sc=eob(min(1, (t - tk - 0.5) / 0.3)))

# ------------------------------------------------------------------ scene 5: FIGHT
def jag_bubble(text, sz=62):
    t_ = text_img(text, sz, 900, N255, pad=0); tw, th = t_.size; pw, ph = tw + 120, th + 110
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, pw + 40, ph + 80); c = cairo.Context(s); cx, cy = (pw + 40) / 2, (ph + 40) / 2
    n = 26
    for k in range(n * 2 + 1):
        ang = k / (n * 2) * 2 * math.pi; r = 1.0 if k % 2 == 0 else 0.86
        x, y = cx + r * (pw / 2) * math.cos(ang), cy + r * (ph / 2) * math.sin(ang)
        (c.move_to if k == 0 else c.line_to)(x, y)
    c.close_path(); c.set_source_rgba(1, 1, 1, 1); c.fill_preserve(); stroke_style(c, RED, 8); c.stroke()
    c.move_to(cx - 30, cy + ph / 2 - 20); c.line_to(cx - 80, cy + ph / 2 + 60); c.line_to(cx + 20, cy + ph / 2 - 16); c.close_path(); c.set_source_rgba(1, 1, 1, 1); c.fill()
    paste(c, pil2cairo(t_), cx, cy, 1.0); s.flush(); return s
FIGHT_B = jag_bubble("My English is fine.")
TAG_DEF = pill("DEFENSIVE", 46, W255, (120, 20, 40, 230), (255, 90, 110, 255)); TAG_AGG = pill("AGGRESSIVE", 46, W255, (120, 20, 40, 230), (255, 90, 110, 255))
def scene_fight(c, t):
    a = win(t, B[5] - 0.1, B[6] + 0.15, 0.3, 0.35)
    if a <= 0.01: return
    pulse = 0.5 + 0.5 * math.sin(t * 7)
    glow(c, 540, 1250, 520, RED, (0.25 + 0.1 * pulse) * a)
    jit = 4 * math.sin(t * 40) * ramp(t, T_AGG, T_AGG + 0.2)
    hx_, hy_ = figure(c, 540, 1500, 1.35, t, "crossed", a=a, jit=jit)
    for k in range(3):   # anger marks
        ang = -2.2 + 0.5 * k; r0 = 80 + 8 * pulse
        stroke_style(c, (*RED[:3], a * 0.9), 9); c.move_to(hx_ + r0 * math.cos(ang), hy_ + r0 * math.sin(ang)); c.line_to(hx_ + (r0 + 40) * math.cos(ang), hy_ + (r0 + 40) * math.sin(ang)); c.stroke()
    if t > T_FINE - 0.1:
        u = ramp(t, T_FINE - 0.1, T_FINE + 0.15); paste(c, FIGHT_B, 540 + 3 * math.sin(t * 30) * u, 800, a * u, sc=eob(min(1, (t - T_FINE + 0.1) / 0.3)))
    for tk, tag, x in ((T_DEF, TAG_DEF, 230), (T_AGG, TAG_AGG, 830)):
        u = ramp(t, tk - 0.1, tk + 0.15)
        if u > 0.01: paste(c, tag, x, 1075, a * u, sc=eob(min(1, (t - tk + 0.1) / 0.3)))

# ------------------------------------------------------------------ scene 6: FLIGHT
BUB_M = bubble("I have another meeting.", "speech", 54); BUB_C = bubble("Let my colleague handle it.", "speech", 54)
def scene_flight(c, t):
    a = win(t, B[6] - 0.1, B[7] + 0.15, 0.3, 0.35)
    if a <= 0.01: return
    glow(c, 830, 1250, 420, ORANGE, 0.22 * a)
    # door
    dx0, dy0, dw, dh = 740, 1000, 200, 500
    close = ramp(t, T_ESC + 0.35, T_ESC + 0.75)
    rr(c, dx0 - 14, dy0 - 14, dw + 28, dh + 14, 10); c.set_source_rgba(*NAVYD[:3], a); c.fill()
    g = cairo.LinearGradient(dx0, 0, dx0 + dw, 0); g.add_color_stop_rgba(0, *ORANGE[:3], 0.95 * a * (1 - close)); g.add_color_stop_rgba(1, *YEL[:3], 0.75 * a * (1 - close))
    c.set_source(g); c.rectangle(dx0, dy0, dw, dh); c.fill()
    leaf = lerp(0.25, 1.0, close)       # door leaf swings shut
    c.set_source_rgba(*hx("#7A4A1E")[:3], a); c.rectangle(dx0 + dw * (1 - leaf), dy0, dw * leaf, dh); c.fill()
    stroke_style(c, (*ORANGE[:3], a), 6); c.rectangle(dx0 - 14, dy0 - 14, dw + 28, dh + 14); c.stroke()
    # walker heading for the door
    u = ramp(t, B[6] + 0.2, T_ESC + 0.4); x = lerp(260, 860, u)
    c.save(); c.rectangle(0, 0, dx0 + dw * (1 - leaf) if x > dx0 - 40 else W, H); c.clip()
    c.push_group(); c.translate(x, 1500); c.scale(1.05, 1.05); c.translate(-x, -1500)
    import lib as _l
    sp = 1.0 if u < 1 else 0.0
    _l.draw_person(c, x, 1500, 1.25, (t - B[6]) * 7.5, sp, t)
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()
    for k in range(4):   # speed lines
        y = 1260 + 50 * k; ln = 120 + 40 * math.sin(t * 9 + k)
        stroke_style(c, (*ORANGE[:3], 0.6 * a * (1 - close)), 6); c.move_to(x - 120 - 30 * k, y); c.line_to(x - 120 - 30 * k - ln, y); c.stroke()
    for tk, bub, y in ((T_MEET, BUB_M, 640), (T_COLL, BUB_C, 800)):
        v = ramp(t, tk - 0.1, tk + 0.15)
        if v > 0.01: paste(c, bub, 80, y - 6 * math.sin(t * 2 + y), a * v, sc=eob(min(1, (t - tk + 0.1) / 0.3)), anchor="tl")

# ------------------------------------------------------------------ scene 7: FREEZE (frost texture + glass)
def make_frost():
    rng = np.random.default_rng(11); im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    def branch(x, y, ang, ln, dep):
        if dep == 0 or ln < 8: return
        x2, y2 = x + ln * math.cos(ang), y + ln * math.sin(ang)
        d.line([(x, y), (x2, y2)], fill=(220, 245, 255, int(120 + 25 * dep)), width=max(1, dep))
        for s in (-1, 1):
            if rng.random() < 0.8: branch(x + (x2 - x) * 0.5, y + (y2 - y) * 0.5, ang + s * (0.6 + 0.3 * rng.random()), ln * 0.5, dep - 1)
        branch(x2, y2, ang + 0.3 * (rng.random() - 0.5), ln * 0.75, dep - 1)
    for (cx, cy) in ((0, 0), (W, 0), (0, H), (W, H), (0, H / 2), (W, H / 2)):
        for k in range(9):
            ang = math.atan2(H / 2 - cy, W / 2 - cx) + (rng.random() - 0.5) * 2.0
            branch(cx, cy, ang, 130 + 110 * rng.random(), 6)
    g = im.filter(ImageFilter.GaussianBlur(4)); out = Image.alpha_composite(g, im)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dist = np.minimum.reduce([np.hypot(xx - cx, (yy - cy) * 0.75) for cx, cy in ((0, 0), (W, 0), (0, H), (W, H), (0, H / 2), (W, H / 2))])
    return np.asarray(out).astype(np.float32), dist
FROST, FDIST = make_frost()
_frost_cache = {}
def frost_surf(rad):
    k = int(rad / 10)
    if k not in _frost_cache:
        a = FROST.copy(); a[:, :, 3] *= np.clip((k * 10 - FDIST) / 120, 0, 1)
        _frost_cache.clear(); _frost_cache[k] = pil2cairo(Image.fromarray(a.astype(np.uint8), "RGBA"))
    return _frost_cache[k]
GL_WORDS = [("presentation", 54, 360, 705), ("I think that...", 56, 640, 760), ("the budget", 52, 360, 830), ("next quarter", 52, 700, 860)]
GL_S = [T(s, sz, 800, (220, 240, 255, 255)) for s, sz, _, _ in GL_WORDS]
def scene_freeze(c, t):
    a = win(t, B[7] - 0.1, B[8] + 0.15, 0.3, 0.4)
    if a <= 0.01: return
    fr = ramp(t, B[7], B[8] - 0.3)
    glow(c, 540, 1200, 600, ICE, 0.2 * a)
    # words behind glass
    gx, gy, gw, gh = 140, 640, 800, 280
    ug = ramp(t, T_WORDS - 0.2, T_WORDS + 0.3)
    for k, (s, sz, x, y) in enumerate(GL_WORDS):
        paste(c, GL_S[k], x + 14 * math.sin(t * 0.8 + k), y + 10 * math.sin(t * 1.1 + k * 2), a * ug * (0.55 + 0.15 * math.sin(t * 2 + k)))
    if ug > 0.01:
        rr(c, gx, gy, gw, gh, 28); c.set_source_rgba(*ICE[:3], 0.16 * a * ug); c.fill_preserve(); stroke_style(c, (*ICE[:3], 0.85 * a * ug), 5); c.stroke()
        stroke_style(c, (1, 1, 1, 0.35 * a * ug), 10)
        for k in range(2):
            x = gx + 120 + 90 * k + 0.0; c.move_to(x, gy + gh - 20); c.line_to(x + 140, gy + 20); c.stroke()
    jit = 2.0 * math.sin(t * 50) * fr
    ice_col = (lerp(FRONT[0], ICE[0], fr), lerp(FRONT[1], ICE[1], fr), lerp(FRONT[2], ICE[2], fr), 1)
    hx_, hy_ = figure(c, 540, 1500, 1.3, t, "frozen", ice_col, ice_col, a=a, jit=jit, breathe=1 - fr)
    # empty speech bubble: nothing comes out
    ue = ramp(t, T_NOTH - 0.1, T_NOTH + 0.2)
    if ue > 0.01:
        bx, by = hx_ + 90, hy_ - 210; c.set_dash([16, 12]); stroke_style(c, (*ICE[:3], 0.9 * a * ue), 6)
        rr(c, bx, by, 300, 150, 40); c.stroke(); c.move_to(bx + 40, by + 150); c.line_to(bx + 10, by + 200); c.line_to(bx + 90, by + 150); c.stroke(); c.set_dash([])
        for k in range(3):
            ph = 0.5 + 0.5 * math.sin(t * 4 - k)
            c.set_source_rgba(*ICE[:3], a * ue * (0.3 + 0.5 * ph)); c.arc(bx + 100 + 50 * k, by + 75, 11, 0, 2 * math.pi); c.fill()
    # frost creeping in from the edges
    rad = lerp(0, 400, ramp(t, T_FREEZE - 0.1, B[8] - 0.2))
    if rad > 10: c.set_source_surface(frost_surf(rad), 0, 0); c.paint_with_alpha(a * 0.65)

# ------------------------------------------------------------------ scene 8: protection shield
PROJ = [("HA HA", (255, 210, 160, 255), -1, 1060), ("Actually...", (255, 210, 160, 255), 1, 1180), ("Wrong!", (255, 150, 160, 255), -1, 1300), ("HA", (255, 210, 160, 255), 1, 1120)]
PROJ_S = [pill(s, 46, col, (60, 30, 30, 220), col) for s, col, _, _ in PROJ]
SH_C, SH_R = (540, 1250), 270
def scene_shield(c, t):
    a = win(t, B[8] - 0.1, B[9] + 0.15, 0.3, 0.4)
    if a <= 0.01: return
    us = ramp(t, T_PROT - 0.2, T_PROT + 0.4)
    # small brain keeps watch
    ub = ramp(t, T_SAFE - 0.2, T_SAFE + 0.3)
    brain(c, 540, 800, 0.36, a * (0.55 + 0.45 * ub), t, alarm=0.6, flash=4)
    if ub > 0.01:
        stroke_style(c, (*SKY[:3], 0.7 * a * ub), 5); c.set_dash([6, 14], -t * 40); c.move_to(540, 900); c.line_to(540, SH_C[1] - SH_R); c.stroke(); c.set_dash([])
    hx_, hy_ = figure(c, 540, 1480, 1.1, t, "idle", a=a)
    if us > 0.01:
        r = SH_R * eob(us)
        g = cairo.RadialGradient(SH_C[0], SH_C[1], r * 0.6, SH_C[0], SH_C[1], r); g.add_color_stop_rgba(0, *SKY[:3], 0.0); g.add_color_stop_rgba(1, *SKY[:3], 0.30 * a * us)
        c.set_source(g); c.arc(*SH_C, r, 0, 2 * math.pi); c.fill()
        stroke_style(c, (*LIGHT[:3], a * us * (0.8 + 0.2 * math.sin(t * 3))), 8); c.arc(*SH_C, r, 0, 2 * math.pi); c.stroke()
        stroke_style(c, (1, 1, 1, 0.5 * a * us), 6); c.arc(*SH_C, r - 22, -2.6, -1.9); c.stroke()
    for k, (th, (s, col, side, y)) in enumerate(zip(SHIELD_HITS, PROJ)):
        if t < th - 0.6 or t > th + 1.0: continue
        if t < th: x = lerp(540 + side * 700, 540 + side * (SH_R + 120), ease((t - th + 0.6) / 0.6)); al = 1
        else:
            v = (t - th) / 1.0; x = 540 + side * (SH_R + 120 + 500 * v); y = y - 300 * v + 400 * v * v; al = 1 - v
        paste(c, PROJ_S[k], x, y, a * al, sc=1.0)
        if th < t < th + 0.3:
            fl = 1 - (t - th) / 0.3; glow(c, 540 + side * SH_R * 0.95, y, 140, (1, 1, 1, 1), 0.6 * fl * a)

# ------------------------------------------------------------------ scenes 9-10: trust bridge, alarm calms
BR_Y = 1360; PL_X0, PL_X1 = 240, 840; NPL = 8
TRUST_P = pill("TRUST", 64, N255, (255, 213, 74, 255), (255, 240, 190, 255)); GRAM_P = pill("MORE GRAMMAR", 54, W255, (14, 30, 58, 230), (143, 211, 255, 255))
def scene_bridge(c, t):
    a = win(t, B[9] - 0.1, B[11] + 0.15, 0.35, 0.4)
    if a <= 0.01: return
    calm = ramp(t, B[9] + 0.5, B[10] + 2.5)
    brain(c, 540, 770, 0.42, a, t, alarm=1.0, calm=calm, flash=lerp(8, 2, calm))
    col = (lerp(RED[0], SKY[0], calm), lerp(RED[1], SKY[1], calm), lerp(RED[2], SKY[2], calm), 1)
    ecg(c, 100, 980, 1020, t, lambda tau: lerp(70, 34, ramp(tau, B[9], B[10] + 2.5)), col, a)
    # cliffs
    for x0, x1 in ((0, PL_X0), (PL_X1, W)):
        c.move_to(x0, BR_Y); c.line_to(x1, BR_Y); c.line_to(x1 - (24 if x0 == 0 else -24), 1560); c.line_to(x0, 1560); c.close_path()
        g = cairo.LinearGradient(0, BR_Y, 0, 1560); g.add_color_stop_rgba(0, *hx("#2E5BA8")[:3], a); g.add_color_stop_rgba(1, *NAVYD[:3], 0)
        c.set_source(g); c.fill()
        stroke_style(c, (*LIGHT[:3], 0.6 * a), 5); c.move_to(x0, BR_Y); c.line_to(x1, BR_Y); c.stroke()
    # planks + ropes
    pw = (PL_X1 - PL_X0) / NPL; built = 0
    for k in range(NPL):
        tk = PLANK_T[k]; u = ramp(t, tk - 0.05, tk + 0.25)
        if u <= 0.01: continue
        built = k + 1; x = PL_X0 + k * pw + 4; sag = 26 * math.sin(math.pi * (k + 0.5) / NPL)
        y = BR_Y + sag - 40 * (1 - eob(u))
        rr(c, x, y, pw - 8, 30, 6); c.set_source_rgba(*YEL[:3], a * u * 0.95); c.fill()
        c.set_source_rgba(*hx("#B8923F")[:3], a * u); c.rectangle(x, y + 22, pw - 8, 8); c.fill()
        if t < tk + 0.6: glow(c, x + pw / 2, y + 10, 110, YEL, 0.5 * a * (1 - ramp(t, tk, tk + 0.6)))
    if built:
        stroke_style(c, (*YEL[:3], 0.6 * a), 4); c.move_to(PL_X0, BR_Y - 110)
        xe = PL_X0 + built * pw; c.curve_to(PL_X0 + (xe - PL_X0) * 0.33, BR_Y - 80, PL_X0 + (xe - PL_X0) * 0.66, BR_Y - 80, xe, BR_Y - 110 + (0 if built < NPL else 0)); c.stroke()
        for k in range(built + 1):
            x = PL_X0 + k * pw; stroke_style(c, (*YEL[:3], 0.5 * a), 3); c.move_to(x, BR_Y - 100 + 10 * math.sin(math.pi * k / NPL)); c.line_to(x, BR_Y + 26 * math.sin(math.pi * k / NPL)); c.stroke()
    # walker steps onto each new plank
    target = PL_X0 - 90 + (built * pw if built else 0) - (0 if built < NPL else -120)
    if not hasattr(scene_bridge, "x"): scene_bridge.x = {}
    xk = PL_X0 - 90
    for k in range(NPL):
        xk = lerp(xk, PL_X0 + (k + 0.5) * pw if k < NPL - 1 else PL_X1 + 70, ramp(t, PLANK_T[k] + 0.25, PLANK_T[k] + 0.85))
    sag = 26 * math.sin(math.pi * min(1, max(0, (xk - PL_X0) / (PL_X1 - PL_X0))))
    moving = any(PLANK_T[k] + 0.25 < t < PLANK_T[k] + 0.85 for k in range(NPL))
    import lib as _l
    c.push_group(); _l.draw_person(c, xk, BR_Y + sag * (PL_X0 < xk < PL_X1), 0.82, t * 7 if moving else 0, 1.0 if moving else 0.0, t); c.pop_group_to_source(); c.paint_with_alpha(a)
    ug = win(t, T_GRAM - 0.1, T_TRUST + 0.1, 0.25, 0.25)
    if ug > 0.01:
        paste(c, GRAM_P, 540, 1200, a * ug); w_ = GRAM_P.get_width() * 0.5 * ramp(t, T_GRAM + 0.6, T_GRAM + 0.9)
        stroke_style(c, (*RED[:3], a * ug), 9); c.move_to(540 - GRAM_P.get_width() / 2 + 10, 1200); c.line_to(540 - GRAM_P.get_width() / 2 + 10 + 2 * w_ - 20, 1200); c.stroke()
    ut = ramp(t, T_TRUST - 0.1, T_TRUST + 0.2)
    if ut > 0.01: paste(c, TRUST_P, 540, 1170, a * ut, sc=eob(min(1, (t - T_TRUST + 0.1) / 0.35)))

# ------------------------------------------------------------------ scene 11: the red pen
def make_paper():
    w_, h_ = 840, 420; im = Image.new("RGBA", (w_, h_), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w_ - 1, h_ - 1], radius=22, fill=(246, 242, 232, 255))
    for k in range(4): d.line([(40, 150 + k * 90), (w_ - 40, 150 + k * 90)], fill=(190, 205, 230, 255), width=3)
    f = font(66, 800); boxes = {}
    for li, words in enumerate((["Yesterday", "I", "go", "to"], ["meeting", "with", "my", "boss."])):
        x = 60; y = 140 + li * 180
        for wd in words:
            d.text((x, y), wd, font=f, fill=(14, 30, 58, 255), anchor="ls"); wl = f.getlength(wd); boxes[(li, wd)] = (x, y - 50, wl, 60); x += wl + f.getlength(" ")
    return pil2cairo(im), boxes, w_, h_
PAPER, PBOX, PW_, PH_ = make_paper(); PX, PY = 120, 650
RED_T = {s: T(s, 50, 800, (230, 40, 60, 255)) for s in ("went", "the", "?!", "Last")}
def red_pen(c, x, y, a):
    c.save(); c.translate(x, y); c.rotate(0.7)
    rr(c, -12, -150, 24, 130, 6); c.set_source_rgba(0.85, 0.12, 0.2, a); c.fill()
    c.move_to(-12, -20); c.line_to(12, -20); c.line_to(0, 6); c.close_path(); c.set_source_rgba(0.95, 0.85, 0.75, a); c.fill(); c.restore()
def scene_teacher(c, t):
    a = win(t, B[11] - 0.1, B[12] + 0.15, 0.3, 0.35)
    if a <= 0.01: return
    paste(c, PAPER, PX, PY + 4 * math.sin(t * 1.2), a, anchor="tl")
    def bx(key): x, y, w_, h_ = PBOX[key]; return PX + x, PY + y, w_, h_
    marks = []
    x, y, w_, h_ = bx((0, "go")); marks.append(("strike", x, y + 30, w_, "went", x, y - 50))
    x, y, w_, h_ = bx((1, "meeting")); marks.append(("caret", x - 6, y + 62, 0, "the", x - 50, y - 40))
    x, y, w_, h_ = bx((0, "Yesterday")); marks.append(("circle", x + w_ / 2, y + 30, w_, "Last", x + w_ / 2, y - 55))
    x, y, w_, h_ = bx((1, "boss.")); x2 = bx((1, "with"))[0]; marks.append(("wavy", x2, y + 78, x + w_ - x2, "?!", x + w_ + 30, y + 10))
    pen = None
    for k, (kind, mx, my, mw, lab, lx, ly) in enumerate(marks):
        tk = PEN_T[k]; u = ramp(t, tk, tk + 0.35)
        if u <= 0: continue
        stroke_style(c, (0.9, 0.15, 0.24, a), 8)
        if kind == "strike": c.move_to(mx - 8, my); c.line_to(mx - 8 + (mw + 16) * u, my); c.stroke(); pen = (mx - 8 + (mw + 16) * u, my)
        elif kind == "caret": c.move_to(mx - 20, my); c.line_to(mx, my - 40 * u); c.line_to(mx + 20 * u, my); c.stroke(); pen = (mx, my - 40 * u)
        elif kind == "circle":
            c.save(); c.translate(mx, my); c.scale(1, 0.45); c.arc(0, 0, mw / 2 + 18, 0, 2 * math.pi * u); c.restore(); c.stroke(); pen = (mx + (mw / 2 + 18) * math.cos(2 * math.pi * u), my + 0.45 * (mw / 2 + 18) * math.sin(2 * math.pi * u))
        else:
            c.move_to(mx, my)
            for j in range(int(30 * u) + 1): c.line_to(mx + mw * j / 30, my + 8 * math.sin(j * 1.3))
            c.stroke(); pen = (mx + mw * u, my)
        if u > 0.5: paste(c, RED_T[lab], lx, ly, a * ramp(t, tk + 0.17, tk + 0.35), anchor="cl" if kind in ("strike",) else "cc")
    if pen and t < PEN_T[-1] + 0.7: red_pen(c, pen[0], pen[1], a)
    # below: figure shrinking under the corrections, alarm on
    sh = ramp(t, T_TEACH, T_WHEN)
    hx_, hy_ = figure(c, 540, 1520, lerp(1.0, 0.86, sh), t, "idle", a=a, breathe=0.5)
    glow(c, hx_, hy_, 160, RED, 0.35 * a * sh * (0.6 + 0.4 * math.sin(t * 7)))
    uq = ramp(t, T_WHEN, T_WHEN + 0.3)
    if uq > 0.01: paste(c, T("?", 110, 900, Y255), hx_ + 110, hy_ - 60, a * uq, sc=eob(min(1, (t - T_WHEN) / 0.3)))

# ------------------------------------------------------------------ scene 12: correcting yourself, kindly
def scene_self(c, t):
    a = win(t, B[12] - 0.1, B[13] + 0.1, 0.3, 0.35)
    if a <= 0.01: return
    quiet = ramp(t, T_QUIET - 0.2, T_QUIET + 0.6)
    glow(c, 300, 1250, 480, SKY, (0.15 + 0.15 * quiet) * a)
    hx_, hy_ = figure(c, 300, 1500, 1.15, t, "talk", a=a)
    # self bubble: "Yesterday I go went."
    f = font(64, 800); words = ["Yesterday", "I", "go", "went."]; sp = f.getlength(" ")
    ws = [f.getlength(w_) for w_ in words]; fix = ramp(t, T_FIX - 0.1, T_FIX + 0.3); strike = ramp(t, T_CATCH + 0.3, T_CATCH + 0.7)
    tw = ws[0] + ws[1] + ws[2] + 2 * sp + (sp + ws[3]) * ease(fix)
    bw, bh = tw + 90, 130; bx, by = 540 - bw / 2, 690
    ub = ramp(t, B[12], B[12] + 0.3)
    rr(c, bx, by, bw, bh, 36); c.set_source_rgba(1, 1, 1, 0.96 * a * ub); c.fill()
    c.move_to(bx + 120, by + bh); c.line_to(hx_ + 30, hy_ - 70); c.line_to(bx + 200, by + bh); c.close_path(); c.fill()
    x = bx + 45
    for k, w_ in enumerate(words):
        if k == 3 and fix <= 0.01: break
        col = (14, 30, 58, 255)
        if k == 2: col = (130, 140, 160, 255) if strike > 0.5 else col
        if k == 3: col = (210, 150, 0, 255)
        paste(c, T(w_, 64, 800, col), x - 8, by + bh / 2, a * ub * (fix if k == 3 else 1), anchor="cl")
        if k == 2 and strike > 0:
            stroke_style(c, (*SKY[:3], a), 8); c.move_to(x - 4, by + bh / 2 + 4); c.line_to(x - 4 + (ws[2] + 8) * strike, by + bh / 2 + 4); c.stroke()
        x += ws[k] + sp
    if T_FIX < t < T_FIX + 1.0:
        g = 1 - (t - T_FIX) / 1.0
        for k in range(6):
            ang = k / 6 * 2 * math.pi + t; r = 60 + 60 * (1 - g)
            c.set_source_rgba(*YEL[:3], a * g); c.arc(bx + bw - 90 + r * math.cos(ang), by + bh / 2 + r * 0.6 * math.sin(ang), 8, 0, 2 * math.pi); c.fill()
    uc = ramp(t, T_CATCH, T_CATCH + 0.3)
    if uc > 0.01: paste(c, pill("Kindly", 46, N255, (143, 211, 255, 255), (220, 240, 255, 255)), 540, by + bh + 70, a * uc * (1 - quiet))
    # calm brain on the right, amygdala soft blue
    brain(c, 780, 1300, 0.36, a, t, alarm=1.0, calm=max(0.5, quiet), flash=3)
    ecg(c, 620, 980, 1530, t, 30, SKY, a * 0.9, lw=5)
    # speech flows after the alarm goes quiet
    for k, s in enumerate(["Here's my plan.", "Let me explain."]):
        tk = T_QUIET + 0.3 + 0.7 * k; ak = ramp(t, tk, tk + 0.3) * a
        if ak > 0.01: paste(c, bubble(s, "speech", 54), 470, 900 + 130 * k - 6 * math.sin(t * 2 + k), ak, sc=eob(min(1, (t - tk) / 0.3)), anchor="tl")

# ------------------------------------------------------------------ end cards
CARD7 = pil2cairo(end_card([("emoji", "23f1", 150), ("head", "Talk to yourself", 130),
                            ("body", "*7 minutes* in English. Record on WhatsApp. Share it.", 76), ("he", "דברו לעצמכם באנגלית 7 דקות", 64)]))
CARDCTA = pil2cairo(end_card([("body", "Comment", 84), ("pill", "SPEAKER", 130), ("he", "or ספיקר", 68),
                              ("body", "and I'll send you *the video* on how to do it", 74),
                              ("he", "כתבו ספיקר ואשלח לכם סרטון איך עושים את זה", 62)]))

# ------------------------------------------------------------------ frame
SCENES = [(scene_meeting, -1, T_DANGER + 0.4), (scene_danger, T_DANGER - 0.1, B[2] + 0.3), (scene_flash, B[2] - 0.2, B[3] + 0.3),
          (scene_rule, B[3] - 0.2, B[4] + 0.3), (scene_fork, B[4] - 0.2, B[5] + 0.3), (scene_fight, B[5] - 0.2, B[6] + 0.3),
          (scene_flight, B[6] - 0.2, B[7] + 0.3), (scene_freeze, B[7] - 0.2, B[8] + 0.3), (scene_shield, B[8] - 0.2, B[9] + 0.3),
          (scene_bridge, B[9] - 0.2, B[11] + 0.3), (scene_teacher, B[11] - 0.2, B[12] + 0.3), (scene_self, B[12] - 0.2, B[13] + 0.3)]
def frame(fi):
    t = fi / FPS
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG_S, 0, 0); c.paint(); dust(c, t)
    if t < B[13] + 0.6:
        for fn, t0, t1 in SCENES:
            if t0 < t < t1: fn(c, t)
    for k in range(len(CAPS)):
        t0 = B[k]; t1 = B[k + 1]
        if not (t0 - 1e-6 <= t < t1 + 0.32): continue
        a = (1.0 if t0 == 0 else ramp(t, t0, t0 + 0.3)) * (1 - ramp(t, t1 - 0.02, t1 + 0.28)); dy = 0 if t0 == 0 else 26 * (1 - ramp(t, t0, t0 + 0.45))
        if a > 0.005:
            if k in (5, 6, 7):   # reaction word punches in
                sc = 1 + 0.25 * (1 - eob(min(1, (t - t0) / 0.35))); c.save(); c.translate(540, CAPY + 100); c.scale(sc, sc); c.translate(-540, -CAPY - 100)
                c.set_source_surface(CAP_S[k], 0, CAPY + dy); c.paint_with_alpha(a); c.restore()
            else: c.set_source_surface(CAP_S[k], 0, (262 if k == 0 else CAPY) + dy); c.paint_with_alpha(a)
    i9 = 13
    if t >= B[i9] - 0.05:
        u = ramp(t, B[i9] - 0.05, B[i9] + 0.5)
        g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NAVYD[:3], 0.93 * u); g.add_color_stop_rgba(0.55, *NAVY[:3], 0.90 * u); g.add_color_stop_rgba(1, *ROYAL[:3], 0.86 * u)
        c.set_source(g); c.paint()
        drift = 14 - 28 * ease((t - B[i9]) / max(1, B[i9 + 1] - B[i9]))
        a7 = u * (1 - ramp(t, B[i9 + 1] - 0.05, B[i9 + 1] + 0.3)); dy7 = 30 * (1 - ramp(t, B[i9], B[i9] + 0.5)) + drift
        if a7 > 0.005: c.set_source_surface(CARD7, 0, dy7); c.paint_with_alpha(a7)
        if t >= B[i9 + 1] - 0.05:
            ac = ramp(t, B[i9 + 1] - 0.05, B[i9 + 1] + 0.3); dyc = 30 * (1 - ramp(t, B[i9 + 1], B[i9 + 1] + 0.45)) - 8 * ease((t - B[i9 + 1]) / 6)
            sc = 1 + 0.03 * math.sin((t - B[i9 + 1]) * 3.0) * ramp(t, B[i9 + 1] + 0.5, B[i9 + 1] + 1)
            c.save(); c.translate(540, 960); c.scale(sc, sc); c.translate(-540, -960); c.set_source_surface(CARDCTA, 0, dyc); c.paint_with_alpha(ac); c.restore()
    s.flush(); return s
def to_rgb(s): return np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1].copy()

if A.snaps:
    for ts in A.snaps.split(","):
        fi = min(N - 1, int(float(ts) * FPS)); Image.fromarray(to_rgb(frame(fi))).save(f"{QA}/snap_{float(ts):05.1f}.png")
    print("snaps done"); sys.exit(0)
if A.render:
    CHD = f"{D}/chunks"; os.makedirs(CHD, exist_ok=True); STEP = 300; parts = []
    import time; t0 = time.time()
    for a0 in range(0, N, STEP):
        b0 = min(N, a0 + STEP); p = f"{CHD}/c_{a0:05d}.mp4"; parts.append(p)
        if A.resume and os.path.exists(p) and os.path.getsize(p) > 1000: continue
        ff = subprocess.Popen(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-c:v", "libx264", "-threads", "1", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-profile:v", "high", p + ".tmp.mp4"], stdin=subprocess.PIPE)
        for fi in range(a0, b0):
            s = frame(fi); ff.stdin.write(np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W].tobytes())
        ff.stdin.close(); ff.wait(); os.replace(p + ".tmp.mp4", p); print(f"chunk {a0}-{b0} of {N}  {time.time() - t0:.0f}s", flush=True)
    open(f"{CHD}/list.txt", "w").write("".join(f"file '{p}'\n" for p in parts))
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", f"{CHD}/list.txt", "-c", "copy", f"{D}/video_only.mp4"], check=True)
    import shutil; shutil.rmtree(CHD, ignore_errors=True); print("video done", N, "frames")
