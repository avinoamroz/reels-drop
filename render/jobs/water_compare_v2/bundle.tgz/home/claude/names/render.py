#!/usr/bin/env python3
"""Narrated name-meaning reel renderer (Express English). Same design as surnames/family_names.mp4.

Usage (run from anywhere):
  python3 render.py [VOICEDIR] [--out FILE] [--frames 0,3.5,10]
  VOICEDIR can also come from the VOICEDIR env var. Default: <reel dir>/vo_kokoro
  It reads <VOICEDIR>/<key>.wav for every key in lines.json; all timing comes from those wav durations.
Content lives in reel.json next to this script.
"""
import subprocess, numpy as np, soundfile as sf, sys, io, os, json, argparse, cairosvg
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("voicedir", nargs="?", default=None)
ap.add_argument("--out", default=None)
ap.add_argument("--frames", default=None, help="comma list of times: save chk_<t>.png and exit")
ap.add_argument("--vt", default=None, help="voice-timed mode: dir of per-line clips (e.g. vo_noam); hook 1 s, title card, cards on their lines, ducked music")
A = ap.parse_args()
R = json.load(open(os.path.join(HERE, "reel.json")))
LINES = json.load(open(os.path.join(HERE, "lines.json")))
VO = A.voicedir or os.environ.get("VOICEDIR") or os.path.join(HERE, "vo_kokoro")
VO = os.path.abspath(VO)
OUT = os.path.abspath(A.out) if A.out else os.path.join(HERE, f"{R['slug']}_preview.mp4")
os.chdir(HERE)

W, H, FPS = 1080, 1920, 30; CX = W / 2
def F(w, s): return ImageFont.truetype(f"/tmp/claude-0/fonts/Heebo-{w}.ttf", s)
def EMO(c, sz): return Image.open(io.BytesIO(cairosvg.svg2png(url=f"/tmp/claude-0/package/{c}.svg", output_width=sz, output_height=sz))).convert("RGBA")
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
WHITE = (245, 245, 247); G1 = (161, 161, 166); G2 = (105, 105, 112); DK = (20, 20, 24)
ACC = hx(R["accent"]); DARK = R.get("dark_text", False)
CT = DK if DARK else WHITE                       # cover text colour
CT2 = tuple(int(c * 0.85 + (40 if DARK else 230) * 0.15) for c in CT)
EMPH = hx(R.get("emph", "#FFD60A"))
HL = tuple(int(a * 0.62 + 255 * 0.38) for a in ACC)  # meaning colour on dark cards

yv, xv = np.mgrid[0:H, 0:W]
def glow(col):
    b = np.zeros((H, W, 3)) + np.array([6, 7, 10]); b += np.exp(-(((xv-CX)/760)**2 + ((yv-H*0.45)/700)**2))[..., None] * np.array(col)
    return Image.fromarray(np.clip(b, 0, 255).astype(np.uint8))
BG = glow([12, 18, 40])
def cover(acc):
    a = np.array(acc, float); t = (yv/H)[..., None]; lo = 0.68 if DARK else 0.45
    cb = a*0.97*(1-t) + a*lo*t + np.exp(-(((xv-W*0.8)/600)**2 + ((yv-300)/500)**2))[..., None]*40
    return Image.fromarray(np.clip(cb, 0, 255).astype(np.uint8))
CB = cover(ACC)
logo = Image.open("/home/claude/nickq/logo.png").convert("RGBA").resize((40, 40))
SEGS_DEF = R["segments"]
EM = {}
def em(c, sz):
    if (c, sz) not in EM: EM[(c, sz)] = EMO(c, sz)
    return EM[(c, sz)]
def ease(x): x = max(0, min(1, x)); return 1 - (1 - x)**3
def T(d, xy, s, f, c, al=1.0, anchor="mm"):
    if al > 0: d.text(xy, s, font=f, fill=tuple(c) + (int(255*min(1, al)),), anchor=anchor)
def fit(d, s, w, sz, maxw=900):
    while d.textlength(s, font=F(w, sz)) > maxw: sz -= 4
    return F(w, sz)
def paste_em(im, e, cx, cy, sz, al=1):
    if al <= 0: return
    e = e.resize((sz, sz))
    if al < 1: e.putalpha(e.getchannel("A").point(lambda v: int(v*al)))
    im.paste(e, (int(cx-sz/2), int(cy-sz/2)), e)
def base(bg, title, c, n=None):
    im = bg.copy(); d = ImageDraw.Draw(im, "RGBA")  # RGB canvas so RGBA fills blend
    T(d, (CX, 300), title + (f"  ·  {n}" if n else ""), F(700, 26), c)
    lw = d.textlength("Express English", font=F(400, 26)); x0 = CX - (40+14+lw)/2
    im.paste(logo, (int(x0), 1450), logo); T(d, (x0+54, 1470), "Express English", F(400, 26), c, anchor="lm")
    return im, d
def colr(name):
    return {"text": CT, "text2": CT2, "emph": EMPH, "white": WHITE, "dark": DK}.get(name, CT)
def textlines(d, lines, el, anim=True):
    # each: [text, y, weight, size, colour, delay]
    for ln in lines:
        s, y, w, sz, c = ln[:5]; dl = ln[5] if len(ln) > 5 else 0
        al = 1 if not anim else ease((el - dl)/0.3)
        T(d, (CX, y), s, fit(d, s, w, sz), colr(c), al)
def hook(sg, el):
    im, d = base(CB, R["tag"], CT)
    textlines(d, sg["lines"], el, anim=False)          # frame 0 already shows the full hook
    chips = sg.get("chips", [])
    if chips:
        f = F(800, 52); pads = [d.textlength(s, font=f) + 60 for s in chips]; gap = 22
        tot = sum(pads) + gap*(len(chips)-1)
        if tot > 900:
            f = F(800, 44); pads = [d.textlength(s, font=f) + 50 for s in chips]; tot = sum(pads) + gap*(len(chips)-1)
        x = CX - tot/2; y = sg.get("chips_y", 1060)
        fill = (0, 0, 0) if DARK else (255, 255, 255)
        for k, s in enumerate(chips):
            al = ease((el - 1.6 - k*0.18)/0.3)
            if al > 0:
                d.rounded_rectangle((x, y-45, x+pads[k], y+45), radius=45, fill=fill + (int((34 if DARK else 40)*al),))
                T(d, (x+pads[k]/2, y+2), s, f, CT, al)
            x += pads[k] + gap
    if sg.get("emojis"):
        es = sg["emojis"]
        for k, c in enumerate(es):
            paste_em(im, em(c, 110), CX + (k-(len(es)-1)/2)*170, sg.get("emoji_y", 1200), 110, ease((el-1.8-k*0.15)/0.3))
    return im
def divider(sg, el):
    im, d = base(CB, sg.get("tag", R["tag"]), CT)
    textlines(d, sg["lines"], el)
    for k, c in enumerate(sg.get("emojis", [])):
        es = sg["emojis"]
        paste_em(im, em(c, 110), CX + (k-(len(es)-1)/2)*170, 1150, 110, ease((el-1.4-k*0.15)/0.3))
    return im
def card(it, el, n):
    im, d = base(BG, it.get("section", R["section"]), G2, n)
    sc = 0.75 + 0.25*ease(el/0.3); paste_em(im, em(it["emoji"], 240), CX, 550, int(220*sc), ease(el/0.2))
    f = fit(d, it["name"], 900, 150)
    T(d, (CX, 770 - (1-ease(el/0.3))*25), it["name"], f, WHITE, ease(el/0.25))
    if it.get("he"): T(d, (CX, 900), it["he"], fit(d, it["he"], 700, 64), G1, ease((el-0.2)/0.3))
    al = ease((el-0.35)/0.3); ft = F(700, 30); o = it["origin"].upper(); tw = d.textlength(o, font=ft)
    if al > 0:
        d.rounded_rectangle((CX-tw/2-26, 975, CX+tw/2+26, 1031), radius=28, outline=tuple(ACC)+(int(255*al),), width=3)
        T(d, (CX, 1002), o, ft, HL, al)
    m = ease((el-0.75)/0.35)
    T(d, (CX, 1100), "=", F(400, 50), G2, m)
    T(d, (CX, 1200 + (1-m)*40), it["meaning"], fit(d, it["meaning"], 900, 104), HL, m)
    if it.get("sub"): T(d, (CX, 1315), it["sub"], fit(d, it["sub"], 400, 40), G1, ease((el-1.2)/0.3))
    return im
def end(sg, el):
    im, d = base(CB, R["tag"], CT)
    paste_em(im, em("1f4ac", 200), CX, 520, 200, ease(el/0.3))
    textlines(d, sg["lines"], el)
    return im

def title(el):
    # clean title card: the reel's existing tag on the cover background, no new content
    im = CB.copy(); d = ImageDraw.Draw(im, "RGBA")
    words = R["tag"].split(); best = None
    for k in range(1, len(words)):
        a, b = " ".join(words[:k]), " ".join(words[k:]); w = max(d.textlength(a, font=F(900, 80)), d.textlength(b, font=F(900, 80)))
        if best is None or w < best[0]: best = (w, a, b)
    ls = [best[1], best[2]] if best and d.textlength(R["tag"], font=F(900, 80)) > 900 else [R["tag"]]
    y0 = 900 - (len(ls) - 1) * 50
    for k, l in enumerate(ls): T(d, (CX, y0 + k * 100), l, fit(d, l, 900, 80), CT)
    lw = d.textlength("Express English", font=F(400, 26)); x0 = CX - (40+14+lw)/2
    im.paste(logo, (int(x0), 1450), logo); T(d, (x0+54, 1470), "Express English", F(400, 26), CT, anchor="lm")
    return im

if A.vt:
    sys.path.insert(0, "/home/claude/vo_new"); import vt
    keys = [sg["key"] for sg in SEGS_DEF]; BYK = {sg["key"]: sg for sg in SEGS_DEF}
    segs, TT = vt.timeline(keys, os.path.abspath(A.vt)); SC = vt.schedule(segs)
    cnt = {}; NUM = {}
    for sg in SEGS_DEF:
        if sg["type"] == "card":
            sec = sg.get("section", R["section"]); cnt[sec] = cnt.get(sec, 0) + 1; NUM[sg["key"]] = (sec, cnt[sec])
    def vframe(tt):
        kind, key, el = vt.at(SC, tt)
        if kind == "hook": return hook(BYK[key], 5.0)            # full hook from frame 0
        if kind == "title": return title(el)
        sg = BYK[key]; ty = sg["type"]
        if ty == "card": sec, i = NUM[key]; return card(sg, el, f"{i}/{cnt[sec]}")
        if ty == "divider": return divider(sg, el)
        if ty == "hook": return hook(sg, el)
        return end(sg, el)
    if A.frames:
        for s in A.frames.split(","): vframe(float(s)).convert("RGB").save(os.path.join(HERE, f"vt_chk_{s}.png"))
        print(round(TT, 2), [(k, round(t, 2)) for t, k, _ in [(e[0], e[2] or e[1], 0) for e in SC]]); sys.exit()
    MIXW = os.path.join(HERE, "mix_vt.wav")
    info = vt.mix(segs, f"/home/claude/vid/music/{R['music']}.wav", MIXW, TT)
    import json as _j
    _j.dump(dict(total=TT, schedule=SC, voice=[(s["key"], round(s["v0"], 3), round(s["v1"], 3)) for s in segs], mix=info), open(os.path.join(HERE, "vt_timeline.json"), "w"), indent=1)
    ff = vt.encoder(OUT, MIXW)
    for fr in range(int(TT*FPS)):
        ff.stdin.write(vframe(fr/FPS).convert("RGB").tobytes())
    ff.stdin.close(); ff.wait(); print(OUT, round(TT, 1), "s", info); sys.exit()

# ---------- timing from the voice files ----------
def load(k):
    p = os.path.join(VO, f"{k}.wav")
    if not os.path.exists(p): sys.exit(f"missing voice file: {p}")
    x, sr = sf.read(p); x = x.mean(1) if x.ndim > 1 else x
    return x, sr
missing = [k for k in LINES if not os.path.exists(os.path.join(VO, f"{k}.wav"))]
if missing: sys.exit(f"missing voice files in {VO}: {missing}")
PAD = {"hook": (0.15, 0.9), "card": (0.1, 0.6), "divider": (0.1, 0.9), "end": (0.1, 2.0)}
SR = load(SEGS_DEF[0]["key"])[1]
segs = []; t = 0.0
for sg in SEGS_DEF:
    x, sr = load(sg["key"])
    if sr != SR: x = np.interp(np.arange(0, len(x), sr/SR), np.arange(len(x)), x)
    off, tail = PAD[sg["type"]]; ln = len(x)/SR + tail
    segs.append(dict(sg=sg, st=t, ln=ln, off=off, x=x)); t += ln
TT = t
# card counters per section
cnt = {}
for s in segs:
    if s["sg"]["type"] == "card":
        sec = s["sg"].get("section", R["section"]); cnt[sec] = cnt.get(sec, 0) + 1; s["idx"] = cnt[sec]; s["sec"] = sec
for s in segs:
    if "idx" in s: s["n"] = f"{s['idx']}/{cnt[s['sec']]}"

def frame(tt):
    cur = segs[0]
    for s in segs:
        if s["st"] <= tt: cur = s
    el = max(0, tt - cur["st"]); sg = cur["sg"]; ty = sg["type"]
    if ty == "hook": return hook(sg, el)
    if ty == "card": return card(sg, el, cur["n"])
    if ty == "divider": return divider(sg, el)
    return end(sg, el)

if A.frames:
    for s in A.frames.split(","): frame(float(s)).convert("RGB").save(os.path.join(HERE, f"chk_{s}.png"))
    print(round(TT, 2), [(s["sg"]["type"], s["sg"]["key"], round(s["st"], 2)) for s in segs]); sys.exit()

# ---------- audio: voice + soft music at 0.12 ----------
mix = np.zeros(int((TT + 0.5)*SR))
for s in segs:
    x = s["x"]; i = int((s["st"] + s["off"])*SR); mix[i:i+len(x)] += x[:len(mix)-i]
mix = mix/np.abs(mix).max()*0.9
m, msr = sf.read(f"/home/claude/vid/music/{R['music']}.wav"); m = m.mean(1) if m.ndim > 1 else m
if msr != SR: m = np.interp(np.arange(0, len(m), msr/SR), np.arange(len(m)), m)
m = m/np.abs(m).max()
xf = int(2*SR); mo = m.copy()
while len(mo) < len(mix):
    r = np.linspace(0, 1, xf); mo = np.concatenate([mo[:-xf], mo[-xf:]*(1-r) + m[:xf]*r, m[xf:]])
mo = mo[:len(mix)]; fo = int(1.5*SR); mo[-fo:] *= np.linspace(1, 0, fo)
MIXW = os.path.join(HERE, "mix.wav")
sf.write(MIXW, np.clip(mix + mo*R.get("music_vol", 0.12), -1, 1), SR)

ff = subprocess.Popen(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                       "-i", MIXW, "-c:v", "libx264", "-crf", "19", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", OUT], stdin=subprocess.PIPE)
for fr in range(int(TT*FPS)):
    ff.stdin.write(frame(fr/FPS).convert("RGB").tobytes())
ff.stdin.close(); ff.wait(); print(OUT, round(TT, 1), "s")
