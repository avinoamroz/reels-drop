"""Colonize3 narration: ASR checked chunks (vo/asr.json), deeper voice (pitch -0.5 st, formants kept, bass), clean_vo, atempo 1.1,
then every speech chunk is re-placed on a new timeline with chosen gaps (extra air after each stamp, before the reveal).
ASR check 25 Oct: 26 chunks, all 9 lines heard in full, no repeats or false starts, nothing dropped.
out: vo/vo.wav (48 kHz mono) + vo/segs.json (one [start,end] per script line, chunk times for cues)"""
import json, subprocess, os, shutil, numpy as np, soundfile as sf
D = "/home/claude/colonize3/vo"; SR = 48000; TEMPO = 1.1
J = json.load(open(f"{D}/asr.json")); CH = J["chunks"]
assert len(CH) == 26, len(CH)
os.makedirs(f"{D}/c_in", exist_ok=True); os.makedirs(f"{D}/c_out", exist_ok=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/c_in/full.wav"], check=True)
subprocess.run(["nice", "-n", "15", "python3", "/home/claude/vo_new/clean_vo.py", f"{D}/c_in", f"{D}/c_out", "--report"], check=True)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/c_out/full.wav", "-af", f"atempo={TEMPO}", "-ar", str(SR), "-ac", "1", "-c:a", "pcm_f32le", f"{D}/fast.wav"], check=True)
x, sr = sf.read(f"{D}/fast.wav"); assert sr == SR
# chunk -> line
LINE_OF = [0, 0, 1, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7, 8, 8]
EXTRA = {2: 0.45, 5: 0.2, 6: 0.85, 8: 0.2, 9: 0.85, 11: 0.2, 12: 0.85, 15: 0.25, 16: 1.0, 17: 0.2, 18: 0.3, 19: 0.3,
         20: 0.6, 21: 0.25, 22: 0.7, 23: 0.35, 24: 1.6}           # extra seconds of air before chunk k
LEAD = 0.25
y = np.zeros(int(80 * SR)); new = []; t = LEAD
for k, (a, b, txt) in enumerate(CH):
    if k: t = new[-1][1] + (a - CH[k - 1][1]) / TEMPO + EXTRA.get(k, 0)
    a0, b0 = max(0.0, a - 0.06), b + 0.12
    if k: a0 = max(a0, (CH[k - 1][1] + a) / 2)
    if k < len(CH) - 1: b0 = min(b0, (b + CH[k + 1][0]) / 2)
    s = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR); s[:f] *= np.linspace(0, 1, f); s[-f:] *= np.linspace(1, 0, f)
    st = t - (a - a0) / TEMPO; i = int(st * SR); y[i:i + len(s)] += s
    new.append([round(t, 3), round(t + (b - a) / TEMPO, 3), txt])
T_END = new[-1][1] + 2.2
y = y[:int(T_END * SR)]
sf.write(f"{D}/vo.wav", y.astype(np.float32), SR, subtype="FLOAT")
segs = []
for ln in range(9):
    cs = [c for c, l in zip(new, LINE_OF) if l == ln]; segs.append([cs[0][0], cs[-1][1]])
json.dump({"segs": segs, "chunks": new, "T_END": round(T_END, 3), "tempo": TEMPO, "lead": LEAD}, open(f"{D}/segs.json", "w"), indent=1, ensure_ascii=False)
shutil.rmtree(f"{D}/c_in"); shutil.rmtree(f"{D}/c_out"); os.remove(f"{D}/fast.wav")
print("vo", round(T_END, 2), "s")
for c in new: print(c)
