#!/usr/bin/env python3
"""Colonize3 reel: "This is colonization. This is not."
Map style, Heebo text helpers and SFX reused from /home/claude/colonize/render.py. Land of Israel: Natural Earth 1:10m Israel + Palestine
polygons (Golan, West Bank, Gaza incl.) in gold #B8923F, Green Line in (46,204,113), as /home/claude/cities/reel.py.
  python3 render.py --frames 1,8,12     check frames to qa/
  python3 render.py                      video_only.mp4 (frames streamed to ffmpeg) + mix.wav
Timing: vo/segs.json chunks (build_vo.py)."""
import os, sys, json, math, argparse, subprocess, functools
import numpy as np, cairo, soundfile as sf
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon, shape
from shapely.ops import unary_union

HERE = "/home/claude/colonize3"
ap = argparse.ArgumentParser(); ap.add_argument("--frames", default=None); ap.add_argument("--noaudio", action="store_true"); A = ap.parse_args()
W, H, FPS, SR = 1080, 1920, 30, 48000; CX = W / 2
SEG = json.load(open(f"{HERE}/vo/segs.json")); C = [(c[0], c[1]) for c in SEG["chunks"]]; T_END = SEG["T_END"]

# ------------------------------------------------------------------ helpers (from colonize/render.py)
def hx(h, a=1.0):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)
def ease(x): x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3
def eio(x): x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)
def eback(x):
    x = max(0.0, min(1.0, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def lerp(a, b, u): return a + (b - a) * u
def fade(t, t0, t1=None, d=0.25, d2=0.3):
    a = ease((t - t0) / d)
    if t1 is not None: a *= 1 - ease((t - t1) / d2)
    return a

@functools.lru_cache(None)
def FONT(w, s): return ImageFont.truetype(f"/tmp/claude-0/fonts/Heebo-{w}.ttf", s)
def is_he(s): return any("֐" <= ch <= "׿" for ch in s)
@functools.lru_cache(maxsize=3000)
def text_sprite(s, w, size, rgba):
    f = FONT(w, size); kw = dict(direction="rtl", language="he") if is_he(s) else {}
    dd = ImageDraw.Draw(Image.new("RGBA", (4, 4))); l, t, r, b = dd.textbbox((0, 0), s, font=f, **kw)
    pad = 6; iw, ih = int(r - l + 2 * pad), int(size * 1.45 + 2 * pad)
    im = Image.new("RGBA", (max(1, iw), ih), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((pad - l, pad + size * 0.05), s, font=f, fill=tuple(int(c * 255) for c in rgba), **kw)
    a = np.array(im).astype(np.float32); al = a[..., 3:4] / 255.0
    bgra = np.dstack([a[..., 2:3] * al, a[..., 1:2] * al, a[..., 0:1] * al, a[..., 3:4]]).astype(np.uint8)
    stride = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, iw)
    buf = np.zeros((ih, stride // 4, 4), np.uint8); buf[:, :iw] = bgra
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, iw, ih, stride), iw, ih, pad
@functools.lru_cache(maxsize=3000)
def tw(s, w, size):
    kw = dict(direction="rtl", language="he") if is_he(s) else {}
    return ImageDraw.Draw(Image.new("RGBA", (4, 4))).textlength(s, font=FONT(w, size), **kw)
def text(ctx, s, x, y, w, size, col, al=1.0, anchor="c", scale=1.0):
    if al <= 0.01 or not s: return
    surf, iw, ih, pad = text_sprite(s, w, size, col)
    ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale)
    ox = {"c": -iw / 2, "l": -pad, "r": -iw + pad}[anchor]
    ctx.set_source_surface(surf, ox, -ih / 2); ctx.paint_with_alpha(al); ctx.restore()
@functools.lru_cache(None)
def fit(s, w, size, maxw):
    while size > 18 and tw(s, w, size) > maxw: size -= 2
    return size
def rrect(ctx, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    ctx.new_sub_path(); ctx.arc(x + w - r, y + r, r, -math.pi / 2, 0); ctx.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    ctx.arc(x + r, y + h - r, r, math.pi / 2, math.pi); ctx.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); ctx.close_path()

WHITE = (1, 1, 1, 1); YEL = hx("#FFD54A"); SKY = hx("#45A4DD"); SOFT = hx("#C9D5EA")
RED = hx("#E5484D"); GREEN = (46 / 255, 204 / 255, 113 / 255, 1); GOLD = hx("#B8923F"); GOLD2 = hx("#D9B45E")
C_BRIT, C_ESP, C_FR, C_ARAB = hx("#E5484D"), hx("#FF8A3D"), hx("#45A4DD"), hx("#A855F7")

# ------------------------------------------------------------------ geography
def merc(lat):
    lat = max(-85.0, min(85.0, lat)); return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))
def mercv(lat): lat = np.clip(lat, -85, 85); return np.degrees(np.log(np.tan(np.pi / 4 + np.radians(lat) / 2)))
def topo_arcs(t):
    sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    return lambda i: arcs[i] if i >= 0 else arcs[~i][::-1]
def load_world(path):
    tp = json.load(open(path)); arc = topo_arcs(tp); out = []
    for g in tp["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        name = g["properties"]["name"]
        if name in ("Israel", "Palestine", "Antarctica"): continue
        for p in ([g["arcs"]] if g["type"] == "Polygon" else g["arcs"]):
            ring = []
            for i in p[0]: ring.extend(arc(i))
            outp = [ring[0]]; off = 0.0
            for (x0, _), (x1, y1) in zip(ring, ring[1:]):
                if x1 - x0 > 180: off -= 360
                elif x0 - x1 > 180: off += 360
                outp.append((x1 + off, y1))
            a = np.array(outp); a[:, 1] = mercv(a[:, 1])
            for k in (-360, 0, 360):
                b = a + [k, 0]; out.append((name, b, (b[:, 0].min(), b[:, 0].max(), b[:, 1].min(), b[:, 1].max())))
    return out
W50 = load_world("/home/claude/geo/package/countries-50m.json"); W110 = load_world("/home/claude/geo/package/countries-110m.json")
GEO = "/home/claude/goals_scorecard/geodata"
def topo_named(path, names):
    t = json.load(open(path)); arc = topo_arcs(t); out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g["properties"]["name"] not in names: continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
RG = topo_named(f"{GEO}/countries-10m.json", ("Israel", "Palestine")); ISR, PAL = RG["Israel"], RG["Palestine"]
LANDG = unary_union([ISR.buffer(0.002), PAL.buffer(0.002)]).buffer(-0.002).simplify(0.002)
def mc(arr): a = np.array(arr, float); a[:, 1] = mercv(a[:, 1]); return a
LAND_R = [mc(p.exterior.coords) for p in (LANDG.geoms if hasattr(LANDG, "geoms") else [LANDG]) if p.area > 0.002]
LAKES = []
for f in json.load(open(f"{GEO}/ne_10m_lakes.geojson"))["features"]:
    s_ = shape(f["geometry"])
    if 34 < s_.centroid.x < 36.5 and 29 < s_.centroid.y < 34:
        for p in (s_.geoms if hasattr(s_, "geoms") else [s_]): LAKES.append(mc(p.simplify(0.002).exterior.coords))
GREENL = []
_ib = ISR.buffer(0.015)
for poly in (PAL.geoms if hasattr(PAL, "geoms") else [PAL]):
    g = poly.exterior.intersection(_ib)
    for ln in (g.geoms if hasattr(g, "geoms") else [g]):
        if ln.geom_type == "LineString" and ln.length > 0.01: GREENL.append(mc(ln.simplify(0.002).coords))

MY0, MY1 = 450, 1062; MH = MY1 - MY0; MCY = (MY0 + MY1) / 2
LANDC, BORDC = hx("#2A4170"), hx("#45629A")
class Cam:
    def __init__(s, lon, lat, sc, m=None): s.lon, s.m, s.s = lon, (merc(lat) if m is None else m), sc
    def P(s, lon, lat): return (CX + (lon - s.lon) * s.s, MCY - (merc(lat) - s.m) * s.s)
    def Pm(s, a): return np.stack([CX + (a[:, 0] - s.lon) * s.s, MCY - (a[:, 1] - s.m) * s.s], 1)
    def box(s):
        hw, hh = W / 2 / s.s, MH / 2 / s.s + 60 / s.s; return (s.lon - hw - 1, s.lon + hw + 1, s.m - hh - 1, s.m + hh + 1)
def cam_lerp(a, b, u):
    """zoom from a to b: log scale, centre weighted by 1/s so the target point travels smoothly"""
    if u <= 0: return a
    if u >= 1: return b
    s = math.exp(lerp(math.log(a.s), math.log(b.s), u))
    w = (1 / s - 1 / a.s) / (1 / b.s - 1 / a.s) if abs(b.s - a.s) > 1e-6 else u
    return Cam(lerp(a.lon, b.lon, w), 0, s, m=lerp(a.m, b.m, w))
V_WORLD = Cam(15, 0, 3.0, m=22)
V_BRIT = Cam(40, 0, 9.5, m=34)
V_ESP = Cam(-55, 0, 8.0, m=15)
V_FR = Cam(3, 0, 14.0, m=39.5)
V_ARAB = Cam(22, 0, 13.5, m=29)
V_LAND = Cam(35.05, 31.5, 118.0)
V_REG = Cam(27, 0, 10.5, m=40.5)

def path_arr(ctx, pp):
    ctx.move_to(*pp[0])
    for x, y in pp[1:]: ctx.line_to(x, y)
    ctx.close_path()
def visible(cam, rings):
    x0, x1, y0, y1 = cam.box()
    return [(n, a) for n, a, (a0, a1, b0, b1) in rings if a1 >= x0 and a0 <= x1 and b1 >= y0 and b0 <= y1]
def decimate(pp, tol=0.8):
    if len(pp) < 40: return pp
    d = np.abs(np.diff(pp, axis=0)).sum(1); keep = [0]; acc = 0.0
    for i, v in enumerate(d, 1):
        acc += v
        if acc >= tol: keep.append(i); acc = 0.0
    if keep[-1] != len(pp) - 1: keep.append(len(pp) - 1)
    return pp[keep]
_BASE = {}
def base_layer(cam):
    key = (round(cam.lon, 3), round(cam.m, 3), round(cam.s, 4))
    if key in _BASE: return _BASE[key]
    if len(_BASE) > 3: _BASE.clear()
    sf_ = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, MH); c = cairo.Context(sf_); c.translate(0, -MY0)
    c.set_source_rgba(1, 1, 1, 0.04); c.set_line_width(1)
    step = 15 if cam.s < 20 else 5 if cam.s < 60 else 1
    lo = math.floor((cam.lon - W / 2 / cam.s) / step) * step
    while lo < cam.lon + W / 2 / cam.s:
        x, _ = cam.P(lo, 0); c.move_to(x, MY0); c.line_to(x, MY1); lo += step
    for la in range(-75, 90, step):
        _, y = cam.P(0, la)
        if MY0 <= y <= MY1: c.move_to(0, y); c.line_to(W, y)
    c.stroke()
    rings = visible(cam, W110 if cam.s < 5.5 else W50); pps = [(n, decimate(cam.Pm(a))) for n, a in rings]
    for n, pp in pps: path_arr(c, pp)
    c.set_source_rgba(*LANDC); c.fill()
    for n, pp in pps: path_arr(c, pp)
    c.set_line_join(cairo.LINE_JOIN_ROUND); c.set_line_width(1.1 if cam.s < 30 else 1.6); c.set_source_rgba(*BORDC); c.stroke()
    _BASE[key] = sf_; return sf_
def highlight(ctx, cam, names, col, al):
    if al <= 0.01: return
    rings = [(n, a) for n, a in visible(cam, W110 if cam.s < 5.5 else W50) if n in names]
    for n, a in rings: path_arr(ctx, decimate(cam.Pm(a)))
    ctx.set_source_rgba(col[0], col[1], col[2], al * col[3]); ctx.fill()
def gold_land(ctx, cam, al=1.0, glow=0.0):
    k = cam.s
    if glow > 0:
        x, y = cam.P(35.0, 31.6); r = max(40, 3.2 * k)
        g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *GOLD2[:3], 0.55 * glow); g.add_color_stop_rgba(1, *GOLD2[:3], 0)
        ctx.set_source(g); ctx.arc(x, y, r, 0, 2 * math.pi); ctx.fill()
    ctx.push_group()
    for r in LAND_R: path_arr(ctx, cam.Pm(r))
    y0 = cam.P(35, 33.4)[1]; y1 = cam.P(35, 29.5)[1]
    g = cairo.LinearGradient(0, y0, 0, y1); g.add_color_stop_rgba(0, *hx("#C9A24E")[:3], 1); g.add_color_stop_rgba(1, *GOLD[:3], 1)
    ctx.set_source(g); ctx.fill_preserve(); ctx.set_source_rgba(*hx("#EBCB7E")[:3], 0.9); ctx.set_line_width(clamp(k / 60, 0.6, 2.5)); ctx.stroke()
    if k > 30:
        for r in LAKES: path_arr(ctx, cam.Pm(r))
        ctx.set_source_rgba(*hx("#0F2147")[:3], 1); ctx.fill()
    ctx.set_source_rgba(*GREEN[:3], 1); ctx.set_line_width(clamp(k / 40, 0.8, 3.4)); ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    for ln in GREENL:
        pp = cam.Pm(ln); ctx.move_to(*pp[0])
        for x, y in pp[1:]: ctx.line_to(x, y)
        ctx.stroke()
    ctx.pop_group_to_source(); ctx.paint_with_alpha(al)

def map_begin(ctx): ctx.push_group()
def map_end(ctx, al=1.0):
    pat = ctx.pop_group(); m = cairo.LinearGradient(0, MY0, 0, MY1)
    for u, a in ((0, 0), (0.08, 1), (0.92, 1), (1, 0)): m.add_color_stop_rgba(u, 0, 0, 0, a * al)
    ctx.set_source(pat); ctx.mask(m)

def arc_pt(a, b, u, lift=0.22):
    mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2; dx, dy = b[0] - a[0], b[1] - a[1]
    cx_, cy_ = mx + dy * lift * 0.3, my - abs(dx) * lift - abs(dy) * 0.05
    return ((1 - u) ** 2 * a[0] + 2 * (1 - u) * u * cx_ + u * u * b[0], (1 - u) ** 2 * a[1] + 2 * (1 - u) * u * cy_ + u * u * b[1])
def arrow(ctx, a, b, u, lift, col, al, lw=6, head=1.0):
    if u <= 0.02 or al <= 0.01: return
    ctx.save(); ctx.set_line_cap(cairo.LINE_CAP_ROUND); ctx.set_line_join(cairo.LINE_JOIN_ROUND)
    ctx.move_to(*a)
    for k in range(1, 41): ctx.line_to(*arc_pt(a, b, u * k / 40, lift))
    ctx.set_source_rgba(0.03, 0.06, 0.14, 0.5 * al); ctx.set_line_width(lw + 5); ctx.stroke_preserve()
    ctx.set_source_rgba(col[0], col[1], col[2], al); ctx.set_line_width(lw); ctx.stroke()
    p1 = arc_pt(a, b, u, lift); p0 = arc_pt(a, b, max(0, u - 0.03), lift); ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
    ctx.translate(*p1); ctx.rotate(ang); ctx.scale(head, head); ctx.move_to(8, 0); ctx.line_to(-18, -13); ctx.line_to(-18, 13); ctx.close_path(); ctx.fill(); ctx.restore()
def flow(ctx, a, b, t, t0, lift, col, al, n=5, period=1.6):
    """dots travelling a -> b on an arc, looping (wealth home, settlers out)"""
    if t < t0 or al <= 0.01: return
    for k in range(n):
        u = ((t - t0) / period - k / n) % 1.0
        if (t - t0) / period < k / n: continue
        x, y = arc_pt(a, b, u, lift); fa = al * min(1, u / 0.1, (1 - u) / 0.1)
        ctx.arc(x, y, 10, 0, 2 * math.pi); ctx.set_source_rgba(0.03, 0.06, 0.14, 0.5 * fa); ctx.fill()
        ctx.arc(x, y, 7, 0, 2 * math.pi); ctx.set_source_rgba(col[0], col[1], col[2], fa); ctx.fill()
def pin(ctx, x, y, lab, al, side="r", col=WHITE, size=40, he=None, he_al=0.0, dy=0):
    if al <= 0.01: return
    ctx.arc(x, y, 12, 0, 2 * math.pi); ctx.set_source_rgba(0.03, 0.06, 0.14, 0.7 * al); ctx.fill()
    ctx.arc(x, y, 8 * (0.6 + 0.4 * eback(al)), 0, 2 * math.pi); ctx.set_source_rgba(col[0], col[1], col[2], al); ctx.fill()
    if not lab: return
    lw_ = tw(lab, 800, size) + 30; bh = size + 18; hh = bh + (size + 12 if he else 0) * (1 if he_al > 0 else 0)
    bx = x + 22 if side == "r" else x - 22 - lw_ if side == "l" else x - lw_ / 2
    if he: lw_ = max(lw_, tw(he, 700, size + 4) + 30)
    if side == "l": bx = x - 22 - lw_
    by = (y - bh / 2 if side in "lr" else y - bh - 22) + dy
    bx = min(W - 16 - lw_, max(16, bx))
    if dy:
        ctx.move_to(x, y); ctx.line_to(bx + (0 if side == "r" else lw_), by + bh / 2); ctx.set_source_rgba(1, 1, 1, 0.7 * al); ctx.set_line_width(2.5); ctx.stroke()
    rrect(ctx, bx, by, lw_, bh + (size + 8) * ease(he_al) if he else bh, 12); ctx.set_source_rgba(0.04, 0.07, 0.15, 0.9 * al); ctx.fill()
    text(ctx, lab, bx + lw_ / 2, by + bh / 2, 800, size, WHITE, al)
    if he and he_al > 0: text(ctx, he, bx + lw_ / 2, by + bh + size / 2 - 2, 700, size + 4, YEL, al * ease(he_al))

# ------------------------------------------------------------------ card parts
def bg(ctx):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *hx("#0E1E3A")[:3], 1); g.add_color_stop_rgba(1, *hx("#132A57")[:3], 1)
    ctx.set_source(g); ctx.paint()
def header(ctx, title, he, t, t0, he_out=None):
    a = ease((t - t0) / 0.25)
    text(ctx, title, CX, 322, 900, fit(title, 900, 86, 960), WHITE, a, scale=0.94 + 0.06 * eback((t - t0) / 0.35))
    ha = ease((t - t0 - 0.12) / 0.25) * (1 - ease((t - he_out) / 0.25) if he_out else 1)
    text(ctx, he, CX, 404, 700, fit(he, 700, 64, 960), WHITE, ha)
def chip(ctx, lines, slot, col, a, icon="check"):
    if a <= 0.01: return
    y = 1080 + slot * 96 + (1 - a) * 16; h = 84 + (len(lines) - 1) * 66; x = 70; w = 940
    ctx.save(); rrect(ctx, x, y, w, h, 24); ctx.set_source_rgba(1, 1, 1, 0.08 * a); ctx.fill_preserve()
    ctx.set_source_rgba(col[0], col[1], col[2], 0.9 * a); ctx.set_line_width(3); ctx.stroke()
    cx_, cy_ = x + 50, y + h / 2; ctx.arc(cx_, cy_, 24, 0, 2 * math.pi); ctx.set_source_rgba(col[0], col[1], col[2], a); ctx.fill()
    ctx.set_source_rgba(1, 1, 1, a); ctx.set_line_width(6); ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    ctx.move_to(cx_ - 11, cy_ + 1); ctx.line_to(cx_ - 3, cy_ + 9); ctx.line_to(cx_ + 12, cy_ - 9); ctx.stroke(); ctx.restore()
    for k, ln in enumerate(lines):
        segs = ln if isinstance(ln, list) else [(ln, WHITE)]; full = "".join(s for s, _ in segs)
        size = fit(full, 800, 56, 830); xx = x + 96; yy = y + 42 + k * 66
        for s, cl in segs:
            text(ctx, s, xx, yy, 800, size, cl, a, "l"); xx += tw(s, 800, size)
def source(ctx, s, a): text(ctx, s, CX, 1400, 700, fit(s, 700, 40, 940), SOFT, a)
def view_pill(ctx, y, a):
    s = "In my view"; w_ = tw(s, 800, 40) + 44
    rrect(ctx, CX - w_ / 2, y - 30, w_, 60, 30); ctx.set_source_rgba(1, 1, 1, 0.95 * a); ctx.fill()
    text(ctx, s, CX, y, 800, 40, hx("#0E1E3A"), a)
def stamp(ctx, t, t0, lines, col, he=None, y=760, ang=-7, sizes=(92, 118)):
    u = (t - t0) / 0.2
    if u <= 0: return 0
    a = clamp(u * 1.5); sc = 1 + 1.3 * (1 - ease(u)) if u < 1 else 1 + 0.03 * math.exp(-(t - t0 - 0.2) * 6) * math.sin((t - t0) * 30)
    ws = [fit(l, 900, sz, 800) for l, sz in zip(lines, sizes)]
    bw = max(tw(l, 900, s) for l, s in zip(lines, ws)) + 90; lh = [s * 1.12 for s in ws]
    bh = sum(lh) + 54 + (78 if he else 0)
    ctx.save(); ctx.translate(CX, y); ctx.rotate(math.radians(ang)); ctx.scale(sc, sc)
    rrect(ctx, -bw / 2 - 8, -bh / 2 - 8, bw + 16, bh + 16, 26); ctx.set_source_rgba(0.03, 0.06, 0.14, 0.62 * a); ctx.fill()
    rrect(ctx, -bw / 2, -bh / 2, bw, bh, 20); ctx.set_source_rgba(col[0], col[1], col[2], a); ctx.set_line_width(10); ctx.stroke()
    rrect(ctx, -bw / 2 + 16, -bh / 2 + 16, bw - 32, bh - 32, 12); ctx.set_line_width(3); ctx.stroke()
    yy = -bh / 2 + 27
    for l, s, h_ in zip(lines, ws, lh):
        text(ctx, l, 0, yy + h_ / 2, 900, s, col, a); yy += h_
    if he: text(ctx, he, 0, yy + 36, 800, fit(he, 800, 60, bw - 70), WHITE, a)
    ctx.restore()
    return bh
def shake(t, t0):
    d = t - t0
    if 0 <= d < 0.25: k = (1 - d / 0.25) * 9; return (k * math.sin(d * 90), k * math.cos(d * 70))
    return (0, 0)

# ------------------------------------------------------------------ timeline
def cs(k): return C[k][0]
def ce(k): return C[k][1]
S = {"hook": (0, cs(2) - 0.35), "brit": (cs(2) - 0.35, cs(6) - 0.35), "esp": (cs(6) - 0.35, cs(9) - 0.35), "fr": (cs(9) - 0.35, cs(12) - 0.35),
     "arab": (cs(12) - 0.35, cs(16) - 0.35), "ja": (cs(16) - 0.35, cs(20) - 0.35), "jb": (cs(20) - 0.35, cs(22) - 0.35), "jc": (cs(22) - 0.35, cs(24) - 0.45),
     "cta": (cs(24) - 0.45, T_END)}
STAMP_T = {"brit": cs(5) + 0.28, "esp": cs(8) + 0.28, "fr": cs(11) + 0.28, "arab": cs(15) + 0.28, "jc": cs(22) + 0.3}
def frac(k, u): return lerp(cs(k), ce(k), u)
P = dict(LON=(-0.13, 51.5), DEL=(77.2, 28.6), MAD=(-3.7, 40.4), MEX=(-99.1, 19.4), LIM=(-77.0, -12.0), POT=(-65.75, -19.6), PAR=(2.35, 48.86), ALG=(3.06, 36.75),
         MED=(39.6, 24.5), CAI=(31.2, 30.05), KAI=(10.1, 35.7), DAM=(36.3, 33.5), JER=(35.217, 31.778), HEB=(35.095, 31.532), JAF=(34.752, 32.05), BSH=(34.79, 31.25))
CASES = {
    "brit": dict(title="Britain in India", he="בריטניה בהודו", view=V_BRIT, col=C_BRIT, home={"United Kingdom"}, colony={"India", "Pakistan", "Bangladesh"},
                 pins=[("LON", "London", "r", 0.9), ("DEL", "Delhi", "r", 1.4)], arrows=[("LON", "DEL", 1.0, 0.22)],
                 flows=[("DEL", "LON", cs(4) + 0.1, 0.30, YEL)], dist=("about 7,000 km", "LON", "DEL", frac(3, 0.45)),
                 chips=[(["Ruled from London"], 0, cs(3), None), (["Wealth shipped home"], 1, cs(4), None)],
                 src="Source: Britannica, British raj"),
    "esp": dict(title="Spain in the Americas", he="ספרד ביבשת אמריקה", view=V_ESP, col=C_ESP, home={"Spain"},
                colony={"Mexico", "Guatemala", "Honduras", "El Salvador", "Nicaragua", "Costa Rica", "Panama", "Cuba", "Dominican Rep.", "Puerto Rico", "Colombia", "Venezuela",
                        "Ecuador", "Peru", "Bolivia", "Chile", "Argentina", "Paraguay", "Uruguay"},
                pins=[("MAD", "Madrid", "r", 0.9), ("MEX", "Mexico City", "r", 1.4), ("LIM", "Lima", "r", 1.6)], arrows=[("MAD", "MEX", 1.0, 0.2), ("MAD", "LIM", 1.2, 0.2)],
                flows=[("POT", "MAD", frac(7, 0.55), 0.18, YEL), ("MEX", "MAD", frac(7, 0.6), 0.28, YEL)], dist=None,
                chips=[(["Spanish language"], 0, frac(7, 0.0), None), (["Catholic Church"], 1, frac(7, 0.3), None), ([[("Silver, gold ", YEL), ("to Spain", WHITE)]], 2, frac(7, 0.6), None)],
                src="Source: Britannica, Spanish Empire"),
    "fr": dict(title="France in Algeria", he="צרפת באלג'יריה", view=V_FR, col=C_FR, home={"France"}, colony={"Algeria"},
               pins=[("PAR", "Paris", "r", 0.9), ("ALG", "Algiers", "r", 1.4)], arrows=[("PAR", "ALG", 1.0, 0.35)],
               flows=[("PAR", "ALG", cs(10), -0.25, WHITE)], dist=None,
               chips=[([[("1830 ", YEL), ("to ", WHITE), ("1962", YEL)]], 0, frac(9, 0.55), None), (["Settlers from France"], 1, cs(10), None), (["Ruled from Paris"], 2, frac(10, 0.6), None)],
               src="Source: Britannica, Algeria: French rule"),
    "arab": dict(title="Early Arab conquests", he="הכיבושים הערביים הראשונים", view=V_ARAB, col=C_ARAB,
                 home={"Saudi Arabia", "Yemen", "Oman", "United Arab Emirates", "Qatar", "Bahrain", "Kuwait"},
                 colony={"Egypt", "Libya", "Tunisia", "Algeria", "Morocco", "W. Sahara", "Syria", "Iraq", "Jordan", "Lebanon"},
                 pins=[("MED", "Arabia", "r", 0.9), ("CAI", "Egypt", "b", 1.4), ("KAI", "North Africa", "b", 1.9)], arrows=[("MED", "CAI", 1.0, 0.25), ("CAI", "KAI", 1.5, 0.25), ("MED", "DAM", 1.3, 0.25)],
                 flows=[], dist=None,
                 chips=[([[("7th century", YEL)]], 0, cs(13), cs(14)), (["Arabia to North Africa"], 1, frac(13, 0.3), cs(14)),
                        ([[("Over centuries, ", YEL), ("Arabic replaced", WHITE)], "Coptic and Aramaic"], 0, cs(14) + 0.15, None)],
                 langs=[("Coptic", 28.5, 25.0), ("Aramaic", 43.8, 36.2)],
                 src="Source: Britannica, Arabization; Coptic; Aramaic"),
}
STAMP_HE = {"brit": "זו קולוניזציה.", "esp": "זו קולוניזציה.", "fr": "זו קולוניזציה.", "arab": "גם זו קולוניזציה."}
ORDER = ["brit", "esp", "fr", "arab"]

def case_frame(ctx, name, t):
    c = CASES[name]; t0 = S[name][0]; el = t - t0; ts = STAMP_T[name]
    cam = cam_lerp(V_WORLD, c["view"], eio((el - 0.1) / 1.3))
    ox, oy = shake(t, ts); ctx.save(); ctx.translate(ox, oy)
    map_begin(ctx)
    ctx.set_source_surface(base_layer(cam), 0, MY0); ctx.paint()
    ha = ease((el - 0.6) / 0.4)
    highlight(ctx, cam, c["colony"], c["col"], 0.62 * ease((el - 1.2) / 0.6)); highlight(ctx, cam, c["home"], c["col"], ha)
    gold_land(ctx, cam)
    for a_, b_, d, lift in c["arrows"]:
        arrow(ctx, cam.P(*P[a_]), cam.P(*P[b_]), ease((el - d) / 0.8), lift, WHITE, 0.95)
    for a_, b_, tf, lift, col in c["flows"]:
        flow(ctx, cam.P(*P[a_]), cam.P(*P[b_]), t, tf, lift, col, 1.0)
    for key, lab, side, d in c["pins"]:
        x, y = cam.P(*P[key]); pin(ctx, x, y, lab, ease((el - d) / 0.3), side if side != "b" else "c")
    if "langs" in c:
        for k, (lab, lo, la) in enumerate(c["langs"]):
            a = fade(t, cs(14) + 0.2 * k); x, y = cam.P(lo, la)
            if a > 0:
                text(ctx, lab, x, y, 800, 42, WHITE, a); st_ = ease((t - cs(14) - 0.9 - 0.2 * k) / 0.35); w_ = tw(lab, 800, 42)
                if st_ > 0:
                    ctx.move_to(x - w_ / 2 - 6, y + 2); ctx.line_to(x - w_ / 2 - 6 + (w_ + 12) * st_, y + 2); ctx.set_source_rgba(*RED[:3], a); ctx.set_line_width(6); ctx.stroke()
    if c["dist"]:
        lab, a_, b_, td = c["dist"]; p = arc_pt(cam.P(*P[a_]), cam.P(*P[b_]), 0.5, 0.22); a = fade(t, td)
        if a > 0:
            w_ = tw(lab, 800, 44) + 34; rrect(ctx, p[0] - w_ / 2, p[1] - 70, w_, 60, 30); ctx.set_source_rgba(*YEL[:3], a); ctx.fill()
            text(ctx, lab, p[0], p[1] - 40, 800, 44, hx("#0E1E3A"), a)
    map_end(ctx)
    header(ctx, c["title"], c["he"], t, t0 + 0.05, he_out=ts)
    for lines, slot, tin, tout in c["chips"]:
        a = fade(t, tin, tout if tout else ts - 0.05, 0.25, 0.25); chip(ctx, lines, slot, c["col"], a)
    source(ctx, c["src"], fade(t, t0 + 0.8))
    ctx.restore()
    bh = stamp(ctx, t, ts, ["THIS IS", "COLONIZATION"], RED, STAMP_HE[name], y=772)
    if name == "arab" and bh: view_pill(ctx, 772 + bh / 2 + 70, fade(t, ts + 0.35))
    fl = 1 - ease(el / 0.2)
    if fl > 0: ctx.set_source_rgba(1, 1, 1, 0.3 * fl); ctx.paint()

RET = [(-7.6, 33.6), (10.2, 36.8), (13.2, 32.9), (2.35, 48.86), (-0.13, 51.5), (13.4, 52.5), (21.0, 52.2), (37.6, 55.75), (30.5, 50.45), (26.1, 44.4),
       (19.0, 47.5), (29.0, 41.0), (44.4, 33.3), (51.4, 35.7), (44.2, 15.4), (-3.7, 40.4), (-9.1, 38.7), (12.5, 41.9)]
LANDPT = (35.0, 31.6)
def jews_frame(ctx, t):
    ta, tb, tc = S["ja"][0], S["jb"][0], S["jc"][0]
    if t < tb: cam = cam_lerp(V_WORLD, V_LAND, eio((t - ta - 0.1) / 1.7))
    elif t < tc - 0.6: cam = cam_lerp(V_LAND, V_REG, eio((t - tb) / 1.3))
    else: cam = cam_lerp(V_REG, V_LAND, eio((t - (tc - 0.6)) / 1.1))
    ts = STAMP_T["jc"]; ox, oy = shake(t, ts); ctx.save(); ctx.translate(ox, oy)
    map_begin(ctx)
    ctx.set_source_surface(base_layer(cam), 0, MY0); ctx.paint()
    gl = 0.6 + 0.4 * math.sin(t * 2.5)
    gold_land(ctx, cam, glow=gl * (1 if t < tb else 0.6))
    # pins in the land
    pa = fade(t, cs(18), tb - 0.1); he_a = (t - cs(19) - 0.1) / 0.3
    if pa > 0 and cam.s > 60:
        for key, lab, side, dy, he, d in (("JER", "Jerusalem", "r", -34, "ירושלים", 0), ("HEB", "Hebron", "r", 40, "חברון", 0.25)):
            x, y = cam.P(*P[key]); pin(ctx, x, y, lab, pa * ease((t - cs(18) - d) / 0.3), side, YEL, 40, he=he, he_al=he_a, dy=dy)
        for key, lab, he, dy, d in (("JAF", "Jaffa", "יפו", -30, 0.15), ("BSH", "Beersheba", "באר שבע", 30, 0.35)):
            x, y = cam.P(*P[key]); pin(ctx, x, y, lab, pa * ease((t - cs(19) - d) / 0.3), "l", WHITE, 40, he=he, he_al=(t - cs(19) - d - 0.1) / 0.3, dy=dy)
    # return arrows from many places INTO the land
    ra = 1 - ease((t - tc + 0.5) / 0.4)
    if t > tb and ra > 0:
        J = cam.P(*LANDPT)
        for k, (lo, la) in enumerate(RET):
            d = cs(20) + 0.25 + k * 0.17; u = ease((t - d) / 0.9)
            arrow(ctx, cam.P(lo, la), J, u, 0.16, YEL if k % 3 else WHITE, 0.9 * ra, lw=4, head=0.8)
            if u > 0:
                x, y = cam.P(lo, la); ctx.arc(x, y, 7, 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, 0.9 * ra); ctx.fill()
        ha = fade(t, cs(21), tc - 0.5)
        if ha > 0:
            r = 26 + 6 * math.sin(t * 6); ctx.arc(J[0], J[1], r, 0, 2 * math.pi); ctx.set_source_rgba(*GOLD2[:3], 0.9 * ha); ctx.set_line_width(4); ctx.stroke()
            pin(ctx, J[0], J[1] + 4, "Home", ha, "r", GOLD2, 44, dy=46)
    map_end(ctx)
    hout = tc + 0.1
    a = fade(t, ta + 0.25, hout)
    if a > 0:
        ctx.push_group(); header(ctx, "And the Jews?", "והיהודים?", t, cs(16) - 0.15); ctx.pop_group_to_source(); ctx.paint_with_alpha(a)
    chips = [([[("Hebrew: ", WHITE), ("born here", YEL)]], 0, cs(17), tb - 0.05), ([[("Holy places: ", WHITE), ("here", YEL)]], 1, cs(18), tb - 0.05),
             ([[("City names: ", WHITE), ("Hebrew", YEL)]], 2, cs(19), tb - 0.05),
             ([[("No ", YEL), ("mother country", WHITE)]], 0, cs(20) + 0.1, tc - 0.4), ([[("No ", YEL), ("empire shipping riches home", WHITE)]], 1, frac(20, 0.48), tc - 0.4)]
    for lines, slot, tin, tout in chips:
        chip(ctx, lines, slot, GOLD if slot < 3 and tin < tb else GREEN, fade(t, tin, tout, 0.25, 0.25))
    source(ctx, "Source: Britannica, Hebrew; Jerusalem; Hebron", fade(t, cs(17), tb - 0.1))
    source(ctx, "Source: Britannica, aliyah", fade(t, tb + 0.4, tc - 0.3))
    ctx.restore()
    if t >= ts - 0.01:
        bh = stamp(ctx, t, ts, ["THIS IS NOT", "COLONIZATION"], GREEN, None, y=700, ang=-6, sizes=(100, 112))
        view_pill(ctx, 700 + bh / 2 + 66, fade(t, ts + 0.4))
        hu = (t - cs(23) + 0.05) / 0.35
        text(ctx, "This is coming home.", CX, 1150, 900, fit("This is coming home.", 900, 92, 960), YEL, ease(hu), scale=0.9 + 0.1 * eback(hu))
        he = "זו לא קולוניזציה. זו חזרה הביתה"
        text(ctx, he, CX, 1262, 700, fit(he, 700, 64, 960), WHITE, ease(hu - 0.5))
    fl = 1 - ease((t - ta) / 0.2)
    if fl > 0: ctx.set_source_rgba(1, 1, 1, 0.3 * fl); ctx.paint()

TEASE = [(77.2, 28.6, C_BRIT), (-99.1, 19.4, C_ESP), (3.06, 36.75, C_FR), (31.2, 30.05, C_ARAB)]
def hook_frame(ctx, t):
    cam = Cam(V_WORLD.lon + t * 0.6, 0, V_WORLD.s * (1 + 0.025 * t), m=V_WORLD.m)
    map_begin(ctx); ctx.set_source_surface(base_layer(cam), 0, MY0); ctx.paint(); gold_land(ctx, cam, glow=0.8)
    for k, (lo, la, col) in enumerate(TEASE):
        x, y = cam.P(lo, la); p = 0.5 + 0.5 * math.sin(t * 4 + k)
        ctx.arc(x, y, 10 + 8 * p, 0, 2 * math.pi); ctx.set_source_rgba(col[0], col[1], col[2], 0.35); ctx.fill()
        ctx.arc(x, y, 8, 0, 2 * math.pi); ctx.set_source_rgba(col[0], col[1], col[2], 1); ctx.fill()
    map_end(ctx, 0.55)
    ctx.set_source_rgba(0.04, 0.08, 0.17, 0.35); ctx.rectangle(0, MY0, W, MH); ctx.fill()
    sc = 1 + 0.02 * t
    text(ctx, "This is", CX, 690, 900, 150, WHITE, 1, scale=sc)
    text(ctx, "colonization.", CX, 850, 900, fit("colonization.", 900, 160, 960), YEL, 1, scale=sc)
    text(ctx, "זו קולוניזציה.", CX, 1000, 800, 72, WHITE, 1)

def cta_frame(ctx, t):
    t0 = S["cta"][0]; el = t - t0
    cam = Cam(V_WORLD.lon + el * 0.8, 0, V_WORLD.s, m=V_WORLD.m)
    map_begin(ctx); ctx.set_source_surface(base_layer(cam), 0, MY0); ctx.paint(); gold_land(ctx, cam, glow=0.8); map_end(ctx, 0.35)
    a = ease(el / 0.3)
    text(ctx, "Which one", CX, 640, 900, 116, WHITE, a, scale=0.9 + 0.1 * eback(el / 0.35))
    text(ctx, "surprised you?", CX, 780, 900, fit("surprised you?", 900, 116, 960), YEL, a, scale=0.9 + 0.1 * eback(el / 0.35))
    b = ease((t - cs(25) + 0.1) / 0.3)
    s = "Tell me in the comments"; text(ctx, s, CX, 950, 800, fit(s, 800, 72, 960), WHITE, max(b, 0.0))
    he = "מה הפתיע אותך? כתבו לי בתגובות"; text(ctx, he, CX, 1070, 700, fit(he, 700, 64, 960), SOFT if False else WHITE, ease(el / 0.3 - 0.6))
    # comment bubble
    ba = ease((t - cs(25)) / 0.35)
    if ba > 0:
        ctx.save(); ctx.translate(CX, 1250); ctx.scale(0.8 + 0.2 * eback((t - cs(25)) / 0.35), 0.8 + 0.2 * eback((t - cs(25)) / 0.35))
        rrect(ctx, -90, -60, 180, 110, 34); ctx.move_to(-30, 48); ctx.line_to(-55, 88); ctx.line_to(10, 48); ctx.close_path()
        ctx.set_source_rgba(*SKY[:3], ba); ctx.fill()
        for k in range(3):
            ctx.arc(-44 + 44 * k, -5, 11 + 3 * max(0, math.sin(t * 6 - k)), 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, ba); ctx.fill()
        ctx.restore()

def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); ctx = cairo.Context(s); bg(ctx)
    if t < S["hook"][1]: hook_frame(ctx, t)
    elif t < S["ja"][0]: case_frame(ctx, next(n for n in ORDER if S[n][0] <= t < S[n][1]), t)
    elif t < S["cta"][0]: jews_frame(ctx, t)
    else:
        cta_frame(ctx, t)
        fl = 1 - ease((t - S["cta"][0]) / 0.2)
        if fl > 0: ctx.set_source_rgba(1, 1, 1, 0.25 * fl); ctx.paint()
    s.flush()
    return np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, [2, 1, 0]].copy()

# ------------------------------------------------------------------ audio
def synth_sfx():
    tt = lambda d: np.arange(int(d * SR)) / SR; rng = np.random.default_rng(3)
    x = tt(1.6); ding = (np.sin(2 * np.pi * 1046.5 * x) + 0.6 * np.sin(2 * np.pi * 1568 * x) * np.exp(-x * 2) + 0.25 * np.sin(2 * np.pi * 3136 * x) * np.exp(-x * 6)) * np.exp(-x * 2.4)
    x = tt(0.35); thump = np.sin(2 * np.pi * (55 + 90 * np.exp(-x * 28)) * x) * np.exp(-x * 11)
    x = tt(0.12); nz = rng.standard_normal(len(x)); clack = np.convolve(nz, np.ones(4) / 4, "same") * np.exp(-x * 60)
    stampfx = np.concatenate([thump[:len(thump)]]); stampfx[:len(clack)] += 0.6 * clack
    x = tt(0.5); nz = rng.standard_normal(len(x)); whoosh = np.convolve(nz, np.ones(30) / 30, "same") * np.sin(np.pi * x / 0.5) ** 2
    x = tt(0.09); pop = np.sin(2 * np.pi * (500 + 900 * np.exp(-x * 40)) * x) * np.exp(-x * 45)
    nrm = lambda v: v / (np.abs(v).max() + 1e-9)
    return dict(ding=nrm(ding), stamp=nrm(stampfx), whoosh=nrm(whoosh), pop=nrm(pop))
def build_audio(path):
    n = int(T_END * SR); voice = sf.read(f"{HERE}/vo/vo.wav")[0][:n]; voice = np.pad(voice, (0, n - len(voice)))
    voice = voice / (np.abs(voice).max() + 1e-9) * 0.9
    sfx = np.zeros(n); X = synth_sfx()
    def put(x, t0, g):
        i = int(t0 * SR); j = min(n, i + len(x))
        if 0 <= i < n: sfx[i:j] += g * x[:j - i]
    for k in ORDER + ["ja"]: put(X["whoosh"], S[k][0] - 0.15, 0.22)
    put(X["whoosh"], S["jb"][0] - 0.1, 0.16); put(X["whoosh"], S["jc"][0] - 0.6, 0.18); put(X["whoosh"], S["cta"][0] - 0.15, 0.2)
    for k, ts in STAMP_T.items(): put(X["stamp"], ts + 0.17, 0.6)
    put(X["ding"], STAMP_T["jc"] + 0.25, 0.22); put(X["ding"], cs(23), 0.18)
    for nm, c in CASES.items():
        for lines, slot, tin, tout in c["chips"]: put(X["pop"], tin, 0.12)
    for tin in (cs(17), cs(18), cs(19), cs(20) + 0.1, frac(20, 0.48)): put(X["pop"], tin, 0.12)
    for k in range(len(RET)): put(X["pop"], cs(20) + 0.25 + k * 0.17 + 0.9, 0.05)
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", f"{HERE}/music.wav", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True)
    mus = np.frombuffer(p.stdout, np.float32).astype(np.float64); mus = np.pad(mus, (0, max(0, n - len(mus))))[:n]; mus /= np.abs(mus).max()
    g = np.full(n, 0.30)
    a, b = int((STAMP_T["jc"] - 0.4) * SR), int((STAMP_T["jc"] + 0.1) * SR); g[a:b] = np.linspace(0.30, 0.1, b - a); g[b:int((cs(23) + 0.6) * SR)] = 0.1
    c0 = int((cs(23) + 0.6) * SR); r = int(1.0 * SR); g[c0:c0 + r] = np.linspace(0.1, 0.3, r)
    hop = 1024; ve = np.array([np.abs(voice[i:i + hop]).max() for i in range(0, n, hop)]); dk = np.repeat((ve > 0.03).astype(float), hop)[:n]
    L = int(0.3 * SR); cs_ = np.concatenate([[0], np.cumsum(dk)]); i1 = np.clip(np.arange(n) + L // 2, 0, n); i0 = np.clip(np.arange(n) - L // 2, 0, n)
    g = g * (1 - 0.6 * np.clip((cs_[i1] - cs_[i0]) / L, 0, 1))
    fo = int(1.8 * SR); g[-fo:] *= np.linspace(1, 0, fo); g[:int(0.05 * SR)] *= np.linspace(0, 1, int(0.05 * SR))
    mix = np.tanh((voice + sfx * 0.8 + mus * g) * 1.05) * 0.9
    sf.write(path, np.stack([mix, np.roll(mix, 24)], 1).astype(np.float32), SR, subtype="PCM_16")

if __name__ == "__main__":
    print("sections", {k: (round(a, 2), round(b, 2)) for k, (a, b) in S.items()}, "stamps", {k: round(v, 2) for k, v in STAMP_T.items()}, "end", T_END)
    if A.frames:
        os.makedirs(f"{HERE}/qa", exist_ok=True)
        for s_ in A.frames.split(","):
            Image.fromarray(frame(float(s_))).save(f"{HERE}/qa/f_{float(s_):06.2f}.png")
        sys.exit()
    if not A.noaudio: build_audio(f"{HERE}/mix.wav")
    ff = subprocess.Popen(["nice", "-n", "10", "ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-movflags", "+faststart", f"{HERE}/video_only.mp4"], stdin=subprocess.PIPE)
    N = int(T_END * FPS)
    for fr in range(N):
        ff.stdin.write(frame(fr / FPS).tobytes())
        if fr % 150 == 0: print("frame", fr, "/", N, flush=True)
    ff.stdin.close(); ff.wait(); print("done", round(T_END, 2), "s")
