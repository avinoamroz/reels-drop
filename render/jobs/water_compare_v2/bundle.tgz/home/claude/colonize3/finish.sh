#!/bin/bash
# mux video_only.mp4 + mix.wav (two pass loudnorm -14 LUFS, 48 kHz), burn subtitles, web copy, contact sheet, cleanup
set -e
cd /home/claude/colonize3
J=$(ffmpeg -nostdin -hide_banner -i mix.wav -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g() { echo "$J" | python3 -c "import sys,json;print(json.load(sys.stdin)['$1'])"; }
LN="loudnorm=I=-14:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true"
nice -n 15 ffmpeg -nostdin -v error -y -i video_only.mp4 -i mix.wav -af "$LN" -ar 48000 -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart nosubs.mp4
SUB_BOTTOM=1600 nice -n 15 python3 /home/claude/cities/subs/make_subs.py nosubs.mp4 subs/subs_text.txt subs/segs_subs.json colonize3_v1.mp4
nice -n 15 ffmpeg -nostdin -v error -y -i colonize3_v1.mp4 -c:v libx264 -crf 26 -preset medium -pix_fmt yuv420p -c:a copy -movflags +faststart colonize3_v1_web.mp4
ls -la colonize3_v1.mp4 colonize3_v1_web.mp4
ffmpeg -nostdin -hide_banner -i colonize3_v1.mp4 -af ebur128 -f null - 2>&1 | grep -A1 "Integrated loudness" | tail -1
ffprobe -v error -show_entries stream=codec_name,sample_rate,width,height:format=duration -of compact colonize3_v1.mp4
mkdir -p qa/sheet_frames; rm -f qa/sheet_frames/*.png
for t in 0.0 2.0 6.0 9.6 11.8 16.0 18.6 20.4 24.0 26.5 28.3 32.5 35.5 37.8 41.0 43.5 46.0 48.5 51.5 55.0 57.5 60.0 62.0; do
  ffmpeg -nostdin -v error -y -ss $t -i colonize3_v1.mp4 -frames:v 1 -vf scale=390:-1 qa/sheet_frames/f_$t.png
done
python3 - <<'P'
import glob
from PIL import Image, ImageDraw
fs = sorted(glob.glob("/home/claude/colonize3/qa/sheet_frames/*.png"), key=lambda p: float(p.split("_")[-1][:-4]))
ims = [Image.open(f) for f in fs]; w, h = ims[0].size; cols = 6; rows = -(-len(ims) // cols)
S = Image.new("RGB", (cols * w, rows * (h + 30)), (10, 10, 10)); d = ImageDraw.Draw(S)
for i, (f, im) in enumerate(zip(fs, ims)):
    x, y = (i % cols) * w, (i // cols) * (h + 30); S.paste(im, (x, y + 30)); d.text((x + 8, y + 8), f.split("_")[-1][:-4] + " s", fill=(255, 255, 255))
S.save("/home/claude/colonize3/qa/sheet.png"); print("sheet", S.size)
P
rm -rf qa/sheet_frames subs_colonize3_v1 nosubs.mp4
