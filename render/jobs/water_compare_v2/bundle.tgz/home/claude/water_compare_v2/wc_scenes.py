"""Scenes for "Israel's water vs the neighbours" (@noamroz__). Region map (house gold land + Green Line, from
came_home_scenes), neighbours tinted as they are named, pipelines and drops animating. No photos, no faces.
Loaded through spec "scene_module"."""
import math, importlib.util
import numpy as np, cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, draw_emoji, flag_emoji
import kit
from kit import ease, ramp, lerp, St, sa, rr, circ, box

_sp = importlib.util.spec_from_file_location("came_home_scenes", "/home/claude/came_home/build/came_home_scenes.py")
CH = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(CH)

CHIP = "WATER VS THE NEIGHBOURS  |  מים מול השכנים"
def M(S, k, d=None): return S["times"].get(k, d if d is not None else S["t0"] + 0.4)
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))

def chip(c, t, S):
    a, s = PP(t, S["t0"], S); pill(c, CHIP, 32, 540, 245, P["gold"], P["white"], a, s, w=800)

def head(c, t, S, y=340, sz=62, hsz=44):
    a, s = PP(t, S["t0"] + 0.05, S); h = block_h(S["en"], sz, 900, 960, 2)
    block(c, S["en"], sz, 540, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=960, max_lines=2); y += h + 6
    if S.get("he"):
        a2, s2 = PP(t, S["t0"] + 0.15, S); hh = block_h(S["he"], hsz, 700, 960, 2)
        block(c, S["he"], hsz, 540, y + hh / 2, P["blue"], a2, s2, 700, maxw=960, max_lines=2); y += hh
    return y

def src(c, t, S, y=1500):
    s_ = S.get("source")
    if not s_: return
    a = fade_in(t, S["t0"] + 0.5, S)
    z, ls = RD.wrap(s_, 30, 700, 980, 2, 0.95)
    for k, l in enumerate(ls): T(c, l, z, 540, y + 38 * k, P["grey"], a, 1.0, 700, src=True, maxw=980)

def drop(c, x, y, r, col=None, a=1.0):
    """a water drop shape, tip up"""
    if a * St.a <= 0.01: return
    col = col or P["blue"]
    c.save(); c.translate(x, y)
    c.move_to(0, -r * 1.7); c.curve_to(r * 0.5, -r * 0.9, r, -r * 0.4, r, 0.1 * r)
    c.arc(0, 0.1 * r, r, 0, math.pi); c.curve_to(-r, -r * 0.4, -r * 0.5, -r * 0.9, 0, -r * 1.7); c.close_path()
    sa(c, col, a); c.fill_preserve(); sa(c, P["white"], 0.9 * a); c.set_line_width(2.5); c.stroke()
    sa(c, P["white"], 0.55 * a); c.arc(-r * 0.35, -r * 0.05, r * 0.22, 0, 2 * math.pi); c.fill()
    c.restore()

def stat_lines(c, t, S, rows, x, y, maxw, sz=38, hsz=32, gap=16, anchor_x=None):
    """rows: [(time, en, he, size)] stacked from y; returns y below"""
    for tm, en, he, z in rows:
        a, s = PP(t, tm, S)
        z = z or sz; hz = max(30, int(z * 0.84))
        h1 = block_h(en, z, 800, maxw, 3)
        if a > 0.01: block(c, en, z, x, y + h1 / 2, P["navy"], a, s, 800, hl=P["blue"], maxw=maxw, max_lines=3)
        y += h1 + 2
        if he:
            h2 = block_h(he, hz, 700, maxw, 3)
            if a > 0.01: block(c, he, hz, x, y + h2 / 2, P["gold_text"], a, s, 700, maxw=maxw, max_lines=3)
            y += h2
        y += gap
    return y

# ------------------------------------------------------------------ 1. hook: natural water per person (bars)
BARS = [("SY", "Syria", "סוריה", 920), ("LB", "Lebanon", "לבנון", 740), ("EG", "Egypt", "מצרים", 589),
        ("IL", "Israel", "ישראל", 214), (None, "Palestinians", "פלסטינים", 170), ("JO", "Jordan", "ירדן", 97)]
def sc_hook(c, t, S):
    chip(c, t, S); y = head(c, t, S, y=320, sz=64, hsz=46)
    a = 1.0; T(c, "Natural water per person, m³ a year", 34, 540, y + 40, P["grey"], a, 1, 800, maxw=960)
    T(c, "מים טבעיים מתחדשים לנפש, מ״ק בשנה", 32, 540, y + 84, P["grey"], a, 1, 700, maxw=960)
    y0 = y + 150; X0, XW = 380, 520
    grow = ease(min(1.0, 0.75 + t / 1.6))     # bars already most of the way at frame 0, settle by 0.4 s
    for k, (iso, en, he, v) in enumerate(BARS):
        yy = y0 + k * 108; isr = iso == "IL"
        if isr:   # Israel row highlight
            box(c, 60, yy - 50, 960, 100, 24, P["gold2"], 0.35 + 0.1 * math.sin(t * 3))
        if iso: draw_emoji(c, flag_emoji(iso), 100, yy, 56)
        else: drop(c, 100, yy + 10, 20)
        T(c, en, 38, 140, yy - 16, P["navy"], 1, 1, 900, anchor="l", maxw=230)
        T(c, he, 30, 140, yy + 24, P["gold_text"], 1, 1, 700, anchor="l", maxw=230)
        w = max(30, XW * v / 920 * grow); colr = P["gold"] if isr else P["blue"]
        box(c, X0, yy - 30, XW, 60, 30, P["silver"], 0.35)
        box(c, X0, yy - 30, w, 60, 30, colr, 1.0)
        # moving water shine inside the bar
        c.save(); rr(c, X0, yy - 30, w, 60, 30); c.clip()
        for j in range(4):
            sx = X0 + ((t * 160 + j * 170 + k * 40) % (XW + 200)) - 100
            g = cairo.LinearGradient(sx - 60, 0, sx + 60, 0); g.add_color_stop_rgba(0, 1, 1, 1, 0); g.add_color_stop_rgba(0.5, 1, 1, 1, 0.35 * St.a); g.add_color_stop_rgba(1, 1, 1, 1, 0)
            c.set_source(g); c.rectangle(sx - 60, yy - 30, 120, 60); c.fill()
        c.restore()
        T(c, f"{v}", 40, X0 + w + 14, yy + 2, P["gold_text"] if isr else P["navy"], 1, 1, 900, anchor="l", maxw=120)
    # a drop falls onto the Israel bar on a loop
    v_ = (t * 0.9) % 1.0; yI = y0 + 3 * 108
    drop(c, X0 + XW * 214 / 920 * 0.5, lerp(yI - 150, yI - 40, ease(v_)), 16, a=1 - 0.7 * v_)
    tq = M(S, "why", 3.5); a, s = PP(t, tq, S, bounce=2.4)
    yq = y0 + 6 * 108 + 10
    block(c, "So why are the *neighbours* running dry?", 50, 540, yq, P["navy"], a, s, 900, hl=P["red"], maxw=960, max_lines=2)
    T(c, "אז למה דווקא השכנים מתייבשים?", 40, 540, yq + 62, P["blue"], a, s, 700, maxw=960)
    src(c, t, S)

# ------------------------------------------------------------------ 2. Israel makes water
MAPB = (40, 470, 540, 1440); RX = 800; RW = 420
CAM_IL = CH.Cam(35.05, 31.45, 200, MAPB)
PLANTS = [(34.88, 32.47), (34.69, 31.93), (34.71, 31.99), (34.63, 31.82), (34.54, 31.66)]
CITIES = [(35.21, 31.77), (34.79, 31.25), (35.0, 32.79), (34.95, 30.6)]
def coast_waves(c, t, cam, box_):
    x0, y0, x1, y1 = box_
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    sa(c, P["blue"], 0.45); c.set_line_width(4)
    for k in range(5):
        off = (t * 40 + k * 26) % 140
        c.move_to(x0 + 10, y0 + 40)
        for yy in range(int(y0 + 40), int(y1 - 330), 16):
            lat = 33.2 - (yy - y0) / 970 * 4.2; xc, _ = cam.P(34.95 - (33.2 - lat) * 0.27, lat)
            c.line_to(xc - 40 - off * 0.6 + 6 * math.sin(yy / 25 + t * 3), yy)
        c.stroke()
    c.restore()
def pipe(c, t, cam, p0, p1, tm, lift=0.2, lw=10, col=None, dash=None, n=3, speed=0.6):
    u = ease(clamp((t - tm) / 1.0))
    if u <= 0.02: return
    a, b = cam.P(*p0), cam.P(*p1)
    CH.arrow(c, a, b, u, col or P["blue"], lift=lift, lw=lw, dash=dash)
    if u >= 1:
        for k in range(n):
            v = ((t * speed) + k / n) % 1.0; x, y = CH.arc_pt(a, b, v, lift)
            circ(c, x, y, lw * 0.75, P["white"], 0.95); circ(c, x, y, lw * 0.45, col or P["blue"], 1)

def sc_israel(c, t, S):
    chip(c, t, S); head(c, t, S, y=320)
    CH.map_frame(c, CAM_IL, box_=MAPB); coast_waves(c, t, CAM_IL, MAPB)
    c.save(); x0, y0, x1, y1 = MAPB; rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    for k, (lon, lat) in enumerate(PLANTS):
        a, s = PP(t, S["t0"] + 0.3 + 0.15 * k, S, bounce=2.4); x, y = CAM_IL.P(lon, lat)
        circ(c, x, y, 22 + 5 * math.sin(t * 5 + k), P["blue"], 0.25 * a); circ(c, x, y, 11 * s, P["navy"], a, stroke=P["white"], sw=3)
    for k, ((p0), (p1)) in enumerate(((PLANTS[2], CITIES[0]), (PLANTS[4], CITIES[1]), (PLANTS[0], CITIES[2]), (PLANTS[3], CITIES[3]))):
        pipe(c, t, CAM_IL, p0, p1, S["t0"] + 0.6 + 0.3 * k, lift=0.18, lw=8)
    c.restore()
    a, s = PP(t, S["t0"] + 0.5, S)
    pill(c, "6 desalination plants", 30, 200, 1330, P["white"], P["navy"], a, s, outline=P["blue"], w=800, padh=1.4)
    T(c, "6 מתקני התפלה", 30, 200, 1388, P["blue"], a, s, 700, maxw=300)
    # right column
    t8 = M(S, "eighty", S["t0"] + 1.0); u = ease(clamp((t - t8) / 1.1)); a, s = PP(t, t8, S)
    cy = 650; R = 115
    if a > 0.01:
        sa(c, P["silver"], 0.6 * a); c.set_line_width(26); c.arc(RX, cy, R, 0, 2 * math.pi); c.stroke()
        sa(c, P["blue"], a); c.set_line_cap(cairo.LINE_CAP_ROUND); c.arc(RX, cy, R, -math.pi / 2, -math.pi / 2 + 2 * math.pi * 0.8 * u); c.stroke()
        T(c, f"~{int(round(80 * u))}%", 70, RX, cy, P["navy"], a, s, 900)
    y = stat_lines(c, t, S, [(t8 + 0.2, "of drinking water is *desalinated* sea water", "ממי השתייה הם מי ים מותפלים", 34)], RX, cy + R + 30, RW)
    t9 = M(S, "ninety", t8 + 2.5); u9 = ease(clamp((t - t9) / 1.0)); a, s = PP(t, t9, S)
    y += 20
    if a > 0.01:
        T(c, f"~{int(round(90 * u9))}%", 64, RX - RW / 2, y + 30, P["green"], a, s, 900, anchor="l", maxw=200)
        draw_emoji(c, "♻️", RX + RW / 2 - 50, y + 30, 70, a, s)
        box(c, RX - RW / 2, y + 80, RW, 34, 17, P["silver"], 0.5 * a); box(c, RX - RW / 2, y + 80, max(34, RW * 0.9 * u9), 34, 17, P["green"], a)
    y = stat_lines(c, t, S, [(t9 + 0.2, "of sewage *recycled*, mostly for farms", "מהביוב ממוחזר, בעיקר לחקלאות", 34)], RX, y + 136, RW)
    # cost + tech chips
    for k, (en, he) in enumerate((("Sorek 2 bid: NIS 1.45 per m³", "שורק 2: 1.45 ₪ למ״ק"), ("Drip irrigation: Netafim, 1965", "השקיה בטפטוף: נטפים, 1965"))):
        tm = t9 + 0.9 + 0.5 * k; a, s = PP(t, tm, S)
        if a <= 0.01: continue
        yy = y + 16 + k * 118
        c.save(); c.translate(RX, yy + 50); c.scale(max(s, 1e-3), max(s, 1e-3)); old = St.a; St.a *= a
        shadow_box(c, -RW / 2, -52, RW, 104, 20, P["card"], stroke=P["gold"], sw=4); St.a = old; c.restore()
        T(c, en, 30, RX, yy + 30, P["navy"], a, s, 800, maxw=RW - 30)
        T(c, he, 30, RX, yy + 72, P["gold_text"], a, s, 700, maxw=RW - 30)
    src(c, t, S)

# ------------------------------------------------------------------ 3 to 7. the neighbours on the region map
NB_BOX = (55, 470, 1025, 1090)
def cam_of(v): return CH.Cam(v[0], v[1], v[2], NB_BOX)
def nb_cam(t, S):
    a = cam_of(S.get("cam_from") or S["cam"]); b = cam_of(S["cam"])
    return CH.cam_lerp(a, b, ease(clamp((t - S["t0"]) / 0.9)))
def polyline(c, cam, pts, col, lw, a=1.0, prog=1.0):
    if a * St.a <= 0.01 or prog <= 0.01: return
    pp = [cam.P(*p) for p in pts]; n = len(pp) - 1; m = prog * n
    c.save(); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pp[0])
    for k in range(1, n + 1):
        if k <= m: c.line_to(*pp[k])
        else:
            f = m - (k - 1); c.line_to(lerp(pp[k - 1][0], pp[k][0], f), lerp(pp[k - 1][1], pp[k][1], f)); break
    sa(c, P["white"], 0.9 * a); c.set_line_width(lw + 6); c.stroke_preserve(); sa(c, col, a); c.set_line_width(lw); c.stroke(); c.restore()
def along(pts, v):
    seg = [math.dist(a, b) for a, b in zip(pts, pts[1:])]; L = sum(seg); d = v * L
    for (a, b), s_ in zip(zip(pts, pts[1:]), seg):
        if d <= s_: f = d / max(1e-9, s_); return (lerp(a[0], b[0], f), lerp(a[1], b[1], f))
        d -= s_
    return pts[-1]
def label(c, t, tm, S, cam, lon, lat, en, he=None, dy=-40, col=None):
    a, s = PP(t, tm, S); x, y = cam.P(lon, lat)
    pill(c, en, 30, x, y + dy, P["white"], col or P["navy"], a, s, outline=col or P["blue"], w=800, padh=1.4)

EUPHRATES = [(38.6, 38.2), (38.33, 37.48), (38.0, 36.82), (38.3, 36.2), (39.0, 35.95), (40.15, 35.33), (40.9, 34.45)]
NILE = [(35.09, 11.21), (34.0, 12.8), (32.53, 15.6), (33.6, 18.0), (31.6, 20.6), (31.0, 22.0), (32.9, 24.09), (32.6, 26.2), (31.24, 30.04), (31.0, 31.4)]
def fx_jordan(c, t, S, cam):
    pipe(c, t, cam, (35.55, 32.7), (35.93, 31.95), S["t0"] + 0.5, lift=0.25, lw=10)
    pipe(c, t, cam, (35.0, 29.53), (35.93, 31.95), S["t0"] + 1.6, lift=0.12, lw=8, col=P["gold"], dash=[18, 14], n=2)
    label(c, t, S["t0"] + 0.9, S, cam, 35.93, 31.95, "Amman", dy=40)
    label(c, t, S["t0"] + 1.9, S, cam, 35.0, 29.53, "Aqaba", dy=40, col=P["gold_text"])
def fx_lebanon(c, t, S, cam):
    c.save(); x0, y0, x1, y1 = NB_BOX; rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    for k in range(26):   # rain over Lebanon
        lon = 35.2 + (k * 0.137) % 1.3; ph = (t * 1.3 + k * 0.37) % 1.0; lat = 34.9 - ph * 1.7 - (k % 3) * 0.05
        x, y = cam.P(lon, lat); sa(c, P["blue"], 0.75 * (1 - ph)); c.set_line_width(4); c.move_to(x, y); c.line_to(x - 6, y + 22); c.stroke()
    c.restore()
    x, y = cam.P(35.95, 33.85); a, s = PP(t, S["t0"] + 1.0, S, bounce=2.4)
    if a > 0.01:
        circ(c, x, y, 62 * s, P["white"], 0.95 * a, stroke=P["red"], sw=7); draw_emoji(c, "⚡", x, y, 70, a, s)
        sa(c, P["red"], a); c.set_line_width(8); c.move_to(x - 44 * s, y - 44 * s); c.line_to(x + 44 * s, y + 44 * s); c.stroke()
def fx_syria(c, t, S, cam):
    th = 22 - 12 * ease(clamp((t - S["t0"] - 0.8) / 1.6))
    polyline(c, cam, EUPHRATES, P["blue"], th, 1.0, prog=ease(clamp((t - S["t0"] - 0.2) / 1.0)))
    label(c, t, S["t0"] + 1.0, S, cam, 39.4, 35.7, "Euphrates", dy=-50)
    x, y = cam.P(38.33, 37.48); a, s = PP(t, S["t0"] + 1.3, S, bounce=2.4); draw_emoji(c, "🚧", x, y, 56, a, s)
    x, y = cam.P(37.2, 34.6); a, s = PP(t, S["t0"] + 0.6, S)
    draw_emoji(c, "☀️", x, y, 110 + 8 * math.sin(t * 3), a, s)
def fx_egypt(c, t, S, cam):
    polyline(c, cam, NILE, P["blue"], 12, 1.0, prog=ease(clamp((t - S["t0"] - 0.3) / 1.2)))
    if t > S["t0"] + 1.5:
        pp = [cam.P(*p) for p in NILE]
        for k in range(5):
            v = ((t * 0.25) + k / 5) % 1.0; x, y = along(pp, v); circ(c, x, y, 9, P["white"], 0.95); circ(c, x, y, 5, P["blue"], 1)
    x, y = cam.P(35.09, 11.21); a, s = PP(t, S["t0"] + 1.0, S, bounce=2.4)
    draw_emoji(c, "🚧", x, y - 10, 60, a, s); label(c, t, S["t0"] + 1.2, S, cam, 35.09, 11.21, "GERD dam, Ethiopia", dy=50, col=P["red"])
    label(c, t, S["t0"] + 0.8, S, cam, 31.24, 30.04, "Cairo", dy=40)
GAZA_IN = [(34.48, 31.52), (34.37, 31.41), (34.29, 31.31)]
GAZA_IL = [(34.62, 31.47), (34.50, 31.33), (34.40, 31.22)]
def fx_gaza(c, t, S, cam):
    x, y = cam.P(34.38, 31.42); a, s = PP(t, S["t0"] + 0.4, S)
    if a > 0.01:
        r = 120 + 12 * math.sin(t * 4)
        g = cairo.RadialGradient(x, y, 5, x, y, r); g.add_color_stop_rgba(0, *P["red"][:3], 0.55 * a * St.a); g.add_color_stop_rgba(1, *P["red"][:3], 0)
        c.set_source(g); c.arc(x, y, r, 0, 2 * math.pi); c.fill()
    for k, (p0, p1) in enumerate(zip(GAZA_IL, GAZA_IN)):
        pipe(c, t, cam, p0, p1, S["t0"] + 1.2 + 0.25 * k, lift=0.1, lw=9, n=2)
    label(c, t, S["t0"] + 0.5, S, cam, 34.30, 31.47, "Gaza", dy=-50, col=P["red"])
    label(c, t, S["t0"] + 2.0, S, cam, 34.66, 31.33, "3 Mekorot pipes", dy=60)
FX = dict(jordan=fx_jordan, lebanon=fx_lebanon, syria=fx_syria, egypt=fx_egypt, gaza=fx_gaza)

def sc_nb(c, t, S):
    chip(c, t, S)
    a, s = PP(t, S["t0"] + 0.05, S)
    if S.get("flag"): draw_emoji(c, flag_emoji(S["flag"]), 540 - 40 - kit.font(64, 900).getlength(RD.clean(S["en"]).replace("*", "")) / 2, 345, 64, a, s)
    T(c, S["en"], 64, 540 + (30 if S.get("flag") else 0), 345, P["navy"], a, s, 900, hl=P["blue"], maxw=900)
    a2, s2 = PP(t, S["t0"] + 0.15, S); T(c, S["he"], 44, 540, 412, P["blue"], a2, s2, 700, maxw=900)
    cam = nb_cam(t, S); tint = {}
    for iso in S.get("tint", []):
        tint[iso] = (P[S.get("tint_col", "amber")], 0.45 * ramp(t, S["t0"] + 0.2, S["t0"] + 0.7) + 0.05 * math.sin(t * 4))
    CH.map_frame(c, cam, tint=tint, box_=NB_BOX)
    c.save(); x0, y0, x1, y1 = NB_BOX; rr(c, x0, y0, x1 - x0, y1 - y0, 30); c.clip()
    FX[S["fx"]](c, t, S, cam)
    c.restore()
    # fact card
    rows = S["rows"]; ts = [M(S, f"r{k}", S["t0"] + 0.5 + 0.75 * k) for k in range(len(rows))]
    a, s = PP(t, ts[0] - 0.1, S)
    c.save(); c.translate(540, 1290); c.scale(1, max(s, 1e-3)); old = St.a; St.a *= a
    shadow_box(c, -485, -175, 970, 350, 26, P["card"], stroke=P["navy"], sw=5); St.a = old; c.restore()
    stat_lines(c, t, S, [(tm, en, he, z) for tm, (en, he, z) in zip(ts, rows)], 540, 1135, 920, gap=10)
    src(c, t, S)

# ------------------------------------------------------------------ 8. the fair line: West Bank water is disputed
def sc_dispute(c, t, S):
    chip(c, t, S); head(c, t, S, y=320)
    wb = ramp(t, S["t0"] + 0.3, S["t0"] + 0.9); CH.map_frame(c, CAM_IL, box_=MAPB, wb=wb)
    x, y = CAM_IL.P(35.25, 32.0); a, s = PP(t, S["t0"] + 0.6, S)
    pill(c, "West Bank", 30, x, y - 10, P["white"], P["navy"], a, s, outline=P["blue"], w=800, padh=1.4)
    T(c, "יהודה ושומרון", 30, x, y + 40, P["navy"], a, s, 700, maxw=300)
    cards = ((M(S, "bts", S["t0"] + 0.8), P["navy"], "B'TSELEM", "בצלם",
              [("Palestinians: *79 L* a day, Israelis: *287 L* (2014)", "פלסטינים: 79 ליטר ביום, ישראלים: 287"),
               ("Oslo II: 80% of the Mountain Aquifer to Israel", "אוסלו ב׳: 80% מאקוויפר ההר לישראל")]),
             (M(S, "isr", S["t0"] + 4.0), P["blue"], "ISRAEL", "ישראל",
              [("We supply *more* than Oslo requires", "אנחנו מספקים יותר ממה שאוסלו מחייב"),
               ("PA buys about double the agreed volume from Mekorot", "הרשות קונה ממקורות כפול מהכמות שסוכמה")]))
    for k, (tm, colr, lab, lab_he, lines) in enumerate(cards):
        a, s = PP(t, tm, S, bounce=1.8)
        if a <= 0.01: continue
        cy = 715 + k * 410; hh = 390
        c.save(); c.translate(RX, cy); c.scale(max(s, 1e-3), max(s, 1e-3)); old = St.a; St.a *= a
        shadow_box(c, -RW / 2 - 20, -hh / 2, RW + 40, hh, 26, P["card"], stroke=colr, sw=5)
        rr(c, -RW / 2 - 20, -hh / 2, RW + 40, 70, 26); c.save(); c.clip(); sa(c, colr); c.rectangle(-RW / 2 - 20, -hh / 2, RW + 40, 70); c.fill(); c.restore()
        T(c, f"{lab}  |  {lab_he}", 36, 0, -hh / 2 + 36, P["white"], 1, 1, 900, maxw=RW)
        y = -hh / 2 + 84
        for en, he in lines:
            h1 = block_h(en, 32, 800, RW, 3); block(c, en, 32, 0, y + h1 / 2, P["navy"], 1, 1, 800, hl=colr if k else P["blue"], maxw=RW, max_lines=3); y += h1 + 2
            h2 = block_h(he, 30, 700, RW, 2); block(c, he, 30, 0, y + h2 / 2, P["gold_text"], 1, 1, 700, maxw=RW, max_lines=2); y += h2 + 12
        St.a = old; c.restore()
    src(c, t, S)

# ------------------------------------------------------------------ 9. scorecard
SCORE = [("IL", "Israel", "ישראל", "214", "Sea water + recycling", "התפלה ומחזור", "green"),
         ("JO", "Jordan", "ירדן", "97", "Wells, Israel, desal by 2030", "בארות, ישראל, התפלה ב-2030", "amber"),
         ("LB", "Lebanon", "לבנון", "740", "Rivers, no power to pump", "נהרות בלי חשמל לשאיבה", "amber"),
         ("SY", "Syria", "סוריה", "920", "Drought, Euphrates cut", "בצורת, הפרת נחתך", "red"),
         ("EG", "Egypt", "מצרים", "589", "Nile 97%, dam upstream", "97% מהנילוס, סכר במעלה", "amber"),
         (None, "Palestinians", "פלסטינים", "170", "Gaza aquifer up to 97% unfit", "עד 97% מהאקוויפר בעזה פסול", "red")]
def sc_score(c, t, S):
    chip(c, t, S)
    a, s = PP(t, S["t0"] + 0.05, S)
    c.save(); c.translate(540, 370); c.scale(max(s, 1e-3), max(s, 1e-3)); old = St.a; St.a *= a
    shadow_box(c, -490, -85, 980, 170, 28, P["navy"], stroke=P["gold"], sw=5); St.a = old; c.restore()
    T(c, "Water is a *technology*", 50, 540, 345, P["white"], a, s, 900, hl=P["gold2"], maxw=920)
    T(c, "מים הם טכנולוגיה", 40, 540, 405, P["gold2"], a, s, 700, maxw=920)
    a = fade_in(t, S["t0"] + 0.3, S)
    T(c, "m³ per person", 30, 470, 500, P["grey"], a, 1, 800, maxw=200); T(c, "How it's going  |  המצב", 30, 780, 500, P["grey"], a, 1, 800, maxw=440)
    for k, (iso, en, he, v, st, st_he, colr) in enumerate(SCORE):
        tm = S["t0"] + 0.3 + 0.18 * k; a, s = PP(t, tm, S); yy = 580 + k * 140
        if a <= 0.01: continue
        c.save(); c.translate(540, yy); c.scale(max(s, 1e-3), max(s, 1e-3)); old = St.a; St.a *= a
        shadow_box(c, -485, -62, 970, 124, 22, P["card"], stroke=P["gold"] if iso == "IL" else P["border"], sw=4 if iso == "IL" else 2)
        St.a = old; c.restore()
        if iso: draw_emoji(c, flag_emoji(iso), 105, yy, 54, a, s)
        else: drop(c, 105, yy + 10, 18, a=a)
        T(c, en, 36, 150, yy - 18, P["navy"], a, s, 900, anchor="l", maxw=230)
        T(c, he, 30, 150, yy + 24, P["gold_text"], a, s, 700, anchor="l", maxw=230)
        T(c, v, 46, 470, yy, P["navy"], a, s, 900, maxw=150)
        circ(c, 585, yy, 14, P[colr], a)
        T(c, st, 30, 610, yy - 18, P["navy"], a, s, 800, anchor="l", maxw=400)
        T(c, st_he, 30, 610, yy + 24, P["gold_text"], a, s, 700, anchor="l", maxw=400)
    src(c, t, S, y=1440)

def sc_end(c, t, S):
    chip(c, t, S)
    a, s = PP(t, S["t0"] + 0.05, S, bounce=2.4)
    bob = 10 * math.sin(t * 3)
    draw_emoji(c, "🚰", 400, 620, 170, a, s); drop(c, 400 + 40, 760 + ((t * 120) % 120), 18, a=a * 0.9)
    draw_emoji(c, "🌊", 690, 640 + bob, 170, a, s)
    block(c, "Did you know where your *water* comes from?", 80, 540, 960, P["navy"], a, s, 900, hl=P["blue"], maxw=960, max_lines=3)
    a2, s2 = PP(t, S["t0"] + 0.25, S)
    T(c, "ידעתם מאיפה מגיעים המים שלכם?", 54, 540, 1130, P["blue"], a2, s2, 700, maxw=960)
    a3, s3 = PP(t, S["t0"] + 1.2, S)
    pill(c, "Follow @noamroz__", 44, 540, 1300, P["navy"], P["white"], a3, s3, w=900)
    T(c, "עקבו לעוד עובדות במפות", 38, 540, 1380, P["gold_text"], a3, s3, 700, maxw=900)
