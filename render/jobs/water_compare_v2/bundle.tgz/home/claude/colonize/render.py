#!/usr/bin/env python3
"""Colonize reel renderer: map intro ("Empires that spread" vs "What Jews did") + two character skit.

  python3 render.py                         estimated timing (word count), music + SFX only  -> colonize_v1.mp4
  python3 render.py --vo vo_v2/ --out colonize_v2.mp4   per line clips: N01_A.mp3..N07_A.mp3 (map narration), 01_A.mp3, 02_B.mp3 ... (dialogue)
                                            (.mp3 or .wav; any missing clip falls back to the word count estimate)
  python3 render.py --frames 0.5,4,12       save check frames to check/ and exit
  Two full takes instead of clips: python3 align.py --take A noam.mp3 --take B voiceB.mp3 --out vo/  then --vo vo/

Content: narration.json (map lines, Noam), dialogue.json (skit: speaker, text, he, optional bubble/cue). Facts: facts.json.
Hebrew is drawn with PIL + raqm (direction rtl), as in /home/claude/names/render.py.
"""
import os, sys, json, math, re, argparse, subprocess, functools
import numpy as np, cairo, soundfile as sf
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("--vo", default=None)
ap.add_argument("--out", default=os.path.join(HERE, "colonize_v1.mp4"))
ap.add_argument("--frames", default=None)
ap.add_argument("--wps", type=float, default=3.0, help="estimated words per second (dialogue)")
ap.add_argument("--nwps", type=float, default=2.85, help="estimated words per second (map narration)")
A = ap.parse_args()
NARR = json.load(open(os.path.join(HERE, "narration.json"), encoding="utf8"))
DLG = json.load(open(os.path.join(HERE, "dialogue.json"), encoding="utf8"))

W, H, FPS, SR = 1080, 1920, 30, 44100
CX = W / 2

# ------------------------------------------------------------------ helpers
def hx(h, a=1.0):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)
def ease(x): x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3
def eback(x):
    x = max(0.0, min(1.0, x)); c = 1.9; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))

@functools.lru_cache(None)
def FONT(w, s):
    return ImageFont.truetype(f"/tmp/claude-0/fonts/Heebo-{w}.ttf", s)

def is_he(s): return any("֐" <= ch <= "׿" for ch in s)

@functools.lru_cache(maxsize=4000)
def text_sprite(s, w, size, rgba):
    """PIL rendered text -> cairo surface (premultiplied BGRA). Hebrew drawn RTL via raqm."""
    f = FONT(w, size); kw = dict(direction="rtl", language="he") if is_he(s) else {}
    dd = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    l, t, r, b = dd.textbbox((0, 0), s, font=f, **kw)
    pad = 6; iw, ih = int(r - l + 2 * pad), int(size * 1.45 + 2 * pad)
    im = Image.new("RGBA", (max(1, iw), ih), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.text((pad - l, pad + size * 0.05), s, font=f, fill=tuple(int(c * 255) for c in rgba), **kw)
    a = np.array(im).astype(np.float32); al = a[..., 3:4] / 255.0
    bgra = np.dstack([a[..., 2:3] * al, a[..., 1:2] * al, a[..., 0:1] * al, a[..., 3:4]]).astype(np.uint8)
    stride = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, iw)
    buf = np.zeros((ih, stride // 4, 4), np.uint8); buf[:, :iw] = bgra
    surf = cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, iw, ih, stride)
    return surf, iw, ih, pad

def tw(s, w, size):
    kw = dict(direction="rtl", language="he") if is_he(s) else {}
    return ImageDraw.Draw(Image.new("RGBA", (4, 4))).textlength(s, font=FONT(w, size), **kw)

def text(ctx, s, x, y, w, size, col, al=1.0, anchor="c", scale=1.0):
    """draw text centred (anchor c), left (l) or right (r) at x; y is the vertical centre."""
    if al <= 0.01 or not s: return
    surf, iw, ih, pad = text_sprite(s, w, size, col)
    ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale)
    ox = {"c": -iw / 2, "l": -pad, "r": -iw + pad}[anchor]
    ctx.set_source_surface(surf, ox, -ih / 2); ctx.paint_with_alpha(al); ctx.restore()

def fit(s, w, size, maxw):
    while size > 18 and tw(s, w, size) > maxw: size -= 2
    return size

def wrap(s, w, size, maxw):
    words, lines, cur = s.split(), [], ""
    for wd in words:
        c = (cur + " " + wd).strip()
        if tw(c, w, size) <= maxw or not cur: cur = c
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    if len(lines) > 1:   # balance: shrink the width while the line count stays the same
        mw = maxw
        while mw > 200:
            t2 = wrap_greedy(s, w, size, mw - 20)
            if len(t2) != len(lines): break
            lines = t2; mw -= 20
    return lines

def wrap_greedy(s, w, size, maxw):
    words, lines, cur = s.split(), [], ""
    for wd in words:
        c = (cur + " " + wd).strip()
        if tw(c, w, size) <= maxw or not cur: cur = c
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines

def rrect(ctx, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    ctx.new_sub_path(); ctx.arc(x + w - r, y + r, r, -math.pi / 2, 0); ctx.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    ctx.arc(x + r, y + h - r, r, math.pi / 2, math.pi); ctx.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); ctx.close_path()

def surf_from_rgb(arr):
    h, w = arr.shape[:2]; stride = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.full((h, stride // 4, 4), 255, np.uint8); buf[:, :w, 0] = arr[..., 2]; buf[:, :w, 1] = arr[..., 1]; buf[:, :w, 2] = arr[..., 0]
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, stride)

# ------------------------------------------------------------------ audio clips and timing
def decode(path):
    p = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True)
    return np.frombuffer(p.stdout, np.float32).astype(np.float64)

def find_clip(stem):
    if not A.vo: return None
    for ext in (".mp3", ".wav", ".m4a"):
        p = os.path.join(A.vo, stem + ext)
        if os.path.exists(p): return p
    return None

def est(textline, wps):
    return len(textline.split()) / wps + 0.28 * textline.count("...") + 0.1

def envelope(x):
    hop = SR // FPS; n = len(x) // hop
    e = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2)) for i in range(n)]) if n else np.zeros(1)
    return np.clip(e / (np.percentile(e, 95) + 1e-6), 0, 1)

def make_line(item, stem, wps):
    p = find_clip(stem)
    if p:
        x = decode(p); return dict(item, clip=x, dur=len(x) / SR, env=envelope(x), real=True)
    return dict(item, clip=None, dur=est(item["text"], wps), env=None, real=False)

NL = [make_line(it, f"N{i + 1:02d}_{it['speaker']}", A.nwps) for i, it in enumerate(NARR)]
DL = [make_line(it, f"{i + 1:02d}_{it['speaker']}", A.wps) for i, it in enumerate(DLG)]

# map timeline ---------------------------------------------------------
HOOK = 0.95
t = 0.12; NL[0]["t0"] = t; t += NL[0]["dur"]
SEC = {}
def section(name, keys, start, mindur, lead=0.06, gap=0.18, tail=0.3):
    global t
    t = max(t + gap, start + lead)
    for k in keys:
        ln = NL[k]; ln["t0"] = t; t += ln["dur"] + gap
    end = max(t - gap + tail, start + mindur); SEC[name] = (start, end); return end
e = section("british", [1], HOOK, 3.2)
e = section("iberia", [2], e, 2.7)
e = section("arab", [3], e, 2.9)
J0 = e
e = section("jews", [4, 5, 6], e, 7.5, lead=0.15, gap=0.25, tail=1.5)
MAP_END = e

# skit timeline --------------------------------------------------------
BEAT = {"fail1": 0.7, "fail2": 0.7, "fail3": 0.7, "fail4": 0.7, "trombone": 1.7}
t = MAP_END + 0.4
EV = []   # (time, kind)
for i, ln in enumerate(DL):
    ln["t0"] = t; t += ln["dur"]; ln["t1"] = t
    cue = ln.get("cue", "")
    if cue.startswith("step"): EV.append((ln["t0"], cue))
    if cue == "book": EV.append((ln["t0"] + 0.45 * ln["dur"], "book"))
    if cue == "trombone": EV.append((ln["t0"] + 0.25, "zero"))
    if cue in BEAT:
        EV.append((t + 0.05, cue)); t += BEAT[cue]
    t += 0.3
    ln["slot_end"] = t
TOTAL = t + 1.3
for i, ln in enumerate(DL): ln["show_end"] = DL[i + 1]["t0"] if i + 1 < len(DL) else TOTAL
def ev_time(kind):
    for tt, k in EV:
        if k == kind: return tt
    return None
T_BOOK = ev_time("book"); T_SCR = ev_time("scratch"); T_TROM = ev_time("trombone"); T_ZERO = ev_time("zero")
T_SAD = next(l["t0"] for l in DL if l.get("cue") == "trombone")
T_STEP = {k: ev_time(f"step{k}") for k in range(1, 5)}; T_FAIL = {k: ev_time(f"fail{k}") for k in range(1, 5)}
T_WARM = next(l["t0"] for l in DL if l.get("cue") == "warm")
T_CTA = next(l["t0"] for l in DL if l.get("cue") == "cta")

# ------------------------------------------------------------------ map data
TOPO = "/home/claude/geo/package/countries-50m.json"
def merc(lat):
    lat = max(-85.0, min(85.0, lat)); return math.degrees(math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)))
def load_topo():
    tp = json.load(open(TOPO)); sc, tr = tp["transform"]["scale"], tp["transform"]["translate"]
    arcs = []
    for a in tp["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = []
    for g in tp["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        name = g["properties"]["name"]
        polys = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]
        for p in polys:
            ring = []
            for i in p[0]: ring.extend(arc(i))
            outp = [ring[0]]; off = 0.0
            for (x0, _), (x1, y1) in zip(ring, ring[1:]):
                if x1 - x0 > 180: off -= 360
                elif x0 - x1 > 180: off += 360
                outp.append((x1 + off, y1))
            for k in (-360, 0, 360): out.append((name, [(x + k, y) for x, y in outp]))
    return out
RINGS = load_topo()
NAMES = sorted({n for n, _ in RINGS}); NID = {n: i + 1 for i, n in enumerate(NAMES)}

OCEAN, LAND, BORD, COAST = hx("#0B1630"), hx("#24375A"), hx("#3A5079"), hx("#5573A3")

class View:
    def __init__(s, lon0, lon1, lat0, lat1, top):
        s.lon0, s.lon1, s.lat0, s.lat1 = lon0, lon1, lat0, lat1
        s.S = W / (lon1 - lon0); s.yt = merc(lat1); s.w = W; s.h = int((s.yt - merc(lat0)) * s.S); s.top = top
        polys = []
        for n, r in RINGS:
            a = np.array(r)
            if a[:, 0].max() < lon0 - 2 or a[:, 0].min() > lon1 + 2 or a[:, 1].max() < lat0 - 2 or a[:, 1].min() > lat1 + 2: continue
            pp = [s.P(x, y) for x, y in r]; ar = np.array(pp)
            area = abs(np.sum(ar[:-1, 0] * ar[1:, 1] - ar[1:, 0] * ar[:-1, 1])) / 2
            polys.append((area, n, pp))
        polys.sort(key=lambda q: -q[0]); s.polys = polys
        # base raster
        sf_ = cairo.ImageSurface(cairo.FORMAT_ARGB32, s.w, s.h); c = cairo.Context(sf_)
        c.set_source_rgba(*OCEAN); c.paint()
        c.set_source_rgba(1, 1, 1, 0.035); c.set_line_width(1)
        for lo in range(-180, 181, 15):
            x, _ = s.P(lo, 0); c.move_to(x, 0); c.line_to(x, s.h)
        for la in range(-75, 90, 15):
            _, y = s.P(0, la); c.move_to(0, y); c.line_to(s.w, y)
        c.stroke()
        for _, n, pp in polys: s._path(c, pp); c.set_source_rgba(*LAND); c.fill()
        c.set_line_width(1.0); c.set_line_join(cairo.LINE_JOIN_ROUND)
        for _, n, pp in polys: s._path(c, pp); c.set_source_rgba(*BORD); c.stroke()
        s.base = s._arr(sf_).astype(np.float32)
        # country id raster (nearest, drawn big first so enclaves survive)
        idim = Image.new("I", (s.w, s.h), 0); d = ImageDraw.Draw(idim)
        for _, n, pp in polys:
            if len(pp) > 2: d.polygon(pp, fill=NID[n])
        s.ids = np.array(idim, dtype=np.int32)
        yy, xx = np.mgrid[0:s.h, 0:s.w]; s.xx, s.yy = xx.astype(np.float32), yy.astype(np.float32)
    def P(s, lon, lat): return ((lon - s.lon0) * s.S, (s.yt - merc(lat)) * s.S)
    def _path(s, c, pp):
        c.move_to(*pp[0])
        for p in pp[1:]: c.line_to(*p)
        c.close_path()
    def _arr(s, sf_):
        sf_.flush(); a = np.ndarray((s.h, sf_.get_stride() // 4, 4), np.uint8, sf_.get_data())[:, :s.w]
        return a[..., [2, 1, 0]].copy()
    def coverage(s, names):
        sf_ = cairo.ImageSurface(cairo.FORMAT_ARGB32, s.w, s.h); c = cairo.Context(sf_)
        for _, n, pp in s.polys:
            if n in names: s._path(c, pp); c.set_source_rgba(1, 1, 1, 1); c.fill()
        sf_.flush(); a = np.ndarray((s.h, sf_.get_stride() // 4, 4), np.uint8, sf_.get_data())[:, :s.w, 3]
        return a.astype(np.float32) / 255

class Spread:
    """per pixel arrival time: country delay + distance from the country's entry point / speed"""
    def __init__(s, view, origin, delays, colors, speed=330.0, arcs=None):
        s.v = view; ox, oy = view.P(*origin); s.o = (ox, oy); s.colors = colors
        names = set(delays); s.cov = view.coverage(names)
        T = np.full((view.h, view.w), 1e9, np.float32); s.entry = {}
        Dor = np.hypot(view.xx - ox, view.yy - oy)
        colimg = np.zeros((view.h, view.w, 3), np.float32)
        for n, dl in delays.items():
            m = view.ids == NID[n]
            if not m.any(): continue
            idx = np.argmin(np.where(m, Dor, 1e9)); ey, ex = divmod(int(idx), view.w)
            s.entry[n] = (ex, ey, dl)
            T[m] = dl + np.hypot(view.xx[m] - ex, view.yy[m] - ey) / speed
            colimg[m] = np.array(colors.get(n, colors["_"])[:3]) * 255
        for _ in range(2):   # dilate to cover anti aliased edge pixels
            Tn = T.copy(); Cn = colimg.copy()
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                Ts = np.roll(np.roll(T, dy, 0), dx, 1); Cs = np.roll(np.roll(colimg, dy, 0), dx, 1)
                b = Ts < Tn; Tn[b] = Ts[b]; Cn[b] = Cs[b]
            T, colimg = Tn, Cn
        s.T, s.col = T, colimg
        s.arcs = arcs or []
    def frame(s, el):
        d = el - s.T
        a = s.cov * np.clip(d / 0.28, 0, 1) * 0.9
        front = s.cov * np.exp(-((d - 0.12) ** 2) / 0.012) * 0.55
        img = s.v.base * (1 - a[..., None]) + s.col * a[..., None]
        img = img + (255 - img) * front[..., None]
        return np.clip(img, 0, 255).astype(np.uint8)

R_ = lambda: hx("#E5484D")
WORLD = View(-130, 180, -50, 72, 470)
ARABV = View(-20, 80, 5, 55, 470)
JEWV = View(-80, 58, 4, 62, 470)

BRIT = {"United Kingdom": 0.0, "Ireland": 0.25, "Canada": 0.45, "Bahamas": 0.55, "Jamaica": 0.55, "Belize": 0.6, "Guyana": 0.6, "Trinidad and Tobago": 0.6,
        "India": 0.75, "Pakistan": 0.8, "Bangladesh": 0.8, "Sri Lanka": 0.85, "Myanmar": 0.95, "Malaysia": 1.05, "Singapore": 1.05,
        "Australia": 1.1, "New Zealand": 1.35, "South Africa": 1.15, "Botswana": 1.3, "Zimbabwe": 1.3, "Zambia": 1.35, "Malawi": 1.4, "Lesotho": 1.3, "eSwatini": 1.3, "Namibia": 1.45,
        "Kenya": 1.4, "Uganda": 1.45, "Tanzania": 1.45, "Sudan": 1.4, "S. Sudan": 1.45, "Egypt": 1.35, "Nigeria": 1.25, "Ghana": 1.2, "Sierra Leone": 1.15, "Gambia": 1.15,
        "Somaliland": 1.5, "Iraq": 1.6, "Jordan": 1.6, "Israel": 1.6, "Palestine": 1.6, "Papua New Guinea": 1.55, "Fiji": 1.6, "Cyprus": 1.5, "Malta": 1.45, "Falkland Is.": 1.3}
IBER = {"Spain": 0.0, "Portugal": 0.0, "Cuba": 0.35, "Dominican Rep.": 0.35, "Puerto Rico": 0.38, "Mexico": 0.5, "Guatemala": 0.6, "Honduras": 0.62, "El Salvador": 0.62, "Nicaragua": 0.65,
        "Costa Rica": 0.67, "Panama": 0.7, "Colombia": 0.72, "Venezuela": 0.75, "Ecuador": 0.8, "Peru": 0.85, "Bolivia": 0.95, "Chile": 1.0, "Paraguay": 1.05, "Argentina": 1.05, "Uruguay": 1.1,
        "Brazil": 0.55, "Philippines": 1.15}
ARAB = {"Saudi Arabia": 0.0, "Yemen": 0.15, "Oman": 0.15, "United Arab Emirates": 0.15, "Qatar": 0.15, "Bahrain": 0.15, "Kuwait": 0.2, "Iraq": 0.3, "Jordan": 0.3, "Israel": 0.32,
        "Palestine": 0.32, "Syria": 0.35, "Lebanon": 0.38, "Egypt": 0.45, "Iran": 0.55, "Libya": 0.7, "Azerbaijan": 0.8, "Armenia": 0.8, "Turkmenistan": 0.9, "Afghanistan": 1.0,
        "Tunisia": 0.95, "Algeria": 1.1, "Morocco": 1.3, "W. Sahara": 1.4, "Mauritania": 1.5, "Spain": 1.5, "Portugal": 1.6, "Uzbekistan": 1.5, "Tajikistan": 1.6, "Pakistan": 1.55, "Kyrgyzstan": 1.8}
C_BRIT, C_ESP, C_POR, C_ARAB = hx("#E5484D"), hx("#F5B700"), hx("#22C55E"), hx("#A855F7")
SP = {}
def spreads():
    if not SP:
        SP["british"] = Spread(WORLD, (-1.5, 52.5), {k: v + 0.15 for k, v in BRIT.items()}, {"_": C_BRIT}, speed=300)
        SP["iberia"] = Spread(WORLD, (-4.5, 40.0), {k: v + 0.15 for k, v in IBER.items()}, {"_": C_ESP, "Portugal": C_POR, "Brazil": C_POR}, speed=300)
        SP["arab"] = Spread(ARABV, (39.6, 24.5), {k: v + 0.15 for k, v in ARAB.items()}, {"_": C_ARAB}, speed=420)
    return SP

MAPINFO = {
    "british": dict(title="British Empire", sub="Peak around 1920", col=C_BRIT, view=WORLD,
                    chips=[("LAND TAKEN", "24% of Earth (1920)"), ("NAMES CHANGED", "Bombay, Rhodesia"), ("RELIGION", "Anglican missions"), ("LANGUAGE", "English")],
                    pins=[(72.8, 19.0, "Bombay", 0.95), (29.8, -18.0, "Rhodesia", 1.5)],
                    dots=["Canada", "India", "Australia", "South Africa", "Nigeria", "New Zealand", "Guyana"]),
    "iberia": dict(title="Spain & Portugal", sub="1500s to 1800s", col=C_ESP, view=WORLD,
                   chips=[("LAND TAKEN", "Most of the Americas"), ("NAMES CHANGED", "New Spain"), ("RELIGION", "Catholic missions"), ("LANGUAGE", "Spanish, Portuguese")],
                   pins=[(-101.0, 23.0, "New Spain", 0.8)],
                   dots=["Mexico", "Cuba", "Peru", "Argentina", "Brazil", "Philippines", "Colombia"]),
    "arab": dict(title="Early Arab conquests", sub="7th and 8th centuries", col=C_ARAB, view=ARABV,
                 chips=[("LAND TAKEN", "Spain to Central Asia"), ("NAMES CHANGED", "Jabal Tariq (Gibraltar)"), ("RELIGION", "Islam, over centuries"), ("LANGUAGE", "Arabic, over centuries")],
                 pins=[(-5.35, 36.1, "Jabal Tariq", 1.75)],
                 dots=["Egypt", "Iran", "Morocco", "Spain", "Uzbekistan", "Tunisia"]),
}
HEB_HEAD = {"british": "האימפריה הבריטית", "iberia": "ספרד ופורטוגל", "arab": "הכיבושים הערביים הראשונים", "jews": "העם היהודי: גלות ושיבה"}

def chip_row(ctx, chips, y0, col, t_list, el, mode="check"):
    cw, ch, gap = 478, 108, 20; x0 = (W - 2 * cw - gap) / 2
    for k, (cat, val) in enumerate(chips):
        a = ease((el - t_list[k]) / 0.25)
        if a <= 0: continue
        x = x0 + (k % 2) * (cw + gap); y = y0 + (k // 2) * (ch + gap) + (1 - a) * 18
        ctx.save(); rrect(ctx, x, y, cw, ch, 26); ctx.set_source_rgba(1, 1, 1, 0.08 * a); ctx.fill_preserve()
        ctx.set_source_rgba(col[0], col[1], col[2], 0.85 * a); ctx.set_line_width(3); ctx.stroke()
        cx_, cy_ = x + 50, y + ch / 2
        ctx.arc(cx_, cy_, 26, 0, 2 * math.pi)
        if mode == "check":
            ctx.set_source_rgba(col[0], col[1], col[2], a); ctx.fill()
            ctx.set_source_rgba(1, 1, 1, a); ctx.set_line_width(6); ctx.set_line_cap(cairo.LINE_CAP_ROUND)
            ctx.move_to(cx_ - 12, cy_ + 1); ctx.line_to(cx_ - 3, cy_ + 10); ctx.line_to(cx_ + 13, cy_ - 9); ctx.stroke()
        else:
            ctx.set_source_rgba(*hx("#8FD3FF", a)); ctx.fill()
            ctx.set_source_rgba(*hx("#0B1630", a)); ctx.set_line_width(6); ctx.set_line_cap(cairo.LINE_CAP_ROUND)
            ctx.move_to(cx_ - 10, cy_ - 10); ctx.line_to(cx_ + 10, cy_ + 10); ctx.move_to(cx_ + 10, cy_ - 10); ctx.line_to(cx_ - 10, cy_ + 10); ctx.stroke()
        ctx.restore()
        text(ctx, cat, x + 92, y + 32, 700, 24, hx("#AFC0DD"), a, "l")
        text(ctx, val, x + 92, y + 72, 800, fit(val, 800, 36, cw - 110), (1, 1, 1, 1), a, "l")

def map_header(ctx, head, title, sub, col, el, he=None):
    a = ease(el / 0.2)
    pw = tw(head, 800, 28) + 56
    rrect(ctx, CX - pw / 2, 190, pw, 54, 27); ctx.set_source_rgba(1, 1, 1, 0.1 * a); ctx.fill()
    text(ctx, head, CX, 217, 800, 28, hx("#DCE6F7"), a)
    text(ctx, title, CX, 305, 900, fit(title, 900, 84, 980), col, a, scale=0.92 + 0.08 * eback(el / 0.3))
    text(ctx, (sub + "   ·   " + he) if False else sub, CX, 385, 700, 40, hx("#C9D5EA"), ease((el - 0.15) / 0.25))
    if he: text(ctx, he, CX, 432, 700, 32, hx("#8DA2C6"), ease((el - 0.2) / 0.25))

def narr_caption(ctx, tt, y=1470):
    cur = None
    for ln in NL:
        if ln["t0"] - 0.05 <= tt <= ln["t0"] + ln["dur"] + 0.25: cur = ln
    if not cur or cur["key"] == "n7": return
    a = ease((tt - cur["t0"] + 0.05) / 0.15) * (1 - ease((tt - cur["t0"] - cur["dur"] - 0.05) / 0.2))
    lines = wrap(cur["text"], 800, 50, 940)
    for k, l in enumerate(lines): text(ctx, l, CX, y + k * 64, 800, 50, (1, 1, 1, 1), a)
    text(ctx, cur["he"], CX, y + len(lines) * 64 + 8, 700, 38, hx("#AFC0DD"), a)

def arc_pt(a, b, u, lift=0.22):
    mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2; dx, dy = b[0] - a[0], b[1] - a[1]
    cx_, cy_ = mx + dy * lift * 0.3, my - abs(dx) * lift - abs(dy) * 0.05
    x = (1 - u) ** 2 * a[0] + 2 * (1 - u) * u * cx_ + u * u * b[0]; y = (1 - u) ** 2 * a[1] + 2 * (1 - u) * u * cy_ + u * u * b[1]
    return x, y

def empire_frame(ctx, name, el, tt):
    info = MAPINFO[name]; sp = spreads()[name]; v = info["view"]
    ctx.set_source_rgba(*OCEAN); ctx.paint()
    img = sp.frame(el)
    ctx.set_source_surface(surf_from_rgb(img), 0, v.top); ctx.paint()
    ctx.save(); ctx.translate(0, v.top)
    # travelling dots from home to each region
    for n in info["dots"]:
        if n not in sp.entry: continue
        ex, ey, dl = sp.entry[n]; u = (el - (dl - 0.5)) / 0.5
        if 0 < u < 1.15:
            for k in range(8):
                uu = clamp(u - k * 0.04)
                if uu <= 0 or uu >= 1 and k > 0: continue
                x, y = arc_pt(sp.o, (ex, ey), min(1, uu)); ctx.arc(x, y, 7 - k * 0.7, 0, 2 * math.pi)
                ctx.set_source_rgba(1, 1, 1, (0.95 - k * 0.11) * (1 - clamp((u - 1) / 0.15))); ctx.fill()
    a = ease(el / 0.2); ox, oy = sp.o
    ctx.arc(ox, oy, 9 + 3 * math.sin(el * 8), 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, a); ctx.fill()
    for lon, lat, lab, t_ in info["pins"]:
        pa = ease((el - t_) / 0.25)
        if pa <= 0: continue
        x, y = v.P(lon, lat)
        ctx.arc(x, y, 7, 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, pa); ctx.fill()
        lw_ = tw(lab, 800, 30) + 30; bx = min(W - lw_ - 10, max(10, x - lw_ / 2)); by = y - 62
        rrect(ctx, bx, by, lw_, 44, 12); ctx.set_source_rgba(0.04, 0.07, 0.15, 0.88 * pa); ctx.fill()
        text(ctx, lab, bx + lw_ / 2, by + 22, 800, 30, (1, 1, 1, 1), pa)
    ctx.restore()
    map_header(ctx, "EMPIRES THAT SPREAD", info["title"], info["sub"], info["col"], el, HEB_HEAD[name])
    y0 = v.top + v.h + 34
    chip_row(ctx, info["chips"], y0, info["col"], [0.5, 0.9, 1.3, 1.7], el)

# jews section: exile from the Land of Israel, pushed on again, then everyone streams home ------------------
JER = (35.2, 31.8)
COMM = [("Babylon", 44.4, 32.5), ("Rome", 12.5, 41.9), ("Yemen", 44.2, 15.4), ("Spain", -4.0, 39.9),
        ("Morocco", -5.0, 34.0), ("England", -0.1, 51.5), ("Poland", 19.9, 50.1), ("Americas", -74.0, 40.7)]
PUSH = {"England": [(7.0, 50.0)], "Spain": [(-5.6, 33.2), (29.0, 41.0), (4.9, 52.4)]}
PUSHLAB = {"England": ("England 1290", 0, -64), "Spain": ("Spain 1492", -150, -6)}
def jtimes():
    s5, s6, s7 = (NL[k]["t0"] - J0 for k in (4, 5, 6)); d5, d6 = NL[4]["dur"], NL[5]["dur"]
    t_out0 = s5 + 0.38 * d5; span = max(1.0, (s6 + 0.45) - t_out0)
    td = {c[0]: t_out0 + k * span / (len(COMM) - 1) - 0.3 for k, c in enumerate(COMM)}
    return dict(s5=s5, s6=s6, s7=s7, t_out0=t_out0, td=td, push={"England": s6 + 0.42 * d6, "Spain": s6 + 0.68 * d6}, home=s7 + 0.05)
def arc_path(ctx, a, b, u, lift, n=28):
    ctx.move_to(*a)
    for k in range(1, n + 1): ctx.line_to(*arc_pt(a, b, u * k / n, lift))
def arrow(ctx, a, b, u, lift, col, al, lw=4):
    if u <= 0.02 or al <= 0.01: return
    ctx.save(); ctx.set_line_cap(cairo.LINE_CAP_ROUND); ctx.set_line_join(cairo.LINE_JOIN_ROUND)
    arc_path(ctx, a, b, u, lift); ctx.set_source_rgba(col[0], col[1], col[2], al); ctx.set_line_width(lw); ctx.stroke()
    p1 = arc_pt(a, b, u, lift); p0 = arc_pt(a, b, max(0, u - 0.04), lift); ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
    ctx.translate(*p1); ctx.rotate(ang); ctx.move_to(4, 0); ctx.line_to(-16, -10); ctx.line_to(-16, 10); ctx.close_path(); ctx.fill(); ctx.restore()
def pill(ctx, s, x, y, size, bg, fg, al, he=False):
    w_ = tw(s, 800, size) + size * 1.1; x = min(W - 12 - w_ / 2, max(12 + w_ / 2, x))
    rrect(ctx, x - w_ / 2, y - size * 0.8, w_, size * 1.6, size * 0.45); ctx.set_source_rgba(bg[0], bg[1], bg[2], bg[3] * al); ctx.fill()
    text(ctx, s, x, y, 800, size, fg, al)
BLUE = hx("#8FD3FF")
def jews_frame(ctx, el, tt):
    v = JEWV; ctx.set_source_rgba(*OCEAN); ctx.paint(); T = jtimes()
    s5, s6, s7, t_home = T["s5"], T["s6"], T["s7"], T["home"]
    img = v.base.copy()
    ia = ease((el - t_home - 0.8) / 0.5)          # Israel glows once everyone is back
    if ia > 0:
        if not hasattr(v, "isr"): v.isr = v.coverage({"Israel", "Palestine"})
        img = img * (1 - v.isr[..., None] * ia) + np.array([120, 200, 255]) * v.isr[..., None] * ia
    ctx.set_source_surface(surf_from_rgb(np.clip(img, 0, 255).astype(np.uint8)), 0, v.top); ctx.paint()
    ctx.save(); ctx.translate(0, v.top)
    J = v.P(*JER); hk = ease((el - t_home) / 1.1)
    # glow over the Land of Israel: bright at the start, again at the end
    ga = max(1 - ease((el - T["t_out0"] - 0.6) / 0.8), ia) * ease(el / 0.25)
    if ga > 0:
        g = cairo.RadialGradient(J[0], J[1], 4, J[0], J[1], 120 + 40 * ia); g.add_color_stop_rgba(0, 0.6, 0.86, 1, 0.75 * ga); g.add_color_stop_rgba(1, 0.6, 0.86, 1, 0)
        ctx.set_source(g); ctx.arc(J[0], J[1], 170, 0, 2 * math.pi); ctx.fill()
    arr_a = 1 - ease(hk / 0.4)
    dots, labs = [], []
    for k, (name, lon, lat) in enumerate(COMM):
        p = v.P(lon, lat); home = (J[0] + 17 * math.cos(k * 0.785 + 0.3), J[1] + 17 * math.sin(k * 0.785 + 0.3))
        u = (el - T["td"][name]) / 0.6
        if u <= 0: dots.append((home, 0.0)); continue
        arrow(ctx, J, p, min(1, ease(u)), 0.18, BLUE, 0.55 * arr_a)
        pos = arc_pt(home, p, min(1, ease(u)), 0.18)
        labs.append((name, p, ease((el - T["td"][name] - 0.5) / 0.25)))
        if name in PUSH and el > T["push"][name]:
            tp = T["push"][name]; kk = ease((el - tp - 0.25) / 0.7); red = clamp((el - tp) / 0.15)
            for lo2, la2 in PUSH[name]:
                q = v.P(lo2, la2); arrow(ctx, p, q, kk, 0.25, hx("#FF6B6B"), 0.85 * arr_a, 4)
                dots.append((arc_pt(p, q, kk, 0.25), red))
            labs.append((PUSHLAB[name], p, red))
            if kk < 0.05: dots.append((pos, red))
        else: dots.append((pos, 0.0))
    for p, red in dots:
        x, y = p
        if hk > 0: x, y = arc_pt(p, J, hk, 0.15)
        pulse = 1 + 0.15 * math.sin(el * 5 + x)
        ctx.arc(x, y, 20 * pulse, 0, 2 * math.pi); ctx.set_source_rgba(0.56, 0.83, 1, 0.22); ctx.fill()
        ctx.arc(x, y, 10, 0, 2 * math.pi); ctx.set_source_rgba(0.75 + 0.25 * red, 0.92 - 0.6 * red, 1 - 0.7 * red, 1); ctx.fill()
    la_all = 1 - ease(hk / 0.3)
    for lab, p, a in labs:
        if a <= 0 or la_all <= 0: continue
        if isinstance(lab, tuple):
            s, ox, oy = lab; pill(ctx, s, p[0] + ox, p[1] + oy, 30, (0.9, 0.2, 0.25, 0.95), (1, 1, 1, 1), a * la_all)
        else:
            lw2 = tw(lab, 800, 28) / 2 + 8; text(ctx, lab, min(W - lw2, max(lw2, p[0])), p[1] + 34, 800, 28, hx("#DCE6F7"), a * la_all)
    # exile label on the starting cluster
    ea = ease((el - s5 - 0.1) / 0.25) * (1 - ease((el - T["t_out0"] - 0.9) / 0.3))
    if ea > 0: pill(ctx, "586 BCE · 70 CE: exile", J[0] - 60, J[1] + 78, 32, (0.04, 0.07, 0.15, 0.9), (1, 1, 1, 1), ea)
    if ia > 0:
        r = 30 + 40 * (1 - ia); ctx.arc(J[0], J[1], r, 0, 2 * math.pi); ctx.set_source_rgba(1, 1, 1, 0.85 * ia); ctx.set_line_width(4); ctx.stroke()
        text(ctx, "Israel", J[0] - 44, J[1] + 50, 900, 34, (1, 1, 1, 1), ia, "r")
        pill(ctx, "הביתה · Home", J[0] - 30, J[1] - 78, 38, (1, 1, 1, 0.95), hx("#0B1630"), ia)
    ctx.restore()
    map_header(ctx, "WHAT HAPPENED TO THE JEWS", "The Jewish people", "Exile, then return", BLUE, el, HEB_HEAD["jews"])
    y0 = v.top + v.h + 34
    if el < s7 + 0.1:
        fade = 1 - ease((el - s7 + 0.1) / 0.2)
        chips = [("EXILED.", "Then returned."), ("CONVERTED", "No one"), ("KEPT", "Hebrew prayers"), ("EXPELLED", "England, Spain...")]
        ctx.push_group(); chip_row(ctx, chips, y0, BLUE, [s5 + 0.4, s6, s6 + 0.35, T["push"]["England"]], el, mode="x"); ctx.pop_group_to_source(); ctx.paint_with_alpha(fade)
    else:
        ln = NL[6]; a = ease((el - s7) / 0.22)
        text(ctx, ln["text"], CX, y0 + 40, 800, fit(ln["text"], 800, 60, 980), (1, 1, 1, 1), a)
        text(ctx, ln["he"], CX, y0 + 108, 700, 42, hx("#AFC0DD"), a)
        ha = (el - t_home - 0.75) / 0.3
        text(ctx, "Home", CX, y0 + 270, 900, 170, BLUE, ease(ha), scale=0.85 + 0.15 * eback(ha))
        text(ctx, "הביתה", CX, y0 + 420, 900, 100, (1, 1, 1, 1), ease(ha - 0.4), scale=0.85 + 0.15 * eback(ha - 0.4))

def hook_frame(ctx, el):
    v = WORLD; ctx.set_source_rgba(*hx("#B91C1C")); ctx.paint()
    ctx.set_source_surface(surf_from_rgb(v.base.astype(np.uint8)), 0, 700); ctx.paint_with_alpha(0.28)
    text(ctx, "This is what", CX, 790, 900, 112, (1, 1, 1, 1))
    text(ctx, "colonization", CX, 920, 900, 124, hx("#FFE066"))
    text(ctx, "looks like.", CX, 1050, 900, 112, (1, 1, 1, 1))
    text(ctx, NL[0]["he"], CX, 1170, 700, 52, hx("#FFD9D9"))

# ------------------------------------------------------------------ skit
SKY0, SKY1 = hx("#FFE3B8"), hx("#FFC9A3")
def skit_bg():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *hx("#BFE3FF")); g.add_color_stop_rgba(0.55, *hx("#FFE7C2")); g.add_color_stop_rgba(1, *hx("#FFD2A6"))
    c.set_source(g); c.paint()
    c.arc(880, 560, 120, 0, 2 * math.pi); c.set_source_rgba(*hx("#FFD166", 0.55)); c.fill()
    # skyline silhouette (generic low rise city)
    c.set_source_rgba(*hx("#F4B183", 0.75)); x = -20; rng = np.random.default_rng(5)
    while x < W:
        bw = int(rng.integers(70, 150)); bh = int(rng.integers(120, 330)); c.rectangle(x, 1560 - bh, bw - 8, bh + 10); x += bw
    c.fill()
    c.rectangle(0, 1560, W, H - 1560); c.set_source_rgba(*hx("#E9A06B")); c.fill()
    c.rectangle(0, 1560, W, 10); c.set_source_rgba(*hx("#D98957")); c.fill()
    # halftone dots
    c.set_source_rgba(1, 1, 1, 0.16)
    for yy in range(80, 1500, 46):
        for xx in range(20 + (yy // 46 % 2) * 23, W, 46):
            r = 3.2 * (1 - yy / 1600); c.arc(xx, yy, max(0.5, r), 0, 2 * math.pi); c.fill()
    return s
BG = None

CHAR = {"A": dict(x=300, skin=hx("#F2C9A1"), shirt=hx("#2F6FE4"), shirt2=hx("#2457B8"), hair=hx("#4A2E1E"), pants=hx("#26324A"), cap=hx("#E8473C"), name="A"),
        "B": dict(x=785, skin=hx("#D9A17A"), shirt=hx("#F28C28"), shirt2=hx("#D06F12"), hair=hx("#1F1A17"), pants=hx("#3B3349"), kippah=hx("#1D4ED8"), name="B")}
GROUND = 1790
def limb(c, pts, w, col):
    c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0])
    if len(pts) == 3: c.curve_to(pts[1][0], pts[1][1], pts[1][0], pts[1][1], pts[2][0], pts[2][1])
    else: c.line_to(*pts[1])
    c.set_source_rgba(*col); c.stroke()

def draw_char(c, who, st):
    p = CHAR[who]; x = p["x"] + st.get("dx", 0); bob = st.get("bob", 0); slump = st.get("slump", 0)
    face = 1 if who == "A" else -1           # looks toward the other character
    hy = GROUND - 500 + bob + slump * 18; ty = GROUND - 365 + bob * 0.6 + slump * 10
    OUT = (0.12, 0.1, 0.12, 1)
    # shadow
    c.save(); c.translate(x, GROUND + 8); c.scale(1, 0.22); c.arc(0, 0, 150, 0, 2 * math.pi); c.restore(); c.set_source_rgba(0, 0, 0, 0.12); c.fill()
    # legs + shoes
    for sgn in (-1, 1):
        limb(c, [(x + sgn * 45, ty + 200), (x + sgn * 50, GROUND - 30)], 54, p["pants"])
        c.save(); c.translate(x + sgn * 58, GROUND - 16); c.scale(1.6, 1); c.arc(0, 0, 26, 0, 2 * math.pi); c.restore(); c.set_source_rgba(*hx("#2B2B33")); c.fill()
    # torso
    tw_, bw_ = 92, 112
    c.move_to(x - tw_, ty + 8); c.curve_to(x - tw_ - 10, ty + 120, x - bw_, ty + 170, x - bw_ + 8, ty + 228)
    c.line_to(x + bw_ - 8, ty + 228); c.curve_to(x + bw_, ty + 170, x + tw_ + 10, ty + 120, x + tw_, ty + 8)
    c.curve_to(x + 50, ty - 22, x - 50, ty - 22, x - tw_, ty + 8); c.close_path()
    c.set_source_rgba(*p["shirt"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(5); c.stroke()
    if who == "A":   # hoodie pocket + strings
        rrect(c, x - 58, ty + 130, 116, 62, 18); c.set_source_rgba(*p["shirt2"]); c.fill()
        for s_ in (-1, 1): limb(c, [(x + s_ * 22, ty + 10), (x + s_ * 24, ty + 70)], 5, (1, 1, 1, 0.9))
    else:            # sweater stripe
        c.rectangle(x - 104, ty + 120, 208, 22); c.set_source_rgba(*hx("#FFFFFF", 0.85)); c.fill()
    # arms
    pose = st.get("pose", "down"); sh = ty + 40; t_ = st.get("t", 0)
    for sgn in (-1, 1):
        sx = x + sgn * (tw_ - 6)
        if pose == "book" and sgn == face:
            e = (sx + sgn * 40, sh + 90); hnd = (x + sgn * 30, sh + 120)
        elif pose == "wave" and sgn == -face:
            wv = math.sin(t_ * 9) * 22; e = (sx + sgn * 70, sh - 40); hnd = (sx + sgn * 90 + wv, sh - 140)
        elif pose == "shrug":
            e = (sx + sgn * 70, sh + 70); hnd = (sx + sgn * 105, sh + 10)
        elif pose == "point" and sgn == face:
            e = (sx + sgn * 70, sh + 50); hnd = (sx + sgn * 140, sh + 30)
        else:
            sw = math.sin(t_ * 2 + sgn) * 4; e = (sx + sgn * 26, sh + 100); hnd = (sx + sgn * 30 + sw, sh + 190)
        limb(c, [(sx, sh), e, hnd], 46, OUT); limb(c, [(sx, sh), e, hnd], 36, p["shirt"])
        c.arc(hnd[0], hnd[1], 24, 0, 2 * math.pi); c.set_source_rgba(*p["skin"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(4); c.stroke()
    if pose == "book":   # small red handbook in hand
        bx = x + face * 30; c.save(); c.translate(bx, sh + 95); c.rotate(-0.15 * face)
        rrect(c, -48, -36, 96, 70, 8); c.set_source_rgba(*hx("#C62828")); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(4); c.stroke()
        c.rectangle(-30, -16, 60, 8); c.set_source_rgba(1, 0.9, 0.6, 1); c.fill(); c.restore()
    # neck + head
    c.rectangle(x - 26, hy + 80, 52, 50); c.set_source_rgba(*p["skin"]); c.fill()
    tilt = st.get("tilt", 0); c.save(); c.translate(x, hy); c.rotate(tilt)
    R = 108
    # ears
    for sgn in (-1, 1):
        c.arc(sgn * (R - 4), 12, 22, 0, 2 * math.pi); c.set_source_rgba(*p["skin"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(4); c.stroke()
    if who == "B":   # curly hair behind
        for ang in np.linspace(math.pi * 1.05, math.pi * 1.95, 9):
            c.arc(math.cos(ang) * (R - 6), math.sin(ang) * (R - 10) - 6, 36, 0, 2 * math.pi); c.set_source_rgba(*p["hair"]); c.fill()
    c.save(); c.scale(1, 1.04); c.arc(0, 0, R, 0, 2 * math.pi); c.restore()
    c.set_source_rgba(*p["skin"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(5); c.stroke()
    if who == "A":   # cap
        c.move_to(-R - 2, -18); c.curve_to(-R + 6, -R - 52, R - 6, -R - 52, R + 2, -18); c.close_path()
        c.set_source_rgba(*p["cap"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(5); c.stroke()
        c.move_to(face * 10, -30); c.curve_to(face * 90, -46, face * 170, -34, face * 182, -18); c.curve_to(face * 120, -6, face * 40, -10, face * 10, -18); c.close_path()
        c.set_source_rgba(*hx("#B8322A")); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(4); c.stroke()
        c.arc(0, -R - 6, 9, 0, 2 * math.pi); c.set_source_rgba(*hx("#B8322A")); c.fill()
        for sgn in (-1, 1):
            c.move_to(sgn * (R - 4), -18); c.curve_to(sgn * (R + 4), 0, sgn * (R - 6), 18, sgn * (R - 18), 22); c.set_source_rgba(*p["hair"]); c.set_line_width(14); c.stroke()
    else:            # front curls + kippah
        for xx in np.linspace(-70, 70, 6):
            c.arc(xx, -R + 18 + abs(xx) * 0.12, 28, 0, 2 * math.pi); c.set_source_rgba(*p["hair"]); c.fill()
        c.save(); c.translate(-18, -R + 2); c.rotate(-0.12); c.scale(1, 0.42); c.arc(0, 0, 52, math.pi, 2 * math.pi); c.close_path(); c.restore()
        c.set_source_rgba(*p["kippah"]); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(4); c.stroke()
        c.save(); c.translate(-18, -R + 2); c.rotate(-0.12); c.scale(1, 0.42); c.arc(0, 0, 40, math.pi * 1.1, math.pi * 1.9); c.restore()
        c.set_source_rgba(1, 1, 1, 0.9); c.set_line_width(4); c.stroke()
    expr = st.get("expr", "happy"); talk = st.get("talk", 0); blink = st.get("blink", 0)
    lx = face * 8
    # eyes
    for sgn in (-1, 1):
        ex, ey = sgn * 38 + lx, -8
        c.save(); c.translate(ex, ey); c.scale(1, max(0.12, 1 - blink)); c.arc(0, 0, 12 if expr != "shock" else 15, 0, 2 * math.pi); c.restore()
        c.set_source_rgba(*OUT); c.fill()
        if blink < 0.5: c.arc(ex + 4, ey - 5, 4, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, 1); c.fill()
    if who == "B":   # round glasses
        for sgn in (-1, 1):
            c.arc(sgn * 38 + lx, -8, 31, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, 0.18); c.fill_preserve(); c.set_source_rgba(*OUT); c.set_line_width(6); c.stroke()
        c.move_to(-8 + lx, -12); c.curve_to(-3 + lx, -18, 3 + lx, -18, 8 + lx, -12); c.stroke()
        for sgn in (-1, 1): c.move_to(sgn * 69 + lx, -12); c.line_to(sgn * (R - 4), -18); c.stroke()
    # brows
    c.set_line_width(7); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_source_rgba(*p["hair"])
    for sgn in (-1, 1):
        bx, by = sgn * 38 + lx, -48 - (8 if who == "B" else 0)
        if expr == "sad": c.move_to(bx - 16, by + (sgn * -8) + 4); c.line_to(bx + 16, by + (sgn * 8) + 4)
        elif expr == "confused": c.move_to(bx - 16, by - (12 if sgn == face else -2)); c.line_to(bx + 16, by - (4 if sgn == face else 4))
        elif expr in ("oops", "shock"): c.move_to(bx - 16, by - 12); c.line_to(bx + 16, by - 12)
        else: c.move_to(bx - 16, by + 2); c.curve_to(bx - 6, by - 8, bx + 6, by - 8, bx + 16, by + 2)
        c.stroke()
    # cheeks
    for sgn in (-1, 1): c.arc(sgn * 66 + lx, 30, 16, 0, 2 * math.pi); c.set_source_rgba(1, 0.45, 0.45, 0.22); c.fill()
    # mouth
    mx, my = lx, 50
    if talk > 0.05:
        hh = 10 + 30 * talk; ww = 34 - 6 * talk
        c.save(); c.translate(mx, my); c.scale(1, hh / ww); c.arc(0, 0, ww, 0, 2 * math.pi); c.restore()
        c.set_source_rgba(*hx("#5A1A1F")); c.fill()
        c.save(); c.translate(mx, my + hh * 0.45); c.scale(1, 0.45); c.arc(0, 0, ww * 0.6, 0, 2 * math.pi); c.restore(); c.set_source_rgba(*hx("#E86A6A")); c.fill()
    else:
        c.set_source_rgba(*OUT); c.set_line_width(6)
        if expr == "sad": c.move_to(mx - 26, my + 12); c.curve_to(mx - 10, my - 6, mx + 10, my - 6, mx + 26, my + 12); c.stroke()
        elif expr == "confused": c.arc(mx + 10 * face, my + 4, 9, 0, 2 * math.pi); c.stroke()
        elif expr == "oops": c.move_to(mx - 26, my + 4); c.curve_to(mx - 10, my - 6, mx + 6, my + 12, mx + 26, my); c.stroke()
        elif expr == "shock": c.arc(mx, my + 6, 14, 0, 2 * math.pi); c.set_source_rgba(*hx("#5A1A1F")); c.fill()
        else: c.move_to(mx - 30, my - 2); c.curve_to(mx - 14, my + 22, mx + 14, my + 22, mx + 30, my - 2); c.stroke()
    c.restore()
    if expr == "sad" and st.get("sweat", 0) > 0:
        c.arc(x + face * -96, hy - 40 + st["sweat"] * 30, 10, 0, 2 * math.pi); c.set_source_rgba(0.45, 0.75, 1, 0.9); c.fill()

STEPS = [("Rule a foreign land", "לשלוט בארץ זרה"), ("Convert the locals", "להמיר את המקומיים"),
         ("Replace their language", "להחליף להם את השפה"), ("Send the riches home", "לשלוח את העושר הביתה")]
BK = dict(x=70, y=628, w=940, h=500)
INK = (0.12, 0.1, 0.12, 1)
def handbook(ctx, tt):
    if T_BOOK is None or tt < T_BOOK - 0.1: return
    k = eback((tt - T_BOOK + 0.1) / 0.45); out = ease((tt - T_WARM) / 0.35) if tt > T_WARM else 0
    if out >= 1: return
    x, y, w, h = BK["x"], BK["y"] + (1 - k) * 900 + out * 60, BK["w"], BK["h"]
    ctx.save(); ctx.translate(x + w / 2, y + h / 2); ctx.rotate(-0.012 * (1 - out)); ctx.translate(-w / 2, -h / 2)
    ctx.push_group()
    rrect(ctx, 0, 18, w, h, 40); ctx.set_source_rgba(0, 0, 0, 0.13); ctx.fill()
    rrect(ctx, 0, 0, w, h, 40); ctx.set_source_rgba(1, 1, 1, 0.97); ctx.fill()
    text(ctx, "COLONIZER HANDBOOK", 48, 58, 900, 44, hx("#C62828"), 1, "l")
    text(ctx, "המדריך לקולוניאליסט", w - 48, 60, 700, 32, (0.55, 0.5, 0.52, 1), 1, "r")
    ctx.rectangle(48, 100, w - 96, 3); ctx.set_source_rgba(0, 0, 0, 0.08); ctx.fill()
    for i, (s, he) in enumerate(STEPS):
        ry = 118 + i * 94; st_ = T_STEP.get(i + 1); fl = T_FAIL.get(i + 1)
        active = st_ is not None and tt >= st_ and (fl is None or tt < fl + 0.4)
        if active:
            hl = ease((tt - st_) / 0.25); rrect(ctx, 28, ry, (w - 56) * hl, 90, 22); ctx.set_source_rgba(1, 0.86, 0.3, 0.45); ctx.fill()
        done = fl is not None and tt >= fl
        bx, by = 52, ry + 17
        rrect(ctx, bx, by, 56, 56, 14); ctx.set_source_rgba(*INK); ctx.set_line_width(5); ctx.stroke()
        lab = f"{i + 1}. {s}"; ink = (0.6, 0.56, 0.58, 1) if done else INK
        text(ctx, lab, 136, ry + 30, 800, 44, ink, 1, "l")
        text(ctx, he, 140, ry + 70, 700, 27, (0.5, 0.47, 0.5, 1), 1, "l")
        if done:
            u = (tt - fl) / 0.2
            if u > 0.4:
                ctx.set_source_rgba(*hx("#E11D2E", 0.8)); ctx.set_line_width(5)
                ctx.move_to(136, ry + 32); ctx.line_to(136 + (tw(lab, 800, 44) + 4) * ease((u - 0.4) / 0.6), ry + 32); ctx.stroke()
            sc = 1 + 0.9 * (1 - ease(u)); al = clamp(u * 3)
            ctx.save(); ctx.translate(bx + 28, by + 28); ctx.scale(sc, sc); ctx.rotate(-0.08)
            ctx.set_line_cap(cairo.LINE_CAP_ROUND); ctx.set_source_rgba(*hx("#E11D2E", 0.95 * al)); ctx.set_line_width(17)
            ctx.move_to(-40, -40); ctx.line_to(40, 40); ctx.move_to(40, -40); ctx.line_to(-40, 40); ctx.stroke(); ctx.restore()
    if T_ZERO and tt > T_ZERO:   # 0 / 4 stamp
        u = (tt - T_ZERO) / 0.3; sc = 1 + 1.4 * (1 - ease(u)); al = clamp(u * 3)
        ctx.save(); ctx.translate(w / 2 + 120, h / 2 + 40); ctx.rotate(-0.16); ctx.scale(sc, sc)
        rrect(ctx, -190, -90, 380, 180, 24); ctx.set_source_rgba(1, 1, 1, 0.85 * al); ctx.fill_preserve()
        ctx.set_source_rgba(*hx("#E11D2E", 0.95 * al)); ctx.set_line_width(12); ctx.stroke()
        text(ctx, "0 / 4", 0, 4, 900, 130, hx("#E11D2E"), al); ctx.restore()
    ctx.pop_group_to_source(); ctx.paint_with_alpha(1 - out); ctx.restore()

def cta_card(ctx, tt):
    if tt < T_CTA - 0.1: return
    a = ease((tt - T_CTA + 0.1) / 0.35); y = 680 + (1 - eback((tt - T_CTA + 0.1) / 0.45)) * 80
    rrect(ctx, 110, y + 16, 860, 420, 48); ctx.set_source_rgba(0, 0, 0, 0.12 * a); ctx.fill()
    rrect(ctx, 110, y, 860, 420, 48); ctx.set_source_rgba(1, 1, 1, 0.97 * a); ctx.fill()
    text(ctx, "FOLLOW", CX, y + 64, 800, 30, (0.5, 0.47, 0.5, 1), a)
    text(ctx, "Noam Roz", CX, y + 150, 900, 104, INK, a)
    text(ctx, "נועם רז", CX, y + 240, 700, 48, (0.42, 0.4, 0.46, 1), a)
    rrect(ctx, CX - 280, y + 296, 560, 92, 46); ctx.set_source_rgba(*hx("#2F6FE4", a)); ctx.fill()
    text(ctx, "@noamroz__", CX, y + 342, 900, 50, (1, 1, 1, 1), a)

def bubble(ctx, ln, tt):
    who = ln["speaker"]; p = CHAR[who]; col = CHAR[who]["shirt"]
    a = eback((tt - ln["t0"] + 0.08) / 0.22); fa = 1 - ease((tt - ln["show_end"] + 0.12) / 0.12)
    if a <= 0 or fa <= 0: return
    s = ln.get("bubble", ln["text"]); size = 80
    while True:
        lines = wrap(s, 900, size, 840)
        if len(lines) <= 2 or size <= 60: break
        size -= 4
    he_size = 44; he_lines = wrap(ln["he"], 700, he_size, 840)
    bw = max(max(tw(l, 900, size) for l in lines), max(tw(l, 700, he_size) for l in he_lines)) + 110; bw = min(980, max(480, bw))
    lh = size * 1.12; bh = len(lines) * lh + len(he_lines) * 56 + 96
    bx = CX - bw / 2 + (-40 if who == "A" else 40); bx = max(50, min(W - 50 - bw, bx)); by = 215
    hx_ = p["x"] + (40 if who == "A" else -40)
    ctx.save(); ctx.translate(bx + bw / 2, by + bh); ctx.scale(a * fa, a * fa); ctx.translate(-(bx + bw / 2), -(by + bh))
    tip = (hx_, by + bh + 52)
    def shape():
        rrect(ctx, bx, by, bw, bh, 44)
        b0 = min(max(hx_ - 50, bx + 60), bx + bw - 140)
        ctx.move_to(b0, by + bh - 4); ctx.line_to(tip[0], tip[1]); ctx.line_to(b0 + 80, by + bh - 4); ctx.close_path()
    ctx.translate(8, 10); shape(); ctx.set_source_rgba(0, 0, 0, 0.16); ctx.fill(); ctx.translate(-8, -10)
    shape(); ctx.set_source_rgba(*col); ctx.set_line_width(12); ctx.stroke_preserve(); ctx.set_source_rgba(1, 1, 1, 1); ctx.fill()
    for k, l in enumerate(lines): text(ctx, l, bx + bw / 2, by + 50 + lh * 0.5 + k * lh, 900, size, (0.1, 0.09, 0.12, 1))
    for k, l in enumerate(he_lines): text(ctx, l, bx + bw / 2, by + 50 + len(lines) * lh + 30 + k * 56, 700, he_size, (0.42, 0.4, 0.46, 1))
    ctx.restore()

def char_state(who, tt):
    st = dict(t=tt, bob=math.sin(tt * 2.2 + (0 if who == "A" else 1.7)) * 4, expr="happy", talk=0, pose="down")
    ph = (tt * 0.37 + (0.0 if who == "A" else 0.43)) % 1.0
    st["blink"] = 1.0 if ph < 0.03 else 0.0
    cur = None
    for ln in DL:
        if ln["t0"] <= tt < ln["t1"] + 0.05: cur = ln
    if cur and cur["speaker"] == who:
        el = tt - cur["t0"]
        if cur["env"] is not None:
            i = int(el * FPS); st["talk"] = float(cur["env"][min(i, len(cur["env"]) - 1)]) if i < len(cur["env"]) else 0
        else:
            st["talk"] = clamp(0.55 + 0.45 * math.sin(el * 2 * math.pi * 4.2) * math.sin(el * 2 * math.pi * 1.3 + 1)) if el < cur["dur"] - 0.08 else 0
        st["bob"] += math.sin(el * 13) * 3
        if "?" in cur.get("bubble", cur["text"]): st["expr"] = "confused"; st["tilt"] = 0.06 * (1 if who == "A" else -1)
    # A holds the book while reading
    if who == "A" and T_BOOK and T_BOOK - 0.1 <= tt < T_WARM: st["pose"] = "book"
    # reactions after each failed step
    for k in range(1, 5):
        f = T_FAIL.get(k)
        if f and f <= tt < f + 0.75: st["expr"] = "oops"; st["pose"] = "shrug" if who == "B" else st["pose"]
    if T_SCR and T_SCR <= tt < T_SCR + 0.6: st["expr"] = "shock"; st["talk"] = 0
    trom_end = T_TROM + 1.7 if T_TROM else 0
    if T_ZERO and T_ZERO <= tt < trom_end:
        st["expr"] = "sad"; st["slump"] = ease((tt - T_ZERO) / 0.4); st["sweat"] = clamp((tt - T_ZERO) / 1.5)
        if tt >= T_TROM - 0.05: st["talk"] = 0
    if tt >= T_WARM: st["pose"] = "down"
    if tt >= T_CTA: st["pose"] = "wave" if who == "B" else "point"
    return st

def skit_frame(ctx, tt):
    global BG
    if BG is None: BG = skit_bg()
    shake = 0
    for k in range(1, 5):
        f = T_FAIL.get(k)
        if f and f <= tt < f + 0.2: shake = 9 * (1 - (tt - f) / 0.2)
    ctx.save(); ctx.translate(math.sin(tt * 90) * shake, math.cos(tt * 70) * shake * 0.6)
    ctx.set_source_surface(BG, 0, 0); ctx.paint()
    if tt >= T_WARM:   # warm ending: soft golden glow behind the pair
        a = ease((tt - T_WARM) / 0.6) * (1 - 0.5 * ease((tt - T_CTA) / 0.5))
        g = cairo.RadialGradient(CX, 1400, 40, CX, 1400, 620); g.add_color_stop_rgba(0, 1, 0.86, 0.45, 0.75 * a); g.add_color_stop_rgba(1, 1, 0.86, 0.45, 0)
        ctx.set_source(g); ctx.paint()
    pw = tw("@noamroz__", 800, 28) + 44; rrect(ctx, CX - pw / 2, 120, pw, 50, 25); ctx.set_source_rgba(1, 1, 1, 0.55); ctx.fill()
    text(ctx, "@noamroz__", CX, 145, 800, 28, (0.15, 0.13, 0.18, 1))
    handbook(ctx, tt); cta_card(ctx, tt)
    draw_char(ctx, "A", char_state("A", tt)); draw_char(ctx, "B", char_state("B", tt))
    cur = None
    for ln in DL:
        if ln["t0"] - 0.1 <= tt < ln["show_end"]: cur = ln
    if cur: bubble(ctx, cur, tt)
    if T_SCR and T_SCR <= tt < T_SCR + 0.55:
        u = (tt - T_SCR) / 0.55
        text(ctx, "SCRRRATCH!", CX, 652, 900, 78, hx("#111111"), 1 - ease((u - 0.7) / 0.3), scale=0.8 + 0.2 * eback(u * 3))
    ctx.restore()

# ------------------------------------------------------------------ frame router
def frame(tt):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); ctx = cairo.Context(s)
    if tt < HOOK: hook_frame(ctx, tt)
    elif tt < MAP_END:
        name = next(n for n, (a, b) in SEC.items() if a <= tt < b)
        el = tt - SEC[name][0]
        if name == "jews": jews_frame(ctx, el, tt)
        else: empire_frame(ctx, name, el, tt)
        if name != "jews" or tt < NL[6]["t0"]: narr_caption(ctx, tt, 1480 if name != "jews" else JEWV.top + JEWV.h + 34 + 2 * 128 + 50)
        # quick white flash between sections
        fl = 1 - ease(el / 0.18)
        if fl > 0: ctx.set_source_rgba(1, 1, 1, 0.35 * fl); ctx.paint()
    else:
        u = (tt - MAP_END) / 0.4
        if u < 1:   # skit slides in over the map
            jews_frame(ctx, tt - SEC["jews"][0], tt)
            ctx.save(); ctx.translate(W * (1 - eback(u)), 0); skit_frame(ctx, tt); ctx.restore()
        else: skit_frame(ctx, tt)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W]
    return a[..., [2, 1, 0]].copy()

# ------------------------------------------------------------------ audio
def synth_sfx():
    tt = lambda d: np.arange(int(d * SR)) / SR
    x = tt(1.2); ding = (np.sin(2 * np.pi * 1568 * x) + 0.5 * np.sin(2 * np.pi * 3136 * x) * np.exp(-x * 6) + 0.25 * np.sin(2 * np.pi * 4410 * x) * np.exp(-x * 9)) * np.exp(-x * 3.2)
    x = tt(0.25); thump = np.sin(2 * np.pi * (70 + 80 * np.exp(-x * 30)) * x) * np.exp(-x * 14)
    rng = np.random.default_rng(3)
    x = tt(0.55); n = rng.standard_normal(len(x)); f = 600 + 2600 * np.abs(np.sin(2 * np.pi * 3.2 * x)) ** 2
    ph = np.cumsum(f) / SR; scratch = (np.sin(2 * np.pi * ph) * 0.5 + n * 0.5) * np.sin(np.pi * x / 0.55) ** 0.5
    k = np.ones(8) / 8; scratch = np.convolve(scratch, k, "same") * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 7 * x)))
    notes = [(233.1, 0.36), (220.0, 0.36), (207.7, 0.36), (196.0, 1.0)]; trom = []
    for fr, d in notes:
        x = tt(d); vib = 1 + (0.012 * np.sin(2 * np.pi * 5.5 * x) * np.clip(x / 0.3, 0, 1) if d > 0.5 else 0)
        ph = np.cumsum(fr * vib) / SR; s = sum(np.sin(2 * np.pi * h * ph) / h ** 1.1 for h in range(1, 9))
        wah = 0.5 + 0.5 * np.clip(x / 0.12, 0, 1) * np.exp(-x * (1.2 if d > 0.5 else 3)); env = np.minimum(1, x / 0.03) * np.minimum(1, (d - x) / 0.06)
        trom.append(s * wah * env)
    trom = np.concatenate(trom)
    x = tt(0.45); nz = rng.standard_normal(len(x)); whoosh = np.convolve(nz, np.ones(30) / 30, "same") * np.sin(np.pi * x / 0.45) ** 2
    x = tt(0.09); pop = np.sin(2 * np.pi * (500 + 900 * np.exp(-x * 40)) * x) * np.exp(-x * 45)
    nrm = lambda v: v / (np.abs(v).max() + 1e-9)
    return dict(ding=nrm(ding), thump=nrm(thump), scratch=nrm(scratch), trom=nrm(trom), whoosh=nrm(whoosh), pop=nrm(pop))

def loadmus(p):
    m, sr = sf.read(p); m = m.mean(1) if m.ndim > 1 else m
    return m / np.abs(m).max()

def build_audio(path):
    n = int((TOTAL + 0.3) * SR); voice = np.zeros(n); sfx = np.zeros(n); S = synth_sfx()
    def put(buf, x, t0, g=1.0):
        i = int(t0 * SR); j = min(n, i + len(x))
        if 0 <= i < n: buf[i:j] += g * x[:j - i]
    for ln in NL + DL:
        if ln["clip"] is not None: put(voice, ln["clip"] / (np.abs(ln["clip"]).max() + 1e-9) * 0.9, ln["t0"])
    for name, (a, b) in SEC.items(): put(sfx, S["whoosh"], a - 0.12, 0.25)
    for name, info in MAPINFO.items():
        a = SEC[name][0]; sp = spreads()[name]
        for d in info["dots"]:
            if d in sp.entry: put(sfx, S["pop"], a + sp.entry[d][2], 0.12)
    JT = jtimes()
    for nm, td in JT["td"].items(): put(sfx, S["pop"], SEC["jews"][0] + td + 0.6, 0.1)
    for nm, tp in JT["push"].items(): put(sfx, S["thump"], SEC["jews"][0] + tp, 0.3)
    put(sfx, S["whoosh"], SEC["jews"][0] + JT["home"], 0.35); put(sfx, S["ding"], SEC["jews"][0] + JT["home"] + 0.85, 0.25)
    put(sfx, S["whoosh"], MAP_END - 0.1, 0.35)
    if T_BOOK: put(sfx, S["whoosh"], T_BOOK - 0.1, 0.3)
    for k in range(1, 5):
        f = T_FAIL.get(k)
        if f: put(sfx, S["ding"], f, 0.42); put(sfx, S["thump"], f + 0.02, 0.5)
    if T_SCR: put(sfx, S["scratch"], T_SCR, 0.55)
    if T_ZERO: put(sfx, S["thump"], T_ZERO, 0.6)
    if T_TROM: put(sfx, S["trom"], T_TROM + 0.05, 0.5)
    # music: map track then comic track; ducked under voice; cut at the scratch; softer after
    mm = loadmus(os.path.join(HERE, "music_map.wav")); ms = loadmus(os.path.join(HERE, "music_skit.wav"))
    mus = np.zeros(n); i0 = int(MAP_END * SR); xf = int(0.5 * SR)
    seg = mm[:min(len(mm), i0 + xf)]; mus[:len(seg)] += seg * np.concatenate([np.ones(max(0, len(seg) - xf)), np.linspace(1, 0, min(xf, len(seg)))])
    seg = ms[:n - i0]; mus[i0:i0 + len(seg)] += seg * np.concatenate([np.linspace(0, 1, xf), np.ones(len(seg) - xf)])
    g = np.full(n, 0.42)
    if T_TROM:
        a, b = int(T_SAD * SR), int(T_WARM * SR); r0 = int(0.3 * SR); g[a:a + r0] = np.linspace(0.42, 0, r0); g[a + r0:b] = 0.0
        r = int(0.8 * SR); g[b:b + r] = np.linspace(0, 0.34, r)[:len(g[b:b + r])]; g[b + r:] = 0.34
    # duck where voice is present
    hop = 1024; ve = np.array([np.abs(voice[i:i + hop]).max() for i in range(0, n, hop)])
    dk = np.repeat((ve > 0.02).astype(float), hop)[:n]
    L = int(0.25 * SR); cs = np.concatenate([[0], np.cumsum(dk)]); idx = np.clip(np.arange(n) + L // 2, 0, n); idx0 = np.clip(np.arange(n) - L // 2, 0, n)
    dk = (cs[idx] - cs[idx0]) / L
    g = g * (1 - 0.62 * np.clip(dk, 0, 1))
    fo = int(1.4 * SR); g[-fo:] *= np.linspace(1, 0, fo)
    mix = voice + sfx + mus * g
    mix = np.tanh(mix * 1.1) * 0.9
    st = np.stack([mix, np.roll(mix, 30)], 1)
    sf.write(path, st, SR)

# ------------------------------------------------------------------ main
def summary():
    print(f"total {TOTAL:.2f}s  map_end {MAP_END:.2f}s  sections", {k: (round(a, 2), round(b, 2)) for k, (a, b) in SEC.items()})
    for ln in NL: print(f"  N {ln['key']} {ln['t0']:6.2f} {ln['dur']:5.2f} {'clip' if ln['real'] else 'est'} | {ln['text']}")
    for i, ln in enumerate(DL): print(f"  {i + 1:02d}{ln['speaker']} {ln['t0']:6.2f} {ln['dur']:5.2f} {'clip' if ln['real'] else 'est'} | {ln['text']}")
    print("  events", [(k, round(t_, 2)) for t_, k in EV])
    json.dump(dict(total=TOTAL, map_end=MAP_END, sections=SEC, narration=[(l["key"], round(l["t0"], 3), round(l["dur"], 3)) for l in NL],
                   dialogue=[(i + 1, l["speaker"], round(l["t0"], 3), round(l["dur"], 3)) for i, l in enumerate(DL)], events=EV),
              open(os.path.join(HERE, "timeline.json"), "w"), indent=1)

if __name__ == "__main__":
    summary()
    if A.frames:
        os.makedirs(os.path.join(HERE, "check"), exist_ok=True)
        for s_ in A.frames.split(","):
            Image.fromarray(frame(float(s_))).save(os.path.join(HERE, "check", f"f_{float(s_):06.2f}.png"))
        sys.exit()
    MIXW = os.path.join(HERE, "mix.wav"); build_audio(MIXW)
    ff = subprocess.Popen(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-i", MIXW, "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
                           "-shortest", "-movflags", "+faststart", A.out], stdin=subprocess.PIPE)
    N = int(TOTAL * FPS)
    for fr in range(N):
        ff.stdin.write(frame(fr / FPS).tobytes())
        if fr % 300 == 0: print("frame", fr, "/", N, flush=True)
    ff.stdin.close(); ff.wait(); print(A.out, round(TOTAL, 1), "s")
