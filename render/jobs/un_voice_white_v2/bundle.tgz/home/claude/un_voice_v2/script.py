"""un_voice script: one line per beat, the caption key it drives, EN/HE caption text."""
LINES = [
 # (spoken, caption_en or None, caption_he or None)
 ("How the UN counts victims.", None, None),
 ("Syria. Over half a million dead since twenty eleven.", "*500,000+* dead in Syria\nsince 2011.", "מעל חצי מיליון הרוגים בסוריה, מאז 2011"),
 ("UN resolutions? About one a year.", "Resolutions?\nAbout *1 a year.*", "החלטות? בערך אחת בשנה"),
 ("Who's the killer? Not Jews.", "Who’s the killer?\n*Not Jews.*", "מי הרוצח? לא יהודים"),
 ("Meh.", "Meh.", "לא מעניין."),
 ("Yemen. About three hundred and seventy seven thousand dead.", "*377,000* dead\nin Yemen.", "377,000 הרוגים בתימן"),
 ("Resolutions? Zero.", "Resolutions? *Zero.*", "החלטות? אפס."),
 ("Who's the killer? Not Jews.", "Who’s the killer?\n*Not Jews.*", "מי הרוצח? לא יהודים"),
 ("Never mind.", "Never mind.", "לא משנה."),
 ("Sudan. Up to a hundred and fifty thousand dead since twenty twenty three.", "Up to *150,000* dead\nin Sudan since 2023.", "עד 150,000 הרוגים בסודן מאז 2023"),
 ("Resolutions? Zero.", "Resolutions? *Zero.*", "החלטות? אפס."),
 ("Not Jews? Next.", "Not Jews? *Next.*", "לא יהודים? הבא בתור."),
 ("And Israel?", "And Israel?", "ומה עם ישראל?"),
 ("A hundred and seventy three resolutions.", "*173* resolutions.", "173 החלטות גינוי"),
 ("Wait, Jews? Pile them up!", "Wait, Jews?\n*Pile them up!*", "יהודים? תערמו החלטות!"),
 ("The rest of the world, combined? Eighty.", "The rest of the world,\ncombined? *80.*", "כל שאר העולם ביחד? 80."),
 ("Israel got more than twice that.", "Israel got more than\n*twice* that.", "ישראל קיבלה יותר מפי שניים"),
 ("That's not human rights. That's obsession.", None, None),
 ("Some people are hypocrites. Here is...", None, None),
]
PARTS = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9, 10, 11], [12, 13, 14, 15, 16], [17, 18]]
