"""beer_scenes.py: custom reelkit scenes for beer_per_km_v2 and israel_beer_facts (30 Oct 2026).
Loaded through spec "scene_module". Everything is laid out inside the IG safe area:
x 60..920 (right 160 px kept clear), y up to 1540 (bottom 380 px kept clear). Centre column CX = 490.
Text sizes: hook >= 90 px, labels >= 56 px, sources 34 px. Burned-in subtitles are moved up to y 1395 and narrowed."""
import math
import render as RD
from render import P, T, block, block_h, PP, fade_in, draw_emoji, flag_emoji, emoji_surf, clean, count, pill
from kit import box, rr, sa, font, St, ease, ramp, lerp, pil2cairo, W
from PIL import Image, ImageDraw, ImageFont

CX = 490; X0 = 70; X1 = 910; MAXW = 800
SUB_Y = 1362; SRC_Y = 1482; TOP = 330

# ---------------------------------------------------------------- subtitles: narrower, higher (out of the bottom 380 px)
def sub_surfs(pieces, sz=48, maxw=800):
    F = ImageFont.truetype(RD.SUB_FONT, sz); out = []
    for t0, t1, d in pieces:
        words = d.split(); lines = []; cur = ""
        for w_ in words:
            tr = (cur + " " + w_).strip()
            if F.getlength(tr) <= maxw - 60: cur = tr
            else: lines.append(cur); cur = w_
        lines.append(cur); lh = int(sz * 1.25); Wd = int(max(F.getlength(x) for x in lines)) + 60; Hd = lh * len(lines) + 24
        im = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=24, fill=RD.P255["navy"][:3] + (232,), outline=RD.P255["gold"], width=3)
        for k, x in enumerate(lines): dr.text((Wd / 2, 12 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor="mm")
        out.append((t0, t1, pil2cairo(im), int(CX - Wd / 2), int(SUB_Y - Hd / 2), d, Hd))
    return out
RD.sub_surfs = sub_surfs

# ---------------------------------------------------------------- helpers
def tm(S, name, default=None):
    v = S["times"].get(name)
    return default if v is None else v
def source(c, t, S):
    s = S.get("source")
    if not s: return
    a = fade_in(t, S["t0"] + S.get("source_delay", 0.5), S)
    z, ls = RD.wrap(s, 34, 700, MAXW, 2, 0.99)
    for k, l in enumerate(ls): T(c, l, 34, CX, SRC_Y - 21 * (len(ls) - 1) + 42 * k, P["grey"], a, 1.0, 700, maxw=MAXW, src=True)
def chip(c, t, S):
    sp = S["_spec"].get("series") or {}
    if sp.get("en"):
        a, s = PP(t, S["t0"], S); pill(c, sp["en"], 36, CX, 250, P["gold"], P["white"], a, s, w=800)
def heading(c, t, S, y=TOP, size=74):
    en = S.get("title")
    if not en: return y
    a, s = PP(t, S["t0"] + 0.05, S); h = block_h(en, size, 900, MAXW, 2)
    block(c, en, size, CX, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=MAXW, max_lines=2)
    return y + h + 30
def mirror_emoji(c, e, x, y, px, a=1.0, flip=False, rot=0.0):
    if a * St.a <= 0.01: return
    s, w_, h_ = emoji_surf(e, px)
    c.save(); c.translate(x, y); c.rotate(rot)
    if flip: c.scale(-1, 1)
    c.set_source_surface(s, -w_ / 2, -h_ / 2); c.paint_with_alpha(min(1, a * St.a)); c.restore()

def glass(c, x, y, h, level, t, a=1.0, label=None):
    """beer glass fuel gauge centred at x, top at y; level 0..1; bubbles rise; ticks like a fuel gauge"""
    if a * St.a <= 0.01: return
    wt, wb = h * 0.62, h * 0.46
    def path():
        c.move_to(x - wt / 2, y); c.line_to(x + wt / 2, y); c.line_to(x + wb / 2, y + h); c.line_to(x - wb / 2, y + h); c.close_path()
    path(); sa(c, P["white"], 0.55 * a); c.fill()
    lv = max(0.0, min(1.0, level)); yl = y + h * (1 - lv)
    c.save(); path(); c.clip()
    import cairo
    g = cairo.LinearGradient(0, yl, 0, y + h); g.add_color_stop_rgb(0, *P["gold2"][:3]); g.add_color_stop_rgb(1, *P["gold"][:3])
    wob = 5 * math.sin(t * 5)
    c.move_to(x - wt, yl + wob); c.curve_to(x - wt / 3, yl - 8 + wob, x + wt / 3, yl + 8 - wob, x + wt, yl - wob)
    c.line_to(x + wt, y + h + 5); c.line_to(x - wt, y + h + 5); c.close_path(); c.set_source(g); c.fill()
    if lv > 0.04:
        for k in range(9):   # bubbles
            ph = (t * (0.5 + 0.07 * k) + k * 0.37) % 1.0; bx = x + (k - 4) * wb * 0.09 + 4 * math.sin(t * 3 + k)
            by = y + h - ph * (y + h - yl); RD.circ(c, bx, by, 3.5 + (k % 3), P["white"], 0.7 * a)
        for k in range(5):   # foam
            RD.circ(c, x - wt * 0.42 + k * wt * 0.21, yl + 4 + wob * 0.5, h * 0.075, P["white"], 0.95 * a)
    c.restore()
    path(); sa(c, P["navy"], a); c.set_line_width(7); c.stroke()
    for k in range(1, 4):   # gauge ticks
        yy = y + h * k / 4; xr = x + lerp(wt / 2, wb / 2, k / 4)
        c.move_to(xr - 22, yy); c.line_to(xr - 4, yy); sa(c, P["navy"], 0.7 * a); c.set_line_width(5); c.stroke()
    T(c, "F", 40, x + wt / 2 + 30, y + 22, P["navy"], a, 1.0, 900, maxw=60)
    T(c, "E", 40, x + wb / 2 + 30, y + h - 18, P["navy"], a, 1.0, 900, maxw=60)
    if label: T(c, label, 36, x, y + h + 40, P["navy"], a, 1.0, 800, maxw=300)

def road(c, t, y, a=1.0, speed=420.0):
    box(c, X0 - 10, y, X1 - X0 + 20, 120, 30, P["navy"], 0.92 * a)
    off = (t * speed) % 160
    for k in range(-1, 7):
        x = X0 + 20 + k * 160 + off
        if X0 < x < X1 - 80: box(c, x, y + 54, 80, 12, 6, P["gold2"], a)

def car_glass(c, t, S, yc, level, carx=CX - 120, fuel_label="FUEL"):
    """car on a moving road with a beer-glass fuel gauge"""
    road(c, t, yc + 70)
    bob = 6 * math.sin(t * 9)
    mirror_emoji(c, "🚗", carx, yc + 20 + bob, 250, 1.0, flip=S["_spec"].get("car_flip", True), rot=0.015 * math.sin(t * 9))
    for k in range(3):   # exhaust puffs
        ph = (t * 1.6 + k / 3) % 1.0
        RD.circ(c, carx + 150 + ph * 120, yc + 50 - ph * 30, 10 + 18 * ph, P["silver"], 0.6 * (1 - ph))
    glass(c, X1 - 125, yc - 175, 230, level, t, label=fuel_label)

# ---------------------------------------------------------------- scenes
def sc_car_hook(c, t, S):
    """frame-0 hook / loop end: big question + car + beer-glass gauge, all moving from frame 0"""
    if S.get("chip", True): chip(c, t, S)
    a, s = PP(t, S["t0"] + 0.05, S); size = S.get("size", 92)
    h = block_h(S["en"], size, 900, MAXW, 4); y = S.get("y", 330)
    breath = 1 + 0.012 * math.sin(max(0, t) * 2.4)
    block(c, S["en"], size, CX, y + h / 2, P["navy"], a, s * breath, hl=P["blue"], maxw=MAXW, max_lines=4)
    u = ease((t - (S["t0"] + 0.1)) / 0.8) if t > S["t0"] + 0.1 else 0.0
    if S["hook"]: u = 1.0
    if u > 0: box(c, CX - 300 * u, y + h + 10, 600 * u, 12, 6, P["gold"], a)
    drain = S.get("drain", [0.95, 0.55]); dur = max(1.0, (S["t1"] or S["t0"] + 5) - S["t0"])
    lv = lerp(drain[0], drain[1], min(1, max(0, (t - S["t0"]) / dur)))
    car_glass(c, t, S, S.get("car_y", 1060), lv)
    source(c, t, S)

def sc_stack(c, t, S):
    """heading + up to 4 rows: icon/flag, big value, label; optional 'drive' track (a small car drives value km);
    optional formula line. Each row pops on its mark i<k>."""
    chip(c, t, S); y = heading(c, t, S)
    items = S["items"]; n = len(items); room = S.get("room", 1300) - y - (110 if S.get("formula") else 0)
    rh = min(S.get("rh", 250), room / max(1, n))
    for k, it in enumerate(items):
        t_ = tm(S, f"i{k}", S["t0"] + 0.3 + 0.8 * k); a, s = PP(t, t_, S)
        if a <= 0.01: continue
        yc = y + rh * (k + 0.5); hi = it.get("color") == "gold"
        card = P["card"]; c.save(); c.translate(CX, yc); c.scale(s, s); c.translate(-CX, -yc); old = St.a; St.a *= a
        RD.shadow_box(c, X0, yc - rh / 2 + 10, X1 - X0, rh - 20, 30, card, 1.0, stroke=P["gold"] if hi else None, sw=6)
        St.a = old; c.restore()
        em = it.get("icon") or (flag_emoji(it["flag"]) if it.get("flag") else None)
        if em: draw_emoji(c, em, X0 + 75, yc, min(110, rh * 0.5), a, s)
        xl = X0 + 150
        vcol = P["gold_text"] if hi else P["navy"]
        val = it["value"]
        if it.get("num") is not None:
            v = count(t, t_ + 0.05, it.get("dur", 0.9), it.get("from", 0), it["num"], log=it.get("log", False))
            val = it.get("prefix", "") + RD.fmt(v, it.get("dec", 0)) + it.get("suffix", "")
        vs = it.get("vsize", 76); dv = it.get("drive") is not None
        T(c, val, vs, xl, yc - (58 if dv else (24 if it.get("label") else 0)), vcol, a, s, 900, anchor="l", maxw=X1 - xl - 30)
        if it.get("label"): T(c, it["label"], 56, xl, yc + (8 if dv else 44), P["grey"] if not hi else P["navy"], a, s, 700, anchor="l", maxw=X1 - xl - 30)
        if it.get("drive"):   # little car drives km proportional
            frac = it["drive"]; u = ease((t - t_ - 0.2) / 1.2) if t > t_ + 0.2 else 0
            ty = yc + 78; x0_, x1_ = xl, X1 - 40
            box(c, x0_, ty - 4, x1_ - x0_, 8, 4, P["silver"], a)
            xe = lerp(x0_, x0_ + (x1_ - x0_) * frac, u)
            box(c, x0_, ty - 4, xe - x0_, 8, 4, P["gold"] if hi else P["blue"], a)
            mirror_emoji(c, "🚗", xe, ty - 20, 50, a, flip=S["_spec"].get("car_flip", True))
    if S.get("formula"):
        t_ = tm(S, "formula", S["t0"] + 2.0); a, s = PP(t, t_, S)
        T(c, S["formula"], 56, CX, S.get("room", 1300) - 40, P["navy"], a, s, 900, hl=P["blue"], maxw=MAXW)
    source(c, t, S)

def sc_race(c, t, S):
    """compact sorted bar race, 56 px labels, bars glide to rank; Israel gold; optional note pill"""
    chip(c, t, S); y = heading(c, t, S, size=70)
    bars = S["bars"]; n = len(bars); bottom = 1300 - (90 if S.get("note") else 0)
    rh = min(S.get("rh", 130), (bottom - y) / n); bh = rh * 0.66
    LX, BX, BM = X0 + 4, 390, X1 - 10
    vmax = S.get("max") or max(b["value"] for b in bars) * 1.05
    cur = []
    for k, b in enumerate(bars):
        t_ = tm(S, f"b{k}", S["t0"] + 0.3 + 0.5 * k)
        cur.append(count(t, t_, 0.8, 0, b["value"]) if t >= t_ - 0.05 else None)
    vis = [k for k in range(n) if cur[k] is not None]
    order = sorted(vis, key=lambda k: -bars[k]["value"]) + [k for k in range(n) if cur[k] is None]
    rank = {k: r for r, k in enumerate(order)}
    if "_rank" not in S: S["_rank"] = {k: float(rank[k]) for k in range(n)}; S["_lt"] = t
    dt = max(0.0, t - S["_lt"]); S["_lt"] = t; kk = 1 - math.exp(-dt * 9)
    for k in range(n): S["_rank"][k] += (rank[k] - S["_rank"][k]) * (kk if dt > 0 else 1)
    for k, b in enumerate(bars):
        if cur[k] is None: continue
        t_ = tm(S, f"b{k}", 0); a = fade_in(t, t_ - 0.05, S, 0.2); old = St.a; St.a *= a
        yc = y + rh * S["_rank"][k] + rh / 2; hi = b.get("color") == "gold"
        draw_emoji(c, flag_emoji(b["flag"]), LX + 26, yc, 50)
        T(c, b["label"], 56, LX + 62, yc, P["gold_text"] if hi else P["navy"], 1, 1, 900, anchor="l", maxw=BX - LX - 70)
        bw = max(bh, (BM - BX) * cur[k] / vmax); col = P["gold"] if hi else (P["blue"] if b.get("color") != "navy" else P["navy"])
        box(c, BX, yc - bh / 2, bw, bh, bh / 2, col)
        lab = b.get("text") if t > t_ + 0.75 else RD.fmt(cur[k], b.get("dec", 1)) + b.get("suffix", " km")
        f = font(56, 900)
        if f.getlength(lab) + 36 < bw: T(c, lab, 56, BX + bw - 18, yc + 1, P["white"], 1, 1, 900, anchor="r", maxw=bw)
        else: T(c, lab, 56, BX + bw + 14, yc + 1, P["gold_text"] if hi else P["navy"], 1, 1, 900, anchor="l", maxw=BM + 10 - BX - bw)
        St.a = old
    if S.get("note"):
        t_ = tm(S, "note", S["t0"] + 3); a, s = PP(t, t_, S, bounce=2.4)
        pill(c, S["note"], 60, CX, 1300 - 40, P["gold"], P["white"], a, s, w=900)
    source(c, t, S)

def sc_glass_title(c, t, S):
    """big statement + optional emoji, glass gauge (level drains from..to) or an emoji hero"""
    chip(c, t, S)
    a, s = PP(t, S["t0"] + 0.05, S); size = S.get("size", 90); y = S.get("y", 340)
    h = block_h(S["en"], size, 900, MAXW, 3)
    block(c, S["en"], size, CX, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=MAXW, max_lines=3); y += h + 30
    if S.get("sub"):
        t_ = tm(S, "sub", S["t0"] + 0.6); a2, s2 = PP(t, t_, S); hs = block_h(S["sub"], 64, 800, MAXW, 2)
        block(c, S["sub"], 64, CX, y + hs / 2, P["gold_text"], a2, s2, w=800, hl=P["blue"], maxw=MAXW, max_lines=2); y += hs + 20
    dur = max(1.0, (S["t1"] or S["t0"] + 4) - S["t0"])
    if S.get("level"):
        l0, l1 = S["level"]; lv = lerp(l0, l1, ease(min(1, max(0, (t - S["t0"]) / dur))))
        gx = CX + (-120 if S.get("hero") else 0)
        glass(c, gx, max(y + 30, 820), 330, lv, t, label=S.get("glass_label"))
        if S.get("hero"):
            t_ = tm(S, "hero", S["t0"] + 0.4); a3, s3 = PP(t, t_, S)
            draw_emoji(c, S["hero"], CX + 230, max(y + 30, 820) + 160 + 10 * math.sin(t * 3), 200, a3, s3)
    elif S.get("hero"):
        t_ = tm(S, "hero", S["t0"] + 0.2); a3, s3 = PP(t, t_, S)
        draw_emoji(c, S["hero"], CX, max(y + 210, 1000) + 12 * math.sin(t * 2.5), S.get("hero_px", 300), a3, s3, rot=S.get("spin", 0) * t)
    if S.get("big"):
        t_ = tm(S, "big", S["t0"] + 0.4); a4, s4 = PP(t, t_, S, bounce=2.4)
        v = S["big"]
        if S.get("num") is not None:
            v = S.get("prefix", "") + RD.fmt(count(t, t_ + 0.05, S.get("dur", 1.0), S.get("from", 0), S["num"], log=S.get("log", False)), S.get("dec", 0)) + S.get("suffix", "")
        T(c, v, S.get("big_size", 150), CX, S.get("big_y", 1180), P["gold_text"], a4, s4, 900, maxw=MAXW)
        if S.get("big_label"):
            T(c, S["big_label"], 60, CX, S.get("big_y", 1180) + S.get("label_dy", 100), P["navy"], a4, s4, 800, maxw=MAXW)
    source(c, t, S)

def sc_loop(c, t, S):
    """end line that loops to the hook (no Comment X, no follow card): text + glass/car, ends < 1 s after the voice"""
    if S.get("car"): return sc_car_hook(c, t, dict(S, chip=False))
    return sc_glass_title(c, t, S)
