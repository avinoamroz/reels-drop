"""Bespoke reelkit scenes for fair_elections: safeguard card, court reversal, fair-elections scorecard, statement.
statement is the same as in the un_own_people reel."""
import math
import render as RD
from render import P, T, pill, PP, fade_in, source, shadow_box, draw_emoji, block, block_h, col, clean, heading
from kit import ease, ramp, lerp, St, sa, rr, box, font, circ

def _steps(c, t, S, y=372, n=4):
    """four safeguard dots, the current one gold"""
    k = S.get("step")
    if not k: return
    a = fade_in(t, S["t0"] + 0.05, S)
    for i in range(n):
        x = 540 + (i - (n - 1) / 2) * 64; on = i < k
        old = St.a; St.a *= a
        circ(c, x, y, 16 if i == k - 1 else 12, P["gold"] if on else P["silver"])
        St.a = old

def _ring(c, t, S, cx, cy, r, em):
    """white disc + navy ring that draws itself, emoji inside"""
    t0 = S["t0"]; a, s = PP(t, t0 + 0.05, S, s0=0.5, bounce=1.5)
    if a <= 0.01: return
    old = St.a; St.a *= a
    c.save(); c.translate(cx, cy); c.scale(s, s)
    c.new_sub_path(); sa(c, P["navy"], 0.12); c.arc(4, 12, r, 0, 2 * math.pi); c.fill()
    c.new_sub_path(); sa(c, P["white"]); c.arc(0, 0, r, 0, 2 * math.pi); c.fill()
    u = 1.0 if S.get("hook") else ease((t - t0) / 0.9)
    sa(c, P["navy"]); c.set_line_width(10); c.new_sub_path(); c.arc(0, 0, r - 6, -math.pi / 2, -math.pi / 2 + 2 * math.pi * u); c.stroke()
    sa(c, P["gold"]); c.set_line_width(4); c.new_sub_path(); c.arc(0, 0, r + 12, -math.pi / 2, -math.pi / 2 + 2 * math.pi * u); c.stroke()
    c.restore(); St.a = old
    draw_emoji(c, em, cx, cy + 6 * math.sin(t * 2.4), r * 1.05, a, s)

def sc_safeguard(c, t, S):
    t0 = S["t0"]; tm = S["times"]; y = 280
    if S.get("chip"):
        a, s = PP(t, t0 + 0.05, S); pill(c, S["chip"], 38, 540, y, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
        T(c, S.get("chip_he", ""), 38, 540, y + 66, P["navy"], a, s, 700); y += 110
    else: y += 20
    _steps(c, t, S, y + 20); y += 60
    _ring(c, t, S, 540, y + 170, 150, S["icon"]); y += 370
    tb = tm.get("body", t0 + 0.3)
    he_ = block_h(S["en"], 70, 900, 920, 3)
    a, s = PP(t, tb, S, s0=0.7, bounce=1.4)
    block(c, S["en"], 70, 540, y + he_ / 2, P["navy"], a, s, 900, hl=P["blue"], maxw=920, max_lines=3); y += he_ + 20
    hh = block_h(S["he"], 52, 700, 920, 2)
    a, s = PP(t, tb + 0.2, S); block(c, S["he"], 52, 540, y + hh / 2, P["blue"], a, s, 700, maxw=920, max_lines=2); y += hh + 50
    for p in S.get("pills", []):
        a, s = PP(t, tm.get(p["mark"], t0 + 1.2), S, bounce=2.4)
        pill(c, p["en"], 42, 540, y, col(p.get("color"), "gold"), P["white"], a, s, w=800)
        T(c, p["he"], 40, 540, y + 74, col(p.get("color"), "gold_text") if p.get("color") else P["gold_text"], a, s, 700, maxw=940); y += 140
    if S.get("note"):
        a = fade_in(t, t0 + 0.9, S)
        T(c, S["note"]["en"], 40, 540, y + 10, P["grey"], a, 1, 800, maxw=940)
        T(c, S["note"]["he"], 36, 540, y + 62, P["grey"], a, 1, 700, maxw=940)
    source(c, t, S)

def sc_court(c, t, S):
    """two stacked decision cards (ban, then reversal) joined by an arrow, a note pill, source"""
    _steps(c, t, S, 270); y = heading(c, t, S, y=330) + 20; tm = S["times"]
    ch = 280
    for k, st in enumerate(S["steps"]):
        tk = tm.get(st["mark"], S["t0"] + 0.4 + 1.2 * k)
        a, s = PP(t, tk, S, s0=0.6, bounce=1.5)
        y0 = y + k * (ch + 90)
        if k:
            u = ramp(t, tk - 0.3, tk)
            if u > 0:
                sa(c, P["navy"], 0.6 * u); c.set_line_width(8); c.move_to(540, y0 - 80); c.line_to(540, y0 - 80 + 60 * u); c.stroke()
                c.move_to(518, y0 - 34); c.line_to(562, y0 - 34); c.line_to(540, y0 - 12); c.close_path(); sa(c, P["navy"], 0.6 * u); c.fill()
        if a <= 0.01: continue
        cc = col(st.get("color"), "navy"); cy = y0 + ch / 2
        old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(s, s); c.translate(-540, -cy)
        shadow_box(c, 90, y0, 900, ch, 28, P["card"], stroke=cc, sw=6)
        box(c, 90, y0, 18, ch, 9, cc)
        draw_emoji(c, st["icon"], 190, cy, 100)
        hb = block_h(st["en"], 50, 900, 700, 2)
        block(c, st["en"], 50, 610, y0 + 30 + hb / 2, P["navy"], 1, 1, 900, maxw=700, max_lines=2)
        hh = block_h(st["he"], 40, 700, 700, 2)
        block(c, st["he"], 40, 610, y0 + 46 + hb + hh / 2, cc, 1, 1, 700, maxw=700, max_lines=2)
        c.restore(); St.a = old
    if S.get("note"):
        yy = y + 2 * ch + 90 + 70
        a, s = PP(t, tm.get("note", S["t0"] + 3), S, bounce=2.4)
        pill(c, S["note"]["en"], 44, 540, yy, P["gold"], P["white"], a, s, w=800)
        T(c, S["note"]["he"], 40, 540, yy + 78, P["gold_text"], a, s, 700, maxw=940)
    source(c, t, S)

def _score_col(v):
    return P["green"] if v >= 10 else (P["amber"] if v >= 5 else P["red"])

def sc_score(c, t, S):
    """scorecard: badge (emoji or short text), country EN/HE, one-line fact EN/HE, a 12-segment score bar + n/12 chip"""
    y = heading(c, t, S, y=300); tm = S["times"]
    if S.get("sub"):
        a = fade_in(t, S["t0"] + 0.3, S)
        T(c, S["sub"], 36, 540, y + 4, P["grey"], a, 1, 800, maxw=940)
        T(c, S["sub_he"], 34, 540, y + 50, P["grey"], a, 1, 700, maxw=940); y += 90
    rows = S["rows"]; n = len(rows); foot = 150 if S.get("note") else 0
    rh = min(200, (RD.CONTENT_BOTTOM - y - foot) / n); bh = rh - 16
    for k, r in enumerate(rows):
        tk = tm.get(f"r{k}", S["t0"] + 0.3 + 0.5 * k)
        if t < tk - 0.07 and not S.get("hook"): continue
        a = fade_in(t, tk - 0.07, S, 0.2); u = ease((t - tk + 0.07) / 0.35)
        y0 = y + k * rh; cy = y0 + bh / 2; dx = 240 * (1 - u)
        sc = _score_col(r["score"]); isr = r["score"] == 12
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        shadow_box(c, 80, y0, 920, bh, 24, P["card"], stroke=P["gold"] if isr else P["silver"], sw=5 if isr else 3, sh=6)
        # badge
        R = min(56, bh * 0.36); bx = 150
        b = r["badge"]
        if any(ord(ch) > 0x2000 for ch in b): draw_emoji(c, b, bx, cy, R * 1.7)
        else:
            c.new_sub_path(); sa(c, P["navy"]); c.arc(bx, cy, R + 6, 0, 2 * math.pi); c.fill()
            T(c, b, 34 if len(b) <= 4 else 28, bx, cy + 2, P["white"], 1, 1, 900, maxw=2 * R + 4)
        # text
        xl = 230; xr = 800
        T(c, r["en"], 42, xl, y0 + bh * 0.22, P["navy"], 1, 1, 900, anchor="l", maxw=300)
        T(c, r["he"], 38, xr, y0 + bh * 0.22, P["gold_text"], 1, 1, 700, anchor="r", maxw=240)
        T(c, r["fact"], 34, xl, y0 + bh * 0.52, P["navy"], 1, 1, 700, anchor="l", maxw=xr - xl)
        T(c, r["fact_he"], 30, xr, y0 + bh * 0.80, P["blue"], 1, 1, 700, anchor="r", maxw=xr - xl)
        # score
        v = r["score"]; uu = ease((t - tk - 0.1) / 0.6)
        T(c, f"{v}/12", 46, 905, cy - 18, sc, 1, 1 + 0.08 * max(0, 1 - abs(t - tk - 0.7) / 0.2), 900, maxw=170)
        for j in range(12):
            on = j < v * uu + 1e-6 and v > 0
            box(c, 838 + j * 11.5, cy + 22, 9, 26, 3, sc if on else P["silver"], 1.0 if on else 0.5)
        c.restore(); St.a = old
    if S.get("note"):
        yy = y + n * rh + 50
        a, s = PP(t, tm.get("note", S["t0"] + 3), S, bounce=2.2)
        pill(c, S["note"]["en"], 34, 540, yy, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
        T(c, S["note"]["he"], 34, 540, yy + 64, P["navy"], a, s, 700, maxw=940)
    source(c, t, S)

def sc_statement(c, t, S):
    """gold label pill (+ Hebrew), optional icon, a big English statement (*highlight*), Hebrew under it."""
    t0 = S["t0"]; tb = S["times"].get("body", t0 + 0.3)
    en, he = S["en"], S.get("he", "")
    h_en = block_h(en, S.get("size", 76), 900, 920, 4); h_he = block_h(he, 54, 700, 920, 3)
    em = S.get("icon"); total = (190 if em else 0) + 150 + h_en + 40 + h_he
    y = max(330, (330 + 1420) / 2 - total / 2)
    if em:
        a, s = PP(t, t0 + 0.05, S); draw_emoji(c, em, 540, y + 80, 150, a, s); y += 190
    a, s = PP(t, t0 + 0.08, S)
    pill(c, S["label"], 52, 540, y + 36, P["gold"], P["white"], a, s, w=900)
    T(c, S.get("label_he", ""), 44, 540, y + 112, P["navy"], a, s, 700); y += 150
    a, s = PP(t, tb, S, s0=0.7, bounce=1.4); breath = 1 + 0.01 * math.sin(max(0, t - t0) * 2.2)
    block(c, en, S.get("size", 76), 540, y + h_en / 2, P["navy"], a, s * breath, 900, hl=P["blue"], maxw=920, max_lines=4); y += h_en
    u = ease((t - tb - 0.2) / 0.8) if t > tb + 0.2 else 0.0
    if u > 0: box(c, 540 - 300 * u, y + 10, 600 * u, 10, 5, P["gold"], a)
    y += 40
    a, s = PP(t, tb + 0.25, S); block(c, he, 54, 540, y + h_he / 2, P["blue"], a, s, 700, maxw=920, max_lines=3)
    source(c, t, S)

def sc_cards_grid(c, t, S):
    """built-in cards_grid squeezed into the top part, plus a footer pill"""
    keep = RD.CONTENT_BOTTOM; RD.CONTENT_BOTTOM = 1150
    try: RD.sc_cards_grid(c, t, S)
    finally: RD.CONTENT_BOTTOM = keep
    f = S.get("footer")
    if f:
        tf = S["times"]["cards"][-1] + 0.6
        a, s = PP(t, tf, S, bounce=2.4)
        pill(c, f["en"], 44, 540, 1250, P["navy"], P["white"], a, s, outline=P["gold"], w=800)
        T(c, f["he"], 40, 540, 1330, P["navy"], a, s, 700, maxw=940)
