import sys; sys.path.append("/home/claude/fix6/lib")
import looplib; looplib.wrap(globals(), "/home/claude/daily_1028/scenes_daily.py")
