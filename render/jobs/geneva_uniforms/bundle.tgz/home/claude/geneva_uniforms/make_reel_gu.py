"""make_reel_sse (26 Oct 2026): make_reel with the timing from Cartesia SSE word timestamps instead of whisper.
  python3 make_reel_sse.py spec.json SSE_PREFIX out_dir/ [--script tts.txt] [--preview]
SSE_PREFIX.wav + SSE_PREFIX_words.json come from tts_api/sse_parse.py. House chain at atempo 1.0; word times mapped
through it (t = lead + t_raw * out/in). Final ASR QA is off by default (--asr-qa to run it).

reelkit one-shot: voice -> align -> render -> mix -> qa.

  python3 make_reel.py spec.json vo_raw.wav out_dir/ [--script tts.txt] [--no-asr-qa] [--preview]

spec "script": path to the script (one line per TTS line; relative to the spec file), or pass --script.
spec "use_lines": optional 1-based script lines to keep (the voice is cut at the pauses and re-joined).
--preview: stop after timing and write out_dir/preview.png (keyframes) instead of a video.
Outputs in out_dir: reel.mp4 (1080x1920 30 fps, AAC 48 kHz), reel_web.mp4 (540x960, < 8 MB), vo.wav, timing.json,
qa.json, qa_sheet.png, run.json (stage timings). The ASR cache lives in out_dir/work (re-runs skip the ASR)."""
import os, sys, json, time, argparse
HERE = "/home/claude/reelkit"; sys.path.insert(0, HERE)
os.nice(5)

def sse_process(voice, pre, lines, log, tempo=1.0):
    import numpy as np
    from clean_vo import clean as clean_vo
    voice.TEMPO = tempo
    W = json.load(open(pre + "_words.json"))
    dry = voice.chain_dry(pre + ".wav"); cl = clean_vo(dry, voice.SR)
    y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); vo = voice.post(y)
    k = (len(vo) / voice.SR - voice.LEAD) / (len(dry) / voice.SR); tm = lambda x: round(voice.LEAD + x * k, 3)
    words, out_lines, i = [], [], 0
    for li, l in enumerate(lines):
        n = len(l.split()); ws = W[i:i + n]; i += n
        assert len(ws) == n, (li, l)
        for w, sw in zip(ws, l.split()): words.append(dict(w=sw, line=li, t0=tm(w["start"]), t1=tm(max(w["end"], w["start"] + 0.04)), matched=True))
        out_lines.append(dict(i=li, text=l, t0=tm(ws[0]["start"]), t1=tm(ws[-1]["end"]), recall=1.0, missing=[]))
    assert i == len(W), (i, len(W))
    log(f"[sse] {len(words)} words timed from Cartesia timestamps, k {k:.4f}")
    return dict(vo=vo, timing=dict(words=words, lines=out_lines, heard="(Cartesia timestamps)"), report=dict(raw=pre, timing="cartesia sse", tempo=1.0))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("spec"); ap.add_argument("raw"); ap.add_argument("out")
    ap.add_argument("--script"); ap.add_argument("--asr-qa", action="store_true"); ap.add_argument("--preview", action="store_true")
    ap.add_argument("--no-restore", action="store_true")
    A = ap.parse_args(); T0 = time.time(); st = {}
    out = os.path.abspath(A.out); work = os.path.join(out, "work"); os.makedirs(work, exist_ok=True)
    def log(*a): print(f"[{time.time() - T0:6.1f}s]", *a, flush=True)
    import voice, render as RD, mix as MX, qa as QA, asr as ASR
    spec = RD.load_spec(A.spec); sdir = os.path.dirname(os.path.abspath(A.spec))
    sp = A.script or spec.get("script"); sp = sp if os.path.isabs(sp) else os.path.join(sdir, sp)
    lines = voice.read_script(sp)
    # 1. voice + timing
    t = time.time(); r = sse_process(voice, A.raw, lines, log, spec.get("tempo", 1.0))
    keep = [k - 1 for k in spec["use_lines"]] if spec.get("use_lines") else None
    vo, tim = voice.select(r["vo"], r["timing"], keep, gap_max=spec.get("gap_max", 0.6), gap_new=spec.get("gap_new", 0.45))
    voice.write(out, vo, tim, r["report"]); st["voice_align_s"] = round(time.time() - t, 1)
    log(f"voice {tim['dur']:.2f}s, lines " + ", ".join(f"{L['t0']:.2f}-{L['t1']:.2f}" for L in tim["lines"]))
    # 2. timeline
    t = time.time(); R = RD.Reel(spec, tim); st["timeline_s"] = round(time.time() - t, 1)
    log(f"timeline: {len(R.scenes)} scenes, T_END {R.T_END:.2f}s, warnings {R.warn}")
    if A.preview:
        RD.preview(R, R.keytimes(), f"{out}/preview.png"); log("preview", f"{out}/preview.png"); return
    # 3. mix
    t = time.time(); last = R.scenes[-1]
    end_at = last["times"].get("keyword", last["t0"]) if last["type"] == "cta" else R.T_END - 2.0
    bed = MX.bed(spec.get("music", "doc_piano"), R.T_END, end_at)
    ev = [(tt, k, 0.0) for tt, k in R.sfx_events()]
    wav = f"{work}/mix.wav"; mrep = MX.mix(vo, R.T_END, bed, ev, wav, music_db=spec.get("music_db", -17.0), log=log)
    mrep["bed"] = spec.get("music", "doc_piano"); st["mix_s"] = round(time.time() - t, 1)
    # 4. render (frames stream into ffmpeg with the mix)
    t = time.time(); mp4 = f"{out}/reel.mp4"; vid = RD.render_video(R, wav, mp4, log=log); st["render_s"] = round(time.time() - t, 1)
    # 5. web preview
    t = time.time(); web = f"{out}/reel_web.mp4"; MX.web(mp4, web); st["web_s"] = round(time.time() - t, 1)
    # 6. qa
    t = time.time(); rep = QA.run_all(out, R, vid, mp4, web, tim, mrep, log=log, do_asr=A.asr_qa); st["qa_s"] = round(time.time() - t, 1)
    os.remove(wav)
    st["total_s"] = round(time.time() - T0, 1)
    json.dump(dict(stages=st, spec=os.path.abspath(A.spec), raw=os.path.abspath(A.raw), outputs=dict(mp4=mp4, web=web, qa=f"{out}/qa.json",
              sheet=f"{out}/qa_sheet.png")), open(f"{out}/run.json", "w"), indent=1)
    print("\n" + QA.summary(rep)); print("stages", st)

if __name__ == "__main__":
    main()
