"""Bespoke reelkit scenes for "Who's really hiding behind international law?" (@noamroz__, 31 Oct 2026, slug geneva_uniforms).
Full-bleed backgrounds (navy or silver), big justified text across the width, flat silhouettes (no faces, no weapons in the crowd).
Loop: the hook (scene 0) and the loop scene (last) draw the same layout through draw_question(); every ambient motion
(background drift, crowd sway, breathing) is periodic over the reel length, so the last frame matches frame 0.
Music: the journey bed regenerated at a BPM that fits a whole number of bars into the reel, cut on bar lines and
crossfaded so it loops cleanly. No burned-in subtitles. Key text stays in y 220..1590."""
import math, random
import cairo
import render as RD, mix as MX
from render import P, T, pill, PP, fade_in, block, col
from kit import ease, ramp, lerp, St, sa, rr, circ, box, font, hx

RD.draw_subs = lambda c, t, items: None
L, R = 60, 1020; CX = (L + R) / 2; CW = R - L
G = {"T": 60.0}
SRC_Y = (1512, 1556)

_draw0 = RD.Reel.draw
def _draw(s, c, t):
    G["T"] = s.T_END; _draw0(s, c, t)
RD.Reel.draw = _draw

def ph(t, cycles):
    """periodic phase: an integer number of cycles over the reel, so t=0 and t=T_END match"""
    return 2 * math.pi * cycles * t / G["T"]

NAVY = hx("#163260"); NAVY_D = hx("#0B1A36"); BLUE = hx("#2A88D4"); GOLD = hx("#B8923F"); GOLD_L = hx("#E6C77E")
SIL0 = hx("#F4F5F7"); SIL1 = hx("#D3D8DF"); SILV = hx("#B9C0CA"); WHITE = hx("#FFFFFF"); RED = hx("#D63A4A"); GREEN = hx("#1E9E62")
GREY_T = hx("#5B6B82"); SRC_ON_NAVY = hx("#AEB9CB")

# ------------------------------------------------------------------ background (navy, full-bleed, periodic)
_bgc = {}
def background(c, t):
    if "g" not in _bgc:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, 1200, 1200); gc = cairo.Context(s)
        rg = cairo.RadialGradient(600, 600, 0, 600, 600, 600); rg.add_color_stop_rgba(0, *BLUE[:3], 0.55); rg.add_color_stop_rgba(1, *BLUE[:3], 0)
        gc.set_source(rg); gc.paint(); _bgc["g"] = s
    g = cairo.LinearGradient(0, 0, 400, 1920); g.add_color_stop_rgb(0, *NAVY[:3]); g.add_color_stop_rgb(1, *NAVY_D[:3])
    c.set_source(g); c.paint()
    for k, (bx, by, br) in enumerate([(250, 420, 620), (860, 1500, 700)]):
        x = bx + 90 * math.sin(ph(t, 3) + k * 2); y = by + 70 * math.cos(ph(t, 2) + k); s = br / 600
        c.save(); c.translate(x - br, y - br); c.scale(s, s); c.set_source_surface(_bgc["g"], 0, 0); c.paint_with_alpha(0.55); c.restore()
    # faint diagonal stripes drifting (period = reel / 6)
    off = (t / G["T"] * 6 % 1) * 160
    c.save(); c.set_line_width(26)
    for k in range(-14, 16):
        x0 = k * 160 + off; c.move_to(x0, 0); c.line_to(x0 + 700, 1920)
    c.set_source_rgba(1, 1, 1, 0.025); c.stroke(); c.restore()
RD.background = background

def silver_bg(c, t):
    """full-bleed silver panel (drawn by silver scenes at scene alpha)"""
    g = cairo.LinearGradient(0, 0, 500, 1920); g.add_color_stop_rgba(0, *SIL0[:3], St.a); g.add_color_stop_rgba(1, *SIL1[:3], St.a)
    c.rectangle(0, 0, 1080, 1920); c.set_source(g); c.fill()
    off = (t / G["T"] * 6 % 1) * 160
    c.save(); c.set_line_width(26)
    for k in range(-14, 16):
        x0 = k * 160 + off; c.move_to(x0, 0); c.line_to(x0 + 700, 1920)
    c.set_source_rgba(*NAVY[:3], 0.03 * St.a); c.stroke(); c.restore()

# ------------------------------------------------------------------ text helpers
def fit_size(s, maxsz, width, w=900):
    s = RD.clean(s).replace("*", ""); z = maxsz
    while z > 30 and font(z, w).getlength(s) > width: z -= 2
    return z
def J(c, s, y, color, a=1.0, sc=1.0, maxsz=170, w=900, hl=None, l=L, r=R):
    """one line justified to the full content width (font grows until the line spans l..r, capped at maxsz)"""
    z = fit_size(s, maxsz, (r - l) * 0.985, w)
    T(c, s, z, (l + r) / 2, y, color, a, sc, w, hl=hl or GOLD_L, maxw=r - l + 6); return z
def sources(c, t, items, color=None):
    cur = None
    for tf, *ls in items:
        if t >= tf - 0.01: cur = (tf, ls)
    if not cur: return
    a = ramp(t, cur[0], cur[0] + 0.3)
    for k, l in enumerate(cur[1]):
        if l: T(c, l, 34, CX, SRC_Y[k], color or SRC_ON_NAVY, a, 1.0, 700, maxw=CW, src=True)
def tm(S, k, d=None): return S["times"].get(k, d if d is not None else 999)

# ------------------------------------------------------------------ people (flat silhouettes, no faces)
def person(c, x, y, h, body, a=1.0, kind="civ", lean=0.0, child=0.0, sign=None):
    """feet at (x, y), height h. kind: civ, soldier (helmet, armband sign, rifle carried openly), police (cap + badge)"""
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(lean); old = St.a; St.a *= a
    hr = 0.105 * h; w = 0.34 * h
    dark = tuple(v * 0.78 for v in body[:3])
    box(c, -0.15 * h, -0.47 * h, 0.13 * h, 0.47 * h, 0.05 * h, dark)                   # legs
    box(c, 0.02 * h, -0.47 * h, 0.13 * h, 0.47 * h, 0.05 * h, dark)
    box(c, -w / 2 - 0.06 * h, -0.76 * h, 0.1 * h, 0.36 * h, 0.05 * h, body)            # arms
    box(c, w / 2 - 0.04 * h, -0.76 * h, 0.1 * h, 0.36 * h, 0.05 * h, body)
    box(c, -w / 2, -0.78 * h, w, 0.4 * h, 0.09 * h, body)                               # torso
    circ(c, 0, -h + hr, hr, body)                                                       # head
    if kind == "soldier":
        c.new_sub_path(); c.arc(0, -h + hr * 0.95, hr * 1.18, math.pi, 2 * math.pi); c.close_path(); sa(c, dark); c.fill()
        box(c, -hr * 1.35, -h + hr * 0.82, hr * 2.7, hr * 0.32, hr * 0.15, dark)
        box(c, -w / 2 - 0.065 * h, -0.70 * h, 0.11 * h, 0.07 * h, 0.02 * h, sign or GOLD)  # armband (distinctive sign)
        c.save(); c.translate(0, -0.6 * h); c.rotate(-0.75)                                # rifle, carried openly
        box(c, -0.36 * h, -0.025 * h, 0.72 * h, 0.05 * h, 0.02 * h, hx("#2B2F36"))
        box(c, 0.12 * h, -0.025 * h, 0.06 * h, 0.12 * h, 0.02 * h, hx("#2B2F36")); c.restore()
        box(c, -0.05 * h, -0.72 * h, 0.1 * h, 0.08 * h, 0.02 * h, sign or GOLD)           # chest patch
    if kind == "police":
        box(c, -hr * 1.2, -h - hr * 0.05, hr * 2.4, hr * 0.7, hr * 0.2, dark)
        box(c, -hr * 1.45, -h + hr * 0.5, hr * 2.9, hr * 0.22, hr * 0.1, dark)
        circ(c, -0.08 * h, -0.66 * h, 0.04 * h, GOLD)
    if child > 0.01:                                                                    # a child held by the hand
        ch = 0.5 * h * child; cx = w / 2 + 0.16 * h
        c.save(); c.translate(cx, 0); c.scale(child, child); c.translate(-cx, 0)
        box(c, cx - 0.05 * h, -0.24 * h, 0.06 * h, 0.24 * h, 0.03 * h, dark); box(c, cx + 0.03 * h, -0.24 * h, 0.06 * h, 0.24 * h, 0.03 * h, dark)
        box(c, cx - 0.08 * h, -0.42 * h, 0.2 * h, 0.2 * h, 0.06 * h, body); circ(c, cx + 0.02 * h, -0.47 * h, 0.06 * h, body)
        box(c, w / 2 - 0.02 * h, -0.42 * h, 0.12 * h, 0.05 * h, 0.02 * h, body)
        c.restore()
    St.a = old; c.restore()

CIV = [hx(x) for x in ("#9AA6B8", "#B4BDCA", "#8794A8", "#A7B1C1", "#C2C9D4", "#7F8CA1")]
def crowd_layout(seed, rows, x0=-20, x1=1100):
    """rows [(feet_y, height, n)] back to front -> list of (x, y, h, colour, phase)"""
    Rn = random.Random(seed); out = []
    for ri, (fy, h, n) in enumerate(rows):
        step = (x1 - x0) / n
        for k in range(n):
            x = x0 + step * (k + 0.5) + Rn.uniform(-0.18, 0.18) * step + (step / 2 if ri % 2 else 0)
            out.append((x, fy + Rn.uniform(-10, 10), h * Rn.uniform(0.94, 1.06), CIV[Rn.randrange(len(CIV))], Rn.random() * 6.28, ri))
    return out
def draw_crowd(c, t, people, a=1.0, child_k=0.0, child_set=(), tint=0.0, kinds=None, signs=None):
    for i, (x, y, h, cc, p, ri) in enumerate(people):
        lean = 0.025 * math.sin(ph(t, 20) + p); bob = 6 * math.sin(ph(t, 20) + p * 1.3)
        body = cc if tint <= 0 else tuple(lerp(v, w_, tint) for v, w_ in zip(cc[:3], SILV[:3]))
        kind = (kinds or {}).get(i, "civ")
        if kind == "soldier": body = NAVY
        person(c, x, y + bob, h, body, a, kind=kind, lean=lean, child=child_k if i in child_set else 0.0, sign=(signs or {}).get(i))

def qmark(c, x, y, s, a, color=GOLD):
    if a <= 0.01 or s <= 0.01: return
    circ(c, x, y, 40 * s, color, a, stroke=WHITE, sw=5)
    T(c, "?", int(62 * s), x, y + 2, WHITE, a, 1.0, 900, maxw=200)

# ------------------------------------------------------------------ the question (frame 0 and the last frame)
HOOK_CROWD = crowd_layout(7, [(1290, 300, 9), (1500, 380, 7), (1760, 470, 6)])
def draw_question(c, t, a=1.0, s=1.0):
    br = 1 + 0.012 * math.sin(ph(t, 16))
    J(c, "WHO'S REALLY", 330, WHITE, a, s * br, maxsz=150)
    J(c, "HIDING BEHIND", 480, WHITE, a, s * br, maxsz=150)
    J(c, "INTERNATIONAL", 640, GOLD_L, a, s * br, maxsz=170)
    J(c, "LAW?", 800, GOLD_L, a, s * br, maxsz=170, l=330, r=750)
    box(c, CX - 300, 900, 600, 12, 6, GOLD, a)
def draw_hook_crowd(c, t, a=1.0):
    draw_crowd(c, t, HOOK_CROWD, a)
    # pulsing gold question marks over three heads (periodic)
    for k, i in enumerate((4, 11, 17)):
        x, y, h = HOOK_CROWD[i][:3]; pu = 0.5 + 0.5 * math.sin(ph(t, 12) + k * 2.1)
        qmark(c, x, y - h - 60, 0.75 + 0.15 * pu, a * (0.55 + 0.45 * pu))

# ------------------------------------------------------------------ scenes
def sc_crowd(c, t, S):
    """lines 1 to 4: the question, then the gunman in the crowd"""
    tq = tm(S, "q_out", 3.0); u = ease((t - tq) / 0.5)
    if u < 1:
        a = 1 - u
        c.save(); c.translate(0, -120 * u); draw_question(c, t, a); c.restore()
    tg, tc, td, tp, tw = (tm(S, k) for k in ("gun", "child", "dressed", "police", "which"))
    # crowd: from frame 0; grows a little after the question leaves
    z = 1 + 0.08 * u
    c.save(); c.translate(540, 1920); c.scale(z, z); c.translate(-540, -1920)
    ck = ease((t - tc) / 0.5) if t > tc else 0.0
    draw_crowd(c, t, HOOK_CROWD, 1.0, child_k=ck, child_set={2, 9, 12, 16, 19})
    if t < tq + 0.5:   # hook question marks fade with the question
        for k, i in enumerate((4, 11, 17)):
            x, y, h = HOOK_CROWD[i][:3]; pu = 0.5 + 0.5 * math.sin(ph(t, 12) + k * 2.1)
            qmark(c, x, y - h - 60, 0.75 + 0.15 * pu, (1 - u) * (0.55 + 0.45 * pu))
    # firing: alarm rings from somewhere inside the crowd (no weapon shown, no victims)
    if tg < 900 and t > tg - 0.1:
        for k in range(3):
            uu = ((t - tg) * 0.9 + k / 3) % 1.0
            sa(c, RED, (1 - uu) * 0.8 * (1 - ramp(t, tw, tw + 0.6))); c.set_line_width(8)
            c.new_sub_path(); c.arc(560, 1250, 40 + 330 * uu, 0, 2 * math.pi); c.stroke()
    # "which one?": question marks pop over many heads
    if t > tw - 0.1:
        for k, i in enumerate((0, 3, 6, 9, 11, 14, 16, 19)):
            x, y, h = HOOK_CROWD[i][:3]; aa, ss = PP(t, tw + 0.09 * k, S, bounce=2.6)
            qmark(c, x, y - h - 50, 0.9 * ss, aa)
    c.restore()
    # police officer, front left, looking at the crowd
    if t > tp - 0.2:
        k = ease((t - tp + 0.2) / 0.5)
        person(c, lerp(-200, 150, k), 1900, 760, hx("#24447A"), 1.0, kind="police", lean=0.02 * math.sin(ph(t, 20)))
    # top text after the question
    if t >= tq:
        a, s = PP(t, tq + 0.05, S); J(c, "PICTURE A GUNMAN", 330, WHITE, a * (1 - ramp(t, tc - 0.2, tc)), s, maxsz=130)
        a2, s2 = PP(t, tg, S); J(c, "INSIDE A CROWD.", 480, GOLD_L, a2 * (1 - ramp(t, tc - 0.2, tc)), s2, maxsz=130)
    if t >= tc - 0.1:
        a, s = PP(t, tc, S); J(c, "HOLDING A CHILD.", 330, WHITE, a * (1 - ramp(t, tp - 0.2, tp)), s, maxsz=130)
        a2, s2 = PP(t, td, S); J(c, "DRESSED LIKE EVERYONE.", 480, GOLD_L, a2 * (1 - ramp(t, tp - 0.2, tp)), s2, maxsz=130)
    if t >= tp - 0.1:
        a, s = PP(t, tp, S); J(c, "HOW DO POLICE STOP HIM?", 330, WHITE, a, s, maxsz=120)
        a2, s2 = PP(t, tw, S, bounce=2.4); J(c, "WHICH ONE IS HE?", 490, GOLD_L, a2, s2, maxsz=150)

def doc_icon(c, x, y, s, a, t):
    """a treaty page with a gold seal"""
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(-0.05 + 0.015 * math.sin(ph(t, 18))); c.scale(s, s); old = St.a; St.a *= a
    sa(c, NAVY, 0.15); rr(c, -230 + 10, -300 + 18, 460, 600, 26); c.fill()
    box(c, -230, -300, 460, 600, 26, WHITE, stroke=NAVY, sw=6)
    T(c, "GENEVA", 58, 0, -215, NAVY, 1, 1, 900, maxw=400)
    for k in range(7): box(c, -170, -140 + k * 52, 340 if k % 3 else 260, 14, 7, SILV)
    circ(c, 120, 205, 62, GOLD, stroke=GOLD_L, sw=6); T(c, "1949", 34, 120, 207, WHITE, 1, 1, 900, maxw=110)
    St.a = old; c.restore()

def sc_law(c, t, S):
    """lines 5 and 6, silver: the laws of war, Geneva 1949, one big rule"""
    silver_bg(c, t); t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); J(c, "THE LAWS OF WAR", 330, NAVY, a, s, maxsz=150)
    tw_ = tm(S, "written"); a, s = PP(t, tw_, S); J(c, "WERE WRITTEN FOR THIS.", 470, BLUE, a, s, maxsz=110)
    tww, tg, tr = tm(S, "ww"), tm(S, "geneva"), tm(S, "rule")
    k = ease((t - t0 - 0.1) / 0.6); doc_icon(c, 540 + 600 * (1 - k), 980, 0.95 + 0.04 * ease((t - tg) / 0.4), k, t)
    a, s = PP(t, tww, S); pill(c, "AFTER WORLD WAR TWO", 56, CX, 640, NAVY, WHITE, a, s, outline=GOLD)
    if t > tg - 0.1:
        a, s = PP(t, tg, S); J(c, "GENEVA CONVENTIONS, 1949", 1390, NAVY, a, s, maxsz=110)
    if t > tr - 0.1:
        a, s = PP(t, tr, S, bounce=2.6)
        c.save(); c.translate(820, 760); c.rotate(-0.12); c.translate(-820, -760)
        pill(c, "ONE BIG RULE", 64, 820, 760, GOLD, WHITE, a, s, outline=WHITE); c.restore()
    sources(c, t, [(tg, "Geneva Conventions, 12 August 1949.", "Additional Protocol I, 1977 (Israel is not a party).")], GREY_T)

def sc_rule(c, t, S):
    """line 7, navy: armies fight armies, not civilians"""
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); J(c, "ARMIES FIGHT", 330, WHITE, a, s, maxsz=170)
    a, s = PP(t, tm(S, "armies2"), S); J(c, "ARMIES.", 500, WHITE, a, s, maxsz=170, l=250, r=830)
    tn = tm(S, "not")
    a, s = PP(t, tn, S, bounce=2.6); J(c, "NOT CIVILIANS.", 680, GOLD_L, a, s, maxsz=170)
    # two lines of soldiers facing each other, civilians safe in a ring in the middle
    k = ease((t - t0) / 0.6)
    for i in range(3):
        person(c, lerp(-150, 110 + i * 95, k), 1330 + i * 25, 330, NAVY, 1.0, kind="soldier", lean=0.02 * math.sin(ph(t, 20) + i))
        person(c, lerp(1230, 970 - i * 95, k), 1330 + i * 25, 330, hx("#1F6FB0"), 1.0, kind="soldier", sign=hx("#E6E9EE"), lean=0.02 * math.sin(ph(t, 20) + i + 1))
    ks = ease((t - tn) / 0.5) if t > tn else 0.0
    if ks > 0:
        sa(c, GREEN, 0.9 * ks); c.set_line_width(10); c.new_sub_path(); c.arc(540, 1250, 170 + 10 * math.sin(ph(t, 24)), 0, 2 * math.pi); c.stroke()
        sa(c, GREEN, 0.12 * ks); c.new_sub_path(); c.arc(540, 1250, 170, 0, 2 * math.pi); c.fill()
    for i, (dx, hh, cc) in enumerate(((-60, 230, CIV[1]), (40, 260, CIV[4]), (100, 150, CIV[0]))):
        person(c, 540 + dx, 1360 + (i == 2) * 10, hh, cc, 1.0, lean=0.02 * math.sin(ph(t, 20) + i))
    sources(c, t, [(t0 + 0.4, "Additional Protocol I, art. 48: distinguish civilians from", "combatants. Customary law for every state: ICRC rule 1.")])

def sc_uniform(c, t, S):
    """line 8, silver, the key image: a fighter who stands out"""
    silver_bg(c, t); t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); J(c, "FIGHTERS MUST", 320, NAVY, a, s, maxsz=150)
    a, s = PP(t, tm(S, "stand"), S); J(c, "STAND OUT.", 480, BLUE, a, s, maxsz=170, l=170, r=910)
    k = ease((t - t0) / 0.6)
    person(c, lerp(-300, 285, k), 1440, 780, NAVY, 1.0, kind="soldier", lean=0.012 * math.sin(ph(t, 20)))
    items = [("uniform", "UNIFORM", (330, 960)), ("sign", "CLEAR SIGN", (160, 940)), ("weapons", "ARMS OPEN", (300, 1110))]
    for j, (mk, lab, (px, py)) in enumerate(items):
        ti = tm(S, mk)
        if t < ti - 0.1: continue
        a, s = PP(t, ti, S, bounce=2.4); y = 760 + j * 210
        box(c, 560, y, 460, 150, 30, WHITE, a, stroke=NAVY, sw=5)
        circ(c, 630, y + 75, 42, GREEN, a, stroke=WHITE, sw=5)
        sa(c, WHITE, a); c.set_line_width(9); c.set_line_cap(1); c.move_to(612, y + 76); c.line_to(626, y + 90); c.line_to(650, y + 60); c.stroke()
        T(c, lab, 54, 845, y + 78, NAVY, a, s, 900, maxw=300)
        lk = ease((t - ti) / 0.4)
        if lk > 0:
            sa(c, GOLD, a); c.set_line_width(5); c.set_dash([12, 8])
            c.move_to(560, y + 75); c.line_to(lerp(560, px, lk), lerp(y + 75, py, lk)); c.stroke(); c.set_dash([])
            circ(c, px, py, 12 * lk, GOLD, a)
    sources(c, t, [(t0 + 0.5, "Third Geneva Convention 1949, art. 4: \"a fixed distinctive", "sign recognizable at a distance\", \"carrying arms openly\".")], GREY_T)

def stamp(c, x, y, a, s, rot=-0.12):
    if a <= 0.01 or s <= 0.01: return
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); c.translate(-x, -y)
    box(c, x - 180, y - 58, 360, 116, 18, RED, a * 0.12, stroke=RED, sw=8)
    T(c, "BANNED", 80, x, y + 3, RED, a, 1.0, 900, maxw=330); c.restore()
def sc_banned(c, t, S):
    """line 9, navy: perfidy and human shields"""
    t0 = S["t0"]
    for j, (mk_t, mk_b, l1, l2) in enumerate((("posing", "banned", "POSING AS A CIVILIAN", "TO ATTACK"), ("shields", "shields", "USING CIVILIANS", "AS SHIELDS"))):
        tt = tm(S, mk_t, t0 + 0.1)
        if t < tt - 0.1: continue
        a = fade_in(t, tt - 0.1, S, 0.25); dx = 240 * (1 - ease((t - tt + 0.1) / 0.35))
        y = 280 + j * 560; old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        box(c, L, y, CW, 470, 40, WHITE, stroke=GOLD, sw=6)
        J(c, l1, y + 110, NAVY, 1, 1, maxsz=110, l=L + 40, r=R - 40)
        J(c, l2, y + 230, BLUE, 1, 1, maxsz=110, l=L + 40, r=R - 40)
        c.restore(); St.a = old
        tb = tm(S, mk_b) + (0.35 if j == 1 else 0)
        a2, s2 = PP(t, tb, S, s0=1.8, bounce=1.4); stamp(c, CX, y + 370, a2, s2, -0.1 if j == 0 else 0.08)
    sources(c, t, [(t0 + 0.3, "Feigning civilian status to attack (perfidy): AP I art. 37(1)(c).", "Shields: AP I art. 51(7), GC IV art. 28. ICRC rules 65, 97.")])

GUESS_CROWD = crowd_layout(11, [(640, 240, 8), (760, 280, 7)], x0=40, x1=1040)
def sc_guess(c, t, S):
    """line 10, silver, the key image: uniform vs civilian clothes"""
    silver_bg(c, t); t0 = S["t0"]
    tl, tg, tp = tm(S, "look"), tm(S, "guess"), tm(S, "price")
    fighter = 9
    # panel A: with a uniform
    a, s = PP(t, t0 + 0.05, S); pill(c, "IN UNIFORM", 52, 270, 260, NAVY, WHITE, a, s, outline=GOLD)
    box(c, 30, 300, 1020, 520, 36, WHITE, a * 0.55, stroke=SILV, sw=3)
    c.save(); rr(c, 30, 300, 1020, 520, 36); c.clip()
    c.translate(0, 0); draw_crowd(c, t, GUESS_CROWD, a, kinds={fighter: "soldier"})
    c.restore()
    x, y, h = GUESS_CROWD[fighter][:3]
    if a > 0.01:
        sa(c, GREEN, a); c.set_line_width(7); c.new_sub_path(); c.arc(x, y - h * 0.55, h * 0.62, 0, 2 * math.pi); c.stroke()
        a3, s3 = PP(t, t0 + 0.4, S); pill(c, "EASY TO SPOT", 44, 800, 260, GREEN, WHITE, a3, s3)
    # panel B: in civilian clothes
    if t > tl - 0.1:
        a, s = PP(t, tl, S); pill(c, "IN CIVILIAN CLOTHES", 52, 360, 900, RED, WHITE, a, s, outline=WHITE)
        box(c, 30, 940, 1020, 520, 36, WHITE, a * 0.55, stroke=SILV, sw=3)
        c.save(); rr(c, 30, 940, 1020, 520, 36); c.clip(); c.translate(0, 640)
        draw_crowd(c, t, GUESS_CROWD, a); c.restore()
        if t > tg - 0.1:
            for k, i in enumerate((1, 3, 5, 7, 9, 10, 12, 14)):
                x, y, h = GUESS_CROWD[i][:3]; aa, ss = PP(t, tg + 0.07 * k, S, bounce=2.6)
                qmark(c, x, y + 640 - h - 40, 0.8 * ss, aa, RED if i == fighter else GOLD)
    # bottom line
    if t > tg - 0.1 and t < tp + 0.2:
        a, s = PP(t, tg, S); J(c, "THE OTHER SIDE HAS TO GUESS.", 1540, NAVY, a * (1 - ramp(t, tp - 0.15, tp + 0.05)), s, maxsz=80)
    if t > tp - 0.1:
        a, s = PP(t, tp, S, bounce=2.4); J(c, "CIVILIANS PAY THE PRICE.", 1540, RED, a, s, maxsz=90)

def ic_house(c, s):
    c.move_to(-90 * s, -10 * s); c.line_to(0, -95 * s); c.line_to(90 * s, -10 * s); c.close_path(); sa(c, GOLD); c.fill()
    box(c, -70 * s, -12 * s, 140 * s, 100 * s, 6 * s, WHITE); box(c, -18 * s, 30 * s, 36 * s, 58 * s, 4 * s, NAVY)
def ic_school(c, s):
    box(c, -95 * s, -40 * s, 190 * s, 128 * s, 6 * s, WHITE); box(c, -40 * s, -95 * s, 80 * s, 60 * s, 6 * s, WHITE)
    circ(c, 0, -66 * s, 18 * s, GOLD)
    for k in range(3): box(c, (-80 + k * 60) * s, -20 * s, 40 * s, 34 * s, 4 * s, BLUE)
    box(c, -18 * s, 34 * s, 36 * s, 54 * s, 4 * s, NAVY)
def ic_hospital(c, s):
    box(c, -90 * s, -80 * s, 180 * s, 168 * s, 8 * s, WHITE)
    box(c, -14 * s, -62 * s, 28 * s, 76 * s, 4 * s, BLUE); box(c, -38 * s, -38 * s, 76 * s, 28 * s, 4 * s, BLUE)
    box(c, -18 * s, 34 * s, 36 * s, 54 * s, 4 * s, NAVY)
REVEAL_CROWD = crowd_layout(23, [(1520, 260, 8), (1740, 330, 6)])
def sc_reveal(c, t, S):
    """lines 11 and 12, navy: Hamas in civilian clothes, homes, schools, hospitals; that's the gunman in the crowd"""
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S, bounce=2.6); J(c, "HAMAS", 330, GOLD_L, a, s, maxsz=190, l=230, r=850)
    a, s = PP(t, tm(S, "civ"), S); J(c, "FIGHTS IN CIVILIAN", 500, WHITE, a, s, maxsz=130)
    J(c, "CLOTHES,", 640, WHITE, a, s, maxsz=130, l=330, r=750)
    a, s = PP(t, tm(S, "hiding"), S); J(c, "HIDING IN:", 770, SRC_ON_NAVY, a, s, maxsz=70, l=380, r=700)
    for k, (mk, lab, fn) in enumerate((("homes", "HOMES", ic_house), ("schools", "SCHOOLS", ic_school), ("hosp", "HOSPITALS", ic_hospital))):
        ti = tm(S, mk)
        if t < ti - 0.1: continue
        a, s = PP(t, ti, S, bounce=2.4); x = 200 + k * 340
        if s <= 0.01 or a <= 0.01: continue
        c.save(); c.translate(x, 960); c.scale(s, s); c.translate(-x, -960)
        box(c, x - 150, 830, 300, 300, 34, hx("#21447E"), a, stroke=GOLD, sw=5)
        old = St.a; St.a *= a; c.save(); c.translate(x, 950); fn(c, 0.95); c.restore(); St.a = old
        T(c, lab, 46, x, 1080, WHITE, a, 1.0, 900, maxw=270); c.restore()
    tg = tm(S, "gunman")
    if t > tg - 0.2:
        k = ease((t - tg + 0.2) / 0.5)
        c.save(); c.translate(0, 300 * (1 - k)); draw_crowd(c, t, REVEAL_CROWD, k)
        for j, i in enumerate((2, 5, 9, 12)):
            x, y, h = REVEAL_CROWD[i][:3]; aa, ss = PP(t, tg + 0.15 + 0.1 * j, S, bounce=2.6); qmark(c, x, y - h - 40, 0.8 * ss, aa)
        c.restore()
        a, s = PP(t, tg, S, bounce=2.4); pill(c, "THE GUNMAN IN THE CROWD", 64, CX, 1235, RED, WHITE, a, s, outline=WHITE)
    sources(c, t, [(tm(S, "civ", t0), "Dressed as civilians: New York Times, July 2024. Fighting from", "residential areas: NATO StratCom COE, 2019."),
                   (tm(S, "schools", t0), "Rockets in UN schools: UNRWA 2014, UN inquiry 2015, Amnesty 2015.", "Al-Shifa hospital: US intelligence assessment, January 2024.")])

def sc_view(c, t, S):
    """line 13, silver: opinion card"""
    silver_bg(c, t); t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); pill(c, "IN MY VIEW", 70, CX, 300, GOLD, WHITE, a, s, outline=WHITE)
    box(c, L, 400, CW, 900, 44, WHITE, a, stroke=GOLD, sw=6)
    a, s = PP(t, tm(S, "blame"), S); J(c, "THE BLAME", 540, NAVY, a, s, maxsz=150, l=L + 50, r=R - 50)
    J(c, "STARTS WITH", 700, NAVY, a, s, maxsz=150, l=L + 50, r=R - 50)
    a, s = PP(t, tm(S, "whoever"), S); J(c, "WHOEVER HIDES", 870, BLUE, a, s, maxsz=150, l=L + 50, r=R - 50)
    a, s = PP(t, tm(S, "behind"), S, bounce=2.4); J(c, "BEHIND CIVILIANS.", 1040, BLUE, a, s, maxsz=150, l=L + 50, r=R - 50)
    a = fade_in(t, tm(S, "behind") + 0.3, S); T(c, "That's my opinion.", 54, CX, 1200, hx("#96702A"), a, 1.0, 800, maxw=800)
    sources(c, t, [(t0 + 0.3, "This card is my opinion, not a fact.", "")], GREY_T)

def sc_other(c, t, S):
    """line 14, navy: the other side"""
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.05, S); pill(c, "THE OTHER SIDE", 84, CX, 300, GOLD, WHITE, a, s, outline=WHITE)
    items = [("breaking", "THE SAME LAW", "Hamas breaking it doesn't free Israel."),
             ("must", "ISRAEL MUST STILL", "take every feasible precaution."),
             ("critics", "CRITICS, INCLUDING THE UN", "say it often hasn't.")]
    for k, (mk, tag, en) in enumerate(items):
        ti = tm(S, mk, t0 + 0.3)
        if t < ti - 0.1: continue
        a = fade_in(t, ti - 0.1, S, 0.25); dx = 240 * (1 - ease((t - ti + 0.1) / 0.35)); y = 420 + k * 350
        old = St.a; St.a *= a; c.save(); c.translate(dx, 0)
        box(c, L, y, CW, 310, 36, WHITE, stroke=RED, sw=6)
        T(c, tag, 50, L + 44, y + 64, RED, 1, 1, 900, anchor="l", maxw=CW - 88)
        block(c, en, 76, CX, y + 190, NAVY, 1, 1, maxw=CW - 80, max_lines=2, lh=1.05)
        c.restore(); St.a = old
    sources(c, t, [(tm(S, "breaking", t0), "AP I art. 51(8): a violation does not release the other side.", "Customary law: ICRC rules 15 and 140."),
                   (tm(S, "critics", t0), "UN Human Rights Office report, 19 June 2024: warnings,", "distinction and proportionality concerns in Gaza.")])

def sc_loop(c, t, S):
    """line 15: back to the frame 0 layout"""
    t0 = S["t0"]
    a, s = PP(t, t0 + 0.02, S, s0=0.7, bounce=1.4)
    k = ease((t - t0) / 0.5)
    c.save(); c.translate(0, 260 * (1 - k)); draw_hook_crowd(c, t, k); c.restore()
    draw_question(c, t, a, s)

# ------------------------------------------------------------------ music: beat-aligned, seamless loop
def _bed(name, dur, end_at=None):
    import numpy as np, importlib.util, sys
    if name != "journey_loop": return _bed0(name, dur, end_at)
    sys.path.insert(0, "/home/claude/island_israel")
    sp_ = importlib.util.spec_from_file_location("journey_audio", "/home/claude/island_israel/journey_audio.py")
    m = importlib.util.module_from_spec(sp_); sp_.loader.exec_module(m)
    bars = max(1, round(dur / 2.4)); bpm = 60 * 4 * bars / dur; bar = 4 * 60 / bpm
    x = np.asarray(m.music(dur + 4 * bar + 4, bpm=bpm), np.float64)
    if x.ndim == 1: x = np.vstack([x, x])
    sr = MX.SR; a0 = int(round(2 * bar * sr)); n = int(round(dur * sr)); F = int(round(bar / 2 * sr))
    seg = x[:, a0:a0 + n + F].copy()
    fi = np.sin(np.linspace(0, np.pi / 2, F)) ** 2
    out = seg[:, :n].copy(); out[:, :F] = seg[:, :F] * fi + seg[:, n:n + F] * (1 - fi)
    MX.LOOP_INFO = dict(bpm=round(bpm, 3), bars=bars, bar_s=round(bar, 4))
    return out / (np.abs(out).max() + 1e-12)
_bed0 = MX.bed
MX.bed = _bed
