"""Colourful narrated reel kit (wouldnt_do, not_math, oxy_vaso).
VO: series chain from apartheid1 build_vo (rubberband pitch 0.9715 formant kept, bass g2 f135,
clean_vo, atempo 1.1, 0.3 s lead), rebuilt from ASR chunks with every pause capped at 0.35 s, all in memory.
Subtitles: same look and chunking as cities make_subs (Heebo ExtraBold 54, dark box, SUB_BOTTOM 1600),
drawn into the frame so there is no second encode. Frames stream straight into ffmpeg (no frame dumps)."""
import os, re, json, math, subprocess, sys, random
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from bidi.algorithm import get_display
from scipy.signal import butter, sosfiltfilt, lfilter
sys.path.insert(0, "/home/claude/vo_new")
from clean_vo import clean as clean_vo

W, H, FPS, SR = 1080, 1920, 30, 48000
TEMPO, LEAD, GAPCAP = 1.1, 0.3, 0.35
SUB_BOTTOM = 1600; CONTENT_BOTTOM = 1420
DASHES = tuple(chr(x) for x in (0x2013, 0x2014, 0x2012, 0x2015))

# ------------------------------------------------------------------ maths
def ease(u): u = min(1.0, max(0.0, u)); return u * u * (3 - 2 * u)
def eob(u, s=1.7):
    u = min(1.0, max(0.0, u)) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def mix(c1, c2, u): return tuple(lerp(a, b, u) for a, b in zip(c1, c2))
def pop(t, t0, d=0.45, s0=0.15, bounce=2.0):
    """(alpha, scale) for a bouncy pop-in starting at t0"""
    if t is None or t0 is None: return 0.0, 0.0
    t0 -= 0.07
    if t < t0: return 0.0, 0.0
    u = (t - t0) / d
    return ramp(t, t0, t0 + 0.12), (s0 + (1 - s0) * eob(u, bounce) if u < 1 else 1.0)

# ------------------------------------------------------------------ colours
NAVY = hx("#163260"); SKYC = hx("#59A5DF"); GOLD = hx("#D2AA53"); YEL = hx("#FFD54A"); WHITE = (1, 1, 1, 1)
RED = hx("#FF3B5C"); PINK = hx("#FF6FA5"); GREEN = hx("#2ED47A"); ORANGE = hx("#FF8A3D"); PURPLE = hx("#8E5CFF")
TEAL = hx("#19C3B0"); LIME = hx("#B8F35A"); CYAN = hx("#4FD8FF"); INK = hx("#0E1E3A"); CREAM = hx("#FFF4E0")
Y255 = (255, 213, 74, 255); W255 = (255, 255, 255, 255)
def c255(col): return tuple(int(round(v * 255)) for v in col[:3]) + (255,)
PAL = {  # (top-left, bottom-right, blob1, blob2, blob3)
    "navy":    ("#0E1E3A", "#2749D3", "#59A5DF", "#D2AA53", "#8E5CFF"),
    "violet":  ("#22105E", "#7B2FF7", "#FF6FA5", "#4FD8FF", "#FFD54A"),
    "teal":    ("#04324A", "#0C8C9C", "#B8F35A", "#59A5DF", "#FFD54A"),
    "coral":   ("#4A0E2E", "#E0475B", "#FFD54A", "#FF8A3D", "#8E5CFF"),
    "sunset":  ("#2E0F5A", "#E8613A", "#FFD54A", "#FF6FA5", "#4FD8FF"),
    "green":   ("#05372A", "#16955A", "#FFD54A", "#4FD8FF", "#B8F35A"),
    "blue":    ("#0A2468", "#1C7FDB", "#4FD8FF", "#D2AA53", "#FF6FA5"),
    "magenta": ("#3D0A4A", "#B5308F", "#FFD54A", "#4FD8FF", "#FF8A3D"),
    "red":     ("#3E0716", "#C81E45", "#FF8A3D", "#FFD54A", "#8E5CFF"),
    "gold":    ("#3A2406", "#B9822A", "#FFD54A", "#FF6FA5", "#59A5DF"),
}
PAL = {k: tuple(hx(x) for x in v) for k, v in PAL.items()}

# ------------------------------------------------------------------ alpha stack + drawing helpers
class St: a = 1.0
def sa(c, col, a=1.0): c.set_source_rgba(col[0], col[1], col[2], (col[3] if len(col) > 3 else 1) * a * St.a)
def rr(c, x, y, w, h, r):
    r = max(0.1, min(r, w / 2, h / 2)); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def line(c, pts, col, w, a=1.0):
    sa(c, col, a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(*pts[0])
    for p in pts[1:]: c.line_to(*p)
    c.stroke()
def circ(c, x, y, r, col, a=1.0, stroke=None, sw=6):
    c.new_sub_path(); c.arc(x, y, r, 0, 2 * math.pi); sa(c, col, a)
    if stroke: c.fill_preserve(); sa(c, stroke, a); c.set_line_width(sw); c.stroke()
    else: c.fill()
def box(c, x, y, w, h, r, col, a=1.0, stroke=None, sw=6):
    rr(c, x, y, w, h, r); sa(c, col, a)
    if stroke: c.fill_preserve(); sa(c, stroke, a); c.set_line_width(sw); c.stroke()
    else: c.fill()
QA = {"text": [], "icons": []}
CUR = {"scene": None, "t": 0.0}
def icon(c, x, y, s, fn, *args, a=1.0, rot=0.0, r=None):
    """draw icon fn (drawn around 0,0 in a ~200 px box) at x,y, scale s"""
    if a <= 0.01 or abs(s) < 1e-3: return
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); old = St.a; St.a *= a
    fn(c, *args); St.a = old; c.restore()
    if r and a * St.a > 0.5 and abs(s) > 0.6: QA["icons"].append((CUR["scene"], x - r * s, y - r * s, x + r * s, y + r * s))

# ------------------------------------------------------------------ text
FONTS = {w: f"/home/claude/vid/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=900):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONTS[w], int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def is_he(s): return any("֐" <= ch <= "׿" for ch in s)
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3:4] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, :3] = (a[:, :, 2::-1] * al).astype(np.uint8); bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def text_surf(s, sz, w=900, col=W255, hl=Y255, shadow=True):
    k = (s, sz, w, col, hl, shadow)
    if k in _tc: return _tc[k]
    assert not any(d in s for d in DASHES), s
    f = font(sz, w); asc, desc = f.getmetrics(); pad = 26 if shadow else 4
    he = is_he(s)
    if he: fb = ImageFont.truetype(FONTS[w], int(sz), layout_engine=ImageFont.Layout.BASIC)
    parts = [(s, col)] if he else [(p, hl if i % 2 else col) for i, p in enumerate(s.split("*")) if p]
    tw = sum(f.getlength(p) for p, _ in parts)
    im = Image.new("RGBA", (int(tw + 2 * pad + 4), int(asc + desc + 2 * pad)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    x = pad
    for p, cc in parts:
        if he: d.text((x, pad), get_display(p), font=fb, fill=cc, anchor="la")
        else: d.text((x, pad), p, font=f, fill=cc, anchor="la")
        x += f.getlength(p)
    if shadow:
        al = im.split()[3].filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(v * 0.55))
        sh = Image.new("RGBA", im.size, (6, 10, 40, 0)); sh.putalpha(al)
        base = Image.new("RGBA", im.size, (0, 0, 0, 0)); base.alpha_composite(sh, (0, 5)); base.alpha_composite(im); im = base
    _tc[k] = (pil2cairo(im), tw, asc + desc, pad); return _tc[k]
def tx(c, s, sz, x, y, w=900, col=W255, a=1.0, sc=1.0, hl=Y255, shadow=True, src=False, maxw=940, anchor="c"):
    """draw one line of text centred at x,y. *word* = highlight colour. Hebrew auto RTL and auto-shrinks to fit."""
    if is_he(s):
        w = 700 if w == 900 else w
        while font(sz, w).getlength(s) > maxw and sz > 56: sz -= 1
    else:
        floor = 110 if sz >= 110 else 64
        while font(sz, w).getlength(s.replace("*", "")) > maxw and sz > floor: sz -= 2
    surf, tw, th, pad = text_surf(s, sz, w, col, hl, shadow)
    assert tw <= maxw + 1, ("too wide", s, tw)
    if a * St.a > 0.01 and abs(sc) > 1e-3:
        c.save(); c.translate(x, y); c.scale(sc, sc)
        ox = -tw / 2 if anchor == "c" else (0 if anchor == "l" else -tw)
        c.set_source_surface(surf, ox - pad, -th / 2 - pad); c.paint_with_alpha(min(1, a * St.a)); c.restore()
    if a * St.a > 0.6 and abs(sc - 1) < 0.08:
        x0 = x - tw / 2 if anchor == "c" else (x if anchor == "l" else x - tw)
        QA["text"].append((CUR["scene"], s.replace("*", ""), sz, x0, y - th / 2, x0 + tw, y + th / 2, src))
    return tw
def chip(c, s, sz, x, y, bg, fg=W255, a=1.0, sc=1.0, w=900, padx=0.55, outline=None, padh=1.45, strike=0.0, icon_fn=None):
    """rounded pill with text; strike in 0..1 draws a red strike line across"""
    mw = 935 - sz * padx * 2 - (sz * 1.1 if icon_fn else 0)
    if a <= 0.01 or sc < 1e-3: tx(c, s, sz, -5000, -5000, w, fg, 0, maxw=mw); return
    f = font(sz, 700 if is_he(s) else w); tw = f.getlength(s.replace("*", "")); pw = tw + sz * padx * 2 + (sz * 1.1 if icon_fn else 0); ph = sz * padh
    c.save(); c.translate(x, y); c.scale(sc, sc)
    sa(c, (0.02, 0.04, 0.15), 0.28 * a); rr(c, -pw / 2, -ph / 2 + 8, pw, ph, ph / 2); c.fill()
    box(c, -pw / 2, -ph / 2, pw, ph, ph / 2, bg, a, stroke=outline, sw=6)
    c.restore()
    off = (sz * 0.55 if icon_fn else 0) * sc
    if icon_fn: icon(c, x - pw * sc / 2 + sz * 0.95 * sc, y, sc * sz / 150, icon_fn, a=a)
    tx(c, s, sz, x + off, y + 2 * sc, w, fg, a, sc, shadow=False, maxw=mw)
    if strike > 0:
        L = (pw - sz * 0.5) * sc; x0 = x - L / 2
        line(c, [(x0, y + 4), (x0 + L * ease(strike), y - 4)], RED, 12 * sc, a)
    return pw
def he(c, s, x, y, a=1.0, sc=1.0, sz=64, col=W255):
    return tx(c, s, sz, x, y, 700, col, a, sc)

# ------------------------------------------------------------------ narration
def run(cmd, inp=None):
    r = subprocess.run(cmd, input=inp, capture_output=True); assert r.returncode == 0, r.stderr.decode()[-800:]; return r.stdout
NUMW = {"One.": "1.", "Two.": "2.", "Three.": "3.", "Four.": "4."}
KEEP = {'CE', 'P', 'I', "I'm", "I'll", 'TV', 'MBA', 'HAMAS', 'SPEAKER', 'OK', 'NBA', "I've", 'PNAS'}
def subclean(l, nums=()):
    """make_subs.py clean() plus digits for numbers"""
    for x, y in nums: l = l.replace(x, y)
    l = re.sub(r'\[[^\]]*\]', '', l).strip()
    for k, v in NUMW.items():
        if l.startswith(k): l = v + l[len(k):]
    l = l.replace('"', '').replace('... ', ' ').replace(' ,', ',')
    l = re.sub(r',\s*,', ',', l); l = re.sub(r'\s+', ' ', l).strip(' ,')
    w = []
    for x in l.split():
        core = re.sub(r"[^A-Za-z']", '', x)
        if len(core) > 1 and core.isupper() and core not in KEEP:
            x = x.replace(core, core.capitalize() if core in ('ENGLISH',) else core.lower())
        w.append(x)
    s = ' '.join(w); s = re.sub(r'([.?!] )([a-z])', lambda m: m.group(1) + m.group(2).upper(), s); return s[0].upper() + s[1:]
def subchunks(s, n=7):
    sents = re.findall(r'(?:[^.?!]|(?<=\d)\.(?=\d))+[.?!]?', s); out = []
    for se in sents:
        w = se.split()
        if not w: continue
        if out and len(w) <= 2 and len(out[-1].split()) + len(w) <= n: out[-1] += ' ' + ' '.join(w); continue
        k = max(1, -(-len(w) // n)); size = -(-len(w) // k)
        for i in range(0, len(w), size): out.append(' '.join(w[i:i + size]))
    if len(out) > 1 and len(out[0].split()) == 1 and len(out[1].split()) <= 7: out[1] = out[0] + ' ' + out[1]; out.pop(0)
    return out

class Reel:
    def __init__(s, folder, nums=(), tail=2.5):
        s.D = folder; s.name = os.path.basename(folder.rstrip("/")); s.nums = nums; s.tail = tail
        s.lines = [l.strip() for l in open(f"{folder}/tts_v4.txt") if l.strip()]
        J = json.load(open(f"{folder}/vo/asr.json")); s.SEG = J["segs"]; s.CH = J["chunks"]
        assert len(s.SEG) == len(s.lines)
        s.clean = [subclean(l, nums) for l in s.lines]
    def build_vo(s):
        raw = run(["ffmpeg", "-v", "error", "-i", f"{s.D}/vo/raw.wav", "-af", "rubberband=pitch=0.9715:formant=preserved,bass=g=2:f=135",
                   "-ar", str(SR), "-ac", "1", "-f", "f32le", "pipe:1"])
        x = np.frombuffer(raw, np.float32).astype(np.float64); x = clean_vo(x, SR).astype(np.float32)
        x = np.frombuffer(run(["ffmpeg", "-v", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "pipe:0", "-af", f"atempo={TEMPO}",
                               "-f", "f32le", "pipe:1"], x.tobytes()), np.float32).astype(np.float64)
        CH = s.CH; n = len(CH); s.cmap = []; pieces = []; prev_en = None
        for k, (a, b, _) in enumerate(CH):
            pb = CH[k - 1][1] if k else a - 0.3; na = CH[k + 1][0] if k < n - 1 else b + 0.6
            a0 = max(a - 0.06, (pb + a) / 2) if k else max(0, a - 0.06); b0 = min(b + 0.14, (b + na) / 2)
            seg = x[int(a0 / TEMPO * SR):int(b0 / TEMPO * SR)].copy(); f = int(0.008 * SR)
            seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
            st = LEAD if k == 0 else prev_en + min(GAPCAP, (a - CH[k - 1][1]) / TEMPO)
            en = st + (b - a) / TEMPO; prev_en = en
            pieces.append((st - (a - a0) / TEMPO, seg)); s.cmap.append((st, en))
        s.T_END = prev_en + s.tail
        y = np.zeros(int(s.T_END * SR) + SR)
        for t0, seg in pieces: i = int(t0 * SR); y[i:i + len(seg)] += seg
        s.vo = y[:int(s.T_END * SR)]
        # per line: piecewise map from char fraction to time
        s.lmap = []
        for i, (la, lb) in enumerate(s.SEG):
            ks = [k for k, cc in enumerate(CH) if cc[0] >= la - 0.02 and cc[1] <= lb + 0.02]
            assert ks, i
            L = [max(1, len(CH[k][2])) for k in ks]; tot = sum(L); pts = []; acc = 0
            for k, l in zip(ks, L):
                pts.append((acc / tot, s.cmap[k][0])); acc += l; pts.append((acc / tot, s.cmap[k][1]))
            s.lmap.append(pts)
        s.lspan = [(p[0][1], p[-1][1]) for p in s.lmap]
        print(s.name, "VO", round(s.T_END, 2), "s; lines", [(round(a, 2), round(b, 2)) for a, b in s.lspan])
    def ft(s, i, fr):
        P = s.lmap[i]
        for (f0, t0), (f1, t1) in zip(P, P[1:]):
            if fr <= f1 + 1e-9: return t0 if f1 - f0 < 1e-9 else t0 + (t1 - t0) * (fr - f0) / (f1 - f0)
        return P[-1][1]
    def at(s, i, phrase=None, k=0, end=False):
        """time a phrase starts (or ends) in line i"""
        if phrase is None: return s.lspan[i][1] if end else s.lspan[i][0]
        L = s.clean[i].lower(); p = phrase.lower(); pos = -1
        for _ in range(k + 1):
            pos = L.find(p, pos + 1); assert pos >= 0, (i, phrase, L)
        return s.ft(i, (pos + (len(p) if end else 0)) / len(L))
    def subs(s):
        items = []
        for i, l in enumerate(s.clean):
            cs = subchunks(l); L = len(l); pos = 0
            for cc in cs:
                p0 = l.find(cc, pos); p1 = p0 + len(cc); pos = p1
                items.append([s.ft(i, p0 / L), s.ft(i, p1 / L), cc])
        for a, b in zip(items, items[1:]):
            if b[0] - a[1] < 0.45: a[1] = b[0]
        F = ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54); out = []
        for a, b, cc in items:
            assert not any(d in cc for d in DASHES)
            w = cc.split(); lines = []; cur = ''
            for x in w:
                tr = (cur + ' ' + x).strip()
                if F.getlength(tr) <= 920: cur = tr
                else: lines.append(cur); cur = x
            lines.append(cur); lh = 66; Wd = int(max(F.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
            im = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(8, 16, 40, 200))
            for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor='mm')
            out.append((a, b, pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd, cc))
        s.sub_items = out; return out

# ------------------------------------------------------------------ music (original synth)
def _env(n, a, d):
    t = np.arange(n) / SR; return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t * d)
def music(dur, style, seed=1):
    rng = np.random.default_rng(seed); n = int(dur * SR); out = np.zeros((2, n))
    cfg = {"bounce": dict(bpm=118, T=0, prog=[(48, [60, 64, 67]), (43, [59, 62, 67]), (45, [60, 64, 69]), (41, [60, 65, 69])], tim="marimba"),
           "skip": dict(bpm=104, T=2, prog=[(41, [57, 60, 65]), (45, [57, 60, 64]), (38, [57, 62, 65]), (43, [55, 59, 62])], tim="bell"),
           "warm": dict(bpm=96, T=-3, prog=[(43, [59, 62, 67]), (40, [59, 64, 67]), (36, [60, 64, 67]), (38, [57, 62, 66])], tim="pluck")}[style]
    beat = 60 / cfg["bpm"]; bar = 4 * beat; T = cfg["T"]
    def hz(m): return 440 * 2 ** ((m - 69 + T) / 12)
    def put(sig, st, g, pan=0.0):
        i = int(st * SR); j = min(n, i + len(sig))
        if 0 <= i < n and j > i: out[0, i:j] += g * (1 - pan) * sig[:j - i]; out[1, i:j] += g * (1 + pan) * sig[:j - i]
    def tone(f, d, kind):
        m = int(d * SR); t = np.arange(m) / SR
        if kind == "marimba": return (np.sin(2 * np.pi * f * t) + 0.35 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 40)) * _env(m, 0.002, 9)
        if kind == "bell": return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 12)) * _env(m, 0.002, 5)
        sq = sum(np.sin(2 * np.pi * f * h * t) / h ** 1.3 for h in range(1, 7)); return sq * _env(m, 0.003, 7) * 0.6
    nb = int(dur / bar) + 2
    for b in range(nb):
        root, ch = cfg["prog"][b % 4]; st = b * bar; inten = 0.55 if b < 1 else 1.0
        tt = np.arange(int(bar * SR)) / SR  # pad
        pad = sum(sum(np.sin(2 * np.pi * hz(m) * hh * tt + rng.uniform(0, 6)) / hh ** 2 for hh in (1, 2, 3)) for m in ch)
        pad *= np.minimum(1, tt / 0.25) * np.minimum(1, (bar - tt) / 0.2); put(pad, st, 0.035)
        for q, off in enumerate((0, 1.5, 2, 3.5) if style != "warm" else (0, 2, 2.5)):  # bass
            m = root - 12; d = beat * 0.9; t2 = np.arange(int(d * SR)) / SR
            put(np.sin(2 * np.pi * hz(m) * t2) * _env(len(t2), 0.005, 5) + 0.25 * np.sin(4 * np.pi * hz(m) * t2) * _env(len(t2), 0.005, 9), st + off * beat, 0.22 * inten)
        pat = [0, 1, 2, 1, 2, 1, 0, 2] if b % 2 == 0 else [2, 1, 0, 1, 2, 0, 1, 2]
        for q in range(8):  # arpeggio / pluck line
            if style == "warm" and q % 2 == 1 and rng.random() < 0.5: continue
            m = ch[pat[q]] + 12 + (12 if (style == "skip" and q in (3, 7)) else 0)
            put(tone(hz(m), 0.5, cfg["tim"]), st + q * beat / 2, 0.075 * inten, pan=0.25 * (1 if q % 2 else -1))
        if b >= 1:  # drums
            for q in range(4):
                t3 = np.arange(int(0.25 * SR)) / SR; f = 110 * np.exp(-t3 * 18) + 45
                put(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t3 * 14), st + q * beat, 0.30 if style != "warm" or q % 2 == 0 else 0.0)
            for q in (1, 3):
                nz = rng.standard_normal(int(0.18 * SR)); nz = sosfiltfilt(butter(2, [900, 5000], "bp", fs=SR, output="sos"), nz)
                put(nz * _env(len(nz), 0.001, 22), st + q * beat, 0.16)
            for q in range(8 if style != "skip" else 16):
                sub = beat / 2 if style != "skip" else beat / 4
                nz = rng.standard_normal(int(0.05 * SR)); nz = sosfiltfilt(butter(2, 7000, "hp", fs=SR, output="sos"), nz)
                put(nz * _env(len(nz), 0.001, 70), st + q * sub, (0.05 if q % 2 else 0.08) * (0.7 if style == "skip" else 1), pan=0.3)
    fade = np.minimum(1, np.arange(n) / (0.4 * SR)) * np.minimum(1, (n - np.arange(n)) / (1.8 * SR))
    out *= fade; return out / (np.abs(out).max() + 1e-9)
def mix_audio(r, style, seed, out_m4a):
    m = music(r.T_END, style, seed); v = r.vo
    env = np.sqrt(lfilter([1], [1, -0.995], v ** 2) * 0.005 + 1e-12); env = np.convolve(env, np.ones(9600) / 9600, "same")
    duck = 1 - 0.45 * np.clip(env / (np.percentile(env, 90) + 1e-9), 0, 1)
    mus = m * duck * 0.16
    st = np.stack([v, v]) + mus
    raw = st.T.astype(np.float32).tobytes()
    meas = subprocess.run(["ffmpeg", "-v", "info", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af",
                           "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"], input=raw, capture_output=True).stderr.decode()
    J = json.loads(meas[meas.rfind("{"):meas.rfind("}") + 1])
    af = (f"loudnorm=I=-14:TP=-1.5:LRA=11:measured_I={J['input_i']}:measured_TP={J['input_tp']}:measured_LRA={J['input_lra']}:"
          f"measured_thresh={J['input_thresh']}:offset={J['target_offset']}:linear=true,aresample=48000")
    run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "pipe:0", "-af", af, "-ar", "48000",
         "-c:a", "aac", "-b:a", "160k", out_m4a], raw)
    print("mix measured", J["input_i"], "->", out_m4a)

# ------------------------------------------------------------------ background
_conf = None
def background(c, t, pal_a, pal_b, u):
    global _conf
    P = [mix(a, b, ease(u)) for a, b in zip(PAL[pal_a], PAL[pal_b])]
    g = cairo.LinearGradient(0, 0, W * 0.35, H); g.add_color_stop_rgba(0, *P[0][:3], 1); g.add_color_stop_rgba(1, *P[1][:3], 1)
    c.set_source(g); c.paint()
    for k, (bx, by, br, sp) in enumerate([(220, 420, 420, 0.21), (880, 1150, 480, 0.17), (430, 1650, 380, 0.25)]):
        x = bx + 90 * math.sin(t * sp + k * 2); y = by + 70 * math.cos(t * sp * 1.3 + k)
        rg = cairo.RadialGradient(x, y, 0, x, y, br); col = P[2 + k]
        rg.add_color_stop_rgba(0, *col[:3], 0.32); rg.add_color_stop_rgba(1, *col[:3], 0)
        c.set_source(rg); c.arc(x, y, br, 0, 2 * math.pi); c.fill()
    if _conf is None:
        R = random.Random(7); _conf = [(R.uniform(60, 1020), R.uniform(0, H), R.uniform(9, 18), R.choice(range(3)), R.uniform(-1, 1), R.uniform(18, 40)) for _ in range(22)]
    for k, (x0, y0, r, shp, rs, sp) in enumerate(_conf):
        y = (y0 - t * sp) % (H + 80) - 40; x = x0 + 18 * math.sin(t * 0.8 + k); col = P[2 + k % 3]
        c.save(); c.translate(x, y); c.rotate(t * rs); sa(c, col, 0.55)
        if shp == 0: c.arc(0, 0, r * 0.6, 0, 2 * math.pi); c.fill()
        elif shp == 1: c.rectangle(-r / 2, -r / 4, r, r / 2); c.fill()
        else:
            c.set_line_width(5); c.set_line_cap(cairo.LINE_CAP_ROUND); c.move_to(-r, 0); c.curve_to(-r / 2, -r, r / 2, r, r, 0); c.stroke()
        c.restore()
    # brand hairline X in the corners
    sa(c, WHITE, 0.10); c.set_line_width(2)
    for (x0, y0, dx, dy) in [(40, 120, 1, 1), (1040, 1800, -1, -1)]:
        c.move_to(x0, y0); c.line_to(x0 + dx * 120, y0 + dy * 120); c.move_to(x0 + dx * 120, y0); c.line_to(x0, y0 + dy * 120); c.stroke()

# ------------------------------------------------------------------ render
def draw_frame(c, t, scenes, subs):
    CUR["t"] = t; starts = [sc["t0"] for sc in scenes]
    k = max([i for i, s0 in enumerate(starts) if s0 <= t] or [0])
    pu = ramp(t, starts[k], starts[k] + 0.6) if k else 1.0
    background(c, t, scenes[k - 1]["pal"] if k else scenes[0]["pal"], scenes[k]["pal"], pu)
    for i, sc in enumerate(scenes):
        a0 = sc["t0"]; a1 = scenes[i + 1]["t0"] if i + 1 < len(scenes) else 1e9
        if t < a0 - 0.01 or t > a1 + 0.2: continue
        al = (1.0 if i == 0 else ramp(t, a0, a0 + 0.2)) * (1 - ramp(t, a1, a1 + 0.2))
        if al <= 0.01: continue
        CUR["scene"] = i; St.a = al; sc["fn"](c, t, sc); St.a = 1.0
    CUR["scene"] = None
    for a, b, ss, x, y, _ in subs:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()
def surf2pil(surf):
    surf.flush(); a = np.ndarray((H, W, 4), np.uint8, surf.get_data()); return Image.fromarray(a[:, :, [2, 1, 0]].copy())
def sheet_of(thumbs, path, tw=390):
    th = int(tw * 16 / 9); cols = 4; rows = -(-len(thumbs) // cols)
    sheet = Image.new("RGB", (cols * (tw + 10) + 10, rows * (th + 52) + 10), (20, 20, 28)); d = ImageDraw.Draw(sheet)
    for k, (tt, im) in enumerate(thumbs):
        x = 10 + (k % cols) * (tw + 10); y = 10 + (k // cols) * (th + 52); sheet.paste(im.resize((tw, th), Image.LANCZOS), (x, y))
        d.text((x + 4, y + th + 4), f"{tt:.2f}s", font=font(36, 700), fill=(255, 255, 255))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sheet.quantize(256, method=Image.Quantize.MEDIANCUT).save(path, optimize=True)
def preview(r, scenes, times, path, tw=390):
    subs = r.subs(); surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); th = []
    for t in times: draw_frame(c, t, scenes, subs); th.append((t, surf2pil(surf)))
    sheet_of(th, path, tw)
def render(r, scenes, out_mp4, m4a, thumbs_at, sheet_png, crf=20, maxrate="1.8M"):
    os.nice(5)
    N = int(math.ceil(r.T_END * FPS)); subs = r.subs()
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "pipe:0", "-i", m4a, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", str(crf),
           "-maxrate", maxrate, "-bufsize", "4M", "-pix_fmt", "yuv420p", "-c:a", "copy", "-shortest", "-movflags", "+faststart", out_mp4]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); thumbs = []; tset = {int(round(x * FPS)): x for x in thumbs_at}
    for fi in range(N):
        t = fi / FPS; draw_frame(c, t, scenes, subs); surf.flush(); p.stdin.write(surf.get_data())
        if fi in tset: thumbs.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 300 == 0: print(r.name, "frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0
    sheet_of(thumbs, sheet_png)
def wait_disk(mb=120):
    import time, shutil
    while shutil.disk_usage("/").free / 1e6 < mb:
        print("waiting for disk", round(shutil.disk_usage("/").free / 1e6), "MB", flush=True); time.sleep(60)
def main(folder, nums, build, style, seed, tail=2.5):
    r = Reel(folder, nums, tail); r.build_vo(); scenes = build(r)
    scr = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad"
    if "--preview" in sys.argv:
        nx = [sc["t0"] for sc in scenes[1:]] + [r.T_END]
        ts = [float(x) for x in sys.argv[sys.argv.index("--preview") + 1].split(",")] if len(sys.argv) > sys.argv.index("--preview") + 1 else \
             [0.0] + [max(0, sc["t0"]) + 0.8 * (b - max(0, sc["t0"])) for sc, b in zip(scenes, nx)]
        preview(r, scenes, ts, f"{scr}/{r.name}_prev.png"); print(json.dumps(qa_report(r, scenes)["issues"])); return
    wait_disk(120)
    m4a = f"{scr}/{r.name}_mix.m4a"; mix_audio(r, style, seed, m4a)
    out = f"{folder}/{r.name}.mp4"; nx = [sc["t0"] for sc in scenes[1:]] + [r.T_END]
    thumbs = [0.0] + [max(0, sc["t0"]) + 0.8 * (b - max(0, sc["t0"])) for sc, b in zip(scenes, nx)]
    render(r, scenes, out, m4a, thumbs, f"{folder}/qa/sheet.png")
    os.remove(m4a); wait_disk(60)
    run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", out, "-c:v", "libx264", "-preset", "medium", "-crf", "26", "-maxrate", "1M",
         "-bufsize", "2M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", f"{folder}/{r.name}_web.mp4"])
    rep = qa_report(r, scenes); rep["T_END"] = r.T_END
    rep["subs"] = [(round(a, 2), round(b, 2), cc) for a, b, *_, cc in r.sub_items]
    json.dump(rep, open(f"{folder}/qa/qa.json", "w"), indent=1, ensure_ascii=False); print(json.dumps(rep["issues"]))

def qa_report(r, scenes):
    rep = {"min_size": None, "issues": [], "cards": {}}
    sizes = [x[2] for x in QA["text"]]; rep["min_size"] = min(sizes)
    for sc_, s, sz, x0, y0, x1, y1, src in QA["text"]:
        if sz < 36: rep["issues"].append(("small", s, sz))
        if x0 < 70 - 1 or x1 > 1010 + 1: rep["issues"].append(("x safe", s, round(x0), round(x1)))
        if y0 < 260 - 30 or y1 > CONTENT_BOTTOM + 25: rep["issues"].append(("y safe", s, round(y0), round(y1)))
        if any(d in s for d in DASHES): rep["issues"].append(("dash", s))
    for sc_, x0, y0, x1, y1 in QA["icons"]:
        if y1 > CONTENT_BOTTOM + 25 or y0 < 230: rep["issues"].append(("icon y", sc_, round(y0), round(y1)))
    for i, sc in enumerate(scenes):
        strs = sorted({s for k, s, sz, *_, src in QA["text"] if k == i and not src and not is_he(s)})
        words = sum(len([w for w in re.split(r"\s+", s) if re.search(r"[A-Za-z]", w)]) for s in strs)
        hes = sorted({s for k, s, *_ in QA["text"] if k == i and is_he(s)})
        a1 = scenes[i + 1]["t0"] if i + 1 < len(scenes) else r.T_END
        rep["cards"][i] = dict(t0=round(sc["t0"], 2), dur=round(a1 - max(0, sc["t0"]), 2), words=words, text=strs, he=hes)
        if words > 12: rep["issues"].append(("words>12", i, words))
        if a1 - max(0, sc["t0"]) < 3.0: rep["issues"].append(("card<3s", i, round(a1 - max(0, sc["t0"]), 2)))
    return rep
