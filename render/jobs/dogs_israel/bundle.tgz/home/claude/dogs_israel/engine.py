"""dogs_israel: "If dogs ran Israel". Deadpan satire, a flat-illustration gag per line, companion to cats_israel.
python3 engine.py [--frames t1,t2,...] [--out path.mp4]      (DIR = this folder: timing.json, mix.m4a)
Layout (shared with the cats reel): night-to-navy gradient, sky scene label pill at the top, one big punchline,
illustration in the middle, subtitles at the bottom. Circular: the last 0.9 s cross-fade into frame 0."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"

def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def shade(c, f): return (c[0] * f, c[1] * f, c[2] * f, c[3])
def tint(c, f): return (c[0] + (1 - c[0]) * f, c[1] + (1 - c[1]) * f, c[2] + (1 - c[2]) * f, c[3])

NIGHT, NAVY, SKY, GOLD = hx("#0B1426"), hx("#163261"), hx("#45A4DD"), hx("#FFCD50")
WHITE = (1, 1, 1, 1); INK = hx("#1B1F2A"); PINK = hx("#F28CA0"); OLIVE = hx("#6F7F3A"); RED = hx("#E2574C")
CREAM, TAN, BROWN, CHOC, GREYD, SNOW = hx("#F3E3C3"), hx("#D9A066"), hx("#A8693F"), hx("#6B4430"), hx("#9AA5B4"), hx("#FAFAFA")
COATS = [TAN, CREAM, BROWN, GOLD, SNOW, CHOC, GREYD]

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0, rot=0.0):
    """draw s with its baseline at y; align c/l/r on x"""
    if a <= 0.01 or sc <= 0.01: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y - size * 0.35); c.rotate(rot); c.scale(sc, sc); c.translate(-x, -(y - size * 0.35))
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def rich(c, parts, size, x, y, w=900, a=1.0, sc=1.0, hl=GOLD):
    """parts: '*word*' highlighted in gold; centred on x"""
    toks = re.split(r"(\*[^*]+\*)", parts); toks = [t for t in toks if t]
    f = font(size, w); tot = sum(f.getlength(t.strip("*")) for t in toks); cx = x - tot / 2
    c.save(); c.translate(x, y - size * 0.35); c.scale(sc, sc); c.translate(-x, -(y - size * 0.35))
    for t_ in toks:
        s = t_.strip("*"); text(c, s, size, cx, y, w, hl if t_.startswith("*") else WHITE, a, "l"); cx += f.getlength(s)
    c.restore()
def fit(s, size, maxw, w=900, mn=64):
    while size > mn and font(size, w).getlength(s.replace("*", "")) > maxw: size -= 2
    return size
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def ell(c, cx, cy, rx, ry):
    c.save(); c.translate(cx, cy); c.scale(max(rx, 0.01), max(ry, 0.01)); c.new_sub_path(); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()
def fill(c, col, a=1.0): c.set_source_rgba(col[0], col[1], col[2], col[3] * a); c.fill()
def stroke(c, col, w, a=1.0):
    c.set_source_rgba(col[0], col[1], col[2], col[3] * a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND); c.stroke()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()

# ------------------------------------------------------------------ the dog
def head(c, coat, t, ph=0.0, bark=0.0, tongue=True, ears="flop", acc=(), eyes="open", wind=0.0):
    """dog head, centred at (0,0), radius 62, looking right"""
    dark = shade(coat, 0.72); light = tint(coat, 0.45)
    op = max(0.0, math.sin((t + ph) * 11)) * bark          # mouth opening 0..1
    flap = math.sin((t + ph) * 7) * 0.15
    def ear(far):
        c.save(); c.translate(-28 if not far else 6, -46)
        if ears == "wind":
            c.rotate(-1.35 + math.sin((t + ph) * 30) * 0.18)
        else:
            c.rotate((0.12 if not far else -0.25) + flap + op * 0.25)
        c.move_to(-6, 0); c.curve_to(-40, 8, -44, 62, -22, 78); c.curve_to(-6, 86, 10, 50, 14, 4); c.close_path()
        fill(c, dark if not far else shade(coat, 0.6)); c.restore()
    if ears == "up":
        for ex, rot in ((-30, -0.25), (14, 0.2)):
            c.save(); c.translate(ex, -40); c.rotate(rot); c.move_to(-20, 8); c.line_to(0, -52); c.line_to(22, 8); c.close_path(); fill(c, dark); c.restore()
    else:
        ear(True)
    ell(c, 0, 0, 62, 60); fill(c, coat)
    if "patch" in acc: ell(c, 14, -14, 26, 24); fill(c, dark)
    ell(c, 50, 20, 42, 30); fill(c, light)                                  # snout
    ell(c, 86, 8, 14, 11); fill(c, INK)                                     # nose
    ell(c, 82, 4, 4, 3); fill(c, WHITE, 0.6)
    if eyes == "closed":
        c.move_to(8, -14); c.curve_to(14, -6, 26, -6, 32, -14); stroke(c, INK, 6)
    else:
        ell(c, 20, -14, 10, 11); fill(c, INK); ell(c, 23, -18, 3.6, 3.6); fill(c, WHITE)
    if op > 0.05:                                                           # barking mouth
        c.move_to(28, 36); c.curve_to(40, 36 + 40 * op, 74, 36 + 40 * op, 84, 30); c.close_path(); fill(c, hx("#5A1E2A"))
        ell(c, 58, 40 + 22 * op, 12, 7 * op); fill(c, PINK)
    else:
        c.move_to(40, 36); c.curve_to(52, 46, 66, 46, 78, 34); stroke(c, INK, 5)
        if tongue:
            sw = math.sin((t + ph) * 9) * 4
            c.save(); c.translate(58 + sw, 42); rr(c, -11, -2, 22, 34, 11); fill(c, PINK); c.move_to(0, 6); c.line_to(0, 22); stroke(c, shade(PINK, 0.8), 3); c.restore()
    if ears != "up": ear(False)
    if "glasses" in acc:
        c.arc(20, -14, 19, 0, 2 * math.pi); stroke(c, INK, 5); c.move_to(-1, -16); c.line_to(-30, -20); stroke(c, INK, 5)
    if "scarf" in acc:
        c.move_to(-70, 10); c.curve_to(-72, -70, 40, -90, 58, -30); c.curve_to(20, -52, -30, -48, -46, 22); c.close_path(); fill(c, SKY)
        for dx, dy in ((-30, -50), (0, -60), (25, -50), (-50, -20)): ell(c, dx, dy, 6, 6); fill(c, WHITE, 0.9)
    if "cap" in acc:
        c.save(); c.translate(-6, -52); c.rotate(-0.18); ell(c, 0, 0, 60, 22); fill(c, OLIVE); rr(c, -54, -4, 108, 14, 7); fill(c, shade(OLIVE, 0.75)); c.restore()
    if "kippah" in acc:
        c.save(); c.translate(-10, -57); c.rotate(-0.15); c.arc(0, 8, 30, math.pi, 2 * math.pi); c.close_path(); fill(c, SKY); c.restore()

def dog(c, x, y, s, coat, t, face=1, ph=0.0, bark=0.0, wag=1.0, tongue=True, acc=(), walk=0.0, eyes="open", ears="flop", jump=0.0, tilt=0.0):
    """standing dog, ground point (x, y), body about 250*s wide, faces right if face=1"""
    dark = shade(coat, 0.72)
    c.save(); c.translate(x, y - jump); c.scale(s * face, s)
    bob = -abs(math.sin((t + ph) * 11)) * 7 * bark - (abs(math.sin((t + ph) * 8)) * 5 if walk else 0)
    c.translate(0, bob); c.rotate(tilt)
    a = 0.55 * math.sin((t + ph) * 17) * wag
    c.save(); c.translate(-108, -130); c.rotate(-0.75 + a)
    c.move_to(0, 0); c.curve_to(-14, -36, -34, -64, -16, -96); stroke(c, dark, 20); c.restore()
    for lx, k, far in ((-46, 0, True), (78, 1, True), (-80, 1, False), (44, 0, False)):
        sw = math.sin((t + ph) * 10 + k * math.pi) * 14 * walk
        c.save(); c.translate(lx, -82); c.rotate(sw / 60)
        rr(c, -15, 0, 30, 84, 15); fill(c, shade(coat, 0.62) if far else coat); c.restore()
    rr(c, -125, -178, 250, 108, 54); fill(c, coat)
    ell(c, 0, -96, 80, 22); fill(c, tint(coat, 0.35))
    if "patch" in acc: ell(c, -40, -150, 40, 26); fill(c, dark)
    if "tie" in acc:
        c.move_to(78, -150); c.line_to(98, -150); c.line_to(104, -70); c.line_to(88, -54); c.line_to(72, -70); c.close_path(); fill(c, SKY)
    if "vest" in acc:
        rr(c, -60, -180, 110, 110, 20); fill(c, OLIVE)
    c.save(); c.translate(108, -196)
    head(c, coat, t, ph, bark, tongue, ears, acc, eyes)
    c.restore(); c.restore()

def sit_dog(c, x, y, s, coat, t, face=1, ph=0.0, bark=0.0, wag=1.0, acc=(), tongue=True, eyes="open"):
    """sitting dog, seen in three-quarter view, ground point (x, y)"""
    dark = shade(coat, 0.72)
    c.save(); c.translate(x, y); c.scale(s * face, s)
    a = 0.5 * math.sin((t + ph) * 16) * wag
    c.save(); c.translate(-70, -30); c.rotate(-2.2 + a); c.move_to(0, 0); c.curve_to(-10, -30, -30, -50, -12, -80); stroke(c, dark, 20); c.restore()
    ell(c, -30, -50, 70, 52); fill(c, dark)
    rr(c, -70, -230, 140, 220, 64); fill(c, coat)
    ell(c, 0, -110, 40, 70); fill(c, tint(coat, 0.4))
    for lx in (-30, 30): rr(c, lx - 15, -90, 30, 90, 15); fill(c, coat)
    for lx in (-30, 30): ell(c, lx, -4, 22, 10); fill(c, tint(coat, 0.2))
    if "tie" in acc:
        c.move_to(-12, -200); c.line_to(12, -200); c.line_to(18, -110); c.line_to(0, -92); c.line_to(-18, -110); c.close_path(); fill(c, SKY)
    c.save(); c.translate(10, -260); head(c, coat, t, ph, bark, tongue, "flop", acc, eyes); c.restore()
    c.restore()

def woof(c, x, y, sz, a, rot=0.0, word="WOOF!"):
    text(c, word, sz, x, y, 900, GOLD, a, "c", 1.0, rot)

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    if not ws: return LINES[li]["t0"]
    return ws[min(nth, len(ws) - 1)]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
NL = len(LINES)
END = round(LINES[-1]["t1"] + 1.0, 2)
T_FADE = END - 0.8
CUT = [0.0] + [lt(i) - 0.12 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1

# ------------------------------------------------------------------ background + shared layout
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NIGHT[:3], 1); g.add_color_stop_rgba(0.55, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1D427F")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1000, 720, SKY, 0.16); return s
BG = bg_surface()
LABEL_Y = 300          # scene label pill (top)
HEAD_Y = 470           # punchline baseline
def label(c, s, a):
    if a <= 0.01: return
    sz = 46; tw = font(sz, 800).getlength(s); x0 = 540 - tw / 2 - 30
    rr(c, x0, LABEL_Y - 40, tw + 60, 80, 40); fill(c, SKY, a)
    text(c, s, sz, 540, LABEL_Y + 16, 800, WHITE, a)
def headline(c, s, a, y=HEAD_Y, size=84, sc=1.0):
    rich(c, s, fit(s, size, 940), 540, y, 900, a, sc)
def ground(c, y, col=None, a=1.0):
    rr(c, 60, y, 960, 18, 9); fill(c, col or shade(NAVY, 0.7), a)
def stamp(c, s, x, y, u, rot=-0.12, size=110):
    if u <= 0.01: return
    sc = lerp(1.9, 1.0, eout(u)); a = clamp(u * 3)
    f = font(size, 900); tw = f.getlength(s)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc)
    rr(c, -tw / 2 - 34, -size * 0.95, tw + 68, size * 1.3, 26); c.set_source_rgba(*GOLD[:3], a); c.set_line_width(10); c.stroke()
    text(c, s, size, 0, size * 0.18, 900, GOLD, a); c.restore()
def counter_text(c, s, x, y, size, a, col=GOLD, sc=1.0): text(c, s, size, x, y, 900, col, a, "c", sc)

# ------------------------------------------------------------------ scenes (one per script line)
def sc_hook(c, t, u, end=False):
    # frame 0 must show the whole hook; the end card reuses this layout with its lead-in line
    br = 1 + 0.012 * math.sin(t * 3)
    if end:
        rich(c, "Would anyone", 130, 540, 480, 900, 1, br); rich(c, "even *notice...*", 130, 540, 670, 900, 1, br)
    else:
        rich(c, "If *dogs*", 190, 540, 480, 900, 1, br)
        rich(c, "ran Israel...", 160, 540, 670, 900, 1, br)
    glow(c, 540, 1180, 420, GOLD, 0.10)
    ground(c, 1470)
    dog(c, 430, 1470, 2.05, TAN, t, bark=0.0, wag=1.4, acc=("tie",))
    # little flag on a stick
    fx, fy = 850, 1470; c.move_to(fx, fy); c.line_to(fx, fy - 330); stroke(c, WHITE, 8)
    wv = math.sin(t * 4) * 8
    c.move_to(fx, fy - 330); c.curve_to(fx + 60, fy - 340 + wv, fx + 110, fy - 320 - wv, fx + 150, fy - 330)
    c.line_to(fx + 150, fy - 230); c.curve_to(fx + 110, fy - 220 - wv, fx + 60, fy - 240 + wv, fx, fy - 230); c.close_path(); fill(c, WHITE)
    for dy in (-318, -244): c.move_to(fx + 6, fy + dy); c.line_to(fx + 146, fy + dy); stroke(c, SKY, 9)
    sx, sy = fx + 76, fy - 281
    for k in (0, 1):
        r = 20; ang = math.pi / 2 + k * math.pi
        c.move_to(sx + r * math.cos(ang - math.pi / 2), sy - r * math.sin(ang - math.pi / 2)) if False else None
        pts = [(sx + r * math.cos(-math.pi / 2 + k * math.pi / 3 + j * 2 * math.pi / 3), sy + r * math.sin(-math.pi / 2 + k * math.pi / 3 + j * 2 * math.pi / 3)) for j in range(3)]
        c.move_to(*pts[0]); c.line_to(*pts[1]); c.line_to(*pts[2]); c.close_path(); stroke(c, SKY, 4)

def sc_knesset(c, t, u):
    L = 1; label(c, "THE KNESSET", 1)
    t120 = wt(L, "hundred") - 0.1
    v = int(120 * eout((t - t120) / 1.1)) if t >= t120 else 0
    counter_text(c, f"{v}" if v else "120", 540, 560, 190, 1 if v else 0.0)
    text(c, "members", 60, 540, 640, 800, WHITE, ramp(t, t120, t120 + 0.3))
    # horseshoe of heads
    cx, cy = 540, 1430; k = 0; rng = np.random.default_rng(3)
    for row, (R, n, s) in enumerate(((430, 13, 0.6), (320, 10, 0.6), (210, 7, 0.6))):
        for i in range(n):
            ang = math.pi + (i + 0.5) / n * math.pi
            x = cx + R * math.cos(ang); y = cy + R * 1.05 * math.sin(ang)
            ph = rng.uniform(0, 3); coat = COATS[k % len(COATS)]; k += 1
            barking = ramp(t, wt(L, "barking") - 0.3, wt(L, "barking"))
            c.save(); c.translate(x, y); c.scale(s, s)
            ell(c, 0, 70, 70, 40); fill(c, shade(coat, 0.8))
            c.scale(-1 if x > cx else 1, 1); head(c, coat, t, ph, barking, False, "flop", ())
            c.restore()
    # chair of the speaker (empty podium)
    rr(c, cx - 90, cy - 90, 180, 110, 18); fill(c, SKY)
    text(c, "ORDER?", 44, cx, cy - 22, 900, WHITE, 1)
    tb = wt(L, "barking") - 0.2
    if t > tb:
        for j in range(6):
            p = ((t - tb) * 1.6 + j / 6) % 1
            bx = 180 + (j * 157) % 720; by = 820 + (j * 97) % 380 - p * 60
            woof(c, bx, by, 58, math.sin(p * math.pi), (j % 3 - 1) * 0.15)
    ts = wt(L, "same") - 0.05
    if t > ts:
        c.set_source_rgba(*NIGHT[:3], 0.55 * ramp(t, ts, ts + 0.2)); c.paint()
        stamp(c, "SAME AS NOW.", 540, 1060, (t - ts) / 0.35)

def sc_door(c, t, u):
    L = 2; label(c, "HOSPITALITY", 1)
    headline(c, "Nine dogs. *One* guest.", 1)
    # house front
    rr(c, 170, 760, 740, 720, 30); fill(c, shade(NAVY, 1.25))
    rr(c, 430, 980, 220, 490, 110); fill(c, GOLD, 0.9)
    ell(c, 610, 1240, 12, 12); fill(c, INK)
    text(c, "WELCOME", 56, 540, 905, 900, WHITE, 0.9)
    ground(c, 1470)
    gx = 540; tj = wt(L, "Nine")
    guest_tilt = -0.25 * ramp(t, tj + 0.3, tj + 0.9)
    dog(c, gx, 1470, 0.95, SNOW, t, wag=0.4, tongue=False, eyes="open", tilt=guest_tilt)
    rr(c, gx - 190, 1390, 80, 64, 10); fill(c, SKY)        # suitcase
    rng = np.random.default_rng(9)
    for j in range(9):
        t0 = tj + 0.12 * j; p = clamp((t - t0) / 0.5)
        if p <= 0: continue
        side = -1 if j % 2 == 0 else 1
        sx = 540 + side * 700; ex = 540 + side * (60 + 55 * (j // 2)) + rng.uniform(-30, 30)
        ey = 1470 - 70 * (j % 3) - 40
        x = lerp(sx, ex, eout(p)); jump = math.sin(p * math.pi) * 220
        dog(c, x, ey, 0.62, COATS[j % len(COATS)], t, face=-side, ph=j * 0.4, bark=0.6, wag=1.6, jump=jump + 12 * abs(math.sin(t * 9 + j)))
    if t > tj:
        n = min(9, int((t - tj) / 0.12) + 1); counter_text(c, str(n), 900, 760, 150, 1)
    tw = wt(L, "welcome") - 0.1
    if t > tw: stamp(c, "WELCOME!", 540, 700, (t - tw) / 0.35, -0.08, 100)

def sc_food(c, t, u):
    L = 3; label(c, "GRANDMA", 1)
    ground(c, 1470)
    rr(c, 330, 1250, 600, 40, 20); fill(c, shade(NAVY, 1.4))       # table
    for lx in (380, 880): rr(c, lx - 12, 1290, 24, 180, 12); fill(c, shade(NAVY, 1.4))
    sit_dog(c, 230, 1470, 1.3, GREYD, t, face=1, ph=0.2, bark=0.5 * ramp(t, wt(L, "Eat") - 0.2, wt(L, "Eat")), acc=("glasses", "scarf"), tongue=False)
    dog(c, 860, 1470, 0.85, TAN, t, face=-1, wag=0.2, tongue=False, eyes="closed")
    eats = [wt(L, "Eat", 0), wt(L, "Eat", 1), wt(L, "Eat", 2)]
    nb = sum(1 for e in eats if t >= e - 0.1) + (1 if t >= wt(L, "brings") else 0)
    for b in range(nb):
        x = 560 + (b % 2) * 140 - (b // 2) * 10; y = 1250 - (b // 2) * 70 - (b % 2) * 20
        ell(c, x, y - 18, 70, 26); fill(c, SKY); ell(c, x, y - 34, 60, 14); fill(c, GOLD)
    sizes = [(90, 760), (130, 900), (210, 1080)]
    for k, e in enumerate(eats):
        if t >= e - 0.05:
            sz, y = sizes[k]; p = clamp((t - e + 0.05) / 0.25)
            shake = math.sin(t * 60) * 6 if k == 2 else 0
            text(c, "Eat." if k < 2 else "EAT!", sz, 540 + shake, y, 900, GOLD if k == 2 else WHITE, 1, "c", lerp(1.6, 1.0, eout(p)))
    th = wt(L, "Not")
    if th <= t < eats[0] - 0.05:
        text(c, "Not hungry?", 84, 540, 760, 900, WHITE, ramp(t, th, th + 0.2))

def sc_sniff(c, t, u):
    L = 4; label(c, "SMALL TALK", 1)
    ground(c, 1470)
    ts = wt(L, "sniff"); gap = lerp(260, 150, ramp(t, ts - 0.3, ts + 0.2))
    dog(c, 540 - gap - 110, 1470, 0.9, BROWN, t, face=1, wag=1.2, tongue=False)
    dog(c, 540 + gap + 110, 1470, 0.9, CREAM, t, face=-1, ph=1.0, wag=1.2, tongue=False, acc=("patch",))
    if t > ts:
        for j in range(3):
            p = ((t - ts) * 2 + j / 3) % 1; x = 540 + (j - 1) * 28; y = 1240 - p * 120
            c.move_to(x, y); c.curve_to(x + 14, y - 15, x - 14, y - 30, x, y - 45); stroke(c, WHITE, 5, math.sin(p * math.pi) * 0.8)
        text(c, "sniff sniff", 64, 540, 1100, 800, SKY, ramp(t, ts, ts + 0.2) * (1 - ramp(t, wt(L, "Then") - 0.2, wt(L, "Then"))))
    tq = wt(L, "Then") - 0.1
    if t > tq:
        p = eob(clamp((t - tq) / 0.35))
        c.save(); c.translate(540, 820); c.scale(p, p)
        rr(c, -440, -150, 880, 260, 60); fill(c, WHITE)
        c.move_to(180, 100); c.line_to(250, 190); c.line_to(260, 100); c.close_path(); fill(c, WHITE)
        text(c, "So, how much", 82, 0, -30, 900, NAVY, 1); text(c, "do you earn?", 82, 0, 70, 900, NAVY, 1)
        c.restore()
    else:
        headline(c, "Step one: *sniff.*", ramp(t, ts - 0.2, ts))

def sc_friday(c, t, u):
    L = 5; label(c, "FRIDAY", 1)
    headline(c, "Everyone to *grandma's.*", 1)
    # road sign
    rr(c, 640, 600, 360, 150, 22); fill(c, hx("#1E8A55")); rr(c, 652, 612, 336, 126, 16); stroke(c, WHITE, 5)
    text(c, "Grandma", 56, 820, 670, 800, WHITE, 1); text(c, "12 km", 50, 820, 726, 800, GOLD, 1)
    c.move_to(820, 750); c.line_to(820, 860); stroke(c, GREYD, 12)
    # road
    rr(c, 0, 1160, W, 330, 0); fill(c, hx("#1A2236"))
    for k in range(9):
        x = ((k * 180 - t * 520) % 1260) - 90; rr(c, x, 1318, 100, 16, 8); fill(c, GOLD, 0.8)
    ts = lt(L)
    for j, (lane, coat, col) in enumerate(((1260, TAN, SKY), (1440, SNOW, RED), (1260, BROWN, GOLD))):
        x = ((j * 560 + (t - ts) * 300) % 1680) - 300
        y = lane + math.sin(t * 20 + j) * 2
        c.save(); c.translate(x, y)
        rr(c, -200, -150, 400, 130, 40); fill(c, col)
        rr(c, -120, -240, 230, 110, 40); fill(c, tint(col, 0.2))
        rr(c, -95, -222, 180, 80, 20); fill(c, hx("#BFE3F6"))
        for wx in (-120, 120): ell(c, wx, -20, 44, 44); fill(c, INK); ell(c, wx, -20, 18, 18); fill(c, GREYD)
        c.save(); c.translate(120, -250); c.scale(0.95, 0.95); head(c, coat, t, j, 0, True, "wind", ()); c.restore()
        c.restore()

def sc_beach(c, t, u):
    L = 6; label(c, "THE BEACH", 1)
    ts = lt(L); t6 = wt(L, "Six")
    # sky panel + sea + sand
    rr(c, 60, 560, 960, 940, 50); c.save(); c.clip()
    sun_u = ramp(t, ts, CUT[L + 1])
    g = cairo.LinearGradient(0, 560, 0, 1100); g.add_color_stop_rgba(0, *lerp_col(SKY, hx("#F08A5D"), sun_u)[:3], 1); g.add_color_stop_rgba(1, *lerp_col(tint(SKY, 0.4), hx("#FFCD50"), sun_u)[:3], 1)
    c.set_source(g); c.paint()
    ell(c, 760, lerp(700, 1050, sun_u), 70, 70); fill(c, hx("#FFF3C4"))
    rr(c, 0, 1050, W, 120, 0); fill(c, hx("#2C7FC0"))
    for k in range(5):
        x = ((k * 220 + t * 60) % 1200) - 100; c.move_to(x, 1080); c.curve_to(x + 30, 1066, x + 60, 1094, x + 90, 1080); stroke(c, WHITE, 5, 0.7)
    rr(c, 0, 1160, W, 400, 0); fill(c, hx("#F2D39A"))
    c.restore()
    # ball arcs back and forth, dog chases
    per = 1.6; p = ((t - ts) / per) % 1; leg = int((t - ts) / per) % 2
    bx = lerp(260, 820, p) if leg == 0 else lerp(820, 260, p); by = 1380 - math.sin(p * math.pi) * 380
    dx = lerp(240, 780, ease(p)) if leg == 0 else lerp(780, 240, ease(p))
    dog(c, dx, 1450, 0.95, GOLD, t, face=1 if leg == 0 else -1, wag=1.5, walk=1.0)
    ell(c, bx, by, 26, 26); fill(c, hx("#C8E04A")); c.arc(bx, by, 18, 0.4, 2.6); stroke(c, WHITE, 4)
    # clock counter
    hrs = 6 * ramp(t, t6 - 1.0, t6 + 0.4) if t > ts + 0.4 else 0
    h_ = int(hrs); m_ = int((hrs - h_) * 60)
    rr(c, 330, 620, 420, 150, 34); fill(c, NIGHT, 0.75)
    counter_text(c, f"{h_}:{m_:02d} h", 540, 735, 110, 1)
    tn = wt(L, "nobody")
    if t > tn: stamp(c, "NOBODY LEFT.", 540, 960, (t - tn) / 0.35, 0.08, 96)

def lerp_col(a, b, u): return tuple(lerp(a[i], b[i], u) for i in range(4))

def sc_army(c, t, u):
    L = 7; label(c, "THE ARMY", 1)
    tg = wt(L, "guards"); tm = wt(L, "Mostly")
    headline(c, "Everybody *serves.*" if t < tm - 0.1 else "Mostly *the fridge.*", 1)
    ground(c, 1470)
    # fridge
    fx = 700
    rr(c, fx, 820, 280, 650, 34); fill(c, SNOW); c.move_to(fx, 1060); c.line_to(fx + 280, 1060); stroke(c, GREYD, 6)
    rr(c, fx + 26, 900, 14, 110, 7); fill(c, GREYD); rr(c, fx + 26, 1100, 14, 160, 7); fill(c, GREYD)
    for k, (mx, my, col) in enumerate(((fx + 120, 900, RED), (fx + 200, 950, SKY), (fx + 160, 1150, GOLD))):
        ell(c, mx, my, 22, 22); fill(c, col)
    glow(c, fx + 140, 1100, 330, GOLD, 0.18 * ramp(t, tm - 0.1, tm + 0.3))
    # guard dog, proud, with cap; tiny guard post sign
    dog(c, 360, 1470, 1.1, CHOC, t, face=1, wag=0.15, tongue=False, acc=("cap",), ears="up")
    rr(c, 90, 700, 360, 120, 20); fill(c, OLIVE)
    text(c, "GUARD POST", 50, 270, 778, 900, WHITE, 1)
    if t > tm: stamp(c, "ON DUTY", 300, 930, (t - tm) / 0.35, 0.1, 70)

def sc_startup(c, t, u):
    L = 8; label(c, "THE STARTUP NATION", 1)
    te = wt(L, "Exit")
    # phone
    px, py, pw, ph_ = 340, 560, 400, 760
    rr(c, px - 14, py - 14, pw + 28, ph_ + 28, 70); fill(c, INK)
    rr(c, px, py, pw, ph_, 56); c.save(); c.clip()
    c.set_source_rgba(*hx("#DCEFFA")[:3], 1); c.paint()
    for k in range(7): c.move_to(px, py + 160 + k * 100 + (k % 2) * 30); c.line_to(px + pw, py + 110 + k * 100); stroke(c, WHITE, 18)
    for k in range(4): c.move_to(px + 60 + k * 110, py + 60); c.line_to(px + 20 + k * 120, py + ph_); stroke(c, WHITE, 16)
    rr(c, px, py, pw, 120, 0); fill(c, SKY)
    text(c, "Fetch", 64, px + pw / 2, py + 90, 900, WHITE, 1)
    # route to ball
    c.move_to(px + 90, py + ph_ - 90); c.curve_to(px + 150, py + 500, px + 300, py + 480, px + 280, py + 300); c.set_dash([18, 14]); stroke(c, SKY, 10); c.set_dash([])
    bb = abs(math.sin(t * 5)) * 30
    ell(c, px + 280, py + 300 - bb, 34, 34); fill(c, hx("#C8E04A")); c.arc(px + 280, py + 300 - bb, 24, 0.4, 2.6); stroke(c, WHITE, 5)
    text(c, "Ball found!", 52, px + pw / 2, py + ph_ - 40, 800, NAVY, ramp(t, wt(L, "finds"), wt(L, "finds") + 0.3))
    c.restore()
    dog(c, 200, 1470, 0.7, GOLD, t, face=1, wag=1.6)
    ground(c, 1470)
    if t > te - 0.1:
        v = 1.1 * eout((t - te + 0.1) / 1.4)
        rr(c, 120, 1500 - 10, 840, 0, 0)
        c.set_source_rgba(*NIGHT[:3], 0.6 * ramp(t, te - 0.1, te + 0.2)); c.paint()
        text(c, "EXIT", 90, 540, 900, 900, WHITE, ramp(t, te - 0.1, te + 0.2))
        counter_text(c, f"${v:.1f} billion", 540, 1090, 140, ramp(t, te - 0.1, te + 0.2))
    else:
        headline(c, "An app that finds *the ball.*", ramp(t, wt(L, "app") - 0.2, wt(L, "app")) * 0 + 1, y=470)

def sc_shabbat(c, t, u):
    L = 9; label(c, "SHABBAT, 5 PM", 1)
    ts = lt(L); te = wt(L, "Everyone")
    headline(c, "Everyone sniffs *everyone.*" if t > te - 0.1 else "The whole street. *Walking.*", 1)
    # sunset street
    rr(c, 60, 600, 960, 900, 50); c.save(); c.clip()
    g = cairo.LinearGradient(0, 600, 0, 1300); g.add_color_stop_rgba(0, *hx("#2B3E7A")[:3], 1); g.add_color_stop_rgba(1, *hx("#F3A35C")[:3], 1); c.set_source(g); c.paint()
    for k, (bx, bw, bh) in enumerate(((60, 200, 380), (280, 160, 300), (460, 220, 420), (700, 170, 330), (890, 160, 380))):
        rr(c, bx, 1300 - bh, bw, bh, 10); fill(c, hx("#1C2B57"))
        for wy in range(int(1300 - bh + 40), 1280, 70):
            for wx in range(bx + 25, bx + bw - 30, 55): rr(c, wx, wy, 26, 34, 5); fill(c, GOLD, 0.65)
    rr(c, 0, 1300, W, 220, 0); fill(c, hx("#3A3F55"))
    c.restore()
    for j in range(5):
        x = ((j * 300 + (t - ts) * 140) % 1500) - 180
        meet = te - 0.1
        dog(c, x, 1470, 0.68, COATS[j % len(COATS)], t, face=1, ph=j * 0.7, walk=1.0, wag=1.3, acc=("kippah",) if j % 3 == 0 else ())
    if t > te:
        for j in range(4):
            x = 200 + j * 230; woof(c, x, 1130 - (j % 2) * 50, 56, ramp(t, te + j * 0.15, te + j * 0.15 + 0.2), (j % 2 - 0.5) * 0.2, "hi!")

def person(c, x, y, s, col, a=1.0):
    ell(c, x, y - 70 * s, 22 * s, 22 * s); fill(c, col, a)
    rr(c, x - 30 * s, y - 42 * s, 60 * s, 62 * s, 28 * s); fill(c, col, a)

def sc_fact(c, t, u):
    L = 10; label(c, "THE REAL PART", 1)
    t1 = wt(L, "one"); t17 = wt(L, "seventeen")
    text(c, "Tel Aviv", 84, 540, 470, 900, WHITE, 1)
    # one dog vs 17 people
    if t > t1 - 0.15:
        p = eob(clamp((t - t1 + 0.15) / 0.4))
        c.save(); c.translate(540, 900); c.scale(p, p); dog(c, -10, 0, 0.95, GOLD, t, wag=1.5); c.restore()
        counter_text(c, "1 dog", 540, 1010, 96, ramp(t, t1, t1 + 0.2))
    n = int(clamp((t - (t17 - 0.6)) / 0.6) * 17) if t > t17 - 0.6 else 0
    for k in range(n):
        r_ = k // 9; i = k % 9; cnt = 9 if r_ == 0 else 8
        x = 540 + (i - (cnt - 1) / 2) * 104; y = 1200 + r_ * 150
        person(c, x, y, 1.15, SKY)
    if n:
        text(c, f"for every {n} people", 72, 540, 1470, 900, WHITE, 1)
    text(c, "Source: Tel Aviv municipality vet, via AFP, 2016", 38, 540, 1530, 400, tint(SKY, 0.5), 1)

def cat_head(c, x, y, s, t):
    c.save(); c.translate(x, y); c.scale(s, s)
    for sx in (-1, 1):
        c.move_to(sx * 20, -40); c.line_to(sx * 56, -80); c.line_to(sx * 60, -10); c.close_path(); fill(c, GREYD)
    ell(c, 0, 0, 66, 58); fill(c, GREYD)
    for sx in (-1, 1):
        ell(c, sx * 24, -6, 14, 6); fill(c, INK); rr(c, sx * 24 - 15, -14, 30, 9, 3); fill(c, GREYD)
    ell(c, 0, 16, 7, 5); fill(c, PINK)
    for sx in (-1, 1):
        for dy in (-6, 6): c.move_to(sx * 30, 22 + dy); c.line_to(sx * 80, 18 + dy * 2); stroke(c, WHITE, 3, 0.8)
    c.restore()

def sc_traits(c, t, u):
    L = 11; label(c, "IN SHORT", 1)
    words = [("Loud.", "Loud"), ("Loyal.", "Loyal"), ("Way too friendly.", "Way")]
    for k, (s, w_) in enumerate(words):
        tw0 = wt(L, w_) - 0.08
        if t >= tw0:
            p = clamp((t - tw0) / 0.25); sz = 150 if k < 2 else 110
            text(c, s, sz, 540, 640 + k * 190, 900, GOLD if k == 2 else WHITE, 1, "c", lerp(1.5, 1.0, eout(p)))
    tb = wt(L, "Still") - 0.1
    if t > tb:
        p = eob(clamp((t - tb) / 0.35))
        c.save(); c.translate(540, 1300); c.scale(p, p)
        rr(c, -440, -110, 880, 220, 60); fill(c, SKY)
        rich(c, "Still better than", 72, 60, -14, 900, 1); rich(c, "*the cats.*", 72, 60, 70, 900, 1, 1.0, NIGHT)
        cat_head(c, -310, 0, 1.15, t)
        c.restore()
    else:
        dog(c, 540, 1470, 0.8, TAN, t, bark=1.0, wag=1.6)

def sc_end(c, t, u):
    sc_hook(c, t, u, end=True)

SCENES = [sc_hook, sc_knesset, sc_door, sc_food, sc_sniff, sc_friday, sc_beach, sc_army, sc_startup, sc_shabbat, sc_fact, sc_traits, sc_end]
assert len(SCENES) == NL, (len(SCENES), NL)

# ------------------------------------------------------------------ subtitles
REPL = [("A hundred and twenty", "120"), ("one point one billion dollars.", "$1.1 billion."), ("five pm.", "5 pm."),
        ("seventeen people.", "17 people."), ("Six hours", "6 hours"), ("Nine dogs", "9 dogs")]
SUB_BOTTOM = 1680
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]; toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower() == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; toks.append(dict(w=b_, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;")
    return items
SUBS = build_subs()
SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.82); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = scene_at(t); u = t - CUT[i]
    if i == 0 or u > 0.18:
        SCENES[i](c, t, u)
    else:                                   # quick pop-in for every new scene
        p = eout(u / 0.18); c.save(); c.translate(540, 960); c.scale(lerp(0.94, 1, p), lerp(0.94, 1, p)); c.translate(-540, -960)
        c.push_group(); SCENES[i](c, t, u); c.pop_group_to_source(); c.paint_with_alpha(p); c.restore()
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

def blend0(t, img, F0):
    if t < T_FADE: return img
    u = ease((t - T_FADE) / (END - T_FADE))
    return (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); Image.fromarray(blend0(tt, frame(tt), F0)).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; p.stdin.write(blend0(tt, frame(tt), F0).tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
