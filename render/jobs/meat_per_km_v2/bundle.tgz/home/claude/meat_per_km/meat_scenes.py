"""meat_per_km: compact bar race for 11 countries (the stock bar_race needs about 120 px a row, so 11 rows overlap).
Overrides the bar_race type for this spec only (loaded through spec "scene_module"). Same timing, sorting and glide."""
import render as RD
from render import P, T, heading, source, fade_in, count, icon_of, draw_emoji, col, clean, fmt, CONTENT_BOTTOM, HOOK_GRACE
from kit import box, font, St


def sc_bar_race(c, t, S):
    y = heading(c, t, S) + 6
    bars = S["bars"]; ts = S["times"]["bars"]; n = len(bars)
    vmax = S.get("max") or max(b["value"] for b in bars) * 1.08
    rh = min(120, (CONTENT_BOTTOM - 45 - y) / max(1, n))
    LX, X0, XM = 70, 395, 1000
    bh = rh * 0.62
    cur = []
    for k, b in enumerate(bars):
        hk = S.get("hook") and ts[k] <= HOOK_GRACE
        v = b["value"] if hk else count(t, ts[k] + 0.1, b.get("dur", 1.0), b.get("from", 0), b["value"])
        cur.append(v if (t >= ts[k] - 0.05 or hk) else None)
    order = list(range(n))
    if S.get("sort"):
        vis = [k for k in range(n) if cur[k] is not None]
        order = sorted(vis, key=lambda k: -cur[k]) + [k for k in range(n) if cur[k] is None]
    rank = {k: r_ for r_, k in enumerate(order)}
    if "_rank" not in S: S["_rank"] = {k: float(rank[k]) for k in range(n)}
    for k in range(n):
        S["_rank"][k] += (rank[k] - S["_rank"][k]) * 0.25
    for k, b in enumerate(bars):
        if cur[k] is None: continue
        a = fade_in(t, ts[k] - 0.05, S, 0.2); old = St.a; St.a *= a
        yc = y + rh * S["_rank"][k] + rh / 2
        em = icon_of(b); xl = LX
        if em: draw_emoji(c, em, LX + 24, yc, 46); xl = LX + 58
        hi = b.get("color") == "gold"
        T(c, b.get("label", ""), 36, xl, yc - 15, P["gold_text"] if hi else P["navy"], 1, 1, 900, anchor="l", maxw=X0 - xl - 12)
        if b.get("he"): T(c, b["he"], 30, xl, yc + 19, P["grey"], 1, 1, 700, anchor="l", maxw=X0 - xl - 12)
        bw = max(bh, (XM - X0) * cur[k] / vmax); bc = col(b.get("color"), "blue")
        box(c, X0, yc - bh / 2, bw, bh, bh / 2, bc)
        lab = clean(f"{b.get('prefix', '')}{fmt(cur[k], b.get('decimals', 0))}{b.get('suffix', '')}")
        if font(38, 900).getlength(lab) + 40 < bw: T(c, lab, 38, X0 + bw - 20, yc + 1, P["white"], 1, 1, 900, anchor="r")
        else: T(c, lab, 38, X0 + bw + 14, yc + 1, P["navy"], 1, 1, 900, anchor="l")
        St.a = old
    source(c, t, S)
