"""payloads.py: posting payloads (v1 format) for the 1 Nov fix round -> /home/claude/posting/queue/gh/<id>.json.
Caption edits per reel, then strip_opinion.clean_all (no In my view / To be fair), no pointing-hand emoji, no en/em dashes."""
import json, re, sys
sys.path.insert(0, "/home/claude/reelkit")
from strip_opinion import clean_all
Q = "/home/claude/posting/queue/gh"; RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
def rep(cap, pairs):
    for a, b in pairs:
        assert a in cap, (a[:70]); cap = cap.replace(a, b)
    return cap
E = {
 "colonizer_speed_v3": ("colonizer_speed_v2", []),
 "hebrew_revival_v3": ("hebrew_revival_v2", [
    ("Myth: one man brought Hebrew back to life. 🗣️", "Nobody's mother tongue for centuries. Now about 9 million speak it. 🗣️\n\nMyth: one man brought Hebrew back to life."),
    ("Who taught YOU your first Hebrew word? 👇\n\n", "Not bad, for a language that was nobody's mother tongue.\n\n"),
    ("מי לימד אתכם את המילה הראשונה? 👇", "היום מדברים עברית כ-9 מיליון אנשים."),
    ("Sources: Revival", "Sources: Hebrew speakers today, about 9 million (Wikipedia, Hebrew language, 2018 figure); Revival")]),
 "jews_survive_v3": ("jews_survive_v2", [("What's YOUR favorite holiday? 👇\nמה החג האהוב עליכם? 👇\n\n", "")]),
 "lib_startups_pc_v3": ("lib_startups_pc_v2", [
    ("Israel is tiny. So why does it build", "You're probably using Waze. 🗺️\nMaybe your car sees the road with Mobileye, your website runs on Wix, your team plans on monday.com. All of them started in Israel.\n\nIsrael is tiny. So why does it build"),
    ("If the USA built at Israel's rate: 13.3 × 340.1M people = about 4,500 unicorns, versus 2,389 today.\n", ""),
    ("And the money follows: about $1,070 of venture capital per Israeli, versus $823 per American.\n", ""),
    ("ישראל קטנטנה.", "וייז, מובילאיי, Wix ו-monday.com: כולן התחילו בישראל.\nישראל קטנטנה."),
    ("Which country surprised you the most? Tell me in the comments 👇\nאיזו מדינה הכי הפתיעה אתכם? ספרו לי בתגובות 👇\n\n", "Tiny country. Giant output.\n\n"),
    ("Sources: Dealroom country profiles (dealroom.co/countries);", "Sources: Dealroom country profiles (dealroom.co/countries); founding years: Mobileye 1999 (Jerusalem), Waze 2006, Wix 2006, monday.com 2012 (Tel Aviv area), company sites;")]),
 "lib_vid_jews_world_v3": ("lib_vid_jews_world_v2", [(" Tell me in the comments 👇", ""), (" ספרו לי בתגובות 👇", ""),
    ("Sources: Sergio", "Map: NASA Blue Marble (public domain), Natural Earth borders. Sources: Sergio")]),
 "maps_p2_hook2_v2": ("maps_p2_hook2", None),
 "meat_per_km_v2": ("meat_per_km", [("In my view, the shawarma queue is our cardio.\n\nWhat's YOUR shawarma per km? ⬇\n\n", "The shawarma queue is our cardio. 🥙\n\n")]),
 "terror_awards_v3": ("terror_awards_v2new", [
    ("And the award for terror goes to... 🏆", "And the award for top terror organization goes to... HAMAS. 🏆\nOct 7, 2023: about 1,200 people killed in Israel. HAMAS is listed as a terrorist organization by the US, the EU and the UK."),
    (" To be fair: PA President Abbas called off the 2021 elections.", " PA President Abbas called off the 2021 elections."),
    ("In my view, the real losers are the civilians of Gaza and Lebanon.\n\nWhich category would you add? 👇\n\n", "The real losers are the civilians of Gaza and Lebanon.\n\n"),
    ("והפרס על טרור הולך ל... 🏆", "והפרס לארגון הטרור המוביל הולך ל... חמאס 🏆"),
    ("לדעתי, המפסידים האמיתיים הם האזרחים בעזה ובלבנון.\nאיזו קטגוריה הייתם מוסיפים? 👇", "המפסידים האמיתיים הם האזרחים בעזה ובלבנון."),
    ("Sources: Al Jazeera", "Sources: Israel PMO and AFP (Oct 7, about 1,200 killed); US State Department FTO list (1997), EU terrorist list, UK Home Office proscription (2021); Al Jazeera")]),
 "this_life_v2": ("this_life", [
    ("🌱 Secular people: this life is the one we have. Make it count.\n",
     "🌱 Secular people: this life is the one we have. Make it count.\n\n🤝 Most Muslims build this life too. In Pew Research Center surveys of 11 Muslim publics (2013), no extremist group (HAMAS, Hezbollah, al-Qaeda, the Taliban) won majority Muslim support. A violent minority doesn't.\n"),
    ("⚠️ Jihadist groups (Hamas,", "⚠️ Jihadist groups (HAMAS,"), ("(Hamas MP Fathi Hammad", "(HAMAS MP Fathi Hammad"),
    ("🤝 To be fair: most of the world's 2 billion Muslims live, work and build like everyone else. Mainstream Islam forbids",
     "Mainstream Muslim teaching forbids"),
    ("In my view: a culture", "A culture"), ("Beg to differ? Tell us where we're wrong. 👇\n\n", "Because in the end, there are only two ways to see this life.\n\n"),
    ("רוב 2 מיליארד המוסלמים בעולם חיים ובונים כמו כולם: זו אידיאולוגיה, לא דת.", "רוב המוסלמים בונים את החיים האלה גם הם, ומיעוט אלים לא: זו אידיאולוגיה, לא דת."),
    (" חושבים אחרת? כתבו לנו איפה אנחנו טועים 👇", ""),
    ("Pew Research Center (about 2 billion Muslims, 2020)", "Pew Research Center, Muslim Publics Share Concerns about Extremist Groups (Sept 2013)")]),
 "x_could_en_v3": ("x_could_en_v2", []),
 "x_zoom_en_v4": ("x_zoom_en_v3", []),
 "x_express10_en_v4": ("x_express10_en_v3", []),
 "lib_explain_v2": (None, None),
 "lib_express_method_v2": (None, None),
}
DOGS = """One Israeli city had just 5 registered dogs. 🐕

🇮🇱 Israel: 581,022 dogs on the national registry (2022).
🐕 Tel Aviv 43,222, Rishon LeZion 18,876, Haifa 18,154, Be'er Sheva 17,151, Jerusalem 14,913.
📊 Per 1,000 people: Tel Aviv about 88, Jerusalem about 15, with twice Tel Aviv's population.
🐶 Most popular names: Luna (7,323), then Louie (6,281).
📍 The city with 5: Modi'in Illit (and Rechasim, 5 each, 2019).

So next time someone tells you every Israeli has a dog...

בעיר אחת בישראל היו רק 5 כלבים רשומים: מודיעין עילית. בתל אביב 43,222, בירושלים 14,913. השם הכי נפוץ: לונה.

Sources: Ministry of Agriculture national dog registry 2022 (via ICE, Feb 2023); INN 2019 (Modi'in Illit, Rechasim); CBS population 2022

#Israel #dogs #maps #data #ישראל"""
EXPLAIN = """מי מוביל את המפגשים באקספרס? המתאמנים שלנו 🎤

לא מרצים, לא מורים. אנשים כמוכם. כל English Speaker מתרגל באנגלית בדיוק את מה שהוא צריך בעבודה.

רק בשבועיים האחרונים:
🎾 הרצאה על המתמטיקה של הטניס
🎶 שיחה על יחסים במשפחה דרך השירים של אנקנטו
🧭 ראיון על איזון בחיים
🤖 סקירה של שנה בסייבר ובבינה מלאכותית בישראל

אז איזו פגישה אתם דוחים? את זה בדיוק תתרגלו אצלנו, באנגלית. בהדרגה, ממקום בטוח.

רוצים שטף? דברו עם עצמכם באנגלית 7 דקות, בוואטסאפ. ואז הסבירו את אותו רעיון לחבר.

#EnglishExpress #אנגלית #BusinessEnglish #SpeakEnglish"""
METHOD = None
def base(acct, cap, collab=False):
    b = {"media_type": "REELS", "caption": cap, "share_to_feed": True, "is_ai_generated": True, "trial_params": {"graduation_strategy": "SS_PERFORMANCE"}}
    if collab: b["collaborators"] = ["noamroz__"]
    return {"action": "init", "account": acct}, b
for nid, (old, pairs) in E.items():
    if old:
        d = json.load(open(f"{Q}/{old}.json")); b = json.loads(d["body"])
        if pairs is None: b["caption"] = DOGS
        else: b["caption"] = rep(b["caption"], pairs)
    elif nid == "lib_explain_v2":
        d, b = base("express", EXPLAIN)
    else:
        cap = open("/home/claude/fixes_1101/em/caption.txt").read().strip()
        cap = rep(cap, [("Why speaking English feels like driving on the highway on your first day 🚗", "Americans on day one? That's the highway. 🚗"),
                        ("Follow @expressenglishcom\nWith @noamroz__\n\n", "")])
        d, b = base("express", cap)
    c = clean_all(b["caption"]).replace(" 👇", "").replace("👇", "")
    c = re.sub(r"\n{3,}", "\n\n", c)
    b["caption"] = c; b["video_url"] = RAW + nid + ".mp4"; b["is_ai_generated"] = True; b["media_type"] = "REELS"
    b["trial_params"] = {"graduation_strategy": "SS_PERFORMANCE"}; b.setdefault("share_to_feed", True)
    assert not re.search("[–—]", c) and "In my view" not in c and "To be fair" not in c and "לדעתי" not in c, nid
    assert len(c) < 2200, (nid, len(c))
    d["tag"] = nid + "-gh"; d["body"] = json.dumps(b, ensure_ascii=False)
    json.dump(d, open(f"{Q}/{nid}.json", "w"), ensure_ascii=False); print(nid, d["account"], len(c))
