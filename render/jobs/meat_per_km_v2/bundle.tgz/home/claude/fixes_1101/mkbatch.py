"""mkbatch.py ids...: Launch Map batch for the 1 Nov fix round -> batch/writes.json (new check cards + archived parents).
Reads fresh parent docs from lm_fresh/reels/<id>.json (query right before writing) and asset ids from batch/assets.json."""
import json, re, sys
F = "/home/claude/fixes_1101"; L = f"{F}/lm_fresh/reels"
NOW = "2026-11-01T09:30:00Z"; RAW = "https://raw.githubusercontent.com/avinoamroz/reels-drop/main/"
A = json.load(open(f"{F}/batch/assets.json")); VER = json.load(open(f"{F}/batch/versions.json"))
D = {  # new id: (parent, short fix, note, predViews, predWhy)
 "colonizer_speed_v3": ("colonizer_speed_v2", "narration 5% slower",
   "v3 per Noam 1 Nov [0:23] 'slow down a bit, by 5 percent': the whole narration is 5% slower (atempo 0.95 equivalent on the original takes, pitch kept), scenes, bars and subtitles re-timed to the new voice, music re-cut to the new length. Lines and texts unchanged. Ending: Noam's own last line is kept, and the last 0.5 s now cross-fades into frame 0 with a looping bed, so the replay is continuous. 53.1 s (was 50.8 s).",
   1800, "new idea; account median ~1.8k. Under the 2,000 floor: flagged for an upgrade"),
 "hebrew_revival_v3": ("hebrew_revival_v2", "new hook",
   "v3 per Noam 1 Nov [0:01] 'different hook': frame 0 is now 'Nobody's mother tongue. Now 9 million.' (6 words, on screen from frame 0), voiced as a new first line 'For centuries, Hebrew was nobody's mother tongue. Today, nine million people speak it.' Number checked: Wikipedia, Hebrew language, about 9 million speakers (2018 figure), source label on screen. Then the original 'Myth: one man brought Hebrew back to life' and the rest unchanged. Circular: the CTA question is replaced by the lead-in 'Not bad, for a language that was...', which runs into the hook, with a 0.5 s cross-fade into frame 0. 45.9 s.",
   1800, "new hook on a new idea; account median ~1.8k. Under the 2,000 floor: flagged"),
 "jews_survive_v3": ("jews_survive_v2", "sound fixed 0:12 to 0:30",
   "v3 per Noam 1 Nov [0:19] 'issue with sound'. Found: the six holiday holds were pasted as hard digital silence at line end + 0.12 s, cutting the voice tail mid-sound (four of them sit between 0:12 and 0:23), the native Tisha B'Av clip sat about 6 dB under the English, and the Crusaders line about 5 dB under the rest. Fixed: each hold now sits at the quietest 10 ms after the line with 25 ms fades, native clips and every line are level-matched to the median line (all lines now within 1 dB), no stray bursts. Also per the standing rules: the TO BE FAIR pill is gone from the Germany card, and the end is circular: 'What's your favorite holiday?' is replaced by 'Am Yisrael Chai. Even though...', which runs into 'Thirteen times, they tried to wipe out the Jews' (one new Cartesia clip, cross-fade into frame 0). 59.2 s.",
   1800, "new idea; account median ~1.8k. Under the 2,000 floor: flagged"),
 "lib_startups_pc_v3": ("lib_startups_pc_v2", "opens on Waze, under 60 s",
   "v3 per Noam 1 Nov [0:53] remake starting with what these startups do: opens on 'You're probably using Waze.' (frame 0), then 'Maybe your car sees the road with Mobileye. Your website runs on Wix. And your team plans on monday.com.' (a 2x2 card each, icons only, no logos), then 'All of them started in Israel.' and the reveal 'Israel is tiny. So why does it build more billion dollar startups per person than anyone?'. Verified Israeli-founded: Mobileye 1999 Jerusalem, Waze 2006, Wix 2006 and monday.com 2012 (Tel Aviv area), on screen. Kept the three short unicorn races and the Why card; cut the New Jersey, 'if America built at Israel's rate' and VC per person lines to stay under 60 s. Circular: ends 'Tiny country. Giant output. And right now...' into 'You're probably using Waze.'. New lines are new Cartesia clips at the same speed 0.92 (whisper reads Waze, Mobileye, Wix, Monday.com correctly). 58.4 s (was 68.1 s).",
   2000, "proven Israel tech angle with an everyday-product hook; ~2k"),
 "lib_vid_jews_world_v3": ("lib_vid_jews_world_v2", "satellite map, country names",
   "v3 per Noam 1 Nov [0:09] 'add names of countries, and make like google earth map': the flat navy land is now a satellite-style base (NASA Blue Marble, world.topo.bathy Dec 2004, public domain, darkened) with thin white borders (Natural Earth) and clean white country names with a dark halo (36 px+), more names when the camera is zoomed in on the Middle East and Europe, fewer as it zooms out, then the continent names take over at the world view. No label covers a bubble label. Last 0.5 s cross-fades into frame 0. Music, timing and data unchanged. 40.8 s.",
   1800, "data race; account median ~1.8k. Under the 2,000 floor: flagged"),
 "maps_p2_hook2_v2": ("maps_p2_hook2", "dogs stats only",
   "v2 per Noam 'Remake only dogs stats': a new short reel about dogs only, no electric cars or baby names. Frame 0: 'One city. Just 5 registered dogs.' Then 581,022 dogs on the national registry (2022), a map of the top cities (Tel Aviv 43,222, Rishon LeZion 18,876, Haifa 18,154, Be'er Sheva 17,151, Jerusalem 14,913), dogs per 1,000 people (Tel Aviv 88, Rishon 75, Haifa 63, Jerusalem 15), top names Luna 7,323 and Louie 6,281, then the reveal: Modi'in Illit (and Rechasim, 5 each, 2019). New Cartesia narration; Modi'in Illit voiced natively in Hebrew (whisper he reads it as מודיין אליט, worth a listen), Haifa only on screen. Circular end: 'So next time someone tells you every Israeli has a dog...' into the hook. English only on screen. Sources on screen: Ministry of Agriculture registry 2022 via ICE; INN 2019. 32.4 s.",
   1800, "spin-off of maps_p2 (silly_maps did 9.9k); dogs alone is narrower. Under the 2,000 floor: flagged"),
 "meat_per_km_v2": ("meat_per_km", "kilometer re-voiced",
   "v2 per Noam 1 Nov [0:04] 'kilometer mispronounced': the old script spelled it 'kilometre' and the voice said it wrong in four lines (whisper heard 'Kilometra'). Re-voiced with 'kilometer(s)' in one new Cartesia take of the same script (speed 1.1 as before); whisper now reads 'kilometer' and 'kilometers' in all four lines. Also per the standing rules: 'In my view' removed (card now 'The shawarma queue is our cardio'), the CTA question and Follow chip are replaced by a circular lead-in, 'So next time someone asks how much we really eat...', into the hook. 45.4 s.",
   1800, "sister to beer_per_km; account median ~1.8k. Under the 2,000 floor: flagged"),
 "terror_awards_v3": ("terror_awards_v2new", "HAMAS wins top terror organization",
   "v3 per Noam 1 Nov [0:04]: the hook is now 'And the award for top terror organization goes to... HAMAS.' Frame 0 shows 'Top terror organization goes to...' (5 words), the envelope opens, and on the spoken HAMAS the card flips to HAMAS in caps with two trophies; sourced chip: 'Oct 7, 2023: about 1,200 killed in Israel. A terror group to the US, EU and UK.' (Israel PMO/AFP; US State Dept FTO 1997, EU list, UK 2021). One new Cartesia clip. Body is the same categories, re-rendered so 'In my view' is gone from the narration and screen and 'To be fair' from the source label; the 'Which category would you add?' end is replaced by 'Which brings us back to the big one.', which loops into the hook (cross-fade into frame 0). 48.2 s.",
   1200, "redo of a trial that got 131; stronger named hook, still well under the 2,000 floor: flagged"),
 "this_life_v2": ("this_life", "most Muslims reject extremism",
   "v2 per Noam 1 Nov [0:52]: after Jews, Christians and secular people, a new line 'Most Muslims build this life too. In Pew surveys, no extremist group won majority Muslim support.' (card: 'Most Muslims reject extremism.' with 'Pew, 11 countries: no extremist group won majority support.'), then 'But a violent minority doesn't.' (own card), then it continues with the jihadist groups. Source on screen: Pew Research Center, Muslim Publics Share Concerns about Extremist Groups, Sept 2013 (HAMAS, Hezbollah, al-Qaeda, Taliban; in no country did any win majority support). No 80/20 figure: no credible source gives one. Removed per the standing rules: the 'To be fair' two billion line, 'In my view', and 'Mainstream Islam' (the voice says eye-slam) is re-voiced as 'Mainstream Muslim teaching forbids killing innocents...'. HAMAS in caps on screen. Circular end: 'Because in the end, there are only...' on the two-roads frame, into 'Two ways to see this life.'. Four new Cartesia clips. 56.9 s. Sensitive: review before posting.",
   1800, "new idea; account median ~1.8k. Under the 2,000 floor: flagged"),
 "x_could_en_v3": ("x_could_en_v2", "wrong on top, fix below, on the sound",
   "v3 per Noam 1 Nov [0:14]: every pair now has its own card: the sentence you shouldn't say sits on top in a red card ('Don't say', with the small Hebrew meaning) and lands when it is spoken, the correction drops in below in a green card ('Say') on its own spoken words, and the wrong line gets struck through as the correction starts. Seven pairs, each about 3.5 s, all synced to the word timings. Hook, 'magic word' card and SPEAKER loop ending unchanged. 47.7 s.",
   350, "Express account median ~350 to 430; under the 1,000 Express floor: flagged"),
 "x_zoom_en_v4": ("x_zoom_en_v3", "wrong on top, fix below, on the sound",
   "v4 per Noam 1 Nov [0:10]: one card per Zoom phrase: the Hebrew-translated sentence you shouldn't say on top (red, 'Don't say', small Hebrew line) when it is spoken, the correction below (green, 'Say') on its own spoken words, struck through as the fix lands; 'So, we closed?' opens with 'And the big one' and gets both fixes. Synced to the 1.1x voice of v3. Hook and SPEAKER loop ending unchanged. 49.4 s.",
   380, "Express account median ~380; under the 1,000 Express floor: flagged"),
 "x_express10_en_v4": ("x_express10_en_v3", "shorter, no foreign word",
   "v4: fix sent with no note, so checked against the house rules. Fixed: length 53 s is long for an invite, now 38.1 s (cut the 'learning, not studying' and 'the path' beats; kept 10 years, 2,200, the kitchen, 31.10.2016, English Speaker, 51 ExpressX nights, why we do it, 3 November invite); 'Sokolov two' is no longer said by the English voice (Hebrew street name, rule 4f), it stays on screen as 'Sokolov 2, Tel Aviv'; the long 'ENGLISH SPEAKER VS ENGLISH STUDENT' kicker is now 'SPEAKER, NOT STUDENT' at full size. Already fine: circular lead-in 'And that's how one kitchen became:' into the hook, text sizes, no faces. Same takes, no re-voice.",
   430, "Express account median ~430; under the 1,000 Express floor: flagged"),
 "lib_explain_v2": ("lib_explain", "English narration, Hebrew text",
   "v2 per Noam [0:10] 'narration in English, writing in Hebrew': new English voice-over in Noam's Cartesia voice (sonic-3), same meaning as the Hebrew one ('Most people don't know this, but who leads the sessions at Express? Our English Speakers...', the four real sessions, the 7-minute fluency line); all on-screen writing stays Hebrew, re-timed to the English words. Circular: a last line 'So next time someone asks you...' (on screen in Hebrew, אז בפעם הבאה שמישהו ישאל אתכם...) and a cross-fade into the hook frame. No burned-in English subtitles, because Noam asked for Hebrew writing only. 45.7 s.",
   430, "Express account median ~430; under the 1,000 Express floor: flagged"),
 "lib_express_method_v2": ("lib_express_method", "4-word hook",
   "v2 per Noam 'shorter hook': frame 0 is now 'Americans on day one?' (4 words, was 6), then 'That's the highway'; the hook beat is 3.2 s (was 3.8 s). Circular end: the end card's 'Are you on the highway yet?' is now the lead-in 'Still afraid of...' and the last 0.5 s cross-fades into frame 0, so it reads 'Still afraid of... Americans on day one?'. Music and on-screen text only, rest unchanged. 62.1 s.",
   430, "Express account median ~430; under the 1,000 Express floor: flagged"),
}
ids = sys.argv[1:] or list(D)
writes = []
for nid in ids:
    old, short, note, pv, why = D[nid]; od = json.load(open(f"{L}/{old}.json"))
    vtag = "v" + re.search(r"_v(\d+)$", nid).group(1)
    c = {"account": od.get("account"), "status": "check", "parent": old, "kind": "variant", "lang": od.get("lang", "en"),
         "title": f"{od['title']} ({vtag}: {short})", "note": note,
         "preview": f"/_blob/{A[nid]}", "previewAsset": A[nid], "previewRaw": f"{RAW}render/out/{nid}_540.mp4",
         "src": f"{RAW}{nid}.mp4", "link": f"{RAW}{nid}.mp4", "payload": nid, "addedAt": NOW, "editedAt": NOW,
         "dayLabel": "To review", "time": "TBD", "slotted": False, "predViews": pv, "predWhy": why}
    for k in ("collab", "collaborators"):
        if k in od: c[k] = od[k]
    assert not re.search("[–—]", json.dumps(c, ensure_ascii=False)), nid
    json.dump(c, open(f"{F}/batch/{nid}.json", "w"), ensure_ascii=False)
    writes.append({"op": "set", "collection": "reels", "doc_id": nid, "file_path": f"{F}/batch/{nid}.json"})
    writes.append({"op": "update", "collection": "reels", "doc_id": old, "if_version": VER[old],
                   "data": {"status": "archived", "note": "Fixed in " + vtag + ". " + od.get("note", ""), "editedAt": NOW}})
json.dump(writes, open(f"{F}/batch/writes.json", "w"), ensure_ascii=False)
print(len(writes), "writes")
