"""scenes_x10.py (fix batch 6, x_express10_en_v5_rmk1): English Express 10 years, clean process remake.
Same narration as v4/v5 (Noam: "nice narration, messy process"). One idea per card, one clear sequence:
a 5-step journey track at the top (2016, Speaker, ExpressX, Mission, 10 years) lights up step by step,
each card shows a single idea in big type, the second idea replaces the first on its spoken word (mark "b").
Brand: navy #163261 to #2749D3 gradient, sky #45A4DD, yellow for numbers."""
import sys, math
sys.path.append("/home/claude/fix6/lib")
import looplib; looplib.wrap(globals())
import cairo
import render as RD
from kit import ease, St, rr, ramp, lerp
import kit
W, H = 1080, 1920
NAVY0, NAVY1 = kit.hx("#0E1E3A"), kit.hx("#2749D3"); SKY = kit.hx("#45A4DD"); YEL = kit.hx("#F5C518"); WHITE = kit.hx("#FFFFFF")
GREY = kit.hx("#7E8DB3")
STEPS = ["2016", "Speaker", "ExpressX", "Mission", "10 years"]

def bg(c, t):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *NAVY0[:3]); g.add_color_stop_rgb(1, *NAVY1[:3])
    c.rectangle(0, 0, W, H); c.set_source(g); c.fill()
    gx, gy = 540 + 240 * math.sin(t * 0.35), 900 + 260 * math.cos(t * 0.27)
    rg = cairo.RadialGradient(gx, gy, 0, gx, gy, 520); rg.add_color_stop_rgba(0, SKY[0], SKY[1], SKY[2], 0.22); rg.add_color_stop_rgba(1, SKY[0], SKY[1], SKY[2], 0)
    c.rectangle(0, 0, W, H); c.set_source(rg); c.fill()

def track(c, t, k, t_on):
    """k = current step (0-4), -1 = none. Past steps sky, current yellow and pulsing, future grey."""
    if k < 0: return
    x0, x1, y = 130, 950, 330; n = len(STEPS); xs = [x0 + (x1 - x0) * i / (n - 1) for i in range(n)]
    u = ease(ramp(t, t_on, t_on + 0.6))
    c.set_line_width(8); c.set_source_rgba(*GREY[:3], 0.6); c.move_to(x0, y); c.line_to(x1, y); c.stroke()
    xe = lerp(xs[max(0, k - 1)], xs[k], u)
    c.set_source_rgba(*SKY[:3], 1); c.move_to(x0, y); c.line_to(xe, y); c.stroke()
    for i, x in enumerate(xs):
        cur = i == k and u > 0.95
        r = 22 + (4 * math.sin(t * 4) if cur else 0)
        col = YEL if cur else (SKY if i < k or (i == k) else GREY)
        c.arc(x, y, r + 6, 0, 2 * math.pi); c.set_source_rgba(*NAVY0[:3], 1); c.fill()
        c.arc(x, y, r, 0, 2 * math.pi); c.set_source_rgba(*col[:3], 1 if i <= k else 0.7); c.fill()
        RD.T(c, STEPS[i], 40 if cur else 36, x, y + 66, YEL if cur else (WHITE if i <= k else GREY), 1.0, 1.0, 900 if cur else 700, maxw=220)

def card(c, txt, sz, y, a, s, col=WHITE, hl=YEL):
    if a <= 0.01: return
    sz2, lines = RD.wrap(txt, sz, 900, 960, 3)
    lh = sz2 * 1.18; y0 = y - lh * (len(lines) - 1) / 2
    for i, ln in enumerate(lines): RD.T(c, ln, sz2, 540, y0 + i * lh, col, a, s, 900, hl=hl, maxw=980)

def sc_journey(c, t, S):
    bg(c, t)
    t0 = S["t0"]; tb = S["times"].get("b", 1e9); hook = t0 < 0.05
    track(c, t, S.get("step", -1), t0 + 0.05)
    if S.get("kicker"):
        a = 1.0 if hook else ease(ramp(t, t0 + 0.05, t0 + 0.35))
        RD.T(c, S["kicker"], 44, 540, 520, SKY, a, 1.0, 800, maxw=900)
    if S.get("emoji"):
        a = 1.0 if hook else ease(ramp(t, t0 + 0.05, t0 + 0.4))
        RD.draw_emoji(c, S["emoji"], 540, 690 + 6 * math.sin(t * 2.4), 150, a, 1.0) if hasattr(RD, "draw_emoji") else None
    # idea A until mark b, then idea B (one idea on screen at a time)
    ua = 1.0 if hook else ease(ramp(t, t0 + 0.05, t0 + 0.4)); da = 1 - ease(ramp(t, tb - 0.25, tb))
    if S.get("b") is None: da = 1.0
    card(c, S["a"], S.get("a_size", 130), S.get("y", 960), ua * da, lerp(0.9, 1.0, ua))
    if S.get("a_sub") and da > 0.01:
        RD.T(c, S["a_sub"], 64, 540, S.get("y", 960) + 190, WHITE, ua * da * ease(ramp(t, t0 + 0.4, t0 + 0.7)), 1.0, 700, maxw=940)
    if S.get("b") is not None:
        ub = ease(ramp(t, tb - 0.05, tb + 0.35))
        card(c, S["b"], S.get("b_size", 120), S.get("y", 960), ub, lerp(0.9, 1.0, ub))
        if S.get("b_sub"): RD.T(c, S["b_sub"], 64, 540, S.get("y", 960) + 190, WHITE, ease(ramp(t, tb + 0.35, tb + 0.7)), 1.0, 700, maxw=940)
    if S.get("footer"):
        tf = S["times"].get("f", t0 + 1.0); af = ease(ramp(t, tf - 0.05, tf + 0.3))
        if af > 0.01:
            f = kit.font(64, 900); tw = f.getlength(S["footer"]); St.a = 1.0
            c.set_source_rgba(*YEL[:3], af); rr(c, 540 - tw / 2 - 40, 1340, tw + 80, 104, 52); c.fill()
            RD.T(c, S["footer"], 64, 540, 1393, NAVY0, af, 1.0, 900, maxw=940)
