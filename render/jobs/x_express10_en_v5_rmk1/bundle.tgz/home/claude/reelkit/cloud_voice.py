#!/usr/bin/env python3
"""Voice batching for Make TTS1 (scenario 4998936, Cartesia sonic-3, Noam's clone). See VOICE_BATCHING.md.

  python3 cloud_voice.py plan tts.txt PREFIX [--lang en] [--max-sec 55]
      prints the scenarios_run data for ONE TTS1 call per reel (all lines, sentence breaks kept, endpoint sse),
      split at line boundaries only when the expected audio is over --max-sec (the Drive tool limit).
      Writes PREFIX_parts.json next to tts.txt ([{name, lines, idx, est_sec, est_mb, data}]).
  python3 cloud_voice.py pull NAME FILE_ID [NAME FILE_ID ...] [--timeout 900]
      optional GitHub path, no Drive tool and no size limit: appends "NAME FILE_ID" to voice/drive.txt in
      reels-drop, pushes, and fetch.yml downloads it on GitHub. NAME.txt (an sse file) becomes
      voice/NAME.wav + voice/NAME_words.json; any other name is stored as is. Prints the local paths.
      The file must be viewable by link first: run Make IG3 (scenario 4985693) with {"drive_file_id": FILE_ID}.
      TTS1 returns file_id and size in its output, so no Drive search is needed.
"""
import argparse, json, os, re, subprocess, sys, time

REPO = "/home/claude/reels-drop"
LIST = os.path.join(REPO, "voice/drive.txt")
VOICE_ID = "cd06f613-0c92-4347-9b94-b34cb4a0239f"
WPS = 2.6           # Cartesia sonic-3 words per second for Noam's clone, before the house atempo
SSE_BPS = 120_000   # raw SSE bytes per second of audio (44.1 kHz s16 PCM, base64, event framing)
SIGN = "\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_01D8gF2iekadnzKcdJnCPGVX"
DASH = re.compile("[‒–—―]")


def git(*a, check=True):
    return subprocess.run(["git", "-C", REPO, *a], check=check, capture_output=True, text=True)


def est(lines):
    w = sum(len(l.split()) for l in lines)
    pauses = 0.35 * max(0, len(lines) - 1)
    return w / WPS + pauses


def call(lines, name, lang="en"):
    text = re.sub(r"\s+", " ", " ".join(DASH.sub(",", l.strip()) for l in lines)).strip()
    body = {"model_id": "sonic-3", "transcript": text, "voice": {"mode": "id", "id": VOICE_ID},
            "output_format": {"container": "raw", "encoding": "pcm_s16le", "sample_rate": 44100},
            "add_timestamps": True, "language": lang}
    return {"body": json.dumps(body, ensure_ascii=False), "name": name, "tag": "reel", "endpoint": "sse"}


def plan(script, prefix, lang, max_sec):
    lines = [l.strip() for l in open(script, encoding="utf-8") if l.strip()]
    parts, cur, idx = [], [], []
    for k, l in enumerate(lines):
        if cur and est(cur + [l]) > max_sec:
            parts.append((cur, idx)); cur, idx = [], []
        cur.append(l); idx.append(k)
    if cur:
        parts.append((cur, idx))
    out = []
    for p, (ls, ix) in enumerate(parts):
        name = f"{prefix}.txt" if len(parts) == 1 else f"{prefix}_p{p}.txt"
        s = est(ls)
        out.append({"name": name, "lines": ls, "idx": ix, "est_sec": round(s, 1), "est_mb": round(s * SSE_BPS / 1e6, 1),
                    "data": call(ls, name, lang)})
    dst = os.path.join(os.path.dirname(os.path.abspath(script)), os.path.basename(prefix) + "_parts.json")
    json.dump(out, open(dst, "w"), indent=1, ensure_ascii=False)
    print(f"{len(lines)} lines, about {est(lines):.0f} s -> {len(out)} TTS1 call(s); wrote {dst}")
    for o in out:
        print(f"\n# Make scenarios_run scenarioId=4998936  ({o['name']}, lines {o['idx'][0]+1} to {o['idx'][-1]+1}, ~{o['est_sec']} s, ~{o['est_mb']} MB)")
        print(json.dumps(o["data"], ensure_ascii=False))


def ready(name):
    base = name.rsplit(".", 1)[0]
    v = os.path.join(REPO, "voice")
    if name.endswith(".txt"):
        ok = os.path.join(v, base + ".wav")
        return ("ok", [ok, os.path.join(v, base + "_words.json")]) if os.path.exists(ok) else None
    if os.path.exists(os.path.join(v, name)):
        return ("ok", [os.path.join(v, name)])
    e = os.path.join(v, base + ".err")
    return ("err", [open(e).read().strip()]) if os.path.exists(e) else None


def pull(pairs, timeout):
    git("pull", "-q", "--rebase", "--autostash", check=False)
    os.makedirs(os.path.dirname(LIST), exist_ok=True)
    cur = open(LIST, encoding="utf-8").read().splitlines() if os.path.exists(LIST) else []
    names = {n for n, _ in pairs}
    keep = [l for l in cur if not (l.split() and l.split()[0] in names)]
    open(LIST, "w", encoding="utf-8").write("\n".join(keep + [f"{n} {f}" for n, f in pairs]) + "\n")
    for n, _ in pairs:  # clear an earlier error so the wait sees the new result
        e = os.path.join(REPO, "voice", n.rsplit(".", 1)[0] + ".err")
        if os.path.exists(e):
            git("rm", "-q", "--cached", e, check=False); os.remove(e)
    git("add", "-A", os.path.join(REPO, "voice"))
    git("-c", "user.name=Noam Roz", "-c", "user.email=noam@expressenglish.co.il", "commit", "-q", "-m",
        "Voice from Drive: " + " ".join(names) + SIGN)
    for i in range(6):
        if git("push", "-q", check=False).returncode == 0:
            break
        git("pull", "-q", "--rebase", "--autostash", check=False); time.sleep(5)
    else:
        sys.exit("push failed")
    print("pushed; GitHub fetch.yml is downloading", " ".join(names), flush=True)
    t0, left = time.time(), set(names)
    while left and time.time() - t0 < timeout:
        time.sleep(15)
        git("pull", "-q", "--rebase", "--autostash", check=False)
        left = {n for n in left if not ready(n)}
    rc = 0
    for n, _ in pairs:
        r = ready(n)
        if not r:
            rc = 3; print(f"WAIT {n}: not back yet, see https://github.com/avinoamroz/reels-drop/actions/workflows/fetch.yml")
        elif r[0] == "err":
            rc = 2; print(f"FAIL {n}: {r[1][0]}")
        else:
            print(f"OK   {n}: " + "  ".join(r[1]))
    sys.exit(rc)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest="c", required=True)
    p = sp.add_parser("plan"); p.add_argument("script"); p.add_argument("prefix")
    p.add_argument("--lang", default="en"); p.add_argument("--max-sec", type=float, default=55)
    q = sp.add_parser("pull"); q.add_argument("pairs", nargs="+"); q.add_argument("--timeout", type=int, default=900)
    a = ap.parse_args()
    if a.c == "plan":
        plan(a.script, a.prefix, a.lang, a.max_sec)
    else:
        if len(a.pairs) % 2:
            sys.exit("pull takes NAME FILE_ID pairs")
        pull(list(zip(a.pairs[::2], a.pairs[1::2])), a.timeout)
