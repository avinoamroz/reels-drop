# Middle East GDP per person, 1950 to 2026: shaded map (top) + stock-style lines (bottom).
# v3 (27 Oct): phone-legible layout: zoomed full-width map, 7 always-on labels (+ event labels), big chart, same timeline as v2.
# Render (silent, audio re-muxed from v2): python3 engine_gdp_v3.py cfg_gdp_map_v3.py --silent
# Render: cd ~/gdp_map && nice -n 15 python3 engine_gdp.py cfg_gdp_map.py                 (music version)
#         nice -n 15 python3 engine_gdp.py cfg_gdp_map.py --vo /path/noam_gdp.wav                   (narrated version)
#         python3 engine_gdp.py cfg_gdp_map.py --snaps 0.5,20,40                                     (QA stills)
# Data: data.csv = Maddison Project Database 2023 (real GDP per capita, 2011 int'l $, PPP) to 2022, then chained with IMF WEO Apr 2026
# real GDP growth minus World Bank population growth (src/extend_imf.py). See research.md.
D = "/home/claude/" + "gdp_map"   # split so cloud_render packs only the files listed
TAG = "gdp_map_v3"; STYLE = "glass"
OUT = f"{D}/gdp_map_v3_silent.mp4"
FINAL = f"{D}/gdp_map_v3.mp4"; FINAL_VO = f"{D}/gdp_map_v3_vo.mp4"
NARR = f"{D}/narration.txt"; SNAPDIR = f"{D}/qa"; WORKDIR = D; DATA = f"{D}/data.csv"
Y0, Y1 = 1950, 2026
EST_FROM = 2022                         # years after this are IMF-based (2023 to 2025 estimates, 2026 projection)

# ---------------------------------------------------------------- layout v3 (1080x1920, phone first; important text in y 220..1650)
YEAR_XY = (34, 214); YEAR_FS = 150
TITLE_X = 450; TITLE_Y = 244; TITLE_FS = (50, 42, 26)
PANEL = (0, 372, 1080, 830)            # map: full width, y 372..1202
COS_LAT = 28; CAM = (42.4, 28.6, 30.5)  # lon, lat, visible degrees of longitude (zoomed: Egypt to the Gulf)
EV_Y = 1214; EV_FS = 39; EV_HFS = 33; EV_W = 1020; EV_X = 540
PLOT = (118, 1432, 668, 1612)           # x0, y0, x1, y1 of the line chart
CH_FS = 28                              # chart axis + label font size
YMAX = 80000; YTICKS = [0, 40000, 80000]; XTICKS = [1950, 1970, 1990, 2010, 2026]
DISC_Y = 1672; DISC_FS = 22; DISC_LH = 27
LEGEND = (22, 1078); LEG_FS = 24        # legend card over Sudan (no-data land), bottom-left of the map
SCALE = (1000, 150000)                  # log colour scale bounds
RAMP = ["#1f3c6a", "#2f6fae", "#45A4DD", "#9bd3f2", "#e6f6ff"]   # single hue (blue), dark -> light
ISR_LINE = "#2A88D4"; OTHER_LINE = "#8d9cb8"
GOLD = "#B8923F"; GREEN_LINE = (46, 204, 113)   # house rule: land between the river and the sea outlined gold, Green Line dashed green

# ---------------------------------------------------------------- countries
# iso3: (Natural Earth name, EN, HE, label lon/lat, leader-from lon/lat or None, size, when)
# when: "always" = labelled the whole time (Israel + 6 key countries); "event" = labelled only while its event caption highlights it
CTRY = {
 "ISR": ("Israel", "Israel", "ישראל", (31.0, 32.7), (34.85, 31.5), "hero", "always"),
 "PSE": ("Palestine", "West Bank & Gaza", "הגדה ועזה", None, None, "small", "never"),
 "LBN": ("Lebanon", "Lebanon", "לבנון", (32.6, 37.0), (35.7, 33.9), "key", "always"),
 "SYR": ("Syria", "Syria", "סוריה", (38.9, 35.0), None, "key", "always"),
 "JOR": ("Jordan", "Jordan", "ירדן", (37.6, 30.9), (36.4, 31.6), "key", "always"),
 "EGY": ("Egypt", "Egypt", "מצרים", (30.0, 27.0), None, "key", "always"),
 "SAU": ("Saudi Arabia", "Saudi Arabia", "ערב הסעודית", (44.4, 24.0), None, "key", "always"),
 "QAT": ("Qatar", "Qatar", "קטאר", (52.6, 29.0), (51.2, 25.4), "key", "always"),
 "IRQ": ("Iraq", "Iraq", "עיראק", (43.9, 33.0), None, "key", "event"),
 "IRN": ("Iran", "Iran", "איראן", (54.6, 33.2), None, "key", "event"),
 "KWT": ("Kuwait", "Kuwait", "כווית", (48.0, 31.9), (47.7, 29.4), "key", "event"),
 "ARE": ("United Arab Emirates", "UAE", "האמירויות", (55.3, 20.9), (54.3, 23.9), "key", "event"),
 "TUR": ("Turkey", "Turkey", "טורקיה", None, None, "key", "never"),
 "YEM": ("Yemen", "Yemen", "תימן", None, None, "key", "never"),
}
LAB_FS = {"hero": (46, 40, 62), "key": (35, 30, 45)}   # (EN name, HE name, value) font sizes

# line chart: (iso3, short EN, HE). Israel highlighted, the rest muted. 6 lines (Israel + 5 labelled).
LINES = [("ISR", "Israel", "ישראל"), ("ARE", "UAE", "האמירויות"), ("SAU", "Saudi", "סעודיה"),
         ("TUR", "Turkey", "טורקיה"), ("IRN", "Iran", "איראן"), ("SYR", "Syria", "סוריה")]
FLAG = {"ISR": "il", "ARE": "ae", "SAU": "sa", "TUR": "tr", "IRN": "ir", "SYR": "sy"}

# ---------------------------------------------------------------- timeline (beat = year, music version)
# beat 1949.9 = hook; the year runs; holds at each event; then end cards.
TL = [(1949.9, 0.0), (1950.0, 2.6), (1950.25, 5.8)]
RATE = 0.42                               # seconds per year while running
HOLDS = [(1973, 2.0), (1980, 2.0), (1985, 2.4), (1990, 2.4), (2011, 2.0), (2019, 2.3)]
t = 5.8; y = 1950.25
for yr, hold in HOLDS:
    t += (yr - y) * RATE; TL.append((yr, t)); t += hold; y = yr + 0.3; TL.append((y, t))
t += (2026 - y) * RATE; TL.append((2026.0, t)); t += 3.4; TL.append((2026.05, t))
T_CARDS = [("CARD1", t), ("BARS", t + 4.4), ("CTA", t + 11.6)]; T_END = t + 11.6 + 4.6
HIT_BEATS = [2026.0]

# ---------------------------------------------------------------- captions (beat, EN, HE, map highlight isos, chart marker year)
EVENTS = [
 (1949.9, "How does Israel make more per person\nthan all its neighbours combined?", "איך ישראל מייצרת לנפש\nיותר מכל השכנות שלה ביחד?", ["ISR", "EGY", "JOR", "LBN", "SYR"], None),
 (1950.0, "1950: Israel is 2 years old, at $4.5k per person.\nKuwait and Qatar already have oil money.",
          "1950: ישראל בת שנתיים, 4.5 אלף דולר לנפש.\nלכווית ולקטאר כבר יש כסף מנפט.", ["ISR", "KWT", "QAT"], None),
 (1973.0, "1973: oil shock. Arab OPEC embargo,\noil price roughly x4.", "1973: משבר הנפט. אמברגו ערבי,\nמחיר הנפט בערך פי 4.", ["SAU", "KWT", "QAT", "ARE"], 1973),
 (1980.0, "1979: revolution in Iran. 1980: Iraq invades Iran.\nEight years of war.", "1979: מהפכה באיראן. 1980: עיראק פולשת לאיראן.\nשמונה שנות מלחמה.", ["IRN", "IRQ"], 1980),
 (1985.0, "1985: Israel's stabilisation plan.\nInflation from ~445% to ~20%.", "1985: תוכנית הייצוב בישראל.\nאינפלציה מ-445% לכ-20%.", ["ISR"], 1985),
 (1990.0, "1990: Iraq invades Kuwait. Israel absorbs\n~1 million immigrants from the former USSR.", "1990: עיראק פולשת לכווית. ישראל קולטת\nכמיליון עולים מברית המועצות לשעבר.", ["KWT", "ISR"], 1990),
 (2011.0, "2011: Syrian civil war (Assad government vs\narmed opposition). Syria ends below 1950.", "2011: מלחמת האזרחים בסוריה (משטר אסד מול\nהאופוזיציה החמושה). סוריה מסיימת מתחת ל-1950.", ["SYR"], 2011),
 (2019.0, "2019: Lebanon's financial crisis. World Bank:\npossibly a top 3 crisis worldwide since the 1850s.", "2019: המשבר הפיננסי בלבנון. הבנק העולמי:\nאולי מ-3 החמורים בעולם מאז 1850.", ["LBN"], 2019),
 (2026.0, "2026: Israel $37.5k per person. x8.4 since 1950,\nwith x7.7 the population.", "2026: ישראל 37.5 אלף דולר לנפש. פי 8.4 מ-1950,\nעם פי 7.7 אוכלוסייה.", ["ISR"], None),
]
DISC = {1949.9: ["Maddison Project Database 2023. Real GDP per capita, 2011 int'l $ PPP (inflation-adjusted).",
                 "Starts 1950: earliest year with data. 2023 to 2026: IMF estimates, 2026 projected."],
        1973.0: ["US Office of the Historian. Data: Maddison Project Database 2023 (2011 int'l $ PPP)."],
        1980.0: ["Data: Maddison Project Database 2023 (2011 int'l $ PPP). Sources in the caption."],
        1985.0: ["Bank of Israel. Data: Maddison Project Database 2023 (2011 int'l $ PPP)."],
        1990.0: ["UAE: no data for 1991 and 1992 (faded out, not filled in). Data: Maddison 2023."],
        1993.5: ["Data: Maddison Project Database 2023 (2011 int'l $ PPP). Sources in the caption."],
        2019.0: ["World Bank, Lebanon Economic Monitor, Spring 2021. Data: Maddison 2023."],
        2022.3: ["2023 to 2026: IMF estimates, 2026 projected  |  2023 עד 2026: הערכות IMF, 2026 תחזית",
                 "IMF WEO Apr 2026 real growth minus World Bank population growth, on Maddison 2022. No IMF data: Syria after 2022."]}
EST_LABEL = ("IMF estimates", "הערכות IMF")

HOOK = {"dur": 0.9, "lines": [(700, "How does Israel make", "#FFFFFF", 66, 900), (778, "more per person than all", "#FFFFFF", 66, 900),
                              (856, "its neighbours combined?", "#45A4DD", 66, 900),
                              (982, "איך ישראל מייצרת לנפש", "#FFFFFF", 56, 800), (1052, "יותר מכל השכנות שלה ביחד?", "#45A4DD", 56, 800)]}
HOOK_BOX = (590, 560)                     # card y, h
CARDS = {
 "CARD1": dict(edge="#45A4DD", ew=3, y=560, h=620, lines=[
     (650, "Israel since 1950", "#a9bbd8", 40, 800), (745, "x8.4 per person", "#45A4DD", 78, 900),
     (835, "Only the Gulf oil states are higher.", "#FFFFFF", 40, 800),
     (905, "No oil. Built by people.", "#FFFFFF", 54, 900),
     (1010, "פי 8.4 לנפש מאז 1950", "#45A4DD", 52, 800), (1078, "רק מדינות הנפט במפרץ מעליה.", "#FFFFFF", 38, 800),
     (1132, "בלי נפט. נבנתה בידי אנשים.", "#FFFFFF", 42, 900)]),
 "BARS": dict(edge="#45A4DD", ew=3, y=300, h=1268, lines=[]),
 "CTA": dict(edge="#45A4DD", ew=4, y=560, h=620, lines=[(660, "Comment GDP", "#45A4DD", 92, 900), (750, "for the sources", "#FFFFFF", 50, 800),
     (890, "כתבו GDP בתגובות", "#45A4DD", 60, 800), (965, "ותקבלו את המקורות", "#FFFFFF", 46, 800), (1100, "@noamroz__", "#a9bbd8", 42, 800)]),
}
# ---------------------------------------------------------------- the payoff bar: GDP per person, current US$ (World Bank WDI via FRED)
BARS = dict(
 title=("GDP per person, in current US dollars", "תוצר לנפש, בדולרים שוטפים"),
 stack=[("EGY", "Egypt", "מצרים", 3086, 2025, "#7f93b5"), ("JOR", "Jordan", "ירדן", 5348, 2025, "#9aaccb"),
        ("LBN", "Lebanon", "לבנון", 4473, 2024, "#6b7fa3"), ("SYR", "Syria", "סוריה", 847, 2023, "#b9c7de")],
 israel=("ISR", "Israel", "ישראל", 60337, 2025),
 stack_label=("Egypt + Jordan + Lebanon + Syria", "מצרים + ירדן + לבנון + סוריה"),
 ratio=("Israel: 4.4x the four combined", "ישראל: פי 4.4 מארבעתן ביחד"),
 total=("Whole economy: Israel $611bn (10m people)", "vs the four $473bn (159m people)",
        "כל הכלכלה: ישראל 611 מיליארד דולר (10 מיליון איש)", "מול ארבעתן 473 מיליארד דולר (159 מיליון איש)"),
 foot=["World Bank WDI via FRED, current US$. Latest year:", "Israel, Egypt, Jordan 2025; Lebanon 2024; Syria 2023.",
       "This card: current US$. Rest of the reel: PPP, inflation-adjusted."],
)
FLAG = dict(FLAG, EGY="eg", JOR="jo", LBN="lb")
# narration line -> beat it lands on (card keys start that card with the line). 12 lines in narration.txt.
VO_MAP = [1949.9, 1950.0, 1973.0, 1980.0, 1985.0, 1990.0, 2011.0, 2019.0, 2026.0, "CARD1", "BARS", "CTA"]
