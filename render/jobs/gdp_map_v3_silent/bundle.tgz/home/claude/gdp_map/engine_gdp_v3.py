"""Middle East GDP-per-person map + stock-style line chart (phone-legible, 1080x1920, 30 fps).
Look and helpers from ~/israel_rescue/engine_rescue.py (PIL at 2x then downsampled, Natural Earth 1:10m in dark
navy, bold outlined EN + HE labels, caption strip, hook, end cards, music from ~/vid/music/apple2.py, VO mix from
~/vid/vo/mix.py).
usage: nice -n 15 python3 engine_gdp.py CFG.py [--vo VO.wav] [--snaps 0.5,12,30] [--silent]
  no --vo : music-only version -> FINAL (cfg)
  --vo    : narrated version -> FINAL_VO (cfg). Line starts come from WORKDIR/manual_segs.json if it exists, else from
            silence-based segmentation of the VO (the N-1 longest pauses = the <break> marks). Each narration line's start is
            pinned to its beat (VO_MAP) and the music timeline is time-warped piecewise between those pins. Segments found are
            written to WORKDIR/vo_segs.json so they can be checked and copied into manual_segs.json.
  --snaps : QA stills (PNG) at those seconds into SNAPDIR instead of a video.
Data: cfg DATA csv (iso3, year, gdppc). Missing years are never interpolated: the country fades to 'no data' and its line breaks."""
import sys, os, json, math, runpy, subprocess, argparse, csv, io
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from shapely.geometry import Polygon, box
from shapely.ops import unary_union

ap = argparse.ArgumentParser(); ap.add_argument("cfg"); ap.add_argument("--vo"); ap.add_argument("--snaps"); ap.add_argument("--silent", action="store_true")
A = ap.parse_args(); C = runpy.run_path(A.cfg)
HERE = "/home/claude/" + "vid"; WD = C.get("WORKDIR", HERE); S = 2; W, H, FPS = 1080, 1920, 30
def hx(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
BG_T, BG_B = hx("#0E1E3A"), hx("#163261")
SKY = hx("#45A4DD"); SUBC = hx("#a9bbd8"); DISCC = hx("#8ea3c6"); WHITE = hx("#FFFFFF"); MUTED = hx("#7f93b5")
SEA = hx("#0A1730"); LAND = hx("#15284a"); BORDER = (120, 160, 220, 70); NODATA = hx("#2a3550")
FONT = {w: f"{HERE}/fonts/Heebo-{w}.ttf" for w in (400, 700, 800, 900)}
_fc = {}
def font(sz, w=800):
    k = (int(sz * S), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(FONT[w], k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]

# ---------------------------------------------------------------- geometry
def topo(path):
    t = json.load(open(path)); sc, tr = t["transform"]["scale"], t["transform"]["translate"]; arcs = []
    for a in t["arcs"]:
        x = y = 0; pts = []
        for dx, dy in a: x += dx; y += dy; pts.append((x * sc[0] + tr[0], y * sc[1] + tr[1]))
        arcs.append(pts)
    def arc(i): return arcs[i] if i >= 0 else arcs[~i][::-1]
    out = {}
    for g in t["objects"]["countries"]["geometries"]:
        if g.get("type") not in ("Polygon", "MultiPolygon"): continue
        ps = [g["arcs"]] if g["type"] == "Polygon" else g["arcs"]; polys = []
        for p in ps:
            rings = [sum((arc(i) for i in ring), []) for ring in p]
            if len(rings[0]) >= 4: polys.append(Polygon(rings[0]).buffer(0))
        out[g["properties"]["name"]] = unary_union(polys)
    return out
RAWG = topo("/home/claude/goals_scorecard/geodata/countries-10m.json")
PX, PY, PW, PH = C["PANEL"]; COSF = math.cos(math.radians(C.get("COS_LAT", 28))); CAMV = C["CAM"]
VIEW = box(CAMV[0] - CAMV[2] * 0.7, CAMV[1] - 25, CAMV[0] + CAMV[2] * 0.7, CAMV[1] + 25)
def rings(g, tol, min_area, keep=False):
    g = g.intersection(VIEW).simplify(tol)
    return [np.array(p.exterior.coords) for p in (g.geoms if hasattr(g, "geoms") else [g])
            if isinstance(p, Polygon) and not p.is_empty and (keep or p.area >= min_area)]
NE2ISO = {v[0]: k for k, v in C["CTRY"].items()}
BGR = {k: rings(v, 0.03, 0.01) for k, v in RAWG.items() if k not in NE2ISO and v.intersects(VIEW)}
DATAR = {NE2ISO[k]: rings(RAWG[k], 0.008, 0.0005, True) for k in NE2ISO}
def proj(lon, lat):
    cx, cy, span = CAMV; s = PW / (span * COSF)
    return (PX + PW / 2 + (lon - cx) * COSF * s, PY + PH / 2 - (lat - cy) * s)
def projv(xy):
    cx, cy, span = CAMV; s = PW / (span * COSF)
    return [((PW / 2 + (x - cx) * COSF * s) * S, (PH / 2 - (y - cy) * s) * S) for x, y in xy]
PROJ_D = {k: [projv(r) for r in rs] for k, rs in DATAR.items()}
# house rule: the land between the river and the sea (Israel + West Bank + Gaza) outlined in gold, Green Line dashed green
_LANDI = unary_union([RAWG["Israel"], RAWG["Palestine"]]).buffer(0.002).buffer(-0.002)
LAND_R = [projv(r) for r in rings(_LANDI, 0.004, 0.0005, True)]
def _gl():
    g = RAWG["Palestine"].boundary.intersection(RAWG["Israel"].buffer(0.012)); out = []
    for ln in (g.geoms if hasattr(g, "geoms") else [g]):
        if ln.geom_type == "LineString" and ln.length > 0.02: out.append(projv(list(ln.simplify(0.003).coords)))
    return out
GL_R = _gl()
def dashed_poly(d, pts, col, w, dash=9, gap=6):
    """dashed polyline in supersampled pixel coords (pts already * S)."""
    on, left, cur = True, dash * S, [pts[0]]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        seg = math.hypot(x1 - x0, y1 - y0); pos = 0.0
        while seg - pos > 1e-6:
            step = min(left, seg - pos); pos += step; u = pos / seg
            p_ = (x0 + (x1 - x0) * u, y0 + (y1 - y0) * u); left -= step
            if on: cur.append(p_)
            if left <= 1e-6:
                if on and len(cur) >= 2: d.line(cur, fill=col, width=max(1, int(w * S)), joint="curve")
                on = not on; left = (dash if on else gap) * S; cur = [p_]
    if on and len(cur) >= 2: d.line(cur, fill=col, width=max(1, int(w * S)), joint="curve")
def fade(im):
    a = np.ones((PH * S, 1)); fd = int(46 * S); a[:fd, 0] = np.linspace(0, 1, fd) ** 1.5; a[-fd:, 0] = np.linspace(1, 0, fd) ** 1.5
    arr = np.array(im); arr[:, :, 3:4] = (arr[:, :, 3:4].astype(float) * a[:, :, None]).astype(np.uint8); return Image.fromarray(arr, "RGBA")
def base_map():
    im = Image.new("RGBA", (PW * S, PH * S), SEA); d = ImageDraw.Draw(im)
    for nm, rs in BGR.items():
        for r in rs: d.polygon(projv(r), fill=LAND, outline=BORDER)
    return im
BASE = base_map()

# ---------------------------------------------------------------- data
VAL = {}
for r in csv.DictReader(open(C["DATA"])):
    if r["gdppc_2011intl_usd_ppp"]: VAL[(r["iso3"], int(r["year"]))] = float(r["gdppc_2011intl_usd_ppp"])
Y0, Y1 = C["Y0"], C["Y1"]
def value(iso, yr):
    """value at fractional year; None if either bracketing annual value is missing (no bridging of gaps)."""
    yr = min(max(yr, Y0), Y1); a = int(math.floor(yr)); b = min(a + 1, Y1); u = yr - a
    va, vb = VAL.get((iso, a)), VAL.get((iso, b))
    if va is None or (vb is None and u > 1e-6): return None
    return va if vb is None else va + (vb - va) * u
def avail(iso, yr):
    """0..1 data presence, eased over ~0.35 years around a gap so a country fades out and back in."""
    ks = [value(iso, yr + dy) is not None for dy in (-0.35, 0, 0.35)]
    return 1.0 if all(ks) else (0.0 if not ks[1] else 0.5)
LASTY = {}
for (iso_, y_) in VAL: LASTY[iso_] = max(LASTY.get(iso_, 0), y_)
def ended(iso, yr): return yr > LASTY.get(iso, 9999) + 1e-6          # past the last year with data (series stops, not a gap)
def lerp(c1, c2, u): return tuple(int(c1[i] + (c2[i] - c1[i]) * u) for i in range(4))
RAMP = [hx(c) for c in C["RAMP"]]; LS0, LS1 = math.log10(C["SCALE"][0]), math.log10(C["SCALE"][1])
def tpos(v): return min(1, max(0, (math.log10(max(v, 1)) - LS0) / (LS1 - LS0)))
def ramp_col(v):
    x = tpos(v) * (len(RAMP) - 1); i = min(int(x), len(RAMP) - 2); return lerp(RAMP[i], RAMP[i + 1], x - i)
def money(v):
    return f"${v / 1000:.0f}k" if v >= 100000 else f"${v / 1000:.1f}k"

# ---------------------------------------------------------------- timeline + VO warp
TL = list(C["TL"]); TC = dict(C["T_CARDS"]); T_END = C["T_END"]; OUTFILE = C["FINAL"]; VO = A.vo
def silence_segs(path, n):
    SR = 16000
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    hop = 160; fr = np.sqrt(np.convolve(x ** 2, np.ones(320) / 320, "same")[::hop] + 1e-12); db = 20 * np.log10(fr)
    floor, peak = np.percentile(db, 8), np.percentile(db, 99)
    sp = db > max(floor + 7.0, peak - 36.0)          # pauses with room tone / breaths sit ~40 dB under the speech peak
    i = 0                                            # drop speech blips shorter than 0.1 s (clicks, breaths)
    while i < len(sp):
        if sp[i]:
            j = i
            while j < len(sp) and sp[j]: j += 1
            if j - i < 10: sp[i:j] = False
            i = j
        else: i += 1
    idx = np.where(sp)[0]
    if len(idx) == 0: return None
    first, last = idx[0], idx[-1]; gaps = []; i = first
    while i <= last:
        if not sp[i]:
            j = i
            while j <= last and not sp[j]: j += 1
            gaps.append((j - i, i, j)); i = j
        else: i += 1
    if len(gaps) < n - 1: return None
    cut = sorted(sorted(gaps, reverse=True)[:n - 1], key=lambda g: g[1])
    if cut and cut[-1][0] * 0.01 < 0.35: print("warning: shortest chosen pause", cut[-1][0] * 0.01, "s")
    st = [first] + [g[2] for g in cut]; en = [g[1] for g in cut] + [last]
    return [[round(a * 0.01, 2), round(b * 0.01, 2)] for a, b in zip(st, en)]
if VO:
    OUTFILE = C["FINAL_VO"]
    vdur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", VO], capture_output=True, text=True).stdout)
    nl = len(C["VO_MAP"]); segs = None
    if os.path.exists(f"{WD}/manual_segs.json"):
        segs = json.load(open(f"{WD}/manual_segs.json"))["segs"]; print("using manual_segs.json", len(segs))
    else:
        segs = silence_segs(VO, nl); json.dump({"segs": segs}, open(f"{WD}/vo_segs.json", "w")); print("silence segs ->", f"{WD}/vo_segs.json", segs)
    tb0 = [t for _, t in TL]; bb0 = [b for b, _ in TL]
    if segs and len(segs) == nl:
        kn = [(0.0, 0.0)]
        for (a_, b_), m in zip(segs, C["VO_MAP"]):
            tm = TC[m] if isinstance(m, str) else float(np.interp(m, bb0, tb0))
            tv = max(0.0, a_ - (0.15 if isinstance(m, str) else 0.1))
            if tm > kn[-1][0] + 0.05 and tv > kn[-1][1] + 0.05: kn.append((tm, tv))
        kn.append((max(T_END, kn[-1][0] + 1), max(vdur + 1.2, kn[-1][1] + 1)))
        km, kv = [k[0] for k in kn], [k[1] for k in kn]
        warp = lambda t: float(np.interp(t, km, kv))
        TL = [(b, warp(t)) for b, t in TL]; TC = {k: warp(v) for k, v in TC.items()}; T_END = vdur + 1.2
    else:
        print("segmentation did not give", nl, "lines; stretching uniformly. Write manual_segs.json to fix.")
        k = (vdur + 1.2) / T_END; TL = [(b, t * k) for b, t in TL]; TC = {kk: v * k for kk, v in TC.items()}; T_END = vdur + 1.2
tb = [t for _, t in TL]; bb = [b for b, _ in TL]; N = int(T_END * FPS)
def beat_at(t): return float(np.interp(t, tb, bb))
def time_of(b): return float(np.interp(b, bb, tb))
def smooth(u): return u * u * (3 - 2 * u)
def ramp(x, w=0.12): return max(0.0, min(1.0, x / w))
CARD_ORDER = sorted(TC.items(), key=lambda kv: kv[1])
HOOK = C["HOOK"]
if VO: HOOK = dict(HOOK, dur=min(HOOK["dur"], max(1.2, time_of(1950.0))))

# ---------------------------------------------------------------- drawing helpers
BG = None
def bg():
    global BG
    if BG is None:
        r = np.linspace(0, 1, H * S)[:, None, None]; g = np.array(BG_T)[None, None, :] * (1 - r) + np.array(BG_B)[None, None, :] * r
        BG = Image.fromarray((g * np.ones((1, W * S, 1))).astype(np.uint8), "RGBA")
    return BG.copy()
SHRUNK = set()
def txt(d, x, y, s, sz, col, w=800, anchor="la", maxw=None, alpha=1.0, stroke=0, shadow=False):
    if alpha <= 0.01 or not s: return
    f = font(sz, w); sz0 = sz
    if maxw:
        while f.getlength(s) > maxw * S and sz > 10: sz -= 1; f = font(sz, w)
        if sz < sz0 and (s, sz0) not in SHRUNK: SHRUNK.add((s, sz0)); print(f"note: shrunk {s!r} {sz0}->{sz}")
    c = col[:3] + (int(col[3] * alpha),)
    if shadow: d.text(((x + 2) * S, (y + 2.5) * S), s, font=f, fill=(0, 0, 0, int(150 * alpha)), anchor=anchor, stroke_width=int(stroke * S), stroke_fill=(0, 0, 0, int(150 * alpha)))
    if stroke: d.text((x * S, y * S), s, font=f, fill=c, anchor=anchor, stroke_width=max(1, int(stroke * S)), stroke_fill=(6, 14, 30, int(235 * alpha)))
    else: d.text((x * S, y * S), s, font=f, fill=c, anchor=anchor)
def tw(s, sz, w=800): return font(sz, w).getlength(s) / S
def circle(d, x, y, r, fill, ring=None, rw=1.5):
    if r < 0.6: return
    d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=fill, outline=ring, width=max(1, int(rw * S)) if ring else 0)
def overlay(im, col, a):
    if a > 0: im.alpha_composite(Image.new("RGBA", im.size, col[:3] + (int(255 * a),)))
def card(im, x, y, w, h, fill, edge, a=1.0, rad=34, ew=3):
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S], rad * S, fill=fill[:3] + (int(fill[3] * a),), outline=(edge[:3] + (int(edge[3] * a),)) if edge else None, width=int(ew * S))
    im.alpha_composite(lay)
def poly(d, pts, col, w):
    if len(pts) >= 2: d.line([(float(x) * S, float(y) * S) for x, y in pts], fill=col, width=max(1, int(w * S)), joint="curve")
def dashed_v(d, x, y0, y1, col, w=1.5, dash=7, gap=6):
    y = y0
    while y < y1: d.line([(x * S, y * S), (x * S, min(y + dash, y1) * S)], fill=col, width=max(1, int(w * S))); y += dash + gap

# flags (flag-icons 7.5.0, MIT) rendered once
import cairosvg
FLAGS = {}
FW, FH = 34, 25
for iso, code in C["FLAG"].items():
    png = cairosvg.svg2png(url=f"/home/claude/flags_pkg/package/flags/4x3/{code}.svg", output_width=FW * S, output_height=FH * S)
    fl = Image.open(io.BytesIO(png)).convert("RGBA"); m = Image.new("L", fl.size, 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, fl.size[0] - 1, fl.size[1] - 1], 4 * S, fill=255)
    fl.putalpha(Image.fromarray(np.minimum(np.array(fl.split()[3]), np.array(m)))); FLAGS[iso] = fl
def paste_flag(im, iso, x, y, a):
    fl = FLAGS[iso]
    if a < 0.99: fl = fl.copy(); fl.putalpha(Image.fromarray((np.array(fl.split()[3]) * a).astype(np.uint8)))
    im.alpha_composite(fl, (int(x * S), int(y * S)))
    d = ImageDraw.Draw(im); d.rounded_rectangle([x * S, y * S, (x + FW) * S, (y + FH) * S], 4 * S, outline=(255, 255, 255, int(120 * a)), width=S)

# caption wrapping checks
EVW = {}
for e in C["EVENTS"]:
    en, he = e[1].split("\n"), e[2].split("\n"); EVW[e[0]] = (en, he)
    for l in en:
        if tw(l, C["EV_FS"], 900) > C["EV_W"]: print("WARNING caption line wider than strip:", l, round(tw(l, C["EV_FS"], 900)))
    for l in he:
        if tw(l, C["EV_HFS"], 800) > C["EV_W"]: print("WARNING HE caption line wider than strip:", l, round(tw(l, C["EV_HFS"], 800)))

# chart geometry
X0, Y0P, X1, Y1P = C["PLOT"]; YMAX = C["YMAX"]
def cx_(yr): return X0 + (yr - Y0) / (Y1 - Y0) * (X1 - X0)
def cy_(v): return Y1P - min(v, YMAX * 1.04) / YMAX * (Y1P - Y0P)
def series_pts(iso, yr):
    """list of polylines (split at gaps) from 1950 up to yr (fractional end point)."""
    out, cur = [], []
    for y in range(Y0, int(math.floor(yr)) + 1):
        v = VAL.get((iso, y))
        if v is None:
            if cur: out.append(cur); cur = []
            continue
        cur.append((cx_(y), cy_(v)))
    v = value(iso, yr)
    if v is not None and yr > math.floor(yr) + 1e-6: cur.append((cx_(yr), cy_(v)))
    if cur: out.append(cur)
    return out

# ---------------------------------------------------------------- payoff bar card (cfg BARS)
def draw_bars(im, d, lay, tt, a):
    B = C["BARS"]; base = 1100; top = 600; vmax = B["israel"][3]; k = (base - top) / vmax
    txt(d, 540, 376, B["title"][0], 46, WHITE, 900, "mm", 900, a); txt(d, 540, 434, B["title"][1], 40, SKY, 800, "mm", 900, a)
    sx0, sx1, ix0, ix1 = 420, 580, 690, 870
    d.line([(100 * S, base * S), (980 * S, base * S)], fill=(160, 190, 235, int(120 * a)), width=S)
    y = base; tot = 0; labs = []
    for j, (iso, en, he, v, yr_, col) in enumerate(B["stack"]):
        u = smooth(min(1, max(0, (tt - 0.35 - 0.5 * j) / 0.45)))
        if u <= 0: continue
        h_ = v * k * u; d.rectangle([sx0 * S, (y - h_) * S, sx1 * S, y * S], fill=hx(col, int(255 * a)))
        if j: d.line([(sx0 * S, y * S), (sx1 * S, y * S)], fill=hx("#0E1E3A", int(255 * a)), width=2 * S)
        labs.append((y - h_ / 2, iso, en, he, v, yr_, u)); y -= h_; tot += v * u
    ly0 = base - 30
    for j, (my, iso, en, he, v, yr_, u) in enumerate(labs):
        ly = ly0 - 74 * j; la = a * u
        d.line([((sx0 - 4) * S, my * S), ((sx0 - 18) * S, ly * S)], fill=(200, 215, 240, int(150 * la)), width=S)
        paste_flag(lay, iso, 92, ly - 26, la); d = ImageDraw.Draw(lay)
        txt(d, 134, ly - 12, f"{en} ${v:,}", 30, WHITE, 900, "lm", sx0 - 150, la); txt(d, 134, ly + 20, f"{he} ({yr_})", 27, hx("#cfdcf0"), 800, "lm", sx0 - 150, la)
    if labs:
        txt(d, (sx0 + sx1) / 2, y - 32, f"${tot / 1000:.1f}k", 46, WHITE, 900, "mm", alpha=a)
        txt(d, (sx0 + sx1) / 2, base + 34, "The four combined", 30, WHITE, 800, "mm", 300, alpha=a)
        txt(d, (sx0 + sx1) / 2, base + 70, "ארבעתן ביחד", 28, hx("#cfdcf0"), 800, "mm", alpha=a)
    iso, en, he, v, yr_ = B["israel"]; u = smooth(min(1, max(0, (tt - 2.6) / 0.9)))
    if u > 0:
        h_ = v * k * u; d.rectangle([ix0 * S, (base - h_) * S, ix1 * S, base * S], fill=hx(C["ISR_LINE"], int(255 * a)))
        txt(d, (ix0 + ix1) / 2, base - h_ - 36, f"${v * u / 1000:.1f}k", 56, SKY, 900, "mm", alpha=a)
        paste_flag(lay, iso, (ix0 + ix1) / 2 - FW / 2, base + 14, a * u); d = ImageDraw.Draw(lay)
        txt(d, (ix0 + ix1) / 2, base + 62, f"{en} ({yr_}) {he}", 28, SKY, 900, "mm", 330, alpha=a * u)
    ra = a * ramp(tt - 3.9, 0.35)
    txt(d, 540, 1232, B["ratio"][0], 52, SKY, 900, "mm", 900, ra); txt(d, 540, 1290, B["ratio"][1], 44, SKY, 800, "mm", 900, ra)
    ta = a * ramp(tt - 4.6, 0.35)
    for i, l in enumerate(B["total"]): txt(d, 540, 1346 + i * 37 + (8 if i > 1 else 0), l, 31 if i < 2 else 28, WHITE if i < 2 else hx("#cfdcf0"), 800, "mm", 900, ta)
    for i, l in enumerate(B["foot"]): txt(d, 540, 1498 + i * 25, l, 21, DISCC, 700, "mm", 900, a)
    return d

# ---------------------------------------------------------------- frames
SNAPS = [float(x) for x in A.snaps.split(",")] if A.snaps else None
SNAPF = set(int(round(s * FPS)) for s in SNAPS) if SNAPS else set()
SIL = C["OUT"] if not VO else C["OUT"].replace(".mp4", "_vo.mp4")
ff = None if SNAPS else subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
     "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium", "-r", str(FPS), SIL], stdin=subprocess.PIPE)
EVS = C["EVENTS"]; CT = C["CTRY"]
for f in range(N):
    if SNAPS and f not in SNAPF: continue
    t = f / FPS; b = beat_at(t); yr = min(max(b, Y0), Y1)
    ev = [e for e in EVS if e[0] <= b + 1e-6]; e = ev[-1] if ev else EVS[0]; te = time_of(e[0])
    endfade = 1 - ramp(t - CARD_ORDER[0][1], 0.3)
    im = bg()
    # ---- map
    pan = BASE.copy(); d = ImageDraw.Draw(pan)
    for iso, prs in PROJ_D.items():
        v = value(iso, yr); av = avail(iso, yr)
        col = lerp(NODATA, ramp_col(v), av) if v is not None else NODATA
        for p in prs: d.polygon(p, fill=col, outline=(10, 22, 44, 255))
    # highlight pulses for the current event's countries
    hl = e[3] if t - te < 3.2 else []
    pul = 0.5 + 0.5 * math.sin((t - te) * 5.0)
    for iso in hl:
        a = ramp(t - te, 0.25) * (1 - ramp(t - te - 2.6, 0.6))
        for p in PROJ_D[iso]: d.line(p + [p[0]], fill=(255, 255, 255, int((150 + 100 * pul) * a)), width=int(2.6 * S), joint="curve")
    for p in LAND_R: d.line(p + [p[0]], fill=(6, 14, 30, 200), width=int(6.5 * S), joint="curve")
    for p in LAND_R: d.line(p + [p[0]], fill=hx(C["GOLD"]), width=int(3.6 * S), joint="curve")
    for p in GL_R:
        dashed_poly(d, p, (6, 14, 30, 220), 5.0); dashed_poly(d, p, C["GREEN_LINE"] + (255,), 3.0)
    im.alpha_composite(fade(pan), (PX * S, PY * S))
    # map labels
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    for iso, (ne, en, he, lab, lead, size, when) in CT.items():
        if when == "never" or lab is None: continue
        hot = iso in hl and t - te < 3.2
        if when == "event":
            la = ramp(t - te, 0.25) * (1 - ramp(t - te - 2.9, 0.4)) if iso in e[3] else 0.0
            if la <= 0.01: continue
        else: la = 1.0
        v = value(iso, yr); x, y = proj(*lab); fn, fh, fv = C["LAB_FS"][size]
        if v is not None: vs = money(v)
        elif ended(iso, yr): vs = f"{money(VAL[(iso, LASTY[iso])])} ({LASTY[iso]})"
        else: vs = "no data"
        hgt = fn * 1.02 + fh * 1.04 + fv
        top = y - hgt / 2
        if lead:
            lx, ly = proj(*lead); circle(d, lx, ly, 5, WHITE[:3] + (int(235 * la),), hx("#0E1E3A"), 2)
            ty = top + hgt + 2 if ly > y else top - 2
            d.line([(lx * S, ly * S), (x * S, ty * S)], fill=(255, 255, 255, int(200 * la)), width=int(2.2 * S))
        ncol = SKY if iso == "ISR" else WHITE
        hcol = SKY if iso == "ISR" else (WHITE if hot else hx("#cfdcf0"))
        txt(d, x, top + fn * 0.5, en, fn, ncol, 900, "mm", alpha=la, stroke=4)
        txt(d, x, top + fn * 1.02 + fh * 0.5, he, fh, hcol, 800, "mm", alpha=la, stroke=4)
        txt(d, x, top + fn * 1.02 + fh * 1.04 + fv * 0.5, vs, fv if v is not None else fh, WHITE if v is not None else DISCC, 900, "mm",
            alpha=la, stroke=max(4, fv * 0.11), shadow=True)
    im.alpha_composite(lay)
    # legend (log colour scale)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay); lx, ly = C["LEGEND"]; LW_ = 330; LF = C["LEG_FS"]
    d.rounded_rectangle([lx * S, ly * S, (lx + LW_ + 32) * S, (ly + 108) * S], 14 * S, fill=(8, 18, 38, 225), outline=(120, 160, 220, 110), width=S)
    txt(d, lx + 16, ly + 20, "$ per person | דולר לנפש", LF, WHITE, 800, "lm", LW_)
    for i in range(LW_):
        vv = 10 ** (LS0 + (LS1 - LS0) * i / (LW_ - 1)); c = ramp_col(vv)
        d.line([((lx + 16 + i) * S, (ly + 40) * S), ((lx + 16 + i) * S, (ly + 58) * S)], fill=c, width=S)
    for tk, lab in ((1000, "1k"), (3000, "3k"), (10000, "10k"), (30000, "30k"), (100000, "100k")):
        xx = lx + 16 + tpos(tk) * (LW_ - 1); d.line([(xx * S, (ly + 58) * S), (xx * S, (ly + 65) * S)], fill=SUBC, width=S)
        txt(d, min(xx, lx + LW_ - 12), ly + 84, lab, LF, WHITE, 800, "mm")
    d.rectangle([(lx + 16) * S, (ly + 40) * S, (lx + 16 + LW_) * S, (ly + 58) * S], outline=(255, 255, 255, 70), width=S)
    im.alpha_composite(lay)
    # ---- top band: running year + title
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    yx, yy0 = C["YEAR_XY"]
    txt(d, yx, yy0, f"{int(math.floor(yr + 1e-6))}", C["YEAR_FS"], WHITE, 900, "la", shadow=True)
    tx = C["TITLE_X"]
    ty_ = C["TITLE_Y"]; f1, f2, f3 = C["TITLE_FS"]
    txt(d, tx, ty_, "GDP per person", f1, WHITE, 900, "la", 1050 - tx)
    txt(d, tx, ty_ + f1 * 1.08, "תוצר לנפש", f2, SKY, 800, "la", 1050 - tx)
    est = C.get("EST_FROM") is not None and yr > C["EST_FROM"] + 1e-6
    if est: txt(d, tx, ty_ + f1 * 1.08 + f2 * 1.2, "2023 to 2026: IMF estimates", f3, SKY, 800, "la", 1050 - tx)
    else: txt(d, tx, ty_ + f1 * 1.08 + f2 * 1.2, "Inflation-adjusted, 2011 int'l $", f3, hx("#cfdcf0"), 700, "la", 1050 - tx)
    # ---- event strip
    a = (ramp(t - te, 0.2) if e[0] > EVS[0][0] else 1.0) * endfade
    if EVS[0][0] < e[0] < EVS[-1][0]: a *= 1 - ramp(t - te - C.get("EV_HOLD", 5.0), 0.5)   # stale captions fade out
    en_l, he_l = EVW[e[0]]; yy = C["EV_Y"]
    for l in en_l: txt(d, C["EV_X"], yy, l, C["EV_FS"], WHITE, 900, "ma", C["EV_W"], a, stroke=3); yy += C["EV_FS"] * 1.12
    yy += 4
    for l in he_l: txt(d, C["EV_X"], yy, l, C["EV_HFS"], SKY, 800, "ma", C["EV_W"], a, stroke=3); yy += C["EV_HFS"] * 1.18
    im.alpha_composite(lay)
    # ---- chart
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    for v in C["YTICKS"]:
        y = cy_(v); d.line([(X0 * S, y * S), ((X1 + 4) * S, y * S)], fill=(160, 190, 235, 34 if v else 90), width=S)
        txt(d, X0 - 12, y, "$0" if v == 0 else f"${v // 1000}k", C["CH_FS"], hx("#cfdcf0"), 800, "rm")
    for xt in C["XTICKS"]:
        dx = cx_(xt) - cx_(yr); ta_ = 1.0 if (dx < -40 or dx > 330 or xt == Y0 and yr < Y0 + 0.01) else 0.0
        if xt == Y1 and yr >= Y1 - 0.01: ta_ = 1.0
        txt(d, cx_(xt), Y1P + 24, str(xt), C["CH_FS"], hx("#cfdcf0"), 800, "mm", alpha=ta_)
    # IMF-estimate zone (stock-chart style shaded band)
    if C.get("EST_FROM") is not None and yr > C["EST_FROM"]:
        ea = ramp(yr - C["EST_FROM"], 0.4); xa, xb = cx_(C["EST_FROM"]), cx_(min(yr, Y1))
        d.rectangle([xa * S, Y0P * S, xb * S, Y1P * S], fill=(69, 164, 221, int(34 * ea)))
        dashed_v(d, xa, Y0P - 6, Y1P, (69, 164, 221, int(200 * ea)), 1.4)
        txt(d, xa - 8, Y0P + 14, C["EST_LABEL"][0], 26, SKY, 800, "rm", alpha=ea, stroke=3)
        txt(d, xa - 8, Y0P + 44, C["EST_LABEL"][1], 26, SKY, 800, "rm", alpha=ea, stroke=3)
    # event markers: bright while live, faint after
    for e2 in EVS:
        if e2[4] is None or b < e2[0]: continue
        live = 1 - ramp(t - time_of(e2[0]) - 2.8, 0.6); x = cx_(e2[4])
        dashed_v(d, x, Y0P - 6, Y1P, (190, 215, 245, int(40 + 140 * live)), 2.0)
        if live > 0.02: txt(d, x - 8, Y0P + 14, str(e2[4]), C["CH_FS"], WHITE, 900, "rm", alpha=live, stroke=3)
    # Israel area fill (stock style)
    bx0, by0, bx1, by1 = int((X0 - 4) * S), int((Y0P - 20) * S), int((X1 + 8) * S), int(Y1P * S)
    for seg in series_pts("ISR", yr):
        if len(seg) >= 2:
            ar = Image.new("L", (bx1 - bx0, by1 - by0), 0)
            ImageDraw.Draw(ar).polygon([(x * S - bx0, y * S - by0) for x, y in seg] + [(seg[-1][0] * S - bx0, by1 - by0), (seg[0][0] * S - bx0, by1 - by0)], fill=255)
            gm = np.linspace(66, 4, by1 - by0)[:, None]
            m = (np.array(ar).astype(float) / 255 * gm).astype(np.uint8)
            fl = Image.new("RGBA", ar.size, hx(C["ISR_LINE"])[:3] + (0,)); fl.putalpha(Image.fromarray(m)); lay.alpha_composite(fl, (bx0, by0))
    d = ImageDraw.Draw(lay)
    heads = []
    for iso, en, he in C["LINES"]:
        isr = iso == "ISR"
        for seg in series_pts(iso, yr):
            if isr: poly(d, seg, hx(C["ISR_LINE"], 90), 16); poly(d, seg, hx(C["ISR_LINE"]), 7.5)
            else: poly(d, seg, hx(C["OTHER_LINE"], 230), 3.6)
        v = value(iso, yr)
        if v is not None: heads.append([cy_(v), iso, en, he, v, avail(iso, yr), None])
        else:
            prev = max([y_ for (i_, y_) in VAL if i_ == iso and y_ <= yr] or [None]) if any(i_ == iso for (i_, _) in VAL) else None
            if prev: heads.append([cy_(VAL[(iso, prev)]), iso, en, he, None, 0.6, prev if ended(iso, yr) else "gap"])
    for hy, iso, en, he, v, av, _ in heads:
        if v is not None:
            hx_ = cx_(yr); circle(d, hx_, hy, 10 if iso == "ISR" else 6, hx(C["ISR_LINE"]) if iso == "ISR" else hx("#c9d6ea"), hx("#0E1E3A") if iso != "ISR" else WHITE, 2.5)
    # repel end labels
    heads.sort(key=lambda h: h[0]); GAP = C["CH_FS"] + 6; ys = [h[0] for h in heads]
    for i in range(1, len(ys)): ys[i] = max(ys[i], ys[i - 1] + GAP)
    over = ys[-1] - (Y1P + 2) if ys else 0
    if over > 0:
        ys = [y - over for y in ys]
        for i in range(len(ys) - 2, -1, -1): ys[i] = min(ys[i], ys[i + 1] - GAP)
    im.alpha_composite(lay)
    lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    lxl = cx_(yr) + 16
    for (hy, iso, en, he, v, av, endy), ly in zip(heads, ys):
        isr = iso == "ISR"; a = 0.45 if v is None else 1.0
        if abs(ly - hy) > 3 and v is not None: d.line([((cx_(yr) + 6) * S, hy * S), ((lxl - 3) * S, ly * S)], fill=(200, 215, 240, 120), width=S)
        paste_flag(lay, iso, lxl, ly - FH / 2, a); d = ImageDraw.Draw(lay)
        vtxt = money(v) if v is not None else ("no data" if endy == "gap" else f"{money(VAL[(iso, endy)])} ({endy})")
        fs_ = C["CH_FS"] + (4 if isr else 0); nx = lxl + FW + 9
        txt(d, nx, ly, vtxt, fs_, SKY if isr else WHITE, 900, "lm", alpha=a, stroke=3)
        nx += tw(vtxt, fs_, 900) + 10
        txt(d, nx, ly, f"{en} {he}", C["CH_FS"], SKY if isr else hx("#cfdcf0"), 800, "lm", alpha=a, stroke=3, maxw=1072 - nx)
    # source line(s)
    dk = max(k for k in C["DISC"] if k <= max(b, min(C["DISC"])) + 1e-6)
    for i, l in enumerate(C["DISC"][dk]): txt(d, 540, C["DISC_Y"] + i * C["DISC_LH"], l, C["DISC_FS"], DISCC, 700, "ma", 1030, endfade)
    im.alpha_composite(lay)
    # ---- hook (frame 0)
    hk = HOOK
    if t < hk["dur"]:
        a = 1.0 if t < hk["dur"] - 0.22 else max(0, (hk["dur"] - t) / 0.22)
        overlay(im, hx("#0A1630"), 0.82 * a); hy_, hh_ = C.get("HOOK_BOX", (650, 500)); card(im, 114, hy_, 852, hh_, hx("#2749D3", 245), SKY, a, 40, 4)
        sc = 1.0 + 0.035 * min(1, t / hk["dur"]); lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
        for (yy2, s, col, sz, w_) in hk["lines"]: txt(d, 540, yy2, s, sz * sc, hx(col), w_, "mm", 800, a)
        im.alpha_composite(lay)
    # ---- end cards
    if t >= CARD_ORDER[0][1]:
        overlay(im, hx("#06101F"), 0.74 * min(1, (t - CARD_ORDER[0][1]) / 0.4))
        for i, (key, t0) in enumerate(CARD_ORDER):
            if t < t0: continue
            t1 = CARD_ORDER[i + 1][1] if i + 1 < len(CARD_ORDER) else 1e9
            a = min(1, (t - t0) / 0.4) * (1 - min(1, max(0, (t - t1) / 0.35)))
            if a <= 0: continue
            cd = C["CARDS"][key]
            card(im, 66, cd["y"], 948, cd["h"], hx("#0E1E3A", 248), hx(cd["edge"], 230), a, 36, cd["ew"])
            lay = Image.new("RGBA", im.size, (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            for (yy2, s, col, sz, w_) in cd["lines"]: txt(d, 540, yy2, s, sz, hx(col), w_, "mm", 830, a)
            if key == "BARS": draw_bars(im, d, lay, t - t0, a)
            im.alpha_composite(lay)
    out = im.reduce(S).convert("RGB")
    if SNAPS: os.makedirs(C["SNAPDIR"], exist_ok=True); out.save(f"{C['SNAPDIR']}/{C['TAG']}_{t:05.2f}.png"); continue
    ff.stdin.write(out.tobytes())
    if f % 300 == 0: print(f"frame {f}/{N}", flush=True)
if SNAPS: print("snaps ->", C["SNAPDIR"]); sys.exit()
ff.stdin.close(); ff.wait(); print("video", SIL, f"{T_END:.1f}s")
if A.silent: sys.exit()
# ---------------------------------------------------------------- audio + mux
mus = f"{WD}/{C['TAG']}_{'vo' if VO else 'mus'}.wav"
hits = ",".join(f"{time_of(x):.2f}" for x in C.get("HIT_BEATS", []))
subprocess.run(["python3", f"{HERE}/music/apple2.py", mus, f"{T_END:.2f}", C["STYLE"], hits], check=True)
aud = mus
if VO:
    aud = f"{WD}/{C['TAG']}_mix.wav"; subprocess.run(["python3", f"{HERE}/vo/mix.py", VO, mus, f"{T_END:.2f}", aud], check=True)
subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", SIL, "-i", aud, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", f"{T_END:.2f}", "-movflags", "+faststart", OUTFILE], check=True)
print("final", OUTFILE)
