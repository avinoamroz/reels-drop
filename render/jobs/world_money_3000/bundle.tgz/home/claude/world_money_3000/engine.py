"""world_money_3000: 3,000 years of money on a moving world map. A gold coin flies from each financial centre to the next
(Babylon, Lydia, Rome, Chengdu, Florence, Amsterdam, London, Bretton Woods, Washington, New York) while a year counter
runs; London 1914 and New York today radiate lines to the world. Israel tie: London 1899 to Jaffa 1903 (Bank Leumi).
Circular: "It's been moving for..." lands back on the frame 0 hook "3,000 years."
python3 engine.py [--frames t1,t2,...] [--out path.mp4]"""
import os, sys, math, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

D = os.path.dirname(os.path.abspath(__file__)); ARGS = sys.argv[1:]
TM = Timing(D, tail=0.95); wt, lt, CUT, END = TM.wt, TM.lt, TM.CUT, TM.END
GW = json.load(open(f"{D}/geo_world.json")); GIL = json.load(open(f"{D}/geo_il.json"))

C = {"babylon": (44.42, 32.54, "Babylon"), "sardis": (28.04, 38.49, "Sardis, Lydia"), "rome": (12.49, 41.89, "Rome"),
     "chengdu": (104.07, 30.67, "Chengdu"), "florence": (11.26, 43.77, "Florence"), "amsterdam": (4.90, 52.37, "Amsterdam"),
     "london": (-0.09, 51.51, "London"), "bw": (-71.44, 44.26, "Bretton Woods"), "dc": (-77.04, 38.90, "Washington"),
     "nyc": (-74.0, 40.71, "New York"), "jaffa": (34.75, 32.05, "Jaffa")}
# per line: centre the coin sits at, camera (lon, lat, px per degree, screen y), year shown, place label
WIDE = (18.0, 26.0, 5.3, 960)
L = [
    ("babylon", WIDE, None, None),
    ("babylon", (44.4, 32.5, 15, 900), -1750, "Babylon"),
    ("sardis", (28.0, 38.5, 15, 1110), -600, "Lydia"),
    ("rome", (12.5, 41.9, 13, 900), -211, "Rome"),
    ("chengdu", (104.0, 30.7, 9, 900), 1024, "China"),
    ("florence", (11.3, 43.8, 16, 900), 1397, "Florence"),
    ("amsterdam", (4.9, 52.4, 17, 900), 1602, "Amsterdam"),
    ("london", (-0.1, 51.5, 19, 1110), 1694, "London"),
    ("london", (5.0, 45.0, 6.5, 900), 1694, "City of London"),
    ("london", (-0.1, 51.5, 13, 900), 1821, "London"),
    ("london", (20.0, 18.0, 4.6, 920), 1914, "London"),
    ("bw", (-71.4, 44.3, 13, 900), 1944, "Bretton Woods"),
    ("dc", (-77.0, 38.9, 13, 900), 1971, "Washington"),
    ("nyc", (20.0, 18.0, 4.6, 920), 2026, "New York"),
    ("jaffa", (17.0, 42.0, 8.5, 900), 1903, "London to Jaffa"),
    ("babylon", WIDE, None, None),
]
NL = TM.n; assert NL == len(L), (NL, len(L))
CARD = {
    1: (None, "Hammurabi's laws cap interest: 20% max", "Code of Hammurabi, c. 1753 BC"),
    2: (None, "The first coins: electrum, gold and silver", "Lydia, c. 625 to 600 BC (LBMA)"),
    3: (None, "One silver coin across the Mediterranean", "Denarius, from c. 211 BC (World History Encyclopedia)"),
    4: (None, "The first government paper money: jiaozi", "Song dynasty, Chengdu, 1024"),
    5: (None, "The Medici bank: branches from London to Rome", "Medici Bank, 1397 to 1494"),
    6: (None, "Dutch East India Company shares trade in public", "Amsterdam exchange, 1602 (Euronext)"),
    7: (None, "£1.2 million lent in 11 days, for wars with France", "Bank of England Museum"),
    8: (None, "\"Gentlemanly capitalism\": empire driven by the City", "Cain and Hopkins, British Imperialism, 1993"),
    9: (None, "The pound tied to gold", "Convertibility restored, 1821 (Peel's Bill)"),
    10: (("40%", 40, "%"), "of all foreign investment on Earth", "UK $18.0B of $44.0B, 1913 to 1914 (Hardach)"),
    11: (None, "44 nations. Dollar tied to gold at $35 an ounce", "Federal Reserve History"),
    12: (None, "15 Aug 1971: no more gold for dollars", "Federal Reserve History"),
    13: (("57%", 56.7, "%"), "of world reserves are in dollars", "IMF COFER, Q2 2026: 56.7%"),
    14: (None, "Anglo-Palestine Company. Today: Bank Leumi", "Jewish Colonial Trust, London 1899. Jaffa, 1903"),
}
PHOTO = {2: ("wm_lydia_trite.jpg", "Electrum trite: Photography by CNG coins, CC BY-SA 3.0"),
         7: ("wm_boe.jpg", "Bank of England: Diliff, CC BY-SA 3.0")}
PH_W, PH_H, PH_Y = 860, 420, 610
PHS = {k: load_photo(f"{D}/{v[0]}", PH_W, PH_H) for k, v in PHOTO.items()}
RAD = {10: ("london", ["nyc", (-58.4, -34.6), (72.9, 19.1), (18.4, -33.9), (151.2, -33.9), (-79.4, 43.7), (121.5, 31.2)]),
       13: ("nyc", [(-0.09, 51.51), (139.7, 35.7), (114.2, 22.3), (103.8, 1.3), (-46.6, -23.5), (55.3, 25.2), (8.5, 47.4)])}
T_LOOP = CUT[15]

# ------------------------------------------------------------------ camera
def cam_key(i): return L[i][1]
HOP = 1.25
def camera(t):
    i = TM.scene(t)
    a = cam_key(i - 1) if i > 0 else cam_key(0); b = cam_key(i)
    u = ease((t - CUT[i]) / HOP) if i > 0 else 1.0
    lon = lerp(a[0], b[0], u); lat = lerp(a[1], b[1], u)
    k = math.exp(lerp(math.log(a[2]), math.log(b[2]), u))
    dist = math.hypot((b[0] - a[0]) * 0.8, b[1] - a[1])
    dip = clamp(dist / 60) * 0.55
    k *= 1 - dip * math.sin(math.pi * u)
    cy = lerp(a[3], b[3], u)
    return lon, lat, k, cy
COSF = math.cos(math.radians(35))
def proj(cam):
    lon0, lat0, k, cy = cam
    return lambda lo, la: (540 + (lo - lon0) * COSF * k, cy - (la - lat0) * k)
def ll(key): return C[key][:2] if isinstance(key, str) else key

def draw_world(c, P, k):
    for nm, rings in GW.items():
        poly(c, rings, P)
    c.set_source_rgba(*hx("#1C3566")[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.28); c.set_line_width(1.2); c.stroke()
    poly(c, GIL["isr"], P); c.set_source_rgba(*GOLD_IL[:3], 1); c.fill()
    poly(c, GIL["pal"], P); c.set_source_rgba(*GOLD_PA[:3], 1); c.fill()
    if k > 20:
        c.set_source_rgba(*GREEN[:3], 1); c.set_line_width(2)
        for ln in GIL["green"]:
            for i, (lo, la) in enumerate(ln):
                x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
            c.stroke()

def arc_pts(P, a, b, u, n=48, bend=0.18):
    x0, y0 = P(*a); x1, y1 = P(*b); mx, my = (x0 + x1) / 2, (y0 + y1) / 2; dx, dy = x1 - x0, y1 - y0
    cx_, cy_ = mx + dy * bend, my - dx * bend - math.hypot(dx, dy) * 0.12
    pts = []
    for j in range(n + 1):
        s = j / n * u; a_ = (1 - s) ** 2; b_ = 2 * (1 - s) * s; c2 = s * s
        pts.append((a_ * x0 + b_ * cx_ + c2 * x1, a_ * y0 + b_ * cy_ + c2 * y1))
    return pts
def stroke_pts(c, pts, col, a, w):
    if len(pts) < 2 or a <= 0.01: return
    for j, (x, y) in enumerate(pts): (c.move_to if j == 0 else c.line_to)(x, y)
    c.set_source_rgba(*col[:3], a); c.set_line_width(w); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
def coin(c, x, y, r, a):
    if a <= 0.01: return
    glow(c, x, y, r * 4.5, GOLD, 0.45 * a)
    c.arc(x, y, r, 0, 6.283); c.set_source_rgba(*GOLD[:3], a); c.fill()
    c.arc(x, y, r * 0.72, 0, 6.283); c.set_source_rgba(*hx("#C9962E")[:3], a); c.set_line_width(max(2, r * 0.16)); c.stroke()
HOPS = []
for i in range(1, NL - 1):
    if L[i][0] != L[i - 1][0] or i == 14:
        frm = "london" if i == 14 else L[i - 1][0]
        HOPS.append((i, frm, L[i][0]))
ROUTE = ["babylon", "sardis", "rome", "chengdu", "florence", "amsterdam", "london", "bw", "dc", "nyc"]

def draw_map(c, t):
    i = TM.scene(t); cam = camera(t); P = proj(cam); k = cam[2]
    draw_world(c, P, k)
    loop = ramp(t, T_LOOP + 0.3, END - 0.9)
    # faint dotted full route (frame 0 and the loop)
    for a_, b_ in zip(ROUTE, ROUTE[1:]):
        pts = arc_pts(P, ll(a_), ll(b_), 1.0, 40)
        for j in range(0, len(pts) - 1, 2):
            c.move_to(*pts[j]); c.line_to(*pts[j + 1])
        c.set_source_rgba(*SKY[:3], 0.55); c.set_line_width(3.5); c.stroke()
    # completed and current hops
    cx, cy_ = P(*ll(L[i][0]))
    for (hi, frm, to) in HOPS:
        if t < CUT[hi]: continue
        u = eout((t - CUT[hi] - 0.1) / (HOP + 0.1))
        pts = arc_pts(P, ll(frm), ll(to), u)
        stroke_pts(c, pts, GOLD, (0.9 if hi == i else 0.55) * (1 - loop), 5 if hi == i else 3.5)
        if hi == i and u < 1: cx, cy_ = pts[-1]
    # radiating lines
    for ri, (hub, tos) in RAD.items():
        if not (CUT[ri] <= t < CUT[ri + 1] + 0.4): continue
        fa = 1 - ramp(t, CUT[ri + 1] - 0.1, CUT[ri + 1] + 0.4)
        for n, to in enumerate(tos):
            u = eout((t - CUT[ri] - 0.9 - 0.18 * n) / 0.8)
            if u <= 0: continue
            pts = arc_pts(P, ll(hub), ll(to), u, 40, 0.12)
            stroke_pts(c, pts, SKY if ri == 10 else GOLD, 0.85 * fa, 3.5)
            if u >= 1:
                x, y = P(*ll(to)); c.arc(x, y, 7, 0, 6.283); c.set_source_rgba(*(SKY if ri == 10 else GOLD)[:3], fa); c.fill()
    # visited centres
    seen = []
    for j in range(1, min(i, NL - 2) + 1):
        if L[j][0] not in seen: seen.append(L[j][0])
    for key in seen:
        x, y = P(*ll(key))
        if not (-50 < x < 1130 and 150 < y < 1700): continue
        cur = key == L[i][0]
        c.arc(x, y, 9 if cur else 7, 0, 6.283); c.set_source_rgba(*(GOLD if cur else SKY)[:3], 1 - loop); c.fill()
        if k >= 12 and not cur:
            text(c, C[key][2], 38, x, y - 22, 700, MUTE, (1 - loop) * 0.9)
    if i == 14 or (i == 15 and loop < 1):   # Jaffa pin
        x, y = P(*ll("jaffa")); pa = ramp(t, CUT[14] + 1.0, CUT[14] + 1.4) * (1 - loop)
        pin(c, x, y, GOLD, pa, 1.2)
    # the coin
    if i == 0 or t >= T_LOOP:
        x, y = P(*ll("babylon")); ph = (t * 0.9) % 1.0
        c.set_source_rgba(*GOLD[:3], 1 - ph); c.set_line_width(4); c.arc(x, y, 12 + 46 * ph, 0, 6.283); c.stroke()
        coin(c, x, y, 16, 1.0)
    else:
        br = 1 + 0.06 * math.sin(t * 4)
        coin(c, cx, cy_, 20 * br, 1.0)
        if i not in (8, 10, 13) and t - CUT[i] > HOP:
            lab = C[L[i][0]][2]
            text(c, lab, 50, cx, cy_ + 76, 900, WHITE, ramp(t, CUT[i] + HOP, CUT[i] + HOP + 0.3))

def yfmt(y): return f"{-y:,} BC".replace(",", "") if y < 0 else f"{y}"
def year_now(t):
    i = TM.scene(t)
    y1 = L[i][2]; y0 = L[i - 1][2] if i > 1 and L[i - 1][2] is not None else y1
    if y1 is None: return None
    if i == 14: return 1903
    u = eout((t - CUT[i]) / HOP); v = lerp(y0, y1, u)
    v = int(round(v));  v = -1 if v == 0 else v
    return v
def draw_top(c, t):
    i = TM.scene(t)
    sh = cairo.LinearGradient(0, 0, 0, 640); sh.add_color_stop_rgba(0, *NIGHT[:3], 0.9); sh.add_color_stop_rgba(1, *NIGHT[:3], 0)
    c.rectangle(0, 0, W, 640); c.set_source(sh); c.fill()
    if i == 0 or t >= END - 1.3:
        a = 1.0 if i == 0 else ramp(t, END - 1.3, END - 0.9)
        text(c, "3,000 years.", 176, 540, 430, 900, GOLD, a)
        text(c, "Watch the money move.", fit("Watch the money move.", 104, 980, 900), 540, 550, 900, WHITE, a)
        u = eout(t / 1.2) if i == 0 else 1.0
        w_ = font(176, 900).getlength("3,000 years.")
        c.set_source_rgba(*GOLD[:3], 0.9 * a); rr(c, 540 - w_ / 2, 462, w_ * u, 10, 5); c.fill()
        if i == 0: return
    if i == 15:
        b = ramp(t, CUT[15], CUT[15] + 0.3) * (1 - ramp(t, END - 1.3, END - 0.9))
        text(c, "It's been moving", 100, 540, 420, 900, WHITE, b)
        text(c, "for...", 100, 540, 540, 900, WHITE, b)
        return
    a = ramp(t, CUT[1], CUT[1] + 0.3)
    y = year_now(t)
    if y is not None: text(c, yfmt(y), 176, 540, 440, 900, GOLD, a)
    text(c, L[i][3], 64, 540, 535, 800, WHITE, ramp(t, CUT[i] + 0.1, CUT[i] + 0.4))

def draw_card(c, t):
    i = TM.scene(t); cd = CARD.get(i)
    if not cd: return
    big, fact, src = cd
    a = ramp(t, CUT[i] + 0.35, CUT[i] + 0.7) * (1 - ramp(t, CUT[i + 1] - 0.2, CUT[i + 1] + 0.05))
    if a <= 0.01: return
    lines = wrap(fact, 66, 900, 800)
    hgt = (150 if big else 0) + 78 * len(lines) + 92
    y0 = 1548 - hgt
    rr(c, 56, y0, 968, hgt, 34); c.set_source_rgba(*NIGHT[:3], 0.88 * a); c.fill()
    rr(c, 56, y0, 968, hgt, 34); c.set_source_rgba(*SKY[:3], 0.35 * a); c.set_line_width(2); c.stroke()
    y = y0 + 22
    if big:
        lab, val, suf = big; t0 = CUT[i] + 0.9; v = val * eout((t - t0) / 1.3) if t > t0 else 0
        text(c, f"{v:.0f}{suf}", 150, 540, y + 128, 900, GOLD, a); y += 150
    for n, ln in enumerate(lines):
        text(c, ln, 66, 540, y + 66 + 78 * n, 800, WHITE, a)
    text(c, src, fit(src, 38, 920, 700), 540, y0 + hgt - 30, 700, MUTE, a)

def draw_photo(c, t):
    i = TM.scene(t)
    if i not in PHS or PHS[i] is None: return
    a = ramp(t, CUT[i] + 0.5, CUT[i] + 0.9) * (1 - ramp(t, CUT[i + 1] - 0.3, CUT[i + 1]))
    if a <= 0.01: return
    s = PHS[i]; x0 = 540 - PH_W / 2
    z = 1.0 + 0.06 * clamp((t - CUT[i]) / max(1, CUT[i + 1] - CUT[i]))
    c.save(); rr(c, x0, PH_Y, PH_W, PH_H, 30); c.clip()
    c.translate(540, PH_Y + PH_H / 2); c.scale(z, z); c.translate(-s.get_width() / 2, -s.get_height() / 2)
    c.set_source_surface(s, 0, 0); c.paint_with_alpha(a); c.restore()
    rr(c, x0, PH_Y, PH_W, PH_H, 30); c.set_source_rgba(1, 1, 1, 0.5 * a); c.set_line_width(2); c.stroke()
    cr = PHOTO[i][1]
    text(c, cr, fit(cr, 36, 860, 700, 36), 540, PH_Y + PH_H + 44, 700, INK, a)

REPL = [("seventeen fifty BC", "1750 BC"), ("six hundred BC", "600 BC"), ("forty percent", "40%"),
        ("Forty-four nations", "44 nations"), ("fifty-seven percent", "57%"), ("Three thousand years", "3,000 years")]
SUBS = build_subs(TM, REPL)
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    draw_map(c, t); draw_photo(c, t)
    draw_top(c, t); draw_card(c, t)
    draw_subs(c, t, SUBS)
    return to_np(s)

if __name__ == "__main__":
    run(D, TM, frame, ARGS)

def SFX():
    ev = [(CUT[hi] + 0.05, "whoosh", -4) for hi, _, _ in HOPS]
    ev += [(CUT[hi] + HOP, "pop", -4) for hi, _, _ in HOPS]
    ev += [(CUT[10] + 2.2, "ding", -2), (CUT[13] + 2.2, "ding", -2), (CUT[1] + 0.3, "pop", -4)]
    return ev
