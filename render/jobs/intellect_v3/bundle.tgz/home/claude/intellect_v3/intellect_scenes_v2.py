"""Bespoke reelkit scenes for the @noamroz__ reel "intellect vs intelligence".
Loaded by reelkit through the spec field "scene_module". Each sc_<name>(c, t, S) is scene type <name>.
Times: S["t0"], S["t1"], and S["times"][mark] for every entry in the scene's "marks"."""
import math
import cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, shadow_box, diamond, draw_emoji
from kit import ease, ramp, lerp, St, sa, rr, line as kline, circ, box, hx, mix

def M(S, k, d=None): return S["times"].get(k, d if d is not None else S["t0"] + 0.3)
def xfade(t, a0, a1, d=0.22):
    if a1 is None: return ramp(t, a0, a0 + d)
    return ramp(t, a0, a0 + d) * (1 - ramp(t, a1, a1 + d))
def he_line(c, t, S, s, y, tk, sz=48, color=None, maxw=940):
    a, sc = PP(t, tk, S); return block(c, s, sz, 540, y, color or P["blue"], a, sc, w=700, maxw=maxw, max_lines=2)
def head(c, t, S, en, he, y=300, sz=78, tk=None):
    tk = S["t0"] + 0.05 if tk is None else tk
    a, sc = PP(t, tk, S); h = block_h(en, sz, 900, 940, 3)
    block(c, en, sz, 540, y + h / 2, P["navy"], a, sc * (1 + 0.012 * math.sin(t * 2.2)), hl=P["blue"], maxw=940, max_lines=3); y += h + 16
    if he:
        hh = block_h(he, 46, 700, 940, 2); he_line(c, t, S, he, y + hh / 2, tk + 0.2, sz=46); y += hh
    return y + 20
def phased_head(c, t, S, phases, y=290, sz=72):
    """header that cross-fades between (t_start, en, he) phases"""
    for k, (pa, en, he) in enumerate(phases):
        pb = phases[k + 1][0] if k + 1 < len(phases) else None
        al = (1.0 if k == 0 else ramp(t, pa + 0.12, pa + 0.32)) * ((1 - ramp(t, pb - 0.08, pb + 0.12)) if pb is not None else 1.0)
        if al <= 0.01: continue
        old = St.a; St.a *= al
        h = block_h(en, sz, 900, 940, 2); block(c, en, sz, 540, y + h / 2, P["navy"], 1, 1 + 0.012 * math.sin(t * 2.2), hl=P["blue"], maxw=940, max_lines=2)
        hh = block_h(he, 44, 700, 940, 2); block(c, he, 44, 540, y + h + 18 + hh / 2, P["blue"], 1, 1, w=700, maxw=940, max_lines=2)
        St.a = old
def wobble(u, t):   # jittery, uneven
    return (0.5 * math.sin(u * 0.11 + t * 14) + 0.35 * math.sin(u * 0.27 - t * 23) + 0.22 * math.sin(u * 0.61 + t * 37)) * (0.65 + 0.35 * math.sin(u * 0.021 + t * 3.1))
def ecg(p):         # one calm beat, p in 0..1
    if 0.18 < p < 0.28: return -0.18 * math.sin((p - 0.18) / 0.1 * math.pi)
    if 0.40 < p < 0.44: return 0.18 * (p - 0.40) / 0.04
    if 0.44 <= p < 0.49: return lerp(0.18, -1.0, (p - 0.44) / 0.05)
    if 0.49 <= p < 0.54: return lerp(-1.0, 0.3, (p - 0.49) / 0.05)
    if 0.54 <= p < 0.58: return lerp(0.3, 0.0, (p - 0.54) / 0.04)
    if 0.68 < p < 0.84: return -0.26 * math.sin((p - 0.68) / 0.16 * math.pi)
    return 0.0
def pulse(c, x0, x1, y, t, mode, colr, a=1.0, amp=60, lw=7):
    pts = []
    for x in range(int(x0), int(x1) + 1, 3):
        u = x - x0
        v = amp * wobble(u, t) if mode == "jitter" else amp * ecg(((u + t * 150) % 260) / 260)
        pts.append((x, y + v))
    if a <= 0.01: return
    kline(c, pts, colr, lw, a); circ(c, pts[-1][0], pts[-1][1], lw * 1.3, colr, a)
def heart_path(c, x, y, s):
    c.new_sub_path(); c.move_to(x, y + 0.42 * s)
    c.curve_to(x - 1.05 * s, y - 0.2 * s, x - 0.55 * s, y - 0.95 * s, x, y - 0.42 * s)
    c.curve_to(x + 0.55 * s, y - 0.95 * s, x + 1.05 * s, y - 0.2 * s, x, y + 0.42 * s); c.close_path()
def heart(c, x, y, s, colr, a=1.0):
    heart_path(c, x, y, s); sa(c, colr, a); c.fill()
def bubble(c, x, y, w, h, a=1.0, sc=1.0, fill=None, stroke=None, tail=(-0.25, 1), r=None):
    """speech bubble centred at x, y; tail = (fraction of w from centre, 1 for down)"""
    if a <= 0.01 or sc <= 0.01: return
    fill = fill or P["card"]; stroke = stroke or P["navy"]; r = r or min(h / 2, 36)
    c.save(); c.translate(x, y); c.scale(sc, sc)
    sa(c, P["navy"], 0.10 * a); rr(c, -w / 2 + 3, -h / 2 + 10, w, h, r); c.fill()
    tx = tail[0] * w; c.new_sub_path(); c.move_to(tx - 22, h / 2 - 4); c.line_to(tx - 34, h / 2 + 40); c.line_to(tx + 18, h / 2 - 4); c.close_path()
    sa(c, fill, a); c.fill_preserve(); sa(c, stroke, a); c.set_line_width(5); c.stroke()
    box(c, -w / 2, -h / 2, w, h, r, fill, a, stroke=stroke, sw=5)
    box(c, tx - 26, h / 2 - 9, 50, 12, 4, fill, a)
    c.restore()
def person(c, x, y, s, body, a=1.0, mouth=0.0, calm=False, coat=False):
    """simple figure; (x, y) = shoulders centre; mouth 0..1 open"""
    if a <= 0.01: return
    c.save(); c.translate(x, y); c.scale(s, s)
    c.new_sub_path(); c.arc(0, 120, 100, math.pi, 2 * math.pi); c.line_to(100, 150); c.line_to(-100, 150); c.close_path()
    sa(c, P["white"] if coat else body, a); c.fill_preserve(); sa(c, body, a); c.set_line_width(6); c.stroke()
    if coat:
        kline(c, [(0, 22), (0, 150)], body, 5, a)
        c.new_sub_path(); c.arc(0, 52, 46, 0.15 * math.pi, 0.85 * math.pi); sa(c, P["grey"], a); c.set_line_width(5); c.stroke()
        circ(c, -40, 74, 9, P["grey"], a)
        box(c, 36, 58, 34, 34, 6, P["white"], a, stroke=P["red"], sw=3); box(c, 48, 62, 10, 26, 2, P["red"], a); box(c, 40, 70, 26, 10, 2, P["red"], a)
    circ(c, 0, -20, 58, body, a)
    for ex in (-20, 20):
        if calm: kline(c, [(ex - 9, -28), (ex, -23), (ex + 9, -28)], P["white"], 5, a)
        else: circ(c, ex, -28, 7, P["white"], a)
    if calm: c.new_sub_path(); c.arc(0, -8, 18, 0.15 * math.pi, 0.85 * math.pi); sa(c, P["white"], a); c.set_line_width(5); c.stroke()
    else: box(c, -14, -2 - 8 * mouth, 28, 6 + 18 * mouth, 7, P["white"], a)
    c.restore()
def check(c, x, y, s, colr, a=1.0, u=1.0, lw=None):
    pts = [(x - 0.5 * s, y), (x - 0.15 * s, y + 0.35 * s), (x + 0.55 * s, y - 0.4 * s)]
    if u <= 0 or a <= 0.01: return
    if u < 0.4: pts = [pts[0], (lerp(pts[0][0], pts[1][0], u / 0.4), lerp(pts[0][1], pts[1][1], u / 0.4))]
    elif u < 1: v = (u - 0.4) / 0.6; pts = [pts[0], pts[1], (lerp(pts[1][0], pts[2][0], v), lerp(pts[1][1], pts[2][1], v))]
    kline(c, pts, colr, lw or s * 0.18, a)
def check_badge(c, x, y, r, a=1.0, u=1.0, sc=1.0):
    if a <= 0.01 or sc <= 0.01: return
    c.save(); c.translate(x, y); c.scale(sc, sc); circ(c, 0, 0, r, P["green"], a, stroke=P["white"], sw=5); check(c, 0, 3, r * 1.05, P["white"], a, u); c.restore()
def cross(c, x, y, s, colr, a=1.0, u=1.0):
    if a <= 0.01 or u <= 0: return
    u1 = min(1, u * 2); u2 = max(0, u * 2 - 1)
    kline(c, [(x - s, y - s), (x - s + 2 * s * u1, y - s + 2 * s * u1)], colr, s * 0.32, a)
    if u2 > 0: kline(c, [(x + s, y - s), (x + s - 2 * s * u2, y - s + 2 * s * u2)], colr, s * 0.32, a)
def wrench(c, x, y, s, colr, a=1.0, rot=0.0):
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s)
    kline(c, [(-46, 46), (22, -22)], colr, 26, a)
    circ(c, 34, -34, 34, colr, a)
    c.save(); c.translate(34, -34); c.rotate(-math.pi / 4); sa(c, P["card"], a); c.rectangle(-12, -40, 24, 36); c.fill(); c.restore()
    circ(c, -46, 46, 6, P["card"], a)
    c.restore()
def chat_icon(c, x, y, s, colr, a=1.0, t=0.0):
    c.save(); c.translate(x, y); c.scale(s, s)
    box(c, -70, -50, 140, 92, 30, colr, a)
    sa(c, colr, a); c.move_to(-36, 36); c.line_to(-52, 70); c.line_to(-8, 38); c.close_path(); c.fill()
    for k in range(3): circ(c, -34 + k * 34, -4 - 6 * max(0, math.sin(t * 7 - k)), 10, P["white"], a)
    c.restore()
def book(c, x, y, s, a=1.0, lines=True):
    c.save(); c.translate(x, y); c.scale(s, s)
    for sg in (-1, 1):
        c.new_sub_path(); c.move_to(0, -50); c.curve_to(sg * 40, -64, sg * 80, -62, sg * 100, -54); c.line_to(sg * 100, 60)
        c.curve_to(sg * 80, 52, sg * 40, 54, 0, 66); c.close_path(); sa(c, P["card"], a); c.fill_preserve(); sa(c, P["navy"], a); c.set_line_width(6); c.stroke()
        if lines:
            for k in range(4): kline(c, [(sg * 20, -30 + k * 22), (sg * 82, -36 + k * 22)], P["silver"], 5, a)
    c.restore()
def brain_glow(c, x, y, r, a, t):
    g = cairo.RadialGradient(x, y, 0, x, y, r); g.add_color_stop_rgba(0, *P["gold2"][:3], 0.55 * a * St.a * (0.75 + 0.25 * math.sin(t * 3)))
    g.add_color_stop_rgba(1, *P["gold2"][:3], 0); c.set_source(g); c.arc(x, y, r, 0, 2 * math.pi); c.fill()
def runner(c, x, y, s, ph, colr=None, a=1.0):
    """stick runner (from principles_scenes.py); ph = stride phase"""
    colr = colr or P["navy"]; c.save(); c.translate(x, y); c.scale(s, s)
    lw = 11; hip = (0, 10); sh = (8, -48)
    circ(c, 16, -78, 17, colr, a); kline(c, [hip, sh], colr, lw, a)
    for k in range(2):
        q = math.sin(ph + k * math.pi)
        th = 0.75 * q; kn = (hip[0] + 40 * math.sin(th), hip[1] + 40 * math.cos(th))
        sh_a = th - 0.9 - 0.5 * max(0, -q); ft = (kn[0] + 38 * math.sin(sh_a), kn[1] + 38 * math.cos(sh_a))
        kline(c, [hip, kn, ft], colr, lw, a)
        ar = -0.8 * q; el = (sh[0] + 30 * math.sin(ar), sh[1] + 30 * math.cos(ar)); hd = (el[0] + 26 * math.sin(ar + 1.6), el[1] + 26 * math.cos(ar + 1.6) - 10)
        kline(c, [sh, el, hd], colr, lw * 0.9, a)
    c.restore()
def bowl(c, x, y, s, a=1.0):
    c.save(); c.translate(x, y); c.scale(s, s)
    for k, (dx, dy, r, cc) in enumerate(((-30, -14, 22, "green"), (4, -24, 24, "green"), (34, -12, 18, "red"), (-6, -6, 16, "amber"))):
        circ(c, dx, dy, r, P[cc], a)
    c.new_sub_path(); c.arc(0, -6, 70, 0, math.pi); c.close_path(); sa(c, P["blue"], a); c.fill()
    box(c, -34, 60, 68, 10, 5, P["navy"], a)
    c.restore()

# ================================================================== 1. hook
FEEL = ["anxious", "overwhelmed", "frustrated", "hurt", "stressed", "tense", "worried", "restless", "angry", "lonely", "insecure", "triggered"]
def sc_hook(c, t, S):
    y = head(c, t, S, S["en"], S["he"], y=270, sz=80)
    bx, by, bw, bh = 540, 960, 820, 330
    # overflow: extra words keep rising out of the top of the bubble (drawn first, so they emerge from behind it)
    for k in range(7):
        per = 2.1; ph = ((t + k * per / 7) % per) / per; w_ = FEEL[(9 + k) % len(FEEL)] if k < 3 else FEEL[k]
        x = bx - 330 + k * 110 + 30 * math.sin(ph * 3 + k); yy = by - bh / 2 + 30 - 150 * ease(ph)
        al = min(1, ph * 5) * (1 - ramp(ph, 0.6, 1.0))
        c.save(); c.translate(x, yy); c.rotate((0.25 if k % 2 else -0.25) * ph)
        T(c, w_, 32, 0, 0, P["grey"] if k % 2 else P["red"], al * 0.85, 1, 800, maxw=240); c.restore()
    bubble(c, bx, by, bw, bh, 1.0, 1.0 + 0.01 * math.sin(t * 5), tail=(-0.3, 1))
    # words packed inside, nudging
    grid = [(-270, -95), (-20, -100), (250, -92), (-300, -10), (-40, -6), (230, -2), (-250, 80), (20, 84), (270, 78)]
    cols = [P["navy"], P["blue"], P["red"], P["gold_text"]]
    for k, (dx, dy) in enumerate(grid):
        w_ = FEEL[k]; jx = 5 * math.sin(t * 6 + k * 1.7); jy = 4 * math.cos(t * 7 + k)
        T(c, w_, 40 if k % 3 else 46, bx + dx + jx, by + dy + jy, cols[k % 4], 1, 1, 900, maxw=250)
    # jittery pulse + racing heart
    py = 1340; beat = 1 + 0.12 * abs(math.sin(t * 9.5))
    shadow_box(c, 90, py - 120, 900, 240, 30, P["card"], stroke=P["red"], sw=4)
    pulse(c, 250, 950, py, t, "jitter", P["red"], 1.0, amp=70)
    c.save(); c.translate(170, py); c.scale(beat, beat); heart(c, 0, 0, 62, P["red"]); c.restore()

# ================================================================== 2. two people (lines 2 to 4)
A_BUB = ["I feel *anxious* because...", "It's my *attachment style.*", "Classic *cortisol* spike."]
def sc_people(c, t, S):
    tm = S["times"]; t0 = S["t0"]
    phased_head(c, t, S, [(t0, "They can explain *every emotion.*", "יש אנשים שמסבירים כל רגש בצורה מושלמת. ולא מצליחים לווסת אף אחד."),
                          (tm["b"] - 0.1, "Others calm down *in seconds.*", "אחרים נרגעים תוך שניות. ואין להם מילים למה שהם מרגישים."),
                          (tm["lab"] - 0.1, "*Intellect* vs *intelligence*", "הראשון הוא אינטלקט. השני הוא אינטליגנציה.")])
    xa, xb = 290, 790; py = 1100
    # person A
    a, sc = PP(t, t0 + 0.1, S)
    if a > 0.01:
        talk = 0.5 + 0.5 * math.sin(t * 17)
        person(c, xa, py, 0.95 * sc, P["navy"], a, mouth=talk)
        for k, s_ in enumerate(A_BUB):
            tk = t0 + 0.3 + 0.55 * k; ab, sb = PP(t, tk, S)
            yy = 690 + k * 95; xx = xa + (-25 if k % 2 else 25)
            bubble(c, xx, yy, 470, 82, ab * a, sb * (1 + 0.015 * math.sin(t * 4 + k)), tail=(0.0 if k < 2 else -0.1, 1), r=30)
            T(c, s_, 30, xx, yy + 2, P["navy"], ab * a, sb, 800, hl=P["blue"], maxw=430)
        shadow_box(c, 70, 1300, 440, 170, 26, P["card"], a=a, stroke=P["red"], sw=4)
        pulse(c, 160, 480, 1385, t, "jitter", P["red"], a, amp=48, lw=6)
        heart(c, 115, 1385, 34 * (1 + 0.12 * abs(math.sin(t * 9.5))), P["red"], a)
    # person B
    a, sc = PP(t, tm["b"], S)
    if a > 0.01:
        br = 1 + 0.02 * math.sin(t * 1.6)
        person(c, xb, py + 4 * math.sin(t * 1.6), 0.95 * sc * br, P["blue"], a, calm=True)
        bubble(c, xb + 60, 880, 170, 90, a, sc, tail=(-0.2, 1), r=34)
        T(c, "...?", 46, xb + 60, 878, P["grey"], a, sc, 900)
        shadow_box(c, 570, 1300, 440, 170, 26, P["card"], a=a, stroke=P["green"], sw=4)
        pulse(c, 660, 980, 1395, t, "steady", P["green"], a, amp=60, lw=6)
        heart(c, 615, 1385, 34 * (1 + 0.06 * max(0, math.sin(t * 4.2)) ** 8), P["green"], a)
    # labels
    for key, x, txt, cc in (("la", xa, "INTELLECT", "navy"), ("lb", xb, "INTELLIGENCE", "gold")):
        a, sc = PP(t, tm[key], S, bounce=2.4)
        pill(c, txt, 44 if key == "la" else 40, x, 590, P[cc], P["white"], a, sc, outline=P["gold2"] if key == "la" else P["navy"])

# ================================================================== 3. etymology card (line 5)
def two_tone(c, parts, sz, x, y, a, sc):
    f = RD.font(sz, 900); ws = [f.getlength(p) for p, _ in parts]; tot = sum(ws) + 6 * (len(parts) - 1); xx = x - tot / 2 * sc
    for (p, cc), w_ in zip(parts, ws):
        T(c, p, int(sz), xx + w_ * sc / 2, y, cc, a, sc, 900, maxw=600); xx += (w_ + 6) * sc
def sc_etym(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "Same *Latin* root", "עובדה מעניינת: שתי המילים באות מאותה מילה בלטינית.", y=290, sz=82)
    cy = 820; a, sc = PP(t, S["t0"] + 0.15, S)
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(540, cy); c.scale(sc, sc)
        shadow_box(c, -470, -190, 940, 380, 34, P["card"], stroke=P["navy"], sw=5)
        for px, py in ((-452, -172), (452, -172), (-452, 172), (452, 172)): diamond(c, px, py, 16, P["gold"])
        c.restore(); St.a = old
    for k, (lat, en, he, key, x, cc) in enumerate((("inter", "between", "בין", "inter", 290, "navy"), ("legere", "to read, to choose", "לקרוא, לבחור", "legere", 770, "blue"))):
        a, sc = PP(t, tm[key], S, bounce=1.8)
        T(c, lat, 92, x, cy - 70, P[cc], a, sc, 900, maxw=400)
        T(c, f"({en})", 40, x, cy + 30, P["grey"], a, sc, 700, maxw=420)
        T(c, he, 42, x, cy + 110, P["gold_text"], a, sc, 700, maxw=420)
    a, sc = PP(t, tm["legere"] - 0.15, S); T(c, "+", 90, 530, cy - 66, P["gold"], a, sc, 900)
    # both words grow out of it
    u = ramp(t, tm["both"], tm["both"] + 0.6)
    for k, (parts, x, cc, he) in enumerate((([("INTEL", P["navy"]), ("LECT", P["blue"])], 290, "navy", "אינטלקט"),
                                            ([("INTEL", P["navy"]), ("LIGENCE", P["blue"])], 790, "gold", "אינטליגנציה"))):
        if u <= 0.01: continue
        kline(c, [(540, cy + 195), (540, cy + 235), (x, cy + 235), (x, cy + 235 + 60 * u)], P["gold"], 7, u)
        a, sc = PP(t, tm["both"] + 0.35 + 0.15 * k, S)
        if a > 0.01:
            shadow_box(c, x - 230, 1150, 460, 200, 28, P["card"], a=a, stroke=P[cc], sw=5)
            two_tone(c, parts, 58 if k == 0 else 52, x, 1220, a, sc)
            T(c, he, 40, x, 1300, P["gold_text"], a, sc, 700, maxw=420)
    a, sc = PP(t, tm["choose"] + 0.3, S)
    pill(c, "to read *between* the lines", 40, 540, 1450, P["navy"], P["white"], a, sc, outline=P["gold"], w=800)
    if a > 0.01: T(c, "לקרוא בין השורות", 34, 540, 1530, P["blue"], a, sc, 700)

# ================================================================== 4. two columns (lines 6 to 7)
def sc_columns(c, t, S):
    tm = S["times"]
    y = head(c, t, S, "So here's how *I* use them", "אז ככה אני משתמש בהן.", y=290, sz=74)
    a, sc = PP(t, S["t0"] + 0.1, S)
    if a > 0.01:
        shadow_box(c, 60, 600, 470, 880, 32, P["card"], a=a, stroke=P["navy"], sw=5)
        pill(c, "INTELLECT", 42, 295, 660, P["navy"], P["white"], a, sc)
        chat_icon(c, 295, 820, 1.05 * sc, P["navy"], a, t)
    for k, (en, he, key) in enumerate((("Talking about it", "לדבר על זה", "talk"), ("Analysing it", "לנתח את זה", "anal"), ("Explaining it", "להסביר את זה", "expl"))):
        aa, ss = PP(t, tm[key], S); yy = 1010 + k * 150
        if aa <= 0.01: continue
        box(c, 90, yy - 58, 410, 124, 22, hx("#EEF2F8"), aa)
        T(c, en, 40, 295, yy - 14, P["navy"], aa, ss, 800, maxw=380); T(c, he, 34, 295, yy + 36, P["gold_text"], aa, ss, 700, maxw=380)
    a, sc = PP(t, tm["solve"] - 0.2, S)
    if a > 0.01:
        shadow_box(c, 550, 600, 470, 880, 32, P["card"], a=a, stroke=P["gold"], sw=6)
        pill(c, "INTELLIGENCE", 40, 785, 660, P["gold"], P["white"], a, sc)
        u = ramp(t, tm["solve"], tm["solve"] + 0.5)
        wrench(c, 750, 830, 1.15 * sc, P["navy"], a, rot=-0.5 + 0.5 * ease(u) + 0.06 * math.sin(t * 5) * u)
        check_badge(c, 860, 900, 46, a, ramp(t, tm["solve"] + 0.35, tm["solve"] + 0.75), sc)
        aa, ss = PP(t, tm["solve"] + 0.1, S, bounce=2.2)
        box(c, 580, 1092, 410, 196, 22, hx("#FBF4E4"), aa)
        T(c, "Solving it", 60, 785, 1160, P["gold_text"], aa, ss, 900, maxw=380); T(c, "לפתור את זה", 44, 785, 1234, P["navy"], aa, ss, 700, maxw=380)

# ================================================================== 5. money (line 8)
MONEY_WORDS = ["crypto?", "inflation", "index funds", "interest rates", "savings"]
def sc_money(c, t, S):
    tm = S["times"]; tf = tm["fix"]
    y = head(c, t, S, "Talk about *money* all day. Or *fix the budget.*", "אפשר לדבר על כסף כל היום. או לתקן את התקציב.", y=290, sz=70)
    # left: talking
    a, sc = PP(t, S["t0"] + 0.15, S)
    if a > 0.01:
        dim = 1 - 0.35 * ramp(t, tf, tf + 0.4)
        person(c, 260, 1180, 0.85 * sc, P["navy"], a * dim, mouth=0.5 + 0.5 * math.sin(t * 17))
        k = int((t - S["t0"]) / 0.7) % len(MONEY_WORDS); ph = ((t - S["t0"]) / 0.7) % 1
        bubble(c, 260, 860, 400, 200, a * dim, sc, tail=(-0.05, 1))
        T(c, "₪", 70, 260, 820, P["gold_text"], a * dim, sc * (1 + 0.06 * math.sin(t * 8)), 900)
        T(c, MONEY_WORDS[k], 40, 260, 900, P["navy"], a * dim * min(1, ph * 6, (1 - ph) * 6), sc, 800, maxw=360)
        T(c, "talking", 40, 260, 1400, P["grey"], a, sc, 800)
    a, sc = PP(t, tf - 0.4, S); T(c, "vs", 50, 540, 1020, P["gold_text"], a, sc, 900)
    # right: budget sheet getting fixed
    a, sc = PP(t, tf - 0.3, S)
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(800, 1030); c.scale(sc, sc)
        shadow_box(c, -210, -300, 420, 560, 28, P["card"], stroke=P["gold"], sw=5)
        T(c, "BUDGET", 40, 0, -248, P["navy"], 1, 1, 900); T(c, "תקציב", 32, 0, -200, P["gold_text"], 1, 1, 700)
        u = ramp(t, tf + 0.2, tf + 1.2); lim = 120
        for k, (lab, v0, v1) in enumerate((("Rent", 0.8, 0.8), ("Food", 1.35, 0.85), ("Fun", 1.5, 0.7), ("Save", 0.1, 0.9))):
            yy = -120 + k * 92; v = lerp(v0, v1, ease(u)); over = v > 1.0
            T(c, lab, 30, -150, yy, P["navy"], 1, 1, 800, anchor="l", maxw=110)
            box(c, -30, yy - 16, 200, 32, 16, hx("#E9EDF3"))
            box(c, -30, yy - 16, min(220, 200 * v / 1.5 * 1.0 + 0.1), 32, 16, P["red"] if over else P["green"])
        kline(c, [(-30 + 200 / 1.5, -150), (-30 + 200 / 1.5, 175)], P["navy"], 3, 0.6)
        St.a = old; c.restore()
        check_badge(c, 960, 1240, 46, a, ramp(t, tf + 1.1, tf + 1.5), PP(t, tf + 1.0, S)[1])
        T(c, "fixing", 40, 800, 1400, P["gold_text"], a, sc, 800)

# ================================================================== 6. health (line 9)
def sc_health(c, t, S):
    tm = S["times"]; tn, td = tm["not"], tm["do"]
    phased_head(c, t, S, [(S["t0"], "Memorised the *menu* and the *workout plan.*", "שיננתם בעל פה את התפריט ואת תוכנית האימונים."),
                          (tn - 0.1, "That doesn't make you *healthy.*", "זה לא עושה אתכם בריאים."),
                          (td - 0.1, "*Doing it* does.", "לעשות את זה, כן.")], sz=70)
    a, sc = PP(t, S["t0"] + 0.15, S)
    if a > 0.01:
        brain_glow(c, 290, 950, 230, a, t)
        book(c, 290, 950, 1.55 * sc, a)
        for k, (txt, he) in enumerate((("MENU", "תפריט"), ("WORKOUT", "אימונים"))):
            aa, ss = PP(t, S["t0"] + 0.4 + 0.3 * k, S)
            pill(c, txt, 34, 290, 1150 + k * 92, P["navy"] if k == 0 else P["blue"], P["white"], aa, ss, w=800)
        T(c, "memorised", 38, 290, 1370, P["grey"], a, sc, 800)
        T(c, "בעל פה", 34, 290, 1425, P["gold_text"], a, sc, 700)
        cross(c, 420, 790, 40, P["red"], 1.0 if t > tn + 0.5 else a, ramp(t, tn + 0.1, tn + 0.5))
    a, sc = PP(t, td - 0.1, S)
    if a > 0.01:
        shadow_box(c, 560, 640, 440, 820, 32, P["card"], a=a, stroke=P["green"], sw=5)
        kline(c, [(600, 960), (960, 960)], P["navy"], 5, a)
        for g in range(8):
            gx = 610 + g * 46 - (t * 140) % 46; kline(c, [(gx, 960), (gx - 6, 946)], P["green"], 4, a)
        runner(c, 780, 890 - 5 * abs(math.sin(t * 9)), 1.15 * sc, t * 9, P["navy"], a)
        bowl(c, 690, 1120, 0.95 * sc, a)
        heart(c, 880, 1110, 52 * (1 + 0.06 * max(0, math.sin(t * 4.2)) ** 8), P["red"], a)
        check_badge(c, 930, 1150, 30, a, ramp(t, td + 0.4, td + 0.8), sc)
        T(c, "Health check", 42, 780, 1260, P["navy"], a, sc, 900, maxw=400)
        T(c, "בדיקת בריאות: עובר", 34, 780, 1320, P["gold_text"], a, sc, 700, maxw=400)
        pulse(c, 610, 950, 1400, t, "steady", P["green"], a, amp=40, lw=5)

# ================================================================== 7. Venn (lines 10 to 13)
VX = (390, 690); VY = 1000; VR = 250
TAGS = [("💰", "money", "כסף", 175, 700), ("🍏", "health", "בריאות", 905, 700), ("❤️", "relationships", "זוגיות", 205, 1310), ("💼", "work", "עבודה", 905, 1310)]
def sc_venn(c, t, S):
    tm = S["times"]; t0 = S["t0"]
    phased_head(c, t, S, [(t0, "Sometimes they *come together.*", "לפעמים הם באים ביחד: שני עיגולים, והחפיפה."),
                          (tm["l11"] - 0.1, "Stronger in *different parts* of life", "רובנו חזקים יותר באחד מהם, בתחומים שונים בחיים."),
                          (tm["l12"] - 0.1, "Teaching it? More *intellect.*", "מלמדים את זה, כמרצים או כמאמנים? צריך יותר אינטלקט."),
                          (tm["l13"] - 0.1, "Your own problem? *Solve it.*", "בעיה שלכם לפתור? צריך את הפתרון. צריך לעשות את זה.")], sz=70)
    u = ramp(t, tm["two"] - 0.6, tm["two"] + 0.2)
    xl = lerp(285, VX[0], u); xr = lerp(795, VX[1], u); r = lerp(215, VR, u)
    pa = ramp(t, tm["l12"], tm["l12"] + 0.3) * (1 - ramp(t, tm["l13"], tm["l13"] + 0.3)); pb = ramp(t, tm["l13"], tm["l13"] + 0.3)
    a, sc = PP(t, t0 + 0.1, S)
    if a > 0.01:
        old = St.a; St.a *= a
        for x, cc, al, emph in ((xl, P["navy"], 0.14, pa), (xr, P["gold"], 0.20, pb)):
            circ(c, x, VY, r * sc, cc, al + 0.14 * emph)
            c.new_sub_path(); c.arc(x, VY, r * sc, 0, 2 * math.pi); sa(c, cc); c.set_line_width(6 + 4 * emph); c.stroke()
        g = ramp(t, tm["overlap"] - 0.1, tm["overlap"] + 0.4)
        if g > 0.01 and u > 0.5:
            c.save(); c.new_sub_path(); c.arc(xl, VY, r, 0, 2 * math.pi); c.clip()
            gl = 0.75 + 0.25 * math.sin(t * 4)
            rg = cairo.RadialGradient(540, VY, 0, 540, VY, 220); rg.add_color_stop_rgba(0, *P["gold2"][:3], 0.95 * g * gl * St.a); rg.add_color_stop_rgba(1, *P["gold"][:3], 0.35 * g * St.a)
            c.new_sub_path(); c.arc(xr, VY, r, 0, 2 * math.pi); c.set_source(rg); c.fill(); c.restore()
            for k in range(6):
                ang = t * 1.2 + k * math.pi / 3; diamond(c, 540 + 60 * math.cos(ang), VY + 150 * math.sin(ang), 12, P["white"], 0.8 * g)
            T(c, "BOTH", 40, 540, VY - 12, P["navy"], g, 1, 900); T(c, "שניהם", 32, 540, VY + 36, P["navy"], g, 1, 700)
        T(c, "INTELLECT", 40, (xl - r + (xr - r)) / 2 if u > 0.5 else xl, VY - 10, P["navy"], 1, sc, 900, maxw=270)
        T(c, "אינטלקט", 32, (xl - r + (xr - r)) / 2 if u > 0.5 else xl, VY + 40, P["navy"], 1, sc, 700, maxw=270)
        T(c, "INTELLIGENCE", 40, (xl + r + (xr + r)) / 2 if u > 0.5 else xr, VY - 10, P["gold_text"], 1, sc, 900, maxw=270)
        T(c, "אינטליגנציה", 32, (xl + r + (xr + r)) / 2 if u > 0.5 else xr, VY + 40, P["gold_text"], 1, sc, 700, maxw=270)
        St.a = old
    # life-area tags (line 11); the bottom two make room for the icons on lines 12 and 13
    for k, (em, en, he, x, yy) in enumerate(TAGS):
        at, st = PP(t, tm["l11"] + 0.3 + 0.35 * k, S, bounce=2.2)
        if k >= 2: at *= 1 - ramp(t, tm["l12"] - 0.1, tm["l12"] + 0.2)
        if at <= 0.01: continue
        fy = yy + 6 * math.sin(t * 2 + k)
        pw = pill(c, en, 34, x + 22, fy, P["white"], P["navy"], at, st, outline=P["blue"] if k % 2 == 0 else P["gold"], w=800)
        draw_emoji(c, em, x + 22 - (pw or 200) / 2 * st - 26, fy, 50, at, st)
        T(c, he, 30, x + 22, fy + 52, P["gold_text"], at, st, 700, maxw=260)
    # lecturer / coach on the intellect side (v2: the doctor is out, doctors have to solve problems) (line 12), you on the intelligence side (line 13)
    a, sc = PP(t, tm["coach"], S)
    if a > 0.01:
        person(c, 230, 1300, 0.62 * sc, P["navy"], a, mouth=0.4 + 0.4 * math.sin(t * 12))
        T(c, "Lecturer / coach", 34, 230, 1420, P["navy"], a, sc, 900, maxw=330)
        T(c, "מרצה / מאמן", 30, 230, 1470, P["gold_text"], a, sc, 700, maxw=330)
        kline(c, [(300, 1270), (xl - 60, VY + 150)], P["navy"], 5, a * 0.5)
    a, sc = PP(t, tm["l13"] + 0.1, S)
    if a > 0.01:
        person(c, 850, 1300, 0.62 * sc, P["blue"], a, calm=True)
        check_badge(c, 920, 1270, 30, a, ramp(t, tm["do"], tm["do"] + 0.4), sc)
        T(c, "Your own problem", 34, 850, 1420, P["navy"], a, sc, 900, maxw=330)
        T(c, "הבעיה שלכם", 30, 850, 1470, P["gold_text"], a, sc, 700, maxw=330)
        kline(c, [(780, 1270), (xr + 60, VY + 150)], P["gold"], 5, a * 0.6)

# ================================================================== 8. in my view (line 14)
def sc_view(c, t, S):
    tm = S["times"]
    he_line(c, t, S, "לדעת על משהו זה לא כמו להיות מסוגל לעשות אותו.", 410, S["t0"] + 0.2, sz=44)
    for k, (en, he, key, x, cc) in enumerate((("Knowing *about* it", "לדעת על זה", "know", 290, "navy"), ("Being able to *do* it", "להיות מסוגל לעשות", "able", 790, "gold"))):
        a, sc = PP(t, tm[key], S, bounce=1.8)
        if a <= 0.01: continue
        shadow_box(c, x - 230, 560, 460, 780, 32, P["card"], a=a, stroke=P[cc], sw=5)
        if k == 0:
            brain_glow(c, x, 830, 170, a, t); book(c, x, 830, 1.2 * sc, a)
        else:
            kline(c, [(x - 180, 900), (x + 180, 900)], P["navy"], 5, a)
            runner(c, x, 830 - 5 * abs(math.sin(t * 9)), 1.25 * sc, t * 9, P["navy"], a)
            check_badge(c, x + 140, 700, 36, a, ramp(t, tm[key] + 0.3, tm[key] + 0.7), sc)
        block(c, en, 46, x, 1080, P["navy"], a, sc, hl=P["blue"] if k == 0 else P["gold_text"], maxw=400, max_lines=2)
        T(c, he, 36, x, 1220, P["gold_text"] if k == 0 else P["blue"], a, sc, 700, maxw=400)
    a, sc = PP(t, tm["same"], S, bounce=2.4)
    if a > 0.01:
        circ(c, 540, 950, 62 * sc, P["red"], a, stroke=P["white"], sw=6); kline(c, [(540 - 30 * sc, 935), (540 + 30 * sc, 935)], P["white"], 9, a); kline(c, [(540 - 30 * sc, 965), (540 + 30 * sc, 965)], P["white"], 9, a); kline(c, [(540 + 16 * sc, 915), (540 - 16 * sc, 985)], P["white"], 8, a)
    a, sc = PP(t, tm["able"] + 0.5, S)
    pill(c, "not the same", 44, 540, 1440, P["navy"], P["white"], a, sc, outline=P["gold"], w=800)

# ================================================================== 9. part 2 teaser (line 15)
def sc_teaser(c, t, S):
    tm = S["times"]
    a, sc = PP(t, S["t0"] + 0.02, S, bounce=2.2); pill(c, "PART 2", 44, 540, 300, P["navy"], P["white"], a, sc, outline=P["gold"], w=900)
    a, sc = PP(t, tm["debt"] - 0.1, S, bounce=1.6)
    if a > 0.01:
        old = St.a; St.a *= a; c.save(); c.translate(540, 520); c.scale(sc, sc)
        shadow_box(c, -470, -140, 940, 280, 36, P["card"], stroke=P["gold"], sw=7)
        for px, py in ((-452, -122), (452, -122), (-452, 122), (452, 122)): diamond(c, px, py, 16, P["gold"])
        T(c, "Emotional *debt*", 96, 0, -26, P["navy"], 1, 1 + 0.012 * math.sin(t * 2.4), 900, hl=P["gold_text"], maxw=860)
        T(c, "חוב רגשי", 54, 0, 72, P["blue"], 1, 1, 700)
        c.restore(); St.a = old
    for k, (en, he, key) in enumerate((("What it is", "מה זה", "what"), ("How it builds up", "איך הוא מצטבר", "builds"), ("How to pay it back", "איך מחזירים אותו", "pay"))):
        aa, ss = PP(t, tm[key], S); yy = 820 + k * 200
        if aa <= 0.01: continue
        shadow_box(c, 110, yy - 75, 860, 150, 28, P["card"], a=aa, stroke=P["silver"], sw=3, sh=8)
        circ(c, 190, yy, 42, P["gold"], aa); T(c, str(k + 1), 46, 190, yy + 2, P["white"], aa, ss, 900)
        T(c, en, 50, 260, yy - 18, P["navy"], aa, ss, 900, anchor="l", maxw=680); T(c, he, 36, 260, yy + 36, P["gold_text"], aa, ss, 700, anchor="l", maxw=680)
    # a debt meter filling up, then paid back
    a = fade_in(t, tm["builds"], S)
    if a > 0.01:
        u = ramp(t, tm["builds"], tm["pay"]) * (1 - 0.8 * ramp(t, tm["pay"], tm["pay"] + 1.2))
        box(c, 140, 1420, 720, 34, 17, hx("#E3E7EE"), a); box(c, 140, 1420, max(34, 720 * u), 34, 17, mix(P["gold"], P["red"], u), a)
        T(c, "debt", 30, 885, 1437, P["grey"], a, 1, 800, anchor="l", maxw=100)
