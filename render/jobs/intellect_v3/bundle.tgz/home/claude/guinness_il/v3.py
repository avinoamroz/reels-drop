"""Guinness reel v3: "Want to be part of a Guinness World Record?" World records Israel has already broken, the Shabbat dinner we lost,
and the call to action: a 3,000-person Shabbat dinner on the beach in Tel Aviv.
Look and drawings from render.py (v1, imported). VO: Noam's Cartesia take, house chain (rubberband pitch 0.9715 formant
preserved, bass g2 f135, clean_vo, atempo 1.1, 0.3 s lead), timed with /home/claude/vo_v4/asr_segs.py on the processed vo.
Frames stream straight into ffmpeg (no PNG sequence).
usage: python3 v3.py VO.wav ASR.json [--preview [t1,t2,..]]"""
import sys, os, json, math, re, subprocess, random
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/guinness_il")
import numpy as np, cairo
from PIL import Image
import kit
from kit import (W, H, FPS, SR, ease, ramp, lerp, hx, pop, St, sa, rr, line, circ, box, tx, font, is_he, QA, CUR,
                 surf2pil, sheet_of, DASHES, subclean, subchunks, pil2cairo, SUB_BOTTOM, chip)
import render as R
from render import NAVY, BLUE, GOLD, GOLD2, SILV, WHITE, RED, GREEN, GREY, c255, N2, B2, G2, W2, R2, GY2, T, icon, CY0, CY1
import guinness_audio as GA

D = "/home/claude/guinness_il"; SCR = "/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/gw3"
HOLD = 3.0
kit.KEEP.add("SHABBAT")
NUMS = (("two hundred and eighty-nine", "289"), ("two thousand two hundred and twenty-six", "2,226"),
        ("two thousand seven hundred and sixty-one", "2,761"), ("Three thousand", "3,000"))
# chunks the -38 dB silencedetect left merged; split at the digital-silence gaps found inside them (energy < -40 dB)
# v3 narration: silencedetect gives one chunk per phrase, no hand splits needed
SPLITS = {}
SEG_FIX = {}

class Reel(kit.Reel):
    def __init__(s, vo_wav, asr_json):
        s.D = D; s.name = "guinness_v3"; s.nums = NUMS; s.tail = HOLD
        s.lines = [l.strip() for l in open(f"{D}/tts_v3.txt") if l.strip()]
        J = json.load(open(asr_json)); CH = []
        for a, b, txt in J["chunks"]:
            CH += [list(x) for x in SPLITS[round(a, 3)]] if round(a, 3) in SPLITS else [[a, b, txt]]
        s.CH = CH; s.SEG = [list(x) for x in J["segs"]]
        for i, (a, b) in SEG_FIX.items():
            if a is not None: s.SEG[i][0] = a
            if b is not None: s.SEG[i][1] = b
        assert len(s.SEG) == len(s.lines) == 9
        s.clean = [subclean(l, NUMS) for l in s.lines]
        s.asr_check = J["check"]
        s.vo = np.frombuffer(kit.run(["ffmpeg", "-v", "error", "-i", vo_wav, "-ac", "1", "-ar", str(SR), "-f", "f32le", "pipe:1"]), np.float32).astype(np.float64)
    def build_vo(s):
        s.lmap = []
        for i, (la, lb) in enumerate(s.SEG):
            ks = [k for k, cc in enumerate(s.CH) if cc[0] >= la - 0.02 and cc[1] <= lb + 0.02]; assert ks, i
            L = [max(1, len(s.CH[k][2])) for k in ks]; tot = sum(L); pts = []; acc = 0
            for k, l in zip(ks, L):
                pts.append((acc / tot, s.CH[k][0])); acc += l; pts.append((acc / tot, s.CH[k][1]))
            s.lmap.append(pts)
        s.lspan = [(p[0][1], p[-1][1]) for p in s.lmap]
        s.VO_END = s.lspan[-1][1]; s.T_END = round(s.VO_END + HOLD, 2)
        print("VO", round(len(s.vo) / SR, 2), "s; end", s.VO_END, "T_END", s.T_END)
    def subs(s, skip=(0,)):
        items = []
        for i, l in enumerate(s.clean):
            cs = subchunks(l) if i != 8 else ["Comment SHABBAT, share this reel,", "and we'll send you an invite.", "Let's break it together."]
            L = len(l); pos = 0
            for cc in cs:
                p0 = l.find(cc, pos); assert p0 >= 0, cc; p1 = p0 + len(cc); pos = p1
                if i not in skip: items.append([s.ft(i, p0 / L), s.ft(i, p1 / L), cc])
        for a, b in zip(items, items[1:]):
            if b[0] - a[1] < 0.45: a[1] = b[0]
        items[-1][1] = max(items[-1][1], items[-1][1] + 0.6)
        F = kit.ImageFont.truetype('/root/.fonts/Heebo-ExtraBold.ttf', 54); out = []
        for a, b, cc in items:
            assert not any(d in cc for d in DASHES)
            w = cc.split(); lines = []; cur = ''
            for x in w:
                tr_ = (cur + ' ' + x).strip()
                if F.getlength(tr_) <= 920: cur = tr_
                else: lines.append(cur); cur = x
            lines.append(cur); lh = 66; Wd = int(max(F.getlength(x) for x in lines)) + 56; Hd = lh * len(lines) + 28
            im = Image.new('RGBA', (Wd, Hd), (0, 0, 0, 0)); d = kit.ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, Wd - 1, Hd - 1], radius=22, fill=(22, 50, 96, 236))
            for k, x in enumerate(lines): d.text((Wd / 2, 14 + k * lh + lh / 2), x, font=F, fill=(255, 255, 255), anchor='mm')
            out.append((a, b, pil2cairo(im), (W - Wd) // 2, SUB_BOTTOM - Hd, cc))
        s.sub_items = out; return out

# ------------------------------------------------------------------ extra drawings
def eyes(c):   # the 👀 emoji, drawn
    for sx in (-1, 1):
        c.save(); c.translate(sx * 46, 0); c.scale(1, 1.35); circ(c, 0, 0, 40, WHITE, stroke=NAVY, sw=7); c.restore()
        circ(c, sx * 46 + 14, 16, 17, NAVY); circ(c, sx * 46 + 19, 10, 5, WHITE)
def hand_down(c):   # clean rounded down-chevron cue (Noam 1 Nov: no hand or finger shapes anywhere); name kept for old callers
    A = St.a
    if A <= 0.01: return
    c.save()
    c.set_source_rgba(0.086, 0.196, 0.376, 0.16 * A); c.arc(0, 10, 74, 0, 2 * math.pi); c.fill()
    c.set_source_rgba(0.271, 0.643, 0.867, A); c.arc(0, 0, 74, 0, 2 * math.pi); c.fill()
    c.set_source_rgba(1, 1, 1, A); c.set_line_width(17); c.set_line_cap(cairo.LINE_CAP_ROUND); c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.move_to(-31, -13); c.line_to(0, 18); c.line_to(31, -13); c.stroke()
    c.restore()
cue_down = hand_down
def envelope(c):
    box(c, -85, -58, 170, 116, 14, WHITE, stroke=NAVY, sw=8)
    line(c, [(-80, -52), (0, 12), (80, -52)], NAVY, 8)
def medal_s(c, n, col=None):
    R.medal(c, n)
def tracker(c, t, cur, t_in=None, y=320):
    """five medals left to right; cur = current (big, bobbing); t_in: staggered pop-in for the bridge card"""
    for k in range(1, 6):
        x = 540 + (k - 3) * 150
        a, s_ = (1.0, 1.0) if t_in is None else pop(t, t_in + 0.18 * (k - 1), bounce=2.6)
        if a <= 0.01: continue
        if t_in is not None:
            icon(c, x, y + 30, 0.78 * s_ * (1 + 0.04 * math.sin(t * 4 + k)), R.medal, k, a=a)
        elif k == cur: icon(c, x, y + 10, 0.62 + 0.03 * math.sin(t * 5), R.medal, k)
        elif k > cur: circ(c, x, y, 30, GOLD, 0.9, stroke=WHITE, sw=4); T(c, str(k), 40, x, y + 2, col=W2)
        else: circ(c, x, y, 30, WHITE, 0.7, stroke=SILV, sw=4); T(c, str(k), 40, x, y + 2, col=GY2)
def oneliner(c, t, items, sz=54, y0=1290):
    for k, (s, ts) in enumerate(items):
        a, sc = pop(t, ts); T(c, s, sz, 540, y0 + 62 * k, a=a, sc=sc)
def source(c, t, t0, lines, y0=1418):
    a = ramp(t, t0, t0 + 0.3)
    for k, s in enumerate(lines): T(c, s, 36, 540, y0 + 48 * k, col=GY2, a=a, w=700, src=True, maxw=940)
def count(t, t0, d, v0, v1): return lerp(v0, v1, ease((t - t0) / d)) if t >= t0 else v0
fmt = R.fmt

# ------------------------------------------------------------------ the beach (flat vector, Tel Aviv at sunset)
PX0, PY0, PX1, PY1 = 80, 392, 1000, 1030; HZ = 760
def shore_y(x): return HZ + 2 + (620 - x) / 540 * 140 if x < 620 else HZ + 2
TAB = [(lerp(175, 905, u), lerp(952, 840, u), lerp(1.0, 0.5, u)) for u in np.linspace(0, 1, 15)]   # candle points along the table
def beach(c, t, sc):
    a, s_ = pop(t, sc["t0"] + 0.05, d=0.55, s0=0.7, bounce=1.4)
    if a <= 0.01: return
    old = St.a; St.a *= a; c.save(); c.translate(540, 711); c.scale(s_, s_); c.translate(-540, -711)
    sa(c, NAVY, 0.18); rr(c, PX0 + 4, PY0 + 16, PX1 - PX0, PY1 - PY0, 34); c.fill()
    c.save(); rr(c, PX0, PY0, PX1 - PX0, PY1 - PY0, 34); c.clip()
    g = cairo.LinearGradient(0, PY0, 0, HZ)
    for st_, col in ((0, "#163260"), (0.38, "#4B3A7A"), (0.7, "#D9665B"), (0.9, "#F29A57"), (1, "#F7C873")): g.add_color_stop_rgb(st_, *hx(col)[:3])
    c.set_source(g); c.paint()
    R_ = random.Random(9)
    for k in range(18):   # first stars
        x = R_.uniform(PX0 + 20, PX1 - 20); y = R_.uniform(PY0 + 15, PY0 + 150); tw = 0.5 + 0.5 * math.sin(t * 2.2 + k)
        circ(c, x, y, R_.uniform(1.6, 3.2), WHITE, 0.35 + 0.45 * tw)
    sx, sy = 330, HZ + 4; rg = cairo.RadialGradient(sx, sy, 40, sx, sy, 330)
    rg.add_color_stop_rgba(0, 1, 0.86, 0.5, 0.55); rg.add_color_stop_rgba(1, 1, 0.7, 0.4, 0); c.set_source(rg); c.paint()
    circ(c, sx, sy, 88, hx("#FFD27A"))
    # Tel Aviv skyline (generic towers: round, triangular, square, plus mid-rise blocks)
    sky = hx("#3A2E5E")
    for (x, w_, h_) in ((640, 40, 40), (684, 30, 62), (720, 46, 48), (770, 28, 96), (804, 36, 70), (846, 50, 118), (900, 30, 80), (936, 44, 58), (982, 30, 44)):
        box(c, x, HZ - h_, w_, h_ + 6, 3, sky)
    c.move_to(846, HZ - 118); c.line_to(871, HZ - 150); c.line_to(896, HZ - 118); c.close_path(); sa(c, sky); c.fill()     # triangular top
    circ(c, 787, HZ - 100, 15, sky)
    for (x, y) in ((690, HZ - 40), (812, HZ - 50), (860, HZ - 90), (944, HZ - 36)):   # lit windows
        box(c, x, y, 6, 8, 1, hx("#FFD27A"), 0.7 + 0.3 * math.sin(t * 3 + x))
    box(c, 600, HZ - 4, 420, 10, 2, hx("#2E2450"))   # far coast strip
    # sea
    g = cairo.LinearGradient(0, HZ, 0, PY1); g.add_color_stop_rgb(0, *hx("#E0875F")[:3]); g.add_color_stop_rgb(0.35, *hx("#3E6FA8")[:3]); g.add_color_stop_rgb(1, *hx("#21497F")[:3])
    c.move_to(PX0, HZ); c.line_to(620, HZ); c.line_to(620, HZ + 2)
    for x in np.linspace(620, PX0, 20): c.line_to(x, shore_y(x))
    c.line_to(PX0, PY1); c.close_path(); c.set_source(g); c.fill()
    for k in range(9):   # sun glitter on the water
        y = HZ + 14 + k * 13; wv = 90 - k * 7 + 10 * math.sin(t * 2 + k)
        line(c, [(sx - wv / 2 + 8 * math.sin(t * 1.7 + k), y), (sx + wv / 2 + 8 * math.sin(t * 1.7 + k), y)], hx("#FFD27A"), 4, 0.55)
    # sand
    g = cairo.LinearGradient(0, HZ, 0, PY1); g.add_color_stop_rgb(0, *hx("#F3C98E")[:3]); g.add_color_stop_rgb(1, *hx("#E7B173")[:3])
    c.move_to(620, HZ + 2); c.line_to(PX1, HZ + 2); c.line_to(PX1, PY1); c.line_to(PX0, PY1)
    for x in np.linspace(PX0, 620, 20): c.line_to(x, shore_y(x) + 8 * math.sin(t * 1.2 + x * 0.02) * (620 - x) / 540)
    c.close_path(); c.set_source(g); c.fill()
    # foam line
    pts = [(x, shore_y(x) + 6 * math.sin(t * 1.2 + x * 0.02) * (620 - x) / 540) for x in np.linspace(PX0, 620, 24)]
    line(c, pts, WHITE, 5, 0.75)
    # the long table, receding from front left to back right
    A = [(x, y - 14 * s) for x, y, s in TAB]; B = [(x, y + 14 * s) for x, y, s in TAB]
    COLS = (NAVY, BLUE, GOLD, hx("#D9665B"), hx("#1E9E62"))
    for k, (x, y, s) in enumerate(TAB[::-1]):   # far-side diners (behind the table), back to front
        circ(c, x + 6 * s, y - 40 * s, 13 * s, COLS[k % 5]); box(c, x - 8 * s, y - 30 * s, 28 * s, 18 * s, 8 * s, COLS[(k + 2) % 5])
    c.move_to(*A[0])
    for p in A[1:]: c.line_to(*p)
    for p in B[::-1]: c.line_to(*p)
    c.close_path(); sa(c, WHITE); c.fill()
    c.move_to(*B[0])
    for p in B[1:]: c.line_to(*p)
    for x, y, s in TAB[::-1]: c.line_to(x, y + 22 * s)
    c.close_path(); sa(c, hx("#D9DDE3")); c.fill()
    lit0 = sc["lit"]
    for k, (x, y, s0_) in enumerate(TAB[::-1]):
        s = s0_ * 1.6
        j = len(TAB) - 1 - k; tl = lit0 + 0.09 * j                 # candles light front to back
        box(c, x - 3 * s, y - 26 * s, 6 * s, 22 * s, 2 * s, WHITE, stroke=SILV, sw=1.5)
        if t >= tl:
            u = ramp(t, tl, tl + 0.25); fl = 1 + 0.12 * math.sin(t * 17 + j * 1.3)
            rg = cairo.RadialGradient(x, y - 34 * s, 0, x, y - 34 * s, 40 * s * u)
            rg.add_color_stop_rgba(0, 1, 0.85, 0.45, 0.55 * u * St.a); rg.add_color_stop_rgba(1, 1, 0.8, 0.4, 0); c.set_source(rg)
            c.arc(x, y - 34 * s, 40 * s * max(u, 0.01), 0, 2 * math.pi); c.fill()
            c.save(); c.translate(x, y - 30 * s); c.scale(s * u, s * u * fl)
            c.move_to(0, 2); c.curve_to(-8, -4, -6, -14, 0, -20); c.curve_to(6, -14, 8, -4, 0, 2); sa(c, hx("#FFB23F")); c.fill()
            c.move_to(0, 1); c.curve_to(-4, -3, -3, -9, 0, -13); c.curve_to(3, -9, 4, -3, 0, 1); sa(c, hx("#FFF1B8")); c.fill(); c.restore()
        if k % 3 == 1: circ(c, x + 12 * s0_, y - 6 * s0_, 6 * s0_, hx("#C77A36"))   # challah / plates
    for k, (x, y, s) in enumerate(TAB[::-1]):   # near-side diners (backs to camera)
        if k % 1 == 0: circ(c, x - 10 * s, y + 34 * s, 14 * s, COLS[(k + 3) % 5]); box(c, x - 26 * s, y + 42 * s, 32 * s, 26 * s, 10 * s, COLS[(k + 1) % 5])
    c.restore()
    rr(c, PX0, PY0, PX1 - PX0, PY1 - PY0, 34); sa(c, NAVY); c.set_line_width(6); c.stroke()
    c.restore(); St.a = old
    # big gold counter in the sky
    t3 = sc["c3000"]; v = count(t, t3, 1.1, 0, 3000)
    if t >= t3 - 0.05:
        a2 = ramp(t, t3 - 0.05, t3 + 0.1); land = t3 + 1.1; pu = 1 + 0.12 * math.exp(-((t - land) / 0.12) ** 2) if t > land - 0.3 else 1
        tx(c, fmt(round(v / 10) * 10 if t < land else 3000), 200, 540, 560, col=(247, 205, 106, 255), a=a2 * a, sc=pu, shadow=True)
        if t > land:   # gold burst
            for k in range(16):
                ang = k / 16 * 2 * math.pi; d_ = 160 + 260 * ease((t - land) / 0.9); al = 1 - ramp(t, land + 0.3, land + 1.0)
                if al > 0.01:
                    c.save(); c.translate(540 + d_ * math.cos(ang), 560 + 0.6 * d_ * math.sin(ang)); c.rotate(ang + t * 3)
                    sa(c, GOLD2 if k % 2 else WHITE, al * a); c.rectangle(-7, -7, 14, 14); c.fill(); c.restore()

# ------------------------------------------------------------------ scenes
def build(r):
    S = []
    A = r.at
    def add(t0, fn, **kw): S.append(dict(t0=t0, fn=fn, **kw))
    st = lambda i: r.lspan[i][0] - 0.15

    def hook(c, t, sc):   # fully on screen at frame 0
        chip(c, "SHABBAT WORLD RECORD | PART 1", 40, 540, 262, GOLD, fg=N2, w=900)      # series chip, on screen at frame 0
        chip(c, "שיא העולם לארוחת שבת | חלק 1", 38, 540, 333, GOLD, fg=N2)
        icon(c, 540, 525 + 8 * math.sin(t * 2.5), 1.12, R.trophy)
        T(c, "Want to be part of a", 84, 540, 715)
        T(c, "*GUINNESS*", 132, 540, 840, hl=B2); T(c, "WORLD RECORD?", 120, 540, 965)
        T(c, "רוצים להיות חלק משיא גינס?", 64, 540, 1085, col=B2)
        a, s = pop(t, A(0, "watch till the end"))
        chip(c, "Watch till the end", 52, 540, 1230, NAVY, a=a, sc=s, w=800, icon_fn=eyes)
    add(0.0, hook)

    def bridge(c, t, sc):
        t0 = sc["t0"]; tracker(c, t, 0, t_in=t0 + 0.1, y=560)
        a, s = pop(t, t0 + 0.05); T(c, "World records", 96, 540, 800, a=a, sc=s)
        a, s = pop(t, A(1, "already")); T(c, "*Israel has already broken*", 76, 540, 915, a=a, sc=s)
        a, s = pop(t, A(1, "already") + 0.25); T(c, "שיאי עולם שישראל כבר שברה", 56, 540, 1030, a=a, sc=s, col=B2)
        a = ramp(t, t0 + 1.2, t0 + 1.5); T(c, "All real. Sources on screen.", 44, 540, 1180, a=a, w=800, col=GY2)
    add(st(1), bridge)

    def rec(c, t, sc):
        t0 = sc["t0"]
        if sc.get("lost"):
            a, s = pop(t, t0 + 0.05); chip(c, "AND THE ONE WE LOST", 50, 540, 320, RED, a=a, sc=s, w=900)
        else: tracker(c, t, sc["n"])
        a, s = pop(t, t0 + 0.25, d=0.5); icon(c, 540, 470, 0.95 * s, sc["ic"], *sc.get("args", lambda t: ())(t), a=a)
        if R.certificate(c, t, t0) < 0.5: return
        for k, ln in enumerate(sc["title"]):
            a, s = pop(t, t0 + 0.35 + 0.08 * k); T(c, ln, 62, 540, CY0 + 150 + 72 * k, a=a, sc=s)
        yh = CY0 + 150 + 72 * len(sc["title"]) + 2
        a, s = pop(t, t0 + 0.55); T(c, sc["he"], 52, 540, yh, a=a, sc=s, col=B2)
        sc["body"](c, t, sc, yh)

    def strawberry_body(c, t, sc, yh):
        tc = A(2, "289"); v = count(t, tc, 0.9, 0, 289)
        if t >= tc: T(c, f"{fmt(v)} g", 150, 540, yh + 135, col=B2)
        a = ramp(t, A(2, "kadima"), A(2, "kadima") + 0.3); T(c, "Kadima-Zoran, 12 Feb 2021", 44, 540, yh + 245, a=a, w=700, col=GY2)
        R.stamp(c, t, sc["stamp"], "STILL OURS", 540, yh + 335, GREEN)
        oneliner(c, t, [("Heavier than any iPhone.", A(2, "that's heavier")), ("Do not put it in your pocket.", A(2, "do not put"))])
        source(c, t, sc["t0"] + 1.0, ["Source: guinnessworldrecords.com (news, Feb 2022)"])
    def protein_body(c, t, sc, yh):
        tc = A(3, "protein"); v = count(t, tc, 1.1, 0, 128.6)
        if t >= tc: T(c, f"{fmt(v, 1)} g", 124, 540, yh + 100, col=B2)
        a = ramp(t, tc + 1.0, tc + 1.3); T(c, "per person, per day (GWR data: 2006)", 42, 540, yh + 192, a=a, w=700, col=GY2)
        R.stamp(c, t, sc["stamp"], "ISRAEL, No.1", 540, yh + 272, GREEN)
        oneliner(c, t, [("Hummus. Schnitzel. Cottage.", A(3, "hummus")), ("We weren't trying. We were hungry.", A(3, "we weren't"))])
        source(c, t, sc["t0"] + 1.0, ["Source: GWR, Highest protein consumption (country)"])
    def lowest_body(c, t, sc, yh):
        tc = A(4, "lowest town"); v = count(t, tc, 1.1, 0, 393.5)
        if t >= tc: T(c, f"{fmt(v, 1)} m", 140, 540, yh + 125, col=B2)
        a = ramp(t, A(4, "ein bokek"), A(4, "ein bokek") + 0.3); T(c, "below sea level. Ein Bokek, Dead Sea", 42, 540, yh + 232, a=a, w=700, col=GY2)
        R.stamp(c, t, sc["stamp"], "NOBODY CAN TAKE IT", 540, yh + 325, GREEN, sz=46)
        oneliner(c, t, [("Our lowest achievement.", A(4, "our lowest")), ("*Literally.*", A(4, "literally"))])
        source(c, t, sc["t0"] + 1.0, ["Source: GWR, Lowest town (also: Lowest road, 393 m)"])
    def hummus_body(c, t, sc, yh):
        rows = [("Abu Ghosh, Jan 2010", 4090, BLUE, A(5, "abu ghosh")), ("Lebanon, May 2010", 10452, GOLD, A(5, "lebanon makes"))]
        for k, (who, kg, col, ts) in enumerate(rows):
            if t < ts - 0.05: continue
            y = yh + 70 + 120 * k; u = ease((t - ts) / 1.1); full = 760 * kg / 10452; a = ramp(t, ts - 0.05, ts + 0.15)
            T(c, who, 44, 540, y, a=a, w=800, col=GY2)
            bw = max(30, full * u); box(c, 160, y + 32, bw, 46, 23, col, a)
            T(c, f"{fmt(kg * u)} kg", 48, min(800, 160 + bw + 115), y + 56, a=a, col=c255(col) if col is not BLUE else B2)
        a = ramp(t, A(5, "satellite"), A(5, "satellite") + 0.3); T(c, "(served in a satellite dish)", 38, 540, yh + 290, a=a, w=700, col=GY2)
        R.stamp(c, t, sc["stamp"], "STILL LEBANON'S", 540, yh + 375, GOLD, sz=48)
        a, s = pop(t, A(5, "lebanon, respect")); T(c, "Lebanon, respect. *Rematch?*", 60, 540, 1320, a=a, sc=s, hl=c255(GOLD))
        source(c, t, sc["t0"] + 1.0, ["Sources: GWR (Largest serving of hummus), Gulf News"])
    def shabbat_body(c, t, sc, yh):
        tc = A(6, "2,226"); v = count(t, tc, 1.0, 0, 2226); lost = sc["stamp"]; sh = ramp(t, lost + 0.3, lost + 0.7)
        if t >= tc: T(c, fmt(v), lerp(150, 96, sh), 540, yh + lerp(120, 85, sh), col=B2)
        a = ramp(t, A(6, "tel aviv had"), A(6, "tel aviv had") + 0.3) * (1 - sh)
        T(c, "diners, Tel Aviv port, 13 June 2014", 42, 540, yh + 230, a=a, w=700, col=GY2)
        for k, (who, n0, n1, ts, tn) in enumerate([("Berlin, 2015", 2322, 2322, A(6, "berlin") + 0.2, None),
                                                   ("New York, 2025", 2322, 2761, A(6, "new york"), A(6, "2,761"))]):
            a, s = pop(t, ts)
            if a > 0.01:
                y = yh + 175 + 72 * k; n = n1 if tn is None else round(count(t, tn, 0.8, n0, n1))
                T(c, who, 50, 330, y, a=a, sc=s, w=800, col=GY2); T(c, fmt(n), 58, 770, y, a=a, sc=s, col=R2)
        R.stamp(c, t, lost, "LOST IT", 540, yh + 330, RED, rot=-0.06, sz=54)
        source(c, t, sc["t0"] + 1.0, ["Sources: Tel Aviv 2,226 (2014, israel21c)", "Berlin 2,322 (2015, GWR)",
                                      "New York 2,761 (21 Nov 2025, JTA; GWR)"], y0=1300)

    add(st(2), rec, n=1, ic=R.strawberry, title=["Heaviest strawberry"], he="התות הכבד בעולם", body=strawberry_body,
        stamp=A(2, "kadima", end=True) + 0.15)
    add(st(3), rec, n=2, ic=R.protein, title=["Highest protein", "consumption (country)"], he="הכי הרבה חלבון לנפש בעולם", body=protein_body,
        stamp=A(3, "list", end=True) + 0.1)
    add(st(4), rec, n=3, ic=R.gauge, args=lambda t: (t,), title=["Lowest town on Earth"], he="העיר הנמוכה בעולם", body=lowest_body,
        stamp=A(4, "dead sea", end=True) + 0.1)
    add(st(5), rec, n=4, ic=R.bowl, args=lambda t: (GOLD,), title=["Largest serving of hummus"], he="מלחמת החומוס", body=hummus_body,
        stamp=A(5, "makes ten", end=True) + 0.05)
    add(st(6), rec, n=5, ic=R.table, lost=True, title=["Largest Shabbat dinner"], he="ארוחת השבת הגדולה בעולם", body=shabbat_body,
        stamp=A(6, "then berlin"))

    def back(c, t, sc):
        a, s = pop(t, sc["t0"] + 0.05); T(c, "So we're taking it *back.*", 92, 540, 300, a=a, sc=s)
        beach(c, t, sc)
        for k, (ln, ts) in enumerate([("3,000 people.", A(7, "3,000 people")), ("One Shabbat dinner.", A(7, "one shabbat")),
                                      ("On the beach in *Tel Aviv.*", A(7, "on the beach"))]):
            a, s = pop(t, ts); T(c, ln, 64, 540, 1132 + 70 * k, a=a, sc=s)
        a, s = pop(t, sc["date"], bounce=2.4)
        chip(c, "APRIL 2027", 70, 540, 1030, NAVY, fg=(247, 205, 106, 255), a=a, sc=s, w=900, outline=GOLD)
        a, s = pop(t, A(7, "on the beach") + 0.3)
        T(c, "3,000 איש. ארוחת שבת אחת.", 56, 540, 1342, a=a, sc=s, col=B2); T(c, "על החוף בתל אביב. אפריל 2027", 56, 540, 1402, a=a, sc=s, col=B2)
    add(st(7), back, c3000=A(7, "3,000 people") - 0.05, lit=A(7, "one shabbat"), date=A(7, "one shabbat") + 0.5)

    def cta(c, t, sc):
        t0 = sc["t0"]
        a, s = pop(t, t0 + 0.05); T(c, "Comment", 96, 540, 305, a=a, sc=s)
        a, s = pop(t, A(8, "shabbat"), bounce=2.4)
        if a > 0.01:
            f = font(120, 900); pw = f.getlength("SHABBAT") + 130; ph = 190
            c.save(); c.translate(540, 462); c.scale(s, s); old = St.a; St.a *= a
            sa(c, NAVY, 0.18); rr(c, -pw / 2, -ph / 2 + 12, pw, ph, ph / 2); c.fill()
            g = cairo.LinearGradient(-pw / 2, 0, pw / 2, 0); g.add_color_stop_rgb(0, *GOLD[:3]); g.add_color_stop_rgb(0.5, *GOLD2[:3]); g.add_color_stop_rgb(1, *GOLD[:3])
            rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.set_source(g); c.fill_preserve(); sa(c, NAVY); c.set_line_width(7); c.stroke()
            St.a = old; c.restore()
            T(c, "SHABBAT", 120, 540, 466, a=a, sc=s)
        a, s = pop(t, A(8, "share this reel")); T(c, "+ share this reel", 84, 540, 625, a=a, sc=s)
        icon(c, 540, 752 + 12 * math.sin(t * 7), 0.58, hand_down, a=ramp(t, A(8, "share this reel") + 0.2, A(8, "share this reel") + 0.4))
        a, s = pop(t, A(8, "send you an invite"))
        chip(c, "We'll send you an invite", 58, 540, 912, NAVY, a=a, sc=s, w=800, icon_fn=envelope)
        a, s = pop(t, A(8, "send you an invite") + 0.2); T(c, "Sign up: *noamroz.com/shabbat*", 48, 540, 1000, a=a, sc=s, w=800)
        a, s = pop(t, A(8, "send you an invite") + 0.4); T(c, "כתבו שבת ושתפו, ונשלח לכם הזמנה", 58, 540, 1075, a=a, sc=s, col=B2)
        a, s = pop(t, A(8, "let's break")); T(c, "Let's break it *together.*", 66, 540, 1160, a=a, sc=s)
        a, s = pop(t, A(8, "let's break") + 0.3); T(c, "April 2027, Tel Aviv beach", 46, 540, 1232, a=a, sc=s, w=800, col=(166, 112, 22, 255))
        a, s = pop(t, A(8, "let's break", end=True) + 0.4, bounce=2.4)
        chip(c, "Part 2 on my profile", 44, 540, 1310, GOLD, fg=N2, a=a, sc=s, w=900)
        a, s = pop(t, A(8, "let's break", end=True) + 0.6); T(c, "חלק 2 בפרופיל שלי", 40, 540, 1370, a=a, sc=s, col=B2, w=700)
        a = ramp(t, A(8, "let's break") + 0.6, A(8, "let's break") + 0.9)
        T(c, "Every record here is real. Sources in the caption.", 36, 540, 1418, a=a, w=700, col=GY2, src=True)
    add(st(8), cta)
    return S

# ------------------------------------------------------------------ frame + QA
def draw_frame(c, t, S, subs):
    CUR["t"] = t; R.background(c, t)
    for i, sc in enumerate(S):
        a0 = sc["t0"]; a1 = S[i + 1]["t0"] if i + 1 < len(S) else 1e9
        if t < a0 - 0.01 or t > a1 + 0.25: continue
        al = (1.0 if i == 0 else ramp(t, a0, a0 + 0.2)) * (1 - ramp(t, a1, a1 + 0.22))
        if al <= 0.01: continue
        CUR["scene"] = i; St.a = al; sc["fn"](c, t, sc); St.a = 1.0
    CUR["scene"] = None
    for a, b, ss, x, y, _ in subs:
        if a <= t < b: c.set_source_surface(ss, x, y); c.paint()
def qa_issues(S, r):
    iss = []
    for sc_, s, sz, x0, y0, x1, y1, src in QA["text"]:
        if x0 < 0: continue  # local-coordinate (translated) text
        if sz < 36: iss.append(("small", s, sz))
        if x0 < 70 - 1 or x1 > 1010 + 1: iss.append(("x safe", s, round(x0), round(x1)))
        if y0 < 230 or y1 > 1450: iss.append(("y safe", s, round(y0), round(y1)))
        if any(d in s for d in DASHES): iss.append(("dash", s))
    for i, sc in enumerate(S):
        a1 = S[i + 1]["t0"] if i + 1 < len(S) else r.T_END
        if a1 - sc["t0"] < 3.0: iss.append(("card<3s", i, round(a1 - sc["t0"], 2)))
    for a, b, *_, cc in r.sub_items:
        if any(d in cc for d in DASHES): iss.append(("dash sub", cc))
    return sorted(set(map(tuple, iss)))
NAMES = ["hook", "bridge", "strawberry", "protein", "lowest town", "hummus", "shabbat (lost)", "beach 3,000", "cta"]

def sfx_events(r, S):
    ding, thunk, cheer, whoosh = GA.trophy_ding(), GA.stamp_thunk(), GA.crowd_cheer(), GA.candle_whoosh()
    ev = [(0.0, ding, -3)]
    for sc in S[2:7]: ev.append((sc["t0"] + 0.05, ding, 0)); ev.append((sc["stamp"] - 0.02, thunk, 2))
    sb = S[7]; ev.append((sb["c3000"] + 0.85, cheer, 1)); ev.append((sb["lit"] - 0.1, whoosh, -4))
    return ev

def main():
    vo_wav, asr_json = sys.argv[1:3]
    r = Reel(vo_wav, asr_json); r.build_vo(); S = build(r); subs = r.subs()
    keys = [0.0, 2.8] + [sc["t0"] + 0.85 * ((S[i + 1]["t0"] if i + 1 < len(S) else r.T_END) - sc["t0"]) for i, sc in enumerate(S)]
    keys += [S[2]["stamp"] + 0.5, S[6]["stamp"] + 0.4, S[7]["c3000"] + 1.3, S[7]["lit"] + 1.6, r.VO_END + 2.5]
    keys = sorted(set(round(x, 2) for x in keys))
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf)
    if "--preview" in sys.argv:
        k = sys.argv.index("--preview"); ts = [float(x) for x in sys.argv[k + 1].split(",")] if len(sys.argv) > k + 1 else keys
        th = []
        for t in ts: draw_frame(c, t, S, subs); th.append((t, surf2pil(surf)))
        sheet_of(th, f"{SCR}/prev.png"); print(qa_issues(S, r)); return
    os.nice(5); kit.wait_disk(150)
    wav = f"{SCR}/mix.wav"; mrep = GA.mix(r.vo, r.T_END, sfx_events(r, S), wav, swell=(S[7]["t0"], S[8]["t0"]), tp=-2.3)
    out = f"{D}/guinness_v3.mp4"; N = int(math.ceil(r.T_END * FPS))
    cmd = ["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "pipe:0", "-i", wav, "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
           "-maxrate", "2.2M", "-bufsize", "4M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); tset = {int(round(x * FPS)): x for x in keys}; th = []
    for fi in range(N):
        t = fi / FPS; draw_frame(c, t, S, subs); surf.flush(); p.stdin.write(surf.get_data())
        if fi in tset: th.append((tset[fi], surf2pil(surf).resize((390, 693), Image.LANCZOS)))
        if fi % 300 == 0: print("frame", fi, "/", N, flush=True)
    p.stdin.close(); assert p.wait() == 0; os.remove(wav)
    sheet_of(th, f"{D}/qa_sheet_v3.png")
    kit.run(["nice", "-n", "15", "ffmpeg", "-v", "error", "-y", "-i", out, "-c:v", "libx264", "-preset", "medium", "-crf", "25", "-maxrate", "0.85M",
             "-bufsize", "1.7M", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "48000", "-movflags", "+faststart", f"{D}/guinness_v3_web.mp4"])
    sb = S[7]
    timing = {"file": "guinness_v3.mp4", "fps": FPS, "size": [W, H], "duration_s": r.T_END, "vo_end_s": round(r.VO_END, 2), "hold_after_vo_s": HOLD,
              "vo": "vo_raw_v3.wav, house chain: rubberband pitch 0.9715 (formant preserved), bass g=2 f=135, clean_vo, atempo 1.1, 0.3 s lead; clean_vo ducked endings restored from the dry chain (v5lib restore: 46 auto spans + forced window 22.25-22.59 for The)",
              "timing_method": "asr_segs.py logic (silencedetect -38 dB, sherpa whisper turbo, DP to tts_v3.txt lines) on the processed, word-restored VO; no hand splits",
              "beats": [{"id": NAMES[i], "start": round(sc["t0"], 2), "end": round(S[i + 1]["t0"] if i + 1 < len(S) else r.T_END, 2),
                         "vo_line": r.lines[i], "vo_span": [round(r.lspan[i][0], 2), round(r.lspan[i][1], 2)]} for i, sc in enumerate(S)],
              "events": {"stamps": {NAMES[i]: round(S[i]["stamp"], 2) for i in range(2, 7)}, "counter_3000_start": round(sb["c3000"], 2),
                         "candles_start": round(sb["lit"], 2), "date_pill": round(sb["date"], 2), "music_swell": [round(S[7]["t0"], 2), round(S[8]["t0"], 2)]},
              "subtitles": [[round(a, 2), round(b, 2), cc] for a, b, *_, cc in r.sub_items],
              "mix": dict(mrep, target="-14 LUFS integrated, -1.5 dBTP, 48 kHz"),
              "qa_issues": qa_issues(S, r)}
    json.dump(timing, open(f"{D}/timing_v3.json", "w"), indent=1, ensure_ascii=False); print("issues", timing["qa_issues"])

if __name__ == "__main__":
    main()
