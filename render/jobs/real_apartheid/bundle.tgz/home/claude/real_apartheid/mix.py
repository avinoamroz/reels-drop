"""local step: loopable music bed + one soft hit at the reveal under work/vo.wav -> work/mix.m4a (-14 LUFS, <= -1.5 dBTP).
Same method as series_more/safe_p2_v3/mix_audio_v3.py: the bed runs at a tempo that fits a whole number of bars into T_END,
is generated one bar longer, and the overflow is folded onto the start, so the last sample flows into the first."""
import sys, os, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/safety_v4"); sys.path.insert(0, "/home/claude/rehook")
import audio_v4 as AU, rk
D = "/home/claude/real_apartheid"
W = json.load(open(f"{D}/work/words.json"))["words"]
LS = lambda li: min(w["t0"] for w in W if w["li"] == li); LE = lambda li: max(w["t1"] for w in W if w["li"] == li)
dur = round(LE(16) + 0.5, 2); SR = AU.SR; TURN = LS(9) - 0.3
bars = round(dur / (4 * 60 / 86)); bpm = 4 * 60 * bars / dur; bar = 4 * 60 / bpm
raw = AU.doc_music(dur + bar, bpm=bpm, flip_at=TURN, end_ring=0.01)
n = int(round(dur * SR)); xf = int(0.6 * SR)
bed = raw[:, :n].copy(); tail = raw[:, n:n + xf]
bed[:, :tail.shape[1]] += tail * (1 - np.minimum(1, np.arange(tail.shape[1]) / xf))[None, :]
vo, sr = sf.read(f"{D}/work/vo.wav"); assert sr == SR, (sr, SR)
ev = [(TURN + 0.25, AU.soft_hit(), -4.0)]
mw = f"{D}/work/mix.wav"; rep = AU.mix(vo, dur, ev, mw, music_db=-19.0, sfx_db=-13.0, bed=bed); print(rep)
x, _ = sf.read(mw); J = rk.finish_audio(x.T.astype(np.float64), f"{D}/work/mix.m4a"); os.remove(mw)
json.dump(dict(T_END=dur, bpm=bpm, loudnorm=J), open(f"{D}/work/audio.json", "w"), indent=1); print("audio", dur, J.get("final_I"), J.get("final_TP"))
