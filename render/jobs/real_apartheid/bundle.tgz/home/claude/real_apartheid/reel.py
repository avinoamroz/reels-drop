"""real_apartheid: "A neighbourhood called the slaves?" (@noamroz__, English, 1 Nov 2026).
Apple keynote look from series_more/safe_p2_v3 (near-black stage, one soft glow, Inter only, cubic fades with blur-in, rolling
hero numbers), helpers shared with empires_israel/reel.py, Ken Burns photo panels (Wikimedia Commons, credited at 36 px).
Beats: the Gaza hook (Hay al-Abeed), four state-level examples (Mauritania, Lebanon, Kuwait, Libya), the turn
("So which country gets called apartheid?"), the reveal (Israel: 1 in 5 Arab, 19 Arab seats, an Arab Supreme Court justice),
Noam's close, then the lead-in "So next time someone says apartheid, ask them about..." at the hook's place, and the last
0.45 s cross-fade into the exact frame 0.
usage: python3 reel.py [--snaps 0,3.1,...|last] (snaps to work/snaps) | python3 reel.py (silent video to work/silent.mp4)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter
D = "/home/claude/real_apartheid"; FD = "/home/claude/series_more/safe_p2_v3/fonts"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out", default=f"{D}/work/silent.mp4"); A = ap.parse_args()
W, H, FPS = 1080, 1920, 30

# ------------------------------------------------------------------ timing from the narration (work/words.json)
WJ = json.load(open(f"{D}/work/words.json")); WORDS = WJ["words"]
LW = {}
for w in WORDS: LW.setdefault(w["li"], []).append(w)
def S(li, i=0): return LW[li][i]["t0"]
def E(li, i=-1): return LW[li][i]["t1"]
def WI(li, word):     # index of the first word in line li that starts with `word`
    for i, w in enumerate(LW[li]):
        if re.sub(r"\W", "", w["w"]).lower().startswith(re.sub(r"\W", "", word).lower()): return i
    raise KeyError((li, word))
NL = max(LW) + 1
T_END = round(E(NL - 1) + 0.5, 2); LOOP = 0.45

# ------------------------------------------------------------------ look
BG = "#060608"; GLOW_COL = "#E8C77E"
WHITE, GREY, GOLD, SKY = "#F5F5F7", "#A1A1A6", "#E8C77E", "#45A4DD"
ISR_GOLD = "#B8923F"; GREEN = (46 / 255, 204 / 255, 113 / 255)
def hx(h): h = h.lstrip("#"); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def ease(u): u = min(1.0, max(0.0, u)); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def lerp(a, b, u): return a + (b - a) * u

FONTS = {k: f"{FD}/{v}.otf" for k, v in dict(db="InterDisplay-Bold", dsb="InterDisplay-SemiBold", dm="InterDisplay-Medium",
                                              dl="InterDisplay-Light", sb="Inter-SemiBold", r="Inter-Regular", l="Inter-Light").items()}
_fc = {}
def font(k, sz):
    key = (k, int(round(sz)))
    if key not in _fc: _fc[key] = ImageFont.truetype(FONTS[k], key[1])
    return _fc[key]
def fit(s, k, size, maxw=960):
    while font(k, size).getlength(s) > maxw and size > 40: size -= 2
    return size

# stage: one wide soft glow
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
GLOW = np.exp(-0.5 * (((xx - 540) / (700 * 0.85)) ** 2 + ((yy - 1000) / 700) ** 2))[:, :, None]
BASE = hx(BG)[None, None, :].astype(np.float32); GCOL = hx(GLOW_COL)[None, None, :].astype(np.float32)
DITHER = (np.random.default_rng(3).random((H, W, 1)).astype(np.float32) - 0.5) * 3.0
del yy, xx
def stage(g):
    a = BASE + GLOW * g * (GCOL - BASE) + DITHER
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

# text rasters at 2x, composited with sub-pixel placement, scale and blur (from engine_v3)
_rc = {}
def raster(s, fk, size, tab=False):
    key = (s, fk, size, tab)
    if key in _rc: return _rc[key]
    f = font(fk, size * 2); asc, desc = f.getmetrics(); pad = 8
    if not tab:
        w = f.getlength(s); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad, pad + asc), s, font=f, fill=255, anchor="ls")
    else:
        dw = sorted(f.getlength(d) for d in "0123456789")[5]; adv = [dw if ch.isdigit() else f.getlength(ch) for ch in s]
        w = sum(adv); im = Image.new("L", (int(w) + 2 * pad, asc + desc + 2 * pad), 0); d = ImageDraw.Draw(im); x = pad
        for ch, a in zip(s, adv):
            off = (dw - f.getlength(ch)) / 2 if ch.isdigit() else 0; d.text((x + off, pad + asc), ch, font=f, fill=255, anchor="ls"); x += a
    cap = f.getbbox("H", anchor="ls"); r = (im, pad + asc, w / 2, -cap[1] / 2)
    if len(_rc) > 500: _rc.pop(next(iter(_rc)))
    _rc[key] = r; return r
def put(canvas, info, cx, base_y, scale, color, alpha, blur):
    if alpha <= 0.004: return
    im, by, w1, _ = info; k = scale / 2.0
    tw, th = max(1, round(im.width * k)), max(1, round(im.height * k)); m = im.resize((tw, th), Image.LANCZOS)
    left = cx - (im.width * k) / 2; top = base_y - by * k
    pad = int(math.ceil(blur * 3)) + 2; ix, iy = math.floor(left) - pad, math.floor(top) - pad; fx, fy = left - ix, top - iy
    cw, ch = tw + 2 * pad + 2, th + 2 * pad + 2
    m = m.transform((cw, ch), Image.AFFINE, (1, 0, -fx, 0, 1, -fy), Image.BICUBIC)
    if blur > 0.25: m = m.filter(ImageFilter.GaussianBlur(blur))
    a = (np.asarray(m, np.float32) * alpha).clip(0, 255).astype(np.uint8)
    lay = Image.new("RGBA", (cw, ch), tuple(int(c) for c in color) + (0,)); lay.putalpha(Image.fromarray(a, "L"))
    x0, y0 = max(0, ix), max(0, iy); x1, y1 = min(W, ix + cw), min(H, iy + ch)
    if x1 > x0 and y1 > y0: canvas.alpha_composite(lay.crop((x0 - ix, y0 - iy, x1 - ix, y1 - iy)), (x0, y0))
def capof(fk, size): return raster("H", fk, size)[3]
T_IN, T_OUT = 0.5, 0.3
def envl(t, t0, t1, ain=T_IN, aout=T_OUT, inst=False):
    if t < t0 and not inst: return 0, 1, 0, 0
    u = 1.0 if (inst and t < t0 + 1e-6) else seg(t, t0, t0 + ain); v = seg(t, t1, t1 + aout)
    return u * (1 - v), (0.965 + 0.035 * u) * (1 + 0.02 * v), 11 * (1 - u) + 7 * v, 16 * (1 - u)
def text(canvas, t, s, y_cap_mid, size, t0, t1, fk="db", color=WHITE, inst=False, tab=False, zoom=1.0, ain=T_IN, aout=T_OUT, alpha=1.0):
    """y_cap_mid: vertical middle of the capitals"""
    a, sc, bl, dy = envl(t, t0, t1, ain, aout, inst)
    if a * alpha <= 0.004: return
    info = raster(s, fk, size, tab); put(canvas, info, 540, y_cap_mid + info[3] / 2 + dy, sc * zoom, hx(color), a * alpha, bl)

# ------------------------------------------------------------------ photos (Ken Burns in a rounded panel)
PH = {  # key: (file, focus x, focus y, credit at 36 px)
}
_ph = {}
def photo_img(k):
    if k not in _ph: _ph[k] = Image.open(f"{D}/photos/{PH[k][0]}").convert("RGB")
    return _ph[k]
_mask = {}
def rmask(w, h, r):
    if (w, h) not in _mask:
        m = Image.new("L", (w * 2, h * 2), 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, w * 2 - 1, h * 2 - 1), r * 2, fill=255)
        _mask[(w, h)] = m.resize((w, h), Image.LANCZOS)
    return _mask[(w, h)]
def photo(canvas, t, k, t0, t1, box, alpha=1.0, ain=0.45, aout=0.35):
    a = seg(t, t0, t0 + ain) * (1 - seg(t, t1, t1 + aout)) * alpha
    if a <= 0.004: return
    x0, y0, x1, y1 = box; w, h = x1 - x0, y1 - y0; im = photo_img(k); fx, fy = PH[k][1], PH[k][2]
    u = min(1, max(0, (t - t0) / max(1.0, t1 - t0))); z = 1.0 + 0.08 * u
    ar = w / h; iw, ih = im.size
    cw = min(iw, ih * ar) / z; chh = cw / ar
    cx = min(max(fx * iw, cw / 2), iw - cw / 2); cy = min(max(fy * ih, chh / 2), ih - chh / 2)
    crop = im.transform((w, h), Image.EXTENT, (cx - cw / 2, cy - chh / 2, cx + cw / 2, cy + chh / 2), Image.BICUBIC)
    sc = 0.97 + 0.03 * seg(t, t0, t0 + ain)
    m = rmask(w, h, 34); lay = crop.convert("RGBA"); lay.putalpha(m.point(lambda v: int(v * a)))
    if sc < 0.999:
        nw, nh = int(w * sc), int(h * sc); lay = lay.resize((nw, nh), Image.BICUBIC); x0 += (w - nw) // 2; y0 += (h - nh) // 2
    canvas.alpha_composite(lay, (int(x0), int(y0)))
def credit(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.45)

# ------------------------------------------------------------------ counters
def roll(t, t0, dur, v0, v1, log=False):
    u = seg(t, t0, t0 + dur)
    if log and v0 > 0 and v1 > 0: return math.exp(lerp(math.log(v0), math.log(v1), u))
    return lerp(v0, v1, u)
def num_text(canvas, t, s, y, size, t0, t1, color=GOLD, ain=0.4):
    text(canvas, t, s, y, size, t0, t1, fk="db", color=color, tab=True, ain=ain)

# ------------------------------------------------------------------ flat layers: subtitles, sources
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)

# ================================================================== real_apartheid
PH.update({
 "gaza": ("gaza.jpg", 0.55, 0.62, "Gaza City, 2007. Photo: MMH, CC BY-SA 3.0"),
 "maur": ("maur.jpg", 0.50, 0.55, "Nouakchott. Photo: Laminesall96, CC BY-SA 4.0"),
 "leb": ("leb.jpg", 0.50, 0.62, "Shatila camp, Beirut. Photo: M. K. Dorai, public domain"),
 "kuw": ("kuw.jpg", 0.62, 0.42, "Kuwait City. Photo: Zairon, CC BY 4.0"),
 "lby": ("lby.jpg", 0.40, 0.55, "Migrants who fled Libya, 2011. Photo: DFID, CC BY 2.0"),
 "isr": ("isr.jpg", 0.50, 0.40, "The Knesset, Jerusalem. Photo: Clema12, CC BY-SA 4.0"),
})
L = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]
SUBF = font("sb", 54); SRCF = font("r", 40)
def wrap(s, f, maxw):
    out = [""]
    for w_ in s.split():
        tr = (out[-1] + " " + w_).strip()
        if f.getlength(tr) <= maxw or not out[-1]: out[-1] = tr
        else: out.append(w_)
    return out
def flat(canvas, lines, f, cy, lh, col, alpha):
    if alpha <= 0.004: return
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay); y0 = cy - lh * (len(lines) - 1) / 2
    for i, l in enumerate(lines): d.text((W / 2, y0 + i * lh), l, font=f, fill=tuple(int(c) for c in hx(col)) + (int(255 * alpha),), anchor="mm")
    canvas.alpha_composite(lay)
def lerpbox(a, b, u): return tuple(lerp(x, y, u) for x, y in zip(a, b))
def photo_b(canvas, t, k, t0, t1, box, ain=0.45, aout=0.35, alpha=1.0):
    x0, y0, x1, y1 = [int(round(v)) for v in box]; photo(canvas, t, k, t0, t1, (x0, y0, x1, y1), alpha=alpha, ain=ain, aout=aout)

# ------------------------------------------------------------------ timing
B = {li: S(li) for li in range(NL)}
HOOK_END = S(1) - 0.15
BOX = (60, 250, 1020, 760); CRED_Y = 792; NAME_Y = 880       # standard photo panel, its credit, the country name
HOOK_BOX = (60, 760, 1020, 1440)
END_T = S(16) - 0.12
BEATS = [  # photo key, first line, last line
 ("maur", 4, 5), ("leb", 6, 6), ("kuw", 7, 7), ("lby", 8, 8)]
def b_t0(li): return S(li) - 0.2
TURN = S(9) - 0.2; REV = S(10) - 0.15

def glow_at(t):
    return 0.06 + 0.08 * seg(t, TURN, TURN + 1.0) * (1 - seg(t, S(13) - 0.3, S(13) + 1.0))

HOOK_A, HOOK_B = "A neighbourhood", "called “the slaves”?"
HS = min(fit(HOOK_A, "db", 124), fit(HOOK_B, "db", 124)); HY1, HY2 = 430, 430 + HS * 1.18
END_A, END_B = "So next time someone", "says apartheid, ask…"
ES = min(fit(END_A, "db", 124), fit(END_B, "db", 124))

def frame_raw(t):
    im = stage(glow_at(t))
    # ---- hook + Gaza (lines 0 to 2): the photo starts low under the hook, then rises into the standard panel
    gu = seg(t, HOOK_END - 0.1, HOOK_END + 0.7)
    photo_b(im, t, "gaza", -1, S(3) - 0.2, lerpbox(HOOK_BOX, BOX, gu), ain=0.01)
    if t < S(3) + 0.2: credit_at(im, t, "gaza", -1, S(3) - 0.2, lerp(HOOK_BOX[3] + 32, CRED_Y, gu))
    zoom = 1 + 0.03 * seg(t, 0, HOOK_END)
    text(im, t, HOOK_A, HY1, HS, 0, HOOK_END, inst=True, zoom=zoom)
    text(im, t, HOOK_B, HY2, HS, 0, HOOK_END, inst=True, zoom=zoom)
    # lead-in at the hook's place and size (the loop then reads "...ask them about / a neighbourhood called the slaves?")
    text(im, t, END_A, HY1, ES, END_T, T_END + 1, ain=0.55); text(im, t, END_B, HY2, ES, END_T + 0.12, T_END + 1, ain=0.55)
    photo_b(im, t, "gaza", END_T + 0.3, T_END + 1, HOOK_BOX, ain=0.8)
    # line 1: Gaza City / Hay al-Abeed / "The slaves"
    t1a = S(1, WI(1, "In")) - 0.1; t1b = S(1, WI(1, "alAbeed")) - 0.08; t1c = S(1, WI(1, "slaves")) - 0.25; t2 = S(2) - 0.12
    text(im, t, "Gaza City", NAME_Y, 92, t1a, t2)
    text(im, t, "Hay al-Abeed", 1060, fit("Hay al-Abeed", "db", 150), t1b, t2, color=GOLD)
    text(im, t, "“The slaves”", 1230, 96, t1c, t2, fk="dsb")
    # line 2: 11,000 / passed over
    t3 = S(3) - 0.15
    text(im, t, "11,000", NAME_Y + 120, 170, t2, t3, color=GOLD, tab=True)
    text(im, t, "Black Palestinians in Gaza City", NAME_Y + 250, fit("Black Palestinians in Gaza City", "dm", 64), t2 + 0.1, t3, fk="dm", color=GREY)
    text(im, t, "Passed over for jobs", 1330, 76, S(2, WI(2, "passed")) - 0.05, t3, fk="dsb")
    text(im, t, "and for marriage", 1430, 76, S(2, WI(2, "marriage")) - 0.25, t3, fk="dsb", color=GOLD)
    # line 3: elsewhere, it's worse
    t4 = b_t0(4)
    text(im, t, "Elsewhere,", 820, 150, t3, t4); text(im, t, "it's worse.", 1000, 150, S(3, WI(3, "it's")) - 0.1, t4, color=GOLD)
    # ---- the four states
    for k, la, lb in BEATS:
        t0 = b_t0(la); t1 = b_t0(lb + 1); photo_b(im, t, k, t0, t1, BOX, ain=0.35, aout=0.3); credit_at(im, t, k, t0, t1, CRED_Y)
    # Mauritania
    t0, t1 = b_t0(4), b_t0(6); m5 = S(5) - 0.1
    text(im, t, "Mauritania", NAME_Y, 104, t0 + 0.05, t1)
    text(im, t, "Slavery a crime only in", 1010, fit("Slavery a crime only in", "dm", 66), t0 + 0.3, m5, fk="dm", color=GREY)
    v = roll(t, S(4, WI(4, "two")) - 0.1, 0.7, 1981, 2007)
    text(im, t, f"{int(round(v))}", 1200, 200, S(4, WI(4, "only")) - 0.1, m5, color=GOLD, tab=True)
    text(im, t, "About 1 in 30", 1110, 150, m5, t1, color=GOLD)
    text(im, t, "still in modern slavery", 1270, fit("still in modern slavery", "dsb", 76), m5 + 0.4, t1, fk="dsb")
    # Lebanon
    t0, t1 = b_t0(6), b_t0(7)
    text(im, t, "Lebanon", NAME_Y, 104, t0 + 0.05, t1)
    text(im, t, "Palestinian refugees", 1010, fit("Palestinian refugees", "dm", 70), t0 + 0.3, t1, fk="dm", color=GREY)
    text(im, t, "can't own property", 1140, fit("can't own property", "dsb", 92), S(6, WI(6, "owning")) - 0.25, t1, fk="dsb")
    text(im, t, "since 2001", 1300, 130, S(6, WI(6, "since")) - 0.1, t1, color=GOLD)
    # Kuwait
    t0, t1 = b_t0(7), b_t0(8); ka = S(7, WI(7, "about")) - 0.1
    text(im, t, "Kuwait", NAME_Y, 104, t0 + 0.05, t1)
    v = roll(t, ka, 1.0, 0, 100000)
    text(im, t, f"{int(round(v)):,}", 1080, 190, ka, t1, color=GOLD, tab=True)
    text(im, t, "stateless residents", 1230, fit("stateless residents", "dsb", 84), S(7, WI(7, "stateless")) - 0.1, t1, fk="dsb")
    text(im, t, "denied citizenship", 1340, fit("denied citizenship", "dm", 70), S(7, WI(7, "denied")) - 0.1, t1, fk="dm", color=GREY)
    # Libya
    t0, t1 = b_t0(8), TURN
    text(im, t, "Libya", NAME_Y, 104, t0 + 0.05, t1)
    text(im, t, "Migrants sold at auction", 1010, fit("Migrants sold at auction", "dsb", 80), S(8, WI(8, "migrants")) - 0.2, t1, fk="dsb")
    text(im, t, "$400", 1200, 220, S(8, WI(8, "four")) - 0.15, t1, color=GOLD, tab=True)
    text(im, t, "Filmed by CNN, 2017", 1330, 64, S(8, WI(8, "four")) + 0.1, t1, fk="dm", color=GREY)
    # ---- the turn
    text(im, t, "So which country", 820, fit("gets called apartheid?", "db", 124), TURN, REV, ain=0.6)
    text(im, t, "gets called apartheid?", 820 + 150, fit("gets called apartheid?", "db", 124), TURN + 0.12, REV, ain=0.6, color=GOLD)
    # ---- the reveal: Israel
    r1 = S(11) - 0.15; r2 = S(12) - 0.15; r3 = S(13) - 0.2
    photo_b(im, t, "isr", REV, r3, BOX, ain=0.5); credit_at(im, t, "isr", REV, r3, CRED_Y)
    text(im, t, "Israel", NAME_Y, 120, REV, r3)
    text(im, t, "1 in 5", 1090, 210, S(10, WI(10, "one")) - 0.1, r1, color=GOLD)
    text(im, t, "citizens is Arab", 1250, 84, S(10, WI(10, "citizens")) - 0.1, r1, fk="dsb")
    v = roll(t, S(11, WI(11, "nineteen")) - 0.25, 0.7, 0, 19)
    text(im, t, f"{int(round(v))}", 1100, 230, r1, r2, color=GOLD, tab=True)
    text(im, t, "seats for Arab parties", 1270, fit("seats for Arab parties", "dsb", 84), r1 + 0.1, r2, fk="dsb")
    text(im, t, "Knesset election, Oct 2026", 1370, 64, r1 + 0.25, r2, fk="dm", color=GREY)
    text(im, t, "An Arab justice", 1060, 104, r2, r3)
    text(im, t, "on the Supreme Court", 1190, fit("on the Supreme Court", "dsb", 84), S(12, WI(12, "Supreme")) - 0.25, r3, fk="dsb", color=GOLD)
    text(im, t, "Khaled Kabub, since 2022", 1300, 64, S(12, WI(12, "Supreme")), r3, fk="dm", color=GREY)
    # ---- Noam's close
    c1 = S(14) - 0.15; c2 = S(15) - 0.15
    text(im, t, "Israel isn't perfect.", 820, fit("Israel isn't perfect.", "db", 120), r3, c1)
    text(im, t, "It's complicated.", 980, 120, S(13, WI(13, "It's")) - 0.1, c1, color=GOLD)
    text(im, t, "Judged by US or", 760, 104, c1, c2, fk="dsb")
    text(im, t, "European standards,", 880, fit("European standards,", "dsb", 104), c1 + 0.1, c2, fk="dsb")
    text(im, t, "you miss what's", 1060, 104, S(14, WI(14, "you")) - 0.15, c2, color=GOLD)
    text(im, t, "really going on.", 1180, 104, S(14, WI(14, "really")) - 0.15, c2, color=GOLD)
    text(im, t, "Compare Israel", 820, 130, c2, END_T)
    text(im, t, "to its neighbours.", 980, fit("to its neighbours.", "db", 130), S(15, WI(15, "to")) - 0.1, END_T, color=GOLD)
    sources(im, t); subtitles(im, t)
    return im
def credit_at(canvas, t, k, t0, t1, y):
    text(canvas, t, PH[k][3], y, 36, t0, t1, fk="r", color="#8E8E93", ain=0.3, inst=(t0 <= 0))

# ------------------------------------------------------------------ subtitles (lines 0, 9, 13, 15, 16: the hero text is the words)
CH = [(1, 0, "It's real. In Gaza City,"), (1, WI(1, "a"), "a Black Palestinian quarter"), (1, WI(1, "is"), "is still called Hay al-Abeed."),
      (1, WI(1, "The"), "The slaves."), (2, 0, "Many say they're passed over,"), (2, WI(2, "for"), "for jobs and for marriage."),
      (3, 0, "And elsewhere, it's worse."),
      (4, 0, "Mauritania made slavery a crime"), (4, WI(4, "only"), "only in 2007."), (5, 0, "About 1 in 30 people there"),
      (5, WI(5, "still"), "still live in it."), (6, 0, "Lebanon has barred Palestinian refugees"), (6, WI(6, "from"), "from owning property"),
      (6, WI(6, "since"), "since 2001."), (7, 0, "Kuwait: about 100,000"), (7, WI(7, "stateless"), "stateless residents,"),
      (7, WI(7, "denied"), "denied citizenship."), (8, 0, "In Libya, CNN filmed migrants"), (8, WI(8, "sold"), "sold at auction."),
      (8, WI(8, "For"), "For as little as $400."), (10, 0, "Israel. Where 1 in 5"), (10, WI(10, "citizens"), "citizens is Arab."),
      (11, 0, "Arab parties just won"), (11, WI(11, "nineteen"), "19 seats in the Knesset."), (12, 0, "An Arab justice"),
      (12, WI(12, "sits"), "sits on the Supreme Court."), (14, 0, "But judge this region"), (14, WI(14, "by"), "by American or European standards,"),
      (14, WI(14, "and"), "and you miss what's really going on.")]
SUBS = []
for i, (li, wi, s) in enumerate(CH):
    a = S(li, wi) - 0.04; nxt = CH[i + 1] if i + 1 < len(CH) else None
    endw = (nxt[1] - 1) if (nxt and nxt[0] == li) else len(LW[li]) - 1
    b = E(li, endw) + 0.4
    if nxt: b = min(b, S(nxt[0], nxt[1]) - 0.06)
    SUBS.append((a, b, s)); assert len(s.split()) <= 7, s
def subtitles(canvas, t):
    for a, b, s in SUBS:
        if a - 0.01 <= t < b:
            al = min(1, (t - a) / 0.12 + 1e-4, (b - t) / 0.12); flat(canvas, wrap(s, SUBF, 900), SUBF, 1608, 68, "#FFFFFF", 0.94 * al)
SRC0 = ["Afro-Palestinians of Al Jalla'a district, Gaza City:", "Gulf News, Nov 2018"]
SOURCES = [(0, SRC0), (b_t0(4), ["Criminalised 2007: Anti-Slavery International, 2007", "1 in 31 (32 per 1,000): Global Slavery Index 2023"]),
           (b_t0(6), ["Law 296 of 2001: Human Rights Watch, 2010", "Still in force: TIMEP, 2026"]),
           (b_t0(7), ["About 100,000 Bidun, government estimate:", "Amnesty International, 2023"]),
           (b_t0(8), ["CNN, “People for sale”, Nov 2017"]),
           (TURN, []),
           (REV, ["Arab citizens: 2.157 million, 21.1%:", "Israel CBS, 2026"]),
           (S(11) - 0.15, ["Arab parties 19 seats, provisional count:", "Jerusalem Post, Al Jazeera, Oct 2026"]),
           (S(12) - 0.15, ["Justice Khaled Kabub sworn in May 2022:", "Times of Israel, 2022"]),
           (S(13) - 0.2, []), (END_T, SRC0)]
def sources(canvas, t):
    for i, (t0, lines) in enumerate(SOURCES):
        t1 = SOURCES[i + 1][0] if i + 1 < len(SOURCES) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.4)) * (1 - seg(t, t1 - 0.3, t1))
        if lines and t >= t0 - 0.01 and a > 0: flat(canvas, lines, SRCF, 1772, 50, "#8E8E93", a)

F0 = None
def frame(t):
    global F0
    if t < T_END - LOOP: return frame_raw(t).convert("RGB")
    if F0 is None: F0 = frame_raw(0.0)
    u = ease((t - (T_END - LOOP)) / max(1e-3, LOOP - 1 / FPS))
    return Image.blend(frame_raw(t), F0, u).convert("RGB")

# ------------------------------------------------------------------ guards
_D = tuple(chr(x) for x in (0x2012, 0x2013, 0x2014, 0x2015))
_txt = [s for _, _, s in SUBS] + [l for _, v in SOURCES for l in v] + [v[3] for v in PH.values()] + [HOOK_A, HOOK_B, END_A, END_B] + L
assert not any(d in s for s in _txt for d in _D), "dash"
assert not any(re.search(r"in my (view|opinion)|to be fair|islam", s, re.I) for s in _txt)
for _, v in SOURCES:
    for l in v: assert SRCF.getlength(l) <= 980, ("source too wide", l)
for v in PH.values(): assert font("r", 36).getlength(v[3]) <= 980, v[3]

N = int(round(T_END * FPS))
if __name__ == "__main__":
    if A.snaps:
        os.makedirs(f"{D}/work/snaps", exist_ok=True)
        for s in A.snaps.split(","):
            t = (N - 1) / FPS if s == "last" else min(float(s), (N - 1) / FPS)
            frame(t).save(f"{D}/work/snaps/s_{t:05.2f}.png")
        print("snaps", T_END); sys.exit()
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", A.out], stdin=subprocess.PIPE)
    for f in range(N):
        ff.stdin.write(frame(f / FPS).tobytes())
        if f % 150 == 0: print(f"frame {f}/{N}", flush=True)
    ff.stdin.close(); ff.wait(); print("video", A.out, T_END)
