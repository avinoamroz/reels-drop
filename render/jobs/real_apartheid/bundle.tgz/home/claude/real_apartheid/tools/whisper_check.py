"""whisper_check.py [wav]: windowed whisper turbo per script line (spans from work/words.json); prints recall per line."""
import sys, json, subprocess, numpy as np
sys.path.insert(0, "/home/claude/reelkit"); import asr
D = "/home/claude/real_apartheid"; src = sys.argv[1] if len(sys.argv) > 1 else f"{D}/work/vo.wav"
x = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True, check=True).stdout, np.float32)
lines = [l.strip() for l in open(f"{D}/tts.txt") if l.strip()]; W = json.load(open(f"{D}/work/words.json"))["words"]
spans = [(min(w["t0"] for w in W if w["li"] == i), max(w["t1"] for w in W if w["li"] == i)) for i in range(len(lines))]
out, texts = asr.isolated("check_audio", x, lines, spans)
for d, tx in zip(out, texts): print(f"{d['recall']:.2f}", d["line"], "| heard:", tx, "| missing:", d["missing"])
print("mean recall", round(sum(d["recall"] for d in out) / len(out), 3))
