"""green_200 scenes (1 Nov 2026): daily_1101 house scenes (dark stage, photo, label, circular loop) plus
- sc_gmap: the whole land of Israel (Golan incl.) on a dark stage. Israel's land fill goes from sand gold (1867) to green as
  the "greening" value g rises; West Bank and Gaza keep a slightly different (darker) gold; Green Line dashed green over a
  white under-stroke so it stays visible on green land. Major KKL forests are green canopy blobs at their real positions,
  growing with g. A big year label and an optional km² counter run through "steps" [{year, g, km, at}].
  Fields: en (headline), en_y, size, steps, pins [{en, lon, lat, at, side}], quote, source, zoom, view, hook.
House map rules: whole land of Israel in gold incl. Golan, WB and Gaza in a different gold, Green Line green."""
exec(compile(open("/home/claude/daily_1101/scenes_d01.py").read(), "/home/claude/daily_1101/scenes_d01.py", "exec"))
from shapely.geometry import Polygon as _Poly, Point as _Pt
from shapely.ops import unary_union as _union

SAND = kit.hx("#C9A24A"); WBG = kit.hx("#A8853A"); GRN = kit.hx("#4F8A3A"); GRN2 = kit.hx("#A8F07E")
LAND = (0.15, 0.23, 0.40); BORD = (0.35, 0.45, 0.62); GLINE = (46 / 255, 204 / 255, 113 / 255)
GOLAN = _Poly([(35.62, 33.25), (35.628, 33.278), (35.704, 33.306), (35.715, 33.331), (35.79, 33.335), (35.83, 33.30),
               (35.82, 33.26), (35.83, 33.20), (35.815, 33.14), (35.82, 33.10), (35.85, 33.04), (35.87, 32.97), (35.88, 32.90),
               (35.87, 32.83), (35.84, 32.76), (35.836, 32.729), (35.791, 32.754), (35.683, 32.708), (35.644, 32.69),
               (35.64, 32.82), (35.635, 32.90), (35.62, 33.0), (35.60, 33.1), (35.60, 33.2)])
# major KKL-JNF forests inside Israel (approximate centres), weight = relative size, y0 = rough planting start
FORESTS = [("Ben Shemen", 34.96, 31.94, 1.0, 1908), ("Hulda", 34.88, 31.83, 0.6, 1908), ("Yatir", 35.05, 31.36, 1.5, 1964),
           ("Lahav", 34.86, 31.38, 1.1, 1952), ("Biriya", 35.50, 32.98, 1.2, 1949), ("Carmel", 35.03, 32.72, 1.1, 1920),
           ("Menashe", 35.06, 32.58, 0.9, 1950), ("Gilboa", 35.42, 32.49, 0.8, 1950), ("Jerusalem hills", 35.05, 31.77, 1.3, 1949),
           ("Segev", 35.23, 32.88, 0.8, 1950), ("Ammiad", 35.53, 32.92, 0.7, 1950), ("Kissufim", 34.42, 31.33, 0.7, 1960),
           ("Golan", 35.75, 33.05, 0.6, 1970), ("Hanita", 35.17, 33.07, 0.6, 1950), ("Eshtaol", 35.00, 31.79, 0.9, 1956),
           ("Shaar Hagai", 35.05, 31.82, 0.9, 1949), ("Beeri", 34.47, 31.42, 0.8, 1960), ("Ilanot", 34.92, 32.29, 0.4, 1950),
           ("Tel Arad", 35.12, 31.30, 0.5, 1970), ("Ramat Menashe", 35.12, 32.62, 0.7, 1955), ("Naftali", 35.57, 33.10, 0.7, 1955)]
VIEW = [34.0, 29.45, 36.1, 33.42]

def _rp(c, pts):
    c.move_to(*pts[0])
    for q in pts[1:]: c.line_to(*q)
    c.close_path()

def _draw_map(c, mv, g, t, a=1.0):
    G = geo(); keep = St.a; St.a = 1.0
    x0, y0, x1, y1 = mv.x0, mv.y0, mv.x1, mv.y1
    for k, v in G.items():
        if k in ("IL", "PS"): continue
        rg = mv.rings(v["g"], 0.5)
        if rg: _path(c, rg); sa(c, LAND, a); c.fill_preserve(); sa(c, BORD, a); c.set_line_width(1.4); c.stroke()
    land = tuple(SAND[i] + (GRN[i] - SAND[i]) * g for i in range(3))
    for k, colr in (("IL", land), ("PS", WBG)):
        rg = mv.rings(G[k]["g"], 0.4)
        if rg: _path(c, rg); sa(c, colr, a); c.fill()
    _rp(c, [mv.P(x, y) for x, y in GOLAN.exterior.coords]); sa(c, land, a); c.fill()
    # forest canopy blobs (inside Israel only), clipped to Israel's land
    if g > 0.01:
        c.save()
        rg = mv.rings(G["IL"]["g"], 0.4); _path(c, rg); _rp(c, [mv.P(x, y) for x, y in GOLAN.exterior.coords]); c.clip()
        for i, (nm, lon, lat, wgt, y0_) in enumerate(FORESTS):
            px, py = mv.P(lon, lat); r = mv.k * 0.10 * wgt * min(1.0, g * 1.25) * (1 + 0.04 * math.sin(t * 2.3 + i))
            if r < 1: continue
            rgr = cairo.RadialGradient(px, py, 0, px, py, r)
            rgr.add_color_stop_rgba(0, GRN2[0], GRN2[1], GRN2[2], 0.95 * a); rgr.add_color_stop_rgba(0.6, GRN2[0], GRN2[1], GRN2[2], 0.55 * a)
            rgr.add_color_stop_rgba(1, GRN2[0], GRN2[1], GRN2[2], 0.0)
            c.set_source(rgr); c.arc(px, py, r, 0, 2 * math.pi); c.fill()
        c.restore()
    rg = mv.rings(G["IL"]["g"], 0.4)
    if rg: _path(c, rg); sa(c, (0.03, 0.06, 0.14), 0.7 * a); c.set_line_width(2.0); c.stroke()
    rg = mv.rings(G["PS"]["g"], 0.3)
    if rg:
        _path(c, rg); sa(c, WHITE, 0.85 * a); c.set_line_width(7); c.stroke()
        _path(c, rg); sa(c, GLINE, a); c.set_line_width(4.5); c.set_dash([12, 7]); c.stroke(); c.set_dash([])
    St.a = keep

def _cur(S, t):
    """current step index, interpolation u and greening g / km / year"""
    steps = S.get("steps") or [dict(year=S.get("year"), g=S.get("g", 0.0))]
    ts = [S["times"].get(f"s{i}", S["t0"] + 0.2 + 1.6 * i) for i in range(len(steps))]
    if S.get("hook"): ts = [min(x, 0.0) if i == 0 else x for i, x in enumerate(ts)]
    k = max([i for i, tt in enumerate(ts) if t >= tt - 0.05] or [0])
    u = 1.0 if (S.get("hook") and k == 0) else ease(min(1.0, max(0.0, (t - ts[k]) / 1.0)))
    prev = steps[k - 1] if k else steps[0]
    g = prev.get("g", 0) + (steps[k].get("g", 0) - prev.get("g", 0)) * u
    km = None
    if steps[k].get("km") is not None:
        k0 = prev.get("km", 0) or 0; km = k0 + (steps[k]["km"] - k0) * u
    yr = steps[k].get("year")
    if isinstance(yr, int) and isinstance(prev.get("year"), int) and k:
        yr = int(round(prev["year"] + (yr - prev["year"]) * u))
    return k, ts, g, km, yr, steps[k]

def sc_gmap(c, t, S):
    t0 = S["t0"]; hook = S.get("hook"); _stage_bg(c, t, S)
    box_ = tuple(S.get("box", (0, 540, W, 1460)))
    if "_mv" not in S: S["_mv"] = MapView(S.get("view", VIEW), box_)
    mv = S["_mv"]; x0, y0, x1, y1 = box_
    a0 = 1.0 if hook else RD.fade_in(t, t0, S, 0.3)
    k, ts, g, km, yr, st = _cur(S, t)
    c.save(); c.rectangle(x0, y0, x1 - x0, y1 - y0); c.clip()
    u = min(1.0, max(0.0, (t - t0) / max(1.0, ((S["t1"] or t0 + 4) - t0))))
    z = lerp(S.get("z0", 1.0), S.get("zoom", 1.06), ease(u)) if not hook else 1.0 + 0.03 * (0.5 - 0.5 * math.cos(t * 1.6))
    fx, fy = S.get("focus", [540, (y0 + y1) / 2])
    c.translate(fx, fy); c.scale(z, z); c.translate(-fx, -fy)
    _draw_map(c, mv, g, t, a0)
    pins = []
    for i, p in enumerate(S.get("pins", [])):
        tk = S["times"].get(f"p{i}", t0 + 0.5 + 0.8 * i); hk = hook and tk <= RD.HOOK_GRACE
        uu = 1.0 if hk else ramp(t, tk - 0.05, tk + 0.25)
        if uu <= 0.01: continue
        px, py = mv.P(p["lon"], p["lat"]); pr = 0 if hk else max(0.0, 1 - (t - tk) / 0.9)
        if pr > 0: circ(c, px, py, 20 + 80 * (1 - pr), YEL, 0.6 * pr * uu)
        circ(c, px, py, 20 * uu, WHITE, uu); circ(c, px, py, 13 * uu, YEL, uu)
        pins.append((i, p, tk, fx + (px - fx) * z, fy + (py - fy) * z))
    c.restore()
    for ya, yb, up in ((y0, y0 + 80, True), (y1 - 80, y1, False)):
        gg = cairo.LinearGradient(0, ya, 0, yb)
        gg.add_color_stop_rgba(0, 0.03, 0.06, 0.14, 1.0 if up else 0.0); gg.add_color_stop_rgba(1, 0.03, 0.06, 0.14, 0.0 if up else 1.0)
        c.rectangle(0, ya, W, yb - ya); c.set_source(gg); c.fill()
    for i, p, tk, px, py in pins:
        a2, s2 = (1.0, 1.0) if (hook and tk <= RD.HOOK_GRACE) else PP(t, tk + 0.08, S)
        if a2 <= 0.01: continue
        dx = 1 if p.get("side", "r") == "r" else -1; lx = min(max(px + dx * 250, 250), 830); ly = py + p.get("dy", 0)
        sa(c, WHITE, 0.85 * a2); c.set_line_width(4); c.move_to(px, py); c.line_to(lx - dx * 120, ly); c.stroke()
        pill(c, p["en"], 56, lx, ly, INK, WHITE, a2, s2, outline=YEL, w=900, padh=1.35)
    # year label and counter (right/left of the land, big)
    if yr is not None and S.get("show_year", True):
        ay = 1.0 if hook else RD.fade_in(t, t0 + 0.05, S)
        _wtext(c, str(yr), S.get("ysize", 170), S.get("year_y", 1290), color=YEL, a=ay, max_lines=1)
    if km is not None:
        ak = 1.0 if hook else RD.fade_in(t, ts[0], S)
        s_ = f"{km:,.0f} km²" + ("+" if st.get("plus") and k == len(S["steps"]) - 1 and km >= st["km"] - 0.5 else "")
        _wtext(c, s_, 120, S.get("km_y", 640), color=WHITE, a=ak, max_lines=1)
        kit.tx(c, S.get("km_label", "of forest"), 52, 540, S.get("km_y", 640) + 88, w=800, col=RD.c255(GRN2), a=ak, shadow=True, maxw=1000)
    if S.get("en"):
        a1, s1 = (1.0, 1.0) if hook else PP(t, t0 + 0.05, S)
        br = 1.0 + 0.012 * math.sin(t * 2.2) if hook else 1.0
        _wtext(c, S["en"], S.get("size", 120), S.get("en_y", 440), a=a1, sc=s1 * br, max_lines=S.get("max_lines", 2))
    if S.get("en2"):
        tk = S["times"].get("e2", t0 + 1.0); a2, s2 = PP(t, tk, S)
        _wtext(c, S["en2"], S.get("size2", 76), S.get("en2_y", 1270), a=a2, sc=s2, max_lines=2)
    la = 1.0 if hook else RD.fade_in(t, t0 + 0.4, S)
    if S.get("note"): _label(c, S["note"], 1352, la)
    if S.get("source"): _label(c, S["source"], 1418, la)


# ------------------------------------------------------------------ satellite panel (NASA ISS photo of the border)
def sc_sat(c, t, S):
    """full photo in a large rounded panel over a blurred copy, slow Ken Burns, a pulsing line along the border and two
    side labels. Fields: src, line_y (border, fraction of image height), labels [{en, fy, at}], title, credit, source."""
    t0 = S["t0"]; t1 = S["t1"] if S["t1"] is not None else t0 + 4.0; a = St.a
    u = _ease3((t - t0) / max(1.0, t1 + 0.25 - t0)); z = 1.0 + 0.10 * u
    bg = _cover(S["src"], W, H, 0.3, 0.5, blur=28); c.set_source_surface(bg, 0, 0); c.paint_with_alpha(a)
    sa(c, INK, 0.62); c.rectangle(0, 0, W, H); c.fill()
    im = Image.open(S["src"]); ar = im.width / im.height
    ph = S.get("panel_h", 900); pw = 1060; py = S.get("panel_y", 900) - ph / 2; px = 10
    fx, fy = S.get("focus", [0.3, 0.48])
    sa(c, (0, 0, 0), 0.35); rr(c, px + 4, py + 18, pw, ph, 36); c.fill()
    c.save(); rr(c, px, py, pw, ph, 36); c.clip()
    fg = _cover(S["src"], pw, ph, fx, fy); cx, cy = px + pw * 0.3, py + ph * 0.5
    c.translate(cx, cy); c.scale(z, z); c.translate(-cx, -cy)
    c.set_source_surface(fg, px, py); c.paint_with_alpha(a)
    # border line: image row line_y mapped through the cover crop
    sh = im.height; sw = im.width; sc_ = max(pw / sw, ph / sh); oy = (sh * sc_ - ph) * fy
    ly = py + S.get("line_y", 0.478) * sh * sc_ - oy
    tl = S["times"].get("line", t0 + 0.8); ul = ease(min(1.0, max(0.0, (t - tl) / 0.8)))
    if ul > 0:
        c.set_dash([18, 12], -(t * 60) % 30); sa(c, YEL, 0.9 * ul * (0.75 + 0.25 * math.sin(t * 5))); c.set_line_width(6 / z)
        c.move_to(px, ly); c.line_to(px + pw * ul, ly); c.stroke(); c.set_dash([])
    c.restore()
    sa(c, WHITE, 0.55); c.set_line_width(3); rr(c, px, py, pw, ph, 36); c.stroke()
    lyz = cy + (ly - cy) * z
    for i, L in enumerate(S.get("labels", [])):
        tk = S["times"].get(f"l{i}", t0 + 1.0 + 0.6 * i); a2, s2 = PP(t, tk, S)
        if a2 > 0.01: pill(c, L["en"], 56, L.get("x", 300), lyz + L["dy"], INK, WHITE, a2, s2, outline=col(L.get("color"), "gold") if L.get("color") else YEL, w=900, padh=1.35)
    y = TOP
    if S.get("title"):
        a1, s1 = PP(t, t0 + 0.05, S); h1 = _wtext(c, S["title"], 100, 0, max_lines=2, a=0) or 0
        _wtext(c, S["title"], 100, y + h1 / 2, a=a1, sc=s1, max_lines=2)
    la = RD.fade_in(t, t0 + 0.4, S)
    if S.get("source"): _label(c, S["source"], 1352 if S.get("credit") else 1418, la)
    if S.get("credit"): _label(c, S["credit"], 1418, la)
