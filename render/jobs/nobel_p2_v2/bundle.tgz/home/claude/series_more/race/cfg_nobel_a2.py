# nobel_p2 phase A: Israel's Nobel laureates 1966 to 2025, by field (race engine look of nobel_race_v6 / cfg_nobel2.py)
import csv
OUT="/home/claude/series_more/race/nobel_a2_silent.mp4"; ROWS=6; MIN=1; FLOOR=8
T_EN="0.2% of the world."; T_HE="0.2% מהעולם."; T_FS=46
SUB="Israel's Nobel prizes  |  פרסי הנובל של ישראל"
PART=None
def step(evts):
    pts=[(1960,0)]; c=0
    for y,k in evts: pts.append((y-0.02,c)); c+=k; pts.append((y,c))
    pts.append((2026,c)); return pts
G={"Chemistry":("כימיה","#10b981",step([(2004,2),(2009,1),(2011,1),(2013,2)])),
 "Economics":("כלכלה","#3b82f6",step([(2002,1),(2005,1),(2021,1),(2025,1)])),
 "Peace":("שלום","#facc15",step([(1978,1),(1994,2)])),
 "Literature":("ספרות","#a855f7",step([(1966,1)]))}
EVENTS=[(1960,"Israel: founded 1948. First Nobel?","ישראל: קמה ב-1948. הנובל הראשון?"),
 (1966,"S.Y. Agnon, Literature","ש\"י עגנון, ספרות"),
 (1978,"Menachem Begin, Peace (with Sadat)","מנחם בגין, שלום (עם סאדאת)"),
 (1994,"Rabin and Peres, Peace (with Arafat)","רבין ופרס, שלום (עם ערפאת)"),
 (2002,"Daniel Kahneman, Economics","דניאל כהנמן, כלכלה"),
 (2004,"Ciechanover and Hershko, Chemistry","צ'חנובר והרשקו, כימיה"),
 (2005,"Robert Aumann, Economics","ישראל (רוברט) אומן, כלכלה"),
 (2009,"Ada Yonath, Chemistry","עדה יונת, כימיה"),
 (2011,"Dan Shechtman, Chemistry","דן שכטמן, כימיה"),
 (2013,"Levitt and Warshel, Chemistry","לויט ווורשל, כימיה"),
 (2021,"Joshua Angrist, Economics","יהושע אנגריסט, כלכלה"),
 (2025,"Joel Mokyr, Economics: 14 laureates","יואל מוקיר, כלכלה: 14 זוכים")]
TL=[(1960,0),(1966,1.6),(1978,3.8),(1994,6.0),(2002,8.0),(2004,9.6),(2005,11.0),(2009,12.6),(2011,14.0),(2013,15.6),(2021,17.4),(2025,19.2)]
HOLD=2.6
COUNTER=("Israeli laureates","זוכים ישראלים",step([(1966,1),(1978,1),(1994,2),(2002,1),(2004,2),(2005,1),(2009,1),(2011,1),(2013,2),(2021,1),(2025,1)]))
COUNTER_FMT=lambda v: f"{int(round(v))}"
DISC=["Israeli laureates (incl. dual citizens): Wikipedia list, prizes as on nobelprize.org.",
      "Share of humanity: World Bank population. Share of laureates: nobelprize.org totals.",
      "זוכים ישראלים: ויקיפדיה ו-nobelprize.org. אוכלוסייה: הבנק העולמי."]
DISC_FS=17; DISC_LH=0.0125; DISC_COL="#8ea3c6"; EV_FS=27
BAR_AX=[0.05,0.33,0.56,0.50]; XMAXF=2.3
_P={}
for r in csv.DictReader(open("/home/claude/series_more/data/wb_population.csv")):
    if r["Country Code"] in ("ISR","WLD"): _P.setdefault(r["Country Code"],{})[int(r["Year"])]=float(r["Value"])
_sh=[(y,_P["ISR"][y]/_P["WLD"][y]) for y in range(1960,2025)]+[(2026,_P["ISR"][2024]/_P["WLD"][2024])]
DONUTS=[("Israel: share of humanity","ישראל מכלל האנושות",_sh,"#3b82f6"),
        ("Israel: share of laureates","ישראל מכלל זוכי הנובל",[(2023,13/965),(2025,14/990),(2026,14/990)],"#3b82f6",2022.9)]
HOOK=("Israel is 0.1% of the world.","It has 14 Nobel laureates.","ישראל היא 0.1% מהעולם.","ויש לה 14 זוכי נובל.","#60a5fa")
HOOK_DUR=1.3
