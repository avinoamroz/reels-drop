#!/bin/bash
# nobel_p2_v2: no Part badge, no Comment CTA; ends on the hook question inside the to-be-fair card (no separate end card)
set -e
cd /home/claude/series_more/race
python3 engine_p2.py cfg_nobel_a2.py > render_a2.log 2>&1 &
python3 engine_p2.py cfg_nobel_b2.py > render_b2.log 2>&1
wait
ffmpeg -y -v error -i nobel_a2_silent.mp4 -i nobel_b2_silent.mp4 -i nobel_mix_v2.m4a -filter_complex "[0:v][1:v]concat=n=2:v=1:a=0[v]" -map "[v]" -map 2:a -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -c:a copy -shortest -movflags +faststart nobel_p2_v2.mp4
