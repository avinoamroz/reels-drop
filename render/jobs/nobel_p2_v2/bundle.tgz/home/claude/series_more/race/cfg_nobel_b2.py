# nobel_p2 phase B: laureates per 10 million people, countries with 10+ laureates (1901 to 2025), bars grow together
import csv
OUT="/home/claude/series_more/race/nobel_b2_silent.mp4"; ROWS=12; MIN=0.05; FLOOR=1
T_EN="Nobel laureates per 10M people"; T_HE="זוכי נובל לכל 10 מיליון תושבים"; T_FS=46
SUB="All 22 countries with 10+ laureates, 1901 to 2025  |  כל 22 המדינות עם 10 זוכים ומעלה"
PART=None
DEC=True; NO_YEAR=True
L={"Sweden":("שוודיה","SWE",34,"se"),"Switzerland":("שווייץ","CHE",27,"ch"),"Austria":("אוסטריה","AUT",25,"at"),"Norway":("נורווגיה","NOR",14,"no"),
 "Denmark":("דנמרק","DNK",14,"dk"),"United Kingdom":("בריטניה","GBR",144,"gb"),"Ireland":("אירלנד","IRL",11,"ie"),"Hungary":("הונגריה","HUN",16,"hu"),
 "Israel":("ישראל","ISR",14,"il"),"Germany":("גרמניה","DEU",116,"de"),"United States":("ארה\"ב","USA",425,"us"),"Netherlands":("הולנד","NLD",22,"nl"),
 "France":("צרפת","FRA",78,"fr"),"Belgium":("בלגיה","BEL",11,None),"Canada":("קנדה","CAN",29,"ca"),"Australia":("אוסטרליה","AUS",15,"au"),
 "Poland":("פולין","POL",18,"pl"),"Italy":("איטליה","ITA",21,"it"),"Japan":("יפן","JPN",33,"jp"),"Russia":("רוסיה","RUS",30,"ru"),
 "South Africa":("דרום אפריקה","ZAF",11,"za"),"India":("הודו","IND",13,"in")}
_P={}
for r in csv.DictReader(open("/home/claude/series_more/data/wb_population.csv")):
    if r["Year"]=="2024": _P[r["Country Code"]]=float(r["Value"])
PC={n:k/_P[c]*1e7 for n,(h,c,k,f) in L.items()}
COLS=["#64748b","#6b7280","#71717a","#78716c","#737373","#64748b","#6b7280","#71717a"]
G={}
for i,(n,(h,c,k,f)) in enumerate(L.items()):
    v=PC[n]; G[n]=(h,"#3b82f6" if n=="Israel" else COLS[i%len(COLS)],[(0,0),(100,v),(200,v)])
FLAGS={n:f for n,(h,c,k,f) in L.items() if f}
EVENTS=[(0,"Per person, who wins the most?","לפי גודל האוכלוסייה, מי זוכה הכי הרבה?"),
 (70,"Israel: 14.0 per 10M people, 9th of 22","ישראל: 14.0 לכל 10 מיליון, מקום 9 מתוך 22"),
 (100,"Ahead of Germany, the US and the Netherlands","לפני גרמניה, ארה\"ב והולנד")]
TL=[(0,0),(70,8.5),(100,12.5)]
HOLD=7.1
COUNTER=("Israel, per 10M people","ישראל, לכל 10 מיליון",[(0,0),(100,PC["Israel"]),(200,PC["Israel"])])
COUNTER_FMT=lambda v: f"{v:.1f}"
DISC=["Laureates 1901 to 2025: Wikipedia, Nobel laureates by country (per nobelprize.org).",
      "Population: World Bank 2024. One laureate can count for 2 countries.",
      "זוכים: ויקיפדיה לפי nobelprize.org. אוכלוסייה: הבנק העולמי 2024."]
DISC_FS=16; DISC_LH=0.0125; DISC_COL="#8ea3c6"; EV_FS=27
BAR_AX=[0.05,0.33,0.90,0.50]; XMAXF=1.45
ENDCARDS=[(13.4,999,[(0.668,"To be fair:","white",34),(0.630,"Sweden, Switzerland and Austria lead.","white",30),
                      (0.594,"Their count starts in 1901.","#ffd166",28),(0.561,"Israel's starts in 1966.","#ffd166",28),
                      (0.516,"ולמען ההגינות: שוודיה, שווייץ ואוסטריה מובילות.","white",25),(0.483,"הספירה שלהן מתחילה ב-1901, של ישראל ב-1966.","#ffd166",25),
                      (0.425,"0.1% of the world. 14 Nobels. How?","#60a5fa",38),(0.378,"0.1% מהעולם, 14 פרסי נובל. איך?","white",32)])]
HOOK=None
