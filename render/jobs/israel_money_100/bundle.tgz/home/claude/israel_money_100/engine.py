"""israel_money_100: how Israel's money system was built, 1902 to today. Split screen: LEFT a growing timeline of
institutions (year, name), RIGHT the whole land of Israel (Israel gold, West Bank and Gaza darker gold, Green Line green)
where each institution lights up as a pin at its city. Top band: hook, then a year counter, then an inflation counter
(445% in 1984 to 19.7% in 1986), then today's reserves. Twist: US aid vs reserves (62x). Circular: the last line
"...a story that began with" lands back on the frame 0 hook "1903: one small bank."
python3 engine.py [--frames t1,t2,...] [--out path.mp4]"""
import os, sys, math, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

D = os.path.dirname(os.path.abspath(__file__)); ARGS = sys.argv[1:]
TM = Timing(D); wt, lt, CUT, END = TM.wt, TM.lt, TM.CUT, TM.END
NL = TM.n

# ------------------------------------------------------------------ the timeline
#   year, name, line, word it lands on, colour, city
ENT = [
    ("1902", "Anglo-Palestine Company", 2, ("Anglo", 0), GOLD, "jaffa"),
    ("1909", "Tel Aviv's first homes", 3, ("first", 0), GOLD, "tlv"),
    ("1921", "Bank Hapoalim", 4, ("Bank", 0), GOLD, "tlv"),
    ("1923", "Mizrahi Bank", 4, ("Mizrahi", 0), GOLD, "tlv"),
    ("1948", "Israel's banknotes", 5, ("banknotes", 0), GOLD, "all"),
    ("1953", "Tel Aviv Stock Exchange", 6, ("Tel", 0), GOLD, "tlv"),
    ("1954", "Bank of Israel", 6, ("1954", 0), GOLD, "jlm"),
    ("1983", "Bank shares crash", 8, ("Bank", 0), RED, "tlv"),
    ("1984", "445% inflation", 9, ("Prices", 0), RED, None),
    ("1985", "Emergency plan", 10, ("emergency", 0), GREENB, "jlm"),
    ("1985", "New shekel", 10, ("new", 0), GREENB, "jlm"),
]
TA = [wt(e[2], e[3][0], e[3][1]) - 0.08 for e in ENT]
T_TODAY = CUT[12]; T_AID = CUT[14]; T_LOOP = CUT[16]

# ------------------------------------------------------------------ map (right panel)
GIL = json.load(open(f"{D}/geo_il.json")); GNB = json.load(open(f"{D}/geo_nb.json"))
PX, PY, PW, PH = 556, 616, 488, 888
MK = 215.0; COSF = math.cos(math.radians(31.5)); MCX, MCY, MLON, MLAT = PX + PW / 2 + 6, PY + PH / 2, 35.0, 31.45
def P(lon, lat): return MCX + (lon - MLON) * COSF * MK, MCY - (lat - MLAT) * MK
CITY = {"jaffa": (34.752, 32.054, "Jaffa", -1, 46), "tlv": (34.80, 32.09, "Tel Aviv", -1, -30), "jlm": (35.215, 31.778, "Jerusalem", 1, 50)}
def map_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    rr(c, PX, PY, PW, PH, 36); c.set_source_rgba(*hx("#0E2348")[:3], 1); c.fill_preserve(); c.save(); c.clip()
    for nm, rings in GNB.items():
        poly(c, rings, P)
    c.set_source_rgba(*hx("#1C3566")[:3], 1); c.fill_preserve(); c.set_source_rgba(*SKY[:3], 0.25); c.set_line_width(1.4); c.stroke()
    poly(c, GIL["isr"], P); c.set_source_rgba(*GOLD_IL[:3], 1); c.fill()
    poly(c, GIL["pal"], P); c.set_source_rgba(*GOLD_PA[:3], 1); c.fill()
    for key in ("lakes",):
        if GIL.get(key):
            poly(c, GIL[key], P); c.set_source_rgba(*hx("#0E2348")[:3], 1); c.fill()
    c.set_source_rgba(*GREEN[:3], 1); c.set_line_width(3.2)
    for ln in GIL["green"]:
        for i, (lo, la) in enumerate(ln):
            x, y = P(lo, la); (c.move_to if i == 0 else c.line_to)(x, y)
        c.stroke()
    c.restore()
    rr(c, PX, PY, PW, PH, 36); c.set_source_rgba(*SKY[:3], 0.35); c.set_line_width(2); c.stroke()
    text(c, "Green Line", 36, PX + PW - 24, PY + PH - 28, 700, GREEN, 1, "r")
    s.flush(); return s
MAP = map_surface()
def land_path(c):
    poly(c, GIL["isr"], P); poly(c, GIL["pal"], P)

def city_state(t):
    """per city: list of entry indexes that have landed"""
    st = {k: [] for k in CITY}
    for k, e in enumerate(ENT):
        if e[5] in CITY and t >= TA[k]: st[e[5]].append(k)
    return st
def draw_map(c, t, a):
    if a <= 0.01: return
    c.set_source_surface(MAP, 0, 0); c.paint_with_alpha(a)
    i = TM.scene(t)
    c.save(); rr(c, PX, PY, PW, PH, 36); c.clip()
    # 1948: the whole land lights up; crisis: red wash; today: gold glow
    u48 = ramp(t, TA[4], TA[4] + 0.3) * (1 - ramp(t, TA[4] + 1.2, TA[4] + 2.2))
    if u48 > 0.01: land_path(c); c.set_source_rgba(1, 1, 1, 0.35 * u48 * a); c.fill()
    ur = ramp(t, CUT[7], CUT[7] + 0.6) * (1 - ramp(t, CUT[11], CUT[11] + 0.8))
    if ur > 0.01:
        land_path(c); c.set_source_rgba(*RED[:3], (0.45 + 0.12 * math.sin(t * 5)) * ur * a); c.fill()
    ug = ramp(t, CUT[11] + 0.3, CUT[12] + 0.6) * (1 - ramp(t, T_LOOP, T_LOOP + 0.6))
    if ug > 0.01:
        land_path(c); c.set_source_rgba(1, 0.92, 0.6, (0.22 + 0.08 * math.sin(t * 3)) * ug * a); c.fill()
    c.restore()
    loop = ramp(t, T_LOOP + 0.2, T_LOOP + 0.8)
    st = city_state(t)
    for key, (lo, la, name, side, dy) in CITY.items():
        x, y = P(lo, la)
        if key == "jaffa": x -= 8; y += 6
        if key == "tlv": x += 6; y -= 4
        ks = st[key]
        show = (key == "jaffa" and (i == 0 or t < CUT[1] + 0.2)) or len(ks) > 0
        if t >= T_LOOP: show = key == "jaffa" or (len(ks) > 0 and loop < 1)
        if not show: continue
        pa = a * (1.0 if key == "jaffa" and t < TA[0] else ramp(t, TA[ks[0]] if ks else 0, (TA[ks[0]] if ks else 0) + 0.3))
        if t >= T_LOOP and key != "jaffa": pa *= 1 - loop
        last = TA[ks[-1]] if ks else -9
        pop = eob(clamp((t - (TA[ks[0]] if ks else 0)) / 0.4)) if ks else 1.0
        if 0 < t - last < 0.6: pop *= 1 + 0.18 * math.sin(math.pi * (t - last) / 0.6)
        col = GOLD
        if ks and ENT[ks[-1]][4] is RED and t < CUT[11]: col = RED
        if ks and ENT[ks[-1]][4] is GREENB: col = GREENB
        if key == "jaffa" and (i == 0 or t >= T_LOOP):            # hook: breathing pulse on the first bank
            ph = (t * 0.9) % 1.0
            c.set_source_rgba(*GOLD[:3], pa * (1 - ph)); c.set_line_width(4); c.arc(x, y, 12 + 50 * ph, 0, 6.283); c.stroke()
        for kk in ks:
            dt = t - TA[kk]
            if 0 < dt < 0.9:
                c.set_source_rgba(*col[:3], pa * (1 - dt / 0.9)); c.set_line_width(4); c.arc(x, y, 10 + 70 * dt, 0, 6.283); c.stroke()
        pin(c, x, y, col, pa, 1.25 * pop)
        lw = font(40, 800).getlength(name)
        lx = x - 34 - lw if side < 0 else x + 30
        ly = y + dy
        lx = max(PX + 16, min(PX + PW - 16 - lw, lx))
        rr(c, lx - 12, ly - 38, lw + 24, 52, 14); c.set_source_rgba(*NIGHT[:3], 0.78 * pa); c.fill()
        text(c, name, 40, lx, ly, 800, WHITE, pa, "l")
        n = len([k for k in ks if t >= TA[k]])
        if key == "tlv" and n >= 2 and t < T_LOOP:
            bx, by = x + 28, y - 70
            c.arc(bx, by, 26, 0, 6.283); c.set_source_rgba(*GOLD[:3], pa); c.fill()
            text(c, f"{n}", 38, bx, by + 13, 900, NIGHT, pa)

# ------------------------------------------------------------------ left: timeline list
LX, LW, LY0, LY1 = 64, 460, 640, 1490
def ent_lines(k): return wrap(ENT[k][1], 52, LW)
def ent_h(k): return 62 + 58 * len(ent_lines(k)) + 26
def draw_list(c, t, a):
    if a <= 0.01: return
    on = [k for k in range(len(ENT)) if t >= TA[k] - 0.05]
    if not on: return
    hs = [ent_h(k) for k in on]
    # scroll so the newest entry ends above LY1 (eased toward each new target)
    def target(m):
        tot = sum(ent_h(k) for k in range(m + 1)); return max(0, tot - (LY1 - LY0))
    m = on[-1]; prev = target(m - 1) if m > 0 else 0; cur = target(m)
    off = lerp(prev, cur, eout((t - TA[m]) / 0.45))
    y = LY0 - off
    c.save(); c.rectangle(0, LY0 - 70, 548, LY1 - LY0 + 80); c.clip()
    for k, h in zip(on, hs):
        u = eout((t - TA[k]) / 0.4); dx = (1 - u) * -40
        fade = clamp((y + h - (LY0 - 40)) / 120)
        aa = a * u * fade
        yr, name, li, _, col, _ = ENT[k]
        newest = k == on[-1] and t < TA[k] + 2.5
        rr(c, LX - 16 + dx, y, LW + 32, h - 20, 22)
        c.set_source_rgba(1, 1, 1, (0.10 if newest else 0.05) * aa); c.fill()
        c.rectangle(LX - 16 + dx, y + 14, 7, h - 48); c.set_source_rgba(*col[:3], aa); c.fill()
        text(c, yr, 56, LX + 8 + dx, y + 60, 900, col, aa, "l")
        for n, ln in enumerate(ent_lines(k)):
            text(c, ln, 52, LX + 8 + dx, y + 60 + 58 * (n + 1), 800, WHITE, aa, "l")
        y += h
    c.restore()

# ------------------------------------------------------------------ top band
def fmtb(v): return f"${v:,.0f}B" if v >= 10 else f"${v:.1f}B"
def year_at(t):
    on = [k for k in range(len(ENT)) if t >= TA[k]]
    if not on: return 1903
    k = on[-1]; y1 = int(ENT[k][0]); y0 = int(ENT[on[-2]][0]) if len(on) > 1 else 1903
    return int(round(lerp(y0, y1, eout((t - TA[k]) / 0.5))))
def draw_hook(c, t, a):
    text(c, "1903:", 176, 540, 430, 900, GOLD, a)
    text(c, "one small bank.", 118, 540, 560, 900, WHITE, a)
    u = eout(t / 1.2) if t < 2 else 1.0
    w_ = font(118, 900).getlength("one small bank.")
    c.set_source_rgba(*GOLD[:3], 0.9 * a); rr(c, 540 - w_ / 2, 588, w_ * u, 10, 5); c.fill()
def draw_today_q(c, t, a):
    """left column on the hook: Today?"""
    if a <= 0.01: return
    br = 1 + 0.04 * math.sin(t * 3.2)
    text(c, "Today", 104, 290, 860, 900, WHITE, a)
    text(c, "?", 380, 290, 1260, 900, GOLD, a, sc=br)
def draw_top(c, t):
    i = TM.scene(t)
    if i == 0:
        draw_hook(c, t, 1.0); return
    if i >= 16:
        a = ramp(t, END - 1.3, END - 0.9)
        draw_hook(c, t, a)
        b = ramp(t, CUT[16], CUT[16] + 0.3) * (1 - a)
        text(c, "Not bad, for a story", 84, 540, 430, 900, WHITE, b)
        text(c, "that began with...", 84, 540, 540, 900, WHITE, b)
        return
    if 1 <= i <= 8:
        a = ramp(t, CUT[1], CUT[1] + 0.3)
        col = RED if i >= 7 else GOLD
        text(c, str(year_at(t)), 180, 540, 450, 900, col, a)
        lab = "Watch it grow" if i <= 6 else "Then, it all goes wrong"
        text(c, lab, 60, 540, 545, 800, WHITE if i <= 6 else RED, a)
        return
    if 9 <= i <= 11:
        a = ramp(t, CUT[9], CUT[9] + 0.25)
        t0 = wt(9, "four") - 0.1; t1 = wt(11, "down") - 0.1
        if t < t1:
            v = 445 * eout((t - t0) / 1.4) if t > t0 else 0; s = f"{v:.0f}%"; col = RED
        else:
            v = lerp(445, 19.7, eout((t - t1) / 1.3)); s = f"{v:.1f}%" if v < 100 else f"{v:.0f}%"; col = GREENB if v < 60 else RED
        text(c, s, 190, 540, 455, 900, col, a)
        text(c, "inflation in one year", 60, 540, 545, 800, WHITE, a)
        return
    if 12 <= i <= 15:
        a = ramp(t, CUT[12], CUT[12] + 0.3)
        text(c, "Today", 170, 540, 450, 900, GOLD, a)
        text(c, "Israel, 2026", 60, 540, 545, 800, WHITE, a)

def draw_today(c, t):
    """left column, lines 12 to 13: reserves and the shekel"""
    a = ramp(t, CUT[12] + 0.1, CUT[12] + 0.4) * (1 - ramp(t, T_AID - 0.2, T_AID + 0.2))
    if a <= 0.01: return
    t0 = wt(12, "Two") - 0.1; v = 237 * eout((t - t0) / 1.6) if t > t0 else 0
    rr(c, LX - 16, LY0, LW + 32, 840, 30); c.set_source_rgba(1, 1, 1, 0.06 * a); c.fill()
    text(c, "Reserves", 64, 290, LY0 + 100, 800, WHITE, a)
    text(c, f"${v:.0f}B", fit("$237B", 150, 440, 900), 290, LY0 + 270, 900, GOLD, a)
    text(c, "Bank of Israel, Sept 2026", 40, 290, LY0 + 340, 700, MUTE, a)
    s0 = CUT[13] + 0.1; b = ramp(t, s0, s0 + 0.35)
    if b > 0.01:
        dy = (1 - eout((t - s0) / 0.4)) * 30
        text(c, "Strongest shekel", 60, 290, LY0 + 500 + dy, 900, SKY, a * b)
        text(c, "in 30 years", 60, 290, LY0 + 570 + dy, 900, SKY, a * b)
        text(c, "vs the dollar, Apr 2026", 40, 290, LY0 + 640 + dy, 700, MUTE, a * b)

def draw_aid(c, t):
    """lines 14 to 15: full-width card, $3.8B a year vs $237B"""
    a = ramp(t, T_AID, T_AID + 0.35) * (1 - ramp(t, T_LOOP - 0.1, T_LOOP + 0.3))
    if a <= 0.01: return
    rr(c, 56, LY0 - 20, 968, 880, 36); c.set_source_rgba(*NIGHT[:3], 0.94 * a); c.fill()
    rr(c, 56, LY0 - 20, 968, 880, 36); c.set_source_rgba(*SKY[:3], 0.4 * a); c.set_line_width(2); c.stroke()
    text(c, "They say Israel", 72, 540, LY0 + 80, 900, WHITE, a)
    text(c, "lives on US aid", 72, 540, LY0 + 160, 900, WHITE, a)
    bx, bw = 100, 880
    u1 = eout((t - wt(14, "Three")) / 0.6)
    text(c, "US military aid: $3.8B a year", fit("US military aid: $3.8B a year", 56, 880), bx, LY0 + 290, 800, WHITE, a * u1, "l")
    rr(c, bx, LY0 + 315, max(16, bw * 3.8 / 237) * u1 + 0.1, 56, 12); c.set_source_rgba(*GOLD[:3], a * u1); c.fill()
    u2 = eout((t - (wt(14, "Three") + 0.9)) / 1.0)
    text(c, "Reserves: $237B", 56, bx, LY0 + 450, 800, WHITE, a * clamp(u2 * 3), "l")
    rr(c, bx, LY0 + 475, bw * u2 + 0.1, 56, 12); c.set_source_rgba(*SKY[:3], a * clamp(u2 * 3)); c.fill()
    s1 = wt(15, "SIXTY") - 0.15; b = ramp(t, s1, s1 + 0.2)
    text(c, "62x", 230, 540, LY0 + 760, 900, GOLD, a * b, sc=max(0.01, eob(clamp((t - s1) / 0.45))))
    text(c, "MOU 2016: $38B over FY2019 to 2028. BoI, Sept 2026", fit("MOU 2016: $38B over FY2019 to 2028. BoI, Sept 2026", 38, 900, 700), 540, LY0 + 830, 700, MUTE, a)

SRC = {2: "Bank Leumi history. Jewish Colonial Trust, London, 1899", 3: "Loans to Ahuzat Bayit, Tel Aviv, 1909 (Bank Leumi)",
       4: "Histadrut, 1921. Mizrachi movement, 1923", 5: "Bank of Israel: Anglo-Palestine Bank series, 1948",
       6: "TASE, 1953. Bank of Israel Law, Aug 1954", 8: "Bank shares crisis: TASE shut 6 to 24 Oct 1983",
       9: "Israel CBS: consumer prices, 1984", 10: "Stabilization plan 1 Jul 1985. New shekel 4 Sep 1985",
       11: "Israel CBS: 1986 inflation 19.7%", 12: "Bank of Israel, forex reserves, end of Sept 2026", 13: "Globes, Apr 2026"}
def draw_source(c, t):
    i = TM.scene(t); s = SRC.get(i)
    if not s: return
    a = ramp(t, CUT[i] + 0.2, CUT[i] + 0.5) * (1 - ramp(t, CUT[i + 1] - 0.25, CUT[i + 1]))
    text(c, s, fit(s, 38, 960, 700, 36), 540, 1528, 700, MUTE, a)

REPL = [("four hundred and forty-five percent", "445%"), ("Two hundred and thirty-seven billion dollars", "$237 billion"),
        ("Three point eight billion", "$3.8 billion"), ("eighteen days", "18 days"), ("thirty years", "30 years"),
        ("twenty percent", "20%"), ("SIXTY", "60")]
SUBS = build_subs(TM, REPL)
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = TM.scene(t)
    ma = 1 - 0.75 * ramp(t, T_AID, T_AID + 0.35) * (1 - ramp(t, T_LOOP - 0.1, T_LOOP + 0.3))
    draw_map(c, t, ma)
    qa = 1.0 if i == 0 else (1 - ramp(t, CUT[1], CUT[1] + 0.3)) if i < 2 else ramp(t, END - 1.3, END - 0.9)
    draw_today_q(c, t, qa)
    la = ramp(t, TA[0] - 0.1, TA[0] + 0.2) * (1 - ramp(t, T_TODAY - 0.2, T_TODAY + 0.2))
    draw_list(c, t, la)
    draw_today(c, t); draw_aid(c, t)
    draw_top(c, t); draw_source(c, t)
    draw_subs(c, t, SUBS)
    return to_np(s)

if __name__ == "__main__":
    run(D, TM, frame, ARGS)

def SFX():
    ev = [(ta + 0.05, "pop", -2) for ta in TA]
    ev += [(CUT[i] - 0.1, "whoosh", -3) for i in (7, 12, 14)]
    ev += [(wt(9, "four") + 1.3, "ding", -2), (wt(15, "SIXTY") - 0.1, "ding", 0)]
    return ev
