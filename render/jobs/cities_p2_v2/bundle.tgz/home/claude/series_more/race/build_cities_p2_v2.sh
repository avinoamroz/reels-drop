#!/bin/bash
# cities_p2_v2: no Part title/badge, no Comment CTA; ends on the hook question inside the to-be-fair card
set -e; cd /home/claude/series_more/race
python3 engine_p2.py cfg_cities_p2_v2.py > render_cv2.log 2>&1
ffmpeg -y -v error -i cities_v2_silent.mp4 -i cities_mix_v2.m4a -map 0:v -map 1:a -c:v copy -c:a copy -shortest -movflags +faststart cities_p2_v2.mp4
