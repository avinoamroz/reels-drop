"""Drawing kit copied from /home/claude/fix5/em_pov.py (lib_express_method_v3): background, captions, stick figures, bubbles, laptop, tiles, phone, hands."""
import math, cairo, sys
sys.path.insert(0, "/home/claude/reelkit")
import render as RD, kit
from kit import sa, rr, ease, ramp, lerp
NAVY = kit.hx("#163261"); NAVY2 = kit.hx("#0E1E3A"); SKY = kit.hx("#45A4DD"); BLUE = kit.hx("#2A88D4"); ORANGE = kit.hx("#F28C28")
RED = kit.hx("#D63A4A"); YEL = kit.hx("#F5C518"); WHITE = kit.hx("#FFFFFF"); PALE = kit.hx("#C9D6EE"); DESK = kit.hx("#22324F")
SKIN = kit.hx("#F1D2B6"); SKIN2 = kit.hx("#D9B595")
W, H = 1080, 1920
def bg(c, t, warm=0.0):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *NAVY2[:3]); g.add_color_stop_rgb(1, *kit.mix(NAVY, (0.15, 0.29, 0.83, 1), 0.55)[:3])
    c.set_source(g); c.paint()
    gx = 540 + 220 * math.sin(t * 0.3); rg = cairo.RadialGradient(gx, 760, 40, gx, 760, 700)
    rg.add_color_stop_rgba(0, 0.35, 0.55, 0.9, 0.22 + warm); rg.add_color_stop_rgba(1, 0.35, 0.55, 0.9, 0); c.set_source(rg); c.paint()
def caption(c, t, en, he, t0, y=330, sz=84, col=WHITE, hl=SKY):
    a, s = kit.pop(t, t0, 0.4, 0.6, 1.6)
    if a <= 0.01: return
    h = RD.block_h(en, sz, 900, 960, 2)
    RD.block(c, en, sz, 540, y + h / 2, col, a, s, hl=hl, maxw=960, max_lines=2)
    if he: RD.T(c, he, 56, 540, y + h + 44, PALE, a * 0.95, 1, 700, maxw=960)
def stick_head(c, x, y, r, colr, a=1.0, talk=0.0, face=True):
    c.set_line_width(max(5, r * 0.14)); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.arc(x, y + r * 2.15, r * 1.55, math.pi * 1.08, math.pi * 1.92); c.set_source_rgba(*colr[:3], a); c.stroke()
    c.arc(x, y, r, 0, 2 * math.pi); c.set_source_rgba(*colr[:3], a); c.stroke()
    if face:
        for dx in (-0.35, 0.35): c.arc(x + dx * r, y - 0.12 * r, r * 0.08, 0, 2 * math.pi); c.fill()
        mo = 0.06 + 0.16 * talk
        c.save(); c.translate(x, y + 0.35 * r); c.scale(1, max(0.15, mo / 0.22)); c.arc(0, 0, r * 0.2, 0, math.pi); c.restore(); c.stroke()
def bubble(c, x, y, txt, colr, a, s=1.0, sz=40, tail="l", new=None, maxw=520):
    if a <= 0.01: return
    f = kit.font(sz, 800); tw = min(f.getlength(txt.replace("*", "")), maxw); pw, ph = tw + sz * 1.2, sz * 1.9
    c.save(); c.translate(x, y); c.scale(s, s)
    sa(c, (0, 0, 0, 1), 0.18 * a); rr(c, -pw / 2 + 4, -ph / 2 + 8, pw, ph, ph / 2.4); c.fill()
    sa(c, colr, a); rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2.4); c.fill()
    tx = -pw * 0.28 if tail == "l" else pw * 0.28
    c.move_to(tx - 18, ph / 2 - 2); c.line_to(tx + (-14 if tail == "l" else 14), ph / 2 + 24); c.line_to(tx + 18, ph / 2 - 2); c.close_path(); c.fill()
    c.restore()
    RD.T(c, txt, sz, x, y + 3 * s, WHITE, a, s, 800, hl=(new or kit.hx("#FF9C9C")), maxw=maxw)   # red = new words
def hands_keyboard(c, t, typing=0.0, a=1.0, y0=1200):
    # desk, keyboard, and the viewer's own two hands
    sa(c, DESK, a); c.rectangle(0, y0, W, H - y0); c.fill()
    sa(c, kit.hx("#31456A"), a); rr(c, 140, y0 + 40, 800, 230, 26); c.fill()
    for r_ in range(3):
        for k_ in range(10):
            sa(c, kit.hx("#4A5F86"), a); rr(c, 175 + k_ * 75, y0 + 62 + r_ * 66, 62, 50, 9); c.fill()
    for side in (-1, 1):
        bob = 10 * math.sin(t * 18 + side) * typing
        hx = 540 + side * 230; hy = y0 + 260 + bob
        sa(c, SKIN, a); c.save(); c.translate(hx, hy); c.rotate(side * 0.18)
        rr(c, -90, -60, 180, 170, 70); c.fill()
        for f_ in range(4):
            fx = -66 + f_ * 44; sa(c, SKIN, a); rr(c, fx - 17, -150 + (8 * math.sin(t * 20 + f_) * typing), 34, 120, 17); c.fill()
        sa(c, SKIN2, a); rr(c, -side * 92 - 18, -70, 36, 90, 18); c.fill()
        c.restore()
def laptop(c, t, screen, a=1.0, y0=600, y1=1160):
    x0, x1 = 80, 1000
    sa(c, kit.hx("#1B2A44"), a); rr(c, x0 - 18, y0 - 18, x1 - x0 + 36, y1 - y0 + 50, 30); c.fill()
    sa(c, kit.hx("#0B1628"), a); rr(c, x0, y0, x1 - x0, y1 - y0, 18); c.fill()
    c.save(); rr(c, x0, y0, x1 - x0, y1 - y0, 18); c.clip(); screen(c, t, x0, y0, x1, y1, a); c.restore()
def tile(c, x, y, w, h, colr, a, speaking=0.0, label=None, talk=0.0):
    sa(c, kit.hx("#1F3357"), a); rr(c, x, y, w, h, 16); c.fill()
    if speaking > 0.01: sa(c, BLUE, a * speaking); c.set_line_width(8); rr(c, x + 4, y + 4, w - 8, h - 8, 14); c.stroke()
    stick_head(c, x + w / 2, y + h * 0.42, min(w, h) * 0.17, colr, a, talk)
    if label: RD.T(c, label, 36, x + w / 2, y + h - 30, PALE, a, 1, 700, maxw=w - 20)
def phone(c, t, a, rec=0.0, y_off=0.0):
    x, y, w, h = 300, 600 + y_off, 480, 820
    sa(c, kit.hx("#0B1628"), a); rr(c, x, y, w, h, 64); c.fill(); sa(c, kit.hx("#1E3A63"), a); rr(c, x + 18, y + 18, w - 36, h - 36, 50); c.fill()
    RD.T(c, "Me, in English", 40, x + w / 2, y + 110, WHITE, a, 1, 800)
    RD.T(c, f"{int(rec * 7)}:{int((rec * 420) % 60):02d}", 64, x + w / 2, y + 200, YEL, a, 1, 900)
    for k_ in range(18):
        hh = 30 + 110 * abs(math.sin(t * 7 + k_ * 0.7)) * (0.4 + 0.6 * rec)
        sa(c, SKY, a); rr(c, x + 70 + k_ * 19, y + 430 - hh / 2, 11, hh, 5); c.fill()
    c.arc(x + w / 2, y + h - 140, 60, 0, 2 * math.pi); sa(c, RED, a); c.fill()
    # thumbs
    for side in (-1, 1):
        sa(c, SKIN, a); c.save(); c.translate(x + w / 2 + side * 250, y + h - 40); c.rotate(-side * 0.5); rr(c, -60, -170, 120, 260, 60); c.fill(); c.restore()
