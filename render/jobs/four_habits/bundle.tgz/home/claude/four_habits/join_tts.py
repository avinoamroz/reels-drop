import wave,json,numpy as np
SR=44100;pcm=[];W=[];off=0.0
for p in ("p1","p2","p3"):
    a=np.frombuffer(wave.open(f"tts/{p}.wav").readframes(10**9),dtype=np.int16)
    ws=json.load(open(f"tts/{p}_words.json"))
    end=min(len(a),int((ws[-1]["end"]+0.35)*SR)); a=a[:end]
    for w in ws: W.append(dict(word=w["word"],start=w["start"]+off,end=w["end"]+off))
    gap=np.zeros(int(0.25*SR) if p!="p3" else 0,np.int16)
    pcm+=[a,gap]; off+=(len(a)+len(gap))/SR
x=np.concatenate(pcm)
with wave.open("tts/fh.wav","wb") as w: w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(x.tobytes())
json.dump(W,open("tts/fh_words.json","w"),indent=0)
L=[l for l in open("tts/fh.txt").read().splitlines() if l.strip()]
print(len(x)/SR,"s",len(W),"words vs",sum(len(l.split()) for l in L))
