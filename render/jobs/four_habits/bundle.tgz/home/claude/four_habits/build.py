#!/usr/bin/env python3
"""four_habits/build.py [--preview t,t,..]: the SPEAKER payoff video for @expressenglishcom (Noam, 1 Nov 13:59).
Every Express SPEAKER reel promises "four habits you need to master"; this is that video.
Content = Noam's slide 'אהב"ת (ארבעת הוקטורים / ארבעת החסמים)' plus the Express Coaching Bible practice steps:
  vocabulary -> context, pronunciation -> right pronunciation (sound table), confidence -> think in English,
  speech patterns -> shadowing (YouTube). The four blocker initials spell אהב"ת ("love"): on-screen reveal only,
  the English voice never reads Hebrew (rule 4f).
Situational: each blocker is a meeting scene (stick figures: blue = speaker and active words, orange = passive /
listening, red = new or wrong), each habit a practice scene. English narration (Cartesia "Noam Roz - reels",
house chain), English subtitles burned in, Hebrew as one small bottom line. Circular: the lead-in
"So next time, you won't ask yourself..." cross-fades into frame 0 "Why do you freeze in English?"."""
import json, math, os, subprocess, sys
import numpy as np, cairo
sys.path.insert(0, "/home/claude/reelkit"); sys.path.insert(0, "/home/claude/four_habits")
import render as RD, kit, voice as V, mix as MX
from clean_vo import clean as clean_vo
from kit import sa, rr, ease, ramp, lerp
from PIL import Image
from fhkit import (bg, caption, stick_head, bubble, hands_keyboard, laptop, tile,
                   NAVY, NAVY2, SKY, BLUE, ORANGE, RED, YEL, WHITE, PALE, DESK, SKIN)
W, H, FPS, SR = 1080, 1920, 30, 48000
OUT = "/home/claude/four_habits/out/four_habits.mp4"
TTS = "/home/claude/four_habits/tts/fh"
MUSIC = "file:/home/claude/fixes_1101/em/music_em.wav"
# ---------------------------------------------------------------- voice + timing
V.TEMPO = 1.0
Wd = json.load(open(TTS + "_words.json"))
dry = V.chain_dry(TTS + ".wav"); cl = clean_vo(dry, V.SR)
y, _ = V.restore_soft(cl, dry, V._speech_spans_pre(dry)); vo = V.post(y)
kk = (len(vo) / SR - V.LEAD) / (len(dry) / SR)
for w in Wd: w["t0"] = V.LEAD + w["start"] * kk; w["t1"] = V.LEAD + w["end"] * kk
lines = [l for l in open("/home/claude/four_habits/tts/fh.txt").read().splitlines() if l.strip()]
k = 0; L = []
for i, l in enumerate(lines):
    n = len(l.split()); ws = Wd[k:k + n]; k += n; L.append(dict(i=i, t0=ws[0]["t0"], t1=ws[-1]["t1"], words=ws))
assert k == len(Wd)
def wt(i, word, n=0):
    hits = [w["t0"] for w in L[i]["words"] if w["word"].strip(".,?!:'").lower() == word.lower()]
    return hits[min(n, len(hits) - 1)] if hits else L[i]["t0"]
for i, l in enumerate(L): l["s0"] = 0.0 if i == 0 else l["t0"] - 0.15
T_END = math.ceil((L[-1]["t1"] + 0.8) * FPS) / FPS
for i, l in enumerate(L): l["s1"] = L[i + 1]["s0"] if i + 1 < len(L) else T_END
XF = 0.5
# ---------------------------------------------------------------- subtitles
def sub_items():
    pieces = []
    for l in L:
        ch = []
        for j, w in enumerate(l["words"]):
            ch.append(w)
            if len(ch) >= 6 or w["word"][-1] in ".,?!:" or j == len(l["words"]) - 1:
                pieces.append((ch[0]["t0"] - 0.05, max(ch[-1]["t1"] + 0.12, ch[0]["t0"] + 0.6), " ".join(x["word"] for x in ch).replace("...", "..."))); ch = []
    for i in range(len(pieces) - 1):
        if pieces[i][1] > pieces[i + 1][0]: pieces[i] = (pieces[i][0], pieces[i + 1][0], pieces[i][2])
    return RD.sub_surfs(pieces)
SUBS = sub_items()
# ---------------------------------------------------------------- helpers
GREEN = kit.hx("#2ECC71")
def heb(c, t, txt, t0):     # the one small Hebrew line, bottom of the safe zone
    a = ramp(t, t0, t0 + 0.3)
    if a > 0.01: RD.T(c, txt, 56, 540, 1530, PALE, a, 1, 700, maxw=960)
def head_cap(c, t, en, t0, sz=88, y=300, hl=SKY):
    caption(c, t, en, None, t0, y=y, sz=sz, hl=hl)
NAMES = ["Mike", "Dana", "Josh", "Me"]
def meeting(c, t, me_col=ORANGE, me_talk=0.0, others=True, typing=0.0, frozen=0.0, spk_rate=1.6):
    sp = int(t * spk_rate) % 3
    def scr(c, t, x0, y0, x1, y1, a):
        w = (x1 - x0 - 30) / 2; h = (y1 - y0 - 30) / 2
        for k_, (gx, gy) in enumerate(((0, 0), (1, 0), (0, 1), (1, 1))):
            if k_ == 3: col, s_ = me_col, me_talk
            else: s_ = 1.0 if (others and sp == k_) else 0.0; col = BLUE if s_ else ORANGE
            tile(c, x0 + 10 + gx * (w + 10), y0 + 10 + gy * (h + 10), w, h, col, a, s_, NAMES[k_], talk=s_ * abs(math.sin(t * 14)))
        if frozen > 0.01:   # ice over my tile
            sa(c, (0.75, 0.9, 1.0, 1), 0.28 * frozen); rr(c, x0 + 10 + w + 10, y0 + 10 + h + 10, w, h, 16); c.fill()
    laptop(c, t, scr, 1.0, 560, 1320)
ME_X, ME_Y = 767, 1112   # centre of my tile on the laptop (560..1320)
def think_cloud(c, x, y, w, h, a, col=WHITE):
    if a <= 0.01: return
    sa(c, col, 0.95 * a); rr(c, x - w / 2, y - h / 2, w, h, h / 2); c.fill()
    for k_, (dx, dy, r) in enumerate(((w * 0.18, h * 0.62, 22), (w * 0.26, h * 0.95, 13))):
        c.arc(x + dx, y + dy, r, 0, 2 * math.pi); c.fill()
def chip(c, txt, x, y, col, a, s=1.0, sz=60, txtcol=WHITE):
    if a <= 0.01: return
    f = kit.font(sz, 800); tw = f.getlength(txt); pw, ph = tw + sz * 1.0, sz * 1.6
    c.save(); c.translate(x, y); c.scale(s, s); sa(c, col, a); rr(c, -pw / 2, -ph / 2, pw, ph, ph / 2); c.fill(); c.restore()
    RD.T(c, txt, sz, x, y + 2, txtcol, a, s, 800, maxw=900)
def figure(c, x, y, r, col, a=1.0, talk=0.0):     # big stick figure: head, body, arms
    stick_head(c, x, y, r, col, a, talk)
    c.set_line_width(r * 0.16); c.set_line_cap(cairo.LINE_CAP_ROUND); sa(c, col, a)
def card(c, x0, y0, x1, y1, a, col=None):
    sa(c, col or kit.hx("#1F3357"), a); rr(c, x0, y0, x1 - x0, y1 - y0, 34); c.fill()
# ---------------------------------------------------------------- scenes
def sc0(c, t, l):     # hook: a fast meeting, my tile frozen
    bg(c, t)
    meeting(c, t, ORANGE, 0.0, True, 0.0, frozen=0.6 + 0.4 * math.sin(t * 3) ** 2)
    for j, (txt, x) in enumerate((("Quick sync?", 330), ("Thoughts?", 740), ("Ballpark it?", 420))):
        tt = (t * 1.1 + j * 0.9) % 2.7; bubble(c, x, 720 + 150 * j - 40 * tt, txt, BLUE, min(1, 3 * (1 - tt / 2.7)), 1, 44)
    RD.T(c, "?", 150, ME_X, ME_Y - 10, RED, 1.0, 1 + 0.08 * math.sin(t * 7), 900)
    head_cap(c, t, "Why do you *freeze* in English?", -1, sz=104, y=250)
    heb(c, t, "למה אתם קופאים באנגלית?", -1)
BLK = [("Vocabulary", "אוצר מילים"), ("Pronunciation", "הגייה"), ("Confidence", "ביטחון עצמי"), ("Speech patterns", "תבניות דיבור")]
def sc1(c, t, l):     # four blockers, four habits (teaser)
    bg(c, t)
    head_cap(c, t, "4 blockers. *4 habits.*", l["s0"] + 0.05, sz=100)
    for k_, (en, he) in enumerate(BLK):
        gx, gy = k_ % 2, k_ // 2; x = 290 + gx * 500; yy = 700 + gy * 420
        a, s = kit.pop(t, l["s0"] + 0.2 + 0.25 * k_, 0.4, 0.4, 2.0)
        if a <= 0.01: continue
        c.save(); c.translate(x, yy); c.scale(s, s); sa(c, RED, a); rr(c, -230, -90, 460, 180, 36); c.fill(); c.restore()
        RD.T(c, en, 56 if len(en) > 12 else 62, x, yy, WHITE, a, s, 900, maxw=420)
        u = ramp(t, wt(1, "habit") - 0.1, wt(1, "habit") + 0.4)
        if u > 0.01:
            c.save(); sa(c, SKY, u); c.set_line_width(10); c.set_line_cap(cairo.LINE_CAP_ROUND)
            c.move_to(x, yy + 100); c.line_to(x, yy + 150); c.stroke(); c.move_to(x - 20, yy + 130); c.line_to(x, yy + 152); c.line_to(x + 20, yy + 130); c.stroke(); c.restore()
            c.save(); sa(c, kit.hx("#2C4675"), u); rr(c, x - 230, yy + 165, 460, 110, 30); c.fill(); c.restore()
            RD.T(c, "habit ?", 56, x, yy + 220, YEL, u, 1, 900)
    heb(c, t, "ארבעה חסמים. ארבעה הרגלים.", l["s0"] + 0.05)
def sc2(c, t, l):     # blocker 1, vocabulary: the memorized list never shows up in the meeting
    bg(c, t)
    meeting(c, t, ORANGE, 0.0, True)
    words = ["leverage", "stakeholder", "deadline", "align"]
    gone = ramp(t, wt(2, "none") - 0.3, wt(2, "show") + 0.3)
    c.save(); c.translate(250, 800); c.rotate(-0.06)
    sa(c, WHITE, 1 - 0.5 * gone); rr(c, -190, -190, 380, 400, 24); c.fill()
    c.restore()
    RD.T(c, "My list", 44, 250, 640, NAVY, 1 - 0.5 * gone, 1, 900)
    for k_, wd in enumerate(words):
        dy = 160 * ease(ramp(t, wt(2, "none") - 0.3 + 0.12 * k_, wt(2, "none") + 0.5 + 0.12 * k_))
        RD.T(c, wd, 44, 250, 720 + 70 * k_ + dy, RED, max(0, 1 - dy / 160), 1, 800)
    if t > wt(2, "meeting") - 0.1: bubble(c, ME_X - 40, ME_Y - 130, "Umm...", ORANGE, ramp(t, wt(2, "meeting") - 0.1, wt(2, "meeting") + 0.2), 1, 44, "r")
    head_cap(c, t, "Blocker 1: *Vocabulary*", l["s0"] + 0.05, hl=kit.hx("#FF9C9C"))
    heb(c, t, "חסם 1: אוצר מילים", l["s0"] + 0.05)
def sc3(c, t, l):     # habit 1, context: open a word group, use a few words in real sentences
    bg(c, t, 0.05)
    head_cap(c, t, "Habit 1: *Context*", l["s0"] + 0.05)
    a0 = ramp(t, l["s0"], l["s0"] + 0.3)
    card(c, 90, 520, 990, 860, a0)
    RD.T(c, "Word group: *Meetings*", 60, 540, 590, WHITE, a0, 1, 900, hl=YEL)
    chips = [("align", 220), ("follow up", 525), ("deadline", 840)]
    use = [wt(3, "use"), wt(3, "real"), wt(3, "Never") - 0.2]
    for k_, (wd, x) in enumerate(chips):
        on = ramp(t, use[k_] - 0.1, use[k_] + 0.3)
        a, s = kit.pop(t, wt(3, "pick") - 0.1 + 0.15 * k_, 0.4, 0.5, 2.0)
        chip(c, wd, x, 750, kit.mix(ORANGE, BLUE, on), a, s, 54)
    figure(c, 300, 1150, 85, BLUE, a0, abs(math.sin(t * 12)) if t > use[0] else 0)
    lines_ = ["Let's *align* on Friday.", "I'll *follow up* today.", "The *deadline* is close."]
    k_ = max([i for i in range(3) if t >= use[i] - 0.1] or [-1])
    if k_ >= 0: bubble(c, 640, 1040, lines_[k_], BLUE, ramp(t, use[k_] - 0.1, use[k_] + 0.15), 1, 50, "l", new=YEL, maxw=560)
    if t > wt(3, "Never") - 0.1:
        u = ramp(t, wt(3, "Never") - 0.1, wt(3, "Never") + 0.3)
        RD.T(c, "No list. *No translating.*", 64, 540, 1380, WHITE, u, 1, 900, hl=YEL)
    heb(c, t, "הרגל 1: קונטקסט", l["s0"] + 0.05)
def sc4(c, t, l):     # blocker 2, pronunciation: "Sorry, what?"
    bg(c, t)
    them = t > wt(4, "they") - 0.1
    meeting(c, t, ORANGE if them else BLUE, 0.0 if them else 1.0, them, spk_rate=0.0)
    if not them: bubble(c, ME_X - 60, ME_Y - 140, "It's very *com-FOR-ta-ble*", BLUE, ramp(t, l["s0"] + 0.2, l["s0"] + 0.5), 1, 46, "r", maxw=560)
    else:
        u = ramp(t, wt(4, "sorry") - 0.1, wt(4, "sorry") + 0.2)
        bubble(c, 330, 780, "Sorry, *what?*", BLUE, u, 1 + 0.03 * math.sin(t * 9), 52, "l")
        RD.T(c, "?", 130, ME_X, ME_Y - 10, RED, u, 1, 900)
    head_cap(c, t, "Blocker 2: *Pronunciation*", l["s0"] + 0.05, hl=kit.hx("#FF9C9C"))
    heb(c, t, "חסם 2: הגייה", l["s0"] + 0.05)
def sc5(c, t, l):     # habit 2, right pronunciation: practise the wrong sound with the sound table
    bg(c, t, 0.05)
    head_cap(c, t, "Habit 2: *Say it right*", l["s0"] + 0.05)
    a0 = ramp(t, l["s0"], l["s0"] + 0.3)
    card(c, 90, 520, 990, 1080, a0)
    RD.T(c, "The sound table", 60, 540, 590, YEL, a0, 1, 900)
    rows = [("comfortable", "KUMF-ter-bl"), ("think", "TH, not S"), ("work", "W, not V")]
    t_on = wt(5, "practice")
    for k_, (w1, w2) in enumerate(rows):
        yy = 700 + 125 * k_
        a = ramp(t, wt(5, "sound") - 0.2 + 0.2 * k_, wt(5, "sound") + 0.2 + 0.2 * k_)
        hi = ramp(t, t_on - 0.1, t_on + 0.3) if k_ == 0 else 0.0
        sa(c, kit.mix(kit.hx("#2C4675"), BLUE, hi), a); rr(c, 130, yy - 50, 820, 100, 24); c.fill()
        RD.T(c, w1, 56, 330, yy, WHITE, a, 1, 800, maxw=380); RD.T(c, w2, 56, 740, yy, YEL, a, 1, 900, maxw=380)
    figure(c, 300, 1250, 70, BLUE, a0, abs(math.sin(t * 12)) if t > t_on else 0)
    for kb in range(14):
        hh = 20 + 70 * abs(math.sin(t * 7 + kb * 0.7)) * (1.0 if t > t_on else 0.25)
        sa(c, SKY, a0); rr(c, 470 + kb * 34, 1260 - hh / 2, 18, hh, 8); c.fill()
    heb(c, t, "הרגל 2: דברו בהגייה נכונה", l["s0"] + 0.05)
def sc6(c, t, l):     # blocker 3, confidence: stop mid-sentence and translate in your head
    bg(c, t)
    stop = t > wt(6, "translate") - 0.2
    meeting(c, t, ORANGE if stop else BLUE, 0.0 if stop else 1.0, False, frozen=ramp(t, wt(6, "translate") - 0.2, wt(6, "translate") + 0.4))
    bubble(c, ME_X - 80, ME_Y - 150, "I think we should...", BLUE if not stop else ORANGE, ramp(t, l["s0"] + 0.2, l["s0"] + 0.5), 1, 46, "r", maxw=560)
    if stop:
        u = ramp(t, wt(6, "translate") - 0.2, wt(6, "translate") + 0.3)
        think_cloud(c, 540, 540 + 0 * u, 760, 130, u)
        RD.T(c, "איך אומרים...?", 60, 540, 540, NAVY, u, 1, 800)
    head_cap(c, t, "Blocker 3: *Confidence*", l["s0"] + 0.05, y=290, hl=kit.hx("#FF9C9C"))
    heb(c, t, "חסם 3: ביטחון עצמי", l["s0"] + 0.05)
def sc7(c, t, l):     # habit 3, think in English: tell someone about your week, keep going
    bg(c, t, 0.05)
    head_cap(c, t, "Habit 3: *Think in English*", l["s0"] + 0.05)
    a0 = ramp(t, l["s0"], l["s0"] + 0.3)
    t_tell = wt(7, "Tell"); t_keep = wt(7, "Keep")
    me_talk = abs(math.sin(t * 12)) if t > t_tell else 0.0
    figure(c, 300, 1050, 90, BLUE, a0, me_talk)
    figure(c, 790, 1050, 90, ORANGE, a0, 0.0)
    sa(c, WHITE, a0); rr(c, 870, 1140, 60, 70, 10); c.fill(); c.set_line_width(8); c.arc(940, 1175, 18, -1.3, 1.3); c.stroke()   # coffee mug
    msgs = [("This week I'm on the *launch*.", t_tell), ("We *ship* it Friday.", wt(7, "Don't") - 0.1), ("And you? *What's new?*", t_keep)]
    for k_, (m, t0) in enumerate(msgs):
        if t > t0 - 0.1:
            bubble(c, 540, 600 + 120 * k_, m, BLUE, ramp(t, t0 - 0.1, t0 + 0.2), 1, 50, "l", new=YEL, maxw=900)
    if t > t_keep - 0.1:
        RD.T(c, "Don't translate. *Keep going.*", 64, 540, 1360, WHITE, ramp(t, t_keep - 0.1, t_keep + 0.3), 1, 900, hl=YEL)
    heb(c, t, "הרגל 3: חשבו באנגלית", l["s0"] + 0.05)
def word_row(c, words, y, cols, a, sz=64, gap=22):
    f = kit.font(sz, 900); ws = [f.getlength(w) + sz * 0.9 for w in words]; tot = sum(ws) + gap * (len(ws) - 1)
    x = 540 - tot / 2; out = []
    for w_, wd, col in zip(words, ws, cols):
        sa(c, col, a); rr(c, x, y - sz * 0.8, wd, sz * 1.6, 22); c.fill()
        RD.T(c, w_, sz, x + wd / 2, y + 2, WHITE, a, 1, 900); out.append(x + wd / 2); x += wd + gap
    return out
def sc8(c, t, l):     # blocker 4, speech patterns: Hebrew word order in English words
    bg(c, t)
    head_cap(c, t, "Blocker 4: *Speech patterns*", l["s0"] + 0.05, hl=kit.hx("#FF9C9C"))
    a0 = ramp(t, l["s0"] + 0.1, l["s0"] + 0.4)
    RD.T(c, "אני מאוד אוהב את הרעיון", 60, 540, 640, PALE, a0, 1, 700)
    sa(c, SKY, a0); c.set_line_width(8); c.move_to(540, 700); c.line_to(540, 780); c.stroke()
    bad = ramp(t, wt(8, "Hebrew") - 0.2, wt(8, "Hebrew") + 0.2)
    shake = 8 * math.sin(t * 40) * bad * (1 - ramp(t, wt(8, "order"), wt(8, "order") + 0.6))
    c.save(); c.translate(shake, 0)
    word_row(c, ["I", "very", "like", "this", "idea"], 880, [ORANGE, kit.mix(ORANGE, RED, bad), kit.mix(ORANGE, RED, bad), ORANGE, ORANGE], a0, 64)
    c.restore()
    figure(c, 540, 1180, 80, ORANGE, a0, 0.0)
    if bad > 0.01: RD.T(c, "Hebrew order", 60, 540, 1390, kit.hx("#FF9C9C"), bad, 1, 900)
    heb(c, t, "חסם 4: תבניות דיבור / תחביר", l["s0"] + 0.05)
def sc9(c, t, l):     # habit 4, shadowing: a video, repeat after the speaker word for word
    bg(c, t, 0.05)
    head_cap(c, t, "Habit 4: *Shadowing*", l["s0"] + 0.05)
    a0 = ramp(t, l["s0"], l["s0"] + 0.3)
    card(c, 110, 510, 970, 930, a0, kit.hx("#0B1628"))
    stick_head(c, 540, 680, 70, BLUE, a0, abs(math.sin(t * 12)))
    sa(c, kit.hx("#31456A"), a0); rr(c, 150, 880, 780, 12, 6); c.fill()
    prog = ramp(t, l["s0"], l["s1"]); sa(c, RED, a0); rr(c, 150, 880, 780 * prog, 12, 6); c.fill(); c.arc(150 + 780 * prog, 886, 16, 0, 2 * math.pi); c.fill()
    words = ["I", "really", "like", "this", "idea"]
    t_rep = wt(9, "repeat"); step = 0.42
    lead = [ramp(t, t_rep + step * k_, t_rep + step * k_ + 0.15) for k_ in range(5)]
    me = [ramp(t, t_rep + 0.5 + step * k_, t_rep + 0.65 + step * k_) for k_ in range(5)]
    word_row(c, words, 1040, [kit.mix(kit.hx("#2C4675"), ORANGE, u) for u in lead], a0, 60)
    word_row(c, words, 1180, [kit.mix(kit.hx("#2C4675"), BLUE, u) for u in me], a0, 60)
    if t > wt(9, "Say") - 0.1:
        RD.T(c, "Say it first. *Fix it later.*", 66, 540, 1360, WHITE, ramp(t, wt(9, "Say") - 0.1, wt(9, "Say") + 0.3), 1, 900, hl=YEL)
    heb(c, t, "הרגל 4: הצללה / חיקוי", l["s0"] + 0.05)
# acronym: the four blocker initials, right to left
ACR = [("אוצר מילים", "א"), ("הגייה", "ה"), ("ביטחון עצמי", "ב"), ("תבניות דיבור", "ת")]
def sc10(c, t, l):
    bg(c, t, 0.08)
    head_cap(c, t, "Put them *together*", l["s0"] + 0.05)
    t_go = wt(10, "together"); t_sp = wt(10, "spell"); t_love = wt(10, "love")
    pos = [(770, 640), (310, 640), (770, 880), (310, 880)]      # RTL: right column first
    f = kit.font(220, 900)
    final = "אהב\"ת"
    # final x for each letter: draw right to left
    glyphs = ["א", "ה", "ב", "\"", "ת"]; gw = [f.getlength(g) for g in glyphs]; tot = sum(gw)
    xs = []; x = 540 + tot / 2
    for g in gw: xs.append(x - g / 2); x -= g
    for k_, (he, ini) in enumerate(ACR):
        bx, by = pos[k_]
        a, s = kit.pop(t, l["s0"] + 0.15 + 0.2 * k_, 0.4, 0.5, 2.0)
        if a <= 0.01: continue
        c.save(); c.translate(bx, by); c.scale(s, s); sa(c, kit.hx("#2C4675"), a); rr(c, -215, -90, 430, 180, 36); c.fill(); c.restore()
        RD.T(c, he, 60, bx, by + 10, WHITE, a * (1 - 0.4 * ramp(t, t_go, t_go + 0.3)), s, 700, maxw=400)
        # the initial lifts out and flies down into the word
        u = ease(ramp(t, t_go + 0.15 * k_, t_sp + 0.15 * k_))
        gi = [0, 1, 2, 4][k_]
        lx = lerp(bx + 150, xs[gi], u); ly = lerp(by - 40, 1170, u)
        RD.T(c, ini, int(lerp(80, 220, u)), lx, ly, YEL, ramp(t, t_go - 0.2 + 0.15 * k_, t_go + 0.1 + 0.15 * k_), 1, 900)
    gq = ramp(t, t_sp + 0.5, t_sp + 0.8)
    RD.T(c, "\"", 220, xs[3], 1170, YEL, gq, 1, 900)
    if t > t_love - 0.15:
        a, s = kit.pop(t, t_love - 0.15, 0.4, 0.5, 2.0)
        RD.T(c, "= love", 110, 540, 1390, WHITE, a, s, 900)
    heb(c, t, "אהב\"ת: ארבעת החסמים", l["s0"] + 0.05)
def sc11(c, t, l):     # the Express offer
    bg(c, t)
    head_cap(c, t, "At *English Express*", l["s0"] + 0.05)
    rows = [("A personal coach", wt(11, "personal")), ("A community", wt(11, "community")), ("Daily habits", wt(11, "daily"))]
    for k_, (txt, t0) in enumerate(rows):
        yy = 610 + 200 * k_
        a, s = kit.pop(t, t0 - 0.15, 0.4, 0.5, 2.0)
        if a <= 0.01: continue
        c.save(); c.translate(540, yy); c.scale(s, s); sa(c, kit.hx("#2C4675"), a); rr(c, -440, -80, 880, 160, 40); c.fill(); c.restore()
        ix = 190
        if k_ == 0: stick_head(c, ix, yy - 20, 34, BLUE, a, 0.3)
        elif k_ == 1:
            for dx in (-40, 0, 40): stick_head(c, ix + dx, yy - 20 + (10 if dx else -6), 22, BLUE if dx == 0 else ORANGE, a, 0)
        else: RD.T(c, "4", 90, ix, yy, YEL, a, s, 900)
        RD.T(c, txt, 68, 600, yy, WHITE, a, s, 900, maxw=640)
    t_ind = wt(11, "independent")
    if t > t_ind - 0.15:
        a, s = kit.pop(t, t_ind - 0.15, 0.4, 0.5, 2.0)
        RD.pill(c, "Independent *English Speaker*", 62, 540, 1310, BLUE, WHITE, a, s, w=900)
    if t > wt(11, "Practice") - 0.1:
        RD.T(c, "Practice all 4. *Every day.*", 60, 540, 1180, YEL, ramp(t, wt(11, "Practice") - 0.1, wt(11, "Practice") + 0.3), 1, 900, hl=WHITE)
    heb(c, t, "מאמן אישי, קהילה והרגלים יומיים", l["s0"] + 0.05)
def car(c, x, y, a=1.0, t=0.0):
    sa(c, (0, 0, 0, 1), 0.25 * a); rr(c, x - 200, y + 58, 400, 20, 10); c.fill()
    sa(c, WHITE, a); rr(c, x - 210, y - 20, 420, 90, 34); c.fill(); rr(c, x - 120, y - 85, 230, 90, 40); c.fill()
    sa(c, kit.hx("#9CC9EE"), a); rr(c, x - 100, y - 70, 95, 55, 16); c.fill(); rr(c, x + 5, y - 70, 90, 55, 16); c.fill()
    RD.T(c, "EXPRESS", 40, x, y + 24, SKY, a, 1, 900)
    for dx in (-120, 120):
        c.arc(x + dx, y + 70, 36, 0, 2 * math.pi); sa(c, kit.hx("#1B2A44"), a); c.fill()
        c.arc(x + dx, y + 70, 14, 0, 2 * math.pi); sa(c, PALE, a); c.fill()
def sc12(c, t, l):     # book a call
    bg(c, t)
    a, s = kit.pop(t, l["s0"] + 0.05, 0.4, 0.5, 2.0)
    RD.T(c, "Book a call:", 116, 540, 640, WHITE, a, s, 900)
    a2, s2 = kit.pop(t, wt(12, "link") - 0.1, 0.4, 0.5, 2.0)
    RD.T(c, "link in bio", 130, 540, 800, YEL, a2, s2, 900)
    sa(c, kit.hx("#0B1628"), 1); c.rectangle(0, 1180, W, 170); c.fill()
    for kx in range(-1, 9):
        x = kx * 160 - (t * 400) % 160; sa(c, WHITE, 0.85); rr(c, x, 1260, 90, 14, 7); c.fill()
    car(c, lerp(-250, 560, ease(ramp(t, l["s0"], l["s0"] + 1.6))), 1140, 1, t)
    heb(c, t, "קבעו שיחה: הלינק בביו", l["s0"] + 0.05)
def sc13(c, t, l):     # lead-in back into the hook (same meeting, same layout as frame 0)
    bg(c, t)
    meeting(c, t, ORANGE, 0.0, True, 0.0)
    head_cap(c, t, "So next time, you won't *ask yourself...*", l["s0"] + 0.05, sz=88, y=250)
    heb(c, t, "אז בפעם הבאה, לא תשאלו את עצמכם...", l["s0"] + 0.05)
SC = [sc0, sc1, sc2, sc3, sc4, sc5, sc6, sc7, sc8, sc9, sc10, sc11, sc12, sc13]
assert len(SC) == len(L), (len(SC), len(L))
def frame(c, t):
    i = max(j for j, l in enumerate(L) if l["s0"] <= t or j == 0)
    SC[i](c, t, L[i])
    if i > 0 and t < L[i]["s0"] + 0.25:
        tmp = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(tmp); SC[i - 1](cc, t, L[i - 1])
        c.set_source_surface(tmp, 0, 0); c.paint_with_alpha(1 - ramp(t, L[i]["s0"], L[i]["s0"] + 0.25))
    RD.draw_subs(c, t, SUBS)
    if t > T_END - XF:
        tmp = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(tmp); sc0(cc, 0.0, L[0])
        c.set_source_surface(tmp, 0, 0); c.paint_with_alpha(ease((t - (T_END - XF)) / XF))
if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    if "--preview" in sys.argv:
        arg = sys.argv[sys.argv.index("--preview") + 1]
        ts = [l["s0"] + 0.6 * (l["s1"] - l["s0"]) for l in L] if arg == "mid" else [float(x) for x in arg.split(",")]
        ims = []
        for t in ts:
            s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s); frame(c, t)
            ims.append(Image.frombuffer("RGBA", (W, H), bytes(s.get_data()), "raw", "BGRA", 0, 1).convert("RGB").resize((390, 693)))
        cols = 7; rows_ = (len(ims) + cols - 1) // cols
        sh = Image.new("RGB", (395 * cols, 698 * rows_), "white")
        for i, im in enumerate(ims): sh.paste(im, ((i % cols) * 395, (i // cols) * 698))
        sh.save(OUT.replace(".mp4", "_pv.png")); print("T_END", round(T_END, 2), [round(l["s0"], 2) for l in L]); sys.exit()
    bed = MX.bed(MUSIC, T_END + 1, T_END + 1)[:, :int(T_END * SR)]
    f = int(0.4 * SR); bed[:, -f:] *= np.linspace(1, 0.4, f)[None, :]
    vt = np.zeros(int(T_END * SR)); vt[:min(len(vo), len(vt))] = vo[:len(vt)]
    MX.mix(vt, T_END, bed, [], OUT + ".wav", music_db=-18.0, log=lambda *a: None)
    nf = int(round(T_END * FPS))
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                            "-i", OUT + ".wav", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                            "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", OUT], stdin=subprocess.PIPE)
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    for k in range(nf):
        frame(c, k / FPS); s.flush(); enc.stdin.write(bytes(s.get_data()))
    enc.stdin.close(); enc.wait(); os.remove(OUT + ".wav"); print("wrote", OUT, round(T_END, 2))
