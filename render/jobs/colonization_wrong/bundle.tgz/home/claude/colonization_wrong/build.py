"""colonization_wrong: write tts.txt, spec.json, tts_parts.json, caption.txt (satirical Colonization 101 reel, @noamroz__)."""
import json, os, re
D = os.path.dirname(os.path.abspath(__file__))
VOICE = "cd06f613-0c92-4347-9b94-b34cb4a0239f"; SPEED = 1.05
DASH = re.compile("[‒–—―־]")

LINES = [
 "Colonization done wrong.",                                                                   # 1 cover
 "Real empires followed the book.",                                                            # 2 (on screen only: dropped from the voice by use_lines)
 "Spain took silver. Belgium, rubber. Britain, India's cotton. Portugal enslaved Africans.",  # 3
 "Israel? Failed every lesson.",                                                               # 4 grade
 "Lesson one: pick a land with gold or oil. Israel picked swamps and desert.",                 # 5
 "Lesson two: rule from a mother country. What mother country? We fled Europe and the Arab world.",  # 6
 "Lesson three: enslave the locals. Instead, Arab citizens vote, and one in four doctors is Arab.",  # 7
 "Lesson four: let them get sick. Instead, universal health care. And Israeli hospitals treat Palestinians too.",  # 8
 "Lesson five: ship the wealth back home. Small problem.",                                     # 9
 "This is home.",                                                                              # 10
 "Wow. We really missed the point. We should have read the book more carefully.",              # 11 verdict
 "Jews. Go figure.",                                                                           # 12
 "Maybe they have different intentions, and you just don't understand them.",                  # 13
 "To be fair, critics point to the West Bank: millions of Palestinians under military rule, with no vote for Israel's government.",  # 14
 "Beg to differ? Tell us where we're wrong.",                                                  # 15
]
# extra silence (s) inserted before these 1-based lines: comic beats before punchlines
PAUSE = {4: 0.15, 10: 0.45, 11: 0.3, 12: 0.3, 13: 0.1, 14: 0.2, 15: 0.2}
PARTS = [[1, 2, 3, 4], [5, 6], [7, 8], [9, 10, 11], [12, 13], [14, 15]]

def lesson(n, line, rule, rule_he, xat, results, src=None):
    d = dict(type="lesson", line=line, n=n, rule=rule, rule_he=rule_he, results=[], marks={"x": xat})
    for k, r in enumerate(results):
        at = r.pop("at"); d["marks"][f"r{k}"] = at; d["results"].append(r)
    if src: d["source"] = src
    return d

SCENES = [
 dict(type="cover", line=1, en="Colonization *done wrong.*", he="קולוניזציה, עשינו את זה לא נכון.",
      book_en="COLONIZATION", book_num="101", book_sub="The complete guide", book_he="המדריך המלא",
      sticker="UNREAD", sticker_he="לא נקרא"),
 dict(type="ledger", line=3, title="Every real empire *followed the book*", title_he="כל אימפריה אמיתית עבדה לפי הספר",
      items=[dict(flag="ES", en="Spain: *silver* from Potosí", he="ספרד: כסף מפוטוסי", src="*1545 onward*   Source: Potosí, Britannica"),
             dict(flag="BE", en="Belgium's King Leopold: Congo *rubber*", he="בלגיה: גומי מקונגו, בעבודת כפייה", src="*1885 to 1908*   Source: Congo Free State, Britannica"),
             dict(flag="GB", en="Britain: India's *cotton* out, British cloth in", he="בריטניה: כותנה מהודו החוצה, בדים בריטיים פנימה", src="*1757 to 1947*   Source: Britannica, British raj; Roy 2007"),
             dict(flag="PT", en="Portugal: *4.8 million* enslaved Africans to Brazil", he="פורטוגל: כ-4.8 מיליון אפריקאים משועבדים לברזיל", src="*1500s to 1850*   Source: SlaveVoyages.org (Eltis)")],
      marks={"i0": "3:Spain", "i1": "3:Belgium", "i2": "3:Britain", "i3": "3:Portugal"}),
 dict(type="grade", line=4, en="Israel?", he="ישראל?", stamp="FAILED EVERY LESSON", stamp_he="נכשלה בכל השיעורים",
      marks={"f": "Failed"}),
 lesson(1, 5, "Pick a land with *gold or oil*", "לבחור ארץ עם זהב או נפט", "Israel",
        [dict(en="Israel picked *swamps and desert.* Almost no oil.", he="ישראל בחרה ביצות ומדבר. כמעט בלי נפט.", at="Israel"),
         dict(en="The big gas finds came in *2009 and 2010*, 60 years later", he="מאגרי הגז הגדולים התגלו רק ב-2009 וב-2010", at="desert")],
        "Sources: Tamar gas field found Jan 2009, Leviathan Dec 2010 (Noble Energy)"),
 lesson(2, 6, "Rule from a *mother country* far away", "לשלוט מארץ אם רחוקה", "What",
        [dict(en="What *mother country?*", he="איזו ארץ אם?", at="What", big=True),
         dict(en="Jews came *fleeing* Europe and the Arab world", he="היהודים הגיעו בורחים מאירופה ומארצות ערב", at="We fled")],
        "Source: Britannica, Israel (Zionism and immigration)"),
 lesson(3, 7, "*Enslave* the locals", "לשעבד את המקומיים", "Instead",
        [dict(en="Arab citizens *vote*: 10 Knesset seats (2022)", he="ערבים אזרחי ישראל מצביעים: 10 מושבים בכנסת", at="Arab citizens"),
         dict(en="*1 in 4* doctors, *half* of pharmacists", he="רבע מהרופאים וחצי מהרוקחים", at="one in four")],
        "Sources: Knesset election Nov 2022 (Ra'am 5, Hadash-Ta'al 5); Rosen and Miaari, IJHPR, Feb 2025"),
 lesson(4, 8, "Let them *get sick*", "לתת להם לחלות", "Instead",
        [dict(en="Health insurance for *every resident* (law of 1994)", he="ביטוח בריאות לכל תושב (חוק 1994)", at="universal"),
         dict(en="Dec 2022 alone: about *3,000* permit requests by Palestinian patients were for hospitals in Israel",
              he="בדצמבר 2022 לבד: כ-3,000 בקשות של מטופלים פלסטינים לבתי חולים בישראל", at="Israeli hospitals")],
        "Sources: National Health Insurance Law 1994; WHO monthly report, Dec 2022 (West Bank and Gaza)"),
 lesson(5, 9, "Ship the wealth *back home*", "לשלוח את העושר הביתה", "Small",
        [dict(en="Small problem:", he="בעיה קטנה:", at="Small"),
         dict(en="This *is* home.", he="זה הבית.", at="10:This", big=True)]),
 dict(type="verdict", line=11, title="Final score", title_he="הציון הסופי", score="0 / 5",
      en="Wow. We really *missed the point.*", he="וואו. ממש פספסנו את העניין.",
      sub="We should have read the book *more carefully.*", sub_he="היינו צריכים לקרוא את הספר יותר בעיון.",
      marks={"en": "Wow", "sub": "We should"}),
 dict(type="title", line=12, icon="🤷", en="Jews. *Go figure.*", he="יהודים, לך תבין.",
      sub="Maybe they have *different intentions*, and you just don't understand them.", sub_at="13:Maybe",
      sub_he="אולי יש להם כוונות אחרות, ואתם פשוט לא מבינים אותן.", size=110),
 dict(type="fair", line=14, icon="⚖️", en="To be fair: *the critics*", he="למען ההגינות: המבקרים",
      sub="Millions of West Bank Palestinians live under *Israeli military rule*, without a vote for Israel's government.", marks={"sub": "millions"},
      sub_he="מיליוני פלסטינים בגדה חיים תחת שלטון צבאי ישראלי, בלי זכות הצבעה לממשלת ישראל.",
      source="Source: Britannica, West Bank"),
 dict(type="ask", line=15, en="Beg to differ?", sub="Tell us *where we're wrong.*", he="חושבים אחרת? כתבו לנו איפה אנחנו טועים.",
      follow="Follow *@noamroz__*", marks={"sub": "Tell"}),
]

CAPTION = """Colonization done wrong. 📕

Every real empire followed the book:
🇪🇸 Spain took the silver of Potosí (from 1545)
🇧🇪 Belgium's King Leopold took Congo's rubber (1885 to 1908)
🇬🇧 Britain took India's cotton and sold back British cloth (1757 to 1947)
🇵🇹 Portugal shipped about 4.8 million enslaved Africans to Brazil

Israel? Failed every lesson.
❌ Pick a land with gold or oil: we picked swamps and desert. The big gas finds came in 2009 and 2010.
❌ Rule from a mother country: what mother country? Jews came fleeing Europe and the Arab world.
❌ Enslave the locals: Arab citizens vote (10 Knesset seats in 2022) and are 1 in 4 doctors and half of pharmacists.
❌ Let them get sick: health insurance for every resident since 1994, and Israeli hospitals treat Palestinian patients too.
❌ Ship the wealth back home: small problem, this is home.

Wow. We really missed the point. Jews, go figure. Maybe they have different intentions, and you just don't understand them.

To be fair: critics point to the West Bank, where millions of Palestinians live under Israeli military rule without a vote for Israel's government.

Beg to differ? Tell us where we're wrong 👇

קולוניזציה, עשינו את זה לא נכון. כל אימפריה אמיתית לקחה את העושר הביתה. ישראל נכשלה בכל השיעורים: אין נפט, אין ארץ אם, ערבים אזרחי ישראל מצביעים ומהווים רבע מהרופאים, וביטוח בריאות לכל תושב. יהודים, לך תבין. חושבים אחרת? כתבו לנו איפה אנחנו טועים 👇

👥 Tag a friend who needs to see this 👇
תייגו חבר שחייב לראות את זה 👇

Sources: Britannica (Potosí; Congo Free State; British raj; Israel; West Bank); Roy, Australian Economic History Review, 2007; SlaveVoyages.org (Eltis); Tamar gas field, Jan 2009 and Leviathan, Dec 2010 (Noble Energy); Knesset election results, Nov 2022; Rosen and Miaari, Israel Journal of Health Policy Research, Feb 2025; National Health Insurance Law, 1994; WHO oPt monthly report, Dec 2022.

#Israel #History #Colonization #Satire #ישראל"""

if __name__ == "__main__":
    blob = json.dumps(dict(L=LINES, S=SCENES, C=CAPTION), ensure_ascii=False)
    assert not DASH.search(blob), DASH.findall(blob)
    assert len(CAPTION) < 2200, len(CAPTION)
    open(f"{D}/tts.txt", "w").write("\n".join(LINES) + "\n")
    open(f"{D}/caption.txt", "w").write(CAPTION)
    pal = dict(bg0="#FAF6EC", bg1="#EDE3CC", card="#FFFDF6", silver="#D8CDB4", grey="#5F6470", gold_text="#8E6A22")
    spec = dict(account="@noamroz__", script="tts.txt", scene_module="cw_scenes.py", palette=pal, music="playful", sfx=True,
                cta_hold=3.0, gap_max=1.3, tail=2.4, use_lines=[1] + list(range(3, 16)), subs_replace=[["one in four", "1 in 4"]], scenes=SCENES)
    json.dump(spec, open(f"{D}/spec.json", "w"), ensure_ascii=False, indent=1)
    out = []
    for k, ls in enumerate(PARTS):
        name = f"cw_colonization_wrong_p{k}.txt"; tr = " ".join(LINES[i - 1] for i in ls)
        body = {"model_id": "sonic-3", "transcript": tr, "voice": {"mode": "id", "id": VOICE},
                "output_format": {"container": "raw", "encoding": "pcm_s16le", "sample_rate": 44100}, "add_timestamps": True,
                "language": "en", "generation_config": {"speed": SPEED}}
        out.append(dict(lines=[LINES[i - 1] for i in ls], name=name, data=dict(body=json.dumps(body, ensure_ascii=False), name=name, tag="reel", endpoint="sse")))
    json.dump(out, open(f"{D}/tts_parts.json", "w"), ensure_ascii=False, indent=1)
    print(len(LINES), "lines", sum(len(l.split()) for l in LINES), "words;", [len(" ".join(LINES[i - 1] for i in p).split()) for p in PARTS], "words/part;", len(CAPTION), "caption chars")
