"""colonization_wrong scenes: the "Colonization 101" textbook / notebook look.
Off-white paper, navy #163260 text, blue #2A88D4, gold accents, red X stamps. English line with Hebrew under it.
Scene types: cover (hook, textbook cover), ledger (empire rows with year + source), grade (report card, F stamp),
lesson (notebook page: rule, red X on the checkbox, Israel's results), verdict (0 / 5), ask (closing question + arrow).
Times: S["times"][mark] from spec "marks" (x, r0.., i0.., f, en, sub)."""
import math, random
import cairo
import render as RD
from render import P, T, block, block_h, pill, PP, fade_in, heading, source, shadow_box, draw_emoji, icon_of, diamond, CONTENT_BOTTOM
from kit import ease, ramp, lerp, St, sa, rr, circ, box, W, H

# ------------------------------------------------------------------ paper background (replaces the house silver one)
_pb = {}
def paper_bg(c, t):
    if "base" not in _pb:
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); cc = cairo.Context(s)
        g = cairo.LinearGradient(0, 0, W * 0.35, H); g.add_color_stop_rgb(0, *P["bg0"][:3]); g.add_color_stop_rgb(1, *P["bg1"][:3])
        cc.set_source(g); cc.paint()
        R = random.Random(7)
        for _ in range(9000):   # paper grain
            x, y = R.uniform(0, W), R.uniform(0, H); v = R.random()
            cc.set_source_rgba(0.45, 0.38, 0.25, 0.035 + 0.04 * v); cc.rectangle(x, y, 1.6, 1.6); cc.fill()
        cc.set_line_width(2)
        for y in range(236, H, 72):   # faint ruled lines
            cc.set_source_rgba(*P["blue"][:3], 0.10); cc.move_to(0, y); cc.line_to(W, y); cc.stroke()
        cc.set_source_rgba(*P["red"][:3], 0.22); cc.set_line_width(3); cc.move_to(46, 0); cc.line_to(46, H); cc.stroke()
        _pb["base"] = s
        _pb["sp"] = [(R.uniform(60, 1020), R.uniform(0, H), R.uniform(7, 12), R.uniform(12, 26), R.random() * 6) for _ in range(14)]
    c.set_source_surface(_pb["base"], 0, 0); c.paint()
    for k, (x0, y0, r, sp, ph) in enumerate(_pb["sp"]):
        y = (y0 - t * sp) % (H + 60) - 30; x = x0 + 12 * math.sin(t * 0.6 + k); tw = 0.5 + 0.5 * math.sin(t * 2 + ph)
        diamond(c, x, y, r, P["gold"], 0.18 + 0.22 * tw)
RD.background = paper_bg

# ------------------------------------------------------------------ pieces
def notebook(c, x, y, w, h, a=1.0, holes=True, lines_from=None):
    """white notebook page: shadow, ruled blue lines, red margin, binder holes"""
    shadow_box(c, x, y, w, h, 26, P["card"], a, stroke=P["silver"], sw=3, sh=10)
    c.save(); rr(c, x, y, w, h, 26); c.clip()
    sa(c, P["blue"], 0.16 * a); c.set_line_width(2)
    for yy in range(int(lines_from or (y + 120)), int(y + h - 20), 66): c.move_to(x + 10, yy); c.line_to(x + w - 10, yy); c.stroke()
    sa(c, P["red"], 0.35 * a); c.set_line_width(3); c.move_to(x + 92, y); c.line_to(x + 92, y + h); c.stroke()
    c.restore()
    if holes:
        for k in range(3):
            hy = y + h * (0.2 + 0.3 * k); circ(c, x + 44, hy, 15, P["bg1"], a); circ(c, x + 44, hy, 15, P["silver"], 0.6 * a, stroke=P["silver"], sw=2)

def red_x(c, x, y, s, t, t0, S, rot=-0.12):
    """stamped red X: slams in from 1.8x, ink slightly transparent"""
    hk = S.get("hook") and t0 <= RD.HOOK_GRACE
    if not hk and t < t0: return 0.0
    u = 1.0 if hk else ease((t - t0) / 0.22); sc = lerp(1.8, 1.0, u); a = 1.0 if hk else ramp(t, t0, t0 + 0.1)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc * s / 100, sc * s / 100)
    sa(c, P["red"], 0.9 * a); c.set_line_width(26); c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.move_to(-42, -42); c.line_to(42, 42); c.stroke(); c.move_to(42, -42); c.line_to(-42, 42); c.stroke()
    c.set_line_cap(cairo.LINE_CAP_BUTT); c.restore()
    return a

def stamp(c, s, sz, x, y, t, t0, S, rot=-0.1, color="red", w=900, he=None):
    """rubber stamp: rotated rectangle outline + caps text, slams in"""
    hk = S.get("hook") and t0 <= RD.HOOK_GRACE
    if not hk and t < t0: return
    u = 1.0 if hk else ease((t - t0) / 0.22); sc = lerp(1.7, 1.0, u); a = 1.0 if hk else ramp(t, t0, t0 + 0.1)
    cc = RD.col(color); f = RD.font(sz, w); tw = min(f.getlength(s), 860); pw, ph = tw + sz * 1.0, sz * (1.7 if not he else 2.7)
    c.save(); c.translate(x, y); c.rotate(rot); c.scale(sc, sc)
    rr(c, -pw / 2, -ph / 2, pw, ph, 18); sa(c, P["card"], 0.75 * a); c.fill_preserve(); sa(c, cc, 0.92 * a); c.set_line_width(9); c.stroke()
    rr(c, -pw / 2 + 12, -ph / 2 + 12, pw - 24, ph - 24, 10); sa(c, cc, 0.6 * a); c.set_line_width(3); c.stroke()
    old = St.a; St.a *= a
    T(c, s, sz, 0, (-sz * 0.48 if he else 2), cc, 1.0, 1.0, w, maxw=860)
    if he: T(c, he, int(sz * 0.72), 0, sz * 0.62, cc, 1.0, 1.0, 700, maxw=860)
    St.a = old; c.restore()

def book(c, cx, cy, bw, bh, S, t, rot=-0.035):
    """navy hardback 'COLONIZATION 101' with page block, spine, gold frame"""
    c.save(); c.translate(cx, cy); c.rotate(rot + 0.01 * math.sin(t * 1.6)); s_ = 1 + 0.012 * math.sin(t * 2.2); c.scale(s_, s_)
    x0, y0 = -bw / 2, -bh / 2
    sa(c, P["navy"], 0.22); rr(c, x0 + 16, y0 + 26, bw, bh, 22); c.fill()
    for k in range(3):   # page block
        box(c, x0 + 14 + 5 * k, y0 + 12 + 4 * k, bw - 12, bh - 10, 16, P["card"], stroke=P["silver"], sw=2)
    g = cairo.LinearGradient(x0, y0, x0 + bw, y0 + bh); g.add_color_stop_rgb(0, 0.13, 0.25, 0.47); g.add_color_stop_rgb(1, *P["navy"][:3])
    rr(c, x0, y0, bw, bh, 22); c.set_source(g); c.fill()
    box(c, x0, y0, 54, bh, 0, (0.06, 0.15, 0.31), 1.0)   # spine
    for yy in (y0 + 70, y0 + bh - 90): box(c, x0 + 6, yy, 42, 14, 4, P["gold"])
    rr(c, x0 + 84, y0 + 34, bw - 118, bh - 68, 14); sa(c, P["gold"]); c.set_line_width(5); c.stroke()
    rr(c, x0 + 100, y0 + 50, bw - 150, bh - 100, 8); sa(c, P["gold2"], 0.7); c.set_line_width(2); c.stroke()
    mx = x0 + 54 + (bw - 54) / 2
    draw_emoji(c, "🌍", mx, y0 + bh * 0.2, bh * 0.13)
    T(c, S.get("book_en", "COLONIZATION"), int(bh * 0.085), mx, y0 + bh * 0.38, P["gold2"], 1.0, 1.0, 900, maxw=bw - 190)
    T(c, S.get("book_num", "101"), int(bh * 0.25), mx, y0 + bh * 0.57, P["gold"], 1.0, 1.0, 900, maxw=bw - 190)
    box(c, mx - 120, y0 + bh * 0.71, 240, 6, 3, P["gold2"])
    T(c, S.get("book_sub", ""), int(bh * 0.05), mx, y0 + bh * 0.79, P["white"], 1.0, 1.0, 700, maxw=bw - 190)
    T(c, S.get("book_he", ""), int(bh * 0.048), mx, y0 + bh * 0.86, P["gold2"], 1.0, 1.0, 700, maxw=bw - 190)
    c.restore()

# ------------------------------------------------------------------ scenes
def sc_cover(c, t, S):
    t0 = S["t0"]; y = 330
    a, s = PP(t, t0, S); h1 = block_h(S["en"], 108, 900, 940, 2)
    block(c, S["en"], 108, 540, y + h1 / 2, P["navy"], a, s * (1 + 0.01 * math.sin(t * 2.4)), hl=P["blue"], maxw=940, max_lines=2); y += h1
    u = ease((t - 0.15) / 0.9) if t > 0.15 else 0.0
    if u > 0: box(c, 540 - 340 * u, y + 4, 680 * u, 12, 6, P["gold"], a)
    y += 44; hh = block_h(S["he"], 62, 700, 940, 2); block(c, S["he"], 62, 540, y + hh / 2, P["blue"], a, s, w=700, maxw=940); y += hh
    bh = min(860, CONTENT_BOTTOM - y - 30); bw = bh * 0.74
    book(c, 540, y + 40 + bh / 2, bw, bh, S, t)
    if S.get("sticker"):   # sticker on the cover corner
        sx, sy = 540 + bw * 0.36, y + 40 + bh * 0.1
        c.save(); c.translate(sx, sy); c.rotate(0.22 + 0.02 * math.sin(t * 3)); circ(c, 0, 8, 98, P["navy"], 0.2); circ(c, 0, 0, 98, P["red"])
        circ(c, 0, 0, 84, P["white"], 0.0, stroke=P["white"], sw=4)
        T(c, S["sticker"], 40, 0, -12, P["white"], 1.0, 1.0, 900, maxw=150); T(c, S.get("sticker_he", ""), 32, 0, 32, P["white"], 1.0, 1.0, 700, maxw=150)
        c.restore()

def sc_ledger(c, t, S):
    y = heading(c, t, S); items = S["items"]; n = len(items)
    rh = min(250, (CONTENT_BOTTOM + 60 - y) / n); bh = rh - 22
    for k, it in enumerate(items):
        tk = S["times"].get(f"i{k}", S["t0"] + 0.4 + 1.2 * k)
        if t < tk - 0.07: continue
        a = fade_in(t, tk - 0.07, S, 0.2); u = ease((t - tk + 0.07) / 0.35); yy = y + rh * k + rh / 2
        old = St.a; St.a *= a; c.save(); c.translate(-240 * (1 - u), 0)
        shadow_box(c, 64, yy - bh / 2, 952, bh, 26, P["card"], stroke=P["silver"], sw=3, sh=6)
        box(c, 64, yy - bh / 2, 14, bh, 6, P["gold"])
        draw_emoji(c, icon_of(it), 150, yy - 8, 82)
        T(c, it["en"], 46, 588, yy - bh * 0.30, P["navy"], 1.0, 1.0, 800, hl=P["blue"], maxw=780)
        T(c, it["he"], 38, 588, yy + 2, P["gold_text"], 1.0, 1.0, 700, maxw=780)
        T(c, it["src"], 30, 588, yy + bh * 0.30, P["grey"], 1.0, 1.0, 700, hl=P["red"], maxw=780, src=True)
        c.restore(); St.a = old

def sc_grade(c, t, S):
    t0 = S["t0"]; tf = S["times"].get("f", t0 + 0.8)
    a, s = PP(t, t0 + 0.05, S)
    x0, y0, w, h = 110, 300, 860, 920
    old = St.a; St.a *= a; c.save(); c.translate(540, y0 + h / 2); c.scale(s, s); c.translate(-540, -(y0 + h / 2))
    notebook(c, x0, y0, w, h, lines_from=y0 + 250)
    T(c, "REPORT CARD", 56, 570, y0 + 90, P["navy"], 1.0, 1.0, 900, maxw=700); T(c, "תעודה", 44, 570, y0 + 160, P["blue"], 1.0, 1.0, 700)
    T(c, "Student: Israel", 54, 570, y0 + 300, P["navy"], 1.0, 1.0, 800, maxw=700); draw_emoji(c, "🇮🇱", 570 + 250, y0 + 300, 62)
    T(c, "Course: Colonization 101", 48, 570, y0 + 386, P["navy"], 1.0, 1.0, 700, maxw=720)
    T(c, "תלמידה: ישראל. קורס: קולוניזציה 101", 38, 570, y0 + 456, P["gold_text"], 1.0, 1.0, 700, maxw=720)
    c.restore(); St.a = old
    # the F
    gt = tf - 0.25
    if t >= gt or (S.get("hook") and gt <= RD.HOOK_GRACE):
        u = ease((t - gt) / 0.25); sc = lerp(1.9, 1.0, u); aa = ramp(t, gt, gt + 0.1)
        c.save(); c.translate(560, 1010); c.rotate(-0.1); c.scale(sc, sc)
        circ(c, 0, 0, 150, P["red"], 0.0, stroke=P["red"], sw=12); sa(c, P["red"], 0.9 * aa); c.arc(0, 0, 150, 0, 2 * math.pi); c.set_line_width(12); c.stroke()
        old = St.a; St.a *= aa; T(c, "F", 210, 0, 8, P["red"], 1.0, 1.0, 900); St.a = old; c.restore()
    stamp(c, S["stamp"], 58, 540, 1370, t, tf, S, rot=-0.05, he=S.get("stamp_he"))

def sc_lesson(c, t, S):
    t0 = S["t0"]; n = S["n"]; tx_ = S["times"].get("x", t0 + 1.2)
    a, s = PP(t, t0 + 0.02, S)
    pill(c, f"LESSON {n}", 46, 540, 272, P["gold"], P["white"], a, s, w=900)
    x0, y0, w, h = 64, 350, 952, CONTENT_BOTTOM - 350 + 20
    aa = fade_in(t, t0, S, 0.25); old = St.a; St.a *= aa
    notebook(c, x0, y0, w, h, lines_from=y0 + 300)
    T(c, f"שיעור {n}", 36, 900, y0 + 52, P["grey"], 1.0, 1.0, 700)
    # checkbox + rule
    box(c, 150, y0 + 90, 96, 96, 14, P["white"], stroke=P["navy"], sw=6)
    T(c, "The book says:", 34, 620, y0 + 70, P["grey"], 1.0, 1.0, 700, maxw=700)
    hr = block_h(S["rule"], 60, 900, 700, 2); block(c, S["rule"], 60, 620, y0 + 110 + hr / 2, P["navy"], 1.0, 1.0, hl=P["blue"], maxw=700, max_lines=2)
    hy = y0 + 110 + hr + 34; T(c, S["rule_he"], 44, 620, hy, P["blue"], 1.0, 1.0, 700, maxw=700)
    St.a = old
    red_x(c, 198, y0 + 138, 120, t, tx_, S)
    if t >= tx_:
        ia = ramp(t, tx_ + 0.15, tx_ + 0.4); T(c, "Israel:", 44, 210, hy + 110, P["red"], ia, 1.0, 900, maxw=260)
    # results
    def dims(r):
        sz, hz = (100, 62) if r.get("big") else (56, 42)
        return sz, hz, block_h(r["en"], sz, 900, 820, 3), block_h(r.get("he"), hz, 700, 820, 2)
    tot = sum(d[2] + d[3] + 52 for d in map(dims, S["results"])) - 52
    top, bot = hy + 160, CONTENT_BOTTOM - 70
    yy = max(top, top + (bot - top - tot) / 2 - 30)
    for k, r in enumerate(S["results"]):
        tk = S["times"].get(f"r{k}", tx_ + 0.5 + 1.0 * k); big = r.get("big")
        sz, hz = (100, 62) if big else (56, 42)
        he_ = block_h(r["en"], sz, 900, 820, 3); hh = block_h(r.get("he"), hz, 700, 820, 2)
        ra, rs = PP(t, tk, S)
        block(c, r["en"], sz, 560, yy + he_ / 2, P["navy"], ra, rs, hl=P["blue"], maxw=820, max_lines=3)
        if r.get("he"): block(c, r["he"], hz, 560, yy + he_ + 10 + hh / 2, P["gold_text"], ra, rs, w=700, maxw=820, max_lines=2)
        yy += he_ + hh + 52
    source(c, t, S)

def sc_verdict(c, t, S):
    y = heading(c, t, S); t0 = S["t0"]
    ts = t0 + 0.25
    if t >= ts:
        u = ease((t - ts) / 0.25); sc = lerp(1.8, 1.0, u); aa = ramp(t, ts, ts + 0.1)
        c.save(); c.translate(540, y + 190); c.rotate(-0.06); c.scale(sc, sc)
        sa(c, P["red"], 0.9 * aa); rr(c, -300, -150, 600, 300, 40); c.set_line_width(12); c.stroke()
        old = St.a; St.a *= aa; T(c, S["score"], 190, 0, 10, P["red"], 1.0, 1.0, 900); St.a = old; c.restore()
    y += 430
    te = S["times"].get("en", t0 + 0.3); a, s = PP(t, te, S); h = block_h(S["en"], 80, 900, 940, 2)
    block(c, S["en"], 80, 540, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=940); y += h + 10
    hh = block_h(S["he"], 54, 700, 940, 2); block(c, S["he"], 54, 540, y + hh / 2, P["blue"], a, s, w=700); y += hh + 70
    tsub = S["times"].get("sub", te + 1.5); a, s = PP(t, tsub, S); h = block_h(S["sub"], 64, 900, 940, 2)
    block(c, S["sub"], 64, 540, y + h / 2, P["navy"], a, s, hl=P["gold_text"], maxw=940); y += h + 10
    block(c, S["sub_he"], 50, 540, y + 40, P["blue"], a, s, w=700, maxw=940)

def arrow_down(c, x, y, a):
    c.save(); c.translate(x, y)
    for dx, dy, col_, al in ((6, 10, P["navy"], 0.2), (0, 0, P["blue"], 1.0)):
        c.save(); c.translate(dx, dy)
        rr(c, -30, -150, 60, 150, 26); sa(c, col_, al * a); c.fill()
        c.move_to(-95, -20); c.line_to(95, -20); c.line_to(0, 100); c.close_path(); sa(c, col_, al * a); c.fill()
        c.restore()
    c.restore()

def sc_ask(c, t, S):
    t0 = S["t0"]; y = 400
    a, s = PP(t, t0 + 0.05, S); h = block_h(S["en"], 112, 900, 940, 2)
    block(c, S["en"], 112, 540, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=940); y += h + 30
    tsb = S["times"].get("sub", t0 + 0.9); a2, s2 = PP(t, tsb, S); h = block_h(S["sub"], 84, 900, 940, 2)
    block(c, S["sub"], 84, 540, y + h / 2, P["navy"], a2, s2, hl=P["red"], maxw=940); y += h + 40
    hh = block_h(S["he"], 50, 700, 980, 2); block(c, S["he"], 50, 540, y + hh / 2, P["blue"], a2, s2, w=700, maxw=980); y += hh + 40
    ha = fade_in(t, tsb + 0.2, S, 0.25)
    arrow_down(c, 540, y + 170 + 18 * math.sin(t * 6.5), ha); y += 330
    a3, s3 = PP(t, tsb + 0.5, S); T(c, S.get("follow", ""), 58, 540, y + 20, P["navy"], a3, s3, 800, hl=P["gold_text"])

def sc_fair(c, t, S):
    """the fair line from the other side: icon, heading, two short paragraphs (EN + HE each) on a notebook page, source"""
    t0 = S["t0"]; y = 300
    a, s = PP(t, t0 + 0.05, S); draw_emoji(c, icon_of(S), 540, y + 60 + 6 * math.sin(t * 2.4), 120, a, s); y += 140
    h = block_h(S["en"], 84, 900, 940, 1); block(c, S["en"], 84, 540, y + h / 2, P["navy"], a, s, hl=P["blue"], maxw=940, max_lines=1); y += h
    u = ease((t - t0 - 0.15) / 0.8) if t > t0 + 0.15 else 0.0
    if u > 0: box(c, 540 - 300 * u, y + 6, 600 * u, 12, 6, P["gold"], a)
    y += 34; hh = block_h(S["he"], 52, 700, 940, 1); block(c, S["he"], 52, 540, y + hh / 2, P["blue"], a, s, w=700); y += hh + 30
    a1 = fade_in(t, S["times"].get("sub", t0 + 0.4), S, 0.25)
    notebook(c, 64, y, 952, CONTENT_BOTTOM - 34 - y, a1, holes=False, lines_from=y + 4000)
    yy = y + 40
    for k, (en, he) in enumerate(((S["sub"], S["sub_he"]), (S["sub2"], S["sub2_he"]))):
        tk = S["times"].get("sub" if k == 0 else "sub2", t0 + 0.6 + 3 * k); ra, rs = PP(t, tk, S)
        h = block_h(en, 54, 900, 830, 3); block(c, en, 54, 560, yy + h / 2, P["navy"], ra, rs, hl=P["red"], maxw=830, max_lines=3); yy += h + 12
        hh = block_h(he, 42, 700, 830, 2); block(c, he, 42, 560, yy + hh / 2, P["gold_text"], ra, rs, w=700, maxw=830, max_lines=2); yy += hh + 38
    source(c, t, S)
