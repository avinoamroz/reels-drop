"""cats_israel: deadpan satire, "Israel. Run by cats." Flat cats drawn in code (no photos, no people, no politicians),
one Israeli quirk per line in cat logic, a sourced real fact (Jerusalem street-cat density + feeding budget), and a
circular ending: "So when you land at Ben Gurion, welcome to..." cross-fades into the frame 0 hook.
    python3 engine.py [--frames t1,t2,...] [--out path.mp4]      (DIR: timing.json, mix.m4a)
Helpers (text, subtitles, frame loop) copied from jews_white/engine.py."""
import json, os, re, sys, math, subprocess
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ARGS = sys.argv[1:]
W, H, FPS = 1080, 1920, 30
FONTS = "/home/claude/vid/fonts"


def hx(h, a=1.0):
    h = h.lstrip("#"); return (int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return u * u * (3 - 2 * u)
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def eob(u, s=1.7):
    u = clamp(u) - 1; return 1 + (s + 1) * u ** 3 + s * u ** 2
def ramp(t, a, b): return ease((t - a) / max(1e-6, b - a))
def lerp(a, b, u): return a + (b - a) * u
def mixc(c1, c2, u): return tuple(lerp(a, b, u) for a, b in zip(c1[:3], c2[:3])) + (1.0,)

# brand book: night, navy, sky, gold
NIGHT, NAVY, NAVY2, SKY, GOLD = hx("#0B1426"), hx("#163261"), hx("#1E3F78"), hx("#45A4DD"), hx("#FFCD50")
INK, MUTE, RED, GREEN = hx("#F4F6FA"), hx("#9AA7BE"), hx("#E5484D"), hx("#3FBF7F")
WHITE = (1, 1, 1, 1)
# cat coats
GINGER, GINGER_D = hx("#F2A65A"), hx("#D9823A")
GREY, GREY_D = hx("#AEB8C8"), hx("#8592A6")
BLACK, BLACK_D = hx("#39415A"), hx("#262C3F")
CREAM, CREAM_D = hx("#F3E3C8"), hx("#D9C29E")
TUX, TUX_D = hx("#2E3550"), hx("#1F2538")
COATS = [(GINGER, GINGER_D), (GREY, GREY_D), (BLACK, BLACK_D), (CREAM, CREAM_D), (TUX, TUX_D)]
PINK = hx("#F49AA8")

_fc = {}
def font(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FONTS}/Heebo-{w}.ttf", int(sz), layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def pil2cairo(im):
    a = np.asarray(im.convert("RGBA")).astype(np.float32); al = a[:, :, 3] / 255
    bgra = np.empty(a.shape, np.uint8); bgra[:, :, 0] = a[:, :, 2] * al; bgra[:, :, 1] = a[:, :, 1] * al; bgra[:, :, 2] = a[:, :, 0] * al; bgra[:, :, 3] = a[:, :, 3]
    h, w = bgra.shape[:2]; st = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    buf = np.zeros((h, st), np.uint8); buf[:, :w * 4] = bgra.reshape(h, w * 4)
    return cairo.ImageSurface.create_for_data(bytearray(buf.tobytes()), cairo.FORMAT_ARGB32, w, h, st)
_tc = {}
def T(s, size, w=800, fill=(255, 255, 255, 255)):
    k = (s, size, w, fill)
    if k not in _tc:
        f = font(size, w); bb = f.getbbox(s, anchor="ls"); pad = 8
        im = Image.new("RGBA", (bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - bb[0], pad - bb[1]), s, font=f, fill=fill, anchor="ls")
        _tc[k] = (pil2cairo(im), pad - bb[0], pad - bb[1])
    return _tc[k]
def text(c, s, size, x, y, w=800, col=WHITE, a=1.0, align="c", sc=1.0):
    if a <= 0.01 or not s: return 0
    fill = tuple(int(255 * v) for v in col[:3]) + (255,)
    surf, ox, oy = T(s, size, w, fill); tw = font(size, w).getlength(s)
    x0 = x - tw / 2 if align == "c" else (x - tw if align == "r" else x)
    c.save(); c.translate(x, y); c.scale(sc, sc); c.translate(-x, -y)
    c.set_source_surface(surf, x0 - ox, y - oy); c.paint_with_alpha(min(1, a * col[3])); c.restore(); return tw
def fit(s, size, maxw, w=800, mn=36):
    while size > mn and font(size, w).getlength(s) > maxw: size -= 2
    return size
def head(c, s, size, y, col=WHITE, a=1.0, w=900, sc=1.0, dy=0):
    text(c, s, fit(s, size, 960, w, 64), 540, y + dy, w, col, a, sc=sc)
def rr(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2); c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi); c.close_path()
def src(c, col):
    c.set_source_rgba(*col[:3], col[3] if len(col) > 3 else 1)
def fillc(c, col, a=1.0):
    c.set_source_rgba(col[0], col[1], col[2], a); c.fill()
def glow(c, x, y, r, col, a):
    if a <= 0.01: return
    g = cairo.RadialGradient(x, y, 2, x, y, r); g.add_color_stop_rgba(0, *col[:3], a); g.add_color_stop_rgba(1, *col[:3], 0); c.set_source(g); c.paint()

# ------------------------------------------------------------------ timing
TM = json.load(open(f"{D}/timing.json")); LINES = TM["lines"]
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]).startswith(norm(word))]
    return ws[nth]["t1" if end else "t0"]
def lt(li): return LINES[li]["t0"]
END = round(LINES[-1]["t1"] + 1.0, 2)
NL = len(LINES)
CUT = [0.0] + [lt(i) - 0.15 for i in range(1, NL)] + [END]
def scene_at(t):
    for i in range(NL):
        if t < CUT[i + 1]: return i
    return NL - 1
T_FADE = END - 0.85
def sa(t, i, fin=0.25, fout=0.2):
    """alpha of scene i: fade in at its cut, out at the next"""
    return ramp(t, CUT[i], CUT[i] + fin) * (1 - ramp(t, CUT[i + 1] - fout, CUT[i + 1]))

# ------------------------------------------------------------------ the cat
def cat(c, x, y, s, coat=0, pose="sit", eyes="open", t=0.0, a=1.0, look=0.0, tie=None, ears_down=0.0, seed=0, stripes=False, mouth=None):
    """flat cat, feet line at (x, y), scale s (s=1: about 230 px tall sitting). pose sit | sleep | peek (head only, e.g. in a box)
    eyes open | closed | wide; look -1..1 shifts the pupils; tie colour draws a tie; ears_down 0..1 flattens the ears"""
    if a <= 0.01: return
    col, dk = COATS[coat] if isinstance(coat, int) else coat
    c.save(); c.translate(x, y); c.scale(s, s); c.push_group()
    ph = t * 2.0 + seed * 1.7
    if pose == "sleep":
        br = 1 + 0.03 * math.sin(t * 2.4 + seed)
        # tail wrap
        c.move_to(70, -18); c.curve_to(110, -10, 100, 30, 20, 22); c.curve_to(-40, 18, -80, 14, -96, 0)
        c.set_line_width(24); c.set_line_cap(cairo.LINE_CAP_ROUND); src(c, dk); c.stroke()
        c.save(); c.translate(0, -40); c.scale(1, br); c.arc(0, 0, 1, 0, 6.283); c.restore()
        c.save(); c.translate(0, -40); c.scale(108, 52 * br); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, col)
        hx_, hy = -62, -58
        for sx in (-1, 1):
            c.move_to(hx_ + sx * 30 - 12, hy - 20); c.line_to(hx_ + sx * 30, hy - 58); c.line_to(hx_ + sx * 30 + 14, hy - 22); c.close_path(); fillc(c, col)
        c.arc(hx_, hy, 44, 0, 6.283); fillc(c, col)
        for sx in (-1, 1):
            c.move_to(hx_ + sx * 18 - 10, hy - 2); c.curve_to(hx_ + sx * 18 - 4, hy + 5, hx_ + sx * 18 + 4, hy + 5, hx_ + sx * 18 + 10, hy - 2)
            c.set_line_width(4.5); src(c, TUX_D if coat not in (2, 4) else INK); c.stroke()
        c.move_to(hx_ - 5, hy + 12); c.line_to(hx_ + 5, hy + 12); c.line_to(hx_, hy + 18); c.close_path(); fillc(c, PINK)
        c.pop_group_to_source(); c.paint_with_alpha(a); c.restore(); return
    sw = math.sin(ph) * 0.5 + math.sin(ph * 0.37) * 0.3
    if pose == "sit":
        # tail
        c.move_to(52, -14); c.curve_to(120, -10, 128 + 20 * sw, -80, 100 + 30 * sw, -130)
        c.set_line_width(22); c.set_line_cap(cairo.LINE_CAP_ROUND); src(c, dk); c.stroke()
        # body
        c.move_to(-70, 0); c.curve_to(-82, -70, -58, -132, 0, -136); c.curve_to(58, -132, 82, -70, 70, 0); c.close_path(); fillc(c, col)
        c.move_to(-34, 0); c.curve_to(-40, -50, -24, -96, 0, -98); c.curve_to(24, -96, 40, -50, 34, 0); c.close_path()
        fillc(c, CREAM if coat in (0, 4) else mixc(col, INK, 0.35))
        if stripes:
            for k in range(3):
                c.move_to(-74 + k * 4, -40 - k * 26); c.line_to(-46, -46 - k * 26); c.set_line_width(9); src(c, dk); c.stroke()
                c.move_to(74 - k * 4, -40 - k * 26); c.line_to(46, -46 - k * 26); c.stroke()
        for sx in (-1, 1):   # front paws
            c.save(); c.translate(sx * 24, -4); c.scale(22, 12); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, CREAM if coat in (0, 4) else mixc(col, INK, 0.2))
        hy = -176
    else:            # peek: only the head, chin at y
        hy = -46
    # head
    bob = math.sin(t * 1.3 + seed) * 2
    hy += bob
    ed = ears_down
    for sx in (-1, 1):
        bx = sx * 40; tipx = sx * lerp(44, 78, ed); tipy = hy - lerp(76, 42, ed)
        c.move_to(bx - 22 * sx, hy - 34); c.line_to(tipx, tipy); c.line_to(bx + 22 * sx, hy - 14); c.close_path(); fillc(c, col)
        c.move_to(bx - 12 * sx, hy - 34); c.line_to(lerp(bx, tipx, 0.8), lerp(hy - 30, tipy, 0.8)); c.line_to(bx + 12 * sx, hy - 22); c.close_path(); fillc(c, PINK, 0.85)
    c.save(); c.translate(0, hy); c.scale(66, 58); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, col)
    if stripes:
        for k in (-1, 0, 1):
            c.move_to(k * 14, hy - 56); c.line_to(k * 12, hy - 36); c.set_line_width(8); src(c, dk); c.stroke()
    if coat == 4:   # tux muzzle
        c.save(); c.translate(0, hy + 22); c.scale(34, 24); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, INK)
    # eyes: blink every few seconds
    blink = (math.fmod(t + seed * 0.9 + 1.3, 3.7) < 0.14)
    for sx in (-1, 1):
        ex, ey = sx * 26, hy - 4
        if eyes == "closed" or (blink and eyes == "open"):
            c.move_to(ex - 12, ey); c.curve_to(ex - 5, ey + 7, ex + 5, ey + 7, ex + 12, ey); c.set_line_width(5); src(c, NIGHT); c.stroke()
        elif eyes == "half":
            c.save(); c.translate(ex, ey + 3); c.scale(13, 7); c.arc(0, 0, 1, 0, math.pi); c.restore(); fillc(c, NIGHT)
            c.move_to(ex - 15, ey); c.line_to(ex + 15, ey); c.set_line_width(5); src(c, dk); c.stroke()
        else:
            r = 15 if eyes == "wide" else 12
            c.save(); c.translate(ex, ey); c.scale(r, r * 1.15); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, hx("#C8E66A") if coat == 2 else WHITE)
            pr = 0.75 if eyes == "wide" else 0.6
            c.save(); c.translate(ex + look * 5, ey + 1); c.scale(r * pr * 0.8, r * pr * 1.1); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, NIGHT)
            c.arc(ex + look * 5 - 3, ey - 4, 3, 0, 6.283); fillc(c, WHITE)
    # nose, mouth, whiskers
    c.move_to(-7, hy + 14); c.line_to(7, hy + 14); c.line_to(0, hy + 22); c.close_path(); fillc(c, PINK)
    ink = NIGHT if coat not in (2, 4) else INK
    if mouth == "open":
        c.save(); c.translate(0, hy + 34); c.scale(10, 9); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, hx("#7A2333"))
    else:
        c.move_to(0, hy + 22); c.curve_to(-2, hy + 30, -10, hy + 31, -14, hy + 27)
        c.move_to(0, hy + 22); c.curve_to(2, hy + 30, 10, hy + 31, 14, hy + 27)
        c.set_line_width(3.5); src(c, ink); c.stroke()
    for sx in (-1, 1):
        for k in (-1, 0, 1):
            c.move_to(sx * 30, hy + 18 + k * 6); c.line_to(sx * 84, hy + 12 + k * 12); c.set_line_width(2.2); src(c, (ink[0], ink[1], ink[2], 0.6)); c.stroke()
    if tie:
        c.move_to(-10, hy + 56); c.line_to(10, hy + 56); c.line_to(14, hy + 112); c.line_to(0, hy + 128); c.line_to(-14, hy + 112); c.close_path(); fillc(c, tie)
        c.move_to(-12, hy + 50); c.line_to(12, hy + 50); c.line_to(8, hy + 64); c.line_to(-8, hy + 64); c.close_path(); fillc(c, mixc(tie, NIGHT, 0.25))
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()

def zzz(c, x, y, t, a, seed=0, size=44):
    for k in range(3):
        u = math.fmod(t * 0.45 + k / 3 + seed * 0.13, 1.0)
        text(c, "z", size * (0.7 + 0.5 * u), x + 30 * u + k * 8, y - 110 * u, 900, SKY, a * math.sin(math.pi * u))

def bubble(c, x, y, w, lines, a, size=64, tail=(-1, 1), col=WHITE, tcol=NIGHT, sc=1.0):
    """speech bubble centred at x, top y, lines of (text, colour) or str; tail toward (dx, dy) sign"""
    if a <= 0.01: return
    lh = size * 1.22; h = lh * len(lines) + size * 0.7
    c.save(); c.translate(x, y + h / 2); c.scale(sc, sc); c.translate(-x, -y - h / 2)
    c.push_group()
    rr(c, x - w / 2, y, w, h, 40); fillc(c, col)
    tx = x + tail[0] * w * 0.25
    c.move_to(tx - 26, y + h - 2); c.line_to(tx + tail[0] * 40, y + h + 54); c.line_to(tx + 26, y + h - 2); c.close_path(); fillc(c, col)
    for n, l in enumerate(lines):
        s, cl = (l, tcol) if isinstance(l, str) else l
        text(c, s, fit(s, size, w - 60, 800, 52), x, y + size * 0.35 + lh * (n + 0.82), 800, cl, 1.0)
    c.pop_group_to_source(); c.paint_with_alpha(a); c.restore()

def chip(c, s, y, a, size=40, col=GOLD, tcol=NIGHT):
    if a <= 0.01: return
    w_ = font(size, 900).getlength(s) + 56; h_ = size * 1.6
    rr(c, 540 - w_ / 2, y - h_ / 2, w_, h_, h_ / 2); fillc(c, col, a)
    text(c, s, size, 540, y + size * 0.36, 900, tcol, a)

# ------------------------------------------------------------------ scenery pieces
def skyline(c, a, y=1440, t=0.0):
    if a <= 0.01: return
    c.push_group()
    bl = [(60, 260, 130), (180, 420, 110), (300, 330, 90), (400, 520, 120), (530, 380, 100), (640, 470, 110), (760, 300, 90), (860, 400, 130), (990, 250, 90)]
    for bx, bh, bw in bl:
        rr(c, bx - bw / 2, y - bh, bw, bh + 10, 10); fillc(c, NAVY2)
        for r_ in range(int(bh / 46)):
            for q in range(int(bw / 34)):
                on = (math.sin(bx * 0.3 + r_ * 1.7 + q * 2.3 + t * 0.6) > 0.55)
                c.rectangle(bx - bw / 2 + 14 + q * 34, y - bh + 22 + r_ * 46, 16, 22); fillc(c, GOLD if on else NAVY, 0.9 if on else 1)
    c.rectangle(0, y, W, 40); fillc(c, NAVY)
    c.pop_group_to_source(); c.paint_with_alpha(a)

def knesset(c, a, t):
    """generic parliament: long low slab on columns, hemicycle of benches"""
    if a <= 0.01: return
    c.push_group()
    rr(c, 90, 690, 900, 70, 14); fillc(c, NAVY2)
    for k in range(12):
        c.rectangle(120 + k * 76, 760, 26, 120); fillc(c, mixc(NAVY2, INK, 0.25))
    c.rectangle(90, 880, 900, 18); fillc(c, NAVY2)
    text(c, "KNESSET", 44, 540, 742, 900, GOLD, 1.0)
    for r_ in range(3):   # benches
        y_ = 1080 + r_ * 150
        c.move_to(70, y_); c.curve_to(300, y_ + 40, 780, y_ + 40, 1010, y_)
        c.set_line_width(22); src(c, NAVY2); c.stroke()
    c.pop_group_to_source(); c.paint_with_alpha(a)
SEATS = [(x_, 1080 + r_ * 150 + 6 + 30 * math.sin(math.pi * (x_ - 70) / 940) * 0.9) for r_ in range(3) for x_ in (170, 355, 540, 725, 910)]

def window_sun(c, x, y, a, t):
    if a <= 0.01: return
    rr(c, x - 150, y - 200, 300, 380, 20); fillc(c, hx("#2A5A9A"), a)
    glow(c, x + 40, y - 80, 220, GOLD, 0.55 * a)
    c.arc(x + 40, y - 80, 56, 0, 6.283); fillc(c, GOLD, a)
    c.set_line_width(14); src(c, (*NAVY2[:3], a))
    rr(c, x - 150, y - 200, 300, 380, 20); c.stroke()
    c.move_to(x, y - 200); c.line_to(x, y + 180); c.move_to(x - 150, y - 10); c.line_to(x + 150, y - 10); c.stroke()
    rr(c, x - 180, y + 176, 360, 30, 10); fillc(c, mixc(NAVY2, INK, 0.3), a)   # sill

def box(c, x, y, w, h, a, col=hx("#C89A5E")):
    rr(c, x - w / 2, y - h, w, h, 8); fillc(c, col, a)
    c.move_to(x - w / 2, y - h); c.line_to(x - w / 2 - 24, y - h - 30); c.line_to(x - 10, y - h - 30); c.line_to(x, y - h); c.close_path(); fillc(c, mixc(col, WHITE, 0.15), a)
    c.move_to(x + w / 2, y - h); c.line_to(x + w / 2 + 24, y - h - 30); c.line_to(x + 10, y - h - 30); c.line_to(x, y - h); c.close_path(); fillc(c, mixc(col, NIGHT, 0.2), a)
    c.rectangle(x - 10, y - h, 20, h * 0.5); fillc(c, mixc(col, NIGHT, 0.12), a)

def phone(c, x, y, w, h, a):
    rr(c, x - w / 2, y, w, h, 56); fillc(c, hx("#0E1A30"), a)
    c.set_line_width(10); src(c, (*MUTE[:3], a)); rr(c, x - w / 2, y, w, h, 56); c.stroke()

def fridge(c, x, y, a, u, t):
    """y = floor; u door open 0..1"""
    if a <= 0.01: return
    fw, fh = 330, 560
    rr(c, x - fw / 2, y - fh, fw, fh, 26); fillc(c, hx("#DCE3EE"), a)
    # inside light
    if u > 0:
        rr(c, x - fw / 2 + 12, y - fh + 12, fw - 24, fh - 24, 18); fillc(c, hx("#FFF4C9"), a * u)
        glow(c, x, y - fh / 2, 380, GOLD, 0.35 * a * u)
        for k in range(3):
            c.rectangle(x - fw / 2 + 20, y - fh + 140 + k * 140, fw - 40, 8); fillc(c, hx("#E8D9A8"), a * u)
        # fish on a shelf
        c.save(); c.translate(x - 20, y - fh + 116); c.scale(1.0, 1.0)
        c.save(); c.scale(52, 26); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, SKY, a * u)
        c.move_to(46, 0); c.line_to(84, -24); c.line_to(84, 24); c.close_path(); fillc(c, SKY, a * u); c.restore()
    # door swinging (drawn as narrowing panel)
    dw = fw * (1 - 0.85 * u)
    rr(c, x - fw / 2 - (fw - dw) * 0.0 - (0 if u == 0 else 0), y - fh, dw, fh, 26)
    fillc(c, hx("#C5CEDC") if u > 0 else hx("#DCE3EE"), a)
    c.rectangle(x - fw / 2 + dw - 40, y - fh + 70, 14, 140); fillc(c, MUTE, a)
    c.rectangle(x - fw / 2, y - fh + 200, dw, 6); fillc(c, MUTE, a * 0.7)

def clock(c, x, y, s_, a, label):
    rr(c, x - 170, y - 70, 340, 140, 30); fillc(c, hx("#0E1A30"), a)
    text(c, label, 92, x, y + 34, 900, RED, a)

def bowl(c, x, y, a, fill_u, col=SKY):
    c.move_to(x - 80, y - 40); c.curve_to(x - 74, y + 6, x + 74, y + 6, x + 80, y - 40); c.close_path(); fillc(c, col, a)
    if fill_u > 0:
        for k in range(int(12 * fill_u)):
            kx = x - 56 + (k * 37) % 112; ky = y - 44 - (k // 4) * 10
            c.arc(kx, ky, 11, 0, 6.283); fillc(c, hx("#B87A3D"), a)
    c.save(); c.translate(x, y - 40); c.scale(80, 12); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, mixc(col, WHITE, 0.3), a)

# ------------------------------------------------------------------ scenes (i = script line)
CHIP = "SATIRE  |  IF CATS RAN ISRAEL"
def s_hook(c, t, a):
    if a <= 0.01: return
    text(c, "Israel.", 160, 540, 470, 900, WHITE, a)
    text(c, "Run by cats.", 140, 540, 640, 900, GOLD, a)
    u = eout(t / 1.2) if t < 3 else 1.0
    w_ = font(140, 900).getlength("Run by cats.")
    rr(c, 540 - w_ / 2, 672, w_ * u, 12, 6); fillc(c, GOLD, 0.9 * a)
    skyline(c, a, 1450, t)
    cat(c, 540, 1450, 2.05, 0, "sit", "open", t, a, look=math.sin(t * 0.9) * 0.8, stripes=True)
    cat(c, 175, 1452, 0.9, 2, "sit", "open", t, a, look=0.8, seed=2)
    cat(c, 905, 1452, 0.9, 1, "sit", "open", t, a, look=-0.8, seed=4)

def s_knesset(c, t, a, i):
    if a <= 0.01: return
    knesset(c, a, t)
    awake_k = 7
    for k, (x_, y_) in enumerate(SEATS):
        if i == 2 and k == awake_k: continue
        cat(c, x_, y_ + 4, 0.62, (k * 3) % 5, "sleep", t=t, a=a, seed=k)
        zzz(c, x_ - 40, y_ - 70, t, a * 0.8, seed=k, size=38)
    if i == 1:
        head(c, "The Knesset", 110, 420, WHITE, a)
        t0 = wt(1, "hundred") - 0.2; v = int(round(120 * eout((t - t0) / 0.9))) if t > t0 else 0
        text(c, str(v), 120, 400, 570, 900, GOLD, a * ramp(t, t0, t0 + 0.2), "r")
        text(c, "members", 84, 430, 570, 800, WHITE, a * ramp(t, t0, t0 + 0.2), "l")
        s1 = wt(1, "All"); text(c, "All asleep.", 84, 540, 650, 800, SKY, a * ramp(t, s1, s1 + 0.2), sc=eob(clamp((t - s1) / 0.35)) if t > s1 else 0.01)

def s_coalition_fall(c, t, a):
    if a <= 0.01: return
    s_knesset(c, t, a, 2)
    x_, y_ = 725, 1250
    # table in front
    rr(c, 600, 1430, 400, 26, 10); fillc(c, hx("#8A6A4A"), a)
    c.rectangle(630, 1456, 18, 80); fillc(c, hx("#6E5236"), a); c.rectangle(952, 1456, 18, 80); fillc(c, hx("#6E5236"), a)
    cat(c, 700, 1430, 1.0, 0, "sit", "open", t, a, look=1.0, seed=7, stripes=True)
    tp = wt(2, "knocked") ; u = clamp((t - tp) / 0.7)
    gx = 900 + 160 * u; gy = 1430 + (380 * u * u if u > 0 else 0); ang = 2.2 * u
    c.save(); c.translate(gx, gy); c.rotate(ang)
    c.move_to(-70, -190); c.line_to(70, -190); c.line_to(54, 0); c.line_to(-54, 0); c.close_path(); fillc(c, hx("#BFE3F7"), a * 0.92)
    c.rectangle(-62, -130, 124, 50); fillc(c, GOLD, a)
    text(c, "COALITION", 40, 0, -205, 900, GOLD, a * (1 - clamp(u * 3)))
    c.restore()
    head(c, "One is awake.", 104, 430, WHITE, a * (1 - ramp(t, tp, tp + 0.3)))
    head(c, "The coalition:", 96, 400, WHITE, a * ramp(t, tp, tp + 0.3))
    text(c, "gone.", 140, 540, 560, 900, GOLD, a * ramp(t, tp + 0.3, tp + 0.5), sc=max(0.01, eob(clamp((t - tp - 0.3) / 0.4))))

def s_talks(c, t, a):
    if a <= 0.01: return
    head(c, "Coalition talks", 110, 420, WHITE, a)
    window_sun(c, 790, 1060, a, t)
    rr(c, 90, 1420, 900, 30, 10); fillc(c, hx("#8A6A4A"), a)
    cat(c, 300, 1420, 1.25, 3, "sit", "half", t, a, look=1.0, seed=3)
    s0 = wt(3, "I"); s1 = wt(3, "if")
    bubble(c, 400, 560, 620, [("I'll join...", NIGHT)], a * ramp(t, s0, s0 + 0.2), 72, (-1, 1), sc=max(0.01, eob(clamp((t - s0) / 0.3))))
    bubble(c, 540, 700, 900, [("if I get the", NIGHT), ("sunny windowsill.", GINGER_D)], a * ramp(t, s1, s1 + 0.2), 72, (-1, 1))

def s_elections(c, t, a):
    if a <= 0.01: return
    s0 = lt(4); n = 1 + int(max(0, t - s0) / 0.42)
    head(c, "Elections", 120, 420, WHITE, a)
    text(c, "every 6 months", 90, 540, 545, 900, GOLD, a)
    # ballot box
    bx, by = 540, 1420
    rr(c, bx - 230, by - 300, 460, 300, 24); fillc(c, hx("#DCE3EE"), a)
    rr(c, bx - 120, by - 310, 240, 22, 10); fillc(c, NIGHT, a)
    text(c, f"Election #{n}", 64, bx, by - 130, 900, NAVY, a)
    for k in range(3):   # paper ballots dropping
        u = math.fmod((t - s0) * 1.4 + k / 3, 1.0)
        c.save(); c.translate(bx - 40 + k * 40, by - 560 + 250 * u); c.rotate(0.3 * math.sin(k + t))
        rr(c, -40, -26, 80, 52, 6); fillc(c, INK, a * (1 - u))
        c.arc(0, 0, 9, 0, 6.283); fillc(c, GINGER_D, a * (1 - u)); c.restore()
    s1 = wt(4, "Cats")
    lk = math.sin((t - s1) * 7) if t > s1 else 1.0
    cat(c, 180, 1440, 0.95, 1, "sit", "open", t, a, look=lk, seed=1)
    cat(c, 900, 1440, 0.95, 4, "sit", "open", t, a, look=-lk, seed=5)
    text(c, "Cats change their minds.", fit("Cats change their minds.", 72, 960, 800), 540, 700, 800, SKY, a * ramp(t, s1, s1 + 0.25))

def s_ayalon(c, t, a, i):
    if a <= 0.01: return
    # road in perspective
    c.move_to(380, 640); c.line_to(700, 640); c.line_to(1080, 1500); c.line_to(0, 1500); c.close_path(); fillc(c, hx("#26324A"), a)
    for lx in (0.333, 0.666):
        for k in range(9):
            v0 = k / 9; v1 = v0 + 0.05
            x0 = lerp(380 + 320 * lx, 0 + 1080 * lx, v0); y0 = lerp(640, 1500, v0)
            x1 = lerp(380 + 320 * lx, 0 + 1080 * lx, v1); y1 = lerp(640, 1500, v1)
            c.move_to(x0, y0); c.line_to(x1, y1); c.set_line_width(4 + 10 * v0); src(c, (*INK[:3], 0.6 * a)); c.stroke()
    # green road sign
    rr(c, 330, 560, 420, 110, 14); fillc(c, hx("#1E7A4E"), a)
    text(c, "AYALON  1", 60, 540, 636, 900, WHITE, a)
    rows = [(0.18, 0.42), (0.45, 0.62), (0.78, 0.86)]
    k = 0
    for v, sc_ in rows:
        for lx in (0.17, 0.5, 0.83):
            x_ = lerp(380 + 320 * lx, 1080 * lx, v); y_ = lerp(640, 1500, v)
            box(c, x_, y_, 190 * sc_ * 1.3, 120 * sc_ * 1.3, a)
            cat(c, x_, y_ - 120 * sc_ * 1.3 + 12, 0.85 * sc_ * 1.3, k % 5, "peek", "half" if k % 2 else "open", t, a, seed=k)
            k += 1
    if i == 5:
        head(c, "Rush hour", 116, 410, WHITE, a)
        s1 = wt(5, "Everyone"); text(c, "Everyone found a box.", fit("Everyone found a box.", 76, 960), 540, 500, 800, GOLD, a * ramp(t, s1, s1 + 0.25))

def s_waze(c, t, a):
    if a <= 0.01: return
    s_ayalon(c, t, a * 0.35, 6)
    phone(c, 540, 420, 600, 1060, a)
    rr(c, 270, 470, 540, 260, 34); fillc(c, SKY, a)
    text(c, "Navigation", 44, 540, 540, 800, NIGHT, a)
    s1 = wt(6, "just")
    text(c, "Just sit there.", fit("Just sit there.", 80, 500, 900), 540, 650, 900, WHITE, a * ramp(t, s1, s1 + 0.2))
    rr(c, 300, 780, 480, 300, 30); fillc(c, hx("#1C2A44"), a)
    text(c, "ETA", 44, 540, 850, 800, MUTE, a)
    text(c, "whenever", 72, 540, 950, 900, GOLD, a)
    text(c, "0 km/h", 52, 540, 1030, 800, INK, a)
    box(c, 540, 1400, 260, 170, a); cat(c, 540, 1240, 1.0, 0, "peek", "closed", t, a, stripes=True)

def s_hummus(c, t, a):
    if a <= 0.01: return
    s1 = wt(7, "tuna"); u = ramp(t, s1 - 0.1, s1 + 0.3)
    head(c, "The hummus war", 104, 400, WHITE, a)
    text(c, "is over.", 90, 540, 520, 800, WHITE, a * (1 - u))
    text(c, "It was tuna.", 120, 540, 540, 900, GOLD, a * u, sc=max(0.01, eob(clamp((t - s1 + 0.1) / 0.4))))
    cx, cy = 540, 1150
    c.save(); c.translate(cx, cy); c.scale(330, 120); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, hx("#DCE3EE"), a)
    c.save(); c.translate(cx, cy - 8); c.scale(260, 90); c.arc(0, 0, 1, 0, 6.283); c.restore()
    fillc(c, mixc(hx("#E9CF95"), hx("#C9D6E0"), u), a)
    # swirl / olive oil vs fish
    c.save(); c.translate(cx, cy - 8); c.scale(150, 46); c.arc(0, 0, 1, 0.3, 5.6); c.restore(); c.set_line_width(10); src(c, (*hx("#C9A43A")[:3], a * (1 - u))); c.stroke()
    for k in range(5):
        c.arc(cx - 90 + k * 46, cy - 14 + (k % 2) * 16, 10, 0, 6.283); fillc(c, hx("#7A6A2A"), a * (1 - u))
    if u > 0:   # a fish
        c.save(); c.translate(cx - 20, cy - 16); c.scale(1.6, 1.6)
        c.save(); c.scale(52, 24); c.arc(0, 0, 1, 0, 6.283); c.restore(); fillc(c, SKY, a * u)
        c.move_to(46, 0); c.line_to(86, -26); c.line_to(86, 26); c.close_path(); fillc(c, SKY, a * u)
        c.arc(-28, -6, 5, 0, 6.283); fillc(c, NIGHT, a * u); c.restore()
    lbl = "TUNA" if u > 0.5 else "HUMMUS"
    chip(c, lbl, 1340, a, 52, GOLD if u > 0.5 else INK)
    cat(c, 170, 1060, 0.9, 2, "peek", "wide", t, a, look=1.0, seed=3)
    cat(c, 910, 1060, 0.9, 0, "peek", "wide", t, a, look=-1.0, seed=6, stripes=True)

def s_shabbat(c, t, a):
    if a <= 0.01: return
    s0 = lt(8)
    g = cairo.LinearGradient(0, 700, 0, 1460); g.add_color_stop_rgba(0, *hx("#2B3F7A")[:3], a); g.add_color_stop_rgba(1, *hx("#E88A5A")[:3], a)
    c.rectangle(60, 700, 960, 760); c.set_source(g); c.fill()
    c.arc(540, 1200, 110, math.pi, 2 * math.pi); fillc(c, GOLD, a)
    for k in range(3):   # shops
        x0 = 90 + k * 310; rr(c, x0, 900, 280, 520, 14); fillc(c, NAVY2, a)
        text(c, ["FALAFEL", "KIOSK", "SHAWARMA"][k], 40, x0 + 140, 960, 900, GOLD, a)
        u = ramp(t, wt(8, "Everything") + 0.25 * k, wt(8, "Everything") + 0.25 * k + 0.6)
        rr(c, x0 + 20, 990, 240, 400, 10); fillc(c, hx("#F7D9A8"), a)
        sh = 400 * u
        c.rectangle(x0 + 20, 990, 240, sh); fillc(c, hx("#8592A6"), a)
        for r_ in range(int(sh / 24)):
            c.rectangle(x0 + 20, 990 + r_ * 24 + 20, 240, 3); fillc(c, hx("#6B778A"), a)
    c.rectangle(60, 1420, 960, 40); fillc(c, hx("#4A3A55"), a)
    for k, x_ in enumerate((250, 560, 860)):
        cat(c, x_, 1450, 0.75, k + 1, "sleep", t=t, a=a, seed=k)
        zzz(c, x_ - 40, 1390, t, a, seed=k)
    head(c, "Shabbat", 130, 420, GOLD, a)
    s1 = wt(8, "Everything"); s2 = wt(8, "Nobody")
    text(c, "Everything closes.", fit("Everything closes.", 80, 960), 540, 540, 800, WHITE, a * ramp(t, s1, s1 + 0.2) * (1 - ramp(t, s2, s2 + 0.2)))
    text(c, "Nobody notices.", 84, 540, 540, 800, SKY, a * ramp(t, s2, s2 + 0.2))

def s_direct(c, t, a):
    if a <= 0.01: return
    head(c, "Israeli directness", 104, 400, WHITE, a)
    s1 = wt(9, "Why"); s2 = wt(9, "Also")
    bubble(c, 400, 470, 640, [("Why aren't you", NIGHT), ("married?", NIGHT)], a * ramp(t, s1, s1 + 0.2), 70, (-1, 1), sc=max(0.01, eob(clamp((t - s1) / 0.3))))
    bubble(c, 640, 790, 680, [("Also, your fur", NIGHT), ("is wrong.", hx("#C2332E"))], a * ramp(t, s2, s2 + 0.2), 70, (1, 1), sc=max(0.01, eob(clamp((t - s2) / 0.3))))
    rr(c, 60, 1440, 960, 20, 10); fillc(c, NAVY2, a)
    cat(c, 270, 1440, 1.25, 3, "sit", "open", t, a, look=1.0, seed=2)
    ed = ramp(t, s2 + 0.3, s2 + 0.7)
    cat(c, 820, 1440, 1.25, 1, "sit", "wide" if ed > 0.5 else "open", t, a, look=-1.0, ears_down=ed, seed=8)

def s_startup(c, t, a):
    if a <= 0.01: return
    head(c, "Startup Nation", 96, 400, WHITE, a)
    s1 = wt(10, "six") - 0.1; v = int(round(6000 * eout((t - s1) / 1.0), -1)) if t > s1 else 0
    text(c, f"{v:,} apps", 130, 540, 540, 900, GOLD, a * ramp(t, s1, s1 + 0.2))
    s2 = wt(10, "All"); s3 = wt(10, "fridge")
    text(c, "All of them do one thing:", fit("All of them do one thing:", 64, 960), 540, 640, 800, INK, a * ramp(t, s2, s2 + 0.2))
    clock(c, 540, 770, 1, a * ramp(t, s2, s2 + 0.3), "4:00 AM")
    u = ramp(t, s3, s3 + 0.6)
    fridge(c, 790, 1460, a, u, t)
    cat(c, 420, 1460, 1.1, 0, "sit", "wide" if u > 0.3 else "open", t, a, look=1.0, stripes=True, seed=4)
    phone(c, 190, 900, 200, 320, a * ramp(t, s2, s2 + 0.3))
    rr(c, 120, 1030, 140, 70, 20); fillc(c, SKY, a * ramp(t, s2, s2 + 0.3))
    text(c, "OPEN", 36, 190, 1078, 900, WHITE, a * ramp(t, s2, s2 + 0.3))

def s_laser(c, t, a):
    if a <= 0.01: return
    s0 = lt(11)
    for k in range(30):
        sx = (k * 137) % 1000 + 40; sy = 700 + (k * 61) % 520
        c.arc(sx, sy, 2.5, 0, 6.283); fillc(c, INK, a * (0.4 + 0.4 * math.sin(t * 2 + k)))
    q = (t - s0) * 1.6
    dx, dy = 540 + 360 * math.sin(q), 960 + 200 * math.sin(2 * q)
    glow(c, dx, dy, 70, RED, 0.8 * a); c.arc(dx, dy, 16, 0, 6.283); fillc(c, hx("#FF6B6B"), a)
    head(c, "Air defence", 116, 420, WHITE, a)
    s1 = wt(11, "one"); text(c, "1 laser pointer", 96, 540, 560, 900, GOLD, a * ramp(t, s1, s1 + 0.2))
    for k, x_ in enumerate((140, 340, 540, 740, 940)):
        lk = clamp((dx - x_) / 220) if dx > x_ else -clamp((x_ - dx) / 220)
        cat(c, x_, 1450, 0.78, k % 5, "sit", "wide", t, a, look=lk, seed=k)

def s_pm(c, t, a):
    if a <= 0.01: return
    head(c, "The Prime Minister", 96, 400, WHITE, a)
    s1 = wt(12, "Pooch"); s2 = wt(12, "term")
    text(c, "Pooch.", 150, 540, 540, 900, GOLD, a * ramp(t, s1, s1 + 0.15), sc=max(0.01, eob(clamp((t - s1) / 0.35))))
    chip(c, "Term ends: next nap", 640, a * ramp(t, s2, s2 + 0.25), 52, SKY, WHITE)
    # flags-free generic podium with a paw seal
    eyes = "half" if t > s2 + 0.9 else "open"
    if t > s2 + 1.6: eyes = "closed"
    cat(c, 540, 1180, 1.6, 0, "sit", eyes, t, a, look=0.0, tie=SKY, stripes=True, mouth="open" if 0 < t - (s2 + 1.0) < 0.6 else None)
    c.move_to(330, 1120); c.line_to(750, 1120); c.line_to(700, 1460); c.line_to(380, 1460); c.close_path(); fillc(c, NAVY2, a)
    c.arc(540, 1260, 70, 0, 6.283); fillc(c, GOLD, a)
    for k, (px, py, r) in enumerate([(0, 14, 22), (-26, -14, 11), (-9, -26, 11), (9, -26, 11), (26, -14, 11)]):
        c.arc(540 + px, 1260 + py, r, 0, 6.283); fillc(c, NAVY2, a)
    rr(c, 330, 1100, 420, 30, 10); fillc(c, mixc(NAVY2, INK, 0.3), a)
    if eyes == "closed": zzz(c, 600, 820, t, a)

SRC_FACT = "Prof. Yoram Yom-Tov, via The Times of Israel, 2019"
SRC_FEED = "Jerusalem Municipality, via The Times of Israel, 2019"
def s_fact(c, t, a):
    if a <= 0.01: return
    chip(c, "REAL FACT", 340, a, 44)
    s1 = wt(13, "Jerusalem"); s2 = wt(13, "two") - 0.1
    text(c, "Jerusalem", 96, 540, 470, 900, WHITE, a * ramp(t, s1, s1 + 0.2))
    v = int(round(2000 * eout((t - s2) / 1.2), -1)) if t > s2 else 0
    text(c, f"~{v:,}", 190, 540, 650, 900, GOLD, a * ramp(t, s2, s2 + 0.2))
    text(c, "street cats per km²", 72, 540, 750, 800, INK, a * ramp(t, s2, s2 + 0.2))
    # one square km, filling with cats (dots), 1 dot = 20 cats
    x0, y0, S, HH = 170, 820, 740, 500
    rr(c, x0, y0, S, HH, 24); fillc(c, NAVY2, a)
    c.set_line_width(4); src(c, (*SKY[:3], a)); rr(c, x0, y0, S, HH, 24); c.stroke()
    n = int(100 * clamp(v / 2000))
    for k in range(n):
        gx = x0 + 50 + (k % 10) * 71; gy = y0 + 44 + (k // 10) * 46
        cat(c, gx, gy + 18, 0.15, k % 5, "peek", "open", t, a, seed=k)
    text(c, "1 cat face = 20 cats", 40, 540, y0 + HH + 58, 700, MUTE, a)
    text(c, SRC_FACT, fit(SRC_FACT, 38, 960, 700, 36), 540, 1460, 700, MUTE, a)

def s_feed(c, t, a):
    if a <= 0.01: return
    head(c, "And the city", 104, 400, WHITE, a)
    text(c, "pays to feed them.", fit("pays to feed them.", 96, 960, 900), 540, 520, 900, WHITE, a)
    s1 = wt(14, "feed")
    text(c, "NIS 100,000", 120, 540, 700, 900, GOLD, a * ramp(t, s1, s1 + 0.25), sc=max(0.01, eob(clamp((t - s1) / 0.35))))
    text(c, "cat food budget, one year", 56, 540, 780, 800, INK, a * ramp(t, s1, s1 + 0.25))
    for k, x_ in enumerate((200, 420, 660, 880)):
        u = ramp(t, lt(14) + 0.2 * k, lt(14) + 0.2 * k + 0.5)
        bowl(c, x_, 1440, a, u, [SKY, GOLD, GREEN, RED][k])
        cat(c, x_, 1330, 0.9, k % 5, "peek", "closed" if u > 0.9 else "open", t, a * u, seed=k, stripes=(k == 0))
    text(c, SRC_FEED, fit(SRC_FEED, 38, 960, 700, 36), 540, 1510, 700, MUTE, a)

def s_welcome(c, t, a):
    if a <= 0.01: return
    rr(c, 90, 360, 900, 190, 26); fillc(c, hx("#111B2E"), a)
    text(c, "ARRIVALS", 44, 540, 420, 800, GOLD, a)
    text(c, "Ben Gurion Airport", fit("Ben Gurion Airport", 84, 840, 900), 540, 515, 900, WHITE, a)
    s1 = wt(15, "welcome")
    text(c, "Welcome to...", 120, 540, 700, 900, GOLD, a * ramp(t, s1, s1 + 0.25))
    skyline(c, a, 1450, t)
    # a little plane landing
    u = clamp((t - lt(15)) / 2.2)
    px, py = lerp(-120, 1200, u), lerp(860, 1040, u)
    c.save(); c.translate(px, py); c.rotate(0.12)
    rr(c, -110, -18, 220, 36, 18); fillc(c, INK, a); c.move_to(-20, 0); c.line_to(30, 0); c.line_to(-30, 70); c.line_to(-60, 70); c.close_path(); fillc(c, SKY, a)
    c.move_to(-100, -10); c.line_to(-80, -10); c.line_to(-110, -56); c.line_to(-126, -56); c.close_path(); fillc(c, SKY, a)
    c.restore()
    cat(c, 540, 1450, 2.05, 0, "sit", "open", t, a, look=math.sin(t * 0.9) * 0.8, stripes=True)

SCENES = {0: s_hook, 1: lambda c, t, a: s_knesset(c, t, a, 1), 2: s_coalition_fall, 3: s_talks, 4: s_elections,
          5: lambda c, t, a: s_ayalon(c, t, a, 5), 6: s_waze, 7: s_hummus, 8: s_shabbat, 9: s_direct, 10: s_startup,
          11: s_laser, 12: s_pm, 13: s_fact, 14: s_feed, 15: s_welcome}

# ------------------------------------------------------------------ subtitles
REPL = [("a hundred and twenty", "120"), ("six months", "6 months"), ("six thousand", "6,000"), ("four a.m", "4 am"),
        ("two thousand", "2,000")]
SUB_BOTTOM = 1690
def build_subs():
    items = []
    for L in LINES:
        ws = [dict(w) for w in L["words"]]
        toks = []; i = 0
        while i < len(ws):
            hit = None
            for a_, b_ in REPL:
                n = len(a_.split())
                if " ".join(w["w"] for w in ws[i:i + n]).lower().rstrip(".,") == a_.lower(): hit = (n, b_); break
            if hit:
                n, b_ = hit; last = ws[i + n - 1]["w"]; p = last[-1] if last[-1] in ".,:?!" and not last.endswith("a.m") else ""
                toks.append(dict(w=b_ + p, t0=ws[i]["t0"], t1=ws[i + n - 1]["t1"])); i += n
            else: toks.append(ws[i]); i += 1
        cur = []
        for k, tk in enumerate(toks):
            cur.append(tk)
            brk = tk["w"][-1] in ".,:?!" and len(cur) >= 2
            if len(cur) >= 6 or brk or k == len(toks) - 1:
                items.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.12, " ".join(x["w"] for x in cur)]); cur = []
    for k in range(len(items) - 1):
        b0 = items[k + 1][0]
        items[k][1] = b0 if b0 - items[k][1] < 0.25 else min(items[k][1], b0)
    for it in items: it[2] = it[2].rstrip(",:;").replace("...", "")
    return items
SUBS = build_subs(); SUBF = 54
def draw_subs(c, t):
    for a0, a1, s in SUBS:
        if a0 <= t < a1:
            f = font(SUBF, 800); words = s.split(); lines = []; cur = ""
            for w_ in words:
                tst = (cur + " " + w_).strip()
                if f.getlength(tst) <= 900: cur = tst
                else: lines.append(cur); cur = w_
            lines.append(cur); lh = 66; bh = lh * len(lines) + 26
            wmax = max(f.getlength(l) for l in lines) + 56; y0 = SUB_BOTTOM - bh
            rr(c, 540 - wmax / 2, y0, wmax, bh, 24); c.set_source_rgba(0.03, 0.06, 0.13, 0.85); c.fill()
            for n, l in enumerate(lines): text(c, l, SUBF, 540, y0 + 13 + lh * n + 49, 800, WHITE, 1.0)
            return

# ------------------------------------------------------------------ frame
def bg_surface():
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgba(0, *NIGHT[:3], 1); g.add_color_stop_rgba(0.65, *NAVY[:3], 1); g.add_color_stop_rgba(1, *hx("#1B3C8C")[:3], 1)
    c.set_source(g); c.paint(); glow(c, 540, 1050, 760, SKY, 0.10); return s
BG = bg_surface()
def frame(t):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(s)
    c.set_source_surface(BG, 0, 0); c.paint()
    i = scene_at(t)
    for j in (i - 1, i, i + 1):
        if 0 <= j < NL:
            a = 1.0 if (j == 0 and t < CUT[1] - 0.2) else sa(t, j)
            if j == NL - 1: a = ramp(t, CUT[j], CUT[j] + 0.25)
            if a > 0.01: SCENES[j](c, t, a)
    text(c, CHIP, 36, 540, 272, 800, MUTE, 0.9)
    draw_subs(c, t)
    s.flush()
    a = np.ndarray((H, s.get_stride() // 4, 4), np.uint8, s.get_data())[:, :W, :3][:, :, ::-1]
    return np.ascontiguousarray(a)

if __name__ == "__main__":
    if "--frames" in ARGS:
        out = ARGS[ARGS.index("--qa") + 1] if "--qa" in ARGS else f"{D}/qa"; os.makedirs(out, exist_ok=True)
        F0 = frame(0.0)
        for x in ARGS[ARGS.index("--frames") + 1].split(","):
            tt = float(x); img = frame(tt)
            if tt >= T_FADE:
                u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
            Image.fromarray(img).save(f"{out}/f_{tt:06.2f}.png")
        print("END", END); sys.exit()
    outp = ARGS[ARGS.index("--out") + 1] if "--out" in ARGS else f"{D}/out.mp4"
    n = int(round(END * FPS)); F0 = frame(0.0)
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-i", f"{D}/mix.m4a", "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
                          "-c:a", "copy", "-t", f"{END:.3f}", "-movflags", "+faststart", outp], stdin=subprocess.PIPE)
    for i in range(n):
        tt = i / FPS; img = frame(tt)
        if tt >= T_FADE:
            u = ease((tt - T_FADE) / (END - T_FADE)); img = (img.astype(np.float32) * (1 - u) + F0.astype(np.float32) * u).astype(np.uint8)
        p.stdin.write(img.tobytes())
        if i % 150 == 0: print("frame", i, "/", n, flush=True)
    p.stdin.close(); p.wait(); print("wrote", outp, END)
