"""house voice chain on vo/bible_map_vo.wav (atempo 1.13), long pauses trimmed -> vo_final.wav (48k) + timing.json
(copy of mena_variants/voice_step.py + gap trim: line gaps capped at 0.36 s, in-line pauses at 0.30 s, cut in the middle of the silence)"""
import sys, json, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/reelkit")
import voice
from clean_vo import clean as clean_vo
D = sys.argv[1]
voice.TEMPO = 1.13
W = json.load(open(f"{D}/vo/bible_map_vo_words.json")); lines = voice.read_script(f"{D}/tts.txt")
dry = voice.chain_dry(f"{D}/vo/bible_map_vo.wav"); cl = clean_vo(dry, voice.SR)
y, _ = voice.restore_soft(cl, dry, voice._speech_spans_pre(dry)); vo = voice.post(y)
SR = voice.SR
k = (len(vo) / SR - voice.LEAD) / (len(dry) / SR); tm = lambda x: voice.LEAD + x * k
out, i = [], 0
for li, l in enumerate(lines):
    n = len(l.split()); ws = W[i:i + n]; i += n
    out.append(dict(i=li, text=l, words=[dict(w=w["word"], t0=tm(w["start"]), t1=tm(w["end"])) for w in ws]))
assert i == len(W)
# gap trim
cuts = []
for li, L in enumerate(out):
    ws = L["words"]
    for a, b in zip(ws, ws[1:]):
        d = b["t0"] - a["t1"]
        if d > 0.30: cuts.append((a["t1"], b["t0"], 0.30))
    if li + 1 < len(out):
        a, b = ws[-1], out[li + 1]["words"][0]; d = b["t0"] - a["t1"]
        if d > 0.36: cuts.append((a["t1"], b["t0"], 0.36))
segs, pos, removed = [], 0, []
xf = int(0.012 * SR)
for g0, g1, cap in cuts:
    ex = (g1 - g0) - cap; mid = (g0 + g1) / 2
    c0, c1 = int((mid - ex / 2) * SR), int((mid + ex / 2) * SR)
    segs.append(vo[pos:c0]); pos = c1; removed.append((mid - ex / 2, ex + xf / SR))
segs.append(vo[pos:])
res = segs[0]
for s in segs[1:]:
    if len(res) > xf and len(s) > xf:
        r = np.linspace(1, 0, xf); sh = (slice(None),) + (None,) * (res.ndim - 1)
        mixz = res[-xf:] * r[sh] + s[:xf] * (1 - r)[sh]
        res = np.concatenate([res[:-xf], mixz, s[xf:]])
    else: res = np.concatenate([res, s])
def remap(t):
    sh = 0.0
    for c0, ex in removed:
        if t > c0 + ex: sh += ex
        elif t > c0: sh += t - c0
    return round(t - sh, 3)
for L in out:
    for w in L["words"]: w["t0"], w["t1"] = remap(w["t0"]), remap(w["t1"])
    L["t0"], L["t1"] = L["words"][0]["t0"], L["words"][-1]["t1"]
sf.write(f"{D}/vo_final.wav", res.astype(np.float32), SR)
json.dump(dict(dur=len(res) / SR, lines=out), open(f"{D}/timing.json", "w"), indent=0)
print("dur", round(len(res) / SR, 2), "cut", round(sum(e for _, e in removed), 2))
for L in out: print(L["i"], L["t0"], L["t1"], L["text"])
