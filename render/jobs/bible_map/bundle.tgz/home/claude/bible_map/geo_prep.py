"""geo/geo.json: NE 50m countries in the region (simplified), whole land / West Bank+Gaza from empires_israel/geo, rivers from NE 10m."""
import json
from shapely.geometry import shape, mapping, box
B = box(15, 8, 66, 50)
NE = json.load(open("/home/claude/bro_meter/geo/ne_50m_admin_0_countries.geojson"))
out = {"countries": {}, "rivers": {}}
for f in NE["features"]:
    g = shape(f["geometry"])
    if not g.intersects(B): continue
    iso = f["properties"].get("ADM0_A3") or f["properties"].get("ISO_A3")
    if iso in ("ISR", "PSX", "PSE"): continue
    out["countries"][iso] = mapping(g.intersection(B.buffer(5)).simplify(0.02, preserve_topology=True))
E = json.load(open("/home/claude/empires_israel/geo/geo.json"))
out["land"] = E["israel"]; out["psx"] = E["psx"]; out["gaza"] = E["gaza"]
R = json.load(open("/home/claude/exodus_route/cache/ne_10m_rivers_lake_centerlines.geojson"))
for f in R["features"]:
    n = (f["properties"].get("name") or "")
    for k in ("Nile", "Euphrates", "Tigris", "Jordan"):
        if n.startswith(k) or n == k:
            g = shape(f["geometry"]).intersection(B)
            if not g.is_empty: out["rivers"].setdefault(k, []).append(mapping(g.simplify(0.01)))
json.dump(out, open("geo/geo.json", "w"))
print(len(out["countries"]), {k: len(v) for k, v in out["rivers"].items()})
