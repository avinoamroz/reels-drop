"""mix_step.py: loop-clean doc_piano bed + SFX under vo_final.wav -> mix.m4a (-14 LUFS, -1.5 dBTP). Recipe from crime_punish/mix_step.py."""
import sys, os, json, numpy as np, soundfile as sf, subprocess
sys.path.insert(0, "/home/claude/reelkit")
import mix as MX
D = "/home/claude/bible_map"
E = json.load(open(f"{D}/events.json")); dur = E["END"]
vo, sr = sf.read(f"{D}/vo_final.wav")
m = MX._mod(*MX.BEDS["doc_piano"][:2]); n = int(dur * MX.SR); f = int(0.8 * MX.SR)
x = np.asarray(m.doc_music(dur + 4.5), np.float64)
if x.ndim == 1: x = np.vstack([x, x])
music = x[:, :n].copy()
music[:, :f] = x[:, :f] * np.sin(np.linspace(0, np.pi / 2, f)) + x[:, n:n + f] * np.cos(np.linspace(0, np.pi / 2, f))
music /= np.abs(music).max() + 1e-12
ev = [tuple(e) for e in E["events"]]
rep = MX.mix(vo, dur, music, ev, f"{D}/mix.wav", music_db=-19.0)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", f"{D}/mix.wav", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", f"{D}/mix.m4a"], check=True)
os.remove(f"{D}/mix.wav"); print(rep)
