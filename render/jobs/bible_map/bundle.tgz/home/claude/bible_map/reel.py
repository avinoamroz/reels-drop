"""bible_map: the Hebrew Bible's story on one map, book by book (Tanakh count, 24 books).
Sibling of "3,000 years. Who lived in this land?": map + book counter + big labels, routes drawn as the story moves,
17 named places tallied by today's borders at the end, circular lead-in back to the hook.
usage: python3 reel.py --snaps 0,3.2,...   (PNG keyframes to snaps/)
       python3 reel.py --out /home/claude/bible_map/bible_map.mp4   (needs mix.m4a)"""
import sys, os, math, json, subprocess, argparse, re
import numpy as np, cairo
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = "/home/claude/bible_map"
ap = argparse.ArgumentParser(); ap.add_argument("--snaps"); ap.add_argument("--out"); ap.add_argument("--jobs", type=int, default=0); ap.add_argument("--events", action="store_true")
A = ap.parse_args()
W, H, FPS = 1080, 1920, 30
FD = "/home/claude/vid/fonts"

# ------------------------------------------------------------------ timing
T = json.load(open(f"{D}/timing.json")); LINES = T["lines"]
END = round(LINES[-1]["t1"] + 0.55, 2); LOOP = 0.45
def norm(s): return re.sub(r"[^a-z0-9]", "", s.lower())
def wt(li, word, nth=0, end=False):
    ws = [w for w in LINES[li]["words"] if norm(w["w"]) == norm(word)]
    return ws[nth]["t1" if end else "t0"]
def L0(li): return LINES[li]["t0"]
def L1(li): return LINES[li]["t1"]
def clamp(x): return min(1.0, max(0.0, x))
def ease(u): u = clamp(u); return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2
def eout(u): u = clamp(u); return 1 - (1 - u) ** 3
def seg(t, t0, t1): return ease((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t0)
def win(t, t0, t1, a=0.3, b=0.3): return seg(t, t0, t0 + a) * (1 - seg(t, t1 - b, t1))
def lerp(a, b, u): return a + (b - a) * u
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def hf(h): return tuple(c / 255 for c in hx(h))

NAVY, NAVY_D, NAVY_L, SKY, YELLOW, WHITE = "#163261", "#0B1730", "#2749D3", "#45A4DD", "#FFD23F", "#FFFFFF"
LAND, LAND_E, GOLD, WB, GREEN = "#2E4E80", "#5878AA", "#D2AA53", "#B8923F", (46 / 255, 204 / 255, 113 / 255)
LGREY = "#C9D1DC"

# ------------------------------------------------------------------ fonts / text
_fc = {}
def F(sz, w=800):
    k = (int(sz), w)
    if k not in _fc: _fc[k] = ImageFont.truetype(f"{FD}/Heebo-{w}.ttf", k[0], layout_engine=ImageFont.Layout.RAQM)
    return _fc[k]
def fit(s, sz, w=800, maxw=960):
    while F(sz, w).getlength(s) > maxw and sz > 40: sz -= 2
    return sz
def text(im, s, x, y, sz, col=WHITE, a=1.0, w=800, anchor="mm", halo=True, scale=1.0, rtl=False):
    """text with a soft dark halo; scale pops around the anchor"""
    if a <= 0.01: return
    sz2 = max(8, int(round(sz * scale))); f = F(sz2, w)
    kw = dict(direction="rtl", language="he") if rtl else {}
    bb = ImageDraw.Draw(im).textbbox((0, 0), s, font=f, anchor="lt", **kw)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]; pad = 30
    lay = Image.new("RGBA", (tw + 2 * pad, th + 2 * pad), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
    d.text((pad - bb[0], pad - bb[1]), s, font=f, fill=hx(col) + (255,), anchor="lt", **kw)
    al = lay.getchannel("A")
    if halo:
        sh = al.filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(min(255, v * 1.6 * a)))
        sl = Image.new("RGBA", lay.size, (5, 10, 22, 0)); sl.putalpha(sh)
    lay.putalpha(al.point(lambda v: int(v * a)))
    ax = {"l": 0, "m": 0.5, "r": 1}[anchor[0]]; ay = {"t": 0, "m": 0.5, "b": 1}[anchor[1]]
    ox, oy = int(x - pad - tw * ax), int(y - pad - th * ay)
    if halo: im.alpha_composite(sl, (ox, oy)) if ox >= 0 and oy >= 0 else _paste(im, sl, ox, oy)
    _paste(im, lay, ox, oy)
def _paste(im, lay, ox, oy):
    x0, y0 = max(0, ox), max(0, oy); x1, y1 = min(W, ox + lay.width), min(H, oy + lay.height)
    if x1 > x0 and y1 > y0: im.alpha_composite(lay.crop((x0 - ox, y0 - oy, x1 - ox, y1 - oy)), (x0, y0))
# ------------------------------------------------------------------ camera (equirectangular, cos-lat scaled)
class Cam:
    def __init__(s, lon, lat, wdeg, cy=1000):
        s.lon, s.lat, s.wdeg, s.cy = lon, lat, wdeg, cy
    @property
    def k(s): return W / (s.wdeg * math.cos(math.radians(s.lat)))
def cl(a, b, u):
    return Cam(lerp(a.lon, b.lon, u), lerp(a.lat, b.lat, u), math.exp(lerp(math.log(a.wdeg), math.log(b.wdeg), u)), lerp(a.cy, b.cy, u))
def xy(c, lon, lat):
    k = c.k; return 540 + (lon - c.lon) * k * math.cos(math.radians(c.lat)), c.cy - (lat - c.lat) * k

# ------------------------------------------------------------------ geography
G = json.load(open(f"{D}/geo/geo.json"))
def rings(gj):
    if gj["type"] == "Polygon": ps = [gj["coordinates"]]
    elif gj["type"] == "MultiPolygon": ps = gj["coordinates"]
    elif gj["type"] == "GeometryCollection": return [r for g in gj["geometries"] for r in rings(g)]
    else: return []
    return [np.array(r, float) for p in ps for r in p]
def lines_of(gj):
    if gj["type"] == "LineString": return [np.array(gj["coordinates"], float)]
    if gj["type"] == "MultiLineString": return [np.array(l, float) for l in gj["coordinates"]]
    if gj["type"] == "GeometryCollection": return [l for g in gj["geometries"] for l in lines_of(g)]
    return []
COUNTRIES = [rings(v) for v in G["countries"].values()]
LANDR = rings(G["land"]); PSX = rings(G["psx"])
RIVERS = [l for v in G["rivers"].values() for g in v for l in lines_of(g)]
def path(c, cam, rs, close=True):
    k = cam.k; kx = k * math.cos(math.radians(cam.lat))
    for r in rs:
        xs = 540 + (r[:, 0] - cam.lon) * kx; ys = cam.cy - (r[:, 1] - cam.lat) * k
        c.move_to(xs[0], ys[0])
        for x_, y_ in zip(xs[1:], ys[1:]): c.line_to(x_, y_)
        if close: c.close_path()

# ------------------------------------------------------------------ places (lon, lat, label side, group)
P = {
 "Ur": (46.103, 30.962, "r", "IQ"), "Haran": (39.03, 36.86, "r", "TR"), "Shechem": (35.281, 32.213, "r", "IL"),
 "Hebron": (35.111, 31.525, "l", "IL"), "Bethel": (35.240, 31.927, "l", "IL"), "Egypt": (31.85, 30.55, "l", "EG"),
 "The sea": (32.56, 29.93, "l", "EG"), "Mount Sinai": (33.975, 28.539, "l", "EG"), "Kadesh": (34.42, 30.65, "l", "EG"),
 "Mount Nebo": (35.725, 31.768, "r", "JO"), "Jericho": (35.444, 31.871, "r", "IL"), "Shiloh": (35.290, 32.055, "r", "IL"),
 "Bethlehem": (35.200, 31.705, "l", "IL"), "Jerusalem": (35.236, 31.776, "r", "IL"), "Samaria": (35.196, 32.276, "l", "IL"),
 "Babylon": (44.421, 32.536, "r", "IQ"), "Shushan": (48.257, 32.190, "l", "IR"),
}
assert len(P) == 17
GROUPS = {"EG": 4, "IQ": 2, "TR": 1, "JO": 1, "IR": 1, "IL": 8}
assert all(sum(1 for v in P.values() if v[3] == g) == n for g, n in GROUPS.items())
LIT = {  # first time each pin lights
 "Ur": wt(1, "Ur"), "Haran": wt(1, "Haran"), "Shechem": wt(1, "Canaan"), "Hebron": wt(2, "Hebron"), "Bethel": wt(3, "Bethel"),
 "Egypt": wt(3, "Egypt"), "The sea": wt(4, "sea"), "Mount Sinai": wt(4, "Sinai"), "Kadesh": wt(5, "Kadesh"),
 "Mount Nebo": wt(6, "Nebo"), "Jericho": wt(7, "Jericho"), "Shiloh": wt(8, "Shiloh"), "Bethlehem": wt(9, "Bethlehem"),
 "Jerusalem": wt(9, "Jerusalem"), "Samaria": wt(10, "Samaria"), "Babylon": wt(11, "Babylon"), "Shushan": wt(12, "Shushan"),
}
PULSE = {"Jerusalem": [wt(10, "Solomon's"), wt(11, "Jerusalem"), wt(13, "home"), L0(14)], "Babylon": [L0(13)], "Egypt": [L0(4)]}
# labels shown while the story is on that place (start, end)
LAB = {
 "Ur": (LIT["Ur"], L1(1) + 0.2), "Haran": (LIT["Haran"], L1(1) + 0.2), "Shechem": (LIT["Shechem"], L0(2) + 0.2),
 "Hebron": (LIT["Hebron"], L0(3) + 0.3), "Bethel": (LIT["Bethel"], wt(3, "Joseph")), "Egypt": (LIT["Egypt"], wt(4, "sea")),
 "The sea": (LIT["The sea"], L1(4) + 0.2), "Mount Sinai": (LIT["Mount Sinai"], L0(5) + 0.4), "Kadesh": (LIT["Kadesh"], L0(6) + 0.3),
 "Mount Nebo": (LIT["Mount Nebo"], L0(7) + 0.3), "Jericho": (LIT["Jericho"], L0(8) + 0.2), "Shiloh": (LIT["Shiloh"], L0(9) + 0.2),
 "Bethlehem": (LIT["Bethlehem"], L0(10) + 0.2), "Jerusalem": (LIT["Jerusalem"], wt(11, "Ezekiel")), "Samaria": (LIT["Samaria"], L0(11) + 0.2),
 "Babylon": (LIT["Babylon"], L0(12) + 0.3), "Shushan": (LIT["Shushan"], L0(13) + 0.3),
}
# routes: waypoints, draw window
def R(*names_or_pts):
    return [P[n][:2] if isinstance(n, str) else n for n in names_or_pts]
ROUTES = [
 (R("Ur", (43.2, 33.2), (40.9, 34.5), (38.6, 35.9), "Haran"), LIT["Ur"] + 0.1, LIT["Haran"] + 0.1),
 (R("Haran", (37.2, 35.2), (36.3, 33.5), (35.6, 32.8), "Shechem"), LIT["Haran"] + 0.15, LIT["Shechem"] + 0.35),
 (R("Shechem", "Bethel", "Hebron"), LIT["Shechem"] + 0.4, LIT["Hebron"] + 0.1),
 (R("Hebron", (34.79, 31.25), (33.5, 30.9), "Egypt"), wt(3, "Joseph"), LIT["Egypt"] + 0.15),
 (R("Egypt", "The sea"), L0(4) + 0.2, LIT["The sea"] + 0.1),
 (R("The sea", (33.0, 29.2), "Mount Sinai"), LIT["The sea"] + 0.15, LIT["Mount Sinai"] + 0.1),
 (R("Mount Sinai", (34.2, 29.6), "Kadesh"), L0(5) + 0.3, LIT["Kadesh"] + 0.1),
 (R("Kadesh", (35.15, 30.45), (35.55, 31.15), "Mount Nebo"), wt(6, "Moses"), LIT["Mount Nebo"] + 0.1),
 (R("Mount Nebo", "Jericho"), L0(7) - 0.1, LIT["Jericho"] + 0.1),
 (R("Jericho", "Shiloh"), L0(8) - 0.1, LIT["Shiloh"] + 0.1),
 (R("Bethlehem", "Jerusalem"), LIT["Bethlehem"] + 0.2, LIT["Jerusalem"] + 0.1),
 (R("Jerusalem", (36.3, 33.5), (37.6, 35.6), (38.6, 36.1), (40.9, 34.5), (43.2, 33.2), "Babylon"), wt(11, "Ezekiel"), LIT["Babylon"] + 0.1),
 (R("Babylon", (46.2, 32.6), "Shushan"), L0(12) - 0.05, LIT["Shushan"] + 0.1),
 (R("Babylon", (43.2, 33.2), (40.9, 34.5), (38.6, 36.1), (37.6, 35.6), (36.3, 33.5), "Jerusalem"), L0(13), L1(13) + 0.3),
]
def poly_len(pts):
    return [0.0] + list(np.cumsum([math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(pts, pts[1:])]))

# ------------------------------------------------------------------ books (Tanakh order, 24)
BOOKS = [  # (number, English, Hebrew, start time)
 (1, "GENESIS", "בראשית", L0(1) - 0.1), (2, "EXODUS", "שמות", L0(4) - 0.1), (4, "NUMBERS", "במדבר", L0(5) - 0.1),
 (5, "DEUTERONOMY", "דברים", L0(6) - 0.1), (6, "JOSHUA", "יהושע", L0(7) - 0.1), (7, "JUDGES", "שופטים", L0(8) - 0.1),
 (8, "SAMUEL", "שמואל", L0(9) - 0.1), (9, "KINGS", "מלכים", L0(10) - 0.1), (10, "ISAIAH", "ישעיהו", L0(11) - 0.1),
 (11, "JEREMIAH", "ירמיהו", wt(11, "Jeremiah") - 0.1), (12, "EZEKIEL", "יחזקאל", wt(11, "Ezekiel") - 0.1),
 (21, "ESTHER", "אסתר", L0(12) - 0.1), (23, "EZRA AND NEHEMIAH", "עזרא ונחמיה", L0(13) - 0.1),
 (24, "CHRONICLES", "דברי הימים", L0(14) - 0.1),
]
BOOK_END = L0(15) - 0.1

# ------------------------------------------------------------------ cameras
HOOK = Cam(39.6, 32.2, 21.5, 1010)
CAMS = [  # (time the move starts, camera, move seconds)
 (0.0, HOOK, 0.01),
 (L0(1) - 0.2, Cam(40.0, 33.4, 18.5, 1020), 0.8),
 (LIT["Shechem"] + 0.5, Cam(34.6, 31.4, 5.2, 860), 1.0),           # Canaan (photo below)
 (wt(3, "Joseph") - 0.1, Cam(33.6, 30.6, 7.8, 960), 0.9),          # Hebron to Egypt
 (L0(4) - 0.1, Cam(33.2, 29.9, 7.0, 980), 0.8),                    # Exodus
 (L0(5), Cam(34.1, 30.1, 6.6, 1000), 0.8),                         # Numbers
 (L0(6), Cam(35.1, 31.0, 4.6, 860), 0.9),                          # Nebo (photo below)
 (L0(7) - 0.1, Cam(35.3, 31.95, 2.1, 1000), 0.9),                  # the hills
 (L0(11) + 0.1, Cam(35.3, 31.85, 2.6, 980), 0.6),
 (wt(11, "Ezekiel") - 0.1, Cam(40.5, 33.2, 17.5, 860), 1.1),       # exile (photo below)
 (L0(12) - 0.1, Cam(41.8, 32.6, 17.0, 900), 0.7),
 (L0(13) - 0.1, Cam(40.5, 33.2, 17.5, 1000), 0.6),
 (L0(14) - 0.15, Cam(35.24, 31.80, 3.0, 820), 1.0),                # Jerusalem (photo below)
 (L0(15) - 0.15, Cam(39.6, 32.4, 21.0, 1080), 1.0),                # all 17
 (L0(16) - 0.1, Cam(39.6, 32.0, 21.0, 1180), 0.7),                 # tally rows on top
 (L0(17) - 0.1, Cam(35.25, 31.92, 1.95, 1060), 1.3),               # the eight
 (L0(19) - 0.15, HOOK, max(0.6, END - LOOP - L0(19) - 0.1)),       # back to the hook view
]
def camera(t):
    cur = CAMS[0][1]
    for i, (t0, c, mv) in enumerate(CAMS):
        if t < t0: break
        prev = cur if i else c
        u = seg(t, t0, t0 + mv); cur = cl(prev, c, u) if u < 1 else c
    nxt = [c for t0, c, _ in CAMS if t0 > t]
    # slow drift so no frame is static
    d = 1 + 0.02 * math.sin(t * 0.35)
    return Cam(cur.lon, cur.lat, cur.wdeg / d, cur.cy)

# ------------------------------------------------------------------ photos (lower panel, Ken Burns)
def ph(n): return Image.open(f"{D}/photos/{n}.jpg").convert("RGB")
def credit(n):
    m = json.load(open(f"{D}/photos/{n}.json")); return m.get("credit_line", "Wikimedia Commons").replace(", Wikimedia Commons", ", Commons")
PHOTOS = [  # name, t0, t1, caption
 ("bm_hebron", LIT["Hebron"] + 0.15, LIT["Hebron"] + 3.25, "Cave of the Patriarchs, Hebron"),
 ("bm_nebo", LIT["Mount Nebo"] + 0.1, LIT["Mount Nebo"] + 3.1, "Mount Nebo, Jordan"),
 ("bm_babylon", LIT["Babylon"] + 0.05, LIT["Babylon"] + 3.05, "Ruins of Babylon, Iraq"),
 ("bm_jlm2", L0(14) + 0.1, L0(14) + 3.3, "Jerusalem, the Temple Mount"),
]
PIM = {n: ph(n) for n, *_ in PHOTOS}; PCR = {n: credit(n) for n, *_ in PHOTOS}
PX0, PY0, PW, PH_ = 70, 1000, 940, 400
_pmask = Image.new("L", (PW * 2, PH_ * 2), 0); ImageDraw.Draw(_pmask).rounded_rectangle((0, 0, PW * 2 - 1, PH_ * 2 - 1), 64, fill=255)
PMASK = _pmask.resize((PW, PH_), Image.LANCZOS)
def photo(im, t):
    for n, t0, t1, cap in PHOTOS:
        a = win(t, t0, t1, 0.3, 0.3)
        if a <= 0.01: continue
        src = PIM[n]; u = clamp((t - t0) / (t1 - t0)); z = 1.0 + 0.08 * u
        sw, sh = src.size; r = max(PW / sw, PH_ / sh) * z
        cw, ch = PW / r, PH_ / r; cx_, cy_ = sw / 2 + (u - 0.5) * (sw - cw) * 0.3, sh / 2
        crop = src.transform((PW, PH_), Image.EXTENT, (cx_ - cw / 2, cy_ - ch / 2, cx_ + cw / 2, cy_ + ch / 2), Image.BICUBIC).convert("RGBA")
        g = np.zeros((PH_, PW), np.float32); yy = np.arange(PH_)[:, None]; g += np.clip((yy - PH_ * 0.55) / (PH_ * 0.45), 0, 1) * 0.8
        dark = Image.new("RGBA", (PW, PH_), (5, 10, 24, 0)); dark.putalpha(Image.fromarray((g * 255).astype(np.uint8)))
        crop.alpha_composite(dark)
        d = ImageDraw.Draw(crop)
        d.text((36, PH_ - 78), cap, font=F(44, 800), fill=(255, 255, 255, 255), anchor="ls")
        d.text((36, PH_ - 28), PCR[n], font=F(36, 400), fill=hx(LGREY) + (255,), anchor="ls")
        sc = 0.94 + 0.06 * eout((t - t0) / 0.35)
        m = PMASK.point(lambda v: int(v * a)); crop.putalpha(m)
        if sc < 0.999:
            crop = crop.resize((int(PW * sc), int(PH_ * sc)), Image.LANCZOS)
        sh_ = Image.new("RGBA", (crop.width + 80, crop.height + 80), (0, 0, 0, 0))
        sh_.putalpha(Image.new("L", sh_.size, 0)); ImageDraw.Draw(sh_).rounded_rectangle((40, 50, crop.width + 40, crop.height + 50), 32, fill=(0, 0, 0, int(150 * a)))
        sh_ = sh_.filter(ImageFilter.GaussianBlur(18))
        ox, oy = int(540 - crop.width / 2), int(PY0 + PH_ / 2 - crop.height / 2)
        _paste(im, sh_, ox - 40, oy - 40); _paste(im, crop, ox, oy)
        # thin white rim
        rim = Image.new("RGBA", crop.size, (0, 0, 0, 0)); ImageDraw.Draw(rim).rounded_rectangle((1, 1, crop.width - 2, crop.height - 2), 31, outline=(255, 255, 255, int(170 * a)), width=3)
        _paste(im, rim, ox, oy)

# ------------------------------------------------------------------ map layer (cairo)
GRP_T = {"EG": wt(16, "Egypt"), "IQ": wt(16, "Iraq"), "TR": wt(16, "Turkey"), "JO": wt(16, "Jordan"), "IR": wt(16, "Iran"), "IL": wt(17, "eight")}
def map_layer(t, cam):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, W, H); c = cairo.Context(surf); c.set_line_join(cairo.LINE_JOIN_ROUND); c.set_line_cap(cairo.LINE_CAP_ROUND)
    # sea gradient
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *hf("#06102A")); g.add_color_stop_rgb(1, *hf("#0A1A40")); c.set_source(g); c.paint()
    for rs in COUNTRIES:
        path(c, cam, rs); c.set_source_rgb(*hf(LAND)); c.fill_preserve(); c.set_source_rgba(*hf(LAND_E), 0.9); c.set_line_width(1.6); c.stroke()
    # rivers
    for l in RIVERS:
        path(c, cam, [l], close=False); c.set_source_rgba(*hf(SKY), 0.55); c.set_line_width(2.4 if cam.wdeg > 6 else 3.2); c.stroke()
    # the whole land of Israel in gold, West Bank and Gaza a shade darker, Green Line green
    path(c, cam, LANDR); c.set_source_rgba(*hf(GOLD), 0.95); c.fill()
    path(c, cam, PSX); c.set_source_rgba(*hf(WB), 1.0); c.fill()
    gl = 2.2 + 3.0 * clamp((8 - cam.wdeg) / 6)
    il8 = win(t, GRP_T["IL"] - 0.1, L0(18) + 0.5, 0.3, 0.6)
    path(c, cam, PSX); c.set_source_rgba(*GREEN, 1.0); c.set_line_width(gl + 2.5 * il8); c.set_dash([12, 7]); c.stroke(); c.set_dash([])
    # routes
    for pts, t0, t1 in ROUTES:
        if t < t0: continue
        u = clamp((t - t0) / max(0.15, t1 - t0)); u = eout(u)
        cum = poly_len(pts); tot = cum[-1]; L = u * tot
        xy_ = [xy(cam, *p) for p in pts]
        c.move_to(*xy_[0]); end = xy_[0]
        for i in range(1, len(pts)):
            if cum[i] <= L: c.line_to(*xy_[i]); end = xy_[i]
            else:
                f = (L - cum[i - 1]) / max(1e-9, cum[i] - cum[i - 1]); a_, b_ = xy_[i - 1], xy_[i]
                end = (lerp(a_[0], b_[0], f), lerp(a_[1], b_[1], f)); c.line_to(*end); break
        fresh = 1 - seg(t, t1 + 0.6, t1 + 1.6)
        al = 0.42 + 0.58 * fresh
        for wdt, aa in ((16, 0.10), (9, 0.22), (5.5, 1.0)):
            c.set_source_rgba(*hf(YELLOW), aa * al); c.set_line_width(wdt); c.stroke_preserve()
        c.new_path()
        if u < 1:  # travelling head
            c.arc(end[0], end[1], 9, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, 0.95); c.fill()
    # pins
    hook_a = 1 - seg(t, L0(1) - 0.3, L0(1) + 0.2)
    for i, (n, (lon, lat, side, grp)) in enumerate(P.items()):
        x_, y_ = xy(cam, lon, lat)
        if not (-60 < x_ < W + 60 and -60 < y_ < H + 60): continue
        lit = seg(t, LIT[n] - 0.05, LIT[n] + 0.25)
        hk = hook_a * seg(t, 0.25 + 0.06 * i, 0.45 + 0.06 * i)       # hook shimmer: all 17 pop in
        a = max(lit, hk)
        if t > END - LOOP - 0.5: a = max(a, 1.0)
        if a <= 0.01: continue
        pop = 1 + 0.9 * (1 - eout((t - LIT[n]) / 0.45)) if LIT[n] <= t < LIT[n] + 0.45 else 1.0
        pul = 0.0
        for tp in PULSE.get(n, []):
            if tp <= t < tp + 0.6: pul = max(pul, 1 - (t - tp) / 0.6)
        gt = GRP_T[grp]
        if gt <= t < gt + 0.8: pul = max(pul, 1 - (t - gt) / 0.8)
        if grp == "IL" and GRP_T["IL"] <= t < L0(18) + 0.5: pul = max(pul, 0.5 + 0.5 * math.sin((t - GRP_T["IL"]) * 6))
        if t >= L0(15) and t < GRP_T["EG"] - 0.1:   # "17 spots": quick roll-call pulse
            tp = L0(15) + 0.12 * i
            if tp <= t < tp + 0.5: pul = max(pul, 1 - (t - tp) / 0.5)
        r = 11 * pop
        if pul > 0:
            c.arc(x_, y_, r + 10 + 26 * (1 - pul), 0, 2 * math.pi); c.set_source_rgba(*hf(YELLOW), 0.55 * pul * a); c.set_line_width(4); c.stroke()
        c.arc(x_, y_, r + 9, 0, 2 * math.pi); c.set_source_rgba(*hf(SKY), 0.30 * a); c.fill()
        c.arc(x_, y_, r + 2.5, 0, 2 * math.pi); c.set_source_rgba(1, 1, 1, a); c.fill()
        c.arc(x_, y_, r - 1, 0, 2 * math.pi); c.set_source_rgba(*hf(YELLOW), a); c.fill()
    surf.flush()
    arr = np.ndarray((H, W, 4), np.uint8, surf.get_data())
    return Image.fromarray(arr[:, :, [2, 1, 0, 3]].copy(), "RGBA")

# vignettes for the top card and the subtitles
_v = np.zeros((H, W), np.float32); yy = np.arange(H)[:, None] + np.zeros((1, W))
_v += np.clip((760 - yy) / 760, 0, 1) ** 1.25 * 0.88 + np.clip((yy - 1380) / 540, 0, 1) ** 1.2 * 0.75
VIG = Image.new("RGBA", (W, H), hx("#071026") + (0,)); VIG.putalpha(Image.fromarray((_v.clip(0, 1) * 255).astype(np.uint8)))

# ------------------------------------------------------------------ place labels
LBL_OFF = {"Jerusalem": (0, 24), "Bethlehem": (0, 26), "Samaria": (0, -12), "Shechem": (0, -6), "Jericho": (0, -4), "Bethel": (0, -6), "Shiloh": (0, 4)}
EIGHT = [n for n, v in P.items() if v[3] == "IL"]
def labels(im, t, cam):
    for n, (lon, lat, side, grp) in P.items():
        t0, t1 = LAB[n]; a = win(t, t0, t1, 0.25, 0.3)
        if grp == "IL": a = max(a, win(t, GRP_T["IL"] + 0.3, L0(19) - 0.1, 0.4, 0.4))
        if a <= 0.01: continue
        x_, y_ = xy(cam, lon, lat); dx, dy = LBL_OFF.get(n, (0, 0))
        sz = 56 if cam.wdeg > 2.5 else 52
        if side == "r": text(im, n, x_ + 26, y_ + dy, sz, WHITE, a, 800, "lm")
        else: text(im, n, x_ - 26, y_ + dy, sz, WHITE, a, 800, "rm")

# ------------------------------------------------------------------ top card: hook, book counter, tally, eight, balance, lead-in
def book_at(t):
    cur = None
    for b in BOOKS:
        if t >= b[3]: cur = b
    return cur
def counter(im, t):
    a = seg(t, BOOKS[0][3], BOOKS[0][3] + 0.3) * (1 - seg(t, BOOK_END, BOOK_END + 0.35))
    if a <= 0.01: return
    b = book_at(t)
    if b is None: return
    i = BOOKS.index(b); prev = BOOKS[i - 1][0] if i else 0
    u = clamp((t - b[3]) / 0.45); num = round(lerp(prev, b[0], eout(u)))
    pop = 1 + 0.18 * (1 - eout((t - b[3]) / 0.35))
    # BOOK  n  OF 24
    f1, f2 = F(64, 800), F(int(130 * pop), 900)
    s1, s2, s3 = "BOOK ", str(num), " OF 24"
    w1, w3 = f1.getlength(s1), f1.getlength(s3); w2 = F(130, 900).getlength("24")
    x0 = 540 - (w1 + w2 + w3) / 2
    text(im, s1, x0, 362, 64, WHITE, a, 800, "lb")
    text(im, s2, x0 + w1 + w2 / 2, 372, 130, YELLOW, a, 900, "mb", scale=pop)
    text(im, s3, x0 + w1 + w2, 362, 64, WHITE, a, 800, "lb")
    na = a * seg(t, b[3], b[3] + 0.25)
    text(im, b[1], 540, 452, fit(b[1], 92, 900), WHITE, na, 900, "mm")
    text(im, b[2], 540, 540, 64, SKY, na, 800, "mm", rtl=True)

TALLY = [("EG", "Egypt", 4, "eg"), ("IQ", "Iraq", 2, "iq"), ("TR", "Turkey", 1, "tr"), ("JO", "Jordan", 1, "jo"), ("IR", "Iran", 1, "ir")]
FLAGS = {}
for _, _, _, f in TALLY:
    fl = Image.open(f"{D}/flags/{f}.png").convert("RGBA"); FLAGS[f] = fl.resize((86, round(fl.height * 86 / fl.width)), Image.LANCZOS)
def topcard(im, t):
    # hook (frame 0, said once)
    ha = 1 - seg(t, L0(1) - 0.25, L0(1) + 0.05)
    if ha > 0.01:
        z = 1 + 0.03 * seg(t, 0, 3)
        text(im, "24 BOOKS.", 540, 360, 150, YELLOW, ha, 900, "mm", scale=z)
        text(im, "ONE MAP.", 540, 520, 150, WHITE, ha, 900, "mm", scale=z)
    counter(im, t)
    # 17 places
    a = win(t, L0(15) - 0.05, GRP_T["EG"] - 0.05, 0.3, 0.25)
    if a > 0.01:
        u = clamp((t - L0(15)) / 1.6); n = round(17 * eout(u))
        text(im, str(n), 540, 400, 210, YELLOW, a, 900, "mm")
        text(im, "PLACES IN THE STORY", 540, 545, 72, WHITE, a, 900, "mm")
    # tally rows
    ta = win(t, GRP_T["EG"] - 0.1, L0(17) + 0.2, 0.25, 0.35)
    if ta > 0.01:
        for j, (g, name, cnt, f) in enumerate(TALLY):
            ra = ta * seg(t, GRP_T[g] - 0.05, GRP_T[g] + 0.25)
            if ra <= 0.01: continue
            y_ = 300 + j * 92; fl = FLAGS[f]
            fla = fl.copy(); fla.putalpha(fl.getchannel("A").point(lambda v: int(v * ra))); _paste(im, fla, 250, int(y_ - fl.height / 2))
            text(im, name, 360, y_, 66, WHITE, ra, 800, "lm")
            text(im, str(cnt), 830, y_, 80, YELLOW, ra, 900, "rm")
    # the eight
    ea = win(t, GRP_T["IL"] - 0.1, L0(18) - 0.05, 0.3, 0.3)
    if ea > 0.01:
        pop = 1 + 0.25 * (1 - eout((t - GRP_T["IL"]) / 0.4))
        text(im, "8", 540, 360, 230, YELLOW, ea, 900, "mm", scale=pop)
        sa = ea * seg(t, wt(17, "past") - 0.1, wt(17, "past") + 0.2)
        text(im, "past the 1967 line", 540, 520, 76, WHITE, sa, 900, "mm")
        ja = ea * seg(t, wt(17, "Judea") - 0.1, wt(17, "Judea") + 0.2)
        text(im, "Judea, Samaria, East Jerusalem", 540, 610, fit("Judea, Samaria, East Jerusalem", 54, 800, 940), SKY, ja, 800, "mm")
    # balance
    ba = win(t, L0(18) - 0.05, L0(19) - 0.05, 0.3, 0.25)
    if ba > 0.01:
        text(im, "Archaeologists debate", 540, 310, fit("Archaeologists debate", 92, 900), WHITE, ba, 900, "mm")
        text(im, "the details.", 540, 415, 92, WHITE, ba, 900, "mm")
        ra = ba * seg(t, wt(18, "places") - 0.25, wt(18, "places") + 0.1)
        text(im, "The places are real.", 540, 530, fit("The places are real.", 92, 900), YELLOW, ra, 900, "mm")
    # lead-in (where the hook sits)
    la = seg(t, L0(19) - 0.05, L0(19) + 0.3)
    if la > 0.01:
        text(im, "SO NEXT TIME SOMEONE", 540, 360, fit("SO NEXT TIME SOMEONE", 104, 900), WHITE, la, 900, "mm")
        text(im, "CALLS JEWS COLONIZERS...", 540, 500, fit("CALLS JEWS COLONIZERS...", 104, 900), YELLOW, la * seg(t, wt(19, "calls") - 0.1, wt(19, "calls") + 0.2), 900, "mm")

# last word of the Hebrew Bible, on the Jerusalem beat
def lastword(im, t):
    a = win(t, wt(14, "word") + 0.1, L1(14) + 0.35, 0.3, 0.3)
    if a <= 0.01: return
    text(im, "ויעל", 540, 760, 170, YELLOW, a, 900, "mm", rtl=True, scale=1 + 0.1 * (1 - eout((t - wt(14, "word") - 0.1) / 0.4)))
    text(im, "let him go up", 540, 890, 72, WHITE, a * seg(t, wt(14, "let") - 0.1, wt(14, "let") + 0.2), 900, "mm")

# ------------------------------------------------------------------ source labels (38 px, under the top card)
SRC = [
 (0.0, ["Book count: Tanakh, 24 books (Christian Old Testament: 39)"]),
 (L0(1) - 0.1, ["Sites: Oxford Bible Atlas, 4th ed., 2007", "Ur excavated by Leonard Woolley, 1922 to 1934"]),
 (LIT["Hebron"], ["Cave enclosure: built under Herod, 1st century BCE", "Sites: Oxford Bible Atlas, 4th ed., 2007"]),
 (L0(4) - 0.1, ["Sea crossing and Mount Sinai: traditional sites,", "their locations are debated"]),
 (L0(5) - 0.1, ["Kadesh Barnea: Ein el-Qudeirat, Sinai (traditional)", "Sites: Oxford Bible Atlas, 4th ed., 2007"]),
 (L0(6) - 0.1, ["Deuteronomy 34: Moses sees the land from Nebo", "Sites: Oxford Bible Atlas, 4th ed., 2007"]),
 (L0(8) - 0.1, ["Tel Shiloh: excavated by Israel Finkelstein,", "1981 to 1984"]),
 (L0(10) - 0.1, ["Samaria (Sebastia): excavated by Harvard,", "1908 to 1910"]),
 (wt(11, "Ezekiel") - 0.1, ["Babylon: UNESCO World Heritage site, 2019"]),
 (L0(12) - 0.1, ["Susa (Shushan): UNESCO World Heritage site, 2015"]),
 (L0(14) - 0.1, ["Last verse of the Tanakh: 2 Chronicles 36:23"]),
 (L0(15) - 0.1, ["Count: the 17 places named in this video,", "by today's borders"]),
 (L0(17) - 0.1, ["Jerusalem's Old City and City of David lie", "east of the 1949 armistice line (Green Line)"]),
 (L0(18) - 0.1, ["Sites: Oxford Bible Atlas, 4th ed., 2007"]),
 (L0(19) - 0.1, []),
]
def sources(im, t, y0):
    for i, (t0, ls) in enumerate(SRC):
        t1 = SRC[i + 1][0] if i + 1 < len(SRC) else 1e9
        a = (1.0 if t0 <= 0 else seg(t, t0, t0 + 0.3)) * (1 - seg(t, t1 - 0.2, t1))
        if t >= t0 - 0.01 and a > 0.01:
            for j, l in enumerate(ls): text(im, l, 540, y0 + j * 46, 38, LGREY, a, 400, "mm")

def src_y(t):
    if L0(16) - 0.2 <= t < L0(17) + 0.1: return 790     # under the tally rows
    if L0(17) - 0.1 <= t < L0(18): return 700           # under "Judea, Samaria..."
    if L0(14) - 0.1 <= t < L0(15): return 960
    return 625

# ------------------------------------------------------------------ subtitles (Heebo ExtraBold 54 on a dark rounded box)
REPL = [("Twenty-four", "24"), ("twenty-four", "24"), ("nineteen sixty-seven", "1967"), ("seventeen", "17")]
CHUNKS = []
for li, L in enumerate(LINES):
    ws = L["words"]; cur = []
    for k, w in enumerate(ws):
        cur.append(w)
        brk = w["w"][-1] in ".?!:" or (w["w"][-1] == "," and len(cur) >= 4) or len(cur) >= 7
        if brk or k == len(ws) - 1:
            s = " ".join(x["w"] for x in cur)
            for a_, b_ in REPL: s = s.replace(a_, b_)
            CHUNKS.append([cur[0]["t0"] - 0.05, cur[-1]["t1"] + 0.25, s]); cur = []
# merge one-word chunks into the next one on the same line where it reads better
for i in range(len(CHUNKS) - 1):
    CHUNKS[i][1] = min(CHUNKS[i][1], CHUNKS[i + 1][0] - 0.02)
SUBF = F(54, 800)
def subtitles(im, t):
    for a0, a1, s in CHUNKS:
        if a0 <= t < a1:
            al = min(1, (t - a0) / 0.08, (a1 - t) / 0.08)
            words = s.split(); lines_ = [[]]
            for w_ in words:
                tr = " ".join(lines_[-1] + [w_])
                if SUBF.getlength(tr) <= 880 or not lines_[-1]: lines_[-1].append(w_)
                else: lines_.append([w_])
            ls = [" ".join(l) for l in lines_]; lh = 70
            bw = max(SUBF.getlength(l) for l in ls) + 56; bh = lh * len(ls) + 30
            y1 = 1525; y0 = y1 - bh
            lay = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(lay)
            d.rounded_rectangle((540 - bw / 2, y0, 540 + bw / 2, y1), 26, fill=(6, 12, 28, int(200 * al)))
            for j, l in enumerate(ls):
                d.text((540, y0 + 15 + lh * j + lh / 2), l, font=SUBF, fill=(255, 255, 255, int(255 * al)), anchor="mm")
            im.alpha_composite(lay)

# ------------------------------------------------------------------ frame
def frame_raw(t):
    cam = camera(t)
    im = map_layer(t, cam)
    labels(im, t, cam)
    im.alpha_composite(VIG)
    photo(im, t)
    topcard(im, t)
    lastword(im, t)
    sources(im, t, src_y(t))
    subtitles(im, t)
    return im
F0 = None
def frame(t):
    global F0
    im = frame_raw(t)
    if t > END - LOOP:   # circular: cross-fade into frame 0
        if F0 is None: F0 = frame_raw(0.0)
        u = ease((t - (END - LOOP)) / LOOP); im = Image.blend(im, F0, u)
    return im.convert("RGB")

if A.events:
    ev = [(b[3], "whoosh", -2) for b in BOOKS] + [(v + 0.02, "pop", -4) for v in LIT.values()]
    ev += [(GRP_T[g] + 0.3, "pop", -2) for g in GRP_T if g != "IL"] + [(GRP_T["IL"], "ding", 1), (L0(15) - 0.1, "whoosh", -1), (L0(19) - 0.1, "whoosh", -3)]
    ev += [(t0, "whoosh", -6) for _, t0, _, _ in PHOTOS]
    json.dump(dict(END=END, events=sorted(ev)), open(f"{D}/events.json", "w")); print(len(ev), END); sys.exit()
if A.snaps:
    os.makedirs(f"{D}/snaps", exist_ok=True)
    for s in A.snaps.split(","):
        t = END - 0.02 if s == "last" else float(s)
        frame(t).save(f"{D}/snaps/f_{t:06.2f}.png")
    print("END", END)
def render_frame(i): return frame(i / FPS).tobytes()
if A.out and not A.snaps:
    nf = int(round(END * FPS)); silent = A.out.replace(".mp4", "_silent.mp4")
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0",
                          "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", silent], stdin=subprocess.PIPE)
    from multiprocessing import Pool
    with Pool(A.jobs or os.cpu_count()) as pool:
        for fr in pool.imap(render_frame, range(nf), chunksize=4): p.stdin.write(fr)
    p.stdin.close(); p.wait()
    mix = f"{D}/mix.m4a"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", silent, "-i", mix, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "copy",
                    "-t", f"{END:.2f}", "-movflags", "+faststart", A.out], check=True)
    os.remove(silent); print("final", A.out)
