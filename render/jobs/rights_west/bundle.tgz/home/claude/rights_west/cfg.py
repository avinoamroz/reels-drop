"""rights_west: Can Israel pass 5 Western tests? Israel vs 6 Western democracies, 5 yes/no tests (sibling of lib_mena_rights_v4).
Tests (V = point, ~ = partly, no point, X = no):
 1 Rated Free: Freedom House, Freedom in the World 2026 (status Free).
 2 Free press: RSF World Press Freedom Index 2026, score 70+ ("good" or "satisfactory").
   NL 88.92, DE 82.17, UK 79.45, FR 76.68, ES 75.42, US 62.61, IL 46.46 (rank 116).
 3 Same-sex marriage (or civil union) at home. Israel: none performed at home; marriages done abroad are registered (High Court 2006). -> partly.
 4 No death penalty. US: 47 executions in 2025 (DPI). Israel: Death Penalty for Terrorists Law passed 30 Mar 2026, in force; last execution 1962. -> partly.
 5 LGBT workers protected by law: IL 1992 Equal Employment Opportunities Law amendment; US Bostock 2020; UK Equality Act 2010; EU Directive 2000/78.
 Tie breaker (unscored): Freedom House 2026 total score /100.
Neighbours (stat card), same tests: Lebanon (PF 41), Jordan (PF 34), Egypt (NF 18), Syria (NF 10): 0 of 5 each."""
WHITE, GOLD, NAVY2, SILVER, YELLOW, RED, SKY = "#FFFFFF", "#D2AA53", "#0C1E3E", "#C9D1DC", "#FFD54A", "#E0453A", "#45A4DD"
D = "/home/claude/rights_west"

def build(wt, lt, LINES):
    CC = {"Netherlands": "nl", "Germany": "de", "UK": "gb", "Spain": "es", "France": "fr", "USA": "us", "Israel": "il",
          "Lebanon": "lb", "Jordan": "jo", "Egypt": "eg", "Syria": "sy"}
    TAB = {
        "Netherlands": ["V", "V", "V", "V", "V", "N"],
        "Germany":     ["V", "V", "V", "V", "V", "N"],
        "UK":          ["V", "V", "V", "V", "V", "N"],
        "Spain":       ["V", "V", "V", "V", "V", "N"],
        "France":      ["V", "V", "V", "V", "V", "N"],
        "USA":         ["V", "X", "V", "X", "V", "N"],
        "Israel":      ["V", "X", "~", "~", "V", "N"],
    }
    FH = {"Netherlands": 97, "Germany": 95, "UK": 92, "Spain": 91, "France": 89, "USA": 81, "Israel": 73}
    NUMROW = {c: str(v) for c, v in FH.items()}
    EXPECT = {"Netherlands": 5, "Germany": 5, "UK": 5, "Spain": 5, "France": 5, "USA": 3, "Israel": 2}
    LABELS = [("Rated", "Free"), ("Free press", "RSF 70+"), ("Same-sex", "marriage"), ("No death", "penalty"), ("LGBT jobs", "protected"),
              ("Freedom", "score /100")]
    G = {}
    G["A"] = dict(cols=["Germany", "UK", "Netherlands"], t_in=lt(5) - 0.45,
                  fill={"Netherlands": wt(5, "Netherlands"), "Germany": wt(5, "Germany"), "UK": wt(5, "Britain")},
                  score={"Germany": wt(5, "Five"), "UK": wt(5, "Five") + 0.12, "Netherlands": wt(5, "Five") + 0.24}, stagger=0.1)
    G["B"] = dict(cols=["Spain", "France", "USA"], t_in=lt(6) - 0.45,
                  fill={"Spain": wt(6, "Spain"), "France": wt(6, "France"), "USA": wt(7, "US")},
                  score={"Spain": wt(6, "Five"), "France": wt(6, "each"), "USA": wt(7, "three")}, stagger=0.1)
    T_ISR = wt(9, "Israel")
    G["D"] = dict(cols=["Spain", "USA", "Israel"], t_in=lt(8) - 0.3,
                  fill={"Spain": -9, "USA": -9, "Israel": T_ISR + 0.25},
                  score={"Spain": -9, "USA": -9, "Israel": wt(9, "Two")}, mystery=["Israel"], stagger=0.09,
                  pulse=[("Israel", 0, wt(10, "Rated")), ("Israel", 4, wt(10, "gay")), ("Israel", 2, wt(11, "samesex")),
                         ("Israel", 3, wt(12, "death")), ("Israel", 1, wt(13, "Press"))])
    ROWT = [wt(3, "Rated"), wt(3, "press"), wt(3, "samesex"), wt(4, "death"), wt(4, "gay"), wt(4, "law", end=True) + 0.1]
    SUBS = {
        1: [(6, "Israel is judged by Western standards."), (4, "So let's use them.")],
        2: [(4, "7 countries. 1 scorecard.")],
        3: [(5, "Rated Free by Freedom House?"), (3, "A free press?"), (4, "Same-sex marriage at home?")],
        4: [(3, "No death penalty?"), (6, "And gay workers protected by law?")],
        5: [(5, "The Netherlands, Germany and Britain."), (4, "5 out of 5.")],
        6: [(5, "Spain and France. 5 each.")],
        7: [(3, "The US, 3."), (4, "47 executions last year,"), (5, "and a press rated problematic.")],
        8: [(3, "One country left.")],
        9: [(5, "Israel. 2 out of 5.")],
        10: [(6, "Rated Free, and gay workers protected.")],
        11: [(7, "But same-sex couples can only marry abroad.")],
        12: [(5, "A new death penalty law,"), (7, "though no one executed since 1962.")],
        13: [(2, "Press freedom?"), (7, "116th in the world.")],
        14: [(4, "Last of the 7.")],
        15: [(4, "Now run the same"), (5, "5 tests on its neighbours.")],
        16: [(4, "Lebanon, Jordan, Egypt, Syria."), (4, "0 out of 5."), (2, "All 4.")],
    }
    PHOTOS = [
        dict(img=f"{D}/photos/knesset.jpg", t0=lt(1) - 0.15, t1=lt(2) - 0.05, fx=0.58, fy=0.5, cap_y=1250, cap_sz=84,
             cap=[("The Knesset,", WHITE), ("Jerusalem", GOLD)],
             credit=["Photo: Clema12, Wikimedia Commons, CC BY-SA 4.0"]),
        dict(img=f"{D}/photos/inject.jpg", t0=wt(7, "fortyseven") - 0.15, t1=lt(8) - 0.05, fx=0.36, fy=0.5, cap_y=1180, cap_sz=110,
             cap=[("47", YELLOW, " executions", WHITE), ("in the US, 2025", WHITE)],
             credit=["Death Penalty Information Center, 2025", "Photo: San Quentin, CDCR, public domain"]),
    ]
    NB = [("Lebanon", "lb", "Partly Free, 41/100"), ("Jordan", "jo", "Partly Free, 34/100"), ("Egypt", "eg", "Not Free, 18/100"), ("Syria", "sy", "Not Free, 10/100")]
    t_nb = [wt(16, "Lebanon"), wt(16, "Jordan"), wt(16, "Egypt"), wt(16, "Syria")]
    t_zero, t_all = wt(16, "Zero"), wt(16, "All")

    def stat_card(base, t, E):
        F, hexa, DR, clamp, ease, back, paste_c = E["F"], E["hexa"], E["DR"], E["clamp"], E["ease"], E["back"], E["paste_c"]
        T0, TQ = E["T_STAT"], E["T_Q"]
        a = clamp((t - T0) / 0.3) * (1 - clamp((t - TQ) / 0.3))
        if a <= 0: return
        d = DR(base); d.rectangle((0, 0, 1080, 1920), fill=hexa(NAVY2, int(255 * a)))
        d.text((60, 330), "Same 5 tests.", font=F(104, 900), fill=hexa(WHITE, int(255 * a)), anchor="ls")
        d.text((60, 450), "Its neighbours:", font=F(104, 900), fill=hexa(GOLD, int(255 * a)), anchor="ls")
        fl = E["FLAG"]
        for n, (nm, code, fh) in enumerate(NB):
            k = clamp((t - t_nb[n] + 0.12) / 0.35)
            if k <= 0: continue
            y = 560 + 180 * n; al = a * clamp(k * 2); xo = (1 - ease(k)) * -80
            im = fl[nm].resize((170, round(fl[nm].height * 170 / fl[nm].width)))
            paste_c(base, im, 145 + xo, y + 70, al)
            d.text((270 + xo, y + 78), nm, font=F(78, 900), fill=hexa(WHITE, int(255 * al)), anchor="ls")
            d.text((270 + xo, y + 132), fh, font=F(40, 800), fill=hexa(SILVER, int(255 * al)), anchor="ls")
            kz = clamp((t - t_zero - 0.08 * n) / 0.3)
            if kz > 0:
                pop = 1 + (0.25 * clamp((t - t_all) / 0.25) * (1 - clamp((t - t_all - 0.35) / 0.35)))
                d.text((1010, y + 100), "0/5", font=F(int(118 * max(0.3, back(kz)) * pop), 900), fill=hexa(RED, int(255 * a * kz)), anchor="rs")
        kI = clamp((t - t_all) / 0.35)
        if kI > 0:
            d.text((60, 1345), "Israel: 2/5. The West: 3 to 5.", font=F(60, 900), fill=hexa(YELLOW, int(255 * a * kI)), anchor="ls")
        d.text((60, 1420), "Status: Freedom House 2026. RSF 2026, ILGA,", font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")
        d.text((60, 1464), "Amnesty. Not one is rated Free.", font=F(36, 700), fill=hexa(SILVER, int(230 * a)), anchor="lm")

    return dict(CC=CC, TAB=TAB, NUMROW=NUMROW, TIEBREAK=FH, EXPECT=EXPECT, LABELS=LABELS, NSCORED=5, RH=124, LABEL_SZ=54, LABEL_GAP=28, ICON=0.95,
                CW=150, G=G, ORDER=["A", "B", "D"], ROWT=ROWT, MYSTERY={"Israel": T_ISR},
                T_TABLE=lt(3) - 0.25, T_COUNT=lt(2), CAR_LABEL="7 countries", HOOK_SZ=118,
                T_ISR=T_ISR, T_SB=lt(14) - 0.25, T_STAT=wt(15, "neighbours") - 0.25, T_Q=lt(17) - 0.2,
                HOOK=[("Can Israel", WHITE), ("pass ", WHITE, "5", YELLOW), ("Western", GOLD, " tests?", WHITE)],
                COUNT_LINE="7 countries. 1 scorecard.", TITLE="Can Israel pass 5 Western tests?",
                SRC=["Freedom House 2026, RSF 2026, DPI 2025, ILGA.", "Amber = partly, no point."],
                SB_TITLE="Score out of 5", SB_COL="Freedom", SB_HI={},
                SB_SRC=["Tie breaker: Freedom House score /100,", "Freedom in the World 2026. Sources in caption."],
                SUBS=SUBS, PHOTOS=PHOTOS, stat_card=stat_card)
