exec(open("/home/claude/vid/cfg_cities.py").read())
SNAPDIR="/tmp/claude-0/-home-claude/b92286a7-2fc5-5d63-9b99-51ddfdf225c3/scratchpad/en_only/snaps"
T_TOTAL=45.0; T_DATA=43.6; T_ENDC=44.2
TAG="cities_race_v5_en"; OUT_EN="/home/claude/en_only/out/cities_race_v5_en.mp4"; MUSIC="/home/claude/vid/music/p_t10.wav"
ROWS_EN=5
HOOK_EN=["5,000 years.","Which city wins?"]
SUB_EN="Israel's biggest cities"
SHORT_EN={}
COUNTER_EN="Population"
REVEAL_EN=(30.0,35.6,["Tel Aviv in 1908:","just sand dunes."])
END_EN=["That was","the last..."]
SRC_EN="Ancient: archaeological estimates. Modern: CBS"
